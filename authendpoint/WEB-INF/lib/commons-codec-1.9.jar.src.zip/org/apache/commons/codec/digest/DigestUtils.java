/*     */ package org.apache.commons.codec.digest;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import org.apache.commons.codec.binary.Hex;
/*     */ import org.apache.commons.codec.binary.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DigestUtils
/*     */ {
/*     */   private static final int STREAM_BUFFER_LENGTH = 1024;
/*     */   
/*     */   private static byte[] digest(MessageDigest digest, InputStream data)
/*     */     throws IOException
/*     */   {
/*  50 */     return updateDigest(digest, data).digest();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MessageDigest getDigest(String algorithm)
/*     */   {
/*     */     try
/*     */     {
/*  68 */       return MessageDigest.getInstance(algorithm);
/*     */     } catch (NoSuchAlgorithmException e) {
/*  70 */       throw new IllegalArgumentException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MessageDigest getMd2Digest()
/*     */   {
/*  85 */     return getDigest("MD2");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MessageDigest getMd5Digest()
/*     */   {
/*  98 */     return getDigest("MD5");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MessageDigest getSha1Digest()
/*     */   {
/* 112 */     return getDigest("SHA-1");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MessageDigest getSha256Digest()
/*     */   {
/* 128 */     return getDigest("SHA-256");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MessageDigest getSha384Digest()
/*     */   {
/* 144 */     return getDigest("SHA-384");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MessageDigest getSha512Digest()
/*     */   {
/* 160 */     return getDigest("SHA-512");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static MessageDigest getShaDigest()
/*     */   {
/* 173 */     return getSha1Digest();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] md2(byte[] data)
/*     */   {
/* 185 */     return getMd2Digest().digest(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] md2(InputStream data)
/*     */     throws IOException
/*     */   {
/* 199 */     return digest(getMd2Digest(), data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] md2(String data)
/*     */   {
/* 211 */     return md2(StringUtils.getBytesUtf8(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String md2Hex(byte[] data)
/*     */   {
/* 223 */     return Hex.encodeHexString(md2(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String md2Hex(InputStream data)
/*     */     throws IOException
/*     */   {
/* 237 */     return Hex.encodeHexString(md2(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String md2Hex(String data)
/*     */   {
/* 249 */     return Hex.encodeHexString(md2(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] md5(byte[] data)
/*     */   {
/* 260 */     return getMd5Digest().digest(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] md5(InputStream data)
/*     */     throws IOException
/*     */   {
/* 274 */     return digest(getMd5Digest(), data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] md5(String data)
/*     */   {
/* 285 */     return md5(StringUtils.getBytesUtf8(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String md5Hex(byte[] data)
/*     */   {
/* 296 */     return Hex.encodeHexString(md5(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String md5Hex(InputStream data)
/*     */     throws IOException
/*     */   {
/* 310 */     return Hex.encodeHexString(md5(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String md5Hex(String data)
/*     */   {
/* 321 */     return Hex.encodeHexString(md5(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static byte[] sha(byte[] data)
/*     */   {
/* 334 */     return sha1(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static byte[] sha(InputStream data)
/*     */     throws IOException
/*     */   {
/* 350 */     return sha1(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static byte[] sha(String data)
/*     */   {
/* 363 */     return sha1(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] sha1(byte[] data)
/*     */   {
/* 375 */     return getSha1Digest().digest(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] sha1(InputStream data)
/*     */     throws IOException
/*     */   {
/* 389 */     return digest(getSha1Digest(), data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] sha1(String data)
/*     */   {
/* 400 */     return sha1(StringUtils.getBytesUtf8(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String sha1Hex(byte[] data)
/*     */   {
/* 412 */     return Hex.encodeHexString(sha1(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String sha1Hex(InputStream data)
/*     */     throws IOException
/*     */   {
/* 426 */     return Hex.encodeHexString(sha1(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String sha1Hex(String data)
/*     */   {
/* 438 */     return Hex.encodeHexString(sha1(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] sha256(byte[] data)
/*     */   {
/* 453 */     return getSha256Digest().digest(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] sha256(InputStream data)
/*     */     throws IOException
/*     */   {
/* 470 */     return digest(getSha256Digest(), data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] sha256(String data)
/*     */   {
/* 485 */     return sha256(StringUtils.getBytesUtf8(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String sha256Hex(byte[] data)
/*     */   {
/* 500 */     return Hex.encodeHexString(sha256(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String sha256Hex(InputStream data)
/*     */     throws IOException
/*     */   {
/* 517 */     return Hex.encodeHexString(sha256(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String sha256Hex(String data)
/*     */   {
/* 532 */     return Hex.encodeHexString(sha256(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] sha384(byte[] data)
/*     */   {
/* 547 */     return getSha384Digest().digest(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] sha384(InputStream data)
/*     */     throws IOException
/*     */   {
/* 564 */     return digest(getSha384Digest(), data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] sha384(String data)
/*     */   {
/* 579 */     return sha384(StringUtils.getBytesUtf8(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String sha384Hex(byte[] data)
/*     */   {
/* 594 */     return Hex.encodeHexString(sha384(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String sha384Hex(InputStream data)
/*     */     throws IOException
/*     */   {
/* 611 */     return Hex.encodeHexString(sha384(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String sha384Hex(String data)
/*     */   {
/* 626 */     return Hex.encodeHexString(sha384(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] sha512(byte[] data)
/*     */   {
/* 641 */     return getSha512Digest().digest(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] sha512(InputStream data)
/*     */     throws IOException
/*     */   {
/* 658 */     return digest(getSha512Digest(), data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] sha512(String data)
/*     */   {
/* 673 */     return sha512(StringUtils.getBytesUtf8(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String sha512Hex(byte[] data)
/*     */   {
/* 688 */     return Hex.encodeHexString(sha512(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String sha512Hex(InputStream data)
/*     */     throws IOException
/*     */   {
/* 705 */     return Hex.encodeHexString(sha512(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String sha512Hex(String data)
/*     */   {
/* 720 */     return Hex.encodeHexString(sha512(data));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static String shaHex(byte[] data)
/*     */   {
/* 733 */     return sha1Hex(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static String shaHex(InputStream data)
/*     */     throws IOException
/*     */   {
/* 749 */     return sha1Hex(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static String shaHex(String data)
/*     */   {
/* 762 */     return sha1Hex(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MessageDigest updateDigest(MessageDigest messageDigest, byte[] valueToDigest)
/*     */   {
/* 776 */     messageDigest.update(valueToDigest);
/* 777 */     return messageDigest;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MessageDigest updateDigest(MessageDigest digest, InputStream data)
/*     */     throws IOException
/*     */   {
/* 793 */     byte[] buffer = new byte['Ѐ'];
/* 794 */     int read = data.read(buffer, 0, 1024);
/*     */     
/* 796 */     while (read > -1) {
/* 797 */       digest.update(buffer, 0, read);
/* 798 */       read = data.read(buffer, 0, 1024);
/*     */     }
/*     */     
/* 801 */     return digest;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MessageDigest updateDigest(MessageDigest messageDigest, String valueToDigest)
/*     */   {
/* 816 */     messageDigest.update(StringUtils.getBytesUtf8(valueToDigest));
/* 817 */     return messageDigest;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\authenticationendpoint.war!\WEB-INF\lib\commons-codec-1.9.jar!\org\apache\commons\codec\digest\DigestUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */