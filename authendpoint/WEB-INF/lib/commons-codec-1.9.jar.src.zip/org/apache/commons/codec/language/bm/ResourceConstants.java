package org.apache.commons.codec.language.bm;

class ResourceConstants
{
  static final String CMT = "//";
  static final String ENCODING = "UTF-8";
  static final String EXT_CMT_END = "*/";
  static final String EXT_CMT_START = "/*";
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\authenticationendpoint.war!\WEB-INF\lib\commons-codec-1.9.jar!\org\apache\commons\codec\language\bm\ResourceConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */