/*     */ package org.apache.commons.codec.language;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.codec.EncoderException;
/*     */ import org.apache.commons.codec.StringEncoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColognePhonetic
/*     */   implements StringEncoder
/*     */ {
/* 183 */   private static final char[] AEIJOUY = { 'A', 'E', 'I', 'J', 'O', 'U', 'Y' };
/* 184 */   private static final char[] SCZ = { 'S', 'C', 'Z' };
/* 185 */   private static final char[] WFPV = { 'W', 'F', 'P', 'V' };
/* 186 */   private static final char[] GKQ = { 'G', 'K', 'Q' };
/* 187 */   private static final char[] CKQ = { 'C', 'K', 'Q' };
/* 188 */   private static final char[] AHKLOQRUX = { 'A', 'H', 'K', 'L', 'O', 'Q', 'R', 'U', 'X' };
/* 189 */   private static final char[] SZ = { 'S', 'Z' };
/* 190 */   private static final char[] AHOUKQX = { 'A', 'H', 'O', 'U', 'K', 'Q', 'X' };
/* 191 */   private static final char[] TDX = { 'T', 'D', 'X' };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private abstract class CologneBuffer
/*     */   {
/*     */     protected final char[] data;
/*     */     
/*     */ 
/*     */ 
/* 202 */     protected int length = 0;
/*     */     
/*     */     public CologneBuffer(char[] data) {
/* 205 */       this.data = data;
/* 206 */       this.length = data.length;
/*     */     }
/*     */     
/*     */     public CologneBuffer(int buffSize) {
/* 210 */       this.data = new char[buffSize];
/* 211 */       this.length = 0;
/*     */     }
/*     */     
/*     */     protected abstract char[] copyData(int paramInt1, int paramInt2);
/*     */     
/*     */     public int length() {
/* 217 */       return this.length;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 222 */       return new String(copyData(0, this.length));
/*     */     }
/*     */   }
/*     */   
/*     */   private class CologneOutputBuffer extends ColognePhonetic.CologneBuffer
/*     */   {
/*     */     public CologneOutputBuffer(int buffSize) {
/* 229 */       super(buffSize);
/*     */     }
/*     */     
/*     */     public void addRight(char chr) {
/* 233 */       this.data[this.length] = chr;
/* 234 */       this.length += 1;
/*     */     }
/*     */     
/*     */     protected char[] copyData(int start, int length)
/*     */     {
/* 239 */       char[] newData = new char[length];
/* 240 */       System.arraycopy(this.data, start, newData, 0, length);
/* 241 */       return newData;
/*     */     }
/*     */   }
/*     */   
/*     */   private class CologneInputBuffer extends ColognePhonetic.CologneBuffer
/*     */   {
/*     */     public CologneInputBuffer(char[] data) {
/* 248 */       super(data);
/*     */     }
/*     */     
/*     */     public void addLeft(char ch) {
/* 252 */       this.length += 1;
/* 253 */       this.data[getNextPos()] = ch;
/*     */     }
/*     */     
/*     */     protected char[] copyData(int start, int length)
/*     */     {
/* 258 */       char[] newData = new char[length];
/* 259 */       System.arraycopy(this.data, this.data.length - this.length + start, newData, 0, length);
/* 260 */       return newData;
/*     */     }
/*     */     
/*     */     public char getNextChar() {
/* 264 */       return this.data[getNextPos()];
/*     */     }
/*     */     
/*     */     protected int getNextPos() {
/* 268 */       return this.data.length - this.length;
/*     */     }
/*     */     
/*     */     public char removeNext() {
/* 272 */       char ch = getNextChar();
/* 273 */       this.length -= 1;
/* 274 */       return ch;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 287 */   private static final char[][] PREPROCESS_MAP = { { 'Ä', 'A' }, { 'Ü', 'U' }, { 'Ö', 'O' }, { 'ß', 'S' } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean arrayContains(char[] arr, char key)
/*     */   {
/* 298 */     for (char element : arr) {
/* 299 */       if (element == key) {
/* 300 */         return true;
/*     */       }
/*     */     }
/* 303 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String colognePhonetic(String text)
/*     */   {
/* 318 */     if (text == null) {
/* 319 */       return null;
/*     */     }
/*     */     
/* 322 */     text = preprocess(text);
/*     */     
/* 324 */     CologneOutputBuffer output = new CologneOutputBuffer(text.length() * 2);
/* 325 */     CologneInputBuffer input = new CologneInputBuffer(text.toCharArray());
/*     */     
/*     */ 
/*     */ 
/* 329 */     char lastChar = '-';
/* 330 */     char lastCode = '/';
/*     */     
/*     */ 
/*     */ 
/* 334 */     int rightLength = input.length();
/*     */     
/* 336 */     while (rightLength > 0) {
/* 337 */       char chr = input.removeNext();
/*     */       char nextChar;
/* 339 */       char nextChar; if ((rightLength = input.length()) > 0) {
/* 340 */         nextChar = input.getNextChar();
/*     */       } else
/* 342 */         nextChar = '-';
/*     */       char code;
/*     */       char code;
/* 345 */       if (arrayContains(AEIJOUY, chr)) {
/* 346 */         code = '0';
/* 347 */       } else if ((chr == 'H') || (chr < 'A') || (chr > 'Z')) {
/* 348 */         if (lastCode == '/') {
/*     */           continue;
/*     */         }
/* 351 */         char code = '-'; } else { char code;
/* 352 */         if ((chr == 'B') || ((chr == 'P') && (nextChar != 'H'))) {
/* 353 */           code = '1'; } else { char code;
/* 354 */           if (((chr == 'D') || (chr == 'T')) && (!arrayContains(SCZ, nextChar))) {
/* 355 */             code = '2'; } else { char code;
/* 356 */             if (arrayContains(WFPV, chr)) {
/* 357 */               code = '3'; } else { char code;
/* 358 */               if (arrayContains(GKQ, chr)) {
/* 359 */                 code = '4';
/* 360 */               } else if ((chr == 'X') && (!arrayContains(CKQ, lastChar))) {
/* 361 */                 char code = '4';
/* 362 */                 input.addLeft('S');
/* 363 */                 rightLength++; } else { char code;
/* 364 */                 if ((chr == 'S') || (chr == 'Z')) {
/* 365 */                   code = '8'; } else { char code;
/* 366 */                   if (chr == 'C') { char code;
/* 367 */                     if (lastCode == '/') { char code;
/* 368 */                       if (arrayContains(AHKLOQRUX, nextChar)) {
/* 369 */                         code = '4';
/*     */                       } else
/* 371 */                         code = '8';
/*     */                     } else {
/*     */                       char code;
/* 374 */                       if ((arrayContains(SZ, lastChar)) || (!arrayContains(AHOUKQX, nextChar))) {
/* 375 */                         code = '8';
/*     */                       } else
/* 377 */                         code = '4';
/*     */                     }
/*     */                   } else { char code;
/* 380 */                     if (arrayContains(TDX, chr)) {
/* 381 */                       code = '8'; } else { char code;
/* 382 */                       if (chr == 'R') {
/* 383 */                         code = '7'; } else { char code;
/* 384 */                         if (chr == 'L') {
/* 385 */                           code = '5'; } else { char code;
/* 386 */                           if ((chr == 'M') || (chr == 'N')) {
/* 387 */                             code = '6';
/*     */                           } else
/* 389 */                             code = chr;
/*     */                         }
/*     */                       } } } } } } } } }
/* 392 */       if ((code != '-') && (((lastCode != code) && ((code != '0') || (lastCode == '/'))) || (code < '0') || (code > '8'))) {
/* 393 */         output.addRight(code);
/*     */       }
/*     */       
/* 396 */       lastChar = chr;
/* 397 */       lastCode = code;
/*     */     }
/* 399 */     return output.toString();
/*     */   }
/*     */   
/*     */   public Object encode(Object object) throws EncoderException
/*     */   {
/* 404 */     if (!(object instanceof String)) {
/* 405 */       throw new EncoderException("This method's parameter was expected to be of the type " + String.class.getName() + ". But actually it was of the type " + object.getClass().getName() + ".");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 411 */     return encode((String)object);
/*     */   }
/*     */   
/*     */   public String encode(String text)
/*     */   {
/* 416 */     return colognePhonetic(text);
/*     */   }
/*     */   
/*     */   public boolean isEncodeEqual(String text1, String text2) {
/* 420 */     return colognePhonetic(text1).equals(colognePhonetic(text2));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private String preprocess(String text)
/*     */   {
/* 427 */     text = text.toUpperCase(Locale.GERMAN);
/*     */     
/* 429 */     char[] chrs = text.toCharArray();
/*     */     
/* 431 */     for (int index = 0; index < chrs.length; index++) {
/* 432 */       if (chrs[index] > 'Z') {
/* 433 */         for (char[] element : PREPROCESS_MAP) {
/* 434 */           if (chrs[index] == element[0]) {
/* 435 */             chrs[index] = element[1];
/* 436 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 441 */     return new String(chrs);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\authenticationendpoint.war!\WEB-INF\lib\commons-codec-1.9.jar!\org\apache\commons\codec\language\ColognePhonetic.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */