package org.apache.commons.codec.digest;

public class MessageDigestAlgorithms
{
  public static final String MD2 = "MD2";
  public static final String MD5 = "MD5";
  public static final String SHA_1 = "SHA-1";
  public static final String SHA_256 = "SHA-256";
  public static final String SHA_384 = "SHA-384";
  public static final String SHA_512 = "SHA-512";
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\authenticationendpoint.war!\WEB-INF\lib\commons-codec-1.9.jar!\org\apache\commons\codec\digest\MessageDigestAlgorithms.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */