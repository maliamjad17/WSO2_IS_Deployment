/*     */ package org.codehaus.stax2.ri;
/*     */ 
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.stream.XMLStreamConstants;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import org.codehaus.stax2.DTDInfo;
/*     */ import org.codehaus.stax2.XMLStreamLocation2;
/*     */ import org.codehaus.stax2.XMLStreamReader2;
/*     */ import org.codehaus.stax2.XMLStreamWriter2;
/*     */ import org.codehaus.stax2.validation.ValidationProblemHandler;
/*     */ import org.codehaus.stax2.validation.XMLValidationSchema;
/*     */ import org.codehaus.stax2.validation.XMLValidator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Stax2WriterAdapter
/*     */   implements XMLStreamWriter2, XMLStreamConstants
/*     */ {
/*     */   final XMLStreamWriter mDelegate;
/*     */   String mEncoding;
/*     */   
/*     */   private Stax2WriterAdapter(XMLStreamWriter sw)
/*     */   {
/*  67 */     this.mDelegate = sw;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XMLStreamWriter2 wrapIfNecessary(XMLStreamWriter sw)
/*     */   {
/*  80 */     if ((sw instanceof XMLStreamWriter2)) {
/*  81 */       return (XMLStreamWriter2)sw;
/*     */     }
/*  83 */     return new Stax2WriterAdapter(sw);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws XMLStreamException
/*     */   {
/*  95 */     this.mDelegate.close();
/*     */   }
/*     */   
/*     */   public void flush()
/*     */     throws XMLStreamException
/*     */   {
/* 101 */     this.mDelegate.flush();
/*     */   }
/*     */   
/*     */   public NamespaceContext getNamespaceContext()
/*     */   {
/* 106 */     return this.mDelegate.getNamespaceContext();
/*     */   }
/*     */   
/*     */   public String getPrefix(String uri)
/*     */     throws XMLStreamException
/*     */   {
/* 112 */     return this.mDelegate.getPrefix(uri);
/*     */   }
/*     */   
/*     */   public Object getProperty(String name)
/*     */   {
/* 117 */     return this.mDelegate.getProperty(name);
/*     */   }
/*     */   
/*     */   public void setDefaultNamespace(String uri)
/*     */     throws XMLStreamException
/*     */   {
/* 123 */     this.mDelegate.setDefaultNamespace(uri);
/*     */   }
/*     */   
/*     */   public void setNamespaceContext(NamespaceContext context)
/*     */     throws XMLStreamException
/*     */   {
/* 129 */     this.mDelegate.setNamespaceContext(context);
/*     */   }
/*     */   
/*     */   public void setPrefix(String prefix, String uri)
/*     */     throws XMLStreamException
/*     */   {
/* 135 */     this.mDelegate.setPrefix(prefix, uri);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeAttribute(String localName, String value)
/*     */     throws XMLStreamException
/*     */   {
/* 142 */     this.mDelegate.writeAttribute(localName, value);
/*     */   }
/*     */   
/*     */   public void writeAttribute(String namespaceURI, String localName, String value)
/*     */     throws XMLStreamException
/*     */   {
/* 148 */     this.mDelegate.writeAttribute(namespaceURI, localName, value);
/*     */   }
/*     */   
/*     */   public void writeAttribute(String prefix, String namespaceURI, String localName, String value)
/*     */     throws XMLStreamException
/*     */   {
/* 154 */     this.mDelegate.writeAttribute(prefix, namespaceURI, localName, value);
/*     */   }
/*     */   
/*     */   public void writeCData(String data)
/*     */     throws XMLStreamException
/*     */   {
/* 160 */     this.mDelegate.writeCData(data);
/*     */   }
/*     */   
/*     */   public void writeCharacters(char[] text, int start, int len)
/*     */     throws XMLStreamException
/*     */   {
/* 166 */     this.mDelegate.writeCharacters(text, start, len);
/*     */   }
/*     */   
/*     */   public void writeCharacters(String text)
/*     */     throws XMLStreamException
/*     */   {
/* 172 */     this.mDelegate.writeCharacters(text);
/*     */   }
/*     */   
/*     */   public void writeComment(String data)
/*     */     throws XMLStreamException
/*     */   {
/* 178 */     this.mDelegate.writeComment(data);
/*     */   }
/*     */   
/*     */   public void writeDefaultNamespace(String namespaceURI)
/*     */     throws XMLStreamException
/*     */   {
/* 184 */     this.mDelegate.writeDefaultNamespace(namespaceURI);
/*     */   }
/*     */   
/*     */   public void writeDTD(String dtd)
/*     */     throws XMLStreamException
/*     */   {
/* 190 */     this.mDelegate.writeDTD(dtd);
/*     */   }
/*     */   
/*     */   public void writeEmptyElement(String localName)
/*     */     throws XMLStreamException
/*     */   {
/* 196 */     this.mDelegate.writeEmptyElement(localName);
/*     */   }
/*     */   
/*     */   public void writeEmptyElement(String namespaceURI, String localName)
/*     */     throws XMLStreamException
/*     */   {
/* 202 */     this.mDelegate.writeEmptyElement(namespaceURI, localName);
/*     */   }
/*     */   
/*     */   public void writeEmptyElement(String prefix, String localName, String namespaceURI)
/*     */     throws XMLStreamException
/*     */   {
/* 208 */     this.mDelegate.writeEmptyElement(prefix, localName, namespaceURI);
/*     */   }
/*     */   
/*     */   public void writeEndDocument()
/*     */     throws XMLStreamException
/*     */   {
/* 214 */     this.mDelegate.writeEndDocument();
/*     */   }
/*     */   
/*     */   public void writeEndElement()
/*     */     throws XMLStreamException
/*     */   {
/* 220 */     this.mDelegate.writeEndElement();
/*     */   }
/*     */   
/*     */   public void writeEntityRef(String name)
/*     */     throws XMLStreamException
/*     */   {
/* 226 */     this.mDelegate.writeEntityRef(name);
/*     */   }
/*     */   
/*     */   public void writeNamespace(String prefix, String namespaceURI)
/*     */     throws XMLStreamException
/*     */   {
/* 232 */     this.mDelegate.writeNamespace(prefix, namespaceURI);
/*     */   }
/*     */   
/*     */   public void writeProcessingInstruction(String target)
/*     */     throws XMLStreamException
/*     */   {
/* 238 */     this.mDelegate.writeProcessingInstruction(target);
/*     */   }
/*     */   
/*     */   public void writeProcessingInstruction(String target, String data)
/*     */     throws XMLStreamException
/*     */   {
/* 244 */     this.mDelegate.writeProcessingInstruction(target, data);
/*     */   }
/*     */   
/*     */   public void writeStartDocument()
/*     */     throws XMLStreamException
/*     */   {
/* 250 */     this.mDelegate.writeStartDocument();
/*     */   }
/*     */   
/*     */   public void writeStartDocument(String version)
/*     */     throws XMLStreamException
/*     */   {
/* 256 */     this.mDelegate.writeStartDocument(version);
/*     */   }
/*     */   
/*     */   public void writeStartDocument(String encoding, String version)
/*     */     throws XMLStreamException
/*     */   {
/* 262 */     this.mEncoding = encoding;
/* 263 */     this.mDelegate.writeStartDocument(encoding, version);
/*     */   }
/*     */   
/*     */   public void writeStartElement(String localName)
/*     */     throws XMLStreamException
/*     */   {
/* 269 */     this.mDelegate.writeStartElement(localName);
/*     */   }
/*     */   
/*     */   public void writeStartElement(String namespaceURI, String localName)
/*     */     throws XMLStreamException
/*     */   {
/* 275 */     this.mDelegate.writeStartElement(namespaceURI, localName);
/*     */   }
/*     */   
/*     */   public void writeStartElement(String prefix, String localName, String namespaceURI)
/*     */     throws XMLStreamException
/*     */   {
/* 281 */     this.mDelegate.writeStartElement(prefix, localName, namespaceURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPropertySupported(String name)
/*     */   {
/* 295 */     return false;
/*     */   }
/*     */   
/*     */   public boolean setProperty(String name, Object value)
/*     */   {
/* 300 */     throw new IllegalArgumentException("No settable property '" + name + "'");
/*     */   }
/*     */   
/*     */ 
/*     */   public XMLStreamLocation2 getLocation()
/*     */   {
/* 306 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getEncoding()
/*     */   {
/* 312 */     return this.mEncoding;
/*     */   }
/*     */   
/*     */   public void writeCData(char[] text, int start, int len)
/*     */     throws XMLStreamException
/*     */   {
/* 318 */     writeCData(new String(text, start, len));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeDTD(String rootName, String systemId, String publicId, String internalSubset)
/*     */     throws XMLStreamException
/*     */   {
/* 328 */     StringBuffer sb = new StringBuffer();
/* 329 */     sb.append("<!DOCTYPE");
/* 330 */     sb.append(rootName);
/* 331 */     if (systemId != null) {
/* 332 */       if (publicId != null) {
/* 333 */         sb.append(" PUBLIC \"");
/* 334 */         sb.append(publicId);
/* 335 */         sb.append("\" \"");
/*     */       } else {
/* 337 */         sb.append(" SYSTEM \"");
/*     */       }
/* 339 */       sb.append(systemId);
/* 340 */       sb.append('"');
/*     */     }
/*     */     
/* 343 */     if ((internalSubset != null) && (internalSubset.length() > 0)) {
/* 344 */       sb.append(" [");
/* 345 */       sb.append(internalSubset);
/* 346 */       sb.append(']');
/*     */     }
/* 348 */     sb.append('>');
/* 349 */     writeDTD(sb.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeFullEndElement()
/*     */     throws XMLStreamException
/*     */   {
/* 359 */     this.mDelegate.writeCharacters("");
/* 360 */     this.mDelegate.writeEndElement();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeSpace(String text)
/*     */     throws XMLStreamException
/*     */   {
/* 371 */     writeRaw(text);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeSpace(char[] text, int offset, int length)
/*     */     throws XMLStreamException
/*     */   {
/* 378 */     writeRaw(text, offset, length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void writeStartDocument(String version, String encoding, boolean standAlone)
/*     */     throws XMLStreamException
/*     */   {
/* 386 */     writeStartDocument(encoding, version);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeRaw(String text)
/*     */     throws XMLStreamException
/*     */   {
/* 398 */     writeRaw(text, 0, text.length());
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeRaw(String text, int offset, int len)
/*     */     throws XMLStreamException
/*     */   {
/* 405 */     throw new UnsupportedOperationException("Not implemented");
/*     */   }
/*     */   
/*     */   public void writeRaw(char[] text, int offset, int length)
/*     */     throws XMLStreamException
/*     */   {
/* 411 */     writeRaw(new String(text, offset, length));
/*     */   }
/*     */   
/*     */   public void copyEventFromReader(XMLStreamReader2 sr, boolean preserveEventData)
/*     */     throws XMLStreamException
/*     */   {
/* 417 */     switch (sr.getEventType())
/*     */     {
/*     */     case 7: 
/* 420 */       String version = sr.getVersion();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 425 */       if ((version != null) && (version.length() != 0))
/*     */       {
/*     */ 
/* 428 */         if (sr.standaloneSet()) {
/* 429 */           writeStartDocument(sr.getVersion(), sr.getCharacterEncodingScheme(), sr.isStandalone());
/*     */         }
/*     */         else
/*     */         {
/* 433 */           writeStartDocument(sr.getCharacterEncodingScheme(), sr.getVersion());
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 438 */       return;
/*     */     
/*     */     case 8: 
/* 441 */       writeEndDocument();
/* 442 */       return;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 1: 
/* 450 */       copyStartElement(sr);
/* 451 */       return;
/*     */     
/*     */     case 2: 
/* 454 */       writeEndElement();
/* 455 */       return;
/*     */     
/*     */     case 6: 
/* 458 */       writeSpace(sr.getTextCharacters(), sr.getTextStart(), sr.getTextLength());
/* 459 */       return;
/*     */     
/*     */     case 12: 
/* 462 */       writeCData(sr.getTextCharacters(), sr.getTextStart(), sr.getTextLength());
/* 463 */       return;
/*     */     
/*     */     case 4: 
/* 466 */       writeCharacters(sr.getTextCharacters(), sr.getTextStart(), sr.getTextLength());
/* 467 */       return;
/*     */     
/*     */     case 5: 
/* 470 */       writeComment(sr.getText());
/* 471 */       return;
/*     */     
/*     */     case 3: 
/* 474 */       writeProcessingInstruction(sr.getPITarget(), sr.getPIData());
/* 475 */       return;
/*     */     
/*     */ 
/*     */     case 11: 
/* 479 */       DTDInfo info = sr.getDTDInfo();
/* 480 */       if (info == null)
/*     */       {
/*     */ 
/*     */ 
/* 484 */         throw new XMLStreamException("Current state DOCTYPE, but not DTDInfo Object returned -- reader doesn't support DTDs?");
/*     */       }
/* 486 */       writeDTD(info.getDTDRootName(), info.getDTDSystemId(), info.getDTDPublicId(), info.getDTDInternalSubset());
/*     */       
/*     */ 
/* 489 */       return;
/*     */     
/*     */     case 9: 
/* 492 */       writeEntityRef(sr.getLocalName());
/* 493 */       return;
/*     */     }
/*     */     
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 501 */     throw new XMLStreamException("Unrecognized event type (" + sr.getEventType() + "); not sure how to copy");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLValidator validateAgainst(XMLValidationSchema schema)
/*     */     throws XMLStreamException
/*     */   {
/* 515 */     throw new UnsupportedOperationException("Not yet implemented");
/*     */   }
/*     */   
/*     */   public XMLValidator stopValidatingAgainst(XMLValidationSchema schema)
/*     */     throws XMLStreamException
/*     */   {
/* 521 */     return null;
/*     */   }
/*     */   
/*     */   public XMLValidator stopValidatingAgainst(XMLValidator validator)
/*     */     throws XMLStreamException
/*     */   {
/* 527 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ValidationProblemHandler setValidationProblemHandler(ValidationProblemHandler h)
/*     */   {
/* 535 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void copyStartElement(XMLStreamReader sr)
/*     */     throws XMLStreamException
/*     */   {
/* 548 */     int nsCount = sr.getNamespaceCount();
/* 549 */     if (nsCount > 0)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 554 */       for (int i = 0; i < nsCount; i++) {
/* 555 */         String prefix = sr.getNamespacePrefix(i);
/* 556 */         String uri = sr.getNamespaceURI(i);
/* 557 */         if ((prefix == null) || (prefix.length() == 0)) {
/* 558 */           setDefaultNamespace(uri);
/*     */         } else {
/* 560 */           setPrefix(prefix, uri);
/*     */         }
/*     */       }
/*     */     }
/* 564 */     writeStartElement(sr.getPrefix(), sr.getLocalName(), sr.getNamespaceURI());
/*     */     
/* 566 */     if (nsCount > 0)
/*     */     {
/* 568 */       for (int i = 0; i < nsCount; i++) {
/* 569 */         String prefix = sr.getNamespacePrefix(i);
/* 570 */         String uri = sr.getNamespaceURI(i);
/*     */         
/* 572 */         if ((prefix == null) || (prefix.length() == 0)) {
/* 573 */           writeDefaultNamespace(uri);
/*     */         } else {
/* 575 */           writeNamespace(prefix, uri);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 583 */     int attrCount = sr.getAttributeCount();
/* 584 */     if (attrCount > 0) {
/* 585 */       for (int i = 0; i < attrCount; i++) {
/* 586 */         writeAttribute(sr.getAttributePrefix(i), sr.getAttributeNamespace(i), sr.getAttributeLocalName(i), sr.getAttributeValue(i));
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\ri\Stax2WriterAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */