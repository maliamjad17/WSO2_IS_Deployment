/*    */ package org.codehaus.stax2.io;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.Reader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Stax2ByteArraySource
/*    */   extends Stax2BlockSource
/*    */ {
/*    */   final byte[] mBuffer;
/*    */   final int mStart;
/*    */   final int mLength;
/*    */   
/*    */   public Stax2ByteArraySource(byte[] buf, int start, int len)
/*    */   {
/* 25 */     this.mBuffer = buf;
/* 26 */     this.mStart = start;
/* 27 */     this.mLength = len;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Reader constructReader()
/*    */     throws IOException
/*    */   {
/* 39 */     String enc = getEncoding();
/* 40 */     InputStream in = constructInputStream();
/* 41 */     if ((enc != null) && (enc.length() > 0)) {
/* 42 */       return new InputStreamReader(in, enc);
/*    */     }
/*    */     
/* 45 */     return new InputStreamReader(in);
/*    */   }
/*    */   
/*    */   public InputStream constructInputStream()
/*    */     throws IOException
/*    */   {
/* 51 */     return new ByteArrayInputStream(this.mBuffer, this.mStart, this.mLength);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getBuffer()
/*    */   {
/* 61 */     return this.mBuffer;
/*    */   }
/*    */   
/*    */   public int getBufferStart() {
/* 65 */     return this.mStart;
/*    */   }
/*    */   
/*    */   public int getBufferLength() {
/* 69 */     return this.mLength;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\io\Stax2ByteArraySource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */