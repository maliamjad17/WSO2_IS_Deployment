package org.codehaus.stax2.validation;

import javax.xml.stream.XMLStreamException;

public abstract interface XMLValidationSchema
{
  public static final String SCHEMA_ID_DTD = "http://www.w3.org/XML/1998/namespace";
  public static final String SCHEMA_ID_RELAXNG = "http://relaxng.org/ns/structure/0.9";
  public static final String SCHEMA_ID_W3C_SCHEMA = "http://www.w3.org/2001/XMLSchema";
  public static final String SCHEMA_ID_TREX = "http://www.thaiopensource.com/trex";
  
  public abstract XMLValidator createValidator(ValidationContext paramValidationContext)
    throws XMLStreamException;
  
  public abstract String getSchemaType();
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\validation\XMLValidationSchema.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */