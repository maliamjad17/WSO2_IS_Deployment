package org.codehaus.stax2.validation;

import javax.xml.stream.XMLStreamException;

public abstract interface Validatable
{
  public abstract XMLValidator validateAgainst(XMLValidationSchema paramXMLValidationSchema)
    throws XMLStreamException;
  
  public abstract XMLValidator stopValidatingAgainst(XMLValidationSchema paramXMLValidationSchema)
    throws XMLStreamException;
  
  public abstract XMLValidator stopValidatingAgainst(XMLValidator paramXMLValidator)
    throws XMLStreamException;
  
  public abstract ValidationProblemHandler setValidationProblemHandler(ValidationProblemHandler paramValidationProblemHandler);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\validation\Validatable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */