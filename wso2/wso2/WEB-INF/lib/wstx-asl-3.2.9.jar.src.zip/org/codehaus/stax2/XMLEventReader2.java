package org.codehaus.stax2;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLStreamException;

public abstract interface XMLEventReader2
  extends XMLEventReader
{
  public abstract boolean hasNextEvent()
    throws XMLStreamException;
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\XMLEventReader2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */