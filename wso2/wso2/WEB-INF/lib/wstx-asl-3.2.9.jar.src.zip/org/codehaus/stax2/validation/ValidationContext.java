package org.codehaus.stax2.validation;

import javax.xml.namespace.QName;
import javax.xml.stream.Location;

public abstract interface ValidationContext
{
  public abstract String getXmlVersion();
  
  public abstract QName getCurrentElementName();
  
  public abstract String getNamespaceURI(String paramString);
  
  public abstract int getAttributeCount();
  
  public abstract String getAttributeLocalName(int paramInt);
  
  public abstract String getAttributeNamespace(int paramInt);
  
  public abstract String getAttributePrefix(int paramInt);
  
  public abstract String getAttributeValue(int paramInt);
  
  public abstract String getAttributeValue(String paramString1, String paramString2);
  
  public abstract int findAttributeIndex(String paramString1, String paramString2);
  
  public abstract boolean isNotationDeclared(String paramString);
  
  public abstract boolean isUnparsedEntityDeclared(String paramString);
  
  public abstract String getBaseUri();
  
  public abstract Location getValidationLocation();
  
  public abstract void reportProblem(XMLValidationProblem paramXMLValidationProblem)
    throws XMLValidationException;
  
  public abstract int addDefaultAttribute(String paramString1, String paramString2, String paramString3, String paramString4);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\validation\ValidationContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */