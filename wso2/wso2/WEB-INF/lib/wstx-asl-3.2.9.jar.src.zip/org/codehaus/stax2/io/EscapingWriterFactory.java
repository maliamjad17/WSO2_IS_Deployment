package org.codehaus.stax2.io;

import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.io.Writer;

public abstract interface EscapingWriterFactory
{
  public abstract Writer createEscapingWriterFor(Writer paramWriter, String paramString)
    throws UnsupportedEncodingException;
  
  public abstract Writer createEscapingWriterFor(OutputStream paramOutputStream, String paramString)
    throws UnsupportedEncodingException;
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\io\EscapingWriterFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */