/*     */ package org.codehaus.stax2.validation;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Properties;
/*     */ import javax.xml.stream.FactoryConfigurationError;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class XMLValidationSchemaFactory
/*     */ {
/*     */   public static final String INTERNAL_ID_SCHEMA_DTD = "dtd";
/*     */   public static final String INTERNAL_ID_SCHEMA_RELAXNG = "relaxng";
/*     */   public static final String INTERNAL_ID_SCHEMA_W3C = "w3c";
/*     */   public static final String INTERNAL_ID_SCHEMA_TREX = "trex";
/*  35 */   static final HashMap sSchemaIds = new HashMap();
/*     */   
/*  37 */   static { sSchemaIds.put("http://www.w3.org/XML/1998/namespace", "dtd");
/*  38 */     sSchemaIds.put("http://relaxng.org/ns/structure/0.9", "relaxng");
/*  39 */     sSchemaIds.put("http://www.w3.org/2001/XMLSchema", "w3c");
/*  40 */     sSchemaIds.put("http://www.thaiopensource.com/trex", "trex");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String JAXP_PROP_FILENAME = "jaxp.properties";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String SYSTEM_PROPERTY_FOR_IMPL = "org.codehaus.stax2.validation.XMLValidationSchemaFactory.";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String SERVICE_DEFINITION_PATH = "META-INF/services/org.codehaus.stax2.validation.XMLValidationSchemaFactory.";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String P_IS_NAMESPACE_AWARE = "org.codehaus2.stax2.validation.isNamespaceAware";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String P_ENABLE_CACHING = "org.codehaus2.stax2.validation.enableCaching";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XMLValidationSchemaFactory newInstance(String schemaType)
/*     */     throws FactoryConfigurationError
/*     */   {
/*  98 */     return newInstance(schemaType, Thread.currentThread().getContextClassLoader());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XMLValidationSchemaFactory newInstance(String schemaType, ClassLoader classLoader)
/*     */     throws FactoryConfigurationError
/*     */   {
/* 108 */     String internalId = (String)sSchemaIds.get(schemaType);
/* 109 */     if (internalId == null) {
/* 110 */       throw new FactoryConfigurationError("Unrecognized schema type (id '" + schemaType + "')");
/*     */     }
/*     */     
/* 113 */     String propertyId = "org.codehaus.stax2.validation.XMLValidationSchemaFactory." + internalId;
/* 114 */     SecurityException secEx = null;
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 120 */       String clsName = System.getProperty(propertyId);
/* 121 */       if ((clsName != null) && (clsName.length() > 0)) {
/* 122 */         return createNewInstance(classLoader, clsName);
/*     */       }
/*     */     }
/*     */     catch (SecurityException se) {
/* 126 */       secEx = se;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 134 */       String home = System.getProperty("java.home");
/* 135 */       File f = new File(home);
/*     */       
/*     */ 
/* 138 */       f = new File(f, "lib");
/* 139 */       f = new File(f, "jaxp.properties");
/* 140 */       if (f.exists()) {
/*     */         try {
/* 142 */           Properties props = new Properties();
/* 143 */           props.load(new FileInputStream(f));
/* 144 */           String clsName = props.getProperty(propertyId);
/* 145 */           if ((clsName != null) && (clsName.length() > 0)) {
/* 146 */             return createNewInstance(classLoader, clsName);
/*     */           }
/*     */         }
/*     */         catch (IOException ioe) {}
/*     */       }
/*     */     }
/*     */     catch (SecurityException se)
/*     */     {
/* 154 */       secEx = se;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 160 */     String path = "META-INF/services/org.codehaus.stax2.validation.XMLValidationSchemaFactory." + internalId;
/*     */     try {
/*     */       Enumeration en;
/*     */       Enumeration en;
/* 164 */       if (classLoader == null) {
/* 165 */         en = ClassLoader.getSystemResources(path);
/*     */       } else {
/* 167 */         en = classLoader.getResources(path);
/*     */       }
/*     */       
/* 170 */       if (en != null) {
/* 171 */         while (en.hasMoreElements()) {
/* 172 */           URL url = (URL)en.nextElement();
/* 173 */           InputStream is = url.openStream();
/* 174 */           BufferedReader rd = new BufferedReader(new InputStreamReader(is, "ISO-8859-1"));
/*     */           
/* 176 */           String clsName = null;
/*     */           try
/*     */           {
/*     */             String line;
/* 180 */             while ((line = rd.readLine()) != null) {
/* 181 */               line = line.trim();
/* 182 */               if ((line.length() > 0) && (line.charAt(0) != '#')) {
/* 183 */                 clsName = line;
/*     */               }
/*     */             }
/*     */           }
/*     */           finally {
/* 188 */             rd.close();
/*     */           }
/* 190 */           if ((clsName != null) && (clsName.length() > 0)) {
/* 191 */             return createNewInstance(classLoader, clsName);
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (SecurityException se) {
/* 196 */       secEx = se;
/*     */     }
/*     */     catch (IOException ex) {}
/*     */     
/*     */ 
/*     */ 
/* 202 */     String msg = "No XMLValidationSchemaFactory implementation class specified or accessible (via system property '" + propertyId + "', or service definition under '" + path + "')";
/*     */     
/*     */ 
/* 205 */     if (secEx != null) {
/* 206 */       throw new FactoryConfigurationError(msg + " (possibly caused by: " + secEx + ")", secEx);
/*     */     }
/* 208 */     throw new FactoryConfigurationError(msg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public XMLValidationSchema createSchema(InputStream in)
/*     */     throws XMLStreamException
/*     */   {
/* 216 */     return createSchema(in, null);
/*     */   }
/*     */   
/*     */   public XMLValidationSchema createSchema(InputStream in, String encoding)
/*     */     throws XMLStreamException
/*     */   {
/* 222 */     return createSchema(in, encoding, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLValidationSchema createSchema(Reader r)
/*     */     throws XMLStreamException
/*     */   {
/* 232 */     return createSchema(r, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static XMLValidationSchemaFactory createNewInstance(ClassLoader cloader, String clsName)
/*     */     throws FactoryConfigurationError
/*     */   {
/*     */     try
/*     */     {
/*     */       Class factoryClass;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       Class factoryClass;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 284 */       if (cloader == null) {
/* 285 */         factoryClass = Class.forName(clsName);
/*     */       } else {
/* 287 */         factoryClass = cloader.loadClass(clsName);
/*     */       }
/* 289 */       return (XMLValidationSchemaFactory)factoryClass.newInstance();
/*     */     } catch (ClassNotFoundException x) {
/* 291 */       throw new FactoryConfigurationError("XMLValidationSchemaFactory implementation '" + clsName + "' not found (missing jar in classpath?)", x);
/*     */     }
/*     */     catch (Exception x) {
/* 294 */       throw new FactoryConfigurationError("XMLValidationSchemaFactory implementation '" + clsName + "' could not be instantiated: " + x, x);
/*     */     }
/*     */   }
/*     */   
/*     */   public abstract XMLValidationSchema createSchema(InputStream paramInputStream, String paramString1, String paramString2, String paramString3)
/*     */     throws XMLStreamException;
/*     */   
/*     */   public abstract XMLValidationSchema createSchema(Reader paramReader, String paramString1, String paramString2)
/*     */     throws XMLStreamException;
/*     */   
/*     */   public abstract XMLValidationSchema createSchema(URL paramURL)
/*     */     throws XMLStreamException;
/*     */   
/*     */   public abstract XMLValidationSchema createSchema(File paramFile)
/*     */     throws XMLStreamException;
/*     */   
/*     */   public abstract boolean isPropertySupported(String paramString);
/*     */   
/*     */   public abstract boolean setProperty(String paramString, Object paramObject);
/*     */   
/*     */   public abstract Object getProperty(String paramString);
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\validation\XMLValidationSchemaFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */