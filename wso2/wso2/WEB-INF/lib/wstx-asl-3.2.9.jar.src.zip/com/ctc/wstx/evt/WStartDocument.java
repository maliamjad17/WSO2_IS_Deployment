/*     */ package com.ctc.wstx.evt;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.stream.events.StartDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WStartDocument
/*     */   extends WEvent
/*     */   implements StartDocument
/*     */ {
/*     */   private final boolean mStandaloneSet;
/*     */   private final boolean mIsStandalone;
/*     */   private final String mVersion;
/*     */   private final boolean mEncodingSet;
/*     */   private final String mEncodingScheme;
/*     */   private final String mSystemId;
/*     */   
/*     */   public WStartDocument(Location loc, XMLStreamReader r)
/*     */   {
/*  27 */     super(loc);
/*  28 */     this.mStandaloneSet = r.standaloneSet();
/*  29 */     this.mIsStandalone = r.isStandalone();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  36 */     String version = r.getVersion();
/*  37 */     if ((version == null) || (version.length() == 0)) {
/*  38 */       version = "1.0";
/*     */     }
/*  40 */     this.mVersion = version;
/*     */     
/*  42 */     this.mEncodingScheme = r.getCharacterEncodingScheme();
/*  43 */     this.mEncodingSet = ((this.mEncodingScheme != null) && (this.mEncodingScheme.length() > 0));
/*  44 */     this.mSystemId = (loc != null ? loc.getSystemId() : "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WStartDocument(Location loc)
/*     */   {
/*  53 */     this(loc, (String)null);
/*     */   }
/*     */   
/*     */   public WStartDocument(Location loc, String encoding)
/*     */   {
/*  58 */     this(loc, encoding, null);
/*     */   }
/*     */   
/*     */   public WStartDocument(Location loc, String encoding, String version)
/*     */   {
/*  63 */     this(loc, encoding, version, false, false);
/*     */   }
/*     */   
/*     */ 
/*     */   public WStartDocument(Location loc, String encoding, String version, boolean standaloneSet, boolean isStandalone)
/*     */   {
/*  69 */     super(loc);
/*  70 */     this.mEncodingScheme = encoding;
/*  71 */     this.mEncodingSet = ((encoding != null) && (encoding.length() > 0));
/*  72 */     this.mVersion = version;
/*  73 */     this.mStandaloneSet = standaloneSet;
/*  74 */     this.mIsStandalone = isStandalone;
/*  75 */     this.mSystemId = "";
/*     */   }
/*     */   
/*     */   public boolean encodingSet() {
/*  79 */     return this.mEncodingSet;
/*     */   }
/*     */   
/*     */   public String getCharacterEncodingScheme() {
/*  83 */     return this.mEncodingScheme;
/*     */   }
/*     */   
/*     */   public String getSystemId() {
/*  87 */     return this.mSystemId;
/*     */   }
/*     */   
/*     */   public String getVersion() {
/*  91 */     return this.mVersion;
/*     */   }
/*     */   
/*     */   public boolean isStandalone() {
/*  95 */     return this.mIsStandalone;
/*     */   }
/*     */   
/*     */   public boolean standaloneSet() {
/*  99 */     return this.mStandaloneSet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getEventType()
/*     */   {
/* 109 */     return 7;
/*     */   }
/*     */   
/*     */   public boolean isStartDocument() {
/* 113 */     return true;
/*     */   }
/*     */   
/*     */   public void writeAsEncodedUnicode(Writer w)
/*     */     throws XMLStreamException
/*     */   {
/*     */     try
/*     */     {
/* 121 */       w.write("<?xml version=\"");
/* 122 */       if ((this.mVersion == null) || (this.mVersion.length() == 0)) {
/* 123 */         w.write("1.0");
/*     */       } else {
/* 125 */         w.write(this.mVersion);
/*     */       }
/* 127 */       w.write(34);
/* 128 */       if (this.mEncodingSet) {
/* 129 */         w.write(" encoding=\"");
/* 130 */         w.write(this.mEncodingScheme);
/* 131 */         w.write(34);
/*     */       }
/* 133 */       if (this.mStandaloneSet) {
/* 134 */         if (this.mIsStandalone) {
/* 135 */           w.write(" standalone=\"yes\"");
/*     */         } else {
/* 137 */           w.write(" standalone=\"no\"");
/*     */         }
/*     */       }
/* 140 */       w.write(" ?>");
/*     */     } catch (IOException ie) {
/* 142 */       throwFromIOE(ie);
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeUsing(XMLStreamWriter w) throws XMLStreamException {
/* 147 */     w.writeStartDocument();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\evt\WStartDocument.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */