/*    */ package com.ctc.wstx.compat;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map.Entry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Jdk14Impl
/*    */   extends Jdk13Impl
/*    */ {
/*    */   public Jdk14Impl()
/*    */   {
/* 16 */     super(true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected Jdk14Impl(boolean dummy)
/*    */   {
/* 24 */     super(true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public final boolean leakingThreadLocal()
/*    */   {
/* 41 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HashMap getInsertOrderedMap()
/*    */   {
/* 54 */     return new LinkedHashMap();
/*    */   }
/*    */   
/*    */   public HashMap getInsertOrderedMap(int initialSize) {
/* 58 */     return new LinkedHashMap(initialSize);
/*    */   }
/*    */   
/*    */   public HashMap getLRULimitMap(int maxSize) {
/* 62 */     int initSize = maxSize;
/* 63 */     return new LimitMap(initSize, maxSize, 0.8F);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean setInitCause(Throwable newT, Throwable rootT)
/*    */   {
/* 73 */     if (newT.getCause() == null) {
/* 74 */       newT.initCause(rootT);
/*    */     }
/* 76 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   static final class LimitMap
/*    */     extends LinkedHashMap
/*    */   {
/*    */     final int mMaxSize;
/*    */     
/*    */ 
/*    */ 
/*    */     public LimitMap(int initialSize, int maxSize, float loadFactor)
/*    */     {
/* 91 */       super(loadFactor, true);
/*    */       
/* 93 */       this.mMaxSize = (maxSize < 4 ? 4 : maxSize);
/*    */     }
/*    */     
/*    */     public boolean removeEldestEntry(Map.Entry eldest) {
/* 97 */       return size() >= this.mMaxSize;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\compat\Jdk14Impl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */