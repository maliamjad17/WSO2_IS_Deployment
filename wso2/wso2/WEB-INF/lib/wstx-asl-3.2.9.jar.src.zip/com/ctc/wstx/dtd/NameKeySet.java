/*    */ package com.ctc.wstx.dtd;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class NameKeySet
/*    */ {
/*    */   public abstract boolean hasMultiple();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract boolean contains(NameKey paramNameKey);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract void appendNames(StringBuffer paramStringBuffer, String paramString);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public final String toString()
/*    */   {
/* 36 */     return toString(", ");
/*    */   }
/*    */   
/*    */   public final String toString(String sep) {
/* 40 */     StringBuffer sb = new StringBuffer();
/* 41 */     appendNames(sb, sep);
/* 42 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\NameKeySet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */