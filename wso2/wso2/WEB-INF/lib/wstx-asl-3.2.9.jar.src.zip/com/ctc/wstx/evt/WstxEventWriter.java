/*     */ package com.ctc.wstx.evt;
/*     */ 
/*     */ import com.ctc.wstx.cfg.OutputConfigFlags;
/*     */ import com.ctc.wstx.sw.BaseStreamWriter;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLEventWriter;
/*     */ import javax.xml.stream.XMLStreamConstants;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.stream.events.Attribute;
/*     */ import javax.xml.stream.events.Characters;
/*     */ import javax.xml.stream.events.Comment;
/*     */ import javax.xml.stream.events.DTD;
/*     */ import javax.xml.stream.events.EndElement;
/*     */ import javax.xml.stream.events.EntityReference;
/*     */ import javax.xml.stream.events.Namespace;
/*     */ import javax.xml.stream.events.ProcessingInstruction;
/*     */ import javax.xml.stream.events.StartDocument;
/*     */ import javax.xml.stream.events.StartElement;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WstxEventWriter
/*     */   implements XMLEventWriter, XMLStreamConstants, OutputConfigFlags
/*     */ {
/*     */   final XMLStreamWriter mWriter;
/*     */   final BaseStreamWriter mWstxWriter;
/*     */   
/*     */   public WstxEventWriter(XMLStreamWriter sw)
/*     */   {
/*  62 */     this.mWriter = sw;
/*  63 */     this.mWstxWriter = ((sw instanceof BaseStreamWriter) ? (BaseStreamWriter)sw : null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(XMLEvent event)
/*     */     throws XMLStreamException
/*     */   {
/*  82 */     switch (event.getEventType())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 10: 
/*  89 */       Attribute attr = (Attribute)event;
/*  90 */       QName name = attr.getName();
/*  91 */       this.mWriter.writeAttribute(name.getPrefix(), name.getNamespaceURI(), name.getLocalPart(), attr.getValue());
/*     */       
/*     */ 
/*  94 */       break;
/*     */     
/*     */     case 8: 
/*  97 */       this.mWriter.writeEndDocument();
/*  98 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */     case 2: 
/* 103 */       if (this.mWstxWriter != null) {
/* 104 */         this.mWstxWriter.writeEndElement(event.asEndElement().getName());
/*     */       } else {
/* 106 */         this.mWriter.writeEndElement();
/*     */       }
/*     */       
/* 109 */       break;
/*     */     
/*     */ 
/*     */     case 13: 
/* 113 */       Namespace ns = (Namespace)event;
/* 114 */       this.mWriter.writeNamespace(ns.getPrefix(), ns.getNamespaceURI());
/*     */       
/* 116 */       break;
/*     */     
/*     */ 
/*     */     case 7: 
/* 120 */       StartDocument sd = (StartDocument)event;
/* 121 */       if (!sd.encodingSet()) {
/* 122 */         this.mWriter.writeStartDocument(sd.getVersion());
/*     */       } else {
/* 124 */         this.mWriter.writeStartDocument(sd.getCharacterEncodingScheme(), sd.getVersion());
/*     */       }
/*     */       
/*     */ 
/* 128 */       break;
/*     */     
/*     */ 
/*     */     case 1: 
/* 132 */       StartElement se = event.asStartElement();
/* 133 */       if (this.mWstxWriter != null)
/*     */       {
/*     */ 
/*     */ 
/* 137 */         this.mWstxWriter.writeStartElement(se);
/*     */       } else {
/* 139 */         QName n = se.getName();
/* 140 */         this.mWriter.writeStartElement(n.getPrefix(), n.getLocalPart(), n.getNamespaceURI());
/*     */         
/* 142 */         Iterator it = se.getNamespaces();
/* 143 */         while (it.hasNext()) {
/* 144 */           Namespace ns = (Namespace)it.next();
/* 145 */           add(ns);
/*     */         }
/* 147 */         it = se.getAttributes();
/* 148 */         while (it.hasNext()) {
/* 149 */           Attribute attr = (Attribute)it.next();
/* 150 */           add(attr);
/*     */         }
/*     */       }
/*     */       
/* 154 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 4: 
/* 163 */       Characters ch = event.asCharacters();
/* 164 */       String text = ch.getData();
/* 165 */       if (ch.isCData()) {
/* 166 */         this.mWriter.writeCData(text);
/*     */       } else {
/* 168 */         this.mWriter.writeCharacters(text);
/*     */       }
/*     */       
/* 171 */       break;
/*     */     
/*     */     case 12: 
/* 174 */       this.mWriter.writeCData(event.asCharacters().getData());
/* 175 */       break;
/*     */     
/*     */     case 5: 
/* 178 */       this.mWriter.writeComment(((Comment)event).getText());
/* 179 */       break;
/*     */     
/*     */     case 11: 
/* 182 */       this.mWriter.writeDTD(((DTD)event).getDocumentTypeDeclaration());
/* 183 */       break;
/*     */     
/*     */     case 9: 
/* 186 */       this.mWriter.writeEntityRef(((EntityReference)event).getName());
/* 187 */       break;
/*     */     
/*     */ 
/*     */     case 3: 
/* 191 */       ProcessingInstruction pi = (ProcessingInstruction)event;
/* 192 */       this.mWriter.writeProcessingInstruction(pi.getTarget(), pi.getData());
/*     */       
/* 194 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 6: 
/*     */     case 14: 
/*     */     case 15: 
/*     */     default: 
/* 208 */       if (this.mWstxWriter != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 213 */         this.mWstxWriter.writeCharacters("");
/* 214 */         event.writeAsEncodedUnicode(this.mWstxWriter.wrapAsRawWriter());
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 221 */         throw new XMLStreamException("Unrecognized event type (" + event.getEventType() + "), for XMLEvent of type " + event.getClass());
/*     */       }
/*     */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */   public void add(XMLEventReader reader) throws XMLStreamException {
/* 229 */     while (reader.hasNext()) {
/* 230 */       add(reader.nextEvent());
/*     */     }
/*     */   }
/*     */   
/*     */   public void close()
/*     */     throws XMLStreamException
/*     */   {
/* 237 */     this.mWriter.close();
/*     */   }
/*     */   
/*     */   public void flush()
/*     */     throws XMLStreamException
/*     */   {
/* 243 */     this.mWriter.flush();
/*     */   }
/*     */   
/*     */   public NamespaceContext getNamespaceContext() {
/* 247 */     return this.mWriter.getNamespaceContext();
/*     */   }
/*     */   
/*     */   public String getPrefix(String uri)
/*     */     throws XMLStreamException
/*     */   {
/* 253 */     return this.mWriter.getPrefix(uri);
/*     */   }
/*     */   
/*     */   public void setDefaultNamespace(String uri)
/*     */     throws XMLStreamException
/*     */   {
/* 259 */     this.mWriter.setDefaultNamespace(uri);
/*     */   }
/*     */   
/*     */   public void setNamespaceContext(NamespaceContext ctxt)
/*     */     throws XMLStreamException
/*     */   {
/* 265 */     this.mWriter.setNamespaceContext(ctxt);
/*     */   }
/*     */   
/*     */   public void setPrefix(String prefix, String uri)
/*     */     throws XMLStreamException
/*     */   {
/* 271 */     this.mWriter.setPrefix(prefix, uri);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\evt\WstxEventWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */