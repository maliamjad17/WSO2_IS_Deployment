/*     */ package com.ctc.wstx.api;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import org.codehaus.stax2.XMLStreamProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class CommonConfig
/*     */   implements XMLStreamProperties
/*     */ {
/*     */   protected static final String IMPL_NAME = "woodstox";
/*     */   protected static final String IMPL_VERSION = "3.2";
/*     */   static final int PROP_IMPL_NAME = 1;
/*     */   static final int PROP_IMPL_VERSION = 2;
/*     */   static final int PROP_SUPPORTS_XML11 = 3;
/*     */   static final int PROP_SUPPORTS_XMLID = 4;
/*  48 */   static final HashMap sStdProperties = new HashMap(16);
/*     */   
/*     */   static {
/*  51 */     sStdProperties.put("org.codehaus.stax2.implName", new Integer(1));
/*     */     
/*  53 */     sStdProperties.put("org.codehaus.stax2.implVersion", new Integer(2));
/*     */     
/*     */ 
/*     */ 
/*  57 */     sStdProperties.put("org.codehaus.stax2.supportsXml11", new Integer(3));
/*     */     
/*     */ 
/*     */ 
/*  61 */     sStdProperties.put("org.codehaus.stax2.supportsXml11", new Integer(3));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */     sStdProperties.put("http://java.sun.com/xml/stream/properties/implementation-name", new Integer(1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Object getProperty(String propName)
/*     */   {
/*  81 */     int id = findPropertyId(propName);
/*  82 */     if (id >= 0) {
/*  83 */       return getProperty(id);
/*     */     }
/*  85 */     id = findStdPropertyId(propName);
/*  86 */     if (id < 0) {
/*  87 */       throw new IllegalArgumentException("Unrecognized property '" + propName + "'");
/*     */     }
/*  89 */     return getStdProperty(id);
/*     */   }
/*     */   
/*     */   public final boolean isPropertySupported(String propName)
/*     */   {
/*  94 */     return (findPropertyId(propName) >= 0) || (findStdPropertyId(propName) >= 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean setProperty(String propName, Object value)
/*     */   {
/* 104 */     int id = findPropertyId(propName);
/* 105 */     if (id >= 0) {
/* 106 */       return setProperty(propName, id, value);
/*     */     }
/* 108 */     id = findStdPropertyId(propName);
/* 109 */     if (id < 0) {
/* 110 */       throw new IllegalArgumentException("Unrecognized property '" + propName + "'");
/*     */     }
/* 112 */     return setStdProperty(propName, id, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean doesSupportXml11()
/*     */   {
/* 133 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int findStdPropertyId(String propName)
/*     */   {
/* 148 */     Integer I = (Integer)sStdProperties.get(propName);
/* 149 */     return I == null ? -1 : I.intValue();
/*     */   }
/*     */   
/*     */ 
/*     */   protected boolean setStdProperty(String propName, int id, Object value)
/*     */   {
/* 155 */     return false;
/*     */   }
/*     */   
/*     */   protected Object getStdProperty(int id)
/*     */   {
/* 160 */     switch (id) {
/*     */     case 1: 
/* 162 */       return "woodstox";
/*     */     case 2: 
/* 164 */       return "3.2";
/*     */     case 3: 
/* 166 */       return doesSupportXml11() ? Boolean.TRUE : Boolean.FALSE;
/*     */     }
/* 168 */     throw new Error("Internal error: no handler for property with internal id " + id + ".");
/*     */   }
/*     */   
/*     */   protected abstract int findPropertyId(String paramString);
/*     */   
/*     */   protected abstract Object getProperty(int paramInt);
/*     */   
/*     */   protected abstract boolean setProperty(String paramString, int paramInt, Object paramObject);
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\api\CommonConfig.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */