/*    */ package com.ctc.wstx.evt;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ import javax.xml.stream.Location;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import javax.xml.stream.XMLStreamWriter;
/*    */ import javax.xml.stream.events.EntityDeclaration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class WEntityDeclaration
/*    */   extends WEvent
/*    */   implements EntityDeclaration
/*    */ {
/*    */   public WEntityDeclaration(Location loc)
/*    */   {
/* 24 */     super(loc);
/*    */   }
/*    */   
/*    */ 
/*    */   public abstract String getBaseURI();
/*    */   
/*    */ 
/*    */   public abstract String getName();
/*    */   
/*    */ 
/*    */   public abstract String getNotationName();
/*    */   
/*    */ 
/*    */   public abstract String getPublicId();
/*    */   
/*    */ 
/*    */   public abstract String getReplacementText();
/*    */   
/*    */   public abstract String getSystemId();
/*    */   
/*    */   public int getEventType()
/*    */   {
/* 46 */     return 15;
/*    */   }
/*    */   
/*    */   public abstract void writeEnc(Writer paramWriter) throws IOException;
/*    */   
/*    */   public void writeAsEncodedUnicode(Writer w) throws XMLStreamException
/*    */   {
/*    */     try
/*    */     {
/* 55 */       writeEnc(w);
/*    */     } catch (IOException ie) {
/* 57 */       throw new XMLStreamException(ie);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void writeUsing(XMLStreamWriter w)
/*    */     throws XMLStreamException
/*    */   {
/* 73 */     throw new XMLStreamException("Can not write entity declarations using an XMLStreamWriter");
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\evt\WEntityDeclaration.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */