/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ import com.ctc.wstx.util.DataUtil;
/*     */ import com.ctc.wstx.util.ExceptionUtil;
/*     */ import java.util.BitSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.codehaus.stax2.validation.ValidationContext;
/*     */ import org.codehaus.stax2.validation.XMLValidationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DTDTypingNonValidator
/*     */   extends DTDValidatorBase
/*     */ {
/*  45 */   protected boolean mHasAttrDefaults = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  52 */   protected BitSet mCurrDefaultAttrs = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  58 */   protected boolean mHasNormalizableAttrs = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   BitSet mTmpDefaultAttrs;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DTDTypingNonValidator(DTDSubset schema, ValidationContext ctxt, boolean hasNsDefaults, Map elemSpecs, Map genEntities)
/*     */   {
/*  81 */     super(schema, ctxt, hasNsDefaults, elemSpecs, genEntities);
/*     */   }
/*     */   
/*     */ 
/*     */   public final boolean reallyValidating()
/*     */   {
/*  87 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAttrValueNormalization(boolean state) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validateElementStart(String localName, String uri, String prefix)
/*     */     throws XMLValidationException
/*     */   {
/* 115 */     this.mTmpKey.reset(prefix, localName);
/* 116 */     DTDElement elem = (DTDElement)this.mElemSpecs.get(this.mTmpKey);
/*     */     
/* 118 */     int elemCount = this.mElemCount++;
/* 119 */     if (elemCount >= this.mElems.length) {
/* 120 */       this.mElems = ((DTDElement[])DataUtil.growArrayBy50Pct(this.mElems));
/*     */     }
/*     */     
/* 123 */     this.mElems[elemCount] = (this.mCurrElem = elem);
/* 124 */     this.mAttrCount = 0;
/* 125 */     this.mIdAttrIndex = -2;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 132 */     if (elem == null) {
/* 133 */       this.mCurrAttrDefs = EMPTY_MAP;
/* 134 */       this.mHasAttrDefaults = false;
/* 135 */       this.mCurrDefaultAttrs = null;
/* 136 */       this.mHasNormalizableAttrs = false;
/* 137 */       return;
/*     */     }
/*     */     
/*     */ 
/* 141 */     this.mCurrAttrDefs = elem.getAttributes();
/* 142 */     if (this.mCurrAttrDefs == null) {
/* 143 */       this.mCurrAttrDefs = EMPTY_MAP;
/* 144 */       this.mHasAttrDefaults = false;
/* 145 */       this.mCurrDefaultAttrs = null;
/* 146 */       this.mHasNormalizableAttrs = false;
/* 147 */       return;
/*     */     }
/*     */     
/*     */ 
/* 151 */     this.mHasNormalizableAttrs = ((this.mNormAttrs) || (elem.attrsNeedValidation()));
/*     */     
/*     */ 
/* 154 */     this.mHasAttrDefaults = elem.hasAttrDefaultValues();
/* 155 */     if (this.mHasAttrDefaults)
/*     */     {
/*     */ 
/*     */ 
/* 159 */       int specCount = elem.getSpecialCount();
/* 160 */       BitSet bs = this.mTmpDefaultAttrs;
/* 161 */       if (bs == null) {
/* 162 */         this.mTmpDefaultAttrs = (bs = new BitSet(specCount));
/*     */       } else {
/* 164 */         bs.clear();
/*     */       }
/* 166 */       this.mCurrDefaultAttrs = bs;
/*     */     } else {
/* 168 */       this.mCurrDefaultAttrs = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validateAttribute(String localName, String uri, String prefix, String value)
/*     */     throws XMLValidationException
/*     */   {
/* 184 */     DTDAttribute attr = (DTDAttribute)this.mCurrAttrDefs.get(this.mTmpKey.reset(prefix, localName));
/* 185 */     int index = this.mAttrCount++;
/* 186 */     if (index >= this.mAttrSpecs.length) {
/* 187 */       this.mAttrSpecs = ((DTDAttribute[])DataUtil.growArrayBy50Pct(this.mAttrSpecs));
/*     */     }
/* 189 */     this.mAttrSpecs[index] = attr;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 194 */     if (attr != null) {
/* 195 */       if (this.mHasAttrDefaults)
/*     */       {
/*     */ 
/*     */ 
/* 199 */         int specIndex = attr.getSpecialIndex();
/* 200 */         if (specIndex >= 0) {
/* 201 */           this.mCurrDefaultAttrs.set(specIndex);
/*     */         }
/*     */       }
/* 204 */       if (!this.mHasNormalizableAttrs) {}
/*     */     }
/*     */     
/*     */ 
/* 208 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validateAttribute(String localName, String uri, String prefix, char[] valueChars, int valueStart, int valueEnd)
/*     */     throws XMLValidationException
/*     */   {
/* 218 */     DTDAttribute attr = (DTDAttribute)this.mCurrAttrDefs.get(this.mTmpKey.reset(prefix, localName));
/* 219 */     int index = this.mAttrCount++;
/* 220 */     if (index >= this.mAttrSpecs.length) {
/* 221 */       this.mAttrSpecs = ((DTDAttribute[])DataUtil.growArrayBy50Pct(this.mAttrSpecs));
/*     */     }
/* 223 */     this.mAttrSpecs[index] = attr;
/* 224 */     if (attr != null) {
/* 225 */       if (this.mHasAttrDefaults) {
/* 226 */         int specIndex = attr.getSpecialIndex();
/* 227 */         if (specIndex >= 0) {
/* 228 */           this.mCurrDefaultAttrs.set(specIndex);
/*     */         }
/*     */       }
/* 231 */       if (this.mHasNormalizableAttrs) {
/* 232 */         return attr.normalize(this, valueChars, valueStart, valueEnd);
/*     */       }
/*     */     }
/* 235 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int validateElementAndAttributes()
/*     */     throws XMLValidationException
/*     */   {
/* 245 */     DTDElement elem = this.mCurrElem;
/* 246 */     if (this.mHasAttrDefaults) {
/* 247 */       BitSet specBits = this.mCurrDefaultAttrs;
/* 248 */       int specCount = elem.getSpecialCount();
/* 249 */       int ix = specBits.nextClearBit(0);
/* 250 */       while (ix < specCount) {
/* 251 */         List specAttrs = elem.getSpecialAttrs();
/* 252 */         DTDAttribute attr = (DTDAttribute)specAttrs.get(ix);
/* 253 */         if (attr.hasDefaultValue()) {
/* 254 */           doAddDefaultValue(attr);
/*     */         }
/* 256 */         ix = specBits.nextClearBit(ix + 1);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 266 */     return elem == null ? 3 : elem.getAllowedContentIfSpace();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int validateElementEnd(String localName, String uri, String prefix)
/*     */     throws XMLValidationException
/*     */   {
/* 276 */     int ix = --this.mElemCount;
/* 277 */     this.mElems[ix] = null;
/* 278 */     if (ix < 1) {
/* 279 */       return 3;
/*     */     }
/* 281 */     DTDElement elem = this.mElems[(ix - 1)];
/* 282 */     return elem == null ? 3 : this.mElems[(ix - 1)].getAllowedContentIfSpace();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validationCompleted(boolean eod)
/*     */     throws XMLValidationException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ElementIdMap getIdMap()
/*     */   {
/* 308 */     ExceptionUtil.throwGenericInternal();
/* 309 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\DTDTypingNonValidator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */