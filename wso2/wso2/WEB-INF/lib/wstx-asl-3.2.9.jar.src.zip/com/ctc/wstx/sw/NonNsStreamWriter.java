/*     */ package com.ctc.wstx.sw;
/*     */ 
/*     */ import com.ctc.wstx.api.WriterConfig;
/*     */ import com.ctc.wstx.cfg.ErrorConsts;
/*     */ import com.ctc.wstx.sr.AttributeCollector;
/*     */ import com.ctc.wstx.sr.InputElementStack;
/*     */ import com.ctc.wstx.util.EmptyNamespaceContext;
/*     */ import com.ctc.wstx.util.StringVector;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.TreeMap;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.events.Attribute;
/*     */ import javax.xml.stream.events.StartElement;
/*     */ import org.codehaus.stax2.validation.XMLValidator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NonNsStreamWriter
/*     */   extends BaseStreamWriter
/*     */ {
/*     */   final StringVector mElements;
/*     */   TreeMap mAttrNames;
/*     */   
/*     */   public NonNsStreamWriter(XmlWriter xw, String enc, WriterConfig cfg)
/*     */   {
/*  90 */     super(xw, enc, cfg);
/*  91 */     this.mElements = new StringVector(32);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NamespaceContext getNamespaceContext()
/*     */   {
/* 101 */     return EmptyNamespaceContext.getInstance();
/*     */   }
/*     */   
/*     */   public String getPrefix(String uri) {
/* 105 */     return null;
/*     */   }
/*     */   
/*     */   public void setDefaultNamespace(String uri)
/*     */     throws XMLStreamException
/*     */   {
/* 111 */     reportIllegalArg("Can not set default namespace for non-namespace writer.");
/*     */   }
/*     */   
/*     */   public void setNamespaceContext(NamespaceContext context)
/*     */   {
/* 116 */     reportIllegalArg("Can not set NamespaceContext for non-namespace writer.");
/*     */   }
/*     */   
/*     */   public void setPrefix(String prefix, String uri)
/*     */     throws XMLStreamException
/*     */   {
/* 122 */     reportIllegalArg("Can not set namespace prefix for non-namespace writer.");
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeAttribute(String localName, String value)
/*     */     throws XMLStreamException
/*     */   {
/* 129 */     if ((!this.mStartElementOpen) && (this.mCheckStructure)) {
/* 130 */       reportNwfStructure(ErrorConsts.WERR_ATTR_NO_ELEM);
/*     */     }
/* 132 */     if (this.mCheckAttrs)
/*     */     {
/*     */ 
/*     */ 
/* 136 */       if (this.mAttrNames == null) {
/* 137 */         this.mAttrNames = new TreeMap();
/* 138 */         this.mAttrNames.put(localName, value);
/*     */       } else {
/* 140 */         Object old = this.mAttrNames.put(localName, value);
/* 141 */         if (old != null) {
/* 142 */           reportNwfAttr("Trying to write attribute '" + localName + "' twice (first value '" + old + "'; second '" + value + "').");
/*     */         }
/*     */       }
/*     */     }
/* 146 */     if (this.mValidator != null)
/*     */     {
/*     */ 
/*     */ 
/* 150 */       this.mValidator.validateAttribute(localName, "", NO_PREFIX, value);
/*     */     }
/*     */     try
/*     */     {
/* 154 */       this.mWriter.writeAttribute(localName, value);
/*     */     } catch (IOException ioe) {
/* 156 */       throwFromIOE(ioe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeAttribute(String nsURI, String localName, String value)
/*     */     throws XMLStreamException
/*     */   {
/* 163 */     writeAttribute(localName, value);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeAttribute(String prefix, String nsURI, String localName, String value)
/*     */     throws XMLStreamException
/*     */   {
/* 170 */     writeAttribute(localName, value);
/*     */   }
/*     */   
/*     */   public void writeDefaultNamespace(String nsURI)
/*     */     throws XMLStreamException
/*     */   {
/* 176 */     reportIllegalMethod("Can not call writeDefaultNamespace namespaces with non-namespace writer.");
/*     */   }
/*     */   
/*     */   public void writeEmptyElement(String localName)
/*     */     throws XMLStreamException
/*     */   {
/* 182 */     doWriteStartElement(localName);
/* 183 */     this.mEmptyElement = true;
/*     */   }
/*     */   
/*     */   public void writeEmptyElement(String nsURI, String localName)
/*     */     throws XMLStreamException
/*     */   {
/* 189 */     writeEmptyElement(localName);
/*     */   }
/*     */   
/*     */   public void writeEmptyElement(String prefix, String localName, String nsURI)
/*     */     throws XMLStreamException
/*     */   {
/* 195 */     writeEmptyElement(localName);
/*     */   }
/*     */   
/*     */   public void writeEndElement()
/*     */     throws XMLStreamException
/*     */   {
/* 201 */     doWriteEndTag(null, this.mCfgAutomaticEmptyElems);
/*     */   }
/*     */   
/*     */   public void writeNamespace(String prefix, String nsURI)
/*     */     throws XMLStreamException
/*     */   {
/* 207 */     reportIllegalMethod("Can not set write namespaces with non-namespace writer.");
/*     */   }
/*     */   
/*     */   public void writeStartElement(String localName)
/*     */     throws XMLStreamException
/*     */   {
/* 213 */     doWriteStartElement(localName);
/* 214 */     this.mEmptyElement = false;
/*     */   }
/*     */   
/*     */   public void writeStartElement(String nsURI, String localName)
/*     */     throws XMLStreamException
/*     */   {
/* 220 */     writeStartElement(localName);
/*     */   }
/*     */   
/*     */   public void writeStartElement(String prefix, String localName, String nsURI)
/*     */     throws XMLStreamException
/*     */   {
/* 226 */     writeStartElement(localName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeFullEndElement()
/*     */     throws XMLStreamException
/*     */   {
/* 242 */     doWriteEndTag(null, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public QName getCurrentElementName()
/*     */   {
/* 252 */     if (this.mElements.isEmpty()) {
/* 253 */       return null;
/*     */     }
/* 255 */     return new QName(this.mElements.getLastString());
/*     */   }
/*     */   
/*     */   public String getNamespaceURI(String prefix) {
/* 259 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeStartElement(StartElement elem)
/*     */     throws XMLStreamException
/*     */   {
/* 271 */     QName name = elem.getName();
/* 272 */     writeStartElement(name.getLocalPart());
/* 273 */     Iterator it = elem.getAttributes();
/* 274 */     while (it.hasNext()) {
/* 275 */       Attribute attr = (Attribute)it.next();
/* 276 */       name = attr.getName();
/* 277 */       writeAttribute(name.getLocalPart(), attr.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeEndElement(QName name)
/*     */     throws XMLStreamException
/*     */   {
/* 289 */     doWriteEndTag(this.mCheckStructure ? name.getLocalPart() : null, this.mCfgAutomaticEmptyElems);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void closeStartElement(boolean emptyElem)
/*     */     throws XMLStreamException
/*     */   {
/* 302 */     this.mStartElementOpen = false;
/* 303 */     if (this.mAttrNames != null) {
/* 304 */       this.mAttrNames.clear();
/*     */     }
/*     */     try
/*     */     {
/* 308 */       if (emptyElem) {
/* 309 */         this.mWriter.writeStartTagEmptyEnd();
/*     */       } else {
/* 311 */         this.mWriter.writeStartTagEnd();
/*     */       }
/*     */     } catch (IOException ioe) {
/* 314 */       throwFromIOE(ioe);
/*     */     }
/*     */     
/* 317 */     if (this.mValidator != null) {
/* 318 */       this.mVldContent = this.mValidator.validateElementAndAttributes();
/*     */     }
/*     */     
/*     */ 
/* 322 */     if (emptyElem) {
/* 323 */       String localName = this.mElements.removeLast();
/* 324 */       if (this.mElements.isEmpty()) {
/* 325 */         this.mState = 3;
/*     */       }
/* 327 */       if (this.mValidator != null) {
/* 328 */         this.mVldContent = this.mValidator.validateElementEnd(localName, "", NO_PREFIX);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void copyStartElement(InputElementStack elemStack, AttributeCollector attrCollector)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 343 */     String ln = elemStack.getLocalName();
/* 344 */     boolean nsAware = elemStack.isNamespaceAware();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 349 */     if (nsAware) {
/* 350 */       String prefix = elemStack.getPrefix();
/* 351 */       if ((prefix != null) && (prefix.length() > 0)) {
/* 352 */         ln = prefix + ":" + ln;
/*     */       }
/*     */     }
/* 355 */     writeStartElement(ln);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 360 */     if (nsAware) {
/* 361 */       int nsCount = elemStack.getCurrentNsCount();
/* 362 */       if (nsCount > 0) {
/* 363 */         for (int i = 0; i < nsCount; i++) {
/* 364 */           String prefix = elemStack.getLocalNsPrefix(i);
/* 365 */           if ((prefix == null) || (prefix.length() == 0)) {
/* 366 */             prefix = "xml";
/*     */           } else {
/* 368 */             prefix = "xmlns:" + prefix;
/*     */           }
/* 370 */           writeAttribute(prefix, elemStack.getLocalNsURI(i));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 378 */     int attrCount = this.mCfgCopyDefaultAttrs ? attrCollector.getCount() : attrCollector.getSpecifiedCount();
/*     */     
/*     */ 
/*     */ 
/* 382 */     if (attrCount > 0) {
/* 383 */       for (int i = 0; i < attrCount; i++) {
/* 384 */         attrCollector.writeAttribute(i, this.mWriter);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected String getTopElementDesc()
/*     */   {
/* 391 */     return this.mElements.isEmpty() ? "#root" : this.mElements.getLastString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void doWriteStartElement(String localName)
/*     */     throws XMLStreamException
/*     */   {
/* 403 */     this.mAnyOutput = true;
/*     */     
/* 405 */     if (this.mStartElementOpen) {
/* 406 */       closeStartElement(this.mEmptyElement);
/* 407 */     } else if (this.mState == 1)
/*     */     {
/* 409 */       verifyRootElement(localName, null);
/* 410 */     } else if (this.mState == 3) {
/* 411 */       if (this.mCheckStructure) {
/* 412 */         reportNwfStructure(ErrorConsts.WERR_PROLOG_SECOND_ROOT, localName);
/*     */       }
/*     */       
/* 415 */       this.mState = 2;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 424 */     if (this.mValidator != null) {
/* 425 */       this.mValidator.validateElementStart(localName, "", NO_PREFIX);
/*     */     }
/*     */     
/* 428 */     this.mStartElementOpen = true;
/* 429 */     this.mElements.addString(localName);
/*     */     try {
/* 431 */       this.mWriter.writeStartTagStart(localName);
/*     */     } catch (IOException ioe) {
/* 433 */       throwFromIOE(ioe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void doWriteEndTag(String expName, boolean allowEmpty)
/*     */     throws XMLStreamException
/*     */   {
/* 455 */     if ((this.mStartElementOpen) && (this.mEmptyElement)) {
/* 456 */       this.mEmptyElement = false;
/*     */       
/* 458 */       closeStartElement(true);
/*     */     }
/*     */     
/*     */ 
/* 462 */     if (this.mState != 2)
/*     */     {
/* 464 */       reportNwfStructure("No open start element, when trying to write end element");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 470 */     String localName = this.mElements.removeLast();
/* 471 */     if ((this.mCheckStructure) && 
/* 472 */       (expName != null) && (!localName.equals(expName)))
/*     */     {
/*     */ 
/*     */ 
/* 476 */       reportNwfStructure("Mismatching close element name, '" + localName + "'; expected '" + expName + "'.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 485 */     if (this.mStartElementOpen)
/*     */     {
/*     */ 
/*     */ 
/* 489 */       if (this.mValidator != null)
/*     */       {
/*     */ 
/*     */ 
/* 493 */         this.mVldContent = this.mValidator.validateElementAndAttributes();
/*     */       }
/* 495 */       this.mStartElementOpen = false;
/* 496 */       if (this.mAttrNames != null) {
/* 497 */         this.mAttrNames.clear();
/*     */       }
/*     */       try
/*     */       {
/* 501 */         if (allowEmpty) {
/* 502 */           this.mWriter.writeStartTagEmptyEnd();
/* 503 */           if (this.mElements.isEmpty()) {
/* 504 */             this.mState = 3;
/*     */           }
/* 506 */           if (this.mValidator != null) {
/* 507 */             this.mVldContent = this.mValidator.validateElementEnd(localName, "", NO_PREFIX);
/*     */           }
/* 509 */           return;
/*     */         }
/*     */         
/* 512 */         this.mWriter.writeStartTagEnd();
/*     */       } catch (IOException ioe) {
/* 514 */         throwFromIOE(ioe);
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 519 */       this.mWriter.writeEndTag(localName);
/*     */     } catch (IOException ioe) {
/* 521 */       throwFromIOE(ioe);
/*     */     }
/*     */     
/* 524 */     if (this.mElements.isEmpty()) {
/* 525 */       this.mState = 3;
/*     */     }
/*     */     
/*     */ 
/* 529 */     if (this.mValidator != null) {
/* 530 */       this.mVldContent = this.mValidator.validateElementEnd(localName, "", NO_PREFIX);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sw\NonNsStreamWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */