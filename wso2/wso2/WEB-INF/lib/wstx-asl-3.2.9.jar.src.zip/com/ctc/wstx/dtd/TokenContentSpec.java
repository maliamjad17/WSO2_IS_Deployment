/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TokenContentSpec
/*     */   extends ContentSpec
/*     */ {
/*  13 */   static final TokenContentSpec sDummy = new TokenContentSpec(' ', new NameKey("*", "*"));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   final NameKey mElemName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TokenContentSpec(char arity, NameKey elemName)
/*     */   {
/*  26 */     super(arity);
/*  27 */     this.mElemName = elemName;
/*     */   }
/*     */   
/*     */   public static TokenContentSpec construct(char arity, NameKey elemName)
/*     */   {
/*  32 */     return new TokenContentSpec(arity, elemName);
/*     */   }
/*     */   
/*     */   public static TokenContentSpec getDummySpec() {
/*  36 */     return sDummy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLeaf()
/*     */   {
/*  46 */     return this.mArity == ' ';
/*     */   }
/*     */   
/*     */   public NameKey getName() {
/*  50 */     return this.mElemName;
/*     */   }
/*     */   
/*     */   public StructValidator getSimpleValidator() {
/*  54 */     return new Validator(this.mArity, this.mElemName);
/*     */   }
/*     */   
/*     */   public ModelNode rewrite() {
/*  58 */     TokenModel model = new TokenModel(this.mElemName);
/*  59 */     if (this.mArity == '*') {
/*  60 */       return new StarModel(model);
/*     */     }
/*  62 */     if (this.mArity == '?') {
/*  63 */       return new OptionalModel(model);
/*     */     }
/*  65 */     if (this.mArity == '+') {
/*  66 */       return new ConcatModel(model, new StarModel(new TokenModel(this.mElemName)));
/*     */     }
/*     */     
/*  69 */     return model;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  73 */     return this.mElemName.toString() + this.mArity;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final class Validator
/*     */     extends StructValidator
/*     */   {
/*     */     final char mArity;
/*     */     
/*     */ 
/*     */ 
/*     */     final NameKey mElemName;
/*     */     
/*     */ 
/*  89 */     int mCount = 0;
/*     */     
/*     */     public Validator(char arity, NameKey elemName)
/*     */     {
/*  93 */       this.mArity = arity;
/*  94 */       this.mElemName = elemName;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public StructValidator newInstance()
/*     */     {
/* 105 */       return this.mArity == '*' ? this : new Validator(this.mArity, this.mElemName);
/*     */     }
/*     */     
/*     */     public String tryToValidate(NameKey elemName)
/*     */     {
/* 110 */       if (!elemName.equals(this.mElemName)) {
/* 111 */         return "Expected element <" + this.mElemName + ">";
/*     */       }
/* 113 */       if ((++this.mCount > 1) && ((this.mArity == '?') || (this.mArity == ' '))) {
/* 114 */         return "More than one instance of element <" + this.mElemName + ">";
/*     */       }
/* 116 */       return null;
/*     */     }
/*     */     
/*     */     public String fullyValid()
/*     */     {
/* 121 */       switch (this.mArity) {
/*     */       case '*': 
/*     */       case '?': 
/* 124 */         return null;
/*     */       case ' ': 
/*     */       case '+': 
/* 127 */         if (this.mCount > 0) {
/* 128 */           return null;
/*     */         }
/* 130 */         return "Expected " + (this.mArity == '+' ? "at least one" : "") + " element <" + this.mElemName + ">";
/*     */       }
/*     */       
/*     */       
/* 134 */       throw new Error("Internal error");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\TokenContentSpec.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */