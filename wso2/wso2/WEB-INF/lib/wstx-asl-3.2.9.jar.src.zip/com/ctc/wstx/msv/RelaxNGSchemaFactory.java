/*     */ package com.ctc.wstx.msv;
/*     */ 
/*     */ import com.ctc.wstx.api.ValidatorConfig;
/*     */ import com.ctc.wstx.exc.WstxIOException;
/*     */ import com.ctc.wstx.util.URLUtil;
/*     */ import com.sun.msv.grammar.trex.TREXGrammar;
/*     */ import com.sun.msv.reader.GrammarReaderController;
/*     */ import com.sun.msv.reader.trex.ng.RELAXNGReader;
/*     */ import com.sun.msv.reader.util.IgnoreController;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.codehaus.stax2.validation.XMLValidationSchema;
/*     */ import org.codehaus.stax2.validation.XMLValidationSchemaFactory;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.Locator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RelaxNGSchemaFactory
/*     */   extends XMLValidationSchemaFactory
/*     */ {
/*     */   protected final SAXParserFactory mSaxFactory;
/*     */   protected final ValidatorConfig mConfig;
/*  62 */   protected final GrammarReaderController mDummyController = new IgnoreController();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RelaxNGSchemaFactory()
/*     */   {
/*  70 */     this.mSaxFactory = SAXParserFactory.newInstance();
/*  71 */     this.mSaxFactory.setNamespaceAware(true);
/*  72 */     this.mConfig = ValidatorConfig.createDefaults();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPropertySupported(String propName)
/*     */   {
/*  83 */     return this.mConfig.isPropertySupported(propName);
/*     */   }
/*     */   
/*     */   public boolean setProperty(String propName, Object value)
/*     */   {
/*  88 */     return this.mConfig.setProperty(propName, value);
/*     */   }
/*     */   
/*     */   public Object getProperty(String propName)
/*     */   {
/*  93 */     return this.mConfig.getProperty(propName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLValidationSchema createSchema(InputStream in, String encoding, String publicId, String systemId)
/*     */     throws XMLStreamException
/*     */   {
/* 106 */     InputSource src = new InputSource(in);
/* 107 */     src.setEncoding(encoding);
/* 108 */     src.setPublicId(publicId);
/* 109 */     src.setSystemId(systemId);
/* 110 */     return loadSchema(src, systemId);
/*     */   }
/*     */   
/*     */ 
/*     */   public XMLValidationSchema createSchema(Reader r, String publicId, String systemId)
/*     */     throws XMLStreamException
/*     */   {
/* 117 */     InputSource src = new InputSource(r);
/* 118 */     src.setPublicId(publicId);
/* 119 */     src.setSystemId(systemId);
/* 120 */     return loadSchema(src, systemId);
/*     */   }
/*     */   
/*     */   public XMLValidationSchema createSchema(URL url) throws XMLStreamException
/*     */   {
/*     */     try
/*     */     {
/* 127 */       InputStream in = URLUtil.optimizedStreamFromURL(url);
/* 128 */       InputSource src = new InputSource(in);
/* 129 */       src.setSystemId(url.toExternalForm());
/* 130 */       return loadSchema(src, url);
/*     */     } catch (IOException ioe) {
/* 132 */       throw new WstxIOException(ioe);
/*     */     }
/*     */   }
/*     */   
/*     */   public XMLValidationSchema createSchema(File f) throws XMLStreamException
/*     */   {
/*     */     try
/*     */     {
/* 140 */       return createSchema(f.toURL());
/*     */     } catch (IOException ioe) {
/* 142 */       throw new WstxIOException(ioe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XMLValidationSchema loadSchema(InputSource src, Object sysRef)
/*     */     throws XMLStreamException
/*     */   {
/* 163 */     MyGrammarController ctrl = new MyGrammarController();
/* 164 */     TREXGrammar grammar = RELAXNGReader.parse(src, this.mSaxFactory, ctrl);
/* 165 */     if (grammar == null) {
/* 166 */       String msg = "Failed to load RelaxNG from '" + sysRef + "'";
/* 167 */       String emsg = ctrl.mErrorMsg;
/* 168 */       if (emsg != null) {
/* 169 */         msg = msg + ": " + emsg;
/*     */       }
/* 171 */       throw new XMLStreamException(msg);
/*     */     }
/* 173 */     return new RelaxNGSchema(grammar);
/*     */   }
/*     */   
/*     */   static final class MyGrammarController
/*     */     extends IgnoreController
/*     */   {
/* 179 */     public String mErrorMsg = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void error(Locator[] locs, String msg, Exception nestedException)
/*     */     {
/* 187 */       if (this.mErrorMsg == null) {
/* 188 */         this.mErrorMsg = msg;
/*     */       } else {
/* 190 */         this.mErrorMsg = (this.mErrorMsg + "; " + msg);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\msv\RelaxNGSchemaFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */