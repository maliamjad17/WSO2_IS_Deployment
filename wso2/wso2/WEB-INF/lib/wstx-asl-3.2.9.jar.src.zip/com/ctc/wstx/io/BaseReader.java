/*     */ package com.ctc.wstx.io;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import java.io.CharConversionException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BaseReader
/*     */   extends Reader
/*     */ {
/*     */   protected static final char NULL_CHAR = '\000';
/*     */   protected static final char NULL_BYTE = '\000';
/*     */   protected static final char CONVERT_NEL_TO = '\n';
/*     */   protected static final char CONVERT_LSEP_TO = '\n';
/*     */   static final char CHAR_DEL = '';
/*     */   private final ReaderConfig mConfig;
/*     */   protected InputStream mIn;
/*     */   protected byte[] mBuffer;
/*     */   protected int mPtr;
/*     */   protected int mLength;
/*     */   
/*     */   protected BaseReader(ReaderConfig cfg, InputStream in, byte[] buf, int ptr, int len)
/*     */   {
/*  51 */     this.mConfig = cfg;
/*  52 */     this.mIn = in;
/*  53 */     this.mBuffer = buf;
/*  54 */     this.mPtr = ptr;
/*  55 */     this.mLength = len;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setXmlCompliancy(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/*  83 */     InputStream in = this.mIn;
/*     */     
/*  85 */     if (in != null) {
/*  86 */       this.mIn = null;
/*  87 */       freeBuffers();
/*  88 */       in.close();
/*     */     }
/*     */   }
/*     */   
/*  92 */   char[] mTmpBuf = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/* 102 */     if (this.mTmpBuf == null) {
/* 103 */       this.mTmpBuf = new char[1];
/*     */     }
/* 105 */     if (read(this.mTmpBuf, 0, 1) < 1) {
/* 106 */       return -1;
/*     */     }
/* 108 */     return this.mTmpBuf[0];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void freeBuffers()
/*     */   {
/* 129 */     byte[] buf = this.mBuffer;
/*     */     
/* 131 */     if (buf != null) {
/* 132 */       this.mBuffer = null;
/* 133 */       if (this.mConfig != null) {
/* 134 */         this.mConfig.freeFullBBuffer(buf);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void reportBounds(char[] cbuf, int start, int len)
/*     */     throws IOException
/*     */   {
/* 142 */     throw new ArrayIndexOutOfBoundsException("read(buf," + start + "," + len + "), cbuf[" + cbuf.length + "]");
/*     */   }
/*     */   
/*     */   protected void reportStrangeStream()
/*     */     throws IOException
/*     */   {
/* 148 */     throw new IOException("Strange I/O stream, returned 0 bytes on read");
/*     */   }
/*     */   
/*     */   protected void reportInvalidXml11(int value, int bytePos, int charPos)
/*     */     throws IOException
/*     */   {
/* 154 */     throw new CharConversionException("Invalid character 0x" + Integer.toHexString(value) + ", can only be included in xml 1.1 using character entities (at char #" + charPos + ", byte #" + bytePos + ")");
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\io\BaseReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */