/*    */ package com.ctc.wstx.ent;
/*    */ 
/*    */ import com.ctc.wstx.evt.WNotationDeclaration;
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ import javax.xml.stream.Location;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotationDecl
/*    */   extends WNotationDeclaration
/*    */ {
/*    */   final Location mLocation;
/*    */   final String mName;
/*    */   final String mPublicId;
/*    */   final String mSystemId;
/*    */   
/*    */   public NotationDecl(Location loc, String name, String pubId, String sysId)
/*    */   {
/* 32 */     super(loc);
/* 33 */     this.mLocation = loc;
/* 34 */     this.mName = name;
/* 35 */     this.mPublicId = pubId;
/* 36 */     this.mSystemId = sysId;
/*    */   }
/*    */   
/*    */   public Location getLocation() {
/* 40 */     return this.mLocation;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 44 */     return this.mName;
/*    */   }
/*    */   
/*    */   public String getPublicId() {
/* 48 */     return this.mPublicId;
/*    */   }
/*    */   
/*    */   public String getSystemId() {
/* 52 */     return this.mSystemId;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void writeEnc(Writer w)
/*    */     throws IOException
/*    */   {
/* 63 */     w.write("<!NOTATION ");
/* 64 */     w.write(this.mName);
/* 65 */     if (this.mPublicId != null) {
/* 66 */       w.write("PUBLIC \"");
/* 67 */       w.write(this.mPublicId);
/* 68 */       w.write(34);
/*    */     } else {
/* 70 */       w.write("SYSTEM");
/*    */     }
/* 72 */     if (this.mSystemId != null) {
/* 73 */       w.write(" \"");
/* 74 */       w.write(this.mSystemId);
/* 75 */       w.write(34);
/*    */     }
/* 77 */     w.write(62);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\ent\NotationDecl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */