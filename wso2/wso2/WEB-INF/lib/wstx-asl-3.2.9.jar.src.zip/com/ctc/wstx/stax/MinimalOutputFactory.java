/*     */ package com.ctc.wstx.stax;
/*     */ 
/*     */ import com.ctc.wstx.api.WriterConfig;
/*     */ import com.ctc.wstx.cfg.OutputConfigFlags;
/*     */ import com.ctc.wstx.exc.WstxIOException;
/*     */ import com.ctc.wstx.io.CharsetNames;
/*     */ import com.ctc.wstx.io.UTF8Writer;
/*     */ import com.ctc.wstx.sw.BaseStreamWriter;
/*     */ import com.ctc.wstx.sw.BufferingXmlWriter;
/*     */ import com.ctc.wstx.sw.ISOLatin1XmlWriter;
/*     */ import com.ctc.wstx.sw.NonNsStreamWriter;
/*     */ import com.ctc.wstx.sw.RepairingNsStreamWriter;
/*     */ import com.ctc.wstx.sw.SimpleNsStreamWriter;
/*     */ import com.ctc.wstx.sw.XmlWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.dom.DOMResult;
/*     */ import javax.xml.transform.sax.SAXResult;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import org.codehaus.stax2.io.Stax2Result;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MinimalOutputFactory
/*     */   implements OutputConfigFlags
/*     */ {
/*     */   protected final boolean mIsMinimal;
/*     */   protected final WriterConfig mConfig;
/*     */   
/*     */   protected MinimalOutputFactory(boolean isMinimal)
/*     */   {
/*  77 */     this.mIsMinimal = isMinimal;
/*  78 */     this.mConfig = WriterConfig.createJ2MEDefaults();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static MinimalOutputFactory newMinimalInstance()
/*     */   {
/*  85 */     return new MinimalOutputFactory(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLStreamWriter createXMLStreamWriter(OutputStream out)
/*     */     throws XMLStreamException
/*     */   {
/*  99 */     return createSW(out, null, null, false);
/*     */   }
/*     */   
/*     */   public XMLStreamWriter createXMLStreamWriter(OutputStream out, String enc)
/*     */     throws XMLStreamException
/*     */   {
/* 105 */     return createSW(out, null, enc, false);
/*     */   }
/*     */   
/*     */   public XMLStreamWriter createXMLStreamWriter(Result result)
/*     */     throws XMLStreamException
/*     */   {
/* 111 */     return createSW(result);
/*     */   }
/*     */   
/*     */   public XMLStreamWriter createXMLStreamWriter(Writer w)
/*     */     throws XMLStreamException
/*     */   {
/* 117 */     return createSW(null, w, null, false);
/*     */   }
/*     */   
/*     */   public XMLStreamWriter createXMLStreamWriter(Writer w, String enc)
/*     */     throws XMLStreamException
/*     */   {
/* 123 */     return createSW(null, w, enc, false);
/*     */   }
/*     */   
/*     */   public Object getProperty(String name)
/*     */   {
/* 128 */     return this.mConfig.getProperty(name);
/*     */   }
/*     */   
/*     */   public boolean isPropertySupported(String name) {
/* 132 */     return this.mConfig.isPropertySupported(name);
/*     */   }
/*     */   
/*     */   public void setProperty(String name, Object value)
/*     */   {
/* 137 */     this.mConfig.setProperty(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WriterConfig getConfig()
/*     */   {
/* 147 */     return this.mConfig;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private BaseStreamWriter createSW(OutputStream out, Writer w, String enc, boolean autoCloseOutput)
/*     */     throws XMLStreamException
/*     */   {
/* 168 */     WriterConfig cfg = this.mConfig.createNonShared();
/*     */     
/*     */     XmlWriter xw;
/* 171 */     if (w == null) {
/* 172 */       if (enc == null) {
/* 173 */         enc = "UTF-8";
/*     */       } else {
/* 175 */         enc = CharsetNames.normalize(enc);
/*     */       }
/*     */       try {
/*     */         XmlWriter xw;
/* 179 */         if (enc == "UTF-8")
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 184 */           w = new UTF8Writer(cfg, out, autoCloseOutput);
/* 185 */           xw = new BufferingXmlWriter(w, cfg, enc, true, out);
/*     */         } else { XmlWriter xw;
/* 187 */           if (enc == "ISO-8859-1") {
/* 188 */             xw = new ISOLatin1XmlWriter(out, cfg, autoCloseOutput);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 202 */             w = new OutputStreamWriter(out, enc);
/* 203 */             xw = new BufferingXmlWriter(w, cfg, enc, autoCloseOutput, out);
/*     */           }
/*     */         }
/* 206 */       } catch (IOException ex) { throw new XMLStreamException(ex);
/*     */       }
/*     */     }
/*     */     else {
/* 210 */       if (enc == null) {
/* 211 */         enc = CharsetNames.findEncodingFor(w);
/*     */       }
/*     */       try {
/* 214 */         xw = new BufferingXmlWriter(w, cfg, enc, autoCloseOutput, out);
/*     */       } catch (IOException ex) {
/* 216 */         throw new XMLStreamException(ex);
/*     */       }
/*     */     }
/*     */     
/* 220 */     if (cfg.willSupportNamespaces()) {
/* 221 */       if (cfg.automaticNamespacesEnabled()) {
/* 222 */         return new RepairingNsStreamWriter(xw, enc, cfg);
/*     */       }
/* 224 */       return new SimpleNsStreamWriter(xw, enc, cfg);
/*     */     }
/* 226 */     return new NonNsStreamWriter(xw, enc, cfg);
/*     */   }
/*     */   
/*     */   private BaseStreamWriter createSW(Result res)
/*     */     throws XMLStreamException
/*     */   {
/* 232 */     OutputStream out = null;
/* 233 */     Writer w = null;
/* 234 */     String encoding = null;
/*     */     
/*     */     boolean autoclose;
/* 237 */     if ((res instanceof Stax2Result)) {
/* 238 */       Stax2Result sr = (Stax2Result)res;
/*     */       try {
/* 240 */         out = sr.constructOutputStream();
/* 241 */         if (out == null) {
/* 242 */           w = sr.constructWriter();
/*     */         }
/*     */       } catch (IOException ioe) {
/* 245 */         throw new WstxIOException(ioe);
/*     */       }
/* 247 */       autoclose = true; } else { boolean autoclose;
/* 248 */       if ((res instanceof StreamResult)) {
/* 249 */         StreamResult sr = (StreamResult)res;
/* 250 */         out = sr.getOutputStream();
/* 251 */         if (out == null) {
/* 252 */           w = sr.getWriter();
/*     */         }
/* 254 */         autoclose = false;
/* 255 */       } else { if ((res instanceof SAXResult))
/*     */         {
/*     */ 
/* 258 */           throw new XMLStreamException("Can not create a STaX writer for a SAXResult -- not implemented."); }
/* 259 */         if ((res instanceof DOMResult))
/*     */         {
/*     */ 
/* 262 */           throw new XMLStreamException("Can not create a STaX writer for a DOMResult -- not (yet?) implemented.");
/*     */         }
/* 264 */         throw new IllegalArgumentException("Can not instantiate a writer for XML result type " + res.getClass() + " (unrecognized type)");
/*     */       } }
/*     */     boolean autoclose;
/* 267 */     if (out != null) {
/* 268 */       return createSW(out, null, encoding, autoclose);
/*     */     }
/* 270 */     if (w != null) {
/* 271 */       return createSW(null, w, encoding, autoclose);
/*     */     }
/* 273 */     throw new XMLStreamException("Can not create StAX writer for passed-in Result -- neither writer nor output stream was accessible");
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\stax\MinimalOutputFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */