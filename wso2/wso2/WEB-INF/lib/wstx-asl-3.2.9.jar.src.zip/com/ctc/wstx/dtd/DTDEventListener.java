package com.ctc.wstx.dtd;

import java.net.URL;
import javax.xml.stream.XMLStreamException;

public abstract interface DTDEventListener
{
  public abstract boolean dtdReportComments();
  
  public abstract void dtdProcessingInstruction(String paramString1, String paramString2);
  
  public abstract void dtdComment(char[] paramArrayOfChar, int paramInt1, int paramInt2);
  
  public abstract void dtdSkippedEntity(String paramString);
  
  public abstract void dtdNotationDecl(String paramString1, String paramString2, String paramString3, URL paramURL)
    throws XMLStreamException;
  
  public abstract void dtdUnparsedEntityDecl(String paramString1, String paramString2, String paramString3, String paramString4, URL paramURL)
    throws XMLStreamException;
  
  public abstract void attributeDecl(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5);
  
  public abstract void dtdElementDecl(String paramString1, String paramString2);
  
  public abstract void dtdExternalEntityDecl(String paramString1, String paramString2, String paramString3);
  
  public abstract void dtdInternalEntityDecl(String paramString1, String paramString2);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\DTDEventListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */