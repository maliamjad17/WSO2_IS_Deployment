/*     */ package com.ctc.wstx.compat;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Jdk12Impl
/*     */   extends JdkImpl
/*     */ {
/*     */   private final List mEmptyList;
/*     */   private final Map mEmptyMap;
/*     */   private final Set mEmptySet;
/*     */   
/*     */   public Jdk12Impl()
/*     */   {
/*  22 */     this.mEmptyList = Collections.unmodifiableList(new ArrayList(1));
/*  23 */     this.mEmptyMap = Collections.unmodifiableMap(new HashMap(4));
/*  24 */     this.mEmptySet = Collections.unmodifiableSet(new HashSet(4));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Jdk12Impl(boolean dummy)
/*     */   {
/*  32 */     this.mEmptyList = null;
/*  33 */     this.mEmptyMap = null;
/*  34 */     this.mEmptySet = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean leakingThreadLocal()
/*     */   {
/*  50 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public List getEmptyList()
/*     */   {
/*  56 */     return this.mEmptyList;
/*     */   }
/*     */   
/*     */   public Map getEmptyMap() {
/*  60 */     return this.mEmptyMap;
/*     */   }
/*     */   
/*     */   public Set getEmptySet() {
/*  64 */     return this.mEmptySet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HashMap getInsertOrderedMap()
/*     */   {
/*  74 */     return new HashMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public HashMap getInsertOrderedMap(int initialSize)
/*     */   {
/*  82 */     return new HashMap(initialSize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public HashMap getLRULimitMap(int maxSize)
/*     */   {
/*  90 */     return new HashMap(5 + maxSize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean setInitCause(Throwable newT, Throwable rootT)
/*     */   {
/* 103 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\compat\Jdk12Impl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */