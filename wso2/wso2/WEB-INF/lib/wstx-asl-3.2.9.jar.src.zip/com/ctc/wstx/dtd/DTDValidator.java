/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ import com.ctc.wstx.cfg.ErrorConsts;
/*     */ import com.ctc.wstx.util.DataUtil;
/*     */ import com.ctc.wstx.util.StringUtil;
/*     */ import java.util.BitSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.codehaus.stax2.validation.ValidationContext;
/*     */ import org.codehaus.stax2.validation.XMLValidationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DTDValidator
/*     */   extends DTDValidatorBase
/*     */ {
/*  54 */   protected boolean mReportDuplicateErrors = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  66 */   protected ElementIdMap mIdMap = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  77 */   protected StructValidator[] mValidators = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */   protected BitSet mCurrSpecialAttrs = null;
/*     */   
/*  85 */   boolean mCurrHasAnyFixed = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   BitSet mTmpSpecialAttrs;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DTDValidator(DTDSubset schema, ValidationContext ctxt, boolean hasNsDefaults, Map elemSpecs, Map genEntities)
/*     */   {
/* 109 */     super(schema, ctxt, hasNsDefaults, elemSpecs, genEntities);
/* 110 */     this.mValidators = new StructValidator[16];
/*     */   }
/*     */   
/* 113 */   public final boolean reallyValidating() { return true; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validateElementStart(String localName, String uri, String prefix)
/*     */     throws XMLValidationException
/*     */   {
/* 135 */     this.mTmpKey.reset(prefix, localName);
/*     */     
/* 137 */     DTDElement elem = (DTDElement)this.mElemSpecs.get(this.mTmpKey);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 143 */     int elemCount = this.mElemCount++;
/* 144 */     if (elemCount >= this.mElems.length) {
/* 145 */       this.mElems = ((DTDElement[])DataUtil.growArrayBy50Pct(this.mElems));
/* 146 */       this.mValidators = ((StructValidator[])DataUtil.growArrayBy50Pct(this.mValidators));
/*     */     }
/* 148 */     this.mElems[elemCount] = (this.mCurrElem = elem);
/* 149 */     if ((elem == null) || (!elem.isDefined())) {
/* 150 */       reportValidationProblem(ErrorConsts.ERR_VLD_UNKNOWN_ELEM, this.mTmpKey.toString());
/*     */     }
/*     */     
/*     */ 
/* 154 */     StructValidator pv = elemCount > 0 ? this.mValidators[(elemCount - 1)] : null;
/*     */     
/* 156 */     if ((pv != null) && (elem != null)) {
/* 157 */       String msg = pv.tryToValidate(elem.getName());
/* 158 */       if (msg != null) {
/* 159 */         int ix = msg.indexOf("$END");
/* 160 */         String pname = this.mElems[(elemCount - 1)].toString();
/* 161 */         if (ix >= 0) {
/* 162 */           msg = msg.substring(0, ix) + "</" + pname + ">" + msg.substring(ix + 4);
/*     */         }
/*     */         
/* 165 */         reportValidationProblem("Validation error, encountered element <" + elem.getName() + "> as a child of <" + pname + ">: " + msg);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 171 */     this.mAttrCount = 0;
/* 172 */     this.mIdAttrIndex = -2;
/*     */     
/*     */ 
/* 175 */     if (elem == null) {
/* 176 */       this.mValidators[elemCount] = null;
/* 177 */       this.mCurrAttrDefs = EMPTY_MAP;
/* 178 */       this.mCurrHasAnyFixed = false;
/* 179 */       this.mCurrSpecialAttrs = null;
/*     */     } else {
/* 181 */       this.mValidators[elemCount] = elem.getValidator();
/* 182 */       this.mCurrAttrDefs = elem.getAttributes();
/* 183 */       if (this.mCurrAttrDefs == null) {
/* 184 */         this.mCurrAttrDefs = EMPTY_MAP;
/*     */       }
/* 186 */       this.mCurrHasAnyFixed = elem.hasFixedAttrs();
/* 187 */       int specCount = elem.getSpecialCount();
/* 188 */       if (specCount == 0) {
/* 189 */         this.mCurrSpecialAttrs = null;
/*     */       } else {
/* 191 */         BitSet bs = this.mTmpSpecialAttrs;
/* 192 */         if (bs == null) {
/* 193 */           this.mTmpSpecialAttrs = (bs = new BitSet(specCount));
/*     */         } else {
/* 195 */           bs.clear();
/*     */         }
/* 197 */         this.mCurrSpecialAttrs = bs;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String validateAttribute(String localName, String uri, String prefix, String value)
/*     */     throws XMLValidationException
/*     */   {
/* 206 */     DTDAttribute attr = (DTDAttribute)this.mCurrAttrDefs.get(this.mTmpKey.reset(prefix, localName));
/* 207 */     if (attr == null)
/*     */     {
/* 209 */       if (this.mCurrElem != null) {
/* 210 */         reportValidationProblem(ErrorConsts.ERR_VLD_UNKNOWN_ATTR, this.mCurrElem.toString(), this.mTmpKey.toString());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 216 */       return value;
/*     */     }
/* 218 */     int index = this.mAttrCount++;
/* 219 */     if (index >= this.mAttrSpecs.length) {
/* 220 */       this.mAttrSpecs = ((DTDAttribute[])DataUtil.growArrayBy50Pct(this.mAttrSpecs));
/*     */     }
/* 222 */     this.mAttrSpecs[index] = attr;
/* 223 */     if (this.mCurrSpecialAttrs != null) {
/* 224 */       int specIndex = attr.getSpecialIndex();
/* 225 */       if (specIndex >= 0) {
/* 226 */         this.mCurrSpecialAttrs.set(specIndex);
/*     */       }
/*     */     }
/* 229 */     String result = attr.validate(this, value, this.mNormAttrs);
/* 230 */     if ((this.mCurrHasAnyFixed) && (attr.isFixed())) {
/* 231 */       String act = result == null ? value : result;
/* 232 */       String exp = attr.getDefaultValue(this.mContext);
/* 233 */       if (!act.equals(exp)) {
/* 234 */         reportValidationProblem("Value of attribute \"" + attr + "\" (element <" + this.mCurrElem + ">) not \"" + exp + "\" as expected, but \"" + act + "\"");
/*     */       }
/*     */     }
/* 237 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validateAttribute(String localName, String uri, String prefix, char[] valueChars, int valueStart, int valueEnd)
/*     */     throws XMLValidationException
/*     */   {
/* 246 */     DTDAttribute attr = (DTDAttribute)this.mCurrAttrDefs.get(this.mTmpKey.reset(prefix, localName));
/* 247 */     if (attr == null)
/*     */     {
/* 249 */       if (this.mCurrElem != null) {
/* 250 */         reportValidationProblem(ErrorConsts.ERR_VLD_UNKNOWN_ATTR, this.mCurrElem.toString(), this.mTmpKey.toString());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 256 */       return new String(valueChars, valueStart, valueEnd);
/*     */     }
/* 258 */     int index = this.mAttrCount++;
/* 259 */     if (index >= this.mAttrSpecs.length) {
/* 260 */       this.mAttrSpecs = ((DTDAttribute[])DataUtil.growArrayBy50Pct(this.mAttrSpecs));
/*     */     }
/* 262 */     this.mAttrSpecs[index] = attr;
/* 263 */     if (this.mCurrSpecialAttrs != null) {
/* 264 */       int specIndex = attr.getSpecialIndex();
/* 265 */       if (specIndex >= 0) {
/* 266 */         this.mCurrSpecialAttrs.set(specIndex);
/*     */       }
/*     */     }
/* 269 */     String result = attr.validate(this, valueChars, valueStart, valueEnd, this.mNormAttrs);
/* 270 */     if ((this.mCurrHasAnyFixed) && (attr.isFixed())) {
/* 271 */       String exp = attr.getDefaultValue(this.mContext);
/*     */       boolean match;
/* 273 */       boolean match; if (result == null) {
/* 274 */         match = StringUtil.matches(exp, valueChars, valueStart, valueEnd - valueStart);
/*     */       } else {
/* 276 */         match = exp.equals(result);
/*     */       }
/* 278 */       if (!match) {
/* 279 */         String act = result == null ? new String(valueChars, valueStart, valueEnd) : result;
/*     */         
/* 281 */         reportValidationProblem("Value of #FIXED attribute \"" + attr + "\" (element <" + this.mCurrElem + ">) not \"" + exp + "\" as expected, but \"" + act + "\"");
/*     */       }
/*     */     }
/* 284 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public int validateElementAndAttributes()
/*     */     throws XMLValidationException
/*     */   {
/* 291 */     DTDElement elem = this.mCurrElem;
/* 292 */     if (elem == null)
/*     */     {
/* 294 */       return 3;
/*     */     }
/*     */     
/*     */ 
/* 298 */     if (this.mCurrSpecialAttrs != null) {
/* 299 */       BitSet specBits = this.mCurrSpecialAttrs;
/* 300 */       int specCount = elem.getSpecialCount();
/* 301 */       int ix = specBits.nextClearBit(0);
/* 302 */       while (ix < specCount) {
/* 303 */         List specAttrs = elem.getSpecialAttrs();
/* 304 */         DTDAttribute attr = (DTDAttribute)specAttrs.get(ix);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 311 */         if (attr.isRequired()) {
/* 312 */           reportValidationProblem("Required attribute '" + attr + "' missing from element <" + elem + ">");
/*     */         } else {
/* 314 */           doAddDefaultValue(attr);
/*     */         }
/* 316 */         ix = specBits.nextClearBit(ix + 1);
/*     */       }
/*     */     }
/*     */     
/* 320 */     return elem.getAllowedContent();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int validateElementEnd(String localName, String uri, String prefix)
/*     */     throws XMLValidationException
/*     */   {
/* 331 */     int ix = --this.mElemCount;
/* 332 */     DTDElement closingElem = this.mElems[ix];
/* 333 */     this.mElems[ix] = null;
/* 334 */     StructValidator v = this.mValidators[ix];
/* 335 */     this.mValidators[ix] = null;
/*     */     
/*     */ 
/* 338 */     if (v != null) {
/* 339 */       String msg = v.fullyValid();
/* 340 */       if (msg != null) {
/* 341 */         reportValidationProblem("Validation error, element </" + closingElem + ">: " + msg);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 347 */     if (ix < 1) {
/* 348 */       checkIdRefs();
/*     */       
/*     */ 
/* 351 */       return 1;
/*     */     }
/* 353 */     return this.mElems[(ix - 1)].getAllowedContent();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validationCompleted(boolean eod)
/*     */     throws XMLValidationException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ElementIdMap getIdMap()
/*     */   {
/* 372 */     if (this.mIdMap == null) {
/* 373 */       this.mIdMap = new ElementIdMap();
/*     */     }
/* 375 */     return this.mIdMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkIdRefs()
/*     */     throws XMLValidationException
/*     */   {
/* 390 */     if (this.mIdMap != null) {
/* 391 */       ElementId ref = this.mIdMap.getFirstUndefined();
/* 392 */       if (ref != null) {
/* 393 */         reportValidationProblem("Undefined id '" + ref.getId() + "': referenced from element <" + ref.getElemName() + ">, attribute '" + ref.getAttrName() + "'", ref.getLocation());
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\DTDValidator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */