/*     */ package com.ctc.wstx.evt;
/*     */ 
/*     */ import com.ctc.wstx.io.TextEscaper;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.stream.events.Characters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WCharacters
/*     */   extends WEvent
/*     */   implements Characters
/*     */ {
/*     */   final String mContent;
/*     */   final boolean mIsCData;
/*     */   final boolean mIgnorableWS;
/*  22 */   boolean mWhitespaceChecked = false;
/*  23 */   boolean mIsWhitespace = false;
/*     */   
/*     */   public WCharacters(Location loc, String content, boolean cdata)
/*     */   {
/*  27 */     super(loc);
/*  28 */     this.mContent = content;
/*  29 */     this.mIsCData = cdata;
/*  30 */     this.mIgnorableWS = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private WCharacters(Location loc, String content, boolean cdata, boolean allWS, boolean ignorableWS)
/*     */   {
/*  39 */     super(loc);
/*  40 */     this.mContent = content;
/*  41 */     this.mIsCData = cdata;
/*  42 */     this.mIsWhitespace = allWS;
/*  43 */     if (allWS) {
/*  44 */       this.mWhitespaceChecked = true;
/*  45 */       this.mIgnorableWS = ignorableWS;
/*     */     } else {
/*  47 */       this.mWhitespaceChecked = false;
/*  48 */       this.mIgnorableWS = false;
/*     */     }
/*     */   }
/*     */   
/*     */   public static final WCharacters createIgnorableWS(Location loc, String content) {
/*  53 */     return new WCharacters(loc, content, false, true, true);
/*     */   }
/*     */   
/*     */   public static final WCharacters createNonIgnorableWS(Location loc, String content) {
/*  57 */     return new WCharacters(loc, content, false, true, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Characters asCharacters()
/*     */   {
/*  67 */     return this;
/*     */   }
/*     */   
/*     */   public int getEventType() {
/*  71 */     return this.mIsCData ? 12 : 4;
/*     */   }
/*     */   
/*  74 */   public boolean isCharacters() { return true; }
/*     */   
/*     */   public void writeAsEncodedUnicode(Writer w) throws XMLStreamException
/*     */   {
/*     */     try
/*     */     {
/*  80 */       if (this.mIsCData) {
/*  81 */         w.write("<![CDATA[");
/*  82 */         w.write(this.mContent);
/*  83 */         w.write("]]>");
/*     */       } else {
/*  85 */         TextEscaper.writeEscapedXMLText(w, this.mContent);
/*     */       }
/*     */     } catch (IOException ie) {
/*  88 */       throwFromIOE(ie);
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeUsing(XMLStreamWriter w) throws XMLStreamException
/*     */   {
/*  94 */     if (this.mIsCData) {
/*  95 */       w.writeCData(this.mContent);
/*     */     } else {
/*  97 */       w.writeCharacters(this.mContent);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getData()
/*     */   {
/* 108 */     return this.mContent;
/*     */   }
/*     */   
/*     */   public boolean isCData() {
/* 112 */     return this.mIsCData;
/*     */   }
/*     */   
/*     */   public boolean isIgnorableWhiteSpace() {
/* 116 */     return this.mIgnorableWS;
/*     */   }
/*     */   
/*     */   public boolean isWhiteSpace()
/*     */   {
/* 121 */     if (!this.mWhitespaceChecked) {
/* 122 */       this.mWhitespaceChecked = true;
/* 123 */       String str = this.mContent;
/* 124 */       int i = 0;
/* 125 */       int len = str.length();
/* 126 */       for (; i < len; i++) {
/* 127 */         if (str.charAt(i) > ' ') {
/*     */           break;
/*     */         }
/*     */       }
/* 131 */       this.mIsWhitespace = (i == len);
/*     */     }
/* 133 */     return this.mIsWhitespace;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWhitespaceStatus(boolean status)
/*     */   {
/* 143 */     this.mWhitespaceChecked = true;
/* 144 */     this.mIsWhitespace = status;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\evt\WCharacters.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */