/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ import com.ctc.wstx.cfg.ErrorConsts;
/*     */ import javax.xml.stream.Location;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ElementId
/*     */ {
/*     */   boolean mDefined;
/*     */   final String mIdValue;
/*     */   Location mLocation;
/*     */   NameKey mElemName;
/*     */   NameKey mAttrName;
/*     */   ElementId mNextUndefd;
/*     */   ElementId mNextColl;
/*     */   
/*     */   ElementId(String id, Location loc, boolean defined, NameKey elemName, NameKey attrName)
/*     */   {
/*  81 */     this.mIdValue = id;
/*  82 */     this.mLocation = loc;
/*  83 */     this.mDefined = defined;
/*  84 */     this.mElemName = elemName;
/*  85 */     this.mAttrName = attrName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getId()
/*     */   {
/*  95 */     return this.mIdValue;
/*     */   }
/*     */   
/*     */   public Location getLocation() {
/*  99 */     return this.mLocation;
/*     */   }
/*     */   
/*     */   public NameKey getElemName() {
/* 103 */     return this.mElemName;
/*     */   }
/*     */   
/*     */   public NameKey getAttrName() {
/* 107 */     return this.mAttrName;
/*     */   }
/*     */   
/*     */   public boolean idMatches(char[] buf, int start, int len)
/*     */   {
/* 112 */     if (this.mIdValue.length() != len) {
/* 113 */       return false;
/*     */     }
/*     */     
/* 116 */     if (buf[start] != this.mIdValue.charAt(0)) {
/* 117 */       return false;
/*     */     }
/* 119 */     int i = 1;
/* 120 */     len += start;
/* 121 */     for (;;) { start++; if (start >= len) break;
/* 122 */       if (buf[start] != this.mIdValue.charAt(i)) {
/* 123 */         return false;
/*     */       }
/* 125 */       i++;
/*     */     }
/* 127 */     return true;
/*     */   }
/*     */   
/*     */   public void markDefined(Location defLoc) {
/* 131 */     if (this.mDefined) {
/* 132 */       throw new Error(ErrorConsts.ERR_INTERNAL);
/*     */     }
/* 134 */     this.mDefined = true;
/* 135 */     this.mLocation = defLoc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 145 */     return this.mIdValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\ElementId.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */