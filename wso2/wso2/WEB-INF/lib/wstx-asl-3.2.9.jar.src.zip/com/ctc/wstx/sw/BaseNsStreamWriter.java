/*     */ package com.ctc.wstx.sw;
/*     */ 
/*     */ import com.ctc.wstx.api.WriterConfig;
/*     */ import com.ctc.wstx.cfg.ErrorConsts;
/*     */ import com.ctc.wstx.exc.WstxIOException;
/*     */ import com.ctc.wstx.util.DefaultXmlSymbolTable;
/*     */ import java.io.IOException;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.events.StartElement;
/*     */ import org.codehaus.stax2.validation.XMLValidator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseNsStreamWriter
/*     */   extends BaseStreamWriter
/*     */ {
/*  53 */   protected static final String sPrefixXml = ;
/*     */   
/*  55 */   protected static final String sPrefixXmlns = DefaultXmlSymbolTable.getXmlnsSymbol();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static final String ERR_NSDECL_WRONG_STATE = "Trying to write a namespace declaration when there is no open start element.";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final boolean mAutomaticNS;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  81 */   protected SimpleOutputElement mCurrElem = SimpleOutputElement.createRoot();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  87 */   protected NamespaceContext mRootNsContext = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */   protected SimpleOutputElement mOutputElemPool = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int MAX_POOL_SIZE = 8;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 111 */   protected int mPoolSize = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BaseNsStreamWriter(XmlWriter xw, String enc, WriterConfig cfg, boolean repairing)
/*     */   {
/* 122 */     super(xw, enc, cfg);
/* 123 */     this.mAutomaticNS = repairing;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NamespaceContext getNamespaceContext()
/*     */   {
/* 133 */     return this.mCurrElem;
/*     */   }
/*     */   
/*     */   public String getPrefix(String uri) {
/* 137 */     return this.mCurrElem.getPrefix(uri);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setDefaultNamespace(String paramString)
/*     */     throws XMLStreamException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNamespaceContext(NamespaceContext ctxt)
/*     */     throws XMLStreamException
/*     */   {
/* 152 */     if (this.mState != 1) {
/* 153 */       throwOutputError("Called setNamespaceContext() after having already output root element.");
/*     */     }
/*     */     
/* 156 */     this.mRootNsContext = ctxt;
/* 157 */     this.mCurrElem.setRootNsContext(ctxt);
/*     */   }
/*     */   
/*     */   public void setPrefix(String prefix, String uri)
/*     */     throws XMLStreamException
/*     */   {
/* 163 */     if (prefix == null) {
/* 164 */       throw new NullPointerException("Can not pass null 'prefix' value");
/*     */     }
/*     */     
/* 167 */     if (prefix.length() == 0) {
/* 168 */       setDefaultNamespace(uri);
/* 169 */       return;
/*     */     }
/* 171 */     if (uri == null) {
/* 172 */       throw new NullPointerException("Can not pass null 'uri' value");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 184 */     if (prefix.equals(sPrefixXml)) {
/* 185 */       if (!uri.equals("http://www.w3.org/XML/1998/namespace")) {
/* 186 */         throwOutputError(ErrorConsts.ERR_NS_REDECL_XML, uri);
/*     */       }
/* 188 */     } else if (prefix.equals(sPrefixXmlns)) {
/* 189 */       if (!uri.equals("http://www.w3.org/2000/xmlns/")) {
/* 190 */         throwOutputError(ErrorConsts.ERR_NS_REDECL_XMLNS, uri);
/*     */       }
/*     */       
/*     */     }
/* 194 */     else if (uri.equals("http://www.w3.org/XML/1998/namespace")) {
/* 195 */       throwOutputError(ErrorConsts.ERR_NS_REDECL_XML_URI, prefix);
/* 196 */     } else if (uri.equals("http://www.w3.org/2000/xmlns/")) {
/* 197 */       throwOutputError(ErrorConsts.ERR_NS_REDECL_XMLNS_URI, prefix);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 208 */     if ((!this.mXml11) && 
/* 209 */       (uri.length() == 0)) {
/* 210 */       throwOutputError(ErrorConsts.ERR_NS_EMPTY);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 215 */     doSetPrefix(prefix, uri);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeAttribute(String localName, String value)
/*     */     throws XMLStreamException
/*     */   {
/* 227 */     if ((!this.mStartElementOpen) && (this.mCheckStructure)) {
/* 228 */       reportNwfStructure(ErrorConsts.WERR_ATTR_NO_ELEM);
/*     */     }
/* 230 */     doWriteAttr(localName, null, null, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract void writeAttribute(String paramString1, String paramString2, String paramString3)
/*     */     throws XMLStreamException;
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract void writeAttribute(String paramString1, String paramString2, String paramString3, String paramString4)
/*     */     throws XMLStreamException;
/*     */   
/*     */ 
/*     */ 
/*     */   public void writeEmptyElement(String localName)
/*     */     throws XMLStreamException
/*     */   {
/* 248 */     checkStartElement(localName, null);
/* 249 */     if (this.mValidator != null) {
/* 250 */       this.mValidator.validateElementStart(localName, "", NO_PREFIX);
/*     */     }
/* 252 */     this.mEmptyElement = true;
/* 253 */     if (this.mOutputElemPool != null) {
/* 254 */       SimpleOutputElement newCurr = this.mOutputElemPool;
/* 255 */       this.mOutputElemPool = newCurr.reuseAsChild(this.mCurrElem, localName);
/* 256 */       this.mPoolSize -= 1;
/* 257 */       this.mCurrElem = newCurr;
/*     */     } else {
/* 259 */       this.mCurrElem = this.mCurrElem.createChild(localName);
/*     */     }
/* 261 */     doWriteStartTag(localName);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeEmptyElement(String nsURI, String localName)
/*     */     throws XMLStreamException
/*     */   {
/* 268 */     writeStartOrEmpty(localName, nsURI);
/* 269 */     this.mEmptyElement = true;
/*     */   }
/*     */   
/*     */   public void writeEmptyElement(String prefix, String localName, String nsURI)
/*     */     throws XMLStreamException
/*     */   {
/* 275 */     writeStartOrEmpty(prefix, localName, nsURI);
/* 276 */     this.mEmptyElement = true;
/*     */   }
/*     */   
/*     */   public void writeEndElement()
/*     */     throws XMLStreamException
/*     */   {
/* 282 */     doWriteEndTag(null, this.mCfgAutomaticEmptyElems);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeStartElement(String localName)
/*     */     throws XMLStreamException
/*     */   {
/* 292 */     checkStartElement(localName, null);
/* 293 */     if (this.mValidator != null) {
/* 294 */       this.mValidator.validateElementStart(localName, "", NO_PREFIX);
/*     */     }
/* 296 */     this.mEmptyElement = false;
/* 297 */     if (this.mOutputElemPool != null) {
/* 298 */       SimpleOutputElement newCurr = this.mOutputElemPool;
/* 299 */       this.mOutputElemPool = newCurr.reuseAsChild(this.mCurrElem, localName);
/* 300 */       this.mPoolSize -= 1;
/* 301 */       this.mCurrElem = newCurr;
/*     */     } else {
/* 303 */       this.mCurrElem = this.mCurrElem.createChild(localName);
/*     */     }
/*     */     
/* 306 */     doWriteStartTag(localName);
/*     */   }
/*     */   
/*     */   public void writeStartElement(String nsURI, String localName)
/*     */     throws XMLStreamException
/*     */   {
/* 312 */     writeStartOrEmpty(localName, nsURI);
/* 313 */     this.mEmptyElement = false;
/*     */   }
/*     */   
/*     */   public void writeStartElement(String prefix, String localName, String nsURI)
/*     */     throws XMLStreamException
/*     */   {
/* 319 */     writeStartOrEmpty(prefix, localName, nsURI);
/* 320 */     this.mEmptyElement = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeFullEndElement()
/*     */     throws XMLStreamException
/*     */   {
/* 336 */     doWriteEndTag(null, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public QName getCurrentElementName()
/*     */   {
/* 347 */     return this.mCurrElem.getName();
/*     */   }
/*     */   
/*     */   public String getNamespaceURI(String prefix) {
/* 351 */     return this.mCurrElem.getNamespaceURI(prefix);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeEndElement(QName name)
/*     */     throws XMLStreamException
/*     */   {
/* 368 */     doWriteEndTag(this.mCheckStructure ? name : null, this.mCfgAutomaticEmptyElems);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void closeStartElement(boolean emptyElem)
/*     */     throws XMLStreamException
/*     */   {
/* 382 */     this.mStartElementOpen = false;
/*     */     try
/*     */     {
/* 385 */       if (emptyElem) {
/* 386 */         this.mWriter.writeStartTagEmptyEnd();
/*     */       } else {
/* 388 */         this.mWriter.writeStartTagEnd();
/*     */       }
/*     */     } catch (IOException ioe) {
/* 391 */       throw new WstxIOException(ioe);
/*     */     }
/*     */     
/* 394 */     if (this.mValidator != null) {
/* 395 */       this.mVldContent = this.mValidator.validateElementAndAttributes();
/*     */     }
/*     */     
/*     */ 
/* 399 */     if (emptyElem) {
/* 400 */       SimpleOutputElement curr = this.mCurrElem;
/* 401 */       this.mCurrElem = curr.getParent();
/* 402 */       if (this.mCurrElem.isRoot()) {
/* 403 */         this.mState = 3;
/*     */       }
/* 405 */       if (this.mValidator != null) {
/* 406 */         this.mVldContent = this.mValidator.validateElementEnd(curr.getLocalName(), curr.getNamespaceURI(), curr.getPrefix());
/*     */       }
/*     */       
/* 409 */       if (this.mPoolSize < 8) {
/* 410 */         curr.addToPool(this.mOutputElemPool);
/* 411 */         this.mOutputElemPool = curr;
/* 412 */         this.mPoolSize += 1;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected String getTopElementDesc() {
/* 418 */     return this.mCurrElem.getNameDesc();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkStartElement(String localName, String prefix)
/*     */     throws XMLStreamException
/*     */   {
/* 436 */     if (this.mStartElementOpen) {
/* 437 */       closeStartElement(this.mEmptyElement);
/* 438 */     } else if (this.mState == 1) {
/* 439 */       verifyRootElement(localName, prefix);
/* 440 */     } else if (this.mState == 3) {
/* 441 */       if (this.mCheckStructure) {
/* 442 */         String name = prefix + ":" + localName;
/*     */         
/* 444 */         reportNwfStructure(ErrorConsts.WERR_PROLOG_SECOND_ROOT, name);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 449 */       this.mState = 2;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void doWriteAttr(String localName, String nsURI, String prefix, String value)
/*     */     throws XMLStreamException
/*     */   {
/* 457 */     if (this.mCheckAttrs) {
/* 458 */       this.mCurrElem.checkAttrWrite(nsURI, localName, value);
/*     */     }
/*     */     
/* 461 */     if (this.mValidator != null)
/*     */     {
/*     */ 
/*     */ 
/* 465 */       this.mValidator.validateAttribute(localName, nsURI, prefix, value);
/*     */     }
/*     */     try {
/* 468 */       int vlen = value.length();
/*     */       
/* 470 */       if (vlen >= 12) {
/* 471 */         char[] buf = this.mCopyBuffer;
/* 472 */         if (buf == null) {
/* 473 */           this.mCopyBuffer = (buf = this.mConfig.allocMediumCBuffer(512));
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 478 */         if (vlen <= buf.length) {
/* 479 */           value.getChars(0, vlen, buf, 0);
/* 480 */           if ((prefix != null) && (prefix.length() > 0)) {
/* 481 */             this.mWriter.writeAttribute(prefix, localName, buf, 0, vlen);
/*     */           } else {
/* 483 */             this.mWriter.writeAttribute(localName, buf, 0, vlen);
/*     */           }
/* 485 */           return;
/*     */         }
/*     */       }
/* 488 */       if ((prefix != null) && (prefix.length() > 0)) {
/* 489 */         this.mWriter.writeAttribute(prefix, localName, value);
/*     */       } else {
/* 491 */         this.mWriter.writeAttribute(localName, value);
/*     */       }
/*     */     } catch (IOException ioe) {
/* 494 */       throw new WstxIOException(ioe);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void doWriteNamespace(String prefix, String nsURI)
/*     */     throws XMLStreamException
/*     */   {
/* 501 */     int vlen = nsURI.length();
/*     */     
/* 503 */     if (vlen >= 12) {
/* 504 */       char[] buf = this.mCopyBuffer;
/* 505 */       if (buf == null) {
/* 506 */         this.mCopyBuffer = (buf = this.mConfig.allocMediumCBuffer(512));
/*     */       }
/*     */       
/* 509 */       if (vlen <= buf.length) {
/* 510 */         nsURI.getChars(0, vlen, buf, 0);
/*     */         try {
/* 512 */           this.mWriter.writeAttribute("xmlns", prefix, buf, 0, vlen);
/*     */         } catch (IOException ioe) {
/* 514 */           throw new WstxIOException(ioe);
/*     */         }
/* 516 */         return;
/*     */       }
/*     */     }
/*     */     try {
/* 520 */       this.mWriter.writeAttribute("xmlns", prefix, nsURI);
/*     */     } catch (IOException ioe) {
/* 522 */       throw new WstxIOException(ioe);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void doWriteDefaultNs(String nsURI)
/*     */     throws XMLStreamException
/*     */   {
/* 529 */     int vlen = nsURI == null ? 0 : nsURI.length();
/*     */     
/* 531 */     if (vlen >= 12) {
/* 532 */       char[] buf = this.mCopyBuffer;
/* 533 */       if (buf == null) {
/* 534 */         this.mCopyBuffer = (buf = this.mConfig.allocMediumCBuffer(512));
/*     */       }
/*     */       
/* 537 */       if (vlen <= buf.length) {
/* 538 */         nsURI.getChars(0, vlen, buf, 0);
/*     */         try {
/* 540 */           this.mWriter.writeAttribute("xmlns", buf, 0, vlen);
/*     */         } catch (IOException ioe) {
/* 542 */           throw new WstxIOException(ioe);
/*     */         }
/* 544 */         return;
/*     */       }
/*     */     }
/*     */     try {
/* 548 */       this.mWriter.writeAttribute("xmlns", nsURI);
/*     */     } catch (IOException ioe) {
/* 550 */       throw new WstxIOException(ioe);
/*     */     }
/*     */   }
/*     */   
/*     */   protected final void doWriteStartTag(String localName)
/*     */     throws XMLStreamException
/*     */   {
/* 557 */     this.mAnyOutput = true;
/* 558 */     this.mStartElementOpen = true;
/*     */     try {
/* 560 */       this.mWriter.writeStartTagStart(localName);
/*     */     } catch (IOException ioe) {
/* 562 */       throw new WstxIOException(ioe);
/*     */     }
/*     */   }
/*     */   
/*     */   protected final void doWriteStartTag(String prefix, String localName)
/*     */     throws XMLStreamException
/*     */   {
/* 569 */     this.mAnyOutput = true;
/* 570 */     this.mStartElementOpen = true;
/*     */     try {
/* 572 */       boolean hasPrefix = (prefix != null) && (prefix.length() > 0);
/* 573 */       if (hasPrefix) {
/* 574 */         this.mWriter.writeStartTagStart(prefix, localName);
/*     */       } else {
/* 576 */         this.mWriter.writeStartTagStart(localName);
/*     */       }
/*     */     } catch (IOException ioe) {
/* 579 */       throw new WstxIOException(ioe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doWriteEndTag(QName expName, boolean allowEmpty)
/*     */     throws XMLStreamException
/*     */   {
/* 598 */     if ((this.mStartElementOpen) && (this.mEmptyElement)) {
/* 599 */       this.mEmptyElement = false;
/* 600 */       closeStartElement(true);
/*     */     }
/*     */     
/*     */ 
/* 604 */     if (this.mState != 2)
/*     */     {
/* 606 */       reportNwfStructure("No open start element, when trying to write end element");
/*     */     }
/*     */     
/* 609 */     SimpleOutputElement thisElem = this.mCurrElem;
/* 610 */     String prefix = thisElem.getPrefix();
/* 611 */     String localName = thisElem.getLocalName();
/* 612 */     String nsURI = thisElem.getNamespaceURI();
/*     */     
/*     */ 
/* 615 */     this.mCurrElem = thisElem.getParent();
/*     */     
/* 617 */     if (this.mPoolSize < 8) {
/* 618 */       thisElem.addToPool(this.mOutputElemPool);
/* 619 */       this.mOutputElemPool = thisElem;
/* 620 */       this.mPoolSize += 1;
/*     */     }
/*     */     
/* 623 */     if ((this.mCheckStructure) && 
/* 624 */       (expName != null))
/*     */     {
/* 626 */       if (!localName.equals(expName.getLocalPart()))
/*     */       {
/*     */ 
/*     */ 
/* 630 */         reportNwfStructure("Mismatching close element local name, '" + localName + "'; expected '" + expName.getLocalPart() + "'.");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 638 */     if (this.mStartElementOpen)
/*     */     {
/*     */ 
/*     */ 
/* 642 */       if (this.mValidator != null)
/*     */       {
/*     */ 
/*     */ 
/* 646 */         this.mVldContent = this.mValidator.validateElementAndAttributes();
/*     */       }
/* 648 */       this.mStartElementOpen = false;
/*     */       try
/*     */       {
/* 651 */         if (allowEmpty) {
/* 652 */           this.mWriter.writeStartTagEmptyEnd();
/* 653 */           if (this.mCurrElem.isRoot()) {
/* 654 */             this.mState = 3;
/*     */           }
/* 656 */           if (this.mValidator != null) {
/* 657 */             this.mVldContent = this.mValidator.validateElementEnd(localName, nsURI, prefix);
/*     */           }
/* 659 */           return;
/*     */         }
/*     */         
/* 662 */         this.mWriter.writeStartTagEnd();
/*     */       } catch (IOException ioe) {
/* 664 */         throw new WstxIOException(ioe);
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 669 */       this.mWriter.writeEndTag(prefix, localName);
/*     */     } catch (IOException ioe) {
/* 671 */       throw new WstxIOException(ioe);
/*     */     }
/*     */     
/* 674 */     if (this.mCurrElem.isRoot()) {
/* 675 */       this.mState = 3;
/*     */     }
/*     */     
/*     */ 
/* 679 */     if (this.mValidator != null) {
/* 680 */       this.mVldContent = this.mValidator.validateElementEnd(localName, nsURI, prefix);
/*     */     }
/*     */   }
/*     */   
/*     */   public abstract void doSetPrefix(String paramString1, String paramString2)
/*     */     throws XMLStreamException;
/*     */   
/*     */   public abstract void writeDefaultNamespace(String paramString)
/*     */     throws XMLStreamException;
/*     */   
/*     */   public abstract void writeNamespace(String paramString1, String paramString2)
/*     */     throws XMLStreamException;
/*     */   
/*     */   public abstract void writeStartElement(StartElement paramStartElement)
/*     */     throws XMLStreamException;
/*     */   
/*     */   protected abstract void writeStartOrEmpty(String paramString1, String paramString2)
/*     */     throws XMLStreamException;
/*     */   
/*     */   protected abstract void writeStartOrEmpty(String paramString1, String paramString2, String paramString3)
/*     */     throws XMLStreamException;
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sw\BaseNsStreamWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */