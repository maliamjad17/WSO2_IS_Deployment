/*     */ package com.ctc.wstx.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UTFTextWriter
/*     */   extends WriterBase
/*     */ {
/*     */   private final boolean mEscapeCR;
/*  22 */   private boolean mJustWroteBracket = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UTFTextWriter(Writer out, String enc, boolean escapeCR)
/*     */   {
/*  33 */     super(out);
/*  34 */     this.mEscapeCR = escapeCR;
/*     */   }
/*     */   
/*     */   public void write(int c) throws IOException
/*     */   {
/*  39 */     if (c <= 62) {
/*  40 */       switch (c) {
/*     */       case 60: 
/*  42 */         this.out.write("&lt;");
/*  43 */         break;
/*     */       case 38: 
/*  45 */         this.out.write("&amp;");
/*  46 */         break;
/*     */       case 62: 
/*  48 */         if (this.mJustWroteBracket) {
/*  49 */           this.out.write("&gt;");
/*     */         } else {
/*  51 */           this.out.write(c);
/*     */         }
/*  53 */         break;
/*     */       case 13: 
/*  55 */         if (this.mEscapeCR) {
/*  56 */           this.out.write("&#13;");
/*     */         } else {
/*  58 */           this.out.write(c);
/*     */         }
/*  60 */         break;
/*     */       default: 
/*  62 */         this.out.write(c);
/*     */       }
/*  64 */       this.mJustWroteBracket = false;
/*     */     } else {
/*  66 */       this.out.write(c);
/*  67 */       this.mJustWroteBracket = (c == 93);
/*     */     }
/*     */   }
/*     */   
/*     */   public void write(char[] cbuf, int offset, int len)
/*     */     throws IOException
/*     */   {
/*  74 */     if (len < 2) {
/*  75 */       if (len == 1) {
/*  76 */         write(cbuf[offset]);
/*     */       }
/*  78 */       return;
/*     */     }
/*     */     
/*  81 */     char c = '\000';
/*  82 */     len += offset;
/*     */     
/*  84 */     if (this.mJustWroteBracket) {
/*  85 */       c = cbuf[offset];
/*  86 */       if (c == '>') {
/*  87 */         this.out.write("&gt;");
/*  88 */         offset++;
/*     */       }
/*     */     }
/*     */     do
/*     */     {
/*  93 */       int start = offset;
/*  94 */       String ent = null;
/*  96 */       for (; 
/*  96 */           offset < len; offset++) {
/*  97 */         c = cbuf[offset];
/*  98 */         if (c <= '>')
/*     */         {
/*     */ 
/* 101 */           if (c == '<') {
/* 102 */             ent = "&lt;"; break; }
/* 103 */           if (c == '&') {
/* 104 */             ent = "&amp;"; break; }
/* 105 */           if (c == '\r') {
/* 106 */             if (this.mEscapeCR)
/*     */             {
/*     */ 
/* 109 */               ent = "&#13;"; break;
/* 110 */             } } else if ((c == '>') && (offset > start) && (cbuf[(offset - 1)] == ']'))
/*     */           {
/* 112 */             ent = "&gt;"; break;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 118 */       int outLen = offset - start;
/*     */       
/* 120 */       if (outLen > 0) {
/* 121 */         this.out.write(cbuf, start, outLen);
/*     */       }
/* 123 */       if (ent != null) {
/* 124 */         this.out.write(ent);
/* 125 */         ent = null;
/*     */       }
/* 127 */       offset++; } while (offset < len);
/*     */     
/*     */ 
/* 130 */     this.mJustWroteBracket = (c == ']');
/*     */   }
/*     */   
/*     */   public void write(String str, int offset, int len) throws IOException
/*     */   {
/* 135 */     if (len < 2) {
/* 136 */       if (len == 1) {
/* 137 */         write(str.charAt(offset));
/*     */       }
/* 139 */       return;
/*     */     }
/*     */     
/* 142 */     char c = '\000';
/* 143 */     len += offset;
/*     */     
/* 145 */     if (this.mJustWroteBracket) {
/* 146 */       c = str.charAt(offset);
/* 147 */       if (c == '>') {
/* 148 */         this.out.write("&gt;");
/* 149 */         offset++;
/*     */       }
/*     */     }
/*     */     do
/*     */     {
/* 154 */       int start = offset;
/* 155 */       String ent = null;
/* 157 */       for (; 
/* 157 */           offset < len; offset++) {
/* 158 */         c = str.charAt(offset);
/* 159 */         if (c <= '>')
/*     */         {
/*     */ 
/* 162 */           if (c == '<') {
/* 163 */             ent = "&lt;"; break; }
/* 164 */           if (c == '&') {
/* 165 */             ent = "&amp;"; break; }
/* 166 */           if (c == '\r') {
/* 167 */             if (this.mEscapeCR)
/*     */             {
/*     */ 
/* 170 */               ent = "&#13;"; break;
/* 171 */             } } else if ((c == '>') && (offset > start) && (str.charAt(offset - 1) == ']'))
/*     */           {
/* 173 */             ent = "&gt;"; break;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 179 */       int outLen = offset - start;
/* 180 */       if (outLen > 0) {
/* 181 */         this.out.write(str, start, outLen);
/*     */       }
/* 183 */       if (ent != null) {
/* 184 */         this.out.write(ent);
/* 185 */         ent = null;
/*     */       }
/* 187 */       offset++; } while (offset < len);
/*     */     
/*     */ 
/* 190 */     this.mJustWroteBracket = (c == ']');
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\io\UTFTextWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */