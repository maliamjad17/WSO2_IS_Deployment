/*     */ package com.ctc.wstx.exc;
/*     */ 
/*     */ import com.ctc.wstx.compat.JdkFeatures;
/*     */ import com.ctc.wstx.compat.JdkImpl;
/*     */ import com.ctc.wstx.util.StringUtil;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WstxException
/*     */   extends XMLStreamException
/*     */ {
/*     */   final String mMsg;
/*     */   
/*     */   public WstxException(String msg)
/*     */   {
/*  37 */     super(msg);
/*  38 */     this.mMsg = msg;
/*     */   }
/*     */   
/*     */   public WstxException(Throwable th) {
/*  42 */     super(th.getMessage(), th);
/*  43 */     this.mMsg = th.getMessage();
/*     */     
/*     */ 
/*  46 */     JdkFeatures.getInstance().setInitCause(this, th);
/*     */   }
/*     */   
/*     */   public WstxException(String msg, Location loc) {
/*  50 */     super(msg, loc);
/*  51 */     this.mMsg = msg;
/*     */   }
/*     */   
/*     */   public WstxException(String msg, Location loc, Throwable th) {
/*  55 */     super(msg, loc, th);
/*  56 */     this.mMsg = msg;
/*     */     
/*     */ 
/*  59 */     JdkFeatures.getInstance().setInitCause(this, th);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage()
/*     */   {
/*  70 */     String locMsg = getLocationDesc();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  75 */     if (locMsg == null) {
/*  76 */       return super.getMessage();
/*     */     }
/*  78 */     StringBuffer sb = new StringBuffer(this.mMsg.length() + locMsg.length() + 20);
/*  79 */     sb.append(this.mMsg);
/*  80 */     StringUtil.appendLF(sb);
/*  81 */     sb.append(" at ");
/*  82 */     sb.append(locMsg);
/*  83 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  88 */     return getClass().getName() + ": " + getMessage();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getLocationDesc()
/*     */   {
/*  99 */     Location loc = getLocation();
/* 100 */     return loc == null ? null : loc.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\exc\WstxException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */