/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ import com.ctc.wstx.io.WstxInputData;
/*     */ import com.ctc.wstx.sr.InputProblemReporter;
/*     */ import org.codehaus.stax2.validation.XMLValidationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DTDNmTokensAttr
/*     */   extends DTDAttribute
/*     */ {
/*     */   public DTDNmTokensAttr(NameKey name, DefaultAttrValue defValue, int specIndex, boolean nsAware, boolean xml11)
/*     */   {
/*  30 */     super(name, defValue, specIndex, nsAware, xml11);
/*     */   }
/*     */   
/*     */   public DTDAttribute cloneWith(int specIndex)
/*     */   {
/*  35 */     return new DTDNmTokensAttr(this.mName, this.mDefValue, specIndex, this.mCfgNsAware, this.mCfgXml11);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getValueType()
/*     */   {
/*  45 */     return 9;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validate(DTDValidatorBase v, char[] cbuf, int start, int end, boolean normalize)
/*     */     throws XMLValidationException
/*     */   {
/*  62 */     int origStart = start;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  67 */     while ((start < end) && (WstxInputData.isSpaceChar(cbuf[start]))) {
/*  68 */       start++;
/*     */     }
/*     */     
/*  71 */     if (start >= end) {
/*  72 */       return reportValidationProblem(v, "Empty NMTOKENS value");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  78 */     if (!normalize) {
/*  79 */       for (; start < end; start++) {
/*  80 */         char c = cbuf[start];
/*  81 */         if ((!WstxInputData.isSpaceChar(c)) && (!WstxInputData.isNameChar(c, this.mCfgNsAware, this.mCfgXml11)))
/*     */         {
/*  83 */           return reportInvalidChar(v, c, "not valid as NMTOKENS character");
/*     */         }
/*     */       }
/*  86 */       return null;
/*     */     }
/*     */     
/*  89 */     boolean trimmed = origStart != start;
/*     */     
/*     */ 
/*  92 */     end--;
/*     */     
/*  94 */     while ((end > start) && (WstxInputData.isSpaceChar(cbuf[end]))) {
/*  95 */       end--;
/*  96 */       trimmed = true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 102 */     StringBuffer sb = null;
/* 104 */     for (; 
/* 104 */         start <= end; 
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 126 */         goto 253)
/*     */     {
/* 105 */       for (int i = start; 
/* 106 */           i <= end; i++) {
/* 107 */         char c = cbuf[i];
/* 108 */         if (WstxInputData.isSpaceChar(c)) {
/*     */           break;
/*     */         }
/* 111 */         if (!WstxInputData.isNameChar(c, this.mCfgNsAware, this.mCfgXml11)) {
/* 112 */           return reportInvalidChar(v, c, "not valid as an NMTOKENS character");
/*     */         }
/*     */       }
/*     */       
/* 116 */       if (sb == null) {
/* 117 */         sb = new StringBuffer(end - start + 1);
/*     */       } else {
/* 119 */         sb.append(' ');
/*     */       }
/* 121 */       sb.append(cbuf, start, i - start);
/*     */       
/* 123 */       start = i + 1;
/*     */       
/* 125 */       if ((start <= end) && (WstxInputData.isSpaceChar(cbuf[start]))) {
/* 126 */         start++;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 134 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validateDefault(InputProblemReporter rep, boolean normalize)
/*     */     throws XMLValidationException
/*     */   {
/* 145 */     String defValue = this.mDefValue.getValue();
/* 146 */     int len = defValue.length();
/*     */     
/*     */ 
/* 149 */     StringBuffer sb = null;
/* 150 */     int count = 0;
/* 151 */     int start = 0;
/*     */     
/*     */ 
/* 154 */     while (start < len) {
/* 155 */       char c = defValue.charAt(start);
/*     */       
/*     */ 
/*     */ 
/* 159 */       while (WstxInputData.isSpaceChar(c))
/*     */       {
/*     */ 
/* 162 */         start++; if (start >= len) {
/*     */           break label252;
/*     */         }
/* 165 */         c = defValue.charAt(start);
/*     */       }
/*     */       
/* 168 */       int i = start + 1;
/*     */       do
/*     */       {
/* 171 */         i++; if (i >= len) {
/*     */           break;
/*     */         }
/* 174 */         c = defValue.charAt(i);
/* 175 */       } while (!WstxInputData.isSpaceChar(c));
/* 176 */       count++;
/* 177 */       String token = defValue.substring(start, i);
/* 178 */       int illegalIx = WstxInputData.findIllegalNmtokenChar(token, this.mCfgNsAware, this.mCfgXml11);
/* 179 */       if (illegalIx >= 0) {
/* 180 */         reportValidationProblem(rep, "Invalid default value '" + defValue + "'; character #" + illegalIx + " (" + WstxInputData.getCharDesc(defValue.charAt(illegalIx)) + ") not a valid NMTOKENS character");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 186 */       if (normalize) {
/* 187 */         if (sb == null) {
/* 188 */           sb = new StringBuffer(i - start + 32);
/*     */         } else {
/* 190 */           sb.append(' ');
/*     */         }
/* 192 */         sb.append(token);
/*     */       }
/* 194 */       start = i + 1;
/*     */     }
/*     */     label252:
/* 197 */     if (count == 0) {
/* 198 */       reportValidationProblem(rep, "Invalid default value '" + defValue + "'; empty String is not a valid NMTOKENS value");
/*     */       
/* 200 */       return;
/*     */     }
/*     */     
/* 203 */     if (normalize) {
/* 204 */       this.mDefValue.setValue(sb.toString());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\DTDNmTokensAttr.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */