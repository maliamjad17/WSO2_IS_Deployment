/*     */ package com.ctc.wstx.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SingleByteTextWriter
/*     */   extends WriterBase
/*     */ {
/*     */   private final char mHighChar;
/*  24 */   private boolean mJustWroteBracket = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SingleByteTextWriter(Writer out, String enc, int charsetSize)
/*     */   {
/*  36 */     super(out);
/*  37 */     this.mHighChar = ((char)charsetSize);
/*     */   }
/*     */   
/*     */   public void write(int c)
/*     */     throws IOException
/*     */   {
/*  43 */     if (c <= 62) {
/*  44 */       if (c == 60) {
/*  45 */         this.out.write("&lt;");
/*  46 */       } else if (c == 38) {
/*  47 */         this.out.write("&amp;");
/*  48 */       } else if (c == 62) {
/*  49 */         if (this.mJustWroteBracket) {
/*  50 */           this.out.write("&gt;");
/*     */         } else {
/*  52 */           this.out.write(c);
/*     */         }
/*     */       } else {
/*  55 */         this.out.write(c);
/*     */       }
/*  57 */       this.mJustWroteBracket = false;
/*  58 */     } else if (c >= this.mHighChar) {
/*  59 */       writeAsEntity(c);
/*     */     } else {
/*  61 */       this.out.write(c);
/*  62 */       this.mJustWroteBracket = (c == 93);
/*     */     }
/*     */   }
/*     */   
/*     */   public void write(char[] cbuf, int offset, int len)
/*     */     throws IOException
/*     */   {
/*  69 */     if (len < 2) {
/*  70 */       if (len == 1) {
/*  71 */         write(cbuf[offset]);
/*     */       }
/*  73 */       return;
/*     */     }
/*     */     
/*  76 */     len += offset;
/*     */     
/*  78 */     if ((this.mJustWroteBracket) && 
/*  79 */       (cbuf[offset] == '>')) {
/*  80 */       this.out.write("&gt;");
/*  81 */       offset++;
/*     */     }
/*     */     
/*     */ 
/*  85 */     char c = '\000';
/*     */     do {
/*  87 */       int start = offset;
/*  88 */       String ent = null;
/*  90 */       for (; 
/*  90 */           offset < len; offset++) {
/*  91 */         c = cbuf[offset];
/*  92 */         if (c <= '>') {
/*  93 */           if (c == '<') {
/*  94 */             ent = "&lt;";
/*  95 */             break; }
/*  96 */           if (c == '&') {
/*  97 */             ent = "&amp;";
/*  98 */             break; }
/*  99 */           if ((c == '>') && (offset > start) && (cbuf[(offset - 1)] == ']'))
/*     */           {
/* 101 */             ent = "&gt;";
/* 102 */             break; }
/* 103 */           if (c == 0) {
/* 104 */             throwNullChar();
/*     */           }
/*     */         } else {
/* 107 */           if (c >= this.mHighChar) {
/*     */             break;
/*     */           }
/*     */         }
/*     */       }
/* 112 */       int outLen = offset - start;
/*     */       
/* 114 */       if (outLen > 0) {
/* 115 */         this.out.write(cbuf, start, outLen);
/*     */       }
/* 117 */       if (ent != null) {
/* 118 */         this.out.write(ent);
/* 119 */         ent = null;
/* 120 */       } else if (offset < len) {
/* 121 */         writeAsEntity(c);
/*     */       }
/* 123 */       offset++; } while (offset < len);
/*     */     
/*     */ 
/* 126 */     this.mJustWroteBracket = (c == ']');
/*     */   }
/*     */   
/*     */   public void write(String str, int offset, int len) throws IOException
/*     */   {
/* 131 */     if (len < 2) {
/* 132 */       if (len == 1) {
/* 133 */         write(str.charAt(offset));
/*     */       }
/* 135 */       return;
/*     */     }
/*     */     
/* 138 */     len += offset;
/*     */     
/* 140 */     if ((this.mJustWroteBracket) && 
/* 141 */       (str.charAt(offset) == '>')) {
/* 142 */       this.out.write("&gt;");
/* 143 */       offset++;
/*     */     }
/*     */     
/*     */ 
/* 147 */     char c = '\000';
/*     */     do {
/* 149 */       int start = offset;
/* 150 */       String ent = null;
/* 152 */       for (; 
/* 152 */           offset < len; offset++) {
/* 153 */         c = str.charAt(offset);
/* 154 */         if (c <= '>') {
/* 155 */           if (c == '<') {
/* 156 */             ent = "&lt;";
/* 157 */             break; }
/* 158 */           if (c == '&') {
/* 159 */             ent = "&amp;";
/* 160 */             break; }
/* 161 */           if ((c == '>') && (offset > start) && (str.charAt(offset - 1) == ']'))
/*     */           {
/* 163 */             ent = "&gt;";
/* 164 */             break;
/*     */           }
/*     */         } else {
/* 167 */           if (c >= this.mHighChar) {
/*     */             break;
/*     */           }
/*     */         }
/*     */       }
/* 172 */       int outLen = offset - start;
/* 173 */       if (outLen > 0) {
/* 174 */         this.out.write(str, start, outLen);
/*     */       }
/* 176 */       if (ent != null) {
/* 177 */         this.out.write(ent);
/* 178 */         ent = null;
/* 179 */       } else if (offset < len) {
/* 180 */         writeAsEntity(c);
/*     */       }
/* 182 */       offset++; } while (offset < len);
/*     */     
/*     */ 
/* 185 */     this.mJustWroteBracket = (c == ']');
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\io\SingleByteTextWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */