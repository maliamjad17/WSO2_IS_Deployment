/*     */ package com.ctc.wstx.evt;
/*     */ 
/*     */ import com.ctc.wstx.cfg.ErrorConsts;
/*     */ import com.ctc.wstx.dtd.DTDSubset;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import org.codehaus.stax2.XMLStreamWriter2;
/*     */ import org.codehaus.stax2.evt.DTD2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WDTD
/*     */   extends WEvent
/*     */   implements DTD2
/*     */ {
/*     */   final String mRootName;
/*     */   final String mSystemId;
/*     */   final String mPublicId;
/*     */   final String mInternalSubset;
/*     */   final DTDSubset mDTD;
/*  51 */   List mEntities = null;
/*     */   
/*  53 */   List mNotations = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  61 */   String mFullText = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WDTD(Location loc, String rootName, String sysId, String pubId, String intSubset, DTDSubset dtd)
/*     */   {
/*  73 */     super(loc);
/*  74 */     this.mDTD = dtd;
/*  75 */     this.mRootName = rootName;
/*  76 */     this.mSystemId = sysId;
/*  77 */     this.mPublicId = pubId;
/*  78 */     this.mInternalSubset = intSubset;
/*  79 */     this.mFullText = null;
/*     */   }
/*     */   
/*     */ 
/*     */   public WDTD(Location loc, String rootName, String sysId, String pubId, String intSubset)
/*     */   {
/*  85 */     this(loc, rootName, sysId, pubId, intSubset, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public WDTD(Location loc, String rootName, String intSubset)
/*     */   {
/*  93 */     this(loc, rootName, null, null, intSubset, null);
/*     */   }
/*     */   
/*     */   public WDTD(Location loc, String fullText)
/*     */   {
/*  98 */     this(loc, null, null, null, null, null);
/*  99 */     this.mFullText = fullText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDocumentTypeDeclaration()
/*     */   {
/* 110 */     if (this.mFullText == null) {
/* 111 */       int len = 60;
/* 112 */       if (this.mInternalSubset != null) {
/* 113 */         len += this.mInternalSubset.length() + 4;
/*     */       }
/* 115 */       StringWriter sw = new StringWriter(len);
/*     */       try {
/* 117 */         writeAsEncodedUnicode(sw);
/*     */       } catch (XMLStreamException sex) {
/* 119 */         throw new Error(ErrorConsts.ERR_INTERNAL + ": " + sex);
/*     */       }
/* 121 */       this.mFullText = sw.toString();
/*     */     }
/* 123 */     return this.mFullText;
/*     */   }
/*     */   
/*     */   public List getEntities()
/*     */   {
/* 128 */     if ((this.mEntities == null) && (this.mDTD != null))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 133 */       this.mEntities = new ArrayList(this.mDTD.getGeneralEntityList());
/*     */     }
/* 135 */     return this.mEntities;
/*     */   }
/*     */   
/*     */   public List getNotations() {
/* 139 */     if ((this.mNotations == null) && (this.mDTD != null)) {
/* 140 */       this.mNotations = new ArrayList(this.mDTD.getNotationList());
/*     */     }
/* 142 */     return this.mNotations;
/*     */   }
/*     */   
/*     */   public Object getProcessedDTD() {
/* 146 */     return this.mDTD;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getEventType()
/*     */   {
/* 156 */     return 11;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void writeAsEncodedUnicode(Writer w)
/*     */     throws XMLStreamException
/*     */   {
/*     */     try
/*     */     {
/* 166 */       if (this.mFullText != null) {
/* 167 */         w.write(this.mFullText);
/* 168 */         return;
/*     */       }
/*     */       
/* 171 */       w.write("<!DOCTYPE");
/* 172 */       if (this.mRootName != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 178 */         w.write(32);
/* 179 */         w.write(this.mRootName);
/*     */       }
/* 181 */       if (this.mSystemId != null) {
/* 182 */         if (this.mPublicId != null) {
/* 183 */           w.write(" PUBLIC \"");
/* 184 */           w.write(this.mPublicId);
/* 185 */           w.write(34);
/*     */         } else {
/* 187 */           w.write(" SYSTEM");
/*     */         }
/* 189 */         w.write(" \"");
/* 190 */         w.write(this.mSystemId);
/* 191 */         w.write(34);
/*     */       }
/* 193 */       if (this.mInternalSubset != null) {
/* 194 */         w.write(" [");
/* 195 */         w.write(this.mInternalSubset);
/* 196 */         w.write(93);
/*     */       }
/* 198 */       w.write(">");
/*     */     } catch (IOException ie) {
/* 200 */       throwFromIOE(ie);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void writeUsing(XMLStreamWriter w)
/*     */     throws XMLStreamException
/*     */   {
/* 209 */     if ((w instanceof XMLStreamWriter2))
/*     */     {
/*     */ 
/*     */ 
/* 213 */       if (this.mRootName != null) {
/* 214 */         XMLStreamWriter2 sw2 = (XMLStreamWriter2)w;
/* 215 */         sw2.writeDTD(this.mRootName, this.mSystemId, this.mPublicId, this.mInternalSubset);
/* 216 */         return;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 221 */     w.writeDTD(getDocumentTypeDeclaration());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRootName()
/*     */   {
/* 231 */     return this.mRootName;
/*     */   }
/*     */   
/*     */   public String getSystemId() {
/* 235 */     return this.mSystemId;
/*     */   }
/*     */   
/*     */   public String getPublicId() {
/* 239 */     return this.mPublicId;
/*     */   }
/*     */   
/*     */   public String getInternalSubset() {
/* 243 */     return this.mInternalSubset;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\evt\WDTD.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */