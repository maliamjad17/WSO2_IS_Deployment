/*    */ package com.ctc.wstx.dtd;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ContentSpec
/*    */ {
/*    */   protected char mArity;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ContentSpec(char arity)
/*    */   {
/* 38 */     this.mArity = arity;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 47 */   public final char getArity() { return this.mArity; }
/*    */   
/* 49 */   public final void setArity(char c) { this.mArity = c; }
/*    */   
/* 51 */   public boolean isLeaf() { return false; }
/*    */   
/*    */   public abstract StructValidator getSimpleValidator();
/*    */   
/*    */   public abstract ModelNode rewrite();
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\ContentSpec.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */