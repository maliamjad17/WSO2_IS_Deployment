/*      */ package com.ctc.wstx.api;
/*      */ 
/*      */ import com.ctc.wstx.cfg.InputConfigFlags;
/*      */ import com.ctc.wstx.compat.JdkFeatures;
/*      */ import com.ctc.wstx.compat.JdkImpl;
/*      */ import com.ctc.wstx.dtd.DTDEventListener;
/*      */ import com.ctc.wstx.ent.EntityDecl;
/*      */ import com.ctc.wstx.ent.IntEntity;
/*      */ import com.ctc.wstx.io.BufferRecycler;
/*      */ import com.ctc.wstx.util.ArgUtil;
/*      */ import com.ctc.wstx.util.EmptyIterator;
/*      */ import com.ctc.wstx.util.SymbolTable;
/*      */ import java.lang.ref.SoftReference;
/*      */ import java.net.URL;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import javax.xml.stream.XMLReporter;
/*      */ import javax.xml.stream.XMLResolver;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ReaderConfig
/*      */   extends CommonConfig
/*      */   implements InputConfigFlags
/*      */ {
/*      */   static final int PROP_COALESCE_TEXT = 1;
/*      */   static final int PROP_NAMESPACE_AWARE = 2;
/*      */   static final int PROP_REPLACE_ENTITY_REFS = 3;
/*      */   static final int PROP_SUPPORT_EXTERNAL_ENTITIES = 4;
/*      */   static final int PROP_VALIDATE_AGAINST_DTD = 5;
/*      */   static final int PROP_SUPPORT_DTD = 6;
/*      */   public static final int PROP_EVENT_ALLOCATOR = 7;
/*      */   static final int PROP_WARNING_REPORTER = 8;
/*      */   static final int PROP_XML_RESOLVER = 9;
/*      */   static final int PROP_INTERN_NS_URIS = 20;
/*      */   static final int PROP_INTERN_NAMES = 21;
/*      */   static final int PROP_REPORT_CDATA = 22;
/*      */   static final int PROP_REPORT_PROLOG_WS = 23;
/*      */   static final int PROP_PRESERVE_LOCATION = 24;
/*      */   static final int PROP_AUTO_CLOSE_INPUT = 25;
/*      */   static final int PROP_SUPPORT_XMLID = 26;
/*      */   static final int PROP_NORMALIZE_LFS = 40;
/*      */   static final int PROP_NORMALIZE_ATTR_VALUES = 41;
/*      */   static final int PROP_CACHE_DTDS = 42;
/*      */   static final int PROP_CACHE_DTDS_BY_PUBLIC_ID = 43;
/*      */   static final int PROP_LAZY_PARSING = 44;
/*      */   static final int PROP_SUPPORT_DTDPP = 45;
/*      */   static final int PROP_INPUT_BUFFER_LENGTH = 50;
/*      */   static final int PROP_MIN_TEXT_SEGMENT = 52;
/*      */   static final int PROP_CUSTOM_INTERNAL_ENTITIES = 53;
/*      */   static final int PROP_DTD_RESOLVER = 54;
/*      */   static final int PROP_ENTITY_RESOLVER = 55;
/*      */   static final int PROP_UNDECLARED_ENTITY_RESOLVER = 56;
/*      */   static final int PROP_BASE_URL = 57;
/*      */   static final int PROP_INPUT_PARSING_MODE = 58;
/*      */   static final int MIN_INPUT_BUFFER_LENGTH = 8;
/*      */   static final int DTD_CACHE_SIZE_J2SE = 12;
/*      */   static final int DTD_CACHE_SIZE_J2ME = 5;
/*      */   static final int DEFAULT_SHORTEST_TEXT_SEGMENT = 64;
/*      */   static final int DEFAULT_FLAGS_FULL = 2977567;
/*      */   static final int DEFAULT_FLAGS_J2ME = 2977567;
/*  207 */   static final HashMap sProperties = new HashMap(64);
/*      */   final boolean mIsJ2MESubset;
/*      */   
/*  210 */   static { sProperties.put("javax.xml.stream.isCoalescing", new Integer(1));
/*      */     
/*  212 */     sProperties.put("javax.xml.stream.isNamespaceAware", new Integer(2));
/*      */     
/*  214 */     sProperties.put("javax.xml.stream.isReplacingEntityReferences", new Integer(3));
/*      */     
/*  216 */     sProperties.put("javax.xml.stream.isSupportingExternalEntities", new Integer(4));
/*      */     
/*  218 */     sProperties.put("javax.xml.stream.isValidating", new Integer(5));
/*      */     
/*  220 */     sProperties.put("javax.xml.stream.supportDTD", new Integer(6));
/*      */     
/*      */ 
/*      */ 
/*  224 */     sProperties.put("javax.xml.stream.allocator", new Integer(7));
/*      */     
/*  226 */     sProperties.put("javax.xml.stream.reporter", new Integer(8));
/*      */     
/*  228 */     sProperties.put("javax.xml.stream.resolver", new Integer(9));
/*      */     
/*      */ 
/*      */ 
/*  232 */     sProperties.put("org.codehaus.stax2.internNames", new Integer(21));
/*      */     
/*  234 */     sProperties.put("org.codehaus.stax2.internNsUris", new Integer(20));
/*      */     
/*  236 */     sProperties.put("http://java.sun.com/xml/stream/properties/report-cdata-event", new Integer(22));
/*      */     
/*  238 */     sProperties.put("org.codehaus.stax2.reportPrologWhitespace", new Integer(23));
/*      */     
/*  240 */     sProperties.put("org.codehaus.stax2.preserveLocation", new Integer(24));
/*      */     
/*  242 */     sProperties.put("org.codehaus.stax2.closeInputSource", new Integer(25));
/*      */     
/*  244 */     sProperties.put("org.codehaus.stax2.supportXmlId", new Integer(26));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  249 */     sProperties.put("com.ctc.wstx.normalizeLFs", new Integer(40));
/*      */     
/*  251 */     sProperties.put("com.ctc.wstx.normalizeAttrValues", new Integer(41));
/*      */     
/*  253 */     sProperties.put("com.ctc.wstx.cacheDTDs", new Integer(42));
/*      */     
/*  255 */     sProperties.put("com.ctc.wstx.cacheDTDsByPublicId", new Integer(43));
/*      */     
/*  257 */     sProperties.put("com.ctc.wstx.lazyParsing", new Integer(44));
/*      */     
/*  259 */     sProperties.put("com.ctc.wstx.supportDTDPP", new Integer(45));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  264 */     sProperties.put("com.ctc.wstx.inputBufferLength", new Integer(50));
/*      */     
/*  266 */     sProperties.put("com.ctc.wstx.minTextSegment", new Integer(52));
/*      */     
/*  268 */     sProperties.put("com.ctc.wstx.customInternalEntities", new Integer(53));
/*      */     
/*  270 */     sProperties.put("com.ctc.wstx.dtdResolver", new Integer(54));
/*      */     
/*  272 */     sProperties.put("com.ctc.wstx.entityResolver", new Integer(55));
/*      */     
/*  274 */     sProperties.put("com.ctc.wstx.undeclaredEntityResolver", new Integer(56));
/*      */     
/*  276 */     sProperties.put("com.ctc.wstx.baseURL", new Integer(57));
/*      */     
/*  278 */     sProperties.put("com.ctc.wstx.fragmentMode", new Integer(58));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final SymbolTable mSymbols;
/*      */   
/*      */ 
/*      */ 
/*      */   int mConfigFlags;
/*      */   
/*      */ 
/*      */ 
/*      */   int mInputBufferLen;
/*      */   
/*      */ 
/*      */ 
/*      */   int mMinTextSegmentLen;
/*      */   
/*      */ 
/*      */ 
/*  301 */   URL mBaseURL = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  308 */   WstxInputProperties.ParsingMode mParsingMode = WstxInputProperties.PARSING_MODE_DOCUMENT;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  318 */   boolean mXml11 = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   XMLReporter mReporter;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  328 */   XMLResolver mDtdResolver = null;
/*  329 */   XMLResolver mEntityResolver = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  341 */   Object[] mSpecialProperties = null;
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int SPEC_PROC_COUNT = 3;
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int SP_IX_CUSTOM_ENTITIES = 0;
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int SP_IX_UNDECL_ENT_RESOLVER = 1;
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int SP_IX_DTD_EVENT_LISTENER = 2;
/*      */   
/*      */ 
/*  360 */   static final ThreadLocal mRecyclerRef = new ThreadLocal();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  368 */   BufferRecycler mCurrRecycler = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ReaderConfig(boolean j2meSubset, SymbolTable symbols, int configFlags, int inputBufLen, int minTextSegmentLen)
/*      */   {
/*  381 */     this.mIsJ2MESubset = j2meSubset;
/*  382 */     this.mSymbols = symbols;
/*      */     
/*  384 */     this.mConfigFlags = configFlags;
/*      */     
/*  386 */     this.mInputBufferLen = inputBufLen;
/*  387 */     this.mMinTextSegmentLen = minTextSegmentLen;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  395 */     SoftReference ref = (SoftReference)mRecyclerRef.get();
/*  396 */     if (ref != null) {
/*  397 */       this.mCurrRecycler = ((BufferRecycler)ref.get());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ReaderConfig createJ2MEDefaults()
/*      */   {
/*  406 */     ReaderConfig rc = new ReaderConfig(true, null, 2977567, 2000, 64);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  411 */     return rc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ReaderConfig createFullDefaults()
/*      */   {
/*  419 */     ReaderConfig rc = new ReaderConfig(false, null, 2977567, 4000, 64);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  424 */     return rc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ReaderConfig createNonShared(SymbolTable sym)
/*      */   {
/*  431 */     ReaderConfig rc = new ReaderConfig(this.mIsJ2MESubset, sym, this.mConfigFlags, this.mInputBufferLen, this.mMinTextSegmentLen);
/*      */     
/*      */ 
/*      */ 
/*  435 */     rc.mReporter = this.mReporter;
/*  436 */     rc.mDtdResolver = this.mDtdResolver;
/*  437 */     rc.mEntityResolver = this.mEntityResolver;
/*  438 */     rc.mBaseURL = this.mBaseURL;
/*  439 */     rc.mParsingMode = this.mParsingMode;
/*  440 */     if (this.mSpecialProperties != null) {
/*  441 */       int len = this.mSpecialProperties.length;
/*  442 */       Object[] specProps = new Object[len];
/*  443 */       System.arraycopy(this.mSpecialProperties, 0, specProps, 0, len);
/*  444 */       rc.mSpecialProperties = specProps;
/*      */     }
/*      */     
/*  447 */     return rc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resetState()
/*      */   {
/*  459 */     this.mXml11 = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int findPropertyId(String propName)
/*      */   {
/*  470 */     Integer I = (Integer)sProperties.get(propName);
/*  471 */     return I == null ? -1 : I.intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SymbolTable getSymbols()
/*      */   {
/*  482 */     return this.mSymbols;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getDtdCacheSize()
/*      */   {
/*  489 */     return this.mIsJ2MESubset ? 5 : 12;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*  494 */   public int getConfigFlags() { return this.mConfigFlags; }
/*      */   
/*  496 */   public boolean hasConfigFlags(int flags) { return (this.mConfigFlags & flags) == flags; }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean willCoalesceText()
/*      */   {
/*  502 */     return hasConfigFlags(2);
/*      */   }
/*      */   
/*      */   public boolean willSupportNamespaces() {
/*  506 */     return hasConfigFlags(1);
/*      */   }
/*      */   
/*      */   public boolean willReplaceEntityRefs() {
/*  510 */     return hasConfigFlags(4);
/*      */   }
/*      */   
/*      */   public boolean willSupportExternalEntities() {
/*  514 */     return hasConfigFlags(8);
/*      */   }
/*      */   
/*      */   public boolean willSupportDTDs() {
/*  518 */     return hasConfigFlags(16);
/*      */   }
/*      */   
/*      */   public boolean willValidateWithDTD() {
/*  522 */     return hasConfigFlags(32);
/*      */   }
/*      */   
/*      */   public boolean willNormalizeLFs()
/*      */   {
/*  527 */     return hasConfigFlags(8192);
/*      */   }
/*      */   
/*      */   public boolean willNormalizeAttrValues() {
/*  531 */     return hasConfigFlags(16384);
/*      */   }
/*      */   
/*      */   public boolean willInternNames()
/*      */   {
/*  536 */     return true;
/*      */   }
/*      */   
/*      */   public boolean willInternNsURIs() {
/*  540 */     return hasConfigFlags(1024);
/*      */   }
/*      */   
/*      */   public boolean willReportCData() {
/*  544 */     return hasConfigFlags(512);
/*      */   }
/*      */   
/*      */   public boolean willReportPrologWhitespace() {
/*  548 */     return hasConfigFlags(256);
/*      */   }
/*      */   
/*      */   public boolean willCacheDTDs() {
/*  552 */     return hasConfigFlags(65536);
/*      */   }
/*      */   
/*      */   public boolean willCacheDTDsByPublicId() {
/*  556 */     return hasConfigFlags(131072);
/*      */   }
/*      */   
/*      */   public boolean willParseLazily() {
/*  560 */     return hasConfigFlags(262144);
/*      */   }
/*      */   
/*      */   public boolean willDoXmlIdTyping() {
/*  564 */     return hasConfigFlags(2097152);
/*      */   }
/*      */   
/*      */   public boolean willDoXmlIdUniqChecks() {
/*  568 */     return hasConfigFlags(4194304);
/*      */   }
/*      */   
/*      */   public boolean willPreserveLocation() {
/*  572 */     return hasConfigFlags(2048);
/*      */   }
/*      */   
/*      */   public boolean willAutoCloseInput() {
/*  576 */     return hasConfigFlags(4096);
/*      */   }
/*      */   
/*      */   public boolean willSupportDTDPP() {
/*  580 */     return hasConfigFlags(524288);
/*      */   }
/*      */   
/*  583 */   public int getInputBufferLength() { return this.mInputBufferLen; }
/*      */   
/*  585 */   public int getShortestReportedTextSegment() { return this.mMinTextSegmentLen; }
/*      */   
/*      */   public Map getCustomInternalEntities()
/*      */   {
/*  589 */     Map custEnt = (Map)getSpecialProperty(0);
/*  590 */     if (custEnt == null) {
/*  591 */       return JdkFeatures.getInstance().getEmptyMap();
/*      */     }
/*      */     
/*  594 */     int len = custEnt.size();
/*  595 */     HashMap m = new HashMap(len + (len >> 2), 0.81F);
/*  596 */     Iterator it = custEnt.entrySet().iterator();
/*  597 */     while (it.hasNext()) {
/*  598 */       Map.Entry me = (Map.Entry)it.next();
/*      */       
/*      */ 
/*      */ 
/*  602 */       m.put(me.getKey(), (EntityDecl)me.getValue());
/*      */     }
/*  604 */     return m;
/*      */   }
/*      */   
/*  607 */   public XMLReporter getXMLReporter() { return this.mReporter; }
/*      */   
/*  609 */   public XMLResolver getXMLResolver() { return this.mEntityResolver; }
/*      */   
/*  611 */   public XMLResolver getDtdResolver() { return this.mDtdResolver; }
/*  612 */   public XMLResolver getEntityResolver() { return this.mEntityResolver; }
/*      */   
/*  614 */   public XMLResolver getUndeclaredEntityResolver() { return (XMLResolver)getSpecialProperty(1); }
/*      */   
/*      */   public URL getBaseURL() {
/*  617 */     return this.mBaseURL;
/*      */   }
/*      */   
/*  620 */   public WstxInputProperties.ParsingMode getInputParsingMode() { return this.mParsingMode; }
/*      */   
/*      */   public boolean inputParsingModeDocuments()
/*      */   {
/*  624 */     return this.mParsingMode == WstxInputProperties.PARSING_MODE_DOCUMENTS;
/*      */   }
/*      */   
/*      */   public boolean inputParsingModeFragment() {
/*  628 */     return this.mParsingMode == WstxInputProperties.PARSING_MODE_FRAGMENT;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isXml11()
/*      */   {
/*  637 */     return this.mXml11;
/*      */   }
/*      */   
/*      */   public DTDEventListener getDTDEventListener() {
/*  641 */     return (DTDEventListener)getSpecialProperty(2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConfigFlags(int flags)
/*      */   {
/*  651 */     this.mConfigFlags = flags;
/*      */   }
/*      */   
/*      */   public void setConfigFlag(int flag) {
/*  655 */     this.mConfigFlags |= flag;
/*      */   }
/*      */   
/*      */   public void clearConfigFlag(int flag) {
/*  659 */     this.mConfigFlags &= (flag ^ 0xFFFFFFFF);
/*      */   }
/*      */   
/*      */ 
/*      */   public void doCoalesceText(boolean state)
/*      */   {
/*  665 */     setConfigFlag(2, state);
/*      */   }
/*      */   
/*      */   public void doSupportNamespaces(boolean state) {
/*  669 */     setConfigFlag(1, state);
/*      */   }
/*      */   
/*      */   public void doReplaceEntityRefs(boolean state) {
/*  673 */     setConfigFlag(4, state);
/*      */   }
/*      */   
/*      */   public void doSupportExternalEntities(boolean state) {
/*  677 */     setConfigFlag(8, state);
/*      */   }
/*      */   
/*      */   public void doSupportDTDs(boolean state) {
/*  681 */     setConfigFlag(16, state);
/*      */   }
/*      */   
/*      */   public void doValidateWithDTD(boolean state) {
/*  685 */     setConfigFlag(32, state);
/*      */   }
/*      */   
/*      */ 
/*      */   public void doNormalizeLFs(boolean state)
/*      */   {
/*  691 */     setConfigFlag(8192, state);
/*      */   }
/*      */   
/*      */   public void doNormalizeAttrValues(boolean state) {
/*  695 */     setConfigFlag(16384, state);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void doInternNsURIs(boolean state)
/*      */   {
/*  703 */     setConfigFlag(1024, state);
/*      */   }
/*      */   
/*      */   public void doReportPrologWhitespace(boolean state) {
/*  707 */     setConfigFlag(256, state);
/*      */   }
/*      */   
/*      */   public void doReportCData(boolean state) {
/*  711 */     setConfigFlag(512, state);
/*      */   }
/*      */   
/*      */   public void doCacheDTDs(boolean state) {
/*  715 */     setConfigFlag(65536, state);
/*      */   }
/*      */   
/*      */   public void doCacheDTDsByPublicId(boolean state) {
/*  719 */     setConfigFlag(131072, state);
/*      */   }
/*      */   
/*      */   public void doParseLazily(boolean state) {
/*  723 */     setConfigFlag(262144, state);
/*      */   }
/*      */   
/*      */   public void doXmlIdTyping(boolean state) {
/*  727 */     setConfigFlag(2097152, state);
/*      */   }
/*      */   
/*      */   public void doXmlIdUniqChecks(boolean state) {
/*  731 */     setConfigFlag(4194304, state);
/*      */   }
/*      */   
/*      */   public void doPreserveLocation(boolean state) {
/*  735 */     setConfigFlag(2048, state);
/*      */   }
/*      */   
/*      */   public void doAutoCloseInput(boolean state) {
/*  739 */     setConfigFlag(4096, state);
/*      */   }
/*      */   
/*      */   public void doSupportDTDPP(boolean state) {
/*  743 */     setConfigFlag(524288, state);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setInputBufferLength(int value)
/*      */   {
/*  751 */     if (value < 8) {
/*  752 */       value = 8;
/*      */     }
/*  754 */     this.mInputBufferLen = value;
/*      */   }
/*      */   
/*      */   public void setShortestReportedTextSegment(int value) {
/*  758 */     this.mMinTextSegmentLen = value;
/*      */   }
/*      */   
/*      */   public void setCustomInternalEntities(Map m) {
/*      */     Map entMap;
/*      */     Map entMap;
/*  764 */     if ((m == null) || (m.size() < 1)) {
/*  765 */       entMap = JdkFeatures.getInstance().getEmptyMap();
/*      */     } else {
/*  767 */       int len = m.size();
/*  768 */       entMap = new HashMap(len + (len >> 1), 0.75F);
/*  769 */       Iterator it = m.entrySet().iterator();
/*  770 */       while (it.hasNext()) {
/*  771 */         Map.Entry me = (Map.Entry)it.next();
/*  772 */         Object val = me.getValue();
/*      */         char[] ch;
/*  774 */         char[] ch; if (val == null) {
/*  775 */           ch = EmptyIterator.getEmptyCharArray(); } else { char[] ch;
/*  776 */           if ((val instanceof char[])) {
/*  777 */             ch = (char[])val;
/*      */           }
/*      */           else {
/*  780 */             String str = val.toString();
/*  781 */             ch = str.toCharArray();
/*      */           } }
/*  783 */         String name = (String)me.getKey();
/*  784 */         entMap.put(name, IntEntity.create(name, ch));
/*      */       }
/*      */     }
/*  787 */     setSpecialProperty(0, entMap);
/*      */   }
/*      */   
/*      */   public void setXMLReporter(XMLReporter r) {
/*  791 */     this.mReporter = r;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setXMLResolver(XMLResolver r)
/*      */   {
/*  799 */     this.mEntityResolver = r;
/*  800 */     this.mDtdResolver = r;
/*      */   }
/*      */   
/*      */   public void setDtdResolver(XMLResolver r) {
/*  804 */     this.mDtdResolver = r;
/*      */   }
/*      */   
/*      */   public void setEntityResolver(XMLResolver r) {
/*  808 */     this.mEntityResolver = r;
/*      */   }
/*      */   
/*      */   public void setUndeclaredEntityResolver(XMLResolver r) {
/*  812 */     setSpecialProperty(1, r);
/*      */   }
/*      */   
/*  815 */   public void setBaseURL(URL baseURL) { this.mBaseURL = baseURL; }
/*      */   
/*      */   public void setInputParsingMode(WstxInputProperties.ParsingMode mode) {
/*  818 */     this.mParsingMode = mode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void enableXml11(boolean state)
/*      */   {
/*  826 */     this.mXml11 = state;
/*      */   }
/*      */   
/*      */   public void setDTDEventListener(DTDEventListener l) {
/*  830 */     setSpecialProperty(2, l);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void configureForXmlConformance()
/*      */   {
/*  867 */     doSupportNamespaces(true);
/*  868 */     doSupportDTDs(true);
/*  869 */     doSupportExternalEntities(true);
/*  870 */     doReplaceEntityRefs(true);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  875 */     doXmlIdTyping(true);
/*  876 */     doXmlIdUniqChecks(true);
/*      */     
/*      */ 
/*  879 */     doNormalizeLFs(true);
/*  880 */     doNormalizeAttrValues(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void configureForConvenience()
/*      */   {
/*  903 */     doCoalesceText(true);
/*  904 */     doReplaceEntityRefs(true);
/*      */     
/*      */ 
/*  907 */     doReportCData(false);
/*  908 */     doReportPrologWhitespace(false);
/*      */     
/*      */ 
/*      */ 
/*  912 */     doPreserveLocation(true);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  919 */     doParseLazily(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void configureForSpeed()
/*      */   {
/*  957 */     doCoalesceText(false);
/*      */     
/*      */ 
/*  960 */     doPreserveLocation(false);
/*  961 */     doReportPrologWhitespace(false);
/*      */     
/*  963 */     doInternNsURIs(true);
/*  964 */     doXmlIdUniqChecks(false);
/*      */     
/*      */ 
/*  967 */     doNormalizeLFs(false);
/*  968 */     doNormalizeAttrValues(false);
/*  969 */     doCacheDTDs(true);
/*  970 */     doParseLazily(true);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  977 */     setShortestReportedTextSegment(16);
/*  978 */     setInputBufferLength(8000);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void configureForLowMemUsage()
/*      */   {
/* 1008 */     doCoalesceText(false);
/*      */     
/*      */ 
/*      */ 
/* 1012 */     doPreserveLocation(false);
/*      */     
/*      */ 
/* 1015 */     doCacheDTDs(false);
/* 1016 */     doParseLazily(true);
/* 1017 */     doXmlIdUniqChecks(false);
/* 1018 */     setShortestReportedTextSegment(64);
/* 1019 */     setInputBufferLength(512);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void configureForRoundTripping()
/*      */   {
/* 1047 */     doCoalesceText(false);
/* 1048 */     doReplaceEntityRefs(false);
/*      */     
/*      */ 
/* 1051 */     doReportCData(true);
/* 1052 */     doReportPrologWhitespace(true);
/*      */     
/*      */ 
/* 1055 */     doNormalizeLFs(false);
/* 1056 */     doNormalizeAttrValues(false);
/*      */     
/* 1058 */     setShortestReportedTextSegment(Integer.MAX_VALUE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public char[] allocSmallCBuffer(int minSize)
/*      */   {
/* 1070 */     if (this.mCurrRecycler != null) {
/* 1071 */       char[] result = this.mCurrRecycler.getSmallCBuffer(minSize);
/* 1072 */       if (result != null) {
/* 1073 */         return result;
/*      */       }
/*      */     }
/*      */     
/* 1077 */     return new char[minSize];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void freeSmallCBuffer(char[] buffer)
/*      */   {
/* 1084 */     if (this.mCurrRecycler == null) {
/* 1085 */       this.mCurrRecycler = createRecycler();
/*      */     }
/* 1087 */     this.mCurrRecycler.returnSmallCBuffer(buffer);
/*      */   }
/*      */   
/*      */ 
/*      */   public char[] allocMediumCBuffer(int minSize)
/*      */   {
/* 1093 */     if (this.mCurrRecycler != null) {
/* 1094 */       char[] result = this.mCurrRecycler.getMediumCBuffer(minSize);
/* 1095 */       if (result != null) {
/* 1096 */         return result;
/*      */       }
/*      */     }
/* 1099 */     return new char[minSize];
/*      */   }
/*      */   
/*      */ 
/*      */   public void freeMediumCBuffer(char[] buffer)
/*      */   {
/* 1105 */     if (this.mCurrRecycler == null) {
/* 1106 */       this.mCurrRecycler = createRecycler();
/*      */     }
/* 1108 */     this.mCurrRecycler.returnMediumCBuffer(buffer);
/*      */   }
/*      */   
/*      */ 
/*      */   public char[] allocFullCBuffer(int minSize)
/*      */   {
/* 1114 */     if (this.mCurrRecycler != null) {
/* 1115 */       char[] result = this.mCurrRecycler.getFullCBuffer(minSize);
/* 1116 */       if (result != null) {
/* 1117 */         return result;
/*      */       }
/*      */     }
/* 1120 */     return new char[minSize];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void freeFullCBuffer(char[] buffer)
/*      */   {
/* 1127 */     if (this.mCurrRecycler == null) {
/* 1128 */       this.mCurrRecycler = createRecycler();
/*      */     }
/* 1130 */     this.mCurrRecycler.returnFullCBuffer(buffer);
/*      */   }
/*      */   
/*      */ 
/*      */   public byte[] allocFullBBuffer(int minSize)
/*      */   {
/* 1136 */     if (this.mCurrRecycler != null) {
/* 1137 */       byte[] result = this.mCurrRecycler.getFullBBuffer(minSize);
/* 1138 */       if (result != null) {
/* 1139 */         return result;
/*      */       }
/*      */     }
/* 1142 */     return new byte[minSize];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void freeFullBBuffer(byte[] buffer)
/*      */   {
/* 1149 */     if (this.mCurrRecycler == null) {
/* 1150 */       this.mCurrRecycler = createRecycler();
/*      */     }
/* 1152 */     this.mCurrRecycler.returnFullBBuffer(buffer);
/*      */   }
/*      */   
/* 1155 */   static int Counter = 0;
/*      */   
/*      */   private BufferRecycler createRecycler()
/*      */   {
/* 1159 */     BufferRecycler recycler = new BufferRecycler();
/*      */     
/*      */ 
/* 1162 */     mRecyclerRef.set(new SoftReference(recycler));
/* 1163 */     return recycler;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void setConfigFlag(int flag, boolean state)
/*      */   {
/* 1173 */     if (state) {
/* 1174 */       this.mConfigFlags |= flag;
/*      */     } else {
/* 1176 */       this.mConfigFlags &= (flag ^ 0xFFFFFFFF);
/*      */     }
/*      */   }
/*      */   
/*      */   public Object getProperty(int id)
/*      */   {
/* 1182 */     switch (id)
/*      */     {
/*      */ 
/*      */     case 1: 
/* 1186 */       return willCoalesceText() ? Boolean.TRUE : Boolean.FALSE;
/*      */     case 2: 
/* 1188 */       return willSupportNamespaces() ? Boolean.TRUE : Boolean.FALSE;
/*      */     case 3: 
/* 1190 */       return willReplaceEntityRefs() ? Boolean.TRUE : Boolean.FALSE;
/*      */     case 4: 
/* 1192 */       return willSupportExternalEntities() ? Boolean.TRUE : Boolean.FALSE;
/*      */     
/*      */     case 5: 
/* 1195 */       return willValidateWithDTD() ? Boolean.TRUE : Boolean.FALSE;
/*      */     case 6: 
/* 1197 */       return willSupportDTDs() ? Boolean.TRUE : Boolean.FALSE;
/*      */     case 8: 
/* 1199 */       return getXMLReporter();
/*      */     case 9: 
/* 1201 */       return getXMLResolver();
/*      */     
/*      */ 
/*      */ 
/*      */     case 7: 
/* 1206 */       return null;
/*      */     
/*      */ 
/*      */ 
/*      */     case 23: 
/* 1211 */       return willReportPrologWhitespace() ? Boolean.TRUE : Boolean.FALSE;
/*      */     case 22: 
/* 1213 */       return willReportCData() ? Boolean.TRUE : Boolean.FALSE;
/*      */     
/*      */     case 21: 
/* 1216 */       return willInternNames() ? Boolean.TRUE : Boolean.FALSE;
/*      */     case 20: 
/* 1218 */       return willInternNsURIs() ? Boolean.TRUE : Boolean.FALSE;
/*      */     
/*      */     case 24: 
/* 1221 */       return willPreserveLocation() ? Boolean.TRUE : Boolean.FALSE;
/*      */     case 25: 
/* 1223 */       return willAutoCloseInput() ? Boolean.TRUE : Boolean.FALSE;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 40: 
/* 1229 */       return willNormalizeLFs() ? Boolean.TRUE : Boolean.FALSE;
/*      */     case 41: 
/* 1231 */       return willNormalizeAttrValues() ? Boolean.TRUE : Boolean.FALSE;
/*      */     case 42: 
/* 1233 */       return willCacheDTDs() ? Boolean.TRUE : Boolean.FALSE;
/*      */     case 43: 
/* 1235 */       return willCacheDTDsByPublicId() ? Boolean.TRUE : Boolean.FALSE;
/*      */     case 44: 
/* 1237 */       return willParseLazily() ? Boolean.TRUE : Boolean.FALSE;
/*      */     
/*      */     case 26: 
/* 1240 */       if (!hasConfigFlags(2097152)) {
/* 1241 */         return "disable";
/*      */       }
/* 1243 */       return hasConfigFlags(4194304) ? "xmlidFull" : "xmlidTyping";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 50: 
/* 1250 */       return new Integer(getInputBufferLength());
/*      */     case 52: 
/* 1252 */       return new Integer(getShortestReportedTextSegment());
/*      */     case 53: 
/* 1254 */       return getCustomInternalEntities();
/*      */     case 54: 
/* 1256 */       return getDtdResolver();
/*      */     case 55: 
/* 1258 */       return getEntityResolver();
/*      */     case 56: 
/* 1260 */       return getUndeclaredEntityResolver();
/*      */     case 57: 
/* 1262 */       return getBaseURL();
/*      */     case 58: 
/* 1264 */       return getInputParsingMode();
/*      */     }
/*      */     
/* 1267 */     throw new Error("Internal error: no handler for property with internal id " + id + ".");
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean setProperty(String propName, int id, Object value)
/*      */   {
/* 1273 */     switch (id)
/*      */     {
/*      */ 
/*      */     case 1: 
/* 1277 */       doCoalesceText(ArgUtil.convertToBoolean(propName, value));
/* 1278 */       break;
/*      */     
/*      */     case 2: 
/* 1281 */       doSupportNamespaces(ArgUtil.convertToBoolean(propName, value));
/* 1282 */       break;
/*      */     
/*      */     case 3: 
/* 1285 */       doReplaceEntityRefs(ArgUtil.convertToBoolean(propName, value));
/* 1286 */       break;
/*      */     
/*      */     case 4: 
/* 1289 */       doSupportExternalEntities(ArgUtil.convertToBoolean(propName, value));
/* 1290 */       break;
/*      */     
/*      */     case 6: 
/* 1293 */       doSupportDTDs(ArgUtil.convertToBoolean(propName, value));
/* 1294 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 5: 
/* 1299 */       doValidateWithDTD(ArgUtil.convertToBoolean(propName, value));
/* 1300 */       break;
/*      */     
/*      */     case 8: 
/* 1303 */       setXMLReporter((XMLReporter)value);
/* 1304 */       break;
/*      */     
/*      */     case 9: 
/* 1307 */       setXMLResolver((XMLResolver)value);
/* 1308 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 7: 
/* 1314 */       return false;
/*      */     
/*      */ 
/*      */ 
/*      */     case 40: 
/* 1319 */       doNormalizeLFs(ArgUtil.convertToBoolean(propName, value));
/* 1320 */       break;
/*      */     
/*      */     case 41: 
/* 1323 */       doNormalizeAttrValues(ArgUtil.convertToBoolean(propName, value));
/* 1324 */       break;
/*      */     
/*      */     case 21: 
/* 1327 */       doInternNames(ArgUtil.convertToBoolean(propName, value));
/* 1328 */       break;
/*      */     
/*      */     case 20: 
/* 1331 */       doInternNsURIs(ArgUtil.convertToBoolean(propName, value));
/* 1332 */       break;
/*      */     
/*      */     case 23: 
/* 1335 */       doReportPrologWhitespace(ArgUtil.convertToBoolean(propName, value));
/* 1336 */       break;
/*      */     
/*      */     case 42: 
/* 1339 */       doCacheDTDs(ArgUtil.convertToBoolean(propName, value));
/* 1340 */       break;
/*      */     
/*      */     case 43: 
/* 1343 */       doCacheDTDsByPublicId(ArgUtil.convertToBoolean(propName, value));
/* 1344 */       break;
/*      */     
/*      */     case 44: 
/* 1347 */       doParseLazily(ArgUtil.convertToBoolean(propName, value));
/* 1348 */       break;
/*      */     case 26: 
/*      */       boolean typing;
/*      */       
/*      */ 
/*      */ 
/* 1354 */       if ("disable".equals(value)) { boolean uniq;
/* 1355 */         typing = uniq = 0; } else { boolean uniq;
/* 1356 */         if ("xmlidTyping".equals(value)) {
/* 1357 */           boolean typing = true;
/* 1358 */           uniq = false; } else { boolean typing;
/* 1359 */           if ("xmlidFull".equals(value)) { boolean uniq;
/* 1360 */             typing = uniq = 1;
/*      */           } else {
/* 1362 */             throw new IllegalArgumentException("Illegal argument ('" + value + "') to set property " + "org.codehaus.stax2.supportXmlId" + " to: has to be one of '" + "disable" + "', '" + "xmlidTyping" + "' or '" + "xmlidFull" + "'");
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */       boolean uniq;
/*      */       
/*      */       boolean typing;
/* 1370 */       setConfigFlag(2097152, typing);
/* 1371 */       setConfigFlag(4194304, uniq);
/* 1372 */       break;
/*      */     
/*      */ 
/*      */     case 24: 
/* 1376 */       doPreserveLocation(ArgUtil.convertToBoolean(propName, value));
/* 1377 */       break;
/*      */     
/*      */     case 25: 
/* 1380 */       doAutoCloseInput(ArgUtil.convertToBoolean(propName, value));
/* 1381 */       break;
/*      */     
/*      */     case 22: 
/* 1384 */       doReportCData(ArgUtil.convertToBoolean(propName, value));
/* 1385 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 50: 
/* 1390 */       setInputBufferLength(ArgUtil.convertToInt(propName, value, 1));
/* 1391 */       break;
/*      */     
/*      */     case 52: 
/* 1394 */       setShortestReportedTextSegment(ArgUtil.convertToInt(propName, value, 1));
/* 1395 */       break;
/*      */     
/*      */     case 53: 
/* 1398 */       setCustomInternalEntities((Map)value);
/* 1399 */       break;
/*      */     
/*      */     case 54: 
/* 1402 */       setDtdResolver((XMLResolver)value);
/* 1403 */       break;
/*      */     
/*      */     case 55: 
/* 1406 */       setEntityResolver((XMLResolver)value);
/* 1407 */       break;
/*      */     
/*      */     case 56: 
/* 1410 */       setUndeclaredEntityResolver((XMLResolver)value);
/* 1411 */       break;
/*      */     
/*      */     case 57: 
/* 1414 */       setBaseURL((URL)value);
/* 1415 */       break;
/*      */     
/*      */     case 58: 
/* 1418 */       setInputParsingMode((WstxInputProperties.ParsingMode)value);
/* 1419 */       break;
/*      */     case 10: case 11: case 12: case 13: case 14: case 15: case 16: case 17: case 18: case 19: case 27: case 28: case 29: case 30: case 31: 
/*      */     case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 39: case 45: case 46: case 47: case 48: case 49: case 51: default: 
/* 1422 */       throw new Error("Internal error: no handler for property with internal id " + id + ".");
/*      */     }
/*      */     
/* 1425 */     return true;
/*      */   }
/*      */   
/*      */   private Object getSpecialProperty(int ix)
/*      */   {
/* 1430 */     if (this.mSpecialProperties == null) {
/* 1431 */       return null;
/*      */     }
/* 1433 */     return this.mSpecialProperties[ix];
/*      */   }
/*      */   
/*      */   private void setSpecialProperty(int ix, Object value)
/*      */   {
/* 1438 */     if (this.mSpecialProperties == null) {
/* 1439 */       this.mSpecialProperties = new Object[3];
/*      */     }
/* 1441 */     this.mSpecialProperties[ix] = value;
/*      */   }
/*      */   
/*      */   public void doInternNames(boolean state) {}
/*      */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\api\ReaderConfig.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */