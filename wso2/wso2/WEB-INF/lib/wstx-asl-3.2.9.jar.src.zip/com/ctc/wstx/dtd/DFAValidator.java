/*    */ package com.ctc.wstx.dtd;
/*    */ 
/*    */ import com.ctc.wstx.util.StringUtil;
/*    */ import java.util.TreeSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DFAValidator
/*    */   extends StructValidator
/*    */ {
/*    */   DFAState mState;
/*    */   
/*    */   public DFAValidator(DFAState initialState)
/*    */   {
/* 36 */     this.mState = initialState;
/*    */   }
/*    */   
/*    */   public StructValidator newInstance() {
/* 40 */     return new DFAValidator(this.mState);
/*    */   }
/*    */   
/*    */ 
/*    */   public String tryToValidate(NameKey elemName)
/*    */   {
/* 46 */     DFAState next = this.mState.findNext(elemName);
/*    */     
/* 48 */     if (next == null)
/*    */     {
/* 50 */       TreeSet names = this.mState.getNextNames();
/* 51 */       if (names.size() == 0) {
/* 52 */         return "Expected $END";
/*    */       }
/*    */       
/*    */ 
/* 56 */       if (this.mState.isAcceptingState()) {
/* 57 */         return "Expected <" + StringUtil.concatEntries(names, ">, <", null) + "> or $END";
/*    */       }
/* 59 */       return "Expected <" + StringUtil.concatEntries(names, ">, <", "> or <") + ">";
/*    */     }
/*    */     
/*    */ 
/* 63 */     this.mState = next;
/* 64 */     return null;
/*    */   }
/*    */   
/*    */   public String fullyValid()
/*    */   {
/* 69 */     if (this.mState.isAcceptingState()) {
/* 70 */       return null;
/*    */     }
/* 72 */     TreeSet names = this.mState.getNextNames();
/* 73 */     return "Expected <" + StringUtil.concatEntries(names, ">, <", "> or <") + ">";
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\DFAValidator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */