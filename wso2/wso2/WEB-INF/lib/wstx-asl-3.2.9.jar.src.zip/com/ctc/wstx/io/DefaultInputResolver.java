/*     */ package com.ctc.wstx.io;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import com.ctc.wstx.util.URLUtil;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URL;
/*     */ import javax.xml.stream.XMLResolver;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DefaultInputResolver
/*     */ {
/*     */   private static final int DEFAULT_BUFFER_LENGTH = 4000;
/*     */   
/*     */   public static WstxInputSource resolveEntity(WstxInputSource parent, URL pathCtxt, String entityName, String publicId, String systemId, XMLResolver customResolver, ReaderConfig cfg, int xmlVersion)
/*     */     throws IOException, XMLStreamException
/*     */   {
/*  74 */     if (pathCtxt == null) {
/*  75 */       pathCtxt = parent.getSource();
/*  76 */       if (pathCtxt == null) {
/*  77 */         pathCtxt = URLUtil.urlFromCurrentDir();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  82 */     if (customResolver != null) {
/*  83 */       Object source = customResolver.resolveEntity(publicId, systemId, pathCtxt.toExternalForm(), entityName);
/*  84 */       if (source != null) {
/*  85 */         return sourceFrom(parent, cfg, entityName, xmlVersion, source);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  90 */     if (systemId == null) {
/*  91 */       throw new XMLStreamException("Can not resolve " + (entityName == null ? "[External DTD subset]" : new StringBuilder().append("entity '").append(entityName).append("'").toString()) + " without a system id (public id '" + publicId + "')");
/*     */     }
/*     */     
/*     */ 
/*  95 */     URL url = URLUtil.urlFromSystemId(systemId, pathCtxt);
/*  96 */     return sourceFromURL(parent, cfg, entityName, xmlVersion, url, publicId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static WstxInputSource resolveEntityUsing(WstxInputSource refCtxt, String entityName, String publicId, String systemId, XMLResolver resolver, ReaderConfig cfg, int xmlVersion)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 110 */     URL ctxt = refCtxt == null ? null : refCtxt.getSource();
/* 111 */     if (ctxt == null) {
/* 112 */       ctxt = URLUtil.urlFromCurrentDir();
/*     */     }
/* 114 */     Object source = resolver.resolveEntity(publicId, systemId, ctxt.toExternalForm(), entityName);
/* 115 */     return source == null ? null : sourceFrom(refCtxt, cfg, entityName, xmlVersion, source);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static WstxInputSource sourceFrom(WstxInputSource parent, ReaderConfig cfg, String refName, int xmlVersion, Object o)
/*     */     throws IllegalArgumentException, IOException, XMLStreamException
/*     */   {
/* 137 */     if ((o instanceof Source)) {
/* 138 */       if ((o instanceof StreamSource)) {
/* 139 */         return sourceFromSS(parent, cfg, refName, xmlVersion, (StreamSource)o);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 144 */       throw new IllegalArgumentException("Can not use other Source objects than StreamSource: got " + o.getClass());
/*     */     }
/* 146 */     if ((o instanceof URL)) {
/* 147 */       return sourceFromURL(parent, cfg, refName, xmlVersion, (URL)o, null);
/*     */     }
/* 149 */     if ((o instanceof InputStream)) {
/* 150 */       return sourceFromIS(parent, cfg, refName, xmlVersion, (InputStream)o, null, null);
/*     */     }
/* 152 */     if ((o instanceof Reader)) {
/* 153 */       return sourceFromR(parent, cfg, refName, xmlVersion, (Reader)o, null, null);
/*     */     }
/* 155 */     if ((o instanceof String)) {
/* 156 */       return sourceFromString(parent, cfg, refName, xmlVersion, (String)o);
/*     */     }
/* 158 */     if ((o instanceof File)) {
/* 159 */       URL u = ((File)o).toURL();
/* 160 */       return sourceFromURL(parent, cfg, refName, xmlVersion, u, null);
/*     */     }
/*     */     
/* 163 */     throw new IllegalArgumentException("Unrecognized input argument type for sourceFrom(): " + o.getClass());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Reader constructOptimizedReader(ReaderConfig cfg, InputStream in, boolean isXml11, String encoding)
/*     */     throws XMLStreamException
/*     */   {
/* 178 */     int inputBufLen = cfg.getInputBufferLength();
/* 179 */     String normEnc = CharsetNames.normalize(encoding);
/*     */     
/*     */     BaseReader r;
/* 182 */     if (normEnc == "UTF-8") {
/* 183 */       r = new UTF8Reader(cfg, in, cfg.allocFullBBuffer(inputBufLen), 0, 0); } else { BaseReader r;
/* 184 */       if (normEnc == "ISO-8859-1") {
/* 185 */         r = new ISOLatinReader(cfg, in, cfg.allocFullBBuffer(inputBufLen), 0, 0); } else { BaseReader r;
/* 186 */         if (normEnc == "US-ASCII") {
/* 187 */           r = new AsciiReader(cfg, in, cfg.allocFullBBuffer(inputBufLen), 0, 0); } else { BaseReader r;
/* 188 */           if (normEnc.startsWith("UTF-32")) {
/* 189 */             boolean isBE = normEnc == "UTF-32BE";
/* 190 */             r = new UTF32Reader(cfg, in, cfg.allocFullBBuffer(inputBufLen), 0, 0, isBE);
/*     */           } else {
/*     */             try {
/* 193 */               return new InputStreamReader(in, encoding);
/*     */             } catch (UnsupportedEncodingException ex) {
/* 195 */               throw new XMLStreamException("[unsupported encoding]: " + ex);
/*     */             }
/*     */           } } } }
/*     */     BaseReader r;
/* 199 */     if (isXml11) {
/* 200 */       r.setXmlCompliancy(272);
/*     */     }
/*     */     
/* 203 */     return r;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static WstxInputSource sourceFromSS(WstxInputSource parent, ReaderConfig cfg, String refName, int xmlVersion, StreamSource ssrc)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 218 */     Reader r = ssrc.getReader();
/* 219 */     String pubId = ssrc.getPublicId();
/* 220 */     String sysId = ssrc.getSystemId();
/* 221 */     URL ctxt = parent == null ? null : parent.getSource();
/* 222 */     URL url = (sysId == null) || (sysId.length() == 0) ? null : URLUtil.urlFromSystemId(sysId, ctxt);
/*     */     InputBootstrapper bs;
/*     */     InputBootstrapper bs;
/* 225 */     if (r == null) {
/* 226 */       InputStream in = ssrc.getInputStream();
/* 227 */       if (in == null) {
/* 228 */         if (url == null) {
/* 229 */           throw new IllegalArgumentException("Can not create StAX reader for a StreamSource -- neither reader, input stream nor system id was set.");
/*     */         }
/* 231 */         in = URLUtil.optimizedStreamFromURL(url);
/*     */       }
/* 233 */       bs = StreamBootstrapper.getInstance(in, pubId, sysId);
/*     */     } else {
/* 235 */       bs = ReaderBootstrapper.getInstance(r, pubId, sysId, null);
/*     */     }
/*     */     
/* 238 */     Reader r2 = bs.bootstrapInput(cfg, false, xmlVersion);
/* 239 */     return InputSourceFactory.constructEntitySource(cfg, parent, refName, bs, pubId, sysId, xmlVersion, url == null ? ctxt : url, r2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static WstxInputSource sourceFromURL(WstxInputSource parent, ReaderConfig cfg, String refName, int xmlVersion, URL url, String pubId)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 256 */     InputStream in = URLUtil.optimizedStreamFromURL(url);
/* 257 */     String sysId = url.toExternalForm();
/* 258 */     StreamBootstrapper bs = StreamBootstrapper.getInstance(in, pubId, sysId);
/* 259 */     Reader r = bs.bootstrapInput(cfg, false, xmlVersion);
/* 260 */     return InputSourceFactory.constructEntitySource(cfg, parent, refName, bs, pubId, sysId, xmlVersion, url, r);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static WstxInputSource sourceFromString(WstxInputSource parent, ReaderConfig cfg, String refName, int xmlVersion, String refContent)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 282 */     return sourceFromR(parent, cfg, refName, xmlVersion, new StringReader(refContent), null, refName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static WstxInputSource sourceFromIS(WstxInputSource parent, ReaderConfig cfg, String refName, int xmlVersion, InputStream is, String pubId, String sysId)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 294 */     StreamBootstrapper bs = StreamBootstrapper.getInstance(is, pubId, sysId);
/* 295 */     Reader r = bs.bootstrapInput(cfg, false, xmlVersion);
/* 296 */     URL ctxt = parent.getSource();
/*     */     
/*     */ 
/* 299 */     if ((sysId != null) && (sysId.length() > 0)) {
/* 300 */       ctxt = URLUtil.urlFromSystemId(sysId, ctxt);
/*     */     }
/* 302 */     return InputSourceFactory.constructEntitySource(cfg, parent, refName, bs, pubId, sysId, xmlVersion, ctxt, r);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static WstxInputSource sourceFromR(WstxInputSource parent, ReaderConfig cfg, String refName, int xmlVersion, Reader r, String pubId, String sysId)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 315 */     ReaderBootstrapper rbs = ReaderBootstrapper.getInstance(r, pubId, sysId, null);
/*     */     
/* 317 */     Reader r2 = rbs.bootstrapInput(cfg, false, xmlVersion);
/* 318 */     URL ctxt = parent == null ? null : parent.getSource();
/* 319 */     if ((sysId != null) && (sysId.length() > 0)) {
/* 320 */       ctxt = URLUtil.urlFromSystemId(sysId, ctxt);
/*     */     }
/* 322 */     return InputSourceFactory.constructEntitySource(cfg, parent, refName, rbs, pubId, sysId, xmlVersion, ctxt, r2);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\io\DefaultInputResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */