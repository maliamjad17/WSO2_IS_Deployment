/*    */ package com.ctc.wstx.ent;
/*    */ 
/*    */ import com.ctc.wstx.api.ReaderConfig;
/*    */ import com.ctc.wstx.io.WstxInputSource;
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ import java.net.URL;
/*    */ import javax.xml.stream.Location;
/*    */ import javax.xml.stream.XMLResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnparsedExtEntity
/*    */   extends ExtEntity
/*    */ {
/*    */   final String mNotationId;
/*    */   
/*    */   public UnparsedExtEntity(Location loc, String name, URL ctxt, String pubId, String sysId, String notationId)
/*    */   {
/* 27 */     super(loc, name, ctxt, pubId, sysId);
/* 28 */     this.mNotationId = notationId;
/*    */   }
/*    */   
/*    */   public String getNotationName() {
/* 32 */     return this.mNotationId;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void writeEnc(Writer w)
/*    */     throws IOException
/*    */   {
/* 43 */     w.write("<!ENTITY ");
/* 44 */     w.write(this.mName);
/* 45 */     String pubId = getPublicId();
/* 46 */     if (pubId != null) {
/* 47 */       w.write("PUBLIC \"");
/* 48 */       w.write(pubId);
/* 49 */       w.write("\" ");
/*    */     } else {
/* 51 */       w.write("SYSTEM ");
/*    */     }
/* 53 */     w.write(34);
/* 54 */     w.write(getSystemId());
/* 55 */     w.write("\" NDATA ");
/* 56 */     w.write(this.mNotationId);
/* 57 */     w.write(62);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isParsed()
/*    */   {
/* 68 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public WstxInputSource expand(WstxInputSource parent, XMLResolver res, ReaderConfig cfg, int xmlVersion)
/*    */   {
/* 75 */     throw new Error("Internal error: createInputSource() called for unparsed (external) entity.");
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\ent\UnparsedExtEntity.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */