/*     */ package com.ctc.wstx.evt;
/*     */ 
/*     */ import com.ctc.wstx.compat.JdkFeatures;
/*     */ import com.ctc.wstx.compat.JdkImpl;
/*     */ import com.ctc.wstx.io.TextEscaper;
/*     */ import com.ctc.wstx.util.BaseNsContext;
/*     */ import com.ctc.wstx.util.EmptyIterator;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.stream.events.Attribute;
/*     */ import javax.xml.stream.events.Namespace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleStartElement
/*     */   extends BaseStartElement
/*     */ {
/*     */   final Map mAttrs;
/*     */   
/*     */   protected SimpleStartElement(Location loc, QName name, BaseNsContext nsCtxt, Map attr)
/*     */   {
/*  41 */     super(loc, name, nsCtxt);
/*  42 */     this.mAttrs = attr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SimpleStartElement construct(Location loc, QName name, Map attrs, List ns, NamespaceContext nsCtxt)
/*     */   {
/*  53 */     BaseNsContext myCtxt = MergedNsContext.construct(nsCtxt, ns);
/*  54 */     return new SimpleStartElement(loc, name, myCtxt, attrs);
/*     */   }
/*     */   
/*     */ 
/*     */   public static SimpleStartElement construct(Location loc, QName name, Iterator attrs, Iterator ns, NamespaceContext nsCtxt)
/*     */   {
/*     */     Map attrMap;
/*     */     Map attrMap;
/*  62 */     if ((attrs == null) || (!attrs.hasNext())) {
/*  63 */       attrMap = null;
/*     */     } else {
/*  65 */       attrMap = JdkFeatures.getInstance().getInsertOrderedMap();
/*     */       do {
/*  67 */         Attribute attr = (Attribute)attrs.next();
/*  68 */         attrMap.put(attr.getName(), attr);
/*  69 */       } while (attrs.hasNext());
/*     */     }
/*     */     BaseNsContext myCtxt;
/*     */     BaseNsContext myCtxt;
/*  73 */     if ((ns != null) && (ns.hasNext())) {
/*  74 */       ArrayList l = new ArrayList();
/*     */       do {
/*  76 */         l.add((Namespace)ns.next());
/*  77 */       } while (ns.hasNext());
/*  78 */       myCtxt = MergedNsContext.construct(nsCtxt, l);
/*     */     }
/*     */     else
/*     */     {
/*     */       BaseNsContext myCtxt;
/*  83 */       if (nsCtxt == null) {
/*  84 */         myCtxt = null; } else { BaseNsContext myCtxt;
/*  85 */         if ((nsCtxt instanceof BaseNsContext)) {
/*  86 */           myCtxt = (BaseNsContext)nsCtxt;
/*     */         } else
/*  88 */           myCtxt = MergedNsContext.construct(nsCtxt, null);
/*     */       }
/*     */     }
/*  91 */     return new SimpleStartElement(loc, name, myCtxt, attrMap);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Attribute getAttributeByName(QName name)
/*     */   {
/* 102 */     if (this.mAttrs == null) {
/* 103 */       return null;
/*     */     }
/* 105 */     return (Attribute)this.mAttrs.get(name);
/*     */   }
/*     */   
/*     */   public Iterator getAttributes()
/*     */   {
/* 110 */     if (this.mAttrs == null) {
/* 111 */       return EmptyIterator.getInstance();
/*     */     }
/* 113 */     return this.mAttrs.values().iterator();
/*     */   }
/*     */   
/*     */   protected void outputNsAndAttr(Writer w)
/*     */     throws IOException
/*     */   {
/* 119 */     if (this.mNsCtxt != null) {
/* 120 */       this.mNsCtxt.outputNamespaceDeclarations(w);
/*     */     }
/*     */     
/* 123 */     if ((this.mAttrs != null) && (this.mAttrs.size() > 0)) {
/* 124 */       Iterator it = this.mAttrs.values().iterator();
/* 125 */       while (it.hasNext()) {
/* 126 */         Attribute attr = (Attribute)it.next();
/*     */         
/* 128 */         if (attr.isSpecified())
/*     */         {
/*     */ 
/*     */ 
/* 132 */           w.write(32);
/* 133 */           QName name = attr.getName();
/* 134 */           String prefix = name.getPrefix();
/* 135 */           if ((prefix != null) && (prefix.length() > 0)) {
/* 136 */             w.write(prefix);
/* 137 */             w.write(58);
/*     */           }
/* 139 */           w.write(name.getLocalPart());
/* 140 */           w.write("=\"");
/* 141 */           String val = attr.getValue();
/* 142 */           if ((val != null) && (val.length() > 0)) {
/* 143 */             TextEscaper.writeEscapedAttrValue(w, val);
/*     */           }
/* 145 */           w.write(34);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void outputNsAndAttr(XMLStreamWriter w) throws XMLStreamException
/*     */   {
/* 153 */     if (this.mNsCtxt != null) {
/* 154 */       this.mNsCtxt.outputNamespaceDeclarations(w);
/*     */     }
/*     */     
/* 157 */     if ((this.mAttrs != null) && (this.mAttrs.size() > 0)) {
/* 158 */       Iterator it = this.mAttrs.values().iterator();
/* 159 */       while (it.hasNext()) {
/* 160 */         Attribute attr = (Attribute)it.next();
/*     */         
/* 162 */         if (attr.isSpecified())
/*     */         {
/*     */ 
/* 165 */           QName name = attr.getName();
/* 166 */           String prefix = name.getPrefix();
/* 167 */           String ln = name.getLocalPart();
/* 168 */           String nsURI = name.getNamespaceURI();
/* 169 */           w.writeAttribute(prefix, nsURI, ln, attr.getValue());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\evt\SimpleStartElement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */