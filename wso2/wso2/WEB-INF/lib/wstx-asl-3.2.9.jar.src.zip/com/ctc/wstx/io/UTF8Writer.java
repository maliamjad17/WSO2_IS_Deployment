/*     */ package com.ctc.wstx.io;
/*     */ 
/*     */ import com.ctc.wstx.api.WriterConfig;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UTF8Writer
/*     */   extends Writer
/*     */ {
/*     */   static final int SURR1_FIRST = 55296;
/*     */   static final int SURR1_LAST = 56319;
/*     */   static final int SURR2_FIRST = 56320;
/*     */   static final int SURR2_LAST = 57343;
/*     */   final WriterConfig mConfig;
/*     */   final boolean mAutoCloseOutput;
/*     */   OutputStream mOut;
/*     */   byte[] mOutBuffer;
/*     */   final int mOutBufferLast;
/*     */   int mOutPtr;
/*  32 */   int mSurrogate = 0;
/*     */   
/*     */   public UTF8Writer(WriterConfig cfg, OutputStream out, boolean autoclose)
/*     */   {
/*  36 */     this.mConfig = cfg;
/*  37 */     this.mAutoCloseOutput = autoclose;
/*  38 */     this.mOut = out;
/*  39 */     this.mOutBuffer = cfg.allocFullBBuffer(4000);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  44 */     this.mOutBufferLast = (this.mOutBuffer.length - 4);
/*  45 */     this.mOutPtr = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/*  66 */     if (this.mOut != null) {
/*  67 */       if (this.mOutPtr > 0) {
/*  68 */         this.mOut.write(this.mOutBuffer, 0, this.mOutPtr);
/*  69 */         this.mOutPtr = 0;
/*     */       }
/*  71 */       OutputStream out = this.mOut;
/*  72 */       this.mOut = null;
/*  73 */       byte[] buf = this.mOutBuffer;
/*  74 */       this.mOutBuffer = null;
/*     */       
/*  76 */       if (this.mAutoCloseOutput) {
/*  77 */         out.close();
/*     */       }
/*  79 */       this.mConfig.freeFullBBuffer(buf);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  84 */       int code = this.mSurrogate;
/*  85 */       this.mSurrogate = 0;
/*  86 */       if (code > 0) {
/*  87 */         throwIllegal(code);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void flush()
/*     */     throws IOException
/*     */   {
/*  95 */     if (this.mOutPtr > 0) {
/*  96 */       this.mOut.write(this.mOutBuffer, 0, this.mOutPtr);
/*  97 */       this.mOutPtr = 0;
/*     */     }
/*  99 */     this.mOut.flush();
/*     */   }
/*     */   
/*     */   public void write(char[] cbuf)
/*     */     throws IOException
/*     */   {
/* 105 */     write(cbuf, 0, cbuf.length);
/*     */   }
/*     */   
/*     */   public void write(char[] cbuf, int off, int len)
/*     */     throws IOException
/*     */   {
/* 111 */     if (len < 2) {
/* 112 */       if (len == 1) {
/* 113 */         write(cbuf[off]);
/*     */       }
/* 115 */       return;
/*     */     }
/*     */     
/*     */ 
/* 119 */     if (this.mSurrogate > 0) {
/* 120 */       char second = cbuf[(off++)];
/* 121 */       len--;
/* 122 */       write(convertSurrogate(second));
/*     */     }
/*     */     
/*     */ 
/* 126 */     int outPtr = this.mOutPtr;
/* 127 */     byte[] outBuf = this.mOutBuffer;
/* 128 */     int outBufLast = this.mOutBufferLast;
/*     */     
/*     */ 
/* 131 */     len += off;
/*     */     
/*     */ 
/* 134 */     while (off < len)
/*     */     {
/*     */ 
/*     */ 
/* 138 */       if (outPtr >= outBufLast) {
/* 139 */         this.mOut.write(outBuf, 0, outPtr);
/* 140 */         outPtr = 0;
/*     */       }
/*     */       
/* 143 */       int c = cbuf[(off++)];
/*     */       
/* 145 */       if (c < 128) {
/* 146 */         outBuf[(outPtr++)] = ((byte)c);
/*     */         
/* 148 */         int maxInCount = len - off;
/* 149 */         int maxOutCount = outBufLast - outPtr;
/*     */         
/* 151 */         if (maxInCount > maxOutCount) {
/* 152 */           maxInCount = maxOutCount;
/*     */         }
/* 154 */         maxInCount += off;
/*     */         
/*     */ 
/* 157 */         while (off < maxInCount)
/*     */         {
/*     */ 
/* 160 */           c = cbuf[(off++)];
/* 161 */           if (c >= 128) {
/*     */             break label193;
/*     */           }
/* 164 */           outBuf[(outPtr++)] = ((byte)c);
/*     */         }
/*     */       }
/*     */       else {
/*     */         label193:
/* 169 */         if (c < 2048) {
/* 170 */           outBuf[(outPtr++)] = ((byte)(0xC0 | c >> 6));
/* 171 */           outBuf[(outPtr++)] = ((byte)(0x80 | c & 0x3F));
/*     */ 
/*     */         }
/* 174 */         else if ((c < 55296) || (c > 57343)) {
/* 175 */           outBuf[(outPtr++)] = ((byte)(0xE0 | c >> 12));
/* 176 */           outBuf[(outPtr++)] = ((byte)(0x80 | c >> 6 & 0x3F));
/* 177 */           outBuf[(outPtr++)] = ((byte)(0x80 | c & 0x3F));
/*     */         }
/*     */         else
/*     */         {
/* 181 */           if (c > 56319) {
/* 182 */             this.mOutPtr = outPtr;
/* 183 */             throwIllegal(c);
/*     */           }
/* 185 */           this.mSurrogate = c;
/*     */           
/* 187 */           if (off >= len) {
/*     */             break;
/*     */           }
/* 190 */           c = convertSurrogate(cbuf[(off++)]);
/* 191 */           if (c > 1114111) {
/* 192 */             this.mOutPtr = outPtr;
/* 193 */             throwIllegal(c);
/*     */           }
/* 195 */           outBuf[(outPtr++)] = ((byte)(0xF0 | c >> 18));
/* 196 */           outBuf[(outPtr++)] = ((byte)(0x80 | c >> 12 & 0x3F));
/* 197 */           outBuf[(outPtr++)] = ((byte)(0x80 | c >> 6 & 0x3F));
/* 198 */           outBuf[(outPtr++)] = ((byte)(0x80 | c & 0x3F));
/*     */         }
/*     */       } }
/* 201 */     this.mOutPtr = outPtr;
/*     */   }
/*     */   
/*     */ 
/*     */   public void write(int c)
/*     */     throws IOException
/*     */   {
/* 208 */     if (this.mSurrogate > 0) {
/* 209 */       c = convertSurrogate(c);
/*     */     }
/* 211 */     else if ((c >= 55296) && (c <= 57343))
/*     */     {
/* 213 */       if (c > 56319) {
/* 214 */         throwIllegal(c);
/*     */       }
/*     */       
/* 217 */       this.mSurrogate = c;
/* 218 */       return;
/*     */     }
/*     */     
/* 221 */     if (this.mOutPtr >= this.mOutBufferLast) {
/* 222 */       this.mOut.write(this.mOutBuffer, 0, this.mOutPtr);
/* 223 */       this.mOutPtr = 0;
/*     */     }
/*     */     
/* 226 */     if (c < 128) {
/* 227 */       this.mOutBuffer[(this.mOutPtr++)] = ((byte)c);
/*     */     } else {
/* 229 */       int ptr = this.mOutPtr;
/* 230 */       if (c < 2048) {
/* 231 */         this.mOutBuffer[(ptr++)] = ((byte)(0xC0 | c >> 6));
/* 232 */         this.mOutBuffer[(ptr++)] = ((byte)(0x80 | c & 0x3F));
/* 233 */       } else if (c <= 65535) {
/* 234 */         this.mOutBuffer[(ptr++)] = ((byte)(0xE0 | c >> 12));
/* 235 */         this.mOutBuffer[(ptr++)] = ((byte)(0x80 | c >> 6 & 0x3F));
/* 236 */         this.mOutBuffer[(ptr++)] = ((byte)(0x80 | c & 0x3F));
/*     */       } else {
/* 238 */         if (c > 1114111) {
/* 239 */           throwIllegal(c);
/*     */         }
/* 241 */         this.mOutBuffer[(ptr++)] = ((byte)(0xF0 | c >> 18));
/* 242 */         this.mOutBuffer[(ptr++)] = ((byte)(0x80 | c >> 12 & 0x3F));
/* 243 */         this.mOutBuffer[(ptr++)] = ((byte)(0x80 | c >> 6 & 0x3F));
/* 244 */         this.mOutBuffer[(ptr++)] = ((byte)(0x80 | c & 0x3F));
/*     */       }
/* 246 */       this.mOutPtr = ptr;
/*     */     }
/*     */   }
/*     */   
/*     */   public void write(String str)
/*     */     throws IOException
/*     */   {
/* 253 */     write(str, 0, str.length());
/*     */   }
/*     */   
/*     */   public void write(String str, int off, int len)
/*     */     throws IOException
/*     */   {
/* 259 */     if (len < 2) {
/* 260 */       if (len == 1) {
/* 261 */         write(str.charAt(off));
/*     */       }
/* 263 */       return;
/*     */     }
/*     */     
/*     */ 
/* 267 */     if (this.mSurrogate > 0) {
/* 268 */       char second = str.charAt(off++);
/* 269 */       len--;
/* 270 */       write(convertSurrogate(second));
/*     */     }
/*     */     
/*     */ 
/* 274 */     int outPtr = this.mOutPtr;
/* 275 */     byte[] outBuf = this.mOutBuffer;
/* 276 */     int outBufLast = this.mOutBufferLast;
/*     */     
/*     */ 
/* 279 */     len += off;
/*     */     
/*     */ 
/* 282 */     while (off < len)
/*     */     {
/*     */ 
/*     */ 
/* 286 */       if (outPtr >= outBufLast) {
/* 287 */         this.mOut.write(outBuf, 0, outPtr);
/* 288 */         outPtr = 0;
/*     */       }
/*     */       
/* 291 */       int c = str.charAt(off++);
/*     */       
/* 293 */       if (c < 128) {
/* 294 */         outBuf[(outPtr++)] = ((byte)c);
/*     */         
/* 296 */         int maxInCount = len - off;
/* 297 */         int maxOutCount = outBufLast - outPtr;
/*     */         
/* 299 */         if (maxInCount > maxOutCount) {
/* 300 */           maxInCount = maxOutCount;
/*     */         }
/* 302 */         maxInCount += off;
/*     */         
/*     */ 
/* 305 */         while (off < maxInCount)
/*     */         {
/*     */ 
/* 308 */           c = str.charAt(off++);
/* 309 */           if (c >= 128) {
/*     */             break label201;
/*     */           }
/* 312 */           outBuf[(outPtr++)] = ((byte)c);
/*     */         }
/*     */       }
/*     */       else {
/*     */         label201:
/* 317 */         if (c < 2048) {
/* 318 */           outBuf[(outPtr++)] = ((byte)(0xC0 | c >> 6));
/* 319 */           outBuf[(outPtr++)] = ((byte)(0x80 | c & 0x3F));
/*     */ 
/*     */         }
/* 322 */         else if ((c < 55296) || (c > 57343)) {
/* 323 */           outBuf[(outPtr++)] = ((byte)(0xE0 | c >> 12));
/* 324 */           outBuf[(outPtr++)] = ((byte)(0x80 | c >> 6 & 0x3F));
/* 325 */           outBuf[(outPtr++)] = ((byte)(0x80 | c & 0x3F));
/*     */         }
/*     */         else
/*     */         {
/* 329 */           if (c > 56319) {
/* 330 */             this.mOutPtr = outPtr;
/* 331 */             throwIllegal(c);
/*     */           }
/* 333 */           this.mSurrogate = c;
/*     */           
/* 335 */           if (off >= len) {
/*     */             break;
/*     */           }
/* 338 */           c = convertSurrogate(str.charAt(off++));
/* 339 */           if (c > 1114111) {
/* 340 */             this.mOutPtr = outPtr;
/* 341 */             throwIllegal(c);
/*     */           }
/* 343 */           outBuf[(outPtr++)] = ((byte)(0xF0 | c >> 18));
/* 344 */           outBuf[(outPtr++)] = ((byte)(0x80 | c >> 12 & 0x3F));
/* 345 */           outBuf[(outPtr++)] = ((byte)(0x80 | c >> 6 & 0x3F));
/* 346 */           outBuf[(outPtr++)] = ((byte)(0x80 | c & 0x3F));
/*     */         }
/*     */       } }
/* 349 */     this.mOutPtr = outPtr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int convertSurrogate(int secondPart)
/*     */     throws IOException
/*     */   {
/* 364 */     int firstPart = this.mSurrogate;
/* 365 */     this.mSurrogate = 0;
/*     */     
/*     */ 
/* 368 */     if ((secondPart < 56320) || (secondPart > 57343)) {
/* 369 */       throw new IOException("Broken surrogate pair: first char 0x" + Integer.toHexString(firstPart) + ", second 0x" + Integer.toHexString(secondPart) + "; illegal combination");
/*     */     }
/* 371 */     return 65536 + (firstPart - 55296 << 10) + (secondPart - 56320);
/*     */   }
/*     */   
/*     */   private void throwIllegal(int code)
/*     */     throws IOException
/*     */   {
/* 377 */     if (code > 1114111) {
/* 378 */       throw new IOException("Illegal character point (0x" + Integer.toHexString(code) + ") to output; max is 0x10FFFF as per RFC 3629");
/*     */     }
/* 380 */     if (code >= 55296) {
/* 381 */       if (code <= 56319) {
/* 382 */         throw new IOException("Unmatched first part of surrogate pair (0x" + Integer.toHexString(code) + ")");
/*     */       }
/* 384 */       throw new IOException("Unmatched second part of surrogate pair (0x" + Integer.toHexString(code) + ")");
/*     */     }
/*     */     
/*     */ 
/* 388 */     throw new IOException("Illegal character point (0x" + Integer.toHexString(code) + ") to output");
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\io\UTF8Writer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */