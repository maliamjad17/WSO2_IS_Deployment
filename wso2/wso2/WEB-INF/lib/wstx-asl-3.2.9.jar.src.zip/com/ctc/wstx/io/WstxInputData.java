/*     */ package com.ctc.wstx.io;
/*     */ 
/*     */ import com.ctc.wstx.util.XmlChars;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WstxInputData
/*     */ {
/*     */   public static final char CHAR_NULL = '\000';
/*     */   public static final char INT_NULL = '\000';
/*     */   public static final char CHAR_SPACE = ' ';
/*     */   public static final char INT_SPACE = ' ';
/*     */   public static final int MAX_UNICODE_CHAR = 1114111;
/*     */   private static final int VALID_CHAR_COUNT = 256;
/*     */   private static final int FIRST_VALID_FOR_FIRST = 65;
/*     */   private static final int FIRST_VALID_FOR_REST = 45;
/*     */   private static final byte NAME_CHAR_INVALID_B = 0;
/*     */   private static final byte NAME_CHAR_ALL_VALID_B = 1;
/*     */   private static final byte NAME_CHAR_VALID_NONFIRST_B = -1;
/*     */   private static final int NAME_CHAR_INVALID_I = 0;
/*     */   private static final int NAME_CHAR_ALL_VALID_I = 1;
/*     */   private static final int NAME_CHAR_VALID_NONFIRST_I = -1;
/*  78 */   private static final byte[] sCharValidity = new byte['Ā'];
/*     */   private static final int VALID_PUBID_CHAR_COUNT = 128;
/*     */   private static final byte[] sPubidValidity;
/*     */   private static final byte PUBID_CHAR_INVALID_B = 0;
/*     */   private static final byte PUBID_CHAR_VALID_B = 1;
/*     */   
/*  84 */   static { sCharValidity[95] = 1;
/*  85 */     int i = 0; for (int last = 25; i <= last; i++) {
/*  86 */       sCharValidity[(65 + i)] = 1;
/*  87 */       sCharValidity[(97 + i)] = 1;
/*     */     }
/*     */     
/*  90 */     for (int i = 192; i < 256; i++) {
/*  91 */       sCharValidity[i] = 1;
/*     */     }
/*     */     
/*  94 */     sCharValidity['×'] = 0;
/*  95 */     sCharValidity['÷'] = 0;
/*     */     
/*     */ 
/*     */ 
/*  99 */     sCharValidity[45] = -1;
/* 100 */     sCharValidity[46] = -1;
/* 101 */     sCharValidity['·'] = -1;
/* 102 */     for (int i = 48; i <= 57; i++) {
/* 103 */       sCharValidity[i] = -1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 111 */     sPubidValidity = new byte[''];
/*     */     
/*     */ 
/*     */ 
/* 115 */     int i = 0; for (int last = 25; i <= last; i++) {
/* 116 */       sPubidValidity[(65 + i)] = 1;
/* 117 */       sPubidValidity[(97 + i)] = 1;
/*     */     }
/* 119 */     for (int i = 48; i <= 57; i++) {
/* 120 */       sPubidValidity[i] = 1;
/*     */     }
/*     */     
/*     */ 
/* 124 */     sPubidValidity[10] = 1;
/* 125 */     sPubidValidity[13] = 1;
/* 126 */     sPubidValidity[32] = 1;
/*     */     
/*     */ 
/* 129 */     sPubidValidity[45] = 1;
/* 130 */     sPubidValidity[39] = 1;
/* 131 */     sPubidValidity[40] = 1;
/* 132 */     sPubidValidity[41] = 1;
/* 133 */     sPubidValidity[43] = 1;
/* 134 */     sPubidValidity[44] = 1;
/* 135 */     sPubidValidity[46] = 1;
/* 136 */     sPubidValidity[47] = 1;
/* 137 */     sPubidValidity[58] = 1;
/* 138 */     sPubidValidity[61] = 1;
/* 139 */     sPubidValidity[63] = 1;
/* 140 */     sPubidValidity[59] = 1;
/* 141 */     sPubidValidity[33] = 1;
/* 142 */     sPubidValidity[42] = 1;
/* 143 */     sPubidValidity[35] = 1;
/* 144 */     sPubidValidity[64] = 1;
/* 145 */     sPubidValidity[36] = 1;
/* 146 */     sPubidValidity[95] = 1;
/* 147 */     sPubidValidity[37] = 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 160 */   protected boolean mXml11 = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected char[] mInputBuffer;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 178 */   protected int mInputPtr = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 183 */   protected int mInputLen = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 195 */   protected long mCurrInputProcessed = 0L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 201 */   protected int mCurrInputRow = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 209 */   protected int mCurrInputRowStart = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void copyBufferStateFrom(WstxInputData src)
/*     */   {
/* 226 */     this.mInputBuffer = src.mInputBuffer;
/* 227 */     this.mInputPtr = src.mInputPtr;
/* 228 */     this.mInputLen = src.mInputLen;
/*     */     
/* 230 */     this.mCurrInputProcessed = src.mCurrInputProcessed;
/* 231 */     this.mCurrInputRow = src.mCurrInputRow;
/* 232 */     this.mCurrInputRowStart = src.mCurrInputRowStart;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final boolean isNameStartChar(char c)
/*     */   {
/* 253 */     if (c <= 'z') {
/* 254 */       if (c >= 'a') {
/* 255 */         return true;
/*     */       }
/* 257 */       if (c < 'A') {
/* 258 */         return false;
/*     */       }
/* 260 */       return (c <= 'Z') || (c == '_');
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 265 */     return this.mXml11 ? XmlChars.is11NameStartChar(c) : XmlChars.is10NameStartChar(c);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final boolean isNameChar(char c)
/*     */   {
/* 278 */     if (c <= 'z') {
/* 279 */       if (c >= 'a') {
/* 280 */         return true;
/*     */       }
/* 282 */       if (c <= 'Z') {
/* 283 */         if (c >= 'A') {
/* 284 */           return true;
/*     */         }
/*     */         
/* 287 */         return ((c >= '0') && (c <= '9')) || (c == '.') || (c == '-');
/*     */       }
/* 289 */       return c == '_';
/*     */     }
/* 291 */     return this.mXml11 ? XmlChars.is11NameChar(c) : XmlChars.is10NameChar(c);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final boolean isNameStartChar(char c, boolean nsAware, boolean xml11)
/*     */   {
/* 299 */     if (c <= 'z') {
/* 300 */       if (c >= 'a') {
/* 301 */         return true;
/*     */       }
/* 303 */       if (c < 'A') {
/* 304 */         if ((c == ':') && (!nsAware)) {
/* 305 */           return true;
/*     */         }
/* 307 */         return false;
/*     */       }
/* 309 */       return (c <= 'Z') || (c == '_');
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 314 */     return xml11 ? XmlChars.is11NameStartChar(c) : XmlChars.is10NameStartChar(c);
/*     */   }
/*     */   
/*     */ 
/*     */   public static final boolean isNameChar(char c, boolean nsAware, boolean xml11)
/*     */   {
/* 320 */     if (c <= 'z') {
/* 321 */       if (c >= 'a') {
/* 322 */         return true;
/*     */       }
/* 324 */       if (c <= 'Z') {
/* 325 */         if (c >= 'A') {
/* 326 */           return true;
/*     */         }
/*     */         
/* 329 */         return ((c >= '0') && (c <= '9')) || (c == '.') || (c == '-') || ((c == ':') && (!nsAware));
/*     */       }
/*     */       
/* 332 */       return c == '_';
/*     */     }
/* 334 */     return xml11 ? XmlChars.is11NameChar(c) : XmlChars.is10NameChar(c);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int findIllegalNameChar(String name, boolean nsAware, boolean xml11)
/*     */   {
/* 346 */     int len = name.length();
/* 347 */     if (len < 1) {
/* 348 */       return -1;
/*     */     }
/*     */     
/* 351 */     char c = name.charAt(0);
/*     */     
/*     */ 
/* 354 */     if (c <= 'z') {
/* 355 */       if (c < 'a') {
/* 356 */         if (c < 'A') {
/* 357 */           if ((c != ':') || (nsAware)) {
/* 358 */             return 0;
/*     */           }
/* 360 */         } else if ((c > 'Z') && (c != '_'))
/*     */         {
/* 362 */           return 0;
/*     */         }
/*     */       }
/*     */     }
/* 366 */     else if (xml11) {
/* 367 */       if (!XmlChars.is11NameStartChar(c)) {
/* 368 */         return 0;
/*     */       }
/*     */     }
/* 371 */     else if (!XmlChars.is10NameStartChar(c)) {
/* 372 */       return 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 377 */     for (int i = 1; i < len; i++) {
/* 378 */       c = name.charAt(i);
/* 379 */       if (c <= 'z') {
/* 380 */         if (c >= 'a') {
/*     */           continue;
/*     */         }
/* 383 */         if (c <= 'Z') {
/* 384 */           if (c >= 'A') {
/*     */             continue;
/*     */           }
/*     */           
/* 388 */           if (((c >= '0') && (c <= '9')) || (c == '.') || (c == '-')) {
/*     */             continue;
/*     */           }
/*     */           
/* 392 */           if ((c == ':') && (!nsAware)) {
/*     */             continue;
/*     */           }
/* 395 */         } else if (c == '_') {
/*     */           continue;
/*     */         }
/*     */       } else {
/* 399 */         if (xml11 ? 
/* 400 */           XmlChars.is11NameChar(c) : 
/*     */           
/*     */ 
/*     */ 
/* 404 */           XmlChars.is10NameChar(c)) {
/*     */           continue;
/*     */         }
/*     */       }
/*     */       
/* 409 */       return i;
/*     */     }
/*     */     
/* 412 */     return -1;
/*     */   }
/*     */   
/*     */   public static final int findIllegalNmtokenChar(String nmtoken, boolean nsAware, boolean xml11)
/*     */   {
/* 417 */     int len = nmtoken.length();
/*     */     
/* 419 */     for (int i = 1; i < len; i++) {
/* 420 */       char c = nmtoken.charAt(i);
/* 421 */       if (c <= 'z') {
/* 422 */         if (c >= 'a') {
/*     */           continue;
/*     */         }
/* 425 */         if (c <= 'Z') {
/* 426 */           if (c >= 'A') {
/*     */             continue;
/*     */           }
/*     */           
/* 430 */           if (((c >= '0') && (c <= '9')) || (c == '.') || (c == '-')) {
/*     */             continue;
/*     */           }
/*     */           
/* 434 */           if ((c == ':') && (!nsAware)) {
/*     */             continue;
/*     */           }
/* 437 */         } else if (c == '_') {
/*     */           continue;
/*     */         }
/*     */       } else {
/* 441 */         if (xml11 ? 
/* 442 */           XmlChars.is11NameChar(c) : 
/*     */           
/*     */ 
/*     */ 
/* 446 */           XmlChars.is10NameChar(c)) {
/*     */           continue;
/*     */         }
/*     */       }
/*     */       
/* 451 */       return i;
/*     */     }
/* 453 */     return -1;
/*     */   }
/*     */   
/*     */   public static final boolean isSpaceChar(char c)
/*     */   {
/* 458 */     return c <= ' ';
/*     */   }
/*     */   
/*     */   public static String getCharDesc(char c)
/*     */   {
/* 463 */     int i = c;
/* 464 */     if (Character.isISOControl(c)) {
/* 465 */       return "(CTRL-CHAR, code " + i + ")";
/*     */     }
/* 467 */     if (i > 255) {
/* 468 */       return "'" + c + "' (code " + i + " / 0x" + Integer.toHexString(i) + ")";
/*     */     }
/* 470 */     return "'" + c + "' (code " + i + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\io\WstxInputData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */