/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NameKey
/*     */   implements Comparable
/*     */ {
/*     */   private String mPrefix;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String mLocalName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  42 */   volatile int mHash = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NameKey(String prefix, String localName)
/*     */   {
/*  52 */     this.mLocalName = localName;
/*  53 */     this.mPrefix = ((prefix != null) && (prefix.length() == 0) ? null : prefix);
/*     */   }
/*     */   
/*     */ 
/*     */   public NameKey reset(String prefix, String localName)
/*     */   {
/*  59 */     this.mLocalName = localName;
/*  60 */     this.mPrefix = ((prefix != null) && (prefix.length() == 0) ? null : prefix);
/*     */     
/*  62 */     this.mHash = 0;
/*  63 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */   public String getPrefix() { return this.mPrefix; }
/*     */   
/*  74 */   public String getLocalName() { return this.mLocalName; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isaNsDeclaration()
/*     */   {
/*  82 */     if (this.mPrefix == null) {
/*  83 */       return this.mLocalName == "xmlns";
/*     */     }
/*  85 */     return this.mPrefix == "xmlns";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isXmlReservedAttr(boolean nsAware, String localName)
/*     */   {
/*  97 */     if (nsAware) {
/*  98 */       if ("xml" == this.mPrefix) {
/*  99 */         return this.mLocalName == localName;
/*     */       }
/*     */     }
/* 102 */     else if (this.mLocalName.length() == 4 + localName.length()) {
/* 103 */       return (this.mLocalName.startsWith("xml:")) && (this.mLocalName.endsWith(localName));
/*     */     }
/*     */     
/*     */ 
/* 107 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 118 */     if ((this.mPrefix == null) || (this.mPrefix.length() == 0)) {
/* 119 */       return this.mLocalName;
/*     */     }
/* 121 */     StringBuffer sb = new StringBuffer(this.mPrefix.length() + 1 + this.mLocalName.length());
/* 122 */     sb.append(this.mPrefix);
/* 123 */     sb.append(':');
/* 124 */     sb.append(this.mLocalName);
/* 125 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public boolean equals(Object o)
/*     */   {
/* 130 */     if (o == this) {
/* 131 */       return true;
/*     */     }
/* 133 */     if (!(o instanceof NameKey)) {
/* 134 */       return false;
/*     */     }
/* 136 */     NameKey other = (NameKey)o;
/*     */     
/* 138 */     if (this.mLocalName != other.mLocalName) {
/* 139 */       return false;
/*     */     }
/* 141 */     return this.mPrefix == other.mPrefix;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 145 */     int hash = this.mHash;
/*     */     
/* 147 */     if (hash == 0) {
/* 148 */       hash = this.mLocalName.hashCode();
/* 149 */       if (this.mPrefix != null) {
/* 150 */         hash ^= this.mPrefix.hashCode();
/*     */       }
/* 152 */       this.mHash = hash;
/*     */     }
/* 154 */     return hash;
/*     */   }
/*     */   
/*     */   public int compareTo(Object o)
/*     */   {
/* 159 */     NameKey other = (NameKey)o;
/*     */     
/*     */ 
/* 162 */     String op = other.mPrefix;
/*     */     
/*     */ 
/* 165 */     if ((op == null) || (op.length() == 0)) {
/* 166 */       if ((this.mPrefix != null) && (this.mPrefix.length() > 0))
/* 167 */         return 1;
/*     */     } else {
/* 169 */       if ((this.mPrefix == null) || (this.mPrefix.length() == 0)) {
/* 170 */         return -1;
/*     */       }
/* 172 */       int result = this.mPrefix.compareTo(op);
/* 173 */       if (result != 0) {
/* 174 */         return result;
/*     */       }
/*     */     }
/*     */     
/* 178 */     return this.mLocalName.compareTo(other.mLocalName);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\NameKey.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */