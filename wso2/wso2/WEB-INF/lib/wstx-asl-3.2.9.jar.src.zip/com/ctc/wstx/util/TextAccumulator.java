/*    */ package com.ctc.wstx.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TextAccumulator
/*    */ {
/*  9 */   private String mText = null;
/*    */   
/* 11 */   private StringBuffer mBuilder = null;
/*    */   
/*    */ 
/*    */   public boolean hasText()
/*    */   {
/* 16 */     return (this.mBuilder != null) || (this.mText != null);
/*    */   }
/*    */   
/*    */   public void addText(String text)
/*    */   {
/* 21 */     int len = text.length();
/* 22 */     if (len > 0)
/*    */     {
/* 24 */       if (this.mText != null) {
/* 25 */         this.mBuilder = new StringBuffer(this.mText.length() + len);
/* 26 */         this.mBuilder.append(this.mText);
/* 27 */         this.mText = null;
/*    */       }
/* 29 */       if (this.mBuilder != null) {
/* 30 */         this.mBuilder.append(text);
/*    */       } else {
/* 32 */         this.mText = text;
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void addText(char[] buf, int start, int end)
/*    */   {
/* 39 */     int len = end - start;
/* 40 */     if (len > 0)
/*    */     {
/* 42 */       if (this.mText != null) {
/* 43 */         this.mBuilder = new StringBuffer(this.mText.length() + len);
/* 44 */         this.mBuilder.append(buf, start, end - start);
/* 45 */         this.mText = null;
/* 46 */       } else if (this.mBuilder == null)
/*    */       {
/*    */ 
/*    */ 
/*    */ 
/* 51 */         this.mBuilder = new StringBuffer(len);
/*    */       }
/* 53 */       this.mBuilder.append(buf, start, end - start);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public String getAndClear()
/*    */   {
/*    */     String result;
/* 61 */     if (this.mText != null) {
/* 62 */       String result = this.mText;
/* 63 */       this.mText = null;
/* 64 */     } else if (this.mBuilder != null) {
/* 65 */       String result = this.mBuilder.toString();
/* 66 */       this.mBuilder = null;
/*    */     } else {
/* 68 */       result = "";
/*    */     }
/* 70 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\util\TextAccumulator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */