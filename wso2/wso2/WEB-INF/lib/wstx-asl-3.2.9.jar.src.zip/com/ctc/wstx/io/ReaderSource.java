/*     */ package com.ctc.wstx.io;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReaderSource
/*     */   extends BaseInputSource
/*     */ {
/*     */   final ReaderConfig mConfig;
/*     */   Reader mReader;
/*     */   final boolean mDoRealClose;
/*  28 */   int mInputProcessed = 0;
/*  29 */   int mInputRow = 1;
/*  30 */   int mInputRowStart = 0;
/*     */   
/*     */ 
/*     */ 
/*     */   public ReaderSource(ReaderConfig cfg, WstxInputSource parent, String fromEntity, String pubId, String sysId, URL src, Reader r, boolean realClose)
/*     */   {
/*  36 */     super(parent, fromEntity, pubId, sysId, src);
/*  37 */     this.mConfig = cfg;
/*  38 */     this.mReader = r;
/*  39 */     this.mDoRealClose = realClose;
/*  40 */     int bufSize = cfg.getInputBufferLength();
/*  41 */     this.mBuffer = cfg.allocFullCBuffer(bufSize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInputOffsets(int proc, int row, int rowStart)
/*     */   {
/*  51 */     this.mInputProcessed = proc;
/*  52 */     this.mInputRow = row;
/*  53 */     this.mInputRowStart = rowStart;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doInitInputLocation(WstxInputData reader)
/*     */   {
/*  62 */     reader.mCurrInputProcessed = this.mInputProcessed;
/*  63 */     reader.mCurrInputRow = this.mInputRow;
/*  64 */     reader.mCurrInputRowStart = this.mInputRowStart;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fromInternalEntity()
/*     */   {
/*  72 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int readInto(WstxInputData reader)
/*     */     throws IOException
/*     */   {
/*  81 */     if (this.mBuffer == null) {
/*  82 */       return -1;
/*     */     }
/*  84 */     int count = this.mReader.read(this.mBuffer, 0, this.mBuffer.length);
/*  85 */     if (count < 1)
/*     */     {
/*     */ 
/*     */ 
/*  89 */       this.mInputLen = 0;
/*  90 */       reader.mInputPtr = 0;
/*  91 */       reader.mInputLen = 0;
/*  92 */       if (count == 0)
/*     */       {
/*     */ 
/*     */ 
/*  96 */         throw new IOException("Reader returned 0 characters, even when asked to read up to " + this.mBuffer.length);
/*     */       }
/*  98 */       return -1;
/*     */     }
/* 100 */     reader.mInputBuffer = this.mBuffer;
/* 101 */     reader.mInputPtr = 0;
/* 102 */     this.mInputLen = count;
/* 103 */     reader.mInputLen = count;
/*     */     
/* 105 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean readMore(WstxInputData reader, int minAmount)
/*     */     throws IOException
/*     */   {
/* 114 */     if (this.mBuffer == null) {
/* 115 */       return false;
/*     */     }
/*     */     
/* 118 */     int ptr = reader.mInputPtr;
/* 119 */     int currAmount = this.mInputLen - ptr;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 127 */     reader.mCurrInputProcessed += ptr;
/* 128 */     reader.mCurrInputRowStart -= ptr;
/*     */     
/*     */ 
/* 131 */     if (currAmount > 0) {
/* 132 */       System.arraycopy(this.mBuffer, ptr, this.mBuffer, 0, currAmount);
/* 133 */       minAmount -= currAmount;
/*     */     }
/* 135 */     reader.mInputBuffer = this.mBuffer;
/* 136 */     reader.mInputPtr = 0;
/* 137 */     this.mInputLen = currAmount;
/*     */     
/* 139 */     while (minAmount > 0) {
/* 140 */       int amount = this.mBuffer.length - currAmount;
/* 141 */       int actual = this.mReader.read(this.mBuffer, currAmount, amount);
/* 142 */       if (actual < 1) {
/* 143 */         if (actual == 0) {
/* 144 */           throw new IOException("Reader returned 0 characters, even when asked to read up to " + amount);
/*     */         }
/* 146 */         reader.mInputLen = (this.mInputLen = currAmount);
/* 147 */         return false;
/*     */       }
/* 149 */       currAmount += actual;
/* 150 */       minAmount -= actual;
/*     */     }
/* 152 */     reader.mInputLen = (this.mInputLen = currAmount);
/* 153 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 162 */     if (this.mBuffer != null) {
/* 163 */       closeAndRecycle(this.mDoRealClose);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void closeCompletely()
/*     */     throws IOException
/*     */   {
/* 173 */     if (this.mReader != null) {
/* 174 */       closeAndRecycle(true);
/*     */     }
/*     */   }
/*     */   
/*     */   private void closeAndRecycle(boolean fullClose)
/*     */     throws IOException
/*     */   {
/* 181 */     char[] buf = this.mBuffer;
/*     */     
/*     */ 
/* 184 */     if (buf != null) {
/* 185 */       this.mBuffer = null;
/* 186 */       this.mConfig.freeFullCBuffer(buf);
/*     */     }
/*     */     
/*     */ 
/* 190 */     if (this.mReader != null) {
/* 191 */       if ((this.mReader instanceof BaseReader)) {
/* 192 */         ((BaseReader)this.mReader).freeBuffers();
/*     */       }
/* 194 */       if (fullClose) {
/* 195 */         Reader r = this.mReader;
/* 196 */         this.mReader = null;
/* 197 */         r.close();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\io\ReaderSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */