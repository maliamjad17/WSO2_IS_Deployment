/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ import com.ctc.wstx.util.ExceptionUtil;
/*     */ import javax.xml.stream.Location;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ElementIdMap
/*     */ {
/*     */   protected static final int DEFAULT_SIZE = 128;
/*     */   protected static final int MIN_SIZE = 16;
/*     */   protected static final int FILL_PCT = 80;
/*     */   protected ElementId[] mTable;
/*     */   protected int mSize;
/*     */   protected int mSizeThreshold;
/*     */   protected int mIndexMask;
/*     */   protected ElementId mHead;
/*     */   protected ElementId mTail;
/*     */   
/*     */   public ElementIdMap()
/*     */   {
/*  97 */     this(128);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ElementIdMap(int initialSize)
/*     */   {
/* 106 */     int actual = 16;
/* 107 */     while (actual < initialSize) {
/* 108 */       actual += actual;
/*     */     }
/* 110 */     this.mTable = new ElementId[actual];
/*     */     
/* 112 */     this.mIndexMask = (actual - 1);
/* 113 */     this.mSize = 0;
/* 114 */     this.mSizeThreshold = (actual * 80 / 100);
/* 115 */     this.mHead = (this.mTail = null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ElementId getFirstUndefined()
/*     */   {
/* 130 */     return this.mHead;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ElementId addReferenced(char[] buffer, int start, int len, int hash, Location loc, NameKey elemName, NameKey attrName)
/*     */   {
/* 141 */     int index = hash & this.mIndexMask;
/* 142 */     ElementId id = this.mTable[index];
/*     */     
/* 144 */     while (id != null) {
/* 145 */       if (id.idMatches(buffer, start, len)) {
/* 146 */         return id;
/*     */       }
/* 148 */       id = id.mNextColl;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 154 */     if (this.mSize >= this.mSizeThreshold) {
/* 155 */       rehash();
/*     */       
/* 157 */       index = hash & this.mIndexMask;
/*     */     }
/* 159 */     this.mSize += 1;
/*     */     
/*     */ 
/* 162 */     String idStr = new String(buffer, start, len);
/* 163 */     id = new ElementId(idStr, loc, false, elemName, attrName);
/*     */     
/*     */ 
/* 166 */     id.mNextColl = this.mTable[index];
/* 167 */     this.mTable[index] = id;
/*     */     
/*     */ 
/* 170 */     if (this.mHead == null) {
/* 171 */       this.mHead = (this.mTail = id);
/*     */     } else {
/* 173 */       this.mTail.mNextUndefd = id;
/* 174 */       this.mTail = id;
/*     */     }
/* 176 */     return id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ElementId addDefined(char[] buffer, int start, int len, int hash, Location loc, NameKey elemName, NameKey attrName)
/*     */   {
/* 190 */     int index = hash & this.mIndexMask;
/* 191 */     ElementId id = this.mTable[index];
/*     */     
/* 193 */     while ((id != null) && 
/* 194 */       (!id.idMatches(buffer, start, len)))
/*     */     {
/*     */ 
/* 197 */       id = id.mNextColl;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 203 */     if (id == null)
/*     */     {
/* 205 */       if (this.mSize >= this.mSizeThreshold) {
/* 206 */         rehash();
/* 207 */         index = hash & this.mIndexMask;
/*     */       }
/* 209 */       this.mSize += 1;
/* 210 */       String idStr = new String(buffer, start, len);
/* 211 */       id = new ElementId(idStr, loc, true, elemName, attrName);
/* 212 */       id.mNextColl = this.mTable[index];
/* 213 */       this.mTable[index] = id;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/* 219 */     else if (!id.mDefined)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 225 */       id.markDefined(loc);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 230 */       if (id == this.mHead) {
/*     */         do {
/* 232 */           this.mHead = this.mHead.mNextUndefd;
/* 233 */         } while ((this.mHead != null) && (this.mHead.mDefined));
/*     */         
/*     */ 
/* 236 */         if (this.mHead == null) {
/* 237 */           this.mTail = null;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 243 */     return id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int calcHash(char[] buffer, int start, int len)
/*     */   {
/* 260 */     int hash = buffer[0];
/* 261 */     for (int i = 1; i < len; i++) {
/* 262 */       hash = hash * 31 + buffer[i];
/*     */     }
/* 264 */     return hash;
/*     */   }
/*     */   
/*     */   public static int calcHash(String key) {
/* 268 */     int hash = key.charAt(0);
/* 269 */     int i = 1; for (int len = key.length(); i < len; i++) {
/* 270 */       hash = hash * 31 + key.charAt(i);
/*     */     }
/*     */     
/* 273 */     return hash;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void rehash()
/*     */   {
/* 291 */     int size = this.mTable.length;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 297 */     int newSize = size << 2;
/* 298 */     ElementId[] oldSyms = this.mTable;
/* 299 */     this.mTable = new ElementId[newSize];
/*     */     
/*     */ 
/* 302 */     this.mIndexMask = (newSize - 1);
/* 303 */     this.mSizeThreshold <<= 2;
/*     */     
/* 305 */     int count = 0;
/*     */     ElementId id;
/* 307 */     for (int i = 0; i < size; i++) {
/* 308 */       for (id = oldSyms[i]; id != null;) {
/* 309 */         count++;
/* 310 */         int index = calcHash(id.mIdValue) & this.mIndexMask;
/* 311 */         ElementId nextIn = id.mNextColl;
/* 312 */         id.mNextColl = this.mTable[index];
/* 313 */         this.mTable[index] = id;
/* 314 */         id = nextIn;
/*     */       }
/*     */     }
/*     */     
/* 318 */     if (count != this.mSize) {
/* 319 */       ExceptionUtil.throwInternal("on rehash(): had " + this.mSize + " entries; now have " + count + ".");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\ElementIdMap.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */