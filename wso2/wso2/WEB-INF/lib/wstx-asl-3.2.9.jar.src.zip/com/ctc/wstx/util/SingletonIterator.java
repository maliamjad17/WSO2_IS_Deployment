/*    */ package com.ctc.wstx.util;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SingletonIterator
/*    */   implements Iterator
/*    */ {
/*    */   private final Object mValue;
/* 15 */   private boolean mDone = false;
/*    */   
/*    */   public SingletonIterator(Object value) {
/* 18 */     this.mValue = value;
/*    */   }
/*    */   
/*    */   public boolean hasNext() {
/* 22 */     return !this.mDone;
/*    */   }
/*    */   
/*    */   public Object next() {
/* 26 */     if (this.mDone) {
/* 27 */       throw new NoSuchElementException();
/*    */     }
/* 29 */     this.mDone = true;
/* 30 */     return this.mValue;
/*    */   }
/*    */   
/*    */   public void remove() {
/* 34 */     throw new UnsupportedOperationException("Can not remove item from SingletonIterator.");
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\util\SingletonIterator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */