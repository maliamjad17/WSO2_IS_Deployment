/*     */ package com.ctc.wstx.sax;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import com.ctc.wstx.stax.WstxInputFactory;
/*     */ import java.io.PrintStream;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import org.xml.sax.SAXNotRecognizedException;
/*     */ import org.xml.sax.SAXNotSupportedException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WstxSAXParserFactory
/*     */   extends SAXParserFactory
/*     */ {
/*     */   final WstxInputFactory mStaxFactory;
/*  45 */   boolean mFeatNsPrefixes = false;
/*     */   
/*     */   public WstxSAXParserFactory()
/*     */   {
/*  49 */     this.mStaxFactory = new WstxInputFactory();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  54 */     setNamespaceAware(true);
/*     */   }
/*     */   
/*     */   public boolean getFeature(String name)
/*     */     throws SAXNotRecognizedException, SAXNotSupportedException
/*     */   {
/*  60 */     SAXFeature stdFeat = SAXFeature.findByUri(name);
/*     */     
/*  62 */     if (stdFeat == SAXFeature.EXTERNAL_GENERAL_ENTITIES)
/*  63 */       return this.mStaxFactory.getConfig().willSupportExternalEntities();
/*  64 */     if (stdFeat == SAXFeature.EXTERNAL_PARAMETER_ENTITIES)
/*  65 */       return this.mStaxFactory.getConfig().willSupportExternalEntities();
/*  66 */     if (stdFeat == SAXFeature.IS_STANDALONE)
/*     */     {
/*  68 */       return false; }
/*  69 */     if (stdFeat == SAXFeature.LEXICAL_HANDLER_PARAMETER_ENTITIES)
/*     */     {
/*  71 */       return false; }
/*  72 */     if (stdFeat == SAXFeature.NAMESPACES)
/*  73 */       return this.mStaxFactory.getConfig().willSupportNamespaces();
/*  74 */     if (stdFeat == SAXFeature.NAMESPACE_PREFIXES)
/*  75 */       return this.mFeatNsPrefixes;
/*  76 */     if (stdFeat == SAXFeature.RESOLVE_DTD_URIS)
/*     */     {
/*  78 */       return false; }
/*  79 */     if (stdFeat == SAXFeature.STRING_INTERNING)
/*  80 */       return true;
/*  81 */     if (stdFeat == SAXFeature.UNICODE_NORMALIZATION_CHECKING)
/*  82 */       return false;
/*  83 */     if (stdFeat == SAXFeature.USE_ATTRIBUTES2)
/*  84 */       return true;
/*  85 */     if (stdFeat == SAXFeature.USE_LOCATOR2)
/*  86 */       return true;
/*  87 */     if (stdFeat == SAXFeature.USE_ENTITY_RESOLVER2)
/*  88 */       return true;
/*  89 */     if (stdFeat == SAXFeature.VALIDATION)
/*  90 */       return this.mStaxFactory.getConfig().willValidateWithDTD();
/*  91 */     if (stdFeat == SAXFeature.XMLNS_URIS)
/*     */     {
/*     */ 
/*     */ 
/*  95 */       return true; }
/*  96 */     if (stdFeat == SAXFeature.XML_1_1) {
/*  97 */       return true;
/*     */     }
/*  99 */     throw new SAXNotRecognizedException("Feature '" + name + "' not recognized");
/*     */   }
/*     */   
/*     */ 
/*     */   public SAXParser newSAXParser()
/*     */   {
/* 105 */     return new WstxSAXParser(this.mStaxFactory, this.mFeatNsPrefixes);
/*     */   }
/*     */   
/*     */   public void setFeature(String name, boolean value)
/*     */     throws SAXNotRecognizedException, SAXNotSupportedException
/*     */   {
/* 111 */     boolean invalidValue = false;
/* 112 */     boolean readOnly = false;
/* 113 */     SAXFeature stdFeat = SAXFeature.findByUri(name);
/*     */     
/* 115 */     if (stdFeat == SAXFeature.EXTERNAL_GENERAL_ENTITIES) {
/* 116 */       this.mStaxFactory.getConfig().doSupportExternalEntities(value);
/* 117 */     } else if (stdFeat != SAXFeature.EXTERNAL_PARAMETER_ENTITIES)
/*     */     {
/* 119 */       if (stdFeat == SAXFeature.IS_STANDALONE) {
/* 120 */         readOnly = true;
/* 121 */       } else if (stdFeat != SAXFeature.LEXICAL_HANDLER_PARAMETER_ENTITIES)
/*     */       {
/* 123 */         if (stdFeat == SAXFeature.NAMESPACES) {
/* 124 */           this.mStaxFactory.getConfig().doSupportNamespaces(value);
/* 125 */         } else if (stdFeat == SAXFeature.NAMESPACE_PREFIXES) {
/* 126 */           this.mFeatNsPrefixes = value;
/* 127 */         } else if (stdFeat != SAXFeature.RESOLVE_DTD_URIS)
/*     */         {
/* 129 */           if (stdFeat == SAXFeature.STRING_INTERNING) {
/* 130 */             invalidValue = !value;
/* 131 */           } else if (stdFeat == SAXFeature.UNICODE_NORMALIZATION_CHECKING) {
/* 132 */             invalidValue = value;
/* 133 */           } else if (stdFeat == SAXFeature.USE_ATTRIBUTES2) {
/* 134 */             readOnly = true;
/* 135 */           } else if (stdFeat == SAXFeature.USE_LOCATOR2) {
/* 136 */             readOnly = true;
/* 137 */           } else if (stdFeat == SAXFeature.USE_ENTITY_RESOLVER2) {
/* 138 */             readOnly = true;
/* 139 */           } else if (stdFeat == SAXFeature.VALIDATION) {
/* 140 */             this.mStaxFactory.getConfig().doValidateWithDTD(value);
/* 141 */           } else if (stdFeat == SAXFeature.XMLNS_URIS) {
/* 142 */             invalidValue = !value;
/* 143 */           } else if (stdFeat == SAXFeature.XML_1_1) {
/* 144 */             readOnly = true;
/*     */           } else
/* 146 */             throw new SAXNotRecognizedException("Feature '" + name + "' not recognized");
/*     */         }
/*     */       }
/*     */     }
/* 150 */     if (readOnly) {
/* 151 */       throw new SAXNotSupportedException("Feature '" + name + "' is read-only, can not be modified");
/*     */     }
/* 153 */     if (invalidValue) {
/* 154 */       throw new SAXNotSupportedException("Trying to set invalid value for feature '" + name + "', '" + value + "'");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 166 */     WstxSAXParserFactory f = new WstxSAXParserFactory();
/*     */     
/* 168 */     System.out.println("Ns -> " + f.isNamespaceAware());
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sax\WstxSAXParserFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */