/*     */ package com.ctc.wstx.io;
/*     */ 
/*     */ import com.ctc.wstx.util.StringUtil;
/*     */ import javax.xml.stream.Location;
/*     */ import org.codehaus.stax2.XMLStreamLocation2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WstxInputLocation
/*     */   implements XMLStreamLocation2
/*     */ {
/*  30 */   private static final WstxInputLocation sEmptyLocation = new WstxInputLocation(null, "", "", -1, -1, -1);
/*     */   
/*     */   final WstxInputLocation mContext;
/*     */   
/*     */   final String mPublicId;
/*     */   
/*     */   final String mSystemId;
/*     */   
/*     */   final int mCharOffset;
/*     */   
/*     */   final int mCol;
/*     */   
/*     */   final int mRow;
/*     */   
/*  44 */   transient String mDesc = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WstxInputLocation(WstxInputLocation ctxt, String pubId, String sysId, int charOffset, int row, int col)
/*     */   {
/*  53 */     this.mContext = ctxt;
/*  54 */     this.mPublicId = pubId;
/*  55 */     this.mSystemId = sysId;
/*     */     
/*     */ 
/*     */ 
/*  59 */     this.mCharOffset = (charOffset < 0 ? Integer.MAX_VALUE : charOffset);
/*  60 */     this.mCol = col;
/*  61 */     this.mRow = row;
/*     */   }
/*     */   
/*     */   public static WstxInputLocation getEmptyLocation() {
/*  65 */     return sEmptyLocation;
/*     */   }
/*     */   
/*  68 */   public int getCharacterOffset() { return this.mCharOffset; }
/*  69 */   public int getColumnNumber() { return this.mCol; }
/*  70 */   public int getLineNumber() { return this.mRow; }
/*     */   
/*  72 */   public String getPublicId() { return this.mPublicId; }
/*  73 */   public String getSystemId() { return this.mSystemId; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLStreamLocation2 getContext()
/*     */   {
/*  81 */     return this.mContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  91 */     if (this.mDesc == null) { StringBuffer sb;
/*     */       StringBuffer sb;
/*  93 */       if (this.mContext != null) {
/*  94 */         sb = new StringBuffer(200);
/*     */       } else {
/*  96 */         sb = new StringBuffer(80);
/*     */       }
/*  98 */       appendDesc(sb);
/*  99 */       this.mDesc = sb.toString();
/*     */     }
/* 101 */     return this.mDesc;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 105 */     return this.mCharOffset ^ this.mRow ^ this.mCol + (this.mCol << 3);
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 109 */     if (!(o instanceof Location)) {
/* 110 */       return false;
/*     */     }
/* 112 */     Location other = (Location)o;
/*     */     
/* 114 */     if (other.getCharacterOffset() != getCharacterOffset()) {
/* 115 */       return false;
/*     */     }
/* 117 */     String otherPub = other.getPublicId();
/* 118 */     if (otherPub == null) {
/* 119 */       otherPub = "";
/*     */     }
/* 121 */     if (!otherPub.equals(this.mPublicId)) {
/* 122 */       return false;
/*     */     }
/* 124 */     String otherSys = other.getSystemId();
/* 125 */     if (otherSys == null) {
/* 126 */       otherSys = "";
/*     */     }
/* 128 */     return otherSys.equals(this.mSystemId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void appendDesc(StringBuffer sb)
/*     */   {
/*     */     String srcId;
/*     */     
/*     */ 
/*     */     String srcId;
/*     */     
/*     */ 
/* 141 */     if (this.mSystemId != null) {
/* 142 */       sb.append("[row,col,system-id]: ");
/* 143 */       srcId = this.mSystemId; } else { String srcId;
/* 144 */       if (this.mPublicId != null) {
/* 145 */         sb.append("[row,col,public-id]: ");
/* 146 */         srcId = this.mPublicId;
/*     */       } else {
/* 148 */         sb.append("[row,col {unknown-source}]: ");
/* 149 */         srcId = null;
/*     */       } }
/* 151 */     sb.append('[');
/* 152 */     sb.append(this.mRow);
/* 153 */     sb.append(',');
/* 154 */     sb.append(this.mCol);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 160 */     if (srcId != null) {
/* 161 */       sb.append(',');
/* 162 */       sb.append('"');
/* 163 */       sb.append(srcId);
/* 164 */       sb.append('"');
/*     */     }
/* 166 */     sb.append(']');
/* 167 */     if (this.mContext != null) {
/* 168 */       StringUtil.appendLF(sb);
/* 169 */       sb.append(" from ");
/* 170 */       this.mContext.appendDesc(sb);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\io\WstxInputLocation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */