/*     */ package com.ctc.wstx.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UTFAttrValueWriter
/*     */   extends WriterBase
/*     */ {
/*     */   private final boolean mEscapeCR;
/*     */   final char mQuoteChar;
/*     */   final String mQuoteEntity;
/*     */   
/*     */   public UTFAttrValueWriter(Writer out, String enc, char qchar, boolean escapeCR)
/*     */   {
/*  36 */     super(out);
/*  37 */     this.mEscapeCR = escapeCR;
/*  38 */     this.mQuoteChar = qchar;
/*  39 */     this.mQuoteEntity = getQuoteEntity(qchar);
/*     */   }
/*     */   
/*     */   public void write(int c)
/*     */     throws IOException
/*     */   {
/*  45 */     if (c <= 60) {
/*  46 */       if (c == this.mQuoteChar) {
/*  47 */         this.out.write(this.mQuoteEntity);
/*  48 */         return;
/*     */       }
/*  50 */       if (c == 60) {
/*  51 */         this.out.write("&lt;");
/*  52 */         return;
/*     */       }
/*  54 */       if (c == 38) {
/*  55 */         this.out.write("&amp;");
/*  56 */         return;
/*     */       }
/*  58 */       if ((c == 13) && (this.mEscapeCR)) {
/*  59 */         this.out.write("&#13;");
/*  60 */         return;
/*     */       }
/*  62 */       if (c < 32) {
/*  63 */         if (c == 0) {
/*  64 */           throwNullChar();
/*     */         } else {
/*  66 */           writeAsEntity(c);
/*  67 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  72 */     this.out.write(c);
/*     */   }
/*     */   
/*     */   public void write(char[] cbuf, int offset, int len) throws IOException
/*     */   {
/*  77 */     len += offset;
/*  78 */     char qchar = this.mQuoteChar;
/*     */     do {
/*  80 */       int start = offset;
/*  81 */       char c = '\000';
/*  82 */       String ent = null;
/*  84 */       for (; 
/*  84 */           offset < len; offset++) {
/*  85 */         c = cbuf[offset];
/*  86 */         if (c <= '<') {
/*  87 */           if (c == qchar) {
/*  88 */             ent = this.mQuoteEntity;
/*  89 */             break;
/*     */           }
/*  91 */           if (c == '<') {
/*  92 */             ent = "&lt;";
/*  93 */             break;
/*     */           }
/*  95 */           if (c == '&') {
/*  96 */             ent = "&amp;";
/*  97 */             break;
/*     */           }
/*  99 */           if ((c == '\r') && (this.mEscapeCR)) {
/* 100 */             ent = "&#13;";
/* 101 */             break;
/*     */           }
/* 103 */           if (c < ' ') {
/* 104 */             if (c != 0) break;
/* 105 */             throwNullChar(); break;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 111 */       int outLen = offset - start;
/* 112 */       if (outLen > 0) {
/* 113 */         this.out.write(cbuf, start, outLen);
/*     */       }
/* 115 */       if (ent != null) {
/* 116 */         this.out.write(ent);
/* 117 */         ent = null;
/* 118 */       } else if (offset < len) {
/* 119 */         writeAsEntity(c);
/*     */       }
/* 121 */       offset++; } while (offset < len);
/*     */   }
/*     */   
/*     */   public void write(String str, int offset, int len) throws IOException
/*     */   {
/* 126 */     len += offset;
/* 127 */     char qchar = this.mQuoteChar;
/*     */     do {
/* 129 */       int start = offset;
/* 130 */       char c = '\000';
/* 131 */       String ent = null;
/* 133 */       for (; 
/* 133 */           offset < len; offset++) {
/* 134 */         c = str.charAt(offset);
/* 135 */         if (c <= '<') {
/* 136 */           if (c == qchar) {
/* 137 */             ent = this.mQuoteEntity;
/* 138 */             break;
/*     */           }
/* 140 */           if (c == '<') {
/* 141 */             ent = "&lt;";
/* 142 */             break;
/*     */           }
/* 144 */           if (c == '&') {
/* 145 */             ent = "&amp;";
/* 146 */             break;
/*     */           }
/* 148 */           if ((c == '\r') && (this.mEscapeCR)) {
/* 149 */             ent = "&#13;";
/* 150 */             break;
/*     */           }
/* 152 */           if (c < ' ') {
/* 153 */             if (c != 0) break;
/* 154 */             throwNullChar(); break;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 160 */       int outLen = offset - start;
/* 161 */       if (outLen > 0) {
/* 162 */         this.out.write(str, start, outLen);
/*     */       }
/* 164 */       if (ent != null) {
/* 165 */         this.out.write(ent);
/* 166 */         ent = null;
/* 167 */       } else if (offset < len) {
/* 168 */         writeAsEntity(c);
/*     */       }
/* 170 */       offset++; } while (offset < len);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\io\UTFAttrValueWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */