/*     */ package com.ctc.wstx.sr;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import com.ctc.wstx.sw.XmlWriter;
/*     */ import com.ctc.wstx.util.DataUtil;
/*     */ import com.ctc.wstx.util.StringVector;
/*     */ import com.ctc.wstx.util.TextBuilder;
/*     */ import java.io.IOException;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NonNsAttributeCollector
/*     */   extends AttributeCollector
/*     */ {
/*  30 */   protected static final String DEFAULT_NS_URI = null;
/*     */   
/*  32 */   protected static final String DEFAULT_PREFIX = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NonNsAttributeCollector(ReaderConfig cfg)
/*     */   {
/*  42 */     super(cfg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/*  51 */     if (this.mAttrCount > 0) {
/*  52 */       this.mAttrNames.clear(false);
/*  53 */       this.mValueBuffer.reset();
/*  54 */       this.mAttrCount = 0;
/*  55 */       if (this.mXmlIdAttrIndex >= 0) {
/*  56 */         this.mXmlIdAttrIndex = -1;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int resolveValues(InputProblemReporter rep)
/*     */     throws XMLStreamException
/*     */   {
/*  76 */     int attrCount = this.mAttrCount;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  81 */     this.mNonDefCount = attrCount;
/*     */     
/*  83 */     if (attrCount < 1)
/*     */     {
/*  85 */       this.mAttrHashSize = 0;
/*     */       
/*  87 */       return this.mXmlIdAttrIndex;
/*     */     }
/*  89 */     String[] attrNames = this.mAttrNames.getInternalArray();
/*     */     
/*     */ 
/*  92 */     if (this.mAttrValues != null)
/*     */     {
/*  94 */       if (this.mAttrValues.length < attrCount) {
/*  95 */         this.mAttrValues = null;
/*     */       }
/*     */       else {
/*  98 */         for (int i = 0; i < attrCount; i++) {
/*  99 */           this.mAttrValues[i] = null;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 109 */     int[] map = this.mAttrMap;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 114 */     int hashCount = 4;
/*     */     
/* 116 */     int min = attrCount + (attrCount >> 2);
/* 117 */     while (hashCount < min) {
/* 118 */       hashCount += hashCount;
/*     */     }
/*     */     
/* 121 */     this.mAttrHashSize = hashCount;
/* 122 */     min = hashCount + (hashCount >> 4);
/* 123 */     if ((map == null) || (map.length < min)) {
/* 124 */       map = new int[min];
/*     */     } else {
/* 126 */       for (int i = 0; i < hashCount; i++) {
/* 127 */         map[i] = 0;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 133 */     int mask = hashCount - 1;
/* 134 */     int spillIndex = hashCount;
/*     */     
/*     */ 
/* 137 */     for (int i = 0; i < attrCount; i++) {
/* 138 */       String name = attrNames[i];
/* 139 */       int hash = name.hashCode();
/* 140 */       int index = hash & mask;
/*     */       
/* 142 */       if (map[index] == 0) {
/* 143 */         map[index] = (i + 1);
/*     */       } else {
/* 145 */         int currIndex = map[index] - 1;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 150 */         map = spillAttr(name, map, currIndex, spillIndex, attrCount, hash, hashCount);
/*     */         
/* 152 */         if (map == null) {
/* 153 */           throwDupAttr(rep, currIndex);
/*     */         }
/*     */         else {
/* 156 */           map[(++spillIndex)] = i;
/* 157 */           spillIndex++;
/*     */         }
/*     */       }
/*     */     }
/* 161 */     this.mAttrSpillEnd = spillIndex;
/*     */     
/* 163 */     this.mAttrMap = map;
/*     */     
/* 165 */     return this.mXmlIdAttrIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNsCount()
/*     */   {
/* 175 */     return 0;
/*     */   }
/*     */   
/*     */   public String getNsPrefix(int index) {
/* 179 */     return DEFAULT_PREFIX;
/*     */   }
/*     */   
/*     */   public String getNsURI(int index) {
/* 183 */     return DEFAULT_NS_URI;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getPrefix(int index)
/*     */   {
/* 189 */     if ((index < 0) || (index >= this.mAttrCount)) {
/* 190 */       throwIndex(index);
/*     */     }
/* 192 */     return DEFAULT_PREFIX;
/*     */   }
/*     */   
/*     */   public String getLocalName(int index) {
/* 196 */     if ((index < 0) || (index >= this.mAttrCount)) {
/* 197 */       throwIndex(index);
/*     */     }
/* 199 */     return this.mAttrNames.getString(index);
/*     */   }
/*     */   
/*     */   public String getURI(int index)
/*     */   {
/* 204 */     if ((index < 0) || (index >= this.mAttrCount)) {
/* 205 */       throwIndex(index);
/*     */     }
/* 207 */     return DEFAULT_NS_URI;
/*     */   }
/*     */   
/*     */   public QName getQName(int index) {
/* 211 */     return new QName(getLocalName(index));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getValue(String nsURI, String localName)
/*     */   {
/* 219 */     if ((nsURI != null) && (nsURI.length() > 0)) {
/* 220 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 224 */     int hashSize = this.mAttrHashSize;
/* 225 */     if (hashSize == 0) {
/* 226 */       return null;
/*     */     }
/* 228 */     int hash = localName.hashCode();
/* 229 */     int ix = this.mAttrMap[(hash & hashSize - 1)];
/* 230 */     if (ix == 0) {
/* 231 */       return null;
/*     */     }
/* 233 */     ix--;
/*     */     
/*     */ 
/* 236 */     String thisName = this.mAttrNames.getString(ix);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 241 */     if ((thisName == localName) || (thisName.equals(localName))) {
/* 242 */       return getValue(ix);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 248 */     int i = hashSize; for (int len = this.mAttrSpillEnd; i < len; i += 2) {
/* 249 */       if (this.mAttrMap[i] == hash)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 255 */         ix = this.mAttrMap[(i + 1)];
/* 256 */         thisName = this.mAttrNames.getString(ix);
/* 257 */         if ((thisName == localName) || (thisName.equals(localName))) {
/* 258 */           return getValue(ix);
/*     */         }
/*     */       }
/*     */     }
/* 262 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int findIndex(String localName)
/*     */   {
/* 274 */     int hashSize = this.mAttrHashSize;
/* 275 */     if (hashSize == 0) {
/* 276 */       return -1;
/*     */     }
/* 278 */     int hash = localName.hashCode();
/* 279 */     int ix = this.mAttrMap[(hash & hashSize - 1)];
/* 280 */     if (ix == 0) {
/* 281 */       return -1;
/*     */     }
/* 283 */     ix--;
/*     */     
/*     */ 
/* 286 */     String thisName = this.mAttrNames.getString(ix);
/* 287 */     if ((thisName == localName) || (thisName.equals(localName))) {
/* 288 */       return ix;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 294 */     int i = hashSize; for (int len = this.mAttrSpillEnd; i < len; i += 2) {
/* 295 */       if (this.mAttrMap[i] == hash)
/*     */       {
/*     */ 
/* 298 */         ix = this.mAttrMap[(i + 1)];
/* 299 */         thisName = this.mAttrNames.getString(ix);
/* 300 */         if ((thisName == localName) || (thisName.equals(localName)))
/* 301 */           return ix;
/*     */       }
/*     */     }
/* 304 */     return -1;
/*     */   }
/*     */   
/*     */   public TextBuilder getDefaultNsBuilder()
/*     */   {
/* 309 */     throwInternal();
/* 310 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TextBuilder getNsBuilder(String localName)
/*     */   {
/* 319 */     throwInternal();
/* 320 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public TextBuilder getAttrBuilder(String attrPrefix, String attrLocalName)
/*     */   {
/* 326 */     if (this.mAttrCount == 0) {
/* 327 */       if (this.mValueBuffer == null) {
/* 328 */         allocBuffers();
/*     */       }
/* 330 */       this.mAttrCount = 1;
/*     */     } else {
/* 332 */       this.mAttrCount += 1;
/*     */     }
/* 334 */     this.mAttrNames.addString(attrLocalName);
/*     */     
/* 336 */     if ((attrLocalName == "xml:id") && 
/* 337 */       (this.mXmlIdAttrIndex != -2)) {
/* 338 */       this.mXmlIdAttrIndex = (this.mAttrCount - 1);
/*     */     }
/*     */     
/* 341 */     return this.mValueBuffer;
/*     */   }
/*     */   
/*     */   public TextBuilder getNsURIs() {
/* 345 */     throwInternal();
/* 346 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ElemAttrs buildAttrOb()
/*     */   {
/* 356 */     int count = this.mAttrCount;
/* 357 */     if (count == 0) {
/* 358 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 363 */     String[] raw = new String[count << 2];
/* 364 */     for (int i = 0; i < count; i++) {
/* 365 */       int ix = i << 2;
/* 366 */       raw[ix] = this.mAttrNames.getString(i);
/* 367 */       raw[(ix + 1)] = DEFAULT_NS_URI;
/* 368 */       raw[(ix + 2)] = DEFAULT_PREFIX;
/* 369 */       raw[(ix + 3)] = getValue(i);
/*     */     }
/*     */     
/*     */ 
/* 373 */     if (count < 4) {
/* 374 */       return new ElemAttrs(raw, this.mNonDefCount);
/*     */     }
/*     */     
/*     */ 
/* 378 */     return new ElemAttrs(raw, this.mNonDefCount, this.mAttrMap, this.mAttrHashSize, this.mAttrSpillEnd);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int addDefaultAttribute(String localName, String value)
/*     */   {
/* 398 */     int attrIndex = this.mAttrCount;
/* 399 */     if (attrIndex < 1)
/*     */     {
/*     */ 
/*     */ 
/* 403 */       initHashArea();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 410 */     int hash = localName.hashCode();
/* 411 */     int index = hash & this.mAttrHashSize - 1;
/* 412 */     int[] map = this.mAttrMap;
/* 413 */     if (map[index] == 0) {
/* 414 */       map[index] = (attrIndex + 1);
/*     */     } else {
/* 416 */       int currIndex = map[index] - 1;
/* 417 */       int spillIndex = this.mAttrSpillEnd;
/* 418 */       map = spillAttr(localName, map, currIndex, spillIndex, attrIndex, hash, this.mAttrHashSize);
/*     */       
/* 420 */       if (map == null) {
/* 421 */         return -1;
/*     */       }
/* 423 */       map[(++spillIndex)] = attrIndex;
/* 424 */       this.mAttrMap = map;
/* 425 */       this.mAttrSpillEnd = (++spillIndex);
/*     */     }
/*     */     
/*     */ 
/* 429 */     this.mAttrNames.addString(localName);
/* 430 */     if (this.mAttrValues == null) {
/* 431 */       this.mAttrValues = new String[attrIndex + 8];
/* 432 */     } else if (attrIndex >= this.mAttrValues.length) {
/* 433 */       this.mAttrValues = DataUtil.growArrayBy(this.mAttrValues, 8);
/*     */     }
/* 435 */     this.mAttrValues[attrIndex] = value;
/* 436 */     return this.mAttrCount++;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeAttribute(int index, XmlWriter xw)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 447 */     String ln = this.mAttrNames.getString(index);
/* 448 */     xw.writeAttribute(ln, getValue(index));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void throwInternal()
/*     */   {
/* 458 */     throw new Error("Internal error: shouldn't call this method.");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int[] spillAttr(String name, int[] map, int currIndex, int spillIndex, int attrCount, int hash, int hashCount)
/*     */   {
/* 473 */     if (this.mAttrNames.getString(currIndex) == name) {
/* 474 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 480 */     if (spillIndex + 1 >= map.length)
/*     */     {
/* 482 */       map = DataUtil.growArrayBy(map, 8);
/*     */     }
/*     */     
/* 485 */     for (int j = hashCount; j < spillIndex; j += 2) {
/* 486 */       if (map[j] == hash) {
/* 487 */         currIndex = map[(j + 1)];
/* 488 */         if (this.mAttrNames.getString(currIndex) == name) {
/* 489 */           return null;
/*     */         }
/*     */       }
/*     */     }
/* 493 */     map[spillIndex] = hash;
/* 494 */     return map;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initHashArea()
/*     */   {
/* 508 */     this.mAttrHashSize = (this.mAttrSpillEnd = 4);
/* 509 */     if ((this.mAttrMap == null) || (this.mAttrMap.length < this.mAttrHashSize)) {
/* 510 */       this.mAttrMap = new int[this.mAttrHashSize + 1];
/*     */     }
/* 512 */     this.mAttrMap[0] = (this.mAttrMap[1] = this.mAttrMap[2] = this.mAttrMap[3] = 0);
/* 513 */     allocBuffers();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sr\NonNsAttributeCollector.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */