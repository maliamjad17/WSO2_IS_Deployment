/*     */ package com.ctc.wstx.sw;
/*     */ 
/*     */ import com.ctc.wstx.api.WriterConfig;
/*     */ import com.ctc.wstx.cfg.ErrorConsts;
/*     */ import com.ctc.wstx.exc.WstxIOException;
/*     */ import com.ctc.wstx.io.WstxInputData;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ import java.text.MessageFormat;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.codehaus.stax2.io.EscapingWriterFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class XmlWriter
/*     */ {
/*     */   protected static final int SURR1_FIRST = 55296;
/*     */   protected static final int SURR1_LAST = 56319;
/*     */   protected static final int SURR2_FIRST = 56320;
/*     */   protected static final int SURR2_LAST = 57343;
/*     */   protected static final char DEFAULT_QUOTE_CHAR = '"';
/*     */   protected final WriterConfig mConfig;
/*     */   protected final String mEncoding;
/*     */   protected final boolean mNsAware;
/*     */   protected final boolean mCheckStructure;
/*     */   protected final boolean mCheckContent;
/*     */   protected final boolean mCheckNames;
/*     */   protected final boolean mFixContent;
/*     */   final boolean mEscapeCR;
/*     */   protected final boolean mAutoCloseOutput;
/*     */   protected Writer mTextWriter;
/*     */   protected Writer mAttrValueWriter;
/* 121 */   protected boolean mXml11 = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 128 */   protected XmlWriterWrapper mRawWrapper = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 135 */   protected XmlWriterWrapper mTextWrapper = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 146 */   protected int mLocPastChars = 0;
/*     */   
/* 148 */   protected int mLocRowNr = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 154 */   protected int mLocRowStartOffset = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XmlWriter(WriterConfig cfg, String encoding, boolean autoclose)
/*     */     throws IOException
/*     */   {
/* 165 */     this.mConfig = cfg;
/* 166 */     this.mEncoding = encoding;
/* 167 */     this.mAutoCloseOutput = autoclose;
/* 168 */     int flags = cfg.getConfigFlags();
/* 169 */     this.mNsAware = ((flags & 0x1) != 0);
/* 170 */     this.mCheckStructure = ((flags & 0x100) != 0);
/* 171 */     this.mCheckContent = ((flags & 0x200) != 0);
/* 172 */     this.mCheckNames = ((flags & 0x400) != 0);
/* 173 */     this.mFixContent = ((flags & 0x1000) != 0);
/* 174 */     this.mEscapeCR = ((flags & 0x20) != 0);
/*     */     
/*     */ 
/*     */ 
/* 178 */     EscapingWriterFactory f = this.mConfig.getTextEscaperFactory();
/* 179 */     if (f == null) {
/* 180 */       this.mTextWriter = null;
/*     */     } else {
/* 182 */       String enc = (this.mEncoding == null) || (this.mEncoding.length() == 0) ? "UTF-8" : this.mEncoding;
/*     */       
/* 184 */       this.mTextWriter = f.createEscapingWriterFor(wrapAsRawWriter(), enc);
/*     */     }
/*     */     
/* 187 */     f = this.mConfig.getAttrValueEscaperFactory();
/* 188 */     if (f == null) {
/* 189 */       this.mAttrValueWriter = null;
/*     */     } else {
/* 191 */       String enc = (this.mEncoding == null) || (this.mEncoding.length() == 0) ? "UTF-8" : this.mEncoding;
/*     */       
/* 193 */       this.mAttrValueWriter = f.createEscapingWriterFor(wrapAsRawWriter(), enc);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void enableXml11()
/*     */   {
/* 204 */     this.mXml11 = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract OutputStream getOutputStream();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract Writer getWriter();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void close()
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void flush()
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writeRaw(String paramString, int paramInt1, int paramInt2)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeRaw(String str)
/*     */     throws IOException
/*     */   {
/* 248 */     writeRaw(str, 0, str.length());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writeRaw(char[] paramArrayOfChar, int paramInt1, int paramInt2)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writeCDataStart()
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writeCDataEnd()
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writeCommentStart()
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writeCommentEnd()
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writePIStart(String paramString, boolean paramBoolean)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writePIEnd()
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int writeCData(String paramString)
/*     */     throws IOException, XMLStreamException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int writeCData(char[] paramArrayOfChar, int paramInt1, int paramInt2)
/*     */     throws IOException, XMLStreamException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writeCharacters(String paramString)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writeCharacters(char[] paramArrayOfChar, int paramInt1, int paramInt2)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int writeComment(String paramString)
/*     */     throws IOException, XMLStreamException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writeDTD(String paramString)
/*     */     throws IOException, XMLStreamException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writeDTD(String paramString1, String paramString2, String paramString3, String paramString4)
/*     */     throws IOException, XMLStreamException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writeEntityReference(String paramString)
/*     */     throws IOException, XMLStreamException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int writePI(String paramString1, String paramString2)
/*     */     throws IOException, XMLStreamException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writeXmlDeclaration(String paramString1, String paramString2, String paramString3)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writeStartTagStart(String paramString)
/*     */     throws IOException, XMLStreamException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writeStartTagStart(String paramString1, String paramString2)
/*     */     throws IOException, XMLStreamException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writeStartTagEnd()
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract void writeStartTagEmptyEnd()
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract void writeEndTag(String paramString)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract void writeEndTag(String paramString1, String paramString2)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract void writeAttribute(String paramString1, String paramString2)
/*     */     throws IOException, XMLStreamException;
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract void writeAttribute(String paramString, char[] paramArrayOfChar, int paramInt1, int paramInt2)
/*     */     throws IOException, XMLStreamException;
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract void writeAttribute(String paramString1, String paramString2, String paramString3)
/*     */     throws IOException, XMLStreamException;
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract void writeAttribute(String paramString1, String paramString2, char[] paramArrayOfChar, int paramInt1, int paramInt2)
/*     */     throws IOException, XMLStreamException;
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract int getOutputPtr();
/*     */   
/*     */ 
/*     */ 
/*     */   public int getRow()
/*     */   {
/* 414 */     return this.mLocRowNr;
/*     */   }
/*     */   
/*     */   public int getColumn() {
/* 418 */     return getOutputPtr() - this.mLocRowStartOffset + 1;
/*     */   }
/*     */   
/*     */   public int getAbsOffset() {
/* 422 */     return this.mLocPastChars + getOutputPtr();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Writer wrapAsRawWriter()
/*     */   {
/* 438 */     if (this.mRawWrapper == null) {
/* 439 */       this.mRawWrapper = XmlWriterWrapper.wrapWriteRaw(this);
/*     */     }
/* 441 */     return this.mRawWrapper;
/*     */   }
/*     */   
/*     */   public final Writer wrapAsTextWriter()
/*     */   {
/* 446 */     if (this.mTextWrapper == null) {
/* 447 */       this.mTextWrapper = XmlWriterWrapper.wrapWriteCharacters(this);
/*     */     }
/* 449 */     return this.mTextWrapper;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void verifyNameValidity(String name, boolean checkNs)
/*     */     throws XMLStreamException
/*     */   {
/* 467 */     if ((name == null) || (name.length() == 0)) {
/* 468 */       reportNwfName(ErrorConsts.WERR_NAME_EMPTY);
/*     */     }
/* 470 */     int illegalIx = WstxInputData.findIllegalNameChar(name, checkNs, this.mXml11);
/* 471 */     if (illegalIx >= 0) {
/* 472 */       if (illegalIx == 0) {
/* 473 */         reportNwfName(ErrorConsts.WERR_NAME_ILLEGAL_FIRST_CHAR, WstxInputData.getCharDesc(name.charAt(0)));
/*     */       }
/*     */       
/* 476 */       reportNwfName(ErrorConsts.WERR_NAME_ILLEGAL_CHAR, WstxInputData.getCharDesc(name.charAt(illegalIx)));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void reportNwfName(String msg)
/*     */     throws XMLStreamException
/*     */   {
/* 490 */     throwOutputError(msg);
/*     */   }
/*     */   
/*     */   protected void reportNwfName(String msg, Object arg)
/*     */     throws XMLStreamException
/*     */   {
/* 496 */     throwOutputError(msg, arg);
/*     */   }
/*     */   
/*     */   protected void reportNwfContent(String msg)
/*     */     throws XMLStreamException
/*     */   {
/* 502 */     throwOutputError(msg);
/*     */   }
/*     */   
/*     */   protected void throwOutputError(String msg)
/*     */     throws XMLStreamException
/*     */   {
/*     */     try
/*     */     {
/* 510 */       flush();
/*     */     } catch (IOException ioe) {
/* 512 */       throw new WstxIOException(ioe);
/*     */     }
/*     */     
/* 515 */     throw new XMLStreamException(msg);
/*     */   }
/*     */   
/*     */   protected void throwOutputError(String format, Object arg)
/*     */     throws XMLStreamException
/*     */   {
/* 521 */     String msg = MessageFormat.format(format, new Object[] { arg });
/* 522 */     throwOutputError(msg);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void throwInvalidChar(int c)
/*     */     throws IOException
/*     */   {
/* 529 */     flush();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 537 */     if (c == 0) {
/* 538 */       throw new IOException("Invalid null character in text to output");
/*     */     }
/* 540 */     if ((c < 32) || ((c >= 127) && (c <= 159))) {
/* 541 */       String msg = "Invalid white space character (0x" + Integer.toHexString(c) + ") in text to output";
/* 542 */       if (this.mXml11) {
/* 543 */         msg = msg + " (can only be output using character entity)";
/*     */       }
/* 545 */       throw new IOException(msg);
/*     */     }
/* 547 */     if (c > 1114111) {
/* 548 */       throw new IOException("Illegal unicode character point (0x" + Integer.toHexString(c) + ") to output; max is 0x10FFFF as per RFC 3629");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 553 */     if ((c >= 55296) && (c <= 57343)) {
/* 554 */       throw new IOException("Illegal surrogate pair -- can only be output via character entities, which are not allowed in this content");
/*     */     }
/* 556 */     throw new IOException("Invalid XML character (0x" + Integer.toHexString(c) + ") in text to output");
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sw\XmlWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */