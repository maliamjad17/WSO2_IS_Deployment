/*     */ package com.ctc.wstx.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BijectiveNsMap
/*     */ {
/*     */   static final int DEFAULT_ARRAY_SIZE = 32;
/*     */   final int mScopeStart;
/*     */   String[] mNsStrings;
/*     */   int mScopeEnd;
/*     */   
/*     */   private BijectiveNsMap(int scopeStart, String[] strs)
/*     */   {
/*  75 */     this.mScopeStart = (this.mScopeEnd = scopeStart);
/*  76 */     this.mNsStrings = strs;
/*     */   }
/*     */   
/*     */   public static BijectiveNsMap createEmpty()
/*     */   {
/*  81 */     String[] strs = new String[32];
/*     */     
/*  83 */     strs[0] = "xml";
/*  84 */     strs[1] = "http://www.w3.org/XML/1998/namespace";
/*  85 */     strs[2] = "xmlns";
/*  86 */     strs[3] = "http://www.w3.org/2000/xmlns/";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  91 */     return new BijectiveNsMap(4, strs);
/*     */   }
/*     */   
/*     */   public BijectiveNsMap createChild() {
/*  95 */     return new BijectiveNsMap(this.mScopeEnd, this.mNsStrings);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String findUriByPrefix(String prefix)
/*     */   {
/* 109 */     String[] strs = this.mNsStrings;
/* 110 */     int phash = prefix.hashCode();
/*     */     
/* 112 */     for (int ix = this.mScopeEnd - 2; ix >= 0; ix -= 2) {
/* 113 */       String thisP = strs[ix];
/* 114 */       if ((thisP == prefix) || ((thisP.hashCode() == phash) && (thisP.equals(prefix))))
/*     */       {
/* 116 */         return strs[(ix + 1)];
/*     */       }
/*     */     }
/* 119 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String findPrefixByUri(String uri)
/*     */   {
/* 131 */     String[] strs = this.mNsStrings;
/* 132 */     int uhash = uri.hashCode();
/*     */     
/*     */     label141:
/* 135 */     for (int ix = this.mScopeEnd - 1; ix > 0; ix -= 2) {
/* 136 */       String thisU = strs[ix];
/* 137 */       if ((thisU == uri) || ((thisU.hashCode() == uhash) && (thisU.equals(uri))))
/*     */       {
/*     */ 
/* 140 */         String prefix = strs[(ix - 1)];
/*     */         
/*     */ 
/*     */ 
/* 144 */         if (ix < this.mScopeStart) {
/* 145 */           int phash = prefix.hashCode();
/* 146 */           int j = ix + 1; for (int end = this.mScopeEnd; j < end; j += 2) {
/* 147 */             String thisP = strs[j];
/* 148 */             if ((thisP == prefix) || ((thisP.hashCode() == phash) && (thisP.equals(prefix)))) {
/*     */               break label141;
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 156 */         return prefix;
/*     */       }
/*     */     }
/* 159 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getPrefixesBoundToUri(String uri, List l)
/*     */   {
/* 167 */     String[] strs = this.mNsStrings;
/* 168 */     int uhash = uri.hashCode();
/*     */     
/*     */     label161:
/* 171 */     for (int ix = this.mScopeEnd - 1; ix > 0; ix -= 2) {
/* 172 */       String thisU = strs[ix];
/* 173 */       if ((thisU == uri) || ((thisU.hashCode() == uhash) && (thisU.equals(uri))))
/*     */       {
/*     */ 
/* 176 */         String prefix = strs[(ix - 1)];
/*     */         
/*     */ 
/*     */ 
/* 180 */         if (ix < this.mScopeStart) {
/* 181 */           int phash = prefix.hashCode();
/* 182 */           int j = ix + 1; for (int end = this.mScopeEnd; j < end; j += 2) {
/* 183 */             String thisP = strs[j];
/* 184 */             if ((thisP == prefix) || ((thisP.hashCode() == phash) && (thisP.equals(prefix)))) {
/*     */               break label161;
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 192 */         if (l == null) {
/* 193 */           l = new ArrayList();
/*     */         }
/* 195 */         l.add(prefix);
/*     */       }
/*     */     }
/* 198 */     return l;
/*     */   }
/*     */   
/*     */   public int size() {
/* 202 */     return this.mScopeEnd >> 1;
/*     */   }
/*     */   
/*     */   public int localSize() {
/* 206 */     return this.mScopeEnd - this.mScopeStart >> 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String addMapping(String prefix, String uri)
/*     */   {
/* 228 */     String[] strs = this.mNsStrings;
/* 229 */     int phash = prefix.hashCode();
/*     */     
/* 231 */     int ix = this.mScopeStart; for (int end = this.mScopeEnd; ix < end; ix += 2) {
/* 232 */       String thisP = strs[ix];
/* 233 */       if ((thisP == prefix) || ((thisP.hashCode() == phash) && (thisP.equals(prefix))))
/*     */       {
/*     */ 
/* 236 */         String old = strs[(ix + 1)];
/* 237 */         strs[(ix + 1)] = uri;
/* 238 */         return old;
/*     */       }
/*     */     }
/*     */     
/* 242 */     if (this.mScopeEnd >= strs.length)
/*     */     {
/* 244 */       strs = DataUtil.growArrayBy(strs, strs.length);
/* 245 */       this.mNsStrings = strs;
/*     */     }
/* 247 */     strs[(this.mScopeEnd++)] = prefix;
/* 248 */     strs[(this.mScopeEnd++)] = uri;
/*     */     
/* 250 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String addGeneratedMapping(String prefixBase, NamespaceContext ctxt, String uri, int[] seqArr)
/*     */   {
/* 260 */     String[] strs = this.mNsStrings;
/* 261 */     int seqNr = seqArr[0];
/*     */     
/*     */     String prefix;
/*     */     
/*     */     label102:
/*     */     
/*     */     do
/*     */     {
/* 269 */       prefix = (prefixBase + seqNr).intern();
/* 270 */       seqNr++;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 277 */       int phash = prefix.hashCode();
/*     */       
/* 279 */       for (int ix = this.mScopeEnd - 2;; ix -= 2) { if (ix < 0) break label102;
/* 280 */         String thisP = strs[ix];
/* 281 */         if ((thisP == prefix) || ((thisP.hashCode() == phash) && (thisP.equals(prefix))))
/*     */         {
/*     */           break;
/*     */ 
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */     }
/* 290 */     while ((ctxt != null) && (ctxt.getNamespaceURI(prefix) != null));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 295 */     seqArr[0] = seqNr;
/*     */     
/*     */ 
/* 298 */     if (this.mScopeEnd >= strs.length)
/*     */     {
/* 300 */       strs = DataUtil.growArrayBy(strs, strs.length);
/* 301 */       this.mNsStrings = strs;
/*     */     }
/* 303 */     strs[(this.mScopeEnd++)] = prefix;
/* 304 */     strs[(this.mScopeEnd++)] = uri;
/*     */     
/* 306 */     return prefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 316 */     return "[" + getClass().toString() + "; " + size() + " entries; of which " + localSize() + " local]";
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\util\BijectiveNsMap.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */