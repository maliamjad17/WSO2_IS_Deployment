/*     */ package com.ctc.wstx.io;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import com.ctc.wstx.cfg.ErrorConsts;
/*     */ import com.ctc.wstx.exc.WstxEOFException;
/*     */ import com.ctc.wstx.exc.WstxException;
/*     */ import com.ctc.wstx.exc.WstxIOException;
/*     */ import com.ctc.wstx.util.StringUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.text.MessageFormat;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLReporter;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReaderBootstrapper
/*     */   extends InputBootstrapper
/*     */ {
/*     */   static final char CHAR_BOM_MARKER = '﻿';
/*     */   final Reader mIn;
/*     */   final String mInputEncoding;
/*     */   private char[] mCharBuffer;
/*     */   private int mInputPtr;
/*     */   private int mInputLen;
/*     */   
/*     */   private ReaderBootstrapper(Reader r, String pubId, String sysId, String appEncoding)
/*     */   {
/*  83 */     super(pubId, sysId);
/*  84 */     this.mIn = r;
/*  85 */     if ((appEncoding == null) && 
/*  86 */       ((r instanceof InputStreamReader))) {
/*  87 */       appEncoding = ((InputStreamReader)r).getEncoding();
/*     */     }
/*     */     
/*  90 */     this.mInputEncoding = appEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ReaderBootstrapper getInstance(Reader r, String pubId, String sysId, String appEncoding)
/*     */   {
/* 110 */     return new ReaderBootstrapper(r, pubId, sysId, appEncoding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Reader bootstrapInput(ReaderConfig cfg, boolean mainDoc, int xmlVersion)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 130 */     this.mCharBuffer = (cfg == null ? new char[''] : cfg.allocSmallCBuffer(128));
/*     */     
/* 132 */     initialLoad(7);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 139 */     if (this.mInputLen >= 7) {
/* 140 */       char c = this.mCharBuffer[this.mInputPtr];
/*     */       
/*     */ 
/* 143 */       if (c == 65279) {
/* 144 */         c = this.mCharBuffer[(++this.mInputPtr)];
/*     */       }
/* 146 */       if (c == '<') {
/* 147 */         if ((this.mCharBuffer[(this.mInputPtr + 1)] == '?') && (this.mCharBuffer[(this.mInputPtr + 2)] == 'x') && (this.mCharBuffer[(this.mInputPtr + 3)] == 'm') && (this.mCharBuffer[(this.mInputPtr + 4)] == 'l') && (this.mCharBuffer[(this.mInputPtr + 5)] <= ' '))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 153 */           this.mInputPtr += 6;
/* 154 */           readXmlDecl(mainDoc, xmlVersion);
/*     */           
/* 156 */           if ((this.mFoundEncoding != null) && (this.mInputEncoding != null)) {
/* 157 */             verifyXmlEncoding(cfg);
/*     */ 
/*     */ 
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/* 172 */       else if (c == 'ï') {
/* 173 */         throw new WstxIOException("Unexpected first character (char code 0xEF), not valid in xml document: could be mangled UTF-8 BOM marker. Make sure that the Reader uses correct encoding or pass an InputStream instead");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 181 */     if (this.mInputPtr < this.mInputLen) {
/* 182 */       return new MergedReader(cfg, this.mIn, this.mCharBuffer, this.mInputPtr, this.mInputLen);
/*     */     }
/*     */     
/* 185 */     return this.mIn;
/*     */   }
/*     */   
/*     */   public String getInputEncoding() {
/* 189 */     return this.mInputEncoding;
/*     */   }
/*     */   
/*     */   public int getInputTotal() {
/* 193 */     return this.mInputProcessed + this.mInputPtr;
/*     */   }
/*     */   
/*     */   public int getInputColumn() {
/* 197 */     return this.mInputPtr - this.mInputRowStart;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void verifyXmlEncoding(ReaderConfig cfg)
/*     */     throws XMLStreamException
/*     */   {
/* 209 */     String inputEnc = this.mInputEncoding;
/*     */     
/*     */ 
/* 212 */     if (StringUtil.equalEncodings(inputEnc, this.mFoundEncoding)) {
/* 213 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 221 */     XMLReporter rep = cfg.getXMLReporter();
/* 222 */     if (rep != null) {
/* 223 */       Location loc = getLocation();
/* 224 */       rep.report(MessageFormat.format(ErrorConsts.W_MIXED_ENCODINGS, new Object[] { this.mFoundEncoding, inputEnc }), ErrorConsts.WT_XML_DECL, this, loc);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean initialLoad(int minimum)
/*     */     throws IOException
/*     */   {
/* 241 */     this.mInputPtr = 0;
/* 242 */     this.mInputLen = 0;
/*     */     
/* 244 */     while (this.mInputLen < minimum) {
/* 245 */       int count = this.mIn.read(this.mCharBuffer, this.mInputLen, this.mCharBuffer.length - this.mInputLen);
/*     */       
/* 247 */       if (count < 1) {
/* 248 */         return false;
/*     */       }
/* 250 */       this.mInputLen += count;
/*     */     }
/* 252 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void loadMore()
/*     */     throws IOException, WstxException
/*     */   {
/* 262 */     this.mInputProcessed += this.mInputLen;
/* 263 */     this.mInputRowStart -= this.mInputLen;
/*     */     
/* 265 */     this.mInputPtr = 0;
/* 266 */     this.mInputLen = this.mIn.read(this.mCharBuffer, 0, this.mCharBuffer.length);
/* 267 */     if (this.mInputLen < 1) {
/* 268 */       throw new WstxEOFException(" in xml declaration", getLocation());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void pushback()
/*     */   {
/* 280 */     this.mInputPtr -= 1;
/*     */   }
/*     */   
/*     */   protected int getNext()
/*     */     throws IOException, WstxException
/*     */   {
/* 286 */     return this.mInputPtr < this.mInputLen ? this.mCharBuffer[(this.mInputPtr++)] : nextChar();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected int getNextAfterWs(boolean reqWs)
/*     */     throws IOException, WstxException
/*     */   {
/* 294 */     int count = 0;
/*     */     for (;;)
/*     */     {
/* 297 */       char c = this.mInputPtr < this.mInputLen ? this.mCharBuffer[(this.mInputPtr++)] : nextChar();
/*     */       
/*     */ 
/* 300 */       if (c > ' ') {
/* 301 */         if ((reqWs) && (count == 0)) {
/* 302 */           reportUnexpectedChar(c, "; expected a white space");
/*     */         }
/* 304 */         return c;
/*     */       }
/* 306 */       if ((c == '\r') || (c == '\n')) {
/* 307 */         skipCRLF(c);
/* 308 */       } else if (c == 0) {
/* 309 */         reportNull();
/*     */       }
/* 311 */       count++;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int checkKeyword(String exp)
/*     */     throws IOException, WstxException
/*     */   {
/* 322 */     int len = exp.length();
/*     */     
/* 324 */     for (int ptr = 1; ptr < len; ptr++) {
/* 325 */       char c = this.mInputPtr < this.mInputLen ? this.mCharBuffer[(this.mInputPtr++)] : nextChar();
/*     */       
/*     */ 
/* 328 */       if (c != exp.charAt(ptr)) {
/* 329 */         return c;
/*     */       }
/* 331 */       if (c == 0) {
/* 332 */         reportNull();
/*     */       }
/*     */     }
/*     */     
/* 336 */     return 0;
/*     */   }
/*     */   
/*     */   protected int readQuotedValue(char[] kw, int quoteChar)
/*     */     throws IOException, WstxException
/*     */   {
/* 342 */     int i = 0;
/* 343 */     int len = kw.length;
/*     */     for (;;)
/*     */     {
/* 346 */       char c = this.mInputPtr < this.mInputLen ? this.mCharBuffer[(this.mInputPtr++)] : nextChar();
/*     */       
/* 348 */       if ((c == '\r') || (c == '\n')) {
/* 349 */         skipCRLF(c);
/* 350 */       } else if (c == 0) {
/* 351 */         reportNull();
/*     */       }
/* 353 */       if (c == quoteChar) {
/* 354 */         return i < len ? i : -1;
/*     */       }
/*     */       
/* 357 */       if (i < len) {
/* 358 */         kw[(i++)] = c;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected Location getLocation()
/*     */   {
/* 365 */     return new WstxInputLocation(null, this.mPublicId, this.mSystemId, this.mInputProcessed + this.mInputPtr - 1, this.mInputRow, this.mInputPtr - this.mInputRowStart);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected char nextChar()
/*     */     throws IOException, WstxException
/*     */   {
/* 379 */     if (this.mInputPtr >= this.mInputLen) {
/* 380 */       loadMore();
/*     */     }
/* 382 */     return this.mCharBuffer[(this.mInputPtr++)];
/*     */   }
/*     */   
/*     */   protected void skipCRLF(char lf)
/*     */     throws IOException, WstxException
/*     */   {
/* 388 */     if (lf == '\r') {
/* 389 */       char c = this.mInputPtr < this.mInputLen ? this.mCharBuffer[(this.mInputPtr++)] : nextChar();
/*     */       
/* 391 */       if (c != '\n') {
/* 392 */         this.mInputPtr -= 1;
/*     */       }
/*     */     }
/* 395 */     this.mInputRow += 1;
/* 396 */     this.mInputRowStart = this.mInputPtr;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\io\ReaderBootstrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */