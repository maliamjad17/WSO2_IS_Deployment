/*    */ package com.ctc.wstx.dtd;
/*    */ 
/*    */ import com.ctc.wstx.sr.InputProblemReporter;
/*    */ import com.ctc.wstx.util.WordResolver;
/*    */ import org.codehaus.stax2.validation.XMLValidationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DTDNotationAttr
/*    */   extends DTDAttribute
/*    */ {
/*    */   final WordResolver mEnumValues;
/*    */   
/*    */   public DTDNotationAttr(NameKey name, DefaultAttrValue defValue, int specIndex, boolean nsAware, boolean xml11, WordResolver enumValues)
/*    */   {
/* 27 */     super(name, defValue, specIndex, nsAware, xml11);
/* 28 */     this.mEnumValues = enumValues;
/*    */   }
/*    */   
/*    */   public DTDAttribute cloneWith(int specIndex)
/*    */   {
/* 33 */     return new DTDNotationAttr(this.mName, this.mDefValue, specIndex, this.mCfgNsAware, this.mCfgXml11, this.mEnumValues);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getValueType()
/*    */   {
/* 44 */     return 7;
/*    */   }
/*    */   
/*    */   public boolean typeIsNotation() {
/* 48 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String validate(DTDValidatorBase v, char[] cbuf, int start, int end, boolean normalize)
/*    */     throws XMLValidationException
/*    */   {
/* 67 */     String ok = validateEnumValue(cbuf, start, end, normalize, this.mEnumValues);
/* 68 */     if (ok == null) {
/* 69 */       String val = new String(cbuf, start, end - start);
/* 70 */       return reportValidationProblem(v, "Invalid notation value '" + val + "': has to be one of (" + this.mEnumValues + ")");
/*    */     }
/*    */     
/* 73 */     return ok;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void validateDefault(InputProblemReporter rep, boolean normalize)
/*    */     throws XMLValidationException
/*    */   {
/* 85 */     String def = validateDefaultName(rep, normalize);
/*    */     
/*    */ 
/* 88 */     String shared = this.mEnumValues.find(def);
/* 89 */     if (shared == null) {
/* 90 */       reportValidationProblem(rep, "Invalid default value '" + def + "': has to be one of (" + this.mEnumValues + ")");
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 95 */     if (normalize) {
/* 96 */       this.mDefValue.setValue(shared);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\DTDNotationAttr.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */