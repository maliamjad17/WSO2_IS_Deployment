/*     */ package com.ctc.wstx.sr;
/*     */ 
/*     */ import com.ctc.wstx.evt.WNamespace;
/*     */ import com.ctc.wstx.util.BaseNsContext;
/*     */ import com.ctc.wstx.util.EmptyIterator;
/*     */ import com.ctc.wstx.util.SingletonIterator;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CompactNsContext
/*     */   extends BaseNsContext
/*     */ {
/*     */   final Location mLocation;
/*     */   final String[] mNamespaces;
/*     */   final int mNsLength;
/*     */   final int mFirstLocalNs;
/*     */   transient ArrayList mNsList;
/*     */   
/*     */   public CompactNsContext(Location loc, String defaultNsURI, String[] namespaces, int nsLen, int firstLocal)
/*     */   {
/*  64 */     this.mLocation = loc;
/*  65 */     this.mNamespaces = namespaces;
/*  66 */     this.mNsLength = nsLen;
/*  67 */     this.mFirstLocalNs = firstLocal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String doGetNamespaceURI(String prefix)
/*     */   {
/*  77 */     String[] ns = this.mNamespaces;
/*  78 */     if ((prefix == null) || (prefix.length() == 0)) {
/*  79 */       for (int i = this.mNsLength - 2; i >= 0; i -= 2) {
/*  80 */         if (ns[i] == null) {
/*  81 */           return ns[(i + 1)];
/*     */         }
/*     */       }
/*  84 */       return null;
/*     */     }
/*  86 */     for (int i = this.mNsLength - 2; i >= 0; i -= 2) {
/*  87 */       if (prefix.equals(ns[i])) {
/*  88 */         return ns[(i + 1)];
/*     */       }
/*     */     }
/*  91 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String doGetPrefix(String nsURI)
/*     */   {
/*  98 */     String[] ns = this.mNamespaces;
/*  99 */     int len = this.mNsLength;
/*     */     
/*     */     label93:
/* 102 */     for (int i = len - 1; i > 0; i -= 2) {
/* 103 */       if (nsURI.equals(ns[i]))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 109 */         String prefix = ns[(i - 1)];
/* 110 */         for (int j = i + 1; j < len; j += 2)
/*     */         {
/* 112 */           if (ns[j] == prefix) {
/*     */             break label93;
/*     */           }
/*     */         }
/* 116 */         String uri = this.mNamespaces[(i - 1)];
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 121 */         return uri == null ? "" : uri;
/*     */       }
/*     */     }
/* 124 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Iterator doGetPrefixes(String nsURI)
/*     */   {
/* 131 */     String[] ns = this.mNamespaces;
/* 132 */     int len = this.mNsLength;
/* 133 */     String first = null;
/* 134 */     ArrayList all = null;
/*     */     
/*     */     label136:
/* 137 */     for (int i = len - 1; i > 0; i -= 2) {
/* 138 */       String currNS = ns[i];
/* 139 */       if ((currNS == nsURI) || (currNS.equals(nsURI)))
/*     */       {
/*     */ 
/*     */ 
/* 143 */         String prefix = ns[(i - 1)];
/* 144 */         for (int j = i + 1; j < len; j += 2)
/*     */         {
/* 146 */           if (ns[j] == prefix) {
/*     */             break label136;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 154 */         if (prefix == null) {
/* 155 */           prefix = "";
/*     */         }
/* 157 */         if (first == null) {
/* 158 */           first = prefix;
/*     */         } else {
/* 160 */           if (all == null) {
/* 161 */             all = new ArrayList();
/* 162 */             all.add(first);
/*     */           }
/* 164 */           all.add(prefix);
/*     */         }
/*     */       }
/*     */     }
/* 168 */     if (all != null) {
/* 169 */       return all.iterator();
/*     */     }
/* 171 */     if (first != null) {
/* 172 */       return new SingletonIterator(first);
/*     */     }
/* 174 */     return EmptyIterator.getInstance();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator getNamespaces()
/*     */   {
/* 185 */     if (this.mNsList == null) {
/* 186 */       int firstLocal = this.mFirstLocalNs;
/* 187 */       int len = this.mNsLength - firstLocal;
/* 188 */       if (len == 0) {
/* 189 */         return EmptyIterator.getInstance();
/*     */       }
/* 191 */       if (len == 2) {
/* 192 */         return new SingletonIterator(WNamespace.constructFor(this.mLocation, this.mNamespaces[firstLocal], this.mNamespaces[(firstLocal + 1)]));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 197 */       ArrayList l = new ArrayList(len >> 1);
/* 198 */       String[] ns = this.mNamespaces;
/* 199 */       for (len = this.mNsLength; firstLocal < len; 
/* 200 */           firstLocal += 2) {
/* 201 */         l.add(WNamespace.constructFor(this.mLocation, ns[firstLocal], ns[(firstLocal + 1)]));
/*     */       }
/*     */       
/* 204 */       this.mNsList = l;
/*     */     }
/* 206 */     return this.mNsList.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void outputNamespaceDeclarations(Writer w)
/*     */     throws IOException
/*     */   {
/* 217 */     String[] ns = this.mNamespaces;
/* 218 */     int i = this.mFirstLocalNs; for (int len = this.mNsLength; i < len; i += 2) {
/* 219 */       w.write(32);
/* 220 */       w.write("xmlns");
/* 221 */       String prefix = ns[i];
/* 222 */       if ((prefix != null) && (prefix.length() > 0)) {
/* 223 */         w.write(58);
/* 224 */         w.write(prefix);
/*     */       }
/* 226 */       w.write("=\"");
/* 227 */       w.write(ns[(i + 1)]);
/* 228 */       w.write(34);
/*     */     }
/*     */   }
/*     */   
/*     */   public void outputNamespaceDeclarations(XMLStreamWriter w) throws XMLStreamException
/*     */   {
/* 234 */     String[] ns = this.mNamespaces;
/* 235 */     int i = this.mFirstLocalNs; for (int len = this.mNsLength; i < len; i += 2) {
/* 236 */       String nsURI = ns[(i + 1)];
/* 237 */       String prefix = ns[i];
/* 238 */       if ((prefix != null) && (prefix.length() > 0)) {
/* 239 */         w.writeNamespace(prefix, nsURI);
/*     */       } else {
/* 241 */         w.writeDefaultNamespace(nsURI);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sr\CompactNsContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */