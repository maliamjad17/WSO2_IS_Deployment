/*     */ package com.ctc.wstx.sw;
/*     */ 
/*     */ import com.ctc.wstx.api.WriterConfig;
/*     */ import com.ctc.wstx.cfg.ErrorConsts;
/*     */ import com.ctc.wstx.sr.AttributeCollector;
/*     */ import com.ctc.wstx.sr.InputElementStack;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.events.Attribute;
/*     */ import javax.xml.stream.events.Namespace;
/*     */ import javax.xml.stream.events.StartElement;
/*     */ import org.codehaus.stax2.validation.XMLValidator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleNsStreamWriter
/*     */   extends BaseNsStreamWriter
/*     */ {
/*     */   public SimpleNsStreamWriter(XmlWriter xw, String enc, WriterConfig cfg)
/*     */   {
/*  59 */     super(xw, enc, cfg, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeAttribute(String nsURI, String localName, String value)
/*     */     throws XMLStreamException
/*     */   {
/*  79 */     if (!this.mStartElementOpen) {
/*  80 */       throwOutputError(ErrorConsts.WERR_ATTR_NO_ELEM);
/*     */     }
/*  82 */     String prefix = this.mCurrElem.getExplicitPrefix(nsURI);
/*  83 */     if (prefix == null) {
/*  84 */       throwOutputError("Unbound namespace URI '" + nsURI + "'");
/*     */     }
/*  86 */     doWriteAttr(localName, nsURI, prefix, value);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeAttribute(String prefix, String nsURI, String localName, String value)
/*     */     throws XMLStreamException
/*     */   {
/*  93 */     if (!this.mStartElementOpen) {
/*  94 */       throwOutputError(ErrorConsts.WERR_ATTR_NO_ELEM);
/*     */     }
/*  96 */     doWriteAttr(localName, nsURI, prefix, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeDefaultNamespace(String nsURI)
/*     */     throws XMLStreamException
/*     */   {
/* 108 */     if (!this.mStartElementOpen) {
/* 109 */       throwOutputError("Trying to write a namespace declaration when there is no open start element.");
/*     */     }
/*     */     
/* 112 */     setDefaultNamespace(nsURI);
/* 113 */     doWriteDefaultNs(nsURI);
/*     */   }
/*     */   
/*     */   public void writeNamespace(String prefix, String nsURI)
/*     */     throws XMLStreamException
/*     */   {
/* 119 */     if ((prefix == null) || (prefix.length() == 0) || (prefix.equals("xmlns")))
/*     */     {
/* 121 */       writeDefaultNamespace(nsURI);
/* 122 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 127 */     if (!this.mStartElementOpen) {
/* 128 */       throwOutputError("Trying to write a namespace declaration when there is no open start element.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 137 */     if ((!this.mXml11) && 
/* 138 */       (nsURI.length() == 0)) {
/* 139 */       throwOutputError(ErrorConsts.ERR_NS_EMPTY);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 144 */     setPrefix(prefix, nsURI);
/* 145 */     doWriteNamespace(prefix, nsURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultNamespace(String uri)
/*     */     throws XMLStreamException
/*     */   {
/* 157 */     this.mCurrElem.setDefaultNsUri(uri);
/*     */   }
/*     */   
/*     */   public void doSetPrefix(String prefix, String uri)
/*     */     throws XMLStreamException
/*     */   {
/* 163 */     this.mCurrElem.addPrefix(prefix, uri);
/*     */   }
/*     */   
/*     */   public void writeStartElement(StartElement elem)
/*     */     throws XMLStreamException
/*     */   {
/* 169 */     QName name = elem.getName();
/* 170 */     Iterator it = elem.getNamespaces();
/*     */     
/* 172 */     while (it.hasNext()) {
/* 173 */       Namespace ns = (Namespace)it.next();
/*     */       
/* 175 */       String prefix = ns.getPrefix();
/* 176 */       if ((prefix == null) || (prefix.length() == 0)) {
/* 177 */         setDefaultNamespace(ns.getNamespaceURI());
/*     */       } else {
/* 179 */         setPrefix(prefix, ns.getNamespaceURI());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 193 */     String nsURI = name.getNamespaceURI();
/* 194 */     if (nsURI == null) {
/* 195 */       writeStartElement(name.getLocalPart());
/*     */     } else {
/* 197 */       String prefix = name.getPrefix();
/* 198 */       writeStartElement(prefix, name.getLocalPart(), nsURI);
/*     */     }
/*     */     
/*     */ 
/* 202 */     it = elem.getNamespaces();
/* 203 */     while (it.hasNext()) {
/* 204 */       Namespace ns = (Namespace)it.next();
/* 205 */       String prefix = ns.getPrefix();
/* 206 */       if ((prefix == null) || (prefix.length() == 0)) {
/* 207 */         writeDefaultNamespace(ns.getNamespaceURI());
/*     */       } else {
/* 209 */         writeNamespace(prefix, ns.getNamespaceURI());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 216 */     it = elem.getAttributes();
/* 217 */     while (it.hasNext()) {
/* 218 */       Attribute attr = (Attribute)it.next();
/* 219 */       name = attr.getName();
/* 220 */       nsURI = name.getNamespaceURI();
/*     */       
/* 222 */       if ((nsURI != null) && (nsURI.length() > 0)) {
/* 223 */         writeAttribute(name.getPrefix(), nsURI, name.getLocalPart(), attr.getValue());
/*     */       }
/*     */       else {
/* 226 */         writeAttribute(name.getLocalPart(), attr.getValue());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeStartOrEmpty(String localName, String nsURI)
/*     */     throws XMLStreamException
/*     */   {
/* 237 */     String prefix = this.mCurrElem.getPrefix(nsURI);
/* 238 */     if (prefix == null) {
/* 239 */       throw new XMLStreamException("Unbound namespace URI '" + nsURI + "'");
/*     */     }
/* 241 */     checkStartElement(localName, prefix);
/* 242 */     if (this.mValidator != null) {
/* 243 */       this.mValidator.validateElementStart(localName, nsURI, prefix);
/*     */     }
/*     */     
/* 246 */     if (this.mOutputElemPool != null) {
/* 247 */       SimpleOutputElement newCurr = this.mOutputElemPool;
/* 248 */       this.mOutputElemPool = newCurr.reuseAsChild(this.mCurrElem, prefix, localName, nsURI);
/* 249 */       this.mPoolSize -= 1;
/* 250 */       this.mCurrElem = newCurr;
/*     */     } else {
/* 252 */       this.mCurrElem = this.mCurrElem.createChild(prefix, localName, nsURI);
/*     */     }
/* 254 */     doWriteStartTag(prefix, localName);
/*     */   }
/*     */   
/*     */   protected void writeStartOrEmpty(String prefix, String localName, String nsURI)
/*     */     throws XMLStreamException
/*     */   {
/* 260 */     checkStartElement(localName, prefix);
/* 261 */     if (this.mValidator != null) {
/* 262 */       this.mValidator.validateElementStart(localName, nsURI, prefix);
/*     */     }
/*     */     
/* 265 */     if (this.mOutputElemPool != null) {
/* 266 */       SimpleOutputElement newCurr = this.mOutputElemPool;
/* 267 */       this.mOutputElemPool = newCurr.reuseAsChild(this.mCurrElem, prefix, localName, nsURI);
/* 268 */       this.mPoolSize -= 1;
/* 269 */       this.mCurrElem = newCurr;
/*     */     } else {
/* 271 */       this.mCurrElem = this.mCurrElem.createChild(prefix, localName, nsURI);
/*     */     }
/* 273 */     doWriteStartTag(prefix, localName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void copyStartElement(InputElementStack elemStack, AttributeCollector attrCollector)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 290 */     int nsCount = elemStack.getCurrentNsCount();
/* 291 */     if (nsCount > 0)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 296 */       for (int i = 0; i < nsCount; i++) {
/* 297 */         String prefix = elemStack.getLocalNsPrefix(i);
/* 298 */         String uri = elemStack.getLocalNsURI(i);
/* 299 */         if ((prefix == null) || (prefix.length() == 0)) {
/* 300 */           setDefaultNamespace(uri);
/*     */         } else {
/* 302 */           setPrefix(prefix, uri);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 307 */     writeStartElement(elemStack.getPrefix(), elemStack.getLocalName(), elemStack.getNsURI());
/*     */     
/*     */ 
/*     */ 
/* 311 */     if (nsCount > 0)
/*     */     {
/* 313 */       for (int i = 0; i < nsCount; i++) {
/* 314 */         String prefix = elemStack.getLocalNsPrefix(i);
/* 315 */         String uri = elemStack.getLocalNsURI(i);
/*     */         
/* 317 */         if ((prefix == null) || (prefix.length() == 0)) {
/* 318 */           writeDefaultNamespace(uri);
/*     */         } else {
/* 320 */           writeNamespace(prefix, uri);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 328 */     int attrCount = this.mCfgCopyDefaultAttrs ? attrCollector.getCount() : attrCollector.getSpecifiedCount();
/*     */     
/*     */ 
/*     */ 
/* 332 */     if (attrCount > 0) {
/* 333 */       for (int i = 0; i < attrCount; i++) {
/* 334 */         attrCollector.writeAttribute(i, this.mWriter);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sw\SimpleNsStreamWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */