package com.ctc.wstx.cfg;

public abstract interface InputConfigFlags
{
  public static final int CFG_NAMESPACE_AWARE = 1;
  public static final int CFG_COALESCE_TEXT = 2;
  public static final int CFG_REPLACE_ENTITY_REFS = 4;
  public static final int CFG_SUPPORT_EXTERNAL_ENTITIES = 8;
  public static final int CFG_SUPPORT_DTD = 16;
  public static final int CFG_VALIDATE_AGAINST_DTD = 32;
  public static final int CFG_REPORT_PROLOG_WS = 256;
  public static final int CFG_REPORT_CDATA = 512;
  public static final int CFG_INTERN_NS_URIS = 1024;
  public static final int CFG_PRESERVE_LOCATION = 2048;
  public static final int CFG_AUTO_CLOSE_INPUT = 4096;
  public static final int CFG_NORMALIZE_LFS = 8192;
  public static final int CFG_NORMALIZE_ATTR_VALUES = 16384;
  public static final int CFG_VALIDATE_TEXT_CHARS = 32768;
  public static final int CFG_CACHE_DTDS = 65536;
  public static final int CFG_CACHE_DTDS_BY_PUBLIC_ID = 131072;
  public static final int CFG_LAZY_PARSING = 262144;
  public static final int CFG_SUPPORT_DTDPP = 524288;
  public static final int CFG_XMLID_TYPING = 2097152;
  public static final int CFG_XMLID_UNIQ_CHECKS = 4194304;
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\cfg\InputConfigFlags.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */