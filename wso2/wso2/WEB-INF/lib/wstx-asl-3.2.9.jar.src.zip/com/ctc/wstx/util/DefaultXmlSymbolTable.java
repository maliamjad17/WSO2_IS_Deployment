/*    */ package com.ctc.wstx.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DefaultXmlSymbolTable
/*    */ {
/* 34 */   static final SymbolTable sInstance = new SymbolTable(true, 128);
/*    */   
/*    */ 
/* 37 */   static final String mNsPrefixXml = sInstance.findSymbol("xml");
/* 38 */   static final String mNsPrefixXmlns = sInstance.findSymbol("xmlns");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static
/*    */   {
/* 47 */     sInstance.findSymbol("id");
/* 48 */     sInstance.findSymbol("name");
/*    */     
/*    */ 
/*    */ 
/* 52 */     sInstance.findSymbol("xsd");
/* 53 */     sInstance.findSymbol("xsi");
/*    */     
/* 55 */     sInstance.findSymbol("type");
/*    */     
/*    */ 
/*    */ 
/* 59 */     sInstance.findSymbol("soap");
/* 60 */     sInstance.findSymbol("SOAP-ENC");
/* 61 */     sInstance.findSymbol("SOAP-ENV");
/*    */     
/* 63 */     sInstance.findSymbol("Body");
/* 64 */     sInstance.findSymbol("Envelope");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static SymbolTable getInstance()
/*    */   {
/* 78 */     return sInstance.makeChild();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String getXmlSymbol()
/*    */   {
/* 89 */     return mNsPrefixXml;
/*    */   }
/*    */   
/*    */   public static String getXmlnsSymbol() {
/* 93 */     return mNsPrefixXmlns;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\util\DefaultXmlSymbolTable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */