/*    */ package com.ctc.wstx.util;
/*    */ 
/*    */ import com.ctc.wstx.compat.JdkFeatures;
/*    */ import com.ctc.wstx.compat.JdkImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ExceptionUtil
/*    */ {
/*    */   public static void throwRuntimeException(Throwable t)
/*    */   {
/* 16 */     throwIfUnchecked(t);
/*    */     
/* 18 */     RuntimeException rex = new RuntimeException("[was " + t.getClass() + "] " + t.getMessage());
/*    */     
/* 20 */     JdkFeatures.getInstance().setInitCause(rex, t);
/* 21 */     throw rex;
/*    */   }
/*    */   
/*    */ 
/*    */   public static void throwAsIllegalArgument(Throwable t)
/*    */   {
/* 27 */     throwIfUnchecked(t);
/*    */     
/* 29 */     IllegalArgumentException rex = new IllegalArgumentException("[was " + t.getClass() + "] " + t.getMessage());
/*    */     
/* 31 */     JdkFeatures.getInstance().setInitCause(rex, t);
/* 32 */     throw rex;
/*    */   }
/*    */   
/*    */ 
/*    */   public static void throwIfUnchecked(Throwable t)
/*    */   {
/* 38 */     if ((t instanceof RuntimeException)) {
/* 39 */       throw ((RuntimeException)t);
/*    */     }
/* 41 */     if ((t instanceof Error)) {
/* 42 */       throw ((Error)t);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void throwGenericInternal()
/*    */   {
/* 53 */     throwInternal(null);
/*    */   }
/*    */   
/*    */   public static void throwInternal(String msg)
/*    */   {
/* 58 */     if (msg == null) {
/* 59 */       msg = "[no description]";
/*    */     }
/* 61 */     throw new RuntimeException("Internal error: " + msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\util\ExceptionUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */