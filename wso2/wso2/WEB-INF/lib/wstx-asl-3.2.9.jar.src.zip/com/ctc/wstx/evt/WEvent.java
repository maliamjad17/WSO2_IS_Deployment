/*     */ package com.ctc.wstx.evt;
/*     */ 
/*     */ import com.ctc.wstx.cfg.ErrorConsts;
/*     */ import com.ctc.wstx.exc.WstxException;
/*     */ import com.ctc.wstx.exc.WstxIOException;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.stream.events.Characters;
/*     */ import javax.xml.stream.events.EndElement;
/*     */ import javax.xml.stream.events.StartElement;
/*     */ import org.codehaus.stax2.evt.XMLEvent2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class WEvent
/*     */   implements XMLEvent2
/*     */ {
/*     */   protected final Location mLocation;
/*     */   
/*     */   protected WEvent(Location loc)
/*     */   {
/*  45 */     this.mLocation = loc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Characters asCharacters()
/*     */   {
/*  55 */     return (Characters)this;
/*     */   }
/*     */   
/*     */   public EndElement asEndElement() {
/*  59 */     return (EndElement)this;
/*     */   }
/*     */   
/*     */   public StartElement asStartElement() {
/*  63 */     return (StartElement)this;
/*     */   }
/*     */   
/*     */   public abstract int getEventType();
/*     */   
/*     */   public Location getLocation() {
/*  69 */     return this.mLocation;
/*     */   }
/*     */   
/*     */   public QName getSchemaType() {
/*  73 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isAttribute()
/*     */   {
/*  78 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isCharacters()
/*     */   {
/*  83 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isEndDocument()
/*     */   {
/*  88 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isEndElement()
/*     */   {
/*  93 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isEntityReference()
/*     */   {
/*  98 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isNamespace()
/*     */   {
/* 103 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isProcessingInstruction()
/*     */   {
/* 108 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isStartDocument()
/*     */   {
/* 113 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isStartElement()
/*     */   {
/* 118 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writeAsEncodedUnicode(Writer paramWriter)
/*     */     throws XMLStreamException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writeUsing(XMLStreamWriter paramXMLStreamWriter)
/*     */     throws XMLStreamException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 139 */     return "[" + ErrorConsts.tokenTypeDesc(getEventType()) + "]";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void throwFromIOE(IOException ioe)
/*     */     throws WstxException
/*     */   {
/* 151 */     throw new WstxIOException(ioe);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\evt\WEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */