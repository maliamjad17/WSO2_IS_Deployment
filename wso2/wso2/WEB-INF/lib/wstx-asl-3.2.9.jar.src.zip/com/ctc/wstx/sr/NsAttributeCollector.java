/*     */ package com.ctc.wstx.sr;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import com.ctc.wstx.cfg.ErrorConsts;
/*     */ import com.ctc.wstx.compat.QNameCreator;
/*     */ import com.ctc.wstx.sw.XmlWriter;
/*     */ import com.ctc.wstx.util.DataUtil;
/*     */ import com.ctc.wstx.util.StringVector;
/*     */ import com.ctc.wstx.util.TextBuilder;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NsAttributeCollector
/*     */   extends AttributeCollector
/*     */ {
/*  41 */   protected static final String DEFAULT_NS_URI = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static final int ATTR_URI_BUF_SIZE = 16;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int EXP_NS_COUNT = 8;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  65 */   private final TextBuilder mNamespaceURIs = new TextBuilder(8);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  71 */   private final StringVector mNsPrefixes = new StringVector(8);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  77 */   private boolean mDefaultNsDeclared = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  89 */   private String[] mAttrURIs = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NsAttributeCollector(ReaderConfig cfg)
/*     */   {
/*  99 */     super(cfg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/* 110 */     this.mNamespaceURIs.reset();
/* 111 */     this.mDefaultNsDeclared = false;
/* 112 */     this.mNsPrefixes.clear(false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 119 */     if (this.mAttrCount > 0) {
/* 120 */       this.mAttrNames.clear(false);
/* 121 */       this.mValueBuffer.reset();
/* 122 */       this.mAttrCount = 0;
/* 123 */       if (this.mXmlIdAttrIndex >= 0) {
/* 124 */         this.mXmlIdAttrIndex = -1;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int resolveNamespaces(InputProblemReporter rep, StringVector ns)
/*     */     throws XMLStreamException
/*     */   {
/* 147 */     int attrCount = this.mAttrCount;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 152 */     this.mNonDefCount = attrCount;
/*     */     
/* 154 */     if (attrCount < 1)
/*     */     {
/* 156 */       this.mAttrHashSize = (this.mAttrSpillEnd = 0);
/*     */       
/* 158 */       return this.mXmlIdAttrIndex;
/*     */     }
/*     */     
/*     */ 
/* 162 */     String[] attrURIs = this.mAttrURIs;
/* 163 */     if ((attrURIs == null) || (attrURIs.length < attrCount)) {
/* 164 */       int size = attrCount < 16 ? 16 : attrCount;
/*     */       
/* 166 */       this.mAttrURIs = (attrURIs = new String[attrCount]);
/*     */     }
/* 168 */     String[] attrNames = this.mAttrNames.getInternalArray();
/* 169 */     for (int i = 0; i < attrCount; i++) {
/* 170 */       String prefix = attrNames[(i + i)];
/*     */       
/* 172 */       if (prefix == null) {
/* 173 */         attrURIs[i] = DEFAULT_NS_URI;
/*     */       }
/* 175 */       else if (prefix == "xml") {
/* 176 */         attrURIs[i] = "http://www.w3.org/XML/1998/namespace";
/*     */       } else {
/* 178 */         String uri = ns.findLastFromMap(prefix);
/* 179 */         if (uri == null) {
/* 180 */           rep.throwParseError(ErrorConsts.ERR_NS_UNDECLARED_FOR_ATTR, prefix, attrNames[(i + i + 1)]);
/*     */         }
/*     */         
/* 183 */         attrURIs[i] = uri;
/*     */       }
/*     */     }
/*     */     
/* 187 */     if (this.mAttrValues != null)
/*     */     {
/* 189 */       if (this.mAttrValues.length < attrCount) {
/* 190 */         this.mAttrValues = null;
/*     */       }
/*     */       else {
/* 193 */         for (int i = 0; i < attrCount; i++) {
/* 194 */           this.mAttrValues[i] = null;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 203 */     int[] map = this.mAttrMap;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 208 */     int hashCount = 4;
/*     */     
/* 210 */     int min = attrCount + (attrCount >> 2);
/*     */     
/*     */ 
/*     */ 
/* 214 */     while (hashCount < min) {
/* 215 */       hashCount += hashCount;
/*     */     }
/*     */     
/* 218 */     this.mAttrHashSize = hashCount;
/* 219 */     min = hashCount + (hashCount >> 4);
/* 220 */     if ((map == null) || (map.length < min)) {
/* 221 */       map = new int[min];
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 227 */       Arrays.fill(map, 0, hashCount, 0);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 232 */     int mask = hashCount - 1;
/* 233 */     int spillIndex = hashCount;
/*     */     
/*     */ 
/* 236 */     for (int i = 0; i < attrCount; i++) {
/* 237 */       String uri = attrURIs[i];
/* 238 */       String name = attrNames[(i + i + 1)];
/* 239 */       int hash = name.hashCode();
/* 240 */       if (uri != null) {
/* 241 */         hash ^= uri.hashCode();
/*     */       }
/* 243 */       int index = hash & mask;
/*     */       
/* 245 */       if (map[index] == 0) {
/* 246 */         map[index] = (i + 1);
/*     */       } else {
/* 248 */         int currIndex = map[index] - 1;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 253 */         map = spillAttr(uri, name, map, currIndex, spillIndex, attrCount, hash, hashCount);
/*     */         
/* 255 */         if (map == null) {
/* 256 */           throwDupAttr(rep, currIndex);
/*     */         }
/*     */         else {
/* 259 */           map[(++spillIndex)] = i;
/* 260 */           spillIndex++;
/*     */         }
/*     */       }
/*     */     }
/* 264 */     this.mAttrSpillEnd = spillIndex;
/*     */     
/* 266 */     this.mAttrMap = map;
/* 267 */     return this.mXmlIdAttrIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNsCount()
/*     */   {
/* 280 */     return this.mNamespaceURIs.size();
/*     */   }
/*     */   
/*     */   public boolean hasDefaultNs() {
/* 284 */     return this.mDefaultNsDeclared;
/*     */   }
/*     */   
/*     */   public String getNsPrefix(int index) {
/* 288 */     return this.mNsPrefixes.getString(index);
/*     */   }
/*     */   
/*     */   public String getNsURI(int index) {
/* 292 */     return this.mNamespaceURIs.getEntry(index);
/*     */   }
/*     */   
/*     */ 
/*     */   public String getPrefix(int index)
/*     */   {
/* 298 */     if ((index < 0) || (index >= this.mAttrCount)) {
/* 299 */       throwIndex(index);
/*     */     }
/* 301 */     return this.mAttrNames.getString(index << 1);
/*     */   }
/*     */   
/*     */   public String getLocalName(int index) {
/* 305 */     if ((index < 0) || (index >= this.mAttrCount)) {
/* 306 */       throwIndex(index);
/*     */     }
/* 308 */     return this.mAttrNames.getString((index << 1) + 1);
/*     */   }
/*     */   
/*     */   public String getURI(int index) {
/* 312 */     if ((index < 0) || (index >= this.mAttrCount)) {
/* 313 */       throwIndex(index);
/*     */     }
/* 315 */     return this.mAttrURIs[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public QName getQName(int index)
/*     */   {
/* 323 */     String prefix = getPrefix(index);
/* 324 */     if (prefix == null) {
/* 325 */       prefix = "";
/*     */     }
/* 327 */     return QNameCreator.create(getURI(index), getLocalName(index), prefix);
/*     */   }
/*     */   
/*     */ 
/*     */   public String getValue(String nsURI, String localName)
/*     */   {
/* 333 */     int hashSize = this.mAttrHashSize;
/* 334 */     if (hashSize == 0) {
/* 335 */       return null;
/*     */     }
/* 337 */     int hash = localName.hashCode();
/* 338 */     boolean hasURI = (nsURI != null) && (nsURI.length() > 0);
/* 339 */     if (hasURI) {
/* 340 */       hash ^= nsURI.hashCode();
/*     */     }
/* 342 */     int ix = this.mAttrMap[(hash & hashSize - 1)];
/* 343 */     if (ix == 0) {
/* 344 */       return null;
/*     */     }
/* 346 */     ix--;
/*     */     
/*     */ 
/* 349 */     String thisName = this.mAttrNames.getString(ix + ix + 1);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 354 */     if ((thisName == localName) || (thisName.equals(localName))) {
/* 355 */       String thisURI = this.mAttrURIs[ix];
/* 356 */       if (hasURI) {
/* 357 */         if ((nsURI == thisURI) || (nsURI.equals(thisURI))) {
/* 358 */           return getValue(ix);
/*     */         }
/*     */       }
/* 361 */       else if (thisURI == null) {
/* 362 */         return getValue(ix);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 370 */     int i = hashSize; for (int len = this.mAttrSpillEnd; i < len; i += 2) {
/* 371 */       if (this.mAttrMap[i] == hash)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 377 */         ix = this.mAttrMap[(i + 1)];
/* 378 */         thisName = this.mAttrNames.getString(ix + ix + 1);
/* 379 */         if ((thisName == localName) || (thisName.equals(localName))) {
/* 380 */           String thisURI = this.mAttrURIs[ix];
/* 381 */           if (hasURI) {
/* 382 */             if ((nsURI == thisURI) || (nsURI.equals(thisURI))) {
/* 383 */               return getValue(ix);
/*     */             }
/*     */           }
/* 386 */           else if (thisURI == null) {
/* 387 */             return getValue(ix);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 393 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int findIndex(String nsURI, String localName)
/*     */   {
/* 405 */     int hashSize = this.mAttrHashSize;
/* 406 */     if (hashSize == 0) {
/* 407 */       return -1;
/*     */     }
/* 409 */     int hash = localName.hashCode();
/* 410 */     boolean hasURI = (nsURI != null) && (nsURI.length() > 0);
/* 411 */     if (hasURI) {
/* 412 */       hash ^= nsURI.hashCode();
/*     */     }
/* 414 */     int ix = this.mAttrMap[(hash & hashSize - 1)];
/* 415 */     if (ix == 0) {
/* 416 */       return -1;
/*     */     }
/* 418 */     ix--;
/*     */     
/*     */ 
/* 421 */     String thisName = this.mAttrNames.getString(ix + ix + 1);
/* 422 */     if ((thisName == localName) || (thisName.equals(localName))) {
/* 423 */       String thisURI = this.mAttrURIs[ix];
/* 424 */       if (hasURI) {
/* 425 */         if ((nsURI == thisURI) || (nsURI.equals(thisURI))) {
/* 426 */           return ix;
/*     */         }
/*     */       }
/* 429 */       else if (thisURI == null) {
/* 430 */         return ix;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 438 */     int i = hashSize; for (int len = this.mAttrSpillEnd; i < len; i += 2) {
/* 439 */       if (this.mAttrMap[i] == hash)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 445 */         ix = this.mAttrMap[(i + 1)];
/* 446 */         thisName = this.mAttrNames.getString(ix + ix + 1);
/* 447 */         if ((thisName == localName) || (thisName.equals(localName))) {
/* 448 */           String thisURI = this.mAttrURIs[ix];
/* 449 */           if (hasURI) {
/* 450 */             if ((nsURI == thisURI) || (nsURI.equals(thisURI))) {
/* 451 */               return ix;
/*     */             }
/*     */           }
/* 454 */           else if (thisURI == null) {
/* 455 */             return ix;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 460 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TextBuilder getDefaultNsBuilder()
/*     */   {
/* 469 */     if (this.mDefaultNsDeclared) {
/* 470 */       return null;
/*     */     }
/* 472 */     this.mDefaultNsDeclared = true;
/* 473 */     this.mNsPrefixes.addString(null);
/* 474 */     return this.mNamespaceURIs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TextBuilder getNsBuilder(String prefix)
/*     */   {
/* 483 */     if (this.mNsPrefixes.containsInterned(prefix)) {
/* 484 */       return null;
/*     */     }
/* 486 */     this.mNsPrefixes.addString(prefix);
/* 487 */     return this.mNamespaceURIs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TextBuilder getAttrBuilder(String attrPrefix, String attrLocalName)
/*     */   {
/* 504 */     if (this.mAttrCount == 0) {
/* 505 */       if (this.mValueBuffer == null) {
/* 506 */         allocBuffers();
/*     */       }
/* 508 */       this.mAttrCount = 1;
/*     */     } else {
/* 510 */       this.mAttrCount += 1;
/*     */     }
/* 512 */     this.mAttrNames.addStrings(attrPrefix, attrLocalName);
/*     */     
/* 514 */     if ((attrPrefix == "xml") && (attrLocalName == "id") && 
/* 515 */       (this.mXmlIdAttrIndex != -2)) {
/* 516 */       this.mXmlIdAttrIndex = (this.mAttrCount - 1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 522 */     return this.mValueBuffer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String[] getNsPrefixes()
/*     */   {
/* 530 */     return this.mNsPrefixes.getInternalArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TextBuilder getNsURIs()
/*     */   {
/* 538 */     return this.mNamespaceURIs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String[] getAttrURIs()
/*     */   {
/* 546 */     return this.mAttrURIs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ElemAttrs buildAttrOb()
/*     */   {
/* 556 */     int count = this.mAttrCount;
/* 557 */     if (count == 0) {
/* 558 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 563 */     String[] raw = new String[count << 2];
/* 564 */     for (int i = 0; i < count; i++) {
/* 565 */       int ix = i << 2;
/* 566 */       raw[ix] = this.mAttrNames.getString(i + i + 1);
/* 567 */       raw[(ix + 1)] = this.mAttrURIs[i];
/* 568 */       raw[(ix + 2)] = this.mAttrNames.getString(i + i);
/* 569 */       raw[(ix + 3)] = getValue(i);
/*     */     }
/*     */     
/*     */ 
/* 573 */     if (count < 4) {
/* 574 */       return new ElemAttrs(raw, this.mNonDefCount);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 581 */     int amapLen = this.mAttrMap.length;
/* 582 */     int[] amap = new int[amapLen];
/*     */     
/* 584 */     System.arraycopy(this.mAttrMap, 0, amap, 0, amapLen);
/* 585 */     return new ElemAttrs(raw, this.mNonDefCount, amap, this.mAttrHashSize, this.mAttrSpillEnd);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int addDefaultAttribute(String localName, String uri, String prefix, String value)
/*     */   {
/* 605 */     int attrIndex = this.mAttrCount;
/* 606 */     if (attrIndex < 1)
/*     */     {
/*     */ 
/*     */ 
/* 610 */       initHashArea();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 617 */     int hash = localName.hashCode();
/* 618 */     if (uri.length() > 0) {
/* 619 */       hash ^= uri.hashCode();
/*     */     }
/* 621 */     int index = hash & this.mAttrHashSize - 1;
/* 622 */     int[] map = this.mAttrMap;
/* 623 */     if (map[index] == 0) {
/* 624 */       map[index] = (attrIndex + 1);
/*     */     } else {
/* 626 */       int currIndex = map[index] - 1;
/* 627 */       int spillIndex = this.mAttrSpillEnd;
/* 628 */       map = spillAttr(uri, localName, map, currIndex, spillIndex, attrIndex, hash, this.mAttrHashSize);
/*     */       
/* 630 */       if (map == null) {
/* 631 */         return -1;
/*     */       }
/* 633 */       map[(++spillIndex)] = attrIndex;
/* 634 */       this.mAttrMap = map;
/* 635 */       this.mAttrSpillEnd = (++spillIndex);
/*     */     }
/*     */     
/*     */ 
/* 639 */     this.mAttrNames.addStrings(prefix, localName);
/* 640 */     if (this.mAttrURIs == null) {
/* 641 */       this.mAttrURIs = new String[16];
/* 642 */     } else if (this.mAttrCount >= this.mAttrURIs.length) {
/* 643 */       this.mAttrURIs = DataUtil.growArrayBy(this.mAttrURIs, 8);
/*     */     }
/* 645 */     this.mAttrURIs[attrIndex] = uri;
/* 646 */     if (this.mAttrValues == null) {
/* 647 */       this.mAttrValues = new String[attrIndex + 8];
/* 648 */     } else if (attrIndex >= this.mAttrValues.length) {
/* 649 */       this.mAttrValues = DataUtil.growArrayBy(this.mAttrValues, 8);
/*     */     }
/* 651 */     this.mAttrValues[attrIndex] = value;
/*     */     
/* 653 */     return this.mAttrCount++;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeAttribute(int index, XmlWriter xw)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 664 */     int offset = index << 1;
/* 665 */     String ln = this.mAttrNames.getString(offset + 1);
/* 666 */     String prefix = this.mAttrNames.getString(offset);
/* 667 */     if ((prefix == null) || (prefix.length() == 0)) {
/* 668 */       xw.writeAttribute(ln, getValue(index));
/*     */     } else {
/* 670 */       xw.writeAttribute(prefix, ln, getValue(index));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int[] spillAttr(String uri, String name, int[] map, int currIndex, int spillIndex, int attrCount, int hash, int hashCount)
/*     */   {
/* 692 */     if (this.mAttrNames.getString(currIndex + currIndex + 1) == name)
/*     */     {
/* 694 */       String currURI = this.mAttrURIs[currIndex];
/* 695 */       if ((currURI == uri) || ((currURI != null) && (currURI.equals(uri)))) {
/* 696 */         return null;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 703 */     if (spillIndex + 1 >= map.length)
/*     */     {
/* 705 */       map = DataUtil.growArrayBy(map, 8);
/*     */     }
/*     */     
/* 708 */     for (int j = hashCount; j < spillIndex; j += 2) {
/* 709 */       if (map[j] == hash) {
/* 710 */         currIndex = map[(j + 1)];
/* 711 */         if (this.mAttrNames.getString(currIndex + currIndex + 1) == name) {
/* 712 */           String currURI = this.mAttrURIs[currIndex];
/* 713 */           if ((currURI == uri) || ((currURI != null) && (currURI.equals(uri)))) {
/* 714 */             return null;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 719 */     map[spillIndex] = hash;
/* 720 */     return map;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initHashArea()
/*     */   {
/* 734 */     this.mAttrHashSize = (this.mAttrSpillEnd = 4);
/* 735 */     if ((this.mAttrMap == null) || (this.mAttrMap.length < this.mAttrHashSize)) {
/* 736 */       this.mAttrMap = new int[this.mAttrHashSize + 1];
/*     */     }
/* 738 */     this.mAttrMap[0] = (this.mAttrMap[1] = this.mAttrMap[2] = this.mAttrMap[3] = 0);
/* 739 */     allocBuffers();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sr\NsAttributeCollector.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */