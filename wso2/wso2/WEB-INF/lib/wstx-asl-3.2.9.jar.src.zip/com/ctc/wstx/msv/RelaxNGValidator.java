/*     */ package com.ctc.wstx.msv;
/*     */ 
/*     */ import com.ctc.wstx.util.TextAccumulator;
/*     */ import com.sun.msv.grammar.IDContextProvider2;
/*     */ import com.sun.msv.util.DatatypeRef;
/*     */ import com.sun.msv.util.StartTagInfo;
/*     */ import com.sun.msv.util.StringRef;
/*     */ import com.sun.msv.verifier.Acceptor;
/*     */ import com.sun.msv.verifier.regexp.REDocumentDeclaration;
/*     */ import java.util.ArrayList;
/*     */ import org.codehaus.stax2.validation.ValidationContext;
/*     */ import org.codehaus.stax2.validation.XMLValidationException;
/*     */ import org.codehaus.stax2.validation.XMLValidationProblem;
/*     */ import org.codehaus.stax2.validation.XMLValidationSchema;
/*     */ import org.codehaus.stax2.validation.XMLValidator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RelaxNGValidator
/*     */   extends XMLValidator
/*     */ {
/*     */   final XMLValidationSchema mParentSchema;
/*     */   final ValidationContext mContext;
/*     */   final REDocumentDeclaration mVGM;
/*  72 */   final ArrayList mAcceptors = new ArrayList();
/*     */   
/*  74 */   Acceptor mCurrAcceptor = null;
/*     */   
/*  76 */   final TextAccumulator mTextAccumulator = new TextAccumulator();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  84 */   final StringRef mErrorRef = new StringRef();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */   final StartTagInfo mStartTag = new StartTagInfo("", "", "", null, (IDContextProvider2)null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final AttributeProxy mAttributeProxy;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final IDContextProvider2 mMsvContext;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RelaxNGValidator(XMLValidationSchema parent, ValidationContext ctxt, REDocumentDeclaration vgm)
/*     */   {
/* 111 */     this.mParentSchema = parent;
/* 112 */     this.mContext = ctxt;
/* 113 */     this.mVGM = vgm;
/*     */     
/* 115 */     this.mCurrAcceptor = this.mVGM.createAcceptor();
/* 116 */     this.mMsvContext = new MSVContextProvider(ctxt);
/* 117 */     this.mAttributeProxy = new AttributeProxy(ctxt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLValidationSchema getSchema()
/*     */   {
/* 127 */     return this.mParentSchema;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validateElementStart(String localName, String uri, String prefix)
/*     */     throws XMLValidationException
/*     */   {
/* 140 */     if (this.mTextAccumulator.hasText()) {
/* 141 */       doValidateText(this.mTextAccumulator);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 147 */     if (uri == null) {
/* 148 */       uri = "";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 156 */     String qname = localName;
/* 157 */     this.mStartTag.reinit(uri, localName, qname, this.mAttributeProxy, this.mMsvContext);
/*     */     
/* 159 */     this.mCurrAcceptor = this.mCurrAcceptor.createChildAcceptor(this.mStartTag, this.mErrorRef);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 164 */     if (this.mErrorRef.str != null) {
/* 165 */       reportError(this.mErrorRef);
/*     */     }
/* 167 */     this.mAcceptors.add(this.mCurrAcceptor);
/*     */   }
/*     */   
/*     */ 
/*     */   public String validateAttribute(String localName, String uri, String prefix, String value)
/*     */     throws XMLValidationException
/*     */   {
/* 174 */     if (this.mCurrAcceptor != null) {
/* 175 */       String qname = localName;
/* 176 */       DatatypeRef typeRef = null;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 181 */       if (uri == null) {
/* 182 */         uri = "";
/*     */       }
/*     */       
/* 185 */       if ((!this.mCurrAcceptor.onAttribute2(uri, localName, qname, value, this.mMsvContext, this.mErrorRef, typeRef)) || (this.mErrorRef.str != null))
/*     */       {
/* 187 */         reportError(this.mErrorRef);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 193 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validateAttribute(String localName, String uri, String prefix, char[] valueChars, int valueStart, int valueEnd)
/*     */     throws XMLValidationException
/*     */   {
/* 202 */     int len = valueEnd - valueStart;
/*     */     
/*     */ 
/*     */ 
/* 206 */     return validateAttribute(localName, uri, prefix, new String(valueChars, valueStart, len));
/*     */   }
/*     */   
/*     */ 
/*     */   public int validateElementAndAttributes()
/*     */     throws XMLValidationException
/*     */   {
/* 213 */     if (this.mCurrAcceptor != null)
/*     */     {
/*     */ 
/*     */ 
/* 217 */       if ((!this.mCurrAcceptor.onEndAttributes(this.mStartTag, this.mErrorRef)) || (this.mErrorRef.str != null))
/*     */       {
/* 219 */         reportError(this.mErrorRef);
/*     */       }
/*     */       
/* 222 */       int stringChecks = this.mCurrAcceptor.getStringCareLevel();
/* 223 */       switch (stringChecks) {
/*     */       case 0: 
/* 225 */         return 1;
/*     */       case 1: 
/* 227 */         return 3;
/*     */       case 2: 
/* 229 */         return 2;
/*     */       }
/* 231 */       throw new IllegalArgumentException("Internal error: unexpected string care level value return by MSV: " + stringChecks);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 236 */     return 3;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int validateElementEnd(String localName, String uri, String prefix)
/*     */     throws XMLValidationException
/*     */   {
/* 247 */     if (this.mTextAccumulator.hasText()) {
/* 248 */       doValidateText(this.mTextAccumulator);
/*     */     }
/*     */     
/* 251 */     Acceptor acc = (Acceptor)this.mAcceptors.remove(this.mAcceptors.size() - 1);
/* 252 */     if ((acc != null) && (
/* 253 */       (!acc.isAcceptState(this.mErrorRef)) || (this.mErrorRef.str != null))) {
/* 254 */       reportError(this.mErrorRef);
/*     */     }
/*     */     
/* 257 */     int len = this.mAcceptors.size();
/* 258 */     if (len == 0) {
/* 259 */       this.mCurrAcceptor = null;
/*     */     } else {
/* 261 */       this.mCurrAcceptor = ((Acceptor)this.mAcceptors.get(len - 1));
/*     */     }
/* 263 */     if ((this.mCurrAcceptor != null) && (acc != null)) {
/* 264 */       if ((!this.mCurrAcceptor.stepForward(acc, this.mErrorRef)) || (this.mErrorRef.str != null))
/*     */       {
/* 266 */         reportError(this.mErrorRef);
/*     */       }
/* 268 */       int stringChecks = this.mCurrAcceptor.getStringCareLevel();
/* 269 */       switch (stringChecks) {
/*     */       case 0: 
/* 271 */         return 1;
/*     */       case 1: 
/* 273 */         return 3;
/*     */       case 2: 
/* 275 */         return 2;
/*     */       }
/* 277 */       throw new IllegalArgumentException("Internal error: unexpected string care level value return by MSV: " + stringChecks);
/*     */     }
/*     */     
/* 280 */     return 3;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validateText(String text, boolean lastTextSegment)
/*     */     throws XMLValidationException
/*     */   {
/* 290 */     this.mTextAccumulator.addText(text);
/* 291 */     if (lastTextSegment) {
/* 292 */       doValidateText(this.mTextAccumulator);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validateText(char[] cbuf, int textStart, int textEnd, boolean lastTextSegment)
/*     */     throws XMLValidationException
/*     */   {
/* 304 */     this.mTextAccumulator.addText(cbuf, textStart, textEnd);
/* 305 */     if (lastTextSegment) {
/* 306 */       doValidateText(this.mTextAccumulator);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validationCompleted(boolean eod)
/*     */     throws XMLValidationException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAttributeType(int index)
/*     */   {
/* 327 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getIdAttrIndex()
/*     */   {
/* 333 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getNotationAttrIndex()
/*     */   {
/* 339 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void doValidateText(TextAccumulator textAcc)
/*     */     throws XMLValidationException
/*     */   {
/* 351 */     if (this.mCurrAcceptor != null) {
/* 352 */       String str = textAcc.getAndClear();
/* 353 */       DatatypeRef typeRef = null;
/* 354 */       if ((!this.mCurrAcceptor.onText2(str, this.mMsvContext, this.mErrorRef, typeRef)) || (this.mErrorRef.str != null))
/*     */       {
/* 356 */         reportError(this.mErrorRef);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void reportError(StringRef errorRef)
/*     */     throws XMLValidationException
/*     */   {
/* 364 */     String msg = errorRef.str;
/* 365 */     errorRef.str = null;
/* 366 */     if (msg == null) {
/* 367 */       msg = "Unknown reason";
/*     */     }
/* 369 */     this.mContext.reportProblem(new XMLValidationProblem(this.mContext.getValidationLocation(), msg, 2));
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\msv\RelaxNGValidator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */