package com.ctc.wstx.sr;

import org.codehaus.stax2.validation.XMLValidationException;

public abstract interface NsDefaultProvider
{
  public abstract boolean mayHaveNsDefaults(String paramString1, String paramString2);
  
  public abstract void checkNsDefaults(InputElementStack paramInputElementStack)
    throws XMLValidationException;
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sr\NsDefaultProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */