/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ import com.ctc.wstx.ent.EntityDecl;
/*     */ import com.ctc.wstx.io.WstxInputData;
/*     */ import com.ctc.wstx.sr.InputProblemReporter;
/*     */ import com.ctc.wstx.util.StringUtil;
/*     */ import com.ctc.wstx.util.WordResolver;
/*     */ import java.util.Map;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.codehaus.stax2.validation.ValidationContext;
/*     */ import org.codehaus.stax2.validation.XMLValidationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DTDAttribute
/*     */ {
/*     */   static final char CHAR_SPACE = ' ';
/*     */   public static final int TYPE_CDATA = 0;
/*     */   public static final int TYPE_ENUMERATED = 1;
/*     */   public static final int TYPE_ID = 2;
/*     */   public static final int TYPE_IDREF = 3;
/*     */   public static final int TYPE_IDREFS = 4;
/*     */   public static final int TYPE_ENTITY = 5;
/*     */   public static final int TYPE_ENTITIES = 6;
/*     */   public static final int TYPE_NOTATION = 7;
/*     */   public static final int TYPE_NMTOKEN = 8;
/*     */   public static final int TYPE_NMTOKENS = 9;
/*  66 */   static final String[] sTypes = { "CDATA", "ENUMERATED", "ID", "IDREF", "IDREFS", "ENTITY", "ENTITIES", "NOTATION", "NMTOKEN", "NMTOKENS" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final NameKey mName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final int mSpecialIndex;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final DefaultAttrValue mDefValue;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final boolean mCfgNsAware;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final boolean mCfgXml11;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DTDAttribute(NameKey name, DefaultAttrValue defValue, int specIndex, boolean nsAware, boolean xml11)
/*     */   {
/* 116 */     this.mName = name;
/* 117 */     this.mDefValue = defValue;
/* 118 */     this.mSpecialIndex = specIndex;
/* 119 */     this.mCfgNsAware = nsAware;
/* 120 */     this.mCfgXml11 = xml11;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract DTDAttribute cloneWith(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */   public final NameKey getName()
/*     */   {
/* 131 */     return this.mName;
/*     */   }
/*     */   
/* 134 */   public final String toString() { return this.mName.toString(); }
/*     */   
/*     */ 
/*     */   public final String getDefaultValue(ValidationContext ctxt)
/*     */     throws XMLValidationException
/*     */   {
/* 140 */     String val = this.mDefValue.getValueIfOk();
/* 141 */     if (val == null) {
/* 142 */       this.mDefValue.reportUndeclared(ctxt);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 147 */       val = this.mDefValue.getValue();
/*     */     }
/* 149 */     return val;
/*     */   }
/*     */   
/*     */   public final int getSpecialIndex() {
/* 153 */     return this.mSpecialIndex;
/*     */   }
/*     */   
/*     */   public final boolean needsValidation() {
/* 157 */     return getValueType() != 0;
/*     */   }
/*     */   
/*     */   public final boolean isFixed() {
/* 161 */     return this.mDefValue.isFixed();
/*     */   }
/*     */   
/*     */   public final boolean isRequired() {
/* 165 */     return this.mDefValue.isRequired();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isSpecial()
/*     */   {
/* 175 */     return this.mDefValue.isSpecial();
/*     */   }
/*     */   
/*     */   public final boolean hasDefaultValue() {
/* 179 */     return this.mDefValue.hasDefaultValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getValueType()
/*     */   {
/* 189 */     return 0;
/*     */   }
/*     */   
/*     */   public String getValueTypeString()
/*     */   {
/* 194 */     return sTypes[getValueType()];
/*     */   }
/*     */   
/*     */   public boolean typeIsId() {
/* 198 */     return false;
/*     */   }
/*     */   
/*     */   public boolean typeIsNotation() {
/* 202 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String validate(DTDValidatorBase paramDTDValidatorBase, char[] paramArrayOfChar, int paramInt1, int paramInt2, boolean paramBoolean)
/*     */     throws XMLValidationException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validate(DTDValidatorBase v, String value, boolean normalize)
/*     */     throws XMLValidationException
/*     */   {
/* 226 */     int len = value.length();
/*     */     
/*     */ 
/*     */ 
/* 230 */     char[] cbuf = v.getTempAttrValueBuffer(value.length());
/* 231 */     if (len > 0) {
/* 232 */       value.getChars(0, len, cbuf, 0);
/*     */     }
/* 234 */     return validate(v, cbuf, 0, len, normalize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void validateDefault(InputProblemReporter paramInputProblemReporter, boolean paramBoolean)
/*     */     throws XMLStreamException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String normalize(DTDValidatorBase v, char[] cbuf, int start, int end)
/*     */   {
/* 261 */     return StringUtil.normalizeSpaces(cbuf, start, end);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void normalizeDefault()
/*     */   {
/* 271 */     String val = this.mDefValue.getValue();
/* 272 */     if (val.length() > 0) {
/* 273 */       char[] cbuf = val.toCharArray();
/* 274 */       String str = StringUtil.normalizeSpaces(cbuf, 0, cbuf.length);
/* 275 */       if (str != null) {
/* 276 */         this.mDefValue.setValue(str);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String validateDefaultName(InputProblemReporter rep, boolean normalize)
/*     */     throws XMLValidationException
/*     */   {
/* 290 */     String origDefValue = this.mDefValue.getValue();
/* 291 */     String defValue = origDefValue.trim();
/*     */     
/* 293 */     if (defValue.length() == 0) {
/* 294 */       reportValidationProblem(rep, "Invalid default value '" + defValue + "'; empty String is not a valid name");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 299 */     int illegalIx = WstxInputData.findIllegalNameChar(defValue, this.mCfgNsAware, this.mCfgXml11);
/* 300 */     if (illegalIx >= 0) {
/* 301 */       if (illegalIx == 0) {
/* 302 */         reportValidationProblem(rep, "Invalid default value '" + defValue + "'; character " + WstxInputData.getCharDesc(defValue.charAt(0)) + ") not valid first character of a name");
/*     */       }
/*     */       else
/*     */       {
/* 306 */         reportValidationProblem(rep, "Invalid default value '" + defValue + "'; character #" + illegalIx + " (" + WstxInputData.getCharDesc(defValue.charAt(illegalIx)) + ") not valid name character");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 313 */     return normalize ? defValue : origDefValue;
/*     */   }
/*     */   
/*     */   protected String validateDefaultNames(InputProblemReporter rep, boolean normalize)
/*     */     throws XMLValidationException
/*     */   {
/* 319 */     String defValue = this.mDefValue.getValue().trim();
/* 320 */     int len = defValue.length();
/*     */     
/*     */ 
/* 323 */     StringBuffer sb = null;
/* 324 */     int count = 0;
/* 325 */     int start = 0;
/*     */     
/*     */ 
/* 328 */     while (start < len) {
/* 329 */       char c = defValue.charAt(start);
/*     */       
/*     */ 
/*     */ 
/* 333 */       while (WstxInputData.isSpaceChar(c))
/*     */       {
/*     */ 
/* 336 */         start++; if (start >= len) {
/*     */           break label295;
/*     */         }
/* 339 */         c = defValue.charAt(start);
/*     */       }
/*     */       
/*     */ 
/* 343 */       for (int i = start + 1; 
/*     */           
/* 345 */           i < len; i++) {
/* 346 */         if (WstxInputData.isSpaceChar(defValue.charAt(i))) {
/*     */           break;
/*     */         }
/*     */       }
/* 350 */       String token = defValue.substring(start, i);
/* 351 */       int illegalIx = WstxInputData.findIllegalNameChar(token, this.mCfgNsAware, this.mCfgXml11);
/* 352 */       if (illegalIx >= 0) {
/* 353 */         if (illegalIx == 0) {
/* 354 */           reportValidationProblem(rep, "Invalid default value '" + defValue + "'; character " + WstxInputData.getCharDesc(defValue.charAt(start)) + ") not valid first character of a name token");
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 359 */           reportValidationProblem(rep, "Invalid default value '" + defValue + "'; character " + WstxInputData.getCharDesc(c) + ") not a valid name character");
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 365 */       count++;
/* 366 */       if (normalize) {
/* 367 */         if (sb == null) {
/* 368 */           sb = new StringBuffer(i - start + 32);
/*     */         } else {
/* 370 */           sb.append(' ');
/*     */         }
/* 372 */         sb.append(token);
/*     */       }
/* 374 */       start = i + 1;
/*     */     }
/*     */     label295:
/* 377 */     if (count == 0) {
/* 378 */       reportValidationProblem(rep, "Invalid default value '" + defValue + "'; empty String is not a valid name value");
/*     */     }
/*     */     
/*     */ 
/* 382 */     return normalize ? sb.toString() : defValue;
/*     */   }
/*     */   
/*     */   protected String validateDefaultNmToken(InputProblemReporter rep, boolean normalize)
/*     */     throws XMLValidationException
/*     */   {
/* 388 */     String origDefValue = this.mDefValue.getValue();
/* 389 */     String defValue = origDefValue.trim();
/*     */     
/* 391 */     if (defValue.length() == 0) {
/* 392 */       reportValidationProblem(rep, "Invalid default value '" + defValue + "'; empty String is not a valid NMTOKEN");
/*     */     }
/* 394 */     int illegalIx = WstxInputData.findIllegalNmtokenChar(defValue, this.mCfgNsAware, this.mCfgXml11);
/* 395 */     if (illegalIx >= 0) {
/* 396 */       reportValidationProblem(rep, "Invalid default value '" + defValue + "'; character #" + illegalIx + " (" + WstxInputData.getCharDesc(defValue.charAt(illegalIx)) + ") not valid NMTOKEN character");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 402 */     return normalize ? defValue : origDefValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validateEnumValue(char[] cbuf, int start, int end, boolean normalize, WordResolver res)
/*     */   {
/* 423 */     if (normalize) {
/* 424 */       while ((start < end) && (cbuf[start] <= ' '))
/* 425 */         start++;
/*     */       do {
/* 427 */         end--; } while ((end > start) && (cbuf[end] <= ' '));
/*     */       
/*     */ 
/* 430 */       end++;
/*     */     }
/*     */     
/*     */ 
/* 434 */     if (start >= end) {
/* 435 */       return null;
/*     */     }
/* 437 */     return res.find(cbuf, start, end);
/*     */   }
/*     */   
/*     */ 
/*     */   protected EntityDecl findEntityDecl(DTDValidatorBase v, char[] ch, int start, int len, int hash)
/*     */     throws XMLValidationException
/*     */   {
/* 444 */     Map entMap = v.getEntityMap();
/*     */     
/*     */ 
/*     */ 
/* 448 */     String id = new String(ch, start, len);
/* 449 */     EntityDecl ent = (EntityDecl)entMap.get(id);
/*     */     
/* 451 */     if (ent == null) {
/* 452 */       reportValidationProblem(v, "Referenced entity '" + id + "' not defined");
/* 453 */     } else if (ent.isParsed()) {
/* 454 */       reportValidationProblem(v, "Referenced entity '" + id + "' is not an unparsed entity");
/*     */     }
/* 456 */     return ent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkEntity(InputProblemReporter rep, String id, EntityDecl ent)
/*     */     throws XMLValidationException
/*     */   {
/* 467 */     if (ent == null) {
/* 468 */       rep.reportValidationProblem("Referenced entity '" + id + "' not defined");
/* 469 */     } else if (ent.isParsed()) {
/* 470 */       rep.reportValidationProblem("Referenced entity '" + id + "' is not an unparsed entity");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String reportInvalidChar(DTDValidatorBase v, char c, String msg)
/*     */     throws XMLValidationException
/*     */   {
/* 483 */     reportValidationProblem(v, "Invalid character " + WstxInputData.getCharDesc(c) + ": " + msg);
/* 484 */     return null;
/*     */   }
/*     */   
/*     */   protected String reportValidationProblem(DTDValidatorBase v, String msg)
/*     */     throws XMLValidationException
/*     */   {
/* 490 */     v.reportValidationProblem("Attribute '" + this.mName + "': " + msg);
/* 491 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String reportValidationProblem(InputProblemReporter rep, String msg)
/*     */     throws XMLValidationException
/*     */   {
/* 503 */     rep.reportValidationProblem("Attribute definition '" + this.mName + "': " + msg);
/* 504 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\DTDAttribute.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */