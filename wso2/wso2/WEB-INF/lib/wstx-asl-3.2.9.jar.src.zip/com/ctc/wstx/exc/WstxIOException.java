/*    */ package com.ctc.wstx.exc;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WstxIOException
/*    */   extends WstxException
/*    */ {
/*    */   public WstxIOException(IOException ie)
/*    */   {
/* 16 */     super(ie);
/*    */   }
/*    */   
/*    */   public WstxIOException(String msg) {
/* 20 */     super(msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\exc\WstxIOException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */