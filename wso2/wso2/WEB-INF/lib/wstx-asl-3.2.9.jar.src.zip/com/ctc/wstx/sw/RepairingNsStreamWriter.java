/*     */ package com.ctc.wstx.sw;
/*     */ 
/*     */ import com.ctc.wstx.api.WriterConfig;
/*     */ import com.ctc.wstx.cfg.ErrorConsts;
/*     */ import com.ctc.wstx.sr.AttributeCollector;
/*     */ import com.ctc.wstx.sr.InputElementStack;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.events.Attribute;
/*     */ import javax.xml.stream.events.StartElement;
/*     */ import org.codehaus.stax2.validation.XMLValidator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RepairingNsStreamWriter
/*     */   extends BaseNsStreamWriter
/*     */ {
/*     */   final String mAutomaticNsPrefix;
/*  76 */   int[] mAutoNsSeq = null;
/*     */   
/*  78 */   String mSuggestedDefNs = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  87 */   HashMap mSuggestedPrefixes = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RepairingNsStreamWriter(XmlWriter xw, String enc, WriterConfig cfg)
/*     */   {
/*  97 */     super(xw, enc, cfg, true);
/*  98 */     this.mAutomaticNsPrefix = cfg.getAutomaticNsPrefix();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeAttribute(String nsURI, String localName, String value)
/*     */     throws XMLStreamException
/*     */   {
/* 119 */     if (!this.mStartElementOpen) {
/* 120 */       throwOutputError(ErrorConsts.WERR_ATTR_NO_ELEM);
/*     */     }
/* 122 */     doWriteAttr(localName, nsURI, findOrCreateAttrPrefix(null, nsURI, this.mCurrElem), value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeAttribute(String prefix, String nsURI, String localName, String value)
/*     */     throws XMLStreamException
/*     */   {
/* 131 */     if (!this.mStartElementOpen) {
/* 132 */       throwOutputError(ErrorConsts.WERR_ATTR_NO_ELEM);
/*     */     }
/*     */     
/* 135 */     doWriteAttr(localName, nsURI, findOrCreateAttrPrefix(prefix, nsURI, this.mCurrElem), value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeDefaultNamespace(String nsURI)
/*     */     throws XMLStreamException
/*     */   {
/* 157 */     if (!this.mStartElementOpen) {
/* 158 */       throwOutputError("Trying to write a namespace declaration when there is no open start element.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 165 */     String prefix = this.mCurrElem.getPrefix();
/* 166 */     if ((prefix != null) && (prefix.length() > 0)) {
/* 167 */       this.mCurrElem.setDefaultNsUri(nsURI);
/* 168 */       doWriteDefaultNs(nsURI);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeNamespace(String prefix, String nsURI)
/*     */     throws XMLStreamException
/*     */   {
/* 180 */     if ((prefix == null) || (prefix.length() == 0)) {
/* 181 */       writeDefaultNamespace(nsURI);
/* 182 */       return;
/*     */     }
/* 184 */     if (!this.mStartElementOpen) {
/* 185 */       throwOutputError("Trying to write a namespace declaration when there is no open start element.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 193 */     int value = this.mCurrElem.isPrefixValid(prefix, nsURI, true);
/* 194 */     if (value == 0) {
/* 195 */       this.mCurrElem.addPrefix(prefix, nsURI);
/* 196 */       doWriteNamespace(prefix, nsURI);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultNamespace(String uri)
/*     */     throws XMLStreamException
/*     */   {
/* 213 */     this.mSuggestedDefNs = ((uri == null) || (uri.length() == 0) ? null : uri);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doSetPrefix(String prefix, String uri)
/*     */     throws XMLStreamException
/*     */   {
/* 223 */     if ((uri == null) || (uri.length() == 0)) {
/* 224 */       if (this.mSuggestedPrefixes != null) {
/* 225 */         Iterator it = this.mSuggestedPrefixes.entrySet().iterator();
/* 226 */         while (it.hasNext()) {
/* 227 */           Map.Entry en = (Map.Entry)it.next();
/* 228 */           String thisP = (String)en.getValue();
/* 229 */           if (thisP.equals(prefix)) {
/* 230 */             it.remove();
/*     */           }
/*     */         }
/*     */       }
/*     */     } else {
/* 235 */       if (this.mSuggestedPrefixes == null) {
/* 236 */         this.mSuggestedPrefixes = new HashMap(16);
/*     */       }
/* 238 */       this.mSuggestedPrefixes.put(uri, prefix);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeStartElement(StartElement elem)
/*     */     throws XMLStreamException
/*     */   {
/* 248 */     QName name = elem.getName();
/* 249 */     writeStartElement(name.getPrefix(), name.getLocalPart(), name.getNamespaceURI());
/*     */     
/* 251 */     Iterator it = elem.getAttributes();
/* 252 */     while (it.hasNext()) {
/* 253 */       Attribute attr = (Attribute)it.next();
/* 254 */       name = attr.getName();
/* 255 */       writeAttribute(name.getPrefix(), name.getNamespaceURI(), name.getLocalPart(), attr.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeStartOrEmpty(String localName, String nsURI)
/*     */     throws XMLStreamException
/*     */   {
/* 265 */     checkStartElement(localName, "");
/*     */     
/*     */ 
/* 268 */     String prefix = findElemPrefix(nsURI, this.mCurrElem);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 274 */     if (this.mOutputElemPool != null) {
/* 275 */       SimpleOutputElement newCurr = this.mOutputElemPool;
/* 276 */       this.mOutputElemPool = newCurr.reuseAsChild(this.mCurrElem, prefix, localName, nsURI);
/* 277 */       this.mPoolSize -= 1;
/* 278 */       this.mCurrElem = newCurr;
/*     */     } else {
/* 280 */       this.mCurrElem = this.mCurrElem.createChild(prefix, localName, nsURI);
/*     */     }
/*     */     
/* 283 */     if (prefix != null) {
/* 284 */       if (this.mValidator != null) {
/* 285 */         this.mValidator.validateElementStart(localName, nsURI, prefix);
/*     */       }
/* 287 */       doWriteStartTag(prefix, localName);
/*     */     } else {
/* 289 */       prefix = generateElemPrefix(null, nsURI, this.mCurrElem);
/* 290 */       if (this.mValidator != null) {
/* 291 */         this.mValidator.validateElementStart(localName, nsURI, prefix);
/*     */       }
/* 293 */       this.mCurrElem.setPrefix(prefix);
/* 294 */       doWriteStartTag(prefix, localName);
/* 295 */       if ((prefix == null) || (prefix.length() == 0)) {
/* 296 */         this.mCurrElem.setDefaultNsUri(nsURI);
/* 297 */         doWriteDefaultNs(nsURI);
/*     */       } else {
/* 299 */         this.mCurrElem.addPrefix(prefix, nsURI);
/* 300 */         doWriteNamespace(prefix, nsURI);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void writeStartOrEmpty(String suggPrefix, String localName, String nsURI)
/*     */     throws XMLStreamException
/*     */   {
/* 308 */     checkStartElement(localName, suggPrefix);
/*     */     
/*     */ 
/* 311 */     String actPrefix = validateElemPrefix(suggPrefix, nsURI, this.mCurrElem);
/* 312 */     if (actPrefix != null) {
/* 313 */       if (this.mValidator != null) {
/* 314 */         this.mValidator.validateElementStart(localName, nsURI, actPrefix);
/*     */       }
/* 316 */       if (this.mOutputElemPool != null) {
/* 317 */         SimpleOutputElement newCurr = this.mOutputElemPool;
/* 318 */         this.mOutputElemPool = newCurr.reuseAsChild(this.mCurrElem, actPrefix, localName, nsURI);
/* 319 */         this.mPoolSize -= 1;
/* 320 */         this.mCurrElem = newCurr;
/*     */       } else {
/* 322 */         this.mCurrElem = this.mCurrElem.createChild(actPrefix, localName, nsURI);
/*     */       }
/* 324 */       doWriteStartTag(actPrefix, localName);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 330 */       if (suggPrefix == null) {
/* 331 */         suggPrefix = "";
/*     */       }
/* 333 */       actPrefix = generateElemPrefix(suggPrefix, nsURI, this.mCurrElem);
/* 334 */       if (this.mValidator != null) {
/* 335 */         this.mValidator.validateElementStart(localName, nsURI, actPrefix);
/*     */       }
/* 337 */       if (this.mOutputElemPool != null) {
/* 338 */         SimpleOutputElement newCurr = this.mOutputElemPool;
/* 339 */         this.mOutputElemPool = newCurr.reuseAsChild(this.mCurrElem, actPrefix, localName, nsURI);
/* 340 */         this.mPoolSize -= 1;
/* 341 */         this.mCurrElem = newCurr;
/*     */       } else {
/* 343 */         this.mCurrElem = this.mCurrElem.createChild(actPrefix, localName, nsURI);
/*     */       }
/* 345 */       this.mCurrElem.setPrefix(actPrefix);
/* 346 */       doWriteStartTag(actPrefix, localName);
/* 347 */       if ((actPrefix == null) || (actPrefix.length() == 0)) {
/* 348 */         this.mCurrElem.setDefaultNsUri(nsURI);
/* 349 */         doWriteDefaultNs(nsURI);
/*     */       } else {
/* 351 */         this.mCurrElem.addPrefix(actPrefix, nsURI);
/* 352 */         doWriteNamespace(actPrefix, nsURI);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void copyStartElement(InputElementStack elemStack, AttributeCollector attrCollector)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 375 */     String prefix = elemStack.getPrefix();
/* 376 */     String uri = elemStack.getNsURI();
/* 377 */     writeStartElement(prefix, elemStack.getLocalName(), uri);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 386 */     int nsCount = elemStack.getCurrentNsCount();
/* 387 */     if (nsCount > 0) {
/* 388 */       for (int i = 0; i < nsCount; i++) {
/* 389 */         writeNamespace(elemStack.getLocalNsPrefix(i), elemStack.getLocalNsURI(i));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 396 */     AttributeCollector ac = this.mAttrCollector;
/* 397 */     int attrCount = this.mCfgCopyDefaultAttrs ? ac.getCount() : ac.getSpecifiedCount();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 404 */     if (attrCount > 0) {
/* 405 */       for (int i = 0; i < attrCount; i++)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 410 */         uri = attrCollector.getURI(i);
/* 411 */         prefix = attrCollector.getPrefix(i);
/*     */         
/*     */ 
/*     */ 
/* 415 */         if ((prefix != null) && (prefix.length() != 0))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 420 */           prefix = findOrCreateAttrPrefix(prefix, uri, this.mCurrElem);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 426 */         if ((prefix == null) || (prefix.length() == 0)) {
/* 427 */           this.mWriter.writeAttribute(attrCollector.getLocalName(i), attrCollector.getValue(i));
/*     */         } else {
/* 429 */           this.mWriter.writeAttribute(prefix, attrCollector.getLocalName(i), attrCollector.getValue(i));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final String findElemPrefix(String nsURI, SimpleOutputElement elem)
/*     */     throws XMLStreamException
/*     */   {
/* 454 */     if ((nsURI == null) || (nsURI.length() == 0)) {
/* 455 */       String currDefNsURI = elem.getDefaultNsUri();
/* 456 */       if ((currDefNsURI != null) && (currDefNsURI.length() > 0))
/*     */       {
/* 458 */         return null;
/*     */       }
/* 460 */       return "";
/*     */     }
/* 462 */     return this.mCurrElem.getPrefix(nsURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final String generateElemPrefix(String suggPrefix, String nsURI, SimpleOutputElement elem)
/*     */     throws XMLStreamException
/*     */   {
/* 479 */     if ((nsURI == null) || (nsURI.length() == 0)) {
/* 480 */       return "";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 486 */     if (suggPrefix == null)
/*     */     {
/* 488 */       if ((this.mSuggestedDefNs != null) && (this.mSuggestedDefNs.equals(nsURI))) {
/* 489 */         suggPrefix = "";
/*     */       } else {
/* 491 */         suggPrefix = this.mSuggestedPrefixes == null ? null : (String)this.mSuggestedPrefixes.get(nsURI);
/*     */         
/* 493 */         if (suggPrefix == null)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 499 */           if (this.mAutoNsSeq == null) {
/* 500 */             this.mAutoNsSeq = new int[1];
/* 501 */             this.mAutoNsSeq[0] = 1;
/*     */           }
/* 503 */           suggPrefix = elem.generateMapping(this.mAutomaticNsPrefix, nsURI, this.mAutoNsSeq);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 510 */     return suggPrefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final String findOrCreateAttrPrefix(String suggPrefix, String nsURI, SimpleOutputElement elem)
/*     */     throws XMLStreamException
/*     */   {
/* 530 */     if ((nsURI == null) || (nsURI.length() == 0))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 535 */       return null;
/*     */     }
/*     */     
/* 538 */     if (suggPrefix != null) {
/* 539 */       int status = elem.isPrefixValid(suggPrefix, nsURI, false);
/* 540 */       if (status == 1) {
/* 541 */         return suggPrefix;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 550 */       if (status == 0) {
/* 551 */         elem.addPrefix(suggPrefix, nsURI);
/* 552 */         doWriteNamespace(suggPrefix, nsURI);
/* 553 */         return suggPrefix;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 558 */     String prefix = elem.getExplicitPrefix(nsURI);
/* 559 */     if (prefix != null) {
/* 560 */       return prefix;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 566 */     if (suggPrefix != null) {
/* 567 */       prefix = suggPrefix;
/* 568 */     } else if (this.mSuggestedPrefixes != null) {
/* 569 */       prefix = (String)this.mSuggestedPrefixes.get(nsURI);
/*     */     }
/*     */     
/*     */ 
/* 573 */     if (prefix != null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 580 */       if ((prefix.length() == 0) || (elem.getNamespaceURI(prefix) != null))
/*     */       {
/* 582 */         prefix = null;
/*     */       }
/*     */     }
/*     */     
/* 586 */     if (prefix == null) {
/* 587 */       if (this.mAutoNsSeq == null) {
/* 588 */         this.mAutoNsSeq = new int[1];
/* 589 */         this.mAutoNsSeq[0] = 1;
/*     */       }
/* 591 */       prefix = this.mCurrElem.generateMapping(this.mAutomaticNsPrefix, nsURI, this.mAutoNsSeq);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 596 */     elem.addPrefix(prefix, nsURI);
/* 597 */     doWriteNamespace(prefix, nsURI);
/* 598 */     return prefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String validateElemPrefix(String prefix, String nsURI, SimpleOutputElement elem)
/*     */     throws XMLStreamException
/*     */   {
/* 609 */     if ((nsURI == null) || (nsURI.length() == 0)) {
/* 610 */       String currURL = elem.getDefaultNsUri();
/* 611 */       if ((currURL == null) || (currURL.length() == 0))
/*     */       {
/* 613 */         return "";
/*     */       }
/*     */       
/* 616 */       return null;
/*     */     }
/*     */     
/* 619 */     int status = elem.isPrefixValid(prefix, nsURI, true);
/* 620 */     if (status == 1) {
/* 621 */       return prefix;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 630 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sw\RepairingNsStreamWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */