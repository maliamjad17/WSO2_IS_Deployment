/*    */ package com.ctc.wstx.io;
/*    */ 
/*    */ import com.ctc.wstx.api.ReaderConfig;
/*    */ import java.io.Reader;
/*    */ import java.net.URL;
/*    */ import javax.xml.stream.Location;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class InputSourceFactory
/*    */ {
/*    */   public static ReaderSource constructEntitySource(ReaderConfig cfg, WstxInputSource parent, String entityName, InputBootstrapper bs, String pubId, String sysId, int xmlVersion, URL src, Reader r)
/*    */   {
/* 36 */     ReaderSource rs = new ReaderSource(cfg, parent, entityName, pubId, sysId, src, r, true);
/*    */     
/* 38 */     if (bs != null) {
/* 39 */       rs.setInputOffsets(bs.getInputTotal(), bs.getInputRow(), -bs.getInputColumn());
/*    */     }
/*    */     
/* 42 */     return rs;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static BranchingReaderSource constructDocumentSource(ReaderConfig cfg, InputBootstrapper bs, String pubId, String sysId, URL src, Reader r, boolean realClose)
/*    */   {
/* 53 */     BranchingReaderSource rs = new BranchingReaderSource(cfg, pubId, sysId, src, r, realClose);
/*    */     
/* 55 */     if (bs != null) {
/* 56 */       rs.setInputOffsets(bs.getInputTotal(), bs.getInputRow(), -bs.getInputColumn());
/*    */     }
/*    */     
/* 59 */     return rs;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static WstxInputSource constructCharArraySource(WstxInputSource parent, String fromEntity, char[] text, int offset, int len, Location loc, URL src)
/*    */   {
/* 70 */     return new CharArraySource(parent, fromEntity, text, offset, len, loc, src);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\io\InputSourceFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */