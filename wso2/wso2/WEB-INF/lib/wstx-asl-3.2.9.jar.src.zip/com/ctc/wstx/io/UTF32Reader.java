/*     */ package com.ctc.wstx.io;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import java.io.CharConversionException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UTF32Reader
/*     */   extends BaseReader
/*     */ {
/*     */   final boolean mBigEndian;
/*     */   boolean mXml11;
/*  39 */   char mSurrogate = '\000';
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  44 */   int mCharCount = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  49 */   int mByteCount = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UTF32Reader(ReaderConfig cfg, InputStream in, byte[] buf, int ptr, int len, boolean isBigEndian)
/*     */   {
/*  60 */     super(cfg, in, buf, ptr, len);
/*  61 */     this.mBigEndian = isBigEndian;
/*     */   }
/*     */   
/*     */   public void setXmlCompliancy(int xmlVersion)
/*     */   {
/*  66 */     this.mXml11 = (xmlVersion == 272);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(char[] cbuf, int start, int len)
/*     */     throws IOException
/*     */   {
/*  79 */     if (this.mBuffer == null) {
/*  80 */       return -1;
/*     */     }
/*  82 */     if (len < 1) {
/*  83 */       return len;
/*     */     }
/*     */     
/*  86 */     if ((start < 0) || (start + len > cbuf.length)) {
/*  87 */       reportBounds(cbuf, start, len);
/*     */     }
/*     */     
/*  90 */     len += start;
/*  91 */     int outPtr = start;
/*     */     
/*     */ 
/*  94 */     if (this.mSurrogate != 0) {
/*  95 */       cbuf[(outPtr++)] = this.mSurrogate;
/*  96 */       this.mSurrogate = '\000';
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 102 */       int left = this.mLength - this.mPtr;
/* 103 */       if ((left < 4) && 
/* 104 */         (!loadMore(left))) {
/* 105 */         return -1;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 110 */     byte[] buf = this.mBuffer;
/*     */     
/*     */ 
/* 113 */     while (outPtr < len) {
/* 114 */       int ptr = this.mPtr;
/*     */       int ch;
/*     */       int ch;
/* 117 */       if (this.mBigEndian) {
/* 118 */         ch = this.mBuffer[ptr] << 24 | (this.mBuffer[(ptr + 1)] & 0xFF) << 16 | (this.mBuffer[(ptr + 2)] & 0xFF) << 8 | this.mBuffer[(ptr + 3)] & 0xFF;
/*     */       }
/*     */       else {
/* 121 */         ch = this.mBuffer[ptr] & 0xFF | (this.mBuffer[(ptr + 1)] & 0xFF) << 8 | (this.mBuffer[(ptr + 2)] & 0xFF) << 16 | this.mBuffer[(ptr + 3)] << 24;
/*     */       }
/*     */       
/* 124 */       this.mPtr += 4;
/*     */       
/*     */ 
/*     */ 
/* 128 */       if (ch >= 127) {
/* 129 */         if (ch <= 159) {
/* 130 */           if (this.mXml11) {
/* 131 */             if (ch != 133) {
/* 132 */               reportInvalid(ch, outPtr - start, "(can only be included via entity in xml 1.1)");
/*     */             }
/* 134 */             ch = 10;
/*     */           }
/* 136 */         } else if (ch >= 55296)
/*     */         {
/* 138 */           if (ch > 1114111) {
/* 139 */             reportInvalid(ch, outPtr - start, "(above " + Integer.toHexString(1114111) + ") ");
/*     */           }
/*     */           
/* 142 */           if (ch > 65535) {
/* 143 */             ch -= 65536;
/* 144 */             cbuf[(outPtr++)] = ((char)(55296 + (ch >> 10)));
/*     */             
/* 146 */             ch = 0xDC00 | ch & 0x3FF;
/*     */             
/* 148 */             if (outPtr >= len) {
/* 149 */               this.mSurrogate = ((char)ch);
/* 150 */               break;
/*     */             }
/*     */           }
/* 153 */           else if (ch < 57344) {
/* 154 */             reportInvalid(ch, outPtr - start, "(a surrogate char) ");
/* 155 */           } else if (ch >= 65534) {
/* 156 */             reportInvalid(ch, outPtr - start, "");
/*     */           }
/*     */         }
/* 159 */         else if ((ch == 8232) && (this.mXml11)) {
/* 160 */           ch = 10;
/*     */         }
/*     */       }
/* 163 */       cbuf[(outPtr++)] = ((char)ch);
/* 164 */       if (this.mPtr >= this.mLength) {
/*     */         break;
/*     */       }
/*     */     }
/*     */     
/* 169 */     len = outPtr - start;
/* 170 */     this.mCharCount += len;
/* 171 */     return len;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void reportUnexpectedEOF(int gotBytes, int needed)
/*     */     throws IOException
/*     */   {
/* 183 */     int bytePos = this.mByteCount + gotBytes;
/* 184 */     int charPos = this.mCharCount;
/*     */     
/* 186 */     throw new CharConversionException("Unexpected EOF in the middle of a 4-byte UTF-32 char: got " + gotBytes + ", needed " + needed + ", at char #" + charPos + ", byte #" + bytePos + ")");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void reportInvalid(int value, int offset, String msg)
/*     */     throws IOException
/*     */   {
/* 194 */     int bytePos = this.mByteCount + this.mPtr - 1;
/* 195 */     int charPos = this.mCharCount + offset;
/*     */     
/* 197 */     throw new CharConversionException("Invalid UTF-32 character 0x" + Integer.toHexString(value) + msg + " at char #" + charPos + ", byte #" + bytePos + ")");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean loadMore(int available)
/*     */     throws IOException
/*     */   {
/* 211 */     this.mByteCount += this.mLength - available;
/*     */     
/*     */ 
/* 214 */     if (available > 0) {
/* 215 */       if (this.mPtr > 0) {
/* 216 */         for (int i = 0; i < available; i++) {
/* 217 */           this.mBuffer[i] = this.mBuffer[(this.mPtr + i)];
/*     */         }
/* 219 */         this.mPtr = 0;
/*     */       }
/* 221 */       this.mLength = available;
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 226 */       this.mPtr = 0;
/* 227 */       int count = this.mIn.read(this.mBuffer);
/* 228 */       if (count < 1) {
/* 229 */         this.mLength = 0;
/* 230 */         if (count < 0) {
/* 231 */           freeBuffers();
/* 232 */           return false;
/*     */         }
/*     */         
/* 235 */         reportStrangeStream();
/*     */       }
/* 237 */       this.mLength = count;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 243 */     while (this.mLength < 4) {
/* 244 */       int count = this.mIn.read(this.mBuffer, this.mLength, this.mBuffer.length - this.mLength);
/* 245 */       if (count < 1) {
/* 246 */         if (count < 0) {
/* 247 */           freeBuffers();
/* 248 */           reportUnexpectedEOF(this.mLength, 4);
/*     */         }
/*     */         
/* 251 */         reportStrangeStream();
/*     */       }
/* 253 */       this.mLength += count;
/*     */     }
/* 255 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\io\UTF32Reader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */