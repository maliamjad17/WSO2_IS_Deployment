/*     */ package com.ctc.wstx.evt;
/*     */ 
/*     */ import com.ctc.wstx.util.EmptyIterator;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.stream.events.EndElement;
/*     */ import javax.xml.stream.events.Namespace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WEndElement
/*     */   extends WEvent
/*     */   implements EndElement
/*     */ {
/*     */   final QName mName;
/*     */   final ArrayList mNamespaces;
/*     */   
/*     */   public WEndElement(Location loc, XMLStreamReader r)
/*     */   {
/*  30 */     super(loc);
/*  31 */     this.mName = r.getName();
/*     */     
/*     */ 
/*  34 */     int nsCount = r.getNamespaceCount();
/*  35 */     if (nsCount == 0) {
/*  36 */       this.mNamespaces = null;
/*     */     } else {
/*  38 */       ArrayList l = new ArrayList(nsCount);
/*  39 */       for (int i = 0; i < nsCount; i++) {
/*  40 */         String prefix = r.getNamespacePrefix(i);
/*  41 */         if ((prefix == null) || (prefix.length() == 0)) {
/*  42 */           l.add(new WNamespace(loc, r.getNamespaceURI(i)));
/*     */         } else {
/*  44 */           l.add(new WNamespace(loc, prefix, r.getNamespaceURI(i)));
/*     */         }
/*     */       }
/*  47 */       this.mNamespaces = l;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public WEndElement(Location loc, QName name, Iterator namespaces)
/*     */   {
/*  56 */     super(loc);
/*  57 */     this.mName = name;
/*  58 */     if ((namespaces == null) || (!namespaces.hasNext())) {
/*  59 */       this.mNamespaces = null;
/*     */     } else {
/*  61 */       ArrayList l = new ArrayList();
/*  62 */       while (namespaces.hasNext())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*  67 */         l.add((Namespace)namespaces.next());
/*     */       }
/*  69 */       this.mNamespaces = l;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public QName getName()
/*     */   {
/*  80 */     return this.mName;
/*     */   }
/*     */   
/*     */   public Iterator getNamespaces()
/*     */   {
/*  85 */     return this.mNamespaces == null ? EmptyIterator.getInstance() : this.mNamespaces.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EndElement asEndElement()
/*     */   {
/*  96 */     return this;
/*     */   }
/*     */   
/*     */   public int getEventType() {
/* 100 */     return 2;
/*     */   }
/*     */   
/*     */   public boolean isEndElement() {
/* 104 */     return true;
/*     */   }
/*     */   
/*     */   public void writeAsEncodedUnicode(Writer w) throws XMLStreamException
/*     */   {
/*     */     try
/*     */     {
/* 111 */       w.write("</");
/* 112 */       String prefix = this.mName.getPrefix();
/* 113 */       if ((prefix != null) && (prefix.length() > 0)) {
/* 114 */         w.write(prefix);
/* 115 */         w.write(58);
/*     */       }
/* 117 */       w.write(this.mName.getLocalPart());
/* 118 */       w.write(62);
/*     */     } catch (IOException ie) {
/* 120 */       throwFromIOE(ie);
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeUsing(XMLStreamWriter w) throws XMLStreamException
/*     */   {
/* 126 */     w.writeEndElement();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\evt\WEndElement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */