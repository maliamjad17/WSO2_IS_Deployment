package com.ctc.wstx.sr;

import com.ctc.wstx.dtd.DTDId;
import com.ctc.wstx.dtd.DTDSubset;
import com.ctc.wstx.util.SymbolTable;

public abstract interface ReaderCreator
{
  public abstract DTDSubset findCachedDTD(DTDId paramDTDId);
  
  public abstract void updateSymbolTable(SymbolTable paramSymbolTable);
  
  public abstract void addCachedDTD(DTDId paramDTDId, DTDSubset paramDTDSubset);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sr\ReaderCreator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */