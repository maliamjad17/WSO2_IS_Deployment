/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DTDWriter
/*     */ {
/*     */   final Writer mWriter;
/*     */   final boolean mIncludeComments;
/*     */   final boolean mIncludeConditionals;
/*     */   final boolean mIncludePEs;
/*  47 */   int mIsFlattening = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  53 */   int mFlattenStart = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DTDWriter(Writer out, boolean inclComments, boolean inclCond, boolean inclPEs)
/*     */   {
/*  64 */     this.mWriter = out;
/*  65 */     this.mIncludeComments = inclComments;
/*  66 */     this.mIncludeConditionals = inclCond;
/*  67 */     this.mIncludePEs = inclPEs;
/*     */     
/*  69 */     this.mIsFlattening = 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean includeComments()
/*     */   {
/*  79 */     return this.mIncludeComments;
/*     */   }
/*     */   
/*     */   public boolean includeConditionals() {
/*  83 */     return this.mIncludeConditionals;
/*     */   }
/*     */   
/*     */   public boolean includeParamEntities() {
/*  87 */     return this.mIncludePEs;
/*     */   }
/*     */   
/*     */   public void disableOutput()
/*     */   {
/*  92 */     this.mIsFlattening -= 1;
/*     */   }
/*     */   
/*     */   public void enableOutput(int newStart)
/*     */   {
/*  97 */     this.mIsFlattening += 1;
/*  98 */     this.mFlattenStart = newStart;
/*     */   }
/*     */   
/*     */   public void setFlattenStart(int ptr) {
/* 102 */     this.mFlattenStart = ptr;
/*     */   }
/*     */   
/*     */   public int getFlattenStart() {
/* 106 */     return this.mFlattenStart;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void flush(char[] buf, int upUntil)
/*     */     throws IOException
/*     */   {
/* 118 */     if (this.mFlattenStart < upUntil) {
/* 119 */       if (this.mIsFlattening > 0) {
/* 120 */         this.mWriter.write(buf, this.mFlattenStart, upUntil - this.mFlattenStart);
/*     */       }
/* 122 */       this.mFlattenStart = upUntil;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void output(String output)
/*     */     throws IOException
/*     */   {
/* 135 */     if (this.mIsFlattening > 0) {
/* 136 */       this.mWriter.write(output);
/*     */     }
/*     */   }
/*     */   
/*     */   public void output(char c)
/*     */     throws IOException
/*     */   {
/* 143 */     if (this.mIsFlattening > 0) {
/* 144 */       this.mWriter.write(c);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\DTDWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */