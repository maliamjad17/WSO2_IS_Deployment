/*     */ package com.ctc.wstx.evt;
/*     */ 
/*     */ import com.ctc.wstx.cfg.ErrorConsts;
/*     */ import com.ctc.wstx.exc.WstxParsingException;
/*     */ import com.ctc.wstx.util.ExceptionUtil;
/*     */ import java.util.NoSuchElementException;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamConstants;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.stream.events.Characters;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ import javax.xml.stream.util.XMLEventAllocator;
/*     */ import org.codehaus.stax2.XMLEventReader2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WstxEventReader
/*     */   implements XMLEventReader2, XMLStreamConstants
/*     */ {
/*     */   protected static final int STATE_INITIAL = 1;
/*     */   protected static final int STATE_EOD = 2;
/*     */   protected static final int STATE_CONTENT = 3;
/*     */   private final XMLEventAllocator mAllocator;
/*     */   private final XMLStreamReader mReader;
/*  70 */   private XMLEvent mPeekedEvent = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  80 */   protected int mState = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  88 */   protected int mPrePeekEvent = 7;
/*     */   
/*     */   public WstxEventReader(XMLEventAllocator a, XMLStreamReader r)
/*     */   {
/*  92 */     this.mAllocator = a;
/*  93 */     this.mReader = r;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws XMLStreamException
/*     */   {
/* 108 */     this.mReader.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getElementText()
/*     */     throws XMLStreamException
/*     */   {
/* 117 */     if (this.mPeekedEvent == null) {
/* 118 */       return this.mReader.getElementText();
/*     */     }
/*     */     
/* 121 */     XMLEvent evt = this.mPeekedEvent;
/* 122 */     this.mPeekedEvent = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 127 */     if (this.mPrePeekEvent != 1) {
/* 128 */       throw new WstxParsingException(ErrorConsts.ERR_STATE_NOT_STELEM, evt.getLocation());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 133 */     String str = null;
/* 134 */     StringBuffer sb = null;
/* 140 */     for (; 
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 140 */         !evt.isEndElement(); evt = nextEvent())
/*     */     {
/*     */ 
/*     */ 
/* 143 */       int type = evt.getEventType();
/* 144 */       if ((type != 5) && (type != 3))
/*     */       {
/*     */ 
/*     */ 
/* 148 */         if (!evt.isCharacters()) {
/* 149 */           throw new WstxParsingException("Expected a text token, got " + ErrorConsts.tokenTypeDesc(type), evt.getLocation());
/*     */         }
/*     */         
/*     */ 
/* 153 */         String curr = evt.asCharacters().getData();
/* 154 */         if (str == null) {
/* 155 */           str = curr;
/*     */         } else {
/* 157 */           if (sb == null) {
/* 158 */             sb = new StringBuffer(str.length() + curr.length());
/* 159 */             sb.append(str);
/*     */           }
/* 161 */           sb.append(curr);
/*     */         }
/*     */       }
/*     */     }
/* 165 */     if (sb != null) {
/* 166 */       return sb.toString();
/*     */     }
/* 168 */     return str == null ? "" : str;
/*     */   }
/*     */   
/*     */   public Object getProperty(String name) {
/* 172 */     return this.mReader.getProperty(name);
/*     */   }
/*     */   
/*     */   public boolean hasNext() {
/* 176 */     return this.mState != 2;
/*     */   }
/*     */   
/*     */   public XMLEvent nextEvent()
/*     */     throws XMLStreamException
/*     */   {
/* 182 */     if (this.mState == 2)
/* 183 */       throw new NoSuchElementException();
/* 184 */     if (this.mState == 1) {
/* 185 */       this.mState = 3;
/* 186 */       return createStartEvent();
/*     */     }
/* 188 */     if (this.mPeekedEvent != null) {
/* 189 */       XMLEvent evt = this.mPeekedEvent;
/* 190 */       this.mPeekedEvent = null;
/* 191 */       if (evt.isEndDocument()) {
/* 192 */         this.mState = 2;
/*     */       }
/* 194 */       return evt;
/*     */     }
/* 196 */     return createNextEvent(true, this.mReader.next());
/*     */   }
/*     */   
/*     */   public Object next() {
/*     */     try {
/* 201 */       return nextEvent();
/*     */     } catch (XMLStreamException sex) {
/* 203 */       throwFromSex(sex); }
/* 204 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public XMLEvent nextTag()
/*     */     throws XMLStreamException
/*     */   {
/* 212 */     if (this.mPeekedEvent != null) {
/* 213 */       XMLEvent evt = this.mPeekedEvent;
/* 214 */       this.mPeekedEvent = null;
/* 215 */       switch (evt.getEventType()) {
/*     */       case 8: 
/* 217 */         return null;
/*     */       
/*     */ 
/*     */       case 7: 
/*     */         break;
/*     */       
/*     */ 
/*     */       case 3: 
/*     */       case 5: 
/*     */       case 6: 
/*     */         break;
/*     */       
/*     */ 
/*     */       case 4: 
/*     */       case 12: 
/* 232 */         if (!((Characters)evt).isWhiteSpace())
/*     */         {
/*     */ 
/*     */ 
/* 236 */           throwParseError("Received non-all-whitespace CHARACTERS or CDATA event in nextTag()."); }
/* 237 */         break;
/*     */       case 1: 
/*     */       case 2: 
/* 240 */         return evt;
/*     */       case 9: case 10: 
/*     */       case 11: default: 
/* 243 */         throwParseError("Received event " + evt.getEventType() + ", instead of START_ELEMENT or END_ELEMENT.");
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       
/*     */     }
/* 253 */     else if (this.mState == 1) {
/* 254 */       this.mState = 3;
/*     */     }
/*     */     
/*     */     for (;;)
/*     */     {
/* 259 */       int next = this.mReader.next();
/*     */       
/* 261 */       switch (next) {
/*     */       case 8: 
/* 263 */         return null;
/*     */       
/*     */ 
/*     */       case 3: 
/*     */       case 5: 
/*     */       case 6: 
/*     */         break;
/*     */       
/*     */ 
/*     */       case 4: 
/*     */       case 12: 
/* 274 */         if (!this.mReader.isWhiteSpace())
/*     */         {
/*     */ 
/* 277 */           throwParseError("Received non-all-whitespace CHARACTERS or CDATA event in nextTag()."); }
/* 278 */         break;
/*     */       
/*     */       case 1: 
/*     */       case 2: 
/* 282 */         return createNextEvent(false, next);
/*     */       case 7: case 9: case 10: 
/*     */       case 11: default: 
/* 285 */         throwParseError("Received event " + next + ", instead of START_ELEMENT or END_ELEMENT.");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public XMLEvent peek()
/*     */     throws XMLStreamException
/*     */   {
/* 293 */     if (this.mPeekedEvent == null) {
/* 294 */       if (this.mState == 2)
/*     */       {
/*     */ 
/* 297 */         return null;
/*     */       }
/* 299 */       if (this.mState == 1)
/*     */       {
/* 301 */         this.mPrePeekEvent = 7;
/* 302 */         this.mPeekedEvent = createStartEvent();
/* 303 */         this.mState = 3;
/*     */       } else {
/* 305 */         this.mPrePeekEvent = this.mReader.getEventType();
/* 306 */         this.mPeekedEvent = createNextEvent(false, this.mReader.next());
/*     */       }
/*     */     }
/* 309 */     return this.mPeekedEvent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void remove()
/*     */   {
/* 316 */     throw new UnsupportedOperationException("Can not remove events from XMLEventReader.");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasNextEvent()
/*     */     throws XMLStreamException
/*     */   {
/* 335 */     return this.mState != 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XMLEvent createNextEvent(boolean checkEOD, int type)
/*     */     throws XMLStreamException
/*     */   {
/* 347 */     XMLEvent evt = this.mAllocator.allocate(this.mReader);
/* 348 */     if ((checkEOD) && (type == 8)) {
/* 349 */       this.mState = 2;
/*     */     }
/* 351 */     return evt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XMLEvent createStartEvent()
/*     */     throws XMLStreamException
/*     */   {
/* 360 */     XMLEvent start = this.mAllocator.allocate(this.mReader);
/* 361 */     return start;
/*     */   }
/*     */   
/*     */   private void throwEOD()
/*     */   {
/* 366 */     throw new NoSuchElementException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void throwFromSex(XMLStreamException sex)
/*     */   {
/* 375 */     ExceptionUtil.throwRuntimeException(sex);
/*     */   }
/*     */   
/*     */   protected void throwParseError(String msg)
/*     */     throws XMLStreamException
/*     */   {
/* 381 */     throwParseError(msg, this.mReader.getLocation());
/*     */   }
/*     */   
/*     */   protected void throwParseError(String msg, Location loc)
/*     */     throws XMLStreamException
/*     */   {
/* 387 */     throw new WstxParsingException(msg, loc);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\evt\WstxEventReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */