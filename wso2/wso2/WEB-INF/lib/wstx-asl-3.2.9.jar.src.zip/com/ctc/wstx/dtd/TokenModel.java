/*    */ package com.ctc.wstx.dtd;
/*    */ 
/*    */ import java.util.BitSet;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TokenModel
/*    */   extends ModelNode
/*    */ {
/* 12 */   static final TokenModel NULL_TOKEN = new TokenModel(null);
/*    */   
/* 14 */   static { NULL_TOKEN.mTokenIndex = 0; }
/*    */   
/*    */ 
/*    */   final NameKey mElemName;
/*    */   
/* 19 */   int mTokenIndex = -1;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TokenModel(NameKey elemName)
/*    */   {
/* 28 */     this.mElemName = elemName;
/*    */   }
/*    */   
/*    */   public static TokenModel getNullToken() {
/* 32 */     return NULL_TOKEN;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public NameKey getName()
/*    */   {
/* 41 */     return this.mElemName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public ModelNode cloneModel()
/*    */   {
/* 48 */     return new TokenModel(this.mElemName);
/*    */   }
/*    */   
/*    */   public boolean isNullable() {
/* 52 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void indexTokens(List tokens)
/*    */   {
/* 60 */     if (this != NULL_TOKEN) {
/* 61 */       int index = tokens.size();
/* 62 */       this.mTokenIndex = index;
/* 63 */       tokens.add(this);
/*    */     }
/*    */   }
/*    */   
/*    */   public void addFirstPos(BitSet firstPos) {
/* 68 */     firstPos.set(this.mTokenIndex);
/*    */   }
/*    */   
/*    */   public void addLastPos(BitSet lastPos) {
/* 72 */     lastPos.set(this.mTokenIndex);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 80 */     return this.mElemName == null ? "[null]" : this.mElemName.toString();
/*    */   }
/*    */   
/*    */   public void calcFollowPos(BitSet[] followPosSets) {}
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\TokenModel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */