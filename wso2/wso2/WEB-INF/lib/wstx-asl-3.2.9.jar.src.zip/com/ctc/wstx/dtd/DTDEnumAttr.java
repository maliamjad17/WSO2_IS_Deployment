/*    */ package com.ctc.wstx.dtd;
/*    */ 
/*    */ import com.ctc.wstx.sr.InputProblemReporter;
/*    */ import com.ctc.wstx.util.WordResolver;
/*    */ import org.codehaus.stax2.validation.XMLValidationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DTDEnumAttr
/*    */   extends DTDAttribute
/*    */ {
/*    */   final WordResolver mEnumValues;
/*    */   
/*    */   public DTDEnumAttr(NameKey name, DefaultAttrValue defValue, int specIndex, boolean nsAware, boolean xml11, WordResolver enumValues)
/*    */   {
/* 26 */     super(name, defValue, specIndex, nsAware, xml11);
/* 27 */     this.mEnumValues = enumValues;
/*    */   }
/*    */   
/*    */   public DTDAttribute cloneWith(int specIndex)
/*    */   {
/* 32 */     return new DTDEnumAttr(this.mName, this.mDefValue, specIndex, this.mCfgNsAware, this.mCfgXml11, this.mEnumValues);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getValueType()
/*    */   {
/* 43 */     return 1;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String validate(DTDValidatorBase v, char[] cbuf, int start, int end, boolean normalize)
/*    */     throws XMLValidationException
/*    */   {
/* 60 */     String ok = validateEnumValue(cbuf, start, end, normalize, this.mEnumValues);
/* 61 */     if (ok == null) {
/* 62 */       String val = new String(cbuf, start, end - start);
/* 63 */       return reportValidationProblem(v, "Invalid enumerated value '" + val + "': has to be one of (" + this.mEnumValues + ")");
/*    */     }
/*    */     
/* 66 */     return ok;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void validateDefault(InputProblemReporter rep, boolean normalize)
/*    */     throws XMLValidationException
/*    */   {
/* 77 */     String def = validateDefaultNmToken(rep, normalize);
/*    */     
/*    */ 
/* 80 */     String shared = this.mEnumValues.find(def);
/* 81 */     if (shared == null) {
/* 82 */       reportValidationProblem(rep, "Invalid default value '" + def + "': has to be one of (" + this.mEnumValues + ")");
/*    */       
/* 84 */       return;
/*    */     }
/*    */     
/*    */ 
/* 88 */     if (normalize) {
/* 89 */       this.mDefValue.setValue(shared);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\DTDEnumAttr.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */