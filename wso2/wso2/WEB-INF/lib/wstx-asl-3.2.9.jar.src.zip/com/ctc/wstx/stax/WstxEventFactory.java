/*     */ package com.ctc.wstx.stax;
/*     */ 
/*     */ import com.ctc.wstx.compat.QNameCreator;
/*     */ import com.ctc.wstx.dtd.DTDSubset;
/*     */ import com.ctc.wstx.evt.SimpleStartElement;
/*     */ import com.ctc.wstx.evt.WAttribute;
/*     */ import com.ctc.wstx.evt.WCharacters;
/*     */ import com.ctc.wstx.evt.WComment;
/*     */ import com.ctc.wstx.evt.WDTD;
/*     */ import com.ctc.wstx.evt.WEndDocument;
/*     */ import com.ctc.wstx.evt.WEndElement;
/*     */ import com.ctc.wstx.evt.WEntityReference;
/*     */ import com.ctc.wstx.evt.WNamespace;
/*     */ import com.ctc.wstx.evt.WProcInstr;
/*     */ import com.ctc.wstx.evt.WStartDocument;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.events.Attribute;
/*     */ import javax.xml.stream.events.Characters;
/*     */ import javax.xml.stream.events.Comment;
/*     */ import javax.xml.stream.events.DTD;
/*     */ import javax.xml.stream.events.EndDocument;
/*     */ import javax.xml.stream.events.EndElement;
/*     */ import javax.xml.stream.events.EntityDeclaration;
/*     */ import javax.xml.stream.events.EntityReference;
/*     */ import javax.xml.stream.events.Namespace;
/*     */ import javax.xml.stream.events.ProcessingInstruction;
/*     */ import javax.xml.stream.events.StartDocument;
/*     */ import javax.xml.stream.events.StartElement;
/*     */ import org.codehaus.stax2.evt.DTD2;
/*     */ import org.codehaus.stax2.evt.XMLEventFactory2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WstxEventFactory
/*     */   extends XMLEventFactory2
/*     */ {
/*     */   private Location mLocation;
/*     */   
/*     */   public Attribute createAttribute(QName name, String value)
/*     */   {
/*  55 */     return new WAttribute(this.mLocation, name, value, true);
/*     */   }
/*     */   
/*     */   public Attribute createAttribute(String localName, String value) {
/*  59 */     return new WAttribute(this.mLocation, localName, null, null, value, true);
/*     */   }
/*     */   
/*     */ 
/*     */   public Attribute createAttribute(String prefix, String nsURI, String localName, String value)
/*     */   {
/*  65 */     return new WAttribute(this.mLocation, localName, nsURI, prefix, value, true);
/*     */   }
/*     */   
/*     */   public Characters createCData(String content) {
/*  69 */     return new WCharacters(this.mLocation, content, true);
/*     */   }
/*     */   
/*     */   public Characters createCharacters(String content) {
/*  73 */     return new WCharacters(this.mLocation, content, false);
/*     */   }
/*     */   
/*     */   public Comment createComment(String text) {
/*  77 */     return new WComment(this.mLocation, text);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DTD createDTD(String dtd)
/*     */   {
/*  86 */     return new WDTD(this.mLocation, dtd);
/*     */   }
/*     */   
/*     */   public EndDocument createEndDocument() {
/*  90 */     return new WEndDocument(this.mLocation);
/*     */   }
/*     */   
/*     */   public EndElement createEndElement(QName name, Iterator namespaces) {
/*  94 */     return new WEndElement(this.mLocation, name, namespaces);
/*     */   }
/*     */   
/*     */ 
/*     */   public EndElement createEndElement(String prefix, String nsURI, String localName)
/*     */   {
/* 100 */     return createEndElement(new QName(nsURI, localName), null);
/*     */   }
/*     */   
/*     */ 
/*     */   public EndElement createEndElement(String prefix, String nsURI, String localName, Iterator ns)
/*     */   {
/* 106 */     return createEndElement(QNameCreator.create(nsURI, localName, prefix), ns);
/*     */   }
/*     */   
/*     */   public EntityReference createEntityReference(String name, EntityDeclaration decl)
/*     */   {
/* 111 */     return new WEntityReference(this.mLocation, decl);
/*     */   }
/*     */   
/*     */   public Characters createIgnorableSpace(String content) {
/* 115 */     return WCharacters.createIgnorableWS(this.mLocation, content);
/*     */   }
/*     */   
/*     */   public Namespace createNamespace(String nsURI) {
/* 119 */     return new WNamespace(this.mLocation, nsURI);
/*     */   }
/*     */   
/*     */   public Namespace createNamespace(String prefix, String nsUri) {
/* 123 */     return new WNamespace(this.mLocation, prefix, nsUri);
/*     */   }
/*     */   
/*     */   public ProcessingInstruction createProcessingInstruction(String target, String data) {
/* 127 */     return new WProcInstr(this.mLocation, target, data);
/*     */   }
/*     */   
/*     */   public Characters createSpace(String content) {
/* 131 */     return WCharacters.createNonIgnorableWS(this.mLocation, content);
/*     */   }
/*     */   
/*     */   public StartDocument createStartDocument() {
/* 135 */     return new WStartDocument(this.mLocation);
/*     */   }
/*     */   
/*     */   public StartDocument createStartDocument(String encoding) {
/* 139 */     return new WStartDocument(this.mLocation, encoding);
/*     */   }
/*     */   
/*     */   public StartDocument createStartDocument(String encoding, String version) {
/* 143 */     return new WStartDocument(this.mLocation, encoding, version);
/*     */   }
/*     */   
/*     */   public StartDocument createStartDocument(String encoding, String version, boolean standalone)
/*     */   {
/* 148 */     return new WStartDocument(this.mLocation, encoding, version, true, standalone);
/*     */   }
/*     */   
/*     */ 
/*     */   public StartElement createStartElement(QName name, Iterator attr, Iterator ns)
/*     */   {
/* 154 */     return createStartElement(name, attr, ns, null);
/*     */   }
/*     */   
/*     */   public StartElement createStartElement(String prefix, String nsURI, String localName)
/*     */   {
/* 159 */     return createStartElement(QNameCreator.create(nsURI, localName, prefix), null, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public StartElement createStartElement(String prefix, String nsURI, String localName, Iterator attr, Iterator ns)
/*     */   {
/* 167 */     return createStartElement(QNameCreator.create(nsURI, localName, prefix), attr, ns, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public StartElement createStartElement(String prefix, String nsURI, String localName, Iterator attr, Iterator ns, NamespaceContext nsCtxt)
/*     */   {
/* 175 */     return createStartElement(QNameCreator.create(nsURI, localName, prefix), attr, ns, nsCtxt);
/*     */   }
/*     */   
/*     */   public void setLocation(Location loc)
/*     */   {
/* 180 */     this.mLocation = loc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DTD2 createDTD(String rootName, String sysId, String pubId, String intSubset)
/*     */   {
/* 192 */     return new WDTD(this.mLocation, rootName, sysId, pubId, intSubset);
/*     */   }
/*     */   
/*     */ 
/*     */   public DTD2 createDTD(String rootName, String sysId, String pubId, String intSubset, Object processedDTD)
/*     */   {
/* 198 */     return new WDTD(this.mLocation, rootName, sysId, pubId, intSubset, (DTDSubset)processedDTD);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private StartElement createStartElement(QName name, Iterator attr, Iterator ns, NamespaceContext ctxt)
/*     */   {
/* 211 */     return SimpleStartElement.construct(this.mLocation, name, attr, ns, ctxt);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\stax\WstxEventFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */