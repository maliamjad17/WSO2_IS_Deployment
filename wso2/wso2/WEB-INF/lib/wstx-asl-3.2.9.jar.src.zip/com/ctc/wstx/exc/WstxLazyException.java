/*    */ package com.ctc.wstx.exc;
/*    */ 
/*    */ import com.ctc.wstx.compat.JdkFeatures;
/*    */ import com.ctc.wstx.compat.JdkImpl;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WstxLazyException
/*    */   extends RuntimeException
/*    */ {
/*    */   final XMLStreamException mOrig;
/*    */   
/*    */   public WstxLazyException(XMLStreamException origEx)
/*    */   {
/* 34 */     super(origEx.getMessage());
/* 35 */     this.mOrig = origEx;
/*    */     
/*    */ 
/*    */ 
/* 39 */     JdkFeatures.getInstance().setInitCause(this, origEx);
/*    */   }
/*    */   
/*    */   public static void throwLazily(XMLStreamException ex)
/*    */     throws WstxLazyException
/*    */   {
/* 45 */     throw new WstxLazyException(ex);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 54 */     return "[" + getClass().getName() + "] " + this.mOrig.getMessage();
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 59 */     return "[" + getClass().getName() + "] " + this.mOrig.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\exc\WstxLazyException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */