/*     */ package com.ctc.wstx.util;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Collection;
/*     */ 
/*     */ public final class DataUtil
/*     */ {
/*   8 */   static final char[] EMPTY_CHAR_ARRAY = new char[0];
/*     */   static final String NO_TYPE = "Illegal to pass null; can not determine component type";
/*     */   
/*     */   public static char[] getEmptyCharArray()
/*     */   {
/*  13 */     return EMPTY_CHAR_ARRAY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean anyValuesInCommon(Collection c1, Collection c2)
/*     */   {
/*  32 */     if (c1.size() > c2.size()) {
/*  33 */       Collection tmp = c1;
/*  34 */       c1 = c2;
/*  35 */       c2 = tmp;
/*     */     }
/*  37 */     java.util.Iterator it = c1.iterator();
/*  38 */     while (it.hasNext()) {
/*  39 */       if (c2.contains(it.next())) {
/*  40 */         return true;
/*     */       }
/*     */     }
/*  43 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Object growArrayBy50Pct(Object arr)
/*     */   {
/*  50 */     if (arr == null) {
/*  51 */       throw new IllegalArgumentException("Illegal to pass null; can not determine component type");
/*     */     }
/*  53 */     Object old = arr;
/*  54 */     int len = Array.getLength(arr);
/*  55 */     arr = Array.newInstance(arr.getClass().getComponentType(), len + (len >> 1));
/*  56 */     System.arraycopy(old, 0, arr, 0, len);
/*  57 */     return arr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object growArrayToAtLeast(Object arr, int minLen)
/*     */   {
/*  66 */     if (arr == null) {
/*  67 */       throw new IllegalArgumentException("Illegal to pass null; can not determine component type");
/*     */     }
/*  69 */     Object old = arr;
/*  70 */     int oldLen = Array.getLength(arr);
/*  71 */     int newLen = oldLen + (oldLen + 1 >> 1);
/*  72 */     if (newLen < minLen) {
/*  73 */       newLen = minLen;
/*     */     }
/*  75 */     arr = Array.newInstance(arr.getClass().getComponentType(), newLen);
/*  76 */     System.arraycopy(old, 0, arr, 0, oldLen);
/*  77 */     return arr;
/*     */   }
/*     */   
/*     */   public static String[] growArrayBy(String[] arr, int more)
/*     */   {
/*  82 */     if (arr == null) {
/*  83 */       return new String[more];
/*     */     }
/*  85 */     String[] old = arr;
/*  86 */     int len = arr.length;
/*  87 */     arr = new String[len + more];
/*  88 */     System.arraycopy(old, 0, arr, 0, len);
/*  89 */     return arr;
/*     */   }
/*     */   
/*     */   public static int[] growArrayBy(int[] arr, int more)
/*     */   {
/*  94 */     if (arr == null) {
/*  95 */       return new int[more];
/*     */     }
/*  97 */     int[] old = arr;
/*  98 */     int len = arr.length;
/*  99 */     arr = new int[len + more];
/* 100 */     System.arraycopy(old, 0, arr, 0, len);
/* 101 */     return arr;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\util\DataUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */