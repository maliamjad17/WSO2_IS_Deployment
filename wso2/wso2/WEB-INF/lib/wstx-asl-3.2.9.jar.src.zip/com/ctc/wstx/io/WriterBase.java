/*     */ package com.ctc.wstx.io;
/*     */ 
/*     */ import java.io.FilterWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WriterBase
/*     */   extends FilterWriter
/*     */ {
/*     */   protected static final char HIGHEST_ENCODABLE_ATTR_CHAR = '<';
/*     */   protected static final char HIGHEST_ENCODABLE_TEXT_CHAR = '>';
/*     */   protected static final char CHAR_NULL = '\000';
/*     */   protected static final char CHAR_SPACE = ' ';
/*     */   protected static final String STR_ESCAPED_CR = "&#13;";
/*  49 */   protected char[] mEntityBuffer = null;
/*     */   
/*     */   protected WriterBase(Writer out) {
/*  52 */     super(out);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static final String getQuoteEntity(char qchar)
/*     */     throws IllegalArgumentException
/*     */   {
/*  64 */     if (qchar == '"') {
/*  65 */       return "&quot;";
/*     */     }
/*  67 */     if (qchar == '\'') {
/*  68 */       return "&apos;";
/*     */     }
/*  70 */     throw new IllegalArgumentException("Unrecognized quote char ('" + qchar + " [" + qchar + "]; expected a single or double quote char");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void throwNullChar()
/*     */     throws IOException
/*     */   {
/*  78 */     throw new IOException("Null character in text to write");
/*     */   }
/*     */   
/*     */   protected final void writeAsEntity(int c)
/*     */     throws IOException
/*     */   {
/*  84 */     char[] cbuf = this.mEntityBuffer;
/*  85 */     if (cbuf == null) {
/*  86 */       cbuf = new char[8];
/*  87 */       this.mEntityBuffer = cbuf;
/*  88 */       cbuf[0] = '&';
/*  89 */       cbuf[1] = '#';
/*  90 */       cbuf[2] = 'x';
/*     */     }
/*     */     
/*  93 */     if (c < 16) {
/*  94 */       cbuf[3] = ((char)(c < 10 ? 48 + c : 87 + c));
/*     */       
/*     */ 
/*  97 */       cbuf[4] = ';';
/*  98 */       this.out.write(cbuf, 0, 5);
/*     */     } else {
/* 100 */       for (int ix = 6; ix > 2; ix--) {
/* 101 */         int digit = c & 0xF;
/* 102 */         c >>= 4;
/* 103 */         cbuf[ix] = ((char)(digit < 10 ? 48 + digit : 87 + digit));
/*     */       }
/*     */       
/*     */ 
/* 107 */       cbuf[7] = ';';
/* 108 */       this.out.write(cbuf, 0, 8);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\io\WriterBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */