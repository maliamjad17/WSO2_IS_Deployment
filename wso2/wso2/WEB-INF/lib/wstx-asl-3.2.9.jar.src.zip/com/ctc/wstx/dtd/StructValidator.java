package com.ctc.wstx.dtd;

public abstract class StructValidator
{
  public abstract StructValidator newInstance();
  
  public abstract String tryToValidate(NameKey paramNameKey);
  
  public abstract String fullyValid();
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\StructValidator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */