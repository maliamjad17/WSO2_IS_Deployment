/*     */ package com.ctc.wstx.evt;
/*     */ 
/*     */ import com.ctc.wstx.cfg.ErrorConsts;
/*     */ import com.ctc.wstx.compat.JdkFeatures;
/*     */ import com.ctc.wstx.compat.JdkImpl;
/*     */ import com.ctc.wstx.dtd.DTDSubset;
/*     */ import com.ctc.wstx.ent.EntityDecl;
/*     */ import com.ctc.wstx.exc.WstxException;
/*     */ import com.ctc.wstx.sr.ElemAttrs;
/*     */ import com.ctc.wstx.sr.ElemCallback;
/*     */ import com.ctc.wstx.sr.StreamReaderImpl;
/*     */ import com.ctc.wstx.util.BaseNsContext;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamConstants;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ import javax.xml.stream.util.XMLEventAllocator;
/*     */ import javax.xml.stream.util.XMLEventConsumer;
/*     */ import org.codehaus.stax2.DTDInfo;
/*     */ import org.codehaus.stax2.XMLStreamReader2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultEventAllocator
/*     */   extends ElemCallback
/*     */   implements XMLEventAllocator, XMLStreamConstants
/*     */ {
/*  64 */   static final DefaultEventAllocator sStdInstance = new DefaultEventAllocator(true);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final boolean mAccurateLocation;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  84 */   protected Location mLastLocation = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected DefaultEventAllocator(boolean accurateLocation)
/*     */   {
/*  93 */     this.mAccurateLocation = accurateLocation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static DefaultEventAllocator getDefaultInstance()
/*     */   {
/* 100 */     return sStdInstance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static DefaultEventAllocator getFastInstance()
/*     */   {
/* 107 */     return new DefaultEventAllocator(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLEvent allocate(XMLStreamReader r)
/*     */     throws XMLStreamException
/*     */   {
/*     */     Location loc;
/*     */     
/*     */ 
/*     */     Location loc;
/*     */     
/*     */ 
/* 122 */     if (this.mAccurateLocation) {
/* 123 */       loc = r.getLocation();
/*     */     } else {
/* 125 */       loc = this.mLastLocation;
/*     */       
/*     */ 
/*     */ 
/* 129 */       if (loc == null) {
/* 130 */         loc = this.mLastLocation = r.getLocation();
/*     */       }
/*     */     }
/*     */     
/* 134 */     switch (r.getEventType()) {
/*     */     case 12: 
/* 136 */       return new WCharacters(loc, r.getText(), true);
/*     */     case 4: 
/* 138 */       return new WCharacters(loc, r.getText(), false);
/*     */     case 5: 
/* 140 */       return new WComment(loc, r.getText());
/*     */     
/*     */     case 11: 
/* 143 */       if ((r instanceof XMLStreamReader2)) {
/* 144 */         XMLStreamReader2 sr2 = (XMLStreamReader2)r;
/* 145 */         DTDInfo dtd = sr2.getDTDInfo();
/* 146 */         return new WDTD(loc, dtd.getDTDRootName(), dtd.getDTDSystemId(), dtd.getDTDPublicId(), dtd.getDTDInternalSubset(), (DTDSubset)dtd.getProcessedDTD());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 156 */       return new WDTD(loc, null, r.getText());
/*     */     
/*     */     case 8: 
/* 159 */       return new WEndDocument(loc);
/*     */     
/*     */     case 2: 
/* 162 */       return new WEndElement(loc, r);
/*     */     
/*     */     case 3: 
/* 165 */       return new WProcInstr(loc, r.getPITarget(), r.getPIData());
/*     */     
/*     */     case 6: 
/* 168 */       WCharacters ch = new WCharacters(loc, r.getText(), false);
/* 169 */       ch.setWhitespaceStatus(true);
/* 170 */       return ch;
/*     */     
/*     */     case 7: 
/* 173 */       return new WStartDocument(loc, r);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 1: 
/* 186 */       if ((r instanceof StreamReaderImpl)) {
/* 187 */         StreamReaderImpl sr = (StreamReaderImpl)r;
/* 188 */         BaseStartElement be = (BaseStartElement)sr.withStartElement(this, loc);
/* 189 */         if (be == null) {
/* 190 */           throw new WstxException("Trying to create START_ELEMENT when current event is " + ErrorConsts.tokenTypeDesc(sr.getEventType()), loc);
/*     */         }
/*     */         
/*     */ 
/* 194 */         return be;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 199 */       NamespaceContext nsCtxt = null;
/* 200 */       if ((r instanceof XMLStreamReader2)) {
/* 201 */         nsCtxt = ((XMLStreamReader2)r).getNonTransientNamespaceContext();
/*     */       }
/*     */       
/*     */ 
/* 205 */       int attrCount = r.getAttributeCount();
/* 206 */       Map attrs; Map attrs; if (attrCount < 1) {
/* 207 */         attrs = null;
/*     */       } else {
/* 209 */         attrs = JdkFeatures.getInstance().getInsertOrderedMap();
/* 210 */         for (int i = 0; i < attrCount; i++) {
/* 211 */           QName aname = r.getAttributeName(i);
/* 212 */           attrs.put(aname, new WAttribute(loc, aname, r.getAttributeValue(i), r.isAttributeSpecified(i)));
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 218 */       int nsCount = r.getNamespaceCount();
/* 219 */       List ns; List ns; if (nsCount < 1) {
/* 220 */         ns = null;
/*     */       } else {
/* 222 */         ns = new ArrayList(nsCount);
/* 223 */         for (int i = 0; i < nsCount; i++) {
/* 224 */           ns.add(WNamespace.constructFor(loc, r.getNamespacePrefix(i), r.getNamespaceURI(i)));
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 229 */       return SimpleStartElement.construct(loc, r.getName(), attrs, ns, nsCtxt);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 9: 
/* 237 */       if ((r instanceof StreamReaderImpl)) {
/* 238 */         EntityDecl ed = ((StreamReaderImpl)r).getCurrentEntityDecl();
/* 239 */         if (ed == null)
/*     */         {
/* 241 */           return new WEntityReference(loc, r.getLocalName());
/*     */         }
/* 243 */         return new WEntityReference(loc, ed);
/*     */       }
/* 245 */       return new WEntityReference(loc, r.getLocalName());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 10: 
/*     */     case 13: 
/*     */     case 14: 
/*     */     case 15: 
/* 261 */       throw new WstxException("Internal error: should not get " + ErrorConsts.tokenTypeDesc(r.getEventType()));
/*     */     }
/*     */     
/* 264 */     throw new Error("Unrecognized event type " + r.getEventType() + ".");
/*     */   }
/*     */   
/*     */ 
/*     */   public void allocate(XMLStreamReader r, XMLEventConsumer consumer)
/*     */     throws XMLStreamException
/*     */   {
/* 271 */     consumer.add(allocate(r));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLEventAllocator newInstance()
/*     */   {
/* 282 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object withStartElement(Location loc, QName name, BaseNsContext nsCtxt, ElemAttrs attrs, boolean wasEmpty)
/*     */   {
/* 295 */     return new CompactStartElement(loc, name, nsCtxt, attrs);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\evt\DefaultEventAllocator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */