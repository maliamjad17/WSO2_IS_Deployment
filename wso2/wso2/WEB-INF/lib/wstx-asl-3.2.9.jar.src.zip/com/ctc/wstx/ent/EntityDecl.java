/*     */ package com.ctc.wstx.ent;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import com.ctc.wstx.evt.WEntityDeclaration;
/*     */ import com.ctc.wstx.io.WstxInputSource;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.net.URL;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLResolver;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class EntityDecl
/*     */   extends WEntityDeclaration
/*     */ {
/*     */   final String mName;
/*     */   final URL mContext;
/*  55 */   protected boolean mDeclaredExternally = false;
/*     */   
/*     */   public EntityDecl(Location loc, String name, URL ctxt)
/*     */   {
/*  59 */     super(loc);
/*  60 */     this.mName = name;
/*  61 */     this.mContext = ctxt;
/*     */   }
/*     */   
/*     */   public void markAsExternallyDeclared() {
/*  65 */     this.mDeclaredExternally = true;
/*     */   }
/*     */   
/*     */   public final String getBaseURI() {
/*  69 */     return this.mContext.toString();
/*     */   }
/*     */   
/*     */   public final String getName() {
/*  73 */     return this.mName;
/*     */   }
/*     */   
/*     */   public final Location getLocation() {
/*  77 */     return this.mLocation;
/*     */   }
/*     */   
/*     */ 
/*     */   public abstract String getNotationName();
/*     */   
/*     */ 
/*     */   public abstract String getPublicId();
/*     */   
/*     */ 
/*     */   public abstract String getReplacementText();
/*     */   
/*     */   public abstract int getReplacementText(Writer paramWriter)
/*     */     throws IOException;
/*     */   
/*     */   public abstract String getSystemId();
/*     */   
/*     */   public boolean wasDeclaredExternally()
/*     */   {
/*  96 */     return this.mDeclaredExternally;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writeEnc(Writer paramWriter)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract char[] getReplacementChars();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getReplacementTextLength()
/*     */   {
/* 118 */     String str = getReplacementText();
/* 119 */     return str == null ? 0 : str.length();
/*     */   }
/*     */   
/*     */   public abstract boolean isExternal();
/*     */   
/*     */   public abstract boolean isParsed();
/*     */   
/*     */   public abstract WstxInputSource expand(WstxInputSource paramWstxInputSource, XMLResolver paramXMLResolver, ReaderConfig paramReaderConfig, int paramInt)
/*     */     throws IOException, XMLStreamException;
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\wso2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\ent\EntityDecl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */