package com.sun.research.ws.wadl;

import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;

@XmlSchema(namespace="http://research.sun.com/wadl/2006/10", elementFormDefault=XmlNsForm.QUALIFIED)
abstract interface package-info {}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\research\ws\wadl\package-info.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */