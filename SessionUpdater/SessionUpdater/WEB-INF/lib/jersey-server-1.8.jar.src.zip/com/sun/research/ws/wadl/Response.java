/*     */ package com.sun.research.ws.wadl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlAnyAttribute;
/*     */ import javax.xml.bind.annotation.XmlAnyElement;
/*     */ import javax.xml.bind.annotation.XmlElementRefs;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name="", propOrder={"doc", "param", "representationOrFault", "any"})
/*     */ @XmlRootElement(name="response")
/*     */ public class Response
/*     */ {
/*     */   protected List<Doc> doc;
/*     */   protected List<Param> param;
/*     */   @XmlElementRefs({@javax.xml.bind.annotation.XmlElementRef(name="representation", namespace="http://research.sun.com/wadl/2006/10", type=JAXBElement.class), @javax.xml.bind.annotation.XmlElementRef(name="fault", namespace="http://research.sun.com/wadl/2006/10", type=JAXBElement.class)})
/*     */   protected List<JAXBElement<RepresentationType>> representationOrFault;
/*     */   @XmlAnyElement(lax=true)
/*     */   protected List<Object> any;
/*     */   @XmlAnyAttribute
/*  73 */   private Map<QName, String> otherAttributes = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Doc> getDoc()
/*     */   {
/*  99 */     if (this.doc == null) {
/* 100 */       this.doc = new ArrayList();
/*     */     }
/* 102 */     return this.doc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Param> getParam()
/*     */   {
/* 128 */     if (this.param == null) {
/* 129 */       this.param = new ArrayList();
/*     */     }
/* 131 */     return this.param;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<JAXBElement<RepresentationType>> getRepresentationOrFault()
/*     */   {
/* 158 */     if (this.representationOrFault == null) {
/* 159 */       this.representationOrFault = new ArrayList();
/*     */     }
/* 161 */     return this.representationOrFault;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Object> getAny()
/*     */   {
/* 188 */     if (this.any == null) {
/* 189 */       this.any = new ArrayList();
/*     */     }
/* 191 */     return this.any;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<QName, String> getOtherAttributes()
/*     */   {
/* 209 */     return this.otherAttributes;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\research\ws\wadl\Response.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */