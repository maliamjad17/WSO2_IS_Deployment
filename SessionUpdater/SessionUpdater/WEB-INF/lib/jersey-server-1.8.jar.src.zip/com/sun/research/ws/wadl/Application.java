/*     */ package com.sun.research.ws.wadl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlAnyElement;
/*     */ import javax.xml.bind.annotation.XmlElementRefs;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name="", propOrder={"doc", "grammars", "resources", "resourceTypeOrMethodOrRepresentation", "any"})
/*     */ @XmlRootElement(name="application")
/*     */ public class Application
/*     */ {
/*     */   protected List<Doc> doc;
/*     */   protected Grammars grammars;
/*     */   protected Resources resources;
/*     */   @XmlElementRefs({@javax.xml.bind.annotation.XmlElementRef(name="resource_type", namespace="http://research.sun.com/wadl/2006/10", type=ResourceType.class), @javax.xml.bind.annotation.XmlElementRef(name="representation", namespace="http://research.sun.com/wadl/2006/10", type=javax.xml.bind.JAXBElement.class), @javax.xml.bind.annotation.XmlElementRef(name="fault", namespace="http://research.sun.com/wadl/2006/10", type=javax.xml.bind.JAXBElement.class), @javax.xml.bind.annotation.XmlElementRef(name="method", namespace="http://research.sun.com/wadl/2006/10", type=Method.class)})
/*     */   protected List<Object> resourceTypeOrMethodOrRepresentation;
/*     */   @XmlAnyElement(lax=true)
/*     */   protected List<Object> any;
/*     */   
/*     */   public List<Doc> getDoc()
/*     */   {
/*  99 */     if (this.doc == null) {
/* 100 */       this.doc = new ArrayList();
/*     */     }
/* 102 */     return this.doc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Grammars getGrammars()
/*     */   {
/* 114 */     return this.grammars;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setGrammars(Grammars value)
/*     */   {
/* 126 */     this.grammars = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Resources getResources()
/*     */   {
/* 138 */     return this.resources;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResources(Resources value)
/*     */   {
/* 150 */     this.resources = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Object> getResourceTypeOrMethodOrRepresentation()
/*     */   {
/* 179 */     if (this.resourceTypeOrMethodOrRepresentation == null) {
/* 180 */       this.resourceTypeOrMethodOrRepresentation = new ArrayList();
/*     */     }
/* 182 */     return this.resourceTypeOrMethodOrRepresentation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Object> getAny()
/*     */   {
/* 209 */     if (this.any == null) {
/* 210 */       this.any = new ArrayList();
/*     */     }
/* 212 */     return this.any;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\research\ws\wadl\Application.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */