/*     */ package com.sun.research.ws.wadl;
/*     */ 
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.bind.annotation.XmlElementDecl;
/*     */ import javax.xml.bind.annotation.XmlRegistry;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlRegistry
/*     */ public class ObjectFactory
/*     */ {
/*  34 */   private static final QName _Representation_QNAME = new QName("http://research.sun.com/wadl/2006/10", "representation");
/*  35 */   private static final QName _Fault_QNAME = new QName("http://research.sun.com/wadl/2006/10", "fault");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Resource createResource()
/*     */   {
/*  49 */     return new Resource();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Param createParam()
/*     */   {
/*  57 */     return new Param();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Request createRequest()
/*     */   {
/*  65 */     return new Request();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Application createApplication()
/*     */   {
/*  73 */     return new Application();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Method createMethod()
/*     */   {
/*  81 */     return new Method();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Grammars createGrammars()
/*     */   {
/*  89 */     return new Grammars();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Resources createResources()
/*     */   {
/*  97 */     return new Resources();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Doc createDoc()
/*     */   {
/* 105 */     return new Doc();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Option createOption()
/*     */   {
/* 113 */     return new Option();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceType createResourceType()
/*     */   {
/* 121 */     return new ResourceType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Link createLink()
/*     */   {
/* 129 */     return new Link();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public RepresentationType createRepresentationType()
/*     */   {
/* 137 */     return new RepresentationType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Response createResponse()
/*     */   {
/* 145 */     return new Response();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Include createInclude()
/*     */   {
/* 153 */     return new Include();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @XmlElementDecl(namespace="http://research.sun.com/wadl/2006/10", name="representation")
/*     */   public JAXBElement<RepresentationType> createRepresentation(RepresentationType value)
/*     */   {
/* 162 */     return new JAXBElement(_Representation_QNAME, RepresentationType.class, null, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @XmlElementDecl(namespace="http://research.sun.com/wadl/2006/10", name="fault")
/*     */   public JAXBElement<RepresentationType> createFault(RepresentationType value)
/*     */   {
/* 171 */     return new JAXBElement(_Fault_QNAME, RepresentationType.class, null, value);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\research\ws\wadl\ObjectFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */