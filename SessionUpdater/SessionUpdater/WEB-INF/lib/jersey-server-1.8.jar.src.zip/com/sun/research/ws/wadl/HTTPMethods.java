/*    */ package com.sun.research.ws.wadl;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlEnum;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlType(name="HTTPMethods")
/*    */ @XmlEnum
/*    */ public enum HTTPMethods
/*    */ {
/* 37 */   GET, 
/* 38 */   POST, 
/* 39 */   PUT, 
/* 40 */   HEAD, 
/* 41 */   DELETE;
/*    */   
/*    */   private HTTPMethods() {}
/* 44 */   public String value() { return name(); }
/*    */   
/*    */   public static HTTPMethods fromValue(String v)
/*    */   {
/* 48 */     return valueOf(v);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\research\ws\wadl\HTTPMethods.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */