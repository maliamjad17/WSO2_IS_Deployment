/*    */ package com.sun.research.ws.wadl;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlEnum;
/*    */ import javax.xml.bind.annotation.XmlEnumValue;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlType(name="ParamStyle")
/*    */ @XmlEnum
/*    */ public enum ParamStyle
/*    */ {
/* 38 */   PLAIN("plain"), 
/*    */   
/* 40 */   QUERY("query"), 
/*    */   
/* 42 */   MATRIX("matrix"), 
/*    */   
/* 44 */   HEADER("header"), 
/*    */   
/* 46 */   TEMPLATE("template");
/*    */   
/*    */   private final String value;
/*    */   
/*    */   private ParamStyle(String v) {
/* 51 */     this.value = v;
/*    */   }
/*    */   
/*    */   public String value() {
/* 55 */     return this.value;
/*    */   }
/*    */   
/*    */   public static ParamStyle fromValue(String v) {
/* 59 */     for (ParamStyle c : ) {
/* 60 */       if (c.value.equals(v)) {
/* 61 */         return c;
/*    */       }
/*    */     }
/* 64 */     throw new IllegalArgumentException(v);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\research\ws\wadl\ParamStyle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */