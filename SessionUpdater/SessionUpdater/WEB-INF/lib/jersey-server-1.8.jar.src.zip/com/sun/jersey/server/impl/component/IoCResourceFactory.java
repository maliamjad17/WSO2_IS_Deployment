/*     */ package com.sun.jersey.server.impl.component;
/*     */ 
/*     */ import com.sun.jersey.api.core.HttpContext;
/*     */ import com.sun.jersey.api.core.ResourceConfig;
/*     */ import com.sun.jersey.api.model.AbstractResource;
/*     */ import com.sun.jersey.core.spi.component.ComponentContext;
/*     */ import com.sun.jersey.core.spi.component.ComponentScope;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCComponentProvider;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCComponentProviderFactory;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCFullyManagedComponentProvider;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCManagedComponentProvider;
/*     */ import com.sun.jersey.server.impl.inject.ServerInjectableProviderContext;
/*     */ import com.sun.jersey.server.spi.component.ResourceComponentInjector;
/*     */ import com.sun.jersey.server.spi.component.ResourceComponentProvider;
/*     */ import com.sun.jersey.server.spi.component.ResourceComponentProviderFactory;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IoCResourceFactory
/*     */   extends ResourceFactory
/*     */ {
/*     */   private final List<IoCComponentProviderFactory> factories;
/*     */   
/*     */   public IoCResourceFactory(ResourceConfig config, ServerInjectableProviderContext ipc, List<IoCComponentProviderFactory> factories)
/*     */   {
/*  68 */     super(config, ipc);
/*  69 */     this.factories = factories;
/*     */   }
/*     */   
/*     */   public ResourceComponentProvider getComponentProvider(ComponentContext cc, Class c)
/*     */   {
/*  74 */     IoCComponentProvider icp = null;
/*  75 */     for (IoCComponentProviderFactory f : this.factories) {
/*  76 */       icp = f.getComponentProvider(cc, c);
/*  77 */       if (icp != null)
/*     */         break;
/*     */     }
/*  80 */     return icp == null ? super.getComponentProvider(cc, c) : wrap(c, icp);
/*     */   }
/*     */   
/*     */   private ResourceComponentProvider wrap(Class c, IoCComponentProvider icp) {
/*  84 */     if ((icp instanceof IoCManagedComponentProvider)) {
/*  85 */       IoCManagedComponentProvider imcp = (IoCManagedComponentProvider)icp;
/*  86 */       if (imcp.getScope() == ComponentScope.PerRequest)
/*  87 */         return new PerRequestWrapper(getInjectableProviderContext(), imcp);
/*  88 */       if (imcp.getScope() == ComponentScope.Singleton) {
/*  89 */         return new SingletonWrapper(getInjectableProviderContext(), imcp);
/*     */       }
/*  91 */       return new UndefinedWrapper(getInjectableProviderContext(), imcp);
/*     */     }
/*  93 */     if ((icp instanceof IoCFullyManagedComponentProvider)) {
/*  94 */       IoCFullyManagedComponentProvider ifmcp = (IoCFullyManagedComponentProvider)icp;
/*  95 */       return new FullyManagedWrapper(ifmcp);
/*     */     }
/*  97 */     ResourceComponentProviderFactory rcpf = getComponentProviderFactory(c);
/*  98 */     return rcpf.getComponentProvider(icp, c);
/*     */   }
/*     */   
/*     */   private static class FullyManagedWrapper implements ResourceComponentProvider
/*     */   {
/*     */     private final IoCFullyManagedComponentProvider ifmcp;
/*     */     
/*     */     FullyManagedWrapper(IoCFullyManagedComponentProvider ifmcp) {
/* 106 */       this.ifmcp = ifmcp;
/*     */     }
/*     */     
/*     */     public void init(AbstractResource abstractResource) {}
/*     */     
/*     */     public ComponentScope getScope()
/*     */     {
/* 113 */       return this.ifmcp.getScope();
/*     */     }
/*     */     
/*     */     public Object getInstance(HttpContext hc) {
/* 117 */       return this.ifmcp.getInstance();
/*     */     }
/*     */     
/*     */     public Object getInstance() {
/* 121 */       throw new IllegalStateException();
/*     */     }
/*     */     
/*     */     public void destroy() {}
/*     */   }
/*     */   
/*     */   private static class PerRequestWrapper implements ResourceComponentProvider
/*     */   {
/*     */     private final ServerInjectableProviderContext ipc;
/*     */     private final IoCManagedComponentProvider imcp;
/*     */     private ResourceComponentInjector rci;
/*     */     
/*     */     PerRequestWrapper(ServerInjectableProviderContext ipc, IoCManagedComponentProvider imcp) {
/* 134 */       this.ipc = ipc;
/* 135 */       this.imcp = imcp;
/*     */     }
/*     */     
/*     */     public void init(AbstractResource abstractResource) {
/* 139 */       this.rci = new ResourceComponentInjector(this.ipc, ComponentScope.PerRequest, abstractResource);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public ComponentScope getScope()
/*     */     {
/* 146 */       return ComponentScope.PerRequest;
/*     */     }
/*     */     
/*     */     public Object getInstance(HttpContext hc) {
/* 150 */       Object o = this.imcp.getInstance();
/* 151 */       this.rci.inject(hc, this.imcp.getInjectableInstance(o));
/* 152 */       return o;
/*     */     }
/*     */     
/*     */     public Object getInstance() {
/* 156 */       throw new IllegalStateException();
/*     */     }
/*     */     
/*     */     public void destroy() {}
/*     */   }
/*     */   
/*     */   private static class SingletonWrapper implements ResourceComponentProvider
/*     */   {
/*     */     private final ServerInjectableProviderContext ipc;
/*     */     private final IoCManagedComponentProvider imcp;
/*     */     private Object o;
/*     */     
/*     */     SingletonWrapper(ServerInjectableProviderContext ipc, IoCManagedComponentProvider imcp) {
/* 169 */       this.ipc = ipc;
/* 170 */       this.imcp = imcp;
/*     */     }
/*     */     
/*     */     public void init(AbstractResource abstractResource) {
/* 174 */       ResourceComponentInjector rci = new ResourceComponentInjector(this.ipc, ComponentScope.Singleton, abstractResource);
/*     */       
/*     */ 
/*     */ 
/* 178 */       this.o = this.imcp.getInstance();
/* 179 */       rci.inject(null, this.imcp.getInjectableInstance(this.o));
/*     */     }
/*     */     
/*     */     public ComponentScope getScope() {
/* 183 */       return ComponentScope.Singleton;
/*     */     }
/*     */     
/*     */     public Object getInstance(HttpContext hc) {
/* 187 */       return this.o;
/*     */     }
/*     */     
/*     */     public Object getInstance() {
/* 191 */       throw new IllegalStateException();
/*     */     }
/*     */     
/*     */     public void destroy() {}
/*     */   }
/*     */   
/*     */   private static class UndefinedWrapper implements ResourceComponentProvider
/*     */   {
/*     */     private final ServerInjectableProviderContext ipc;
/*     */     private final IoCManagedComponentProvider imcp;
/*     */     private ResourceComponentInjector rci;
/*     */     
/*     */     UndefinedWrapper(ServerInjectableProviderContext ipc, IoCManagedComponentProvider imcp) {
/* 204 */       this.ipc = ipc;
/* 205 */       this.imcp = imcp;
/*     */     }
/*     */     
/*     */     public void init(AbstractResource abstractResource) {
/* 209 */       this.rci = new ResourceComponentInjector(this.ipc, ComponentScope.Undefined, abstractResource);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public ComponentScope getScope()
/*     */     {
/* 216 */       return ComponentScope.Undefined;
/*     */     }
/*     */     
/*     */     public Object getInstance(HttpContext hc) {
/* 220 */       Object o = this.imcp.getInstance();
/* 221 */       this.rci.inject(hc, this.imcp.getInjectableInstance(o));
/* 222 */       return o;
/*     */     }
/*     */     
/*     */     public Object getInstance() {
/* 226 */       throw new IllegalStateException();
/*     */     }
/*     */     
/*     */     public void destroy() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\component\IoCResourceFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */