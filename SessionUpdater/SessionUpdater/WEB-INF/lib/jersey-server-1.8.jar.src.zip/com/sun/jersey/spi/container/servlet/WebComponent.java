/*     */ package com.sun.jersey.spi.container.servlet;
/*     */ 
/*     */ import com.sun.jersey.api.container.ContainerException;
/*     */ import com.sun.jersey.api.container.MappableContainerException;
/*     */ import com.sun.jersey.api.core.ApplicationAdapter;
/*     */ import com.sun.jersey.api.core.ClasspathResourceConfig;
/*     */ import com.sun.jersey.api.core.PackagesResourceConfig;
/*     */ import com.sun.jersey.api.core.ResourceConfig;
/*     */ import com.sun.jersey.api.core.TraceInformation;
/*     */ import com.sun.jersey.api.core.TraceInformation.TraceHeaderListener;
/*     */ import com.sun.jersey.api.core.WebAppResourceConfig;
/*     */ import com.sun.jersey.api.representation.Form;
/*     */ import com.sun.jersey.core.header.InBoundHeaders;
/*     */ import com.sun.jersey.core.header.MediaTypes;
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*     */ import com.sun.jersey.core.util.ReaderWriter;
/*     */ import com.sun.jersey.server.impl.InitialContextHelper;
/*     */ import com.sun.jersey.server.impl.ThreadLocalInvoker;
/*     */ import com.sun.jersey.server.impl.application.DeferredResourceConfig;
/*     */ import com.sun.jersey.server.impl.cdi.CDIComponentProviderFactoryInitializer;
/*     */ import com.sun.jersey.server.impl.container.servlet.JSPTemplateProcessor;
/*     */ import com.sun.jersey.server.impl.ejb.EJBComponentProviderFactoryInitilizer;
/*     */ import com.sun.jersey.server.impl.managedbeans.ManagedBeanComponentProviderFactoryInitilizer;
/*     */ import com.sun.jersey.server.impl.monitoring.GlassFishMonitoringInitializer;
/*     */ import com.sun.jersey.server.probes.UriRuleProbeProvider;
/*     */ import com.sun.jersey.spi.container.ContainerListener;
/*     */ import com.sun.jersey.spi.container.ContainerNotifier;
/*     */ import com.sun.jersey.spi.container.ContainerRequest;
/*     */ import com.sun.jersey.spi.container.ContainerResponse;
/*     */ import com.sun.jersey.spi.container.ContainerResponseWriter;
/*     */ import com.sun.jersey.spi.container.ReloadListener;
/*     */ import com.sun.jersey.spi.container.WebApplication;
/*     */ import com.sun.jersey.spi.container.WebApplicationFactory;
/*     */ import com.sun.jersey.spi.inject.SingletonTypeInjectableProvider;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.URI;
/*     */ import java.security.Principal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.naming.NamingException;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.ws.rs.core.Application;
/*     */ import javax.ws.rs.core.GenericEntity;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.core.Response.StatusType;
/*     */ import javax.ws.rs.core.SecurityContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebComponent
/*     */   implements ContainerListener
/*     */ {
/*     */   public static final String APPLICATION_CONFIG_CLASS = "javax.ws.rs.Application";
/*     */   public static final String RESOURCE_CONFIG_CLASS = "com.sun.jersey.config.property.resourceConfigClass";
/*     */   public static final String JSP_TEMPLATES_BASE_PATH = "com.sun.jersey.config.property.JSPTemplatesBasePath";
/* 143 */   private static final Logger LOGGER = Logger.getLogger(WebComponent.class.getName());
/*     */   
/*     */ 
/* 146 */   private final ThreadLocalInvoker<HttpServletRequest> requestInvoker = new ThreadLocalInvoker();
/*     */   
/*     */ 
/* 149 */   private final ThreadLocalInvoker<HttpServletResponse> responseInvoker = new ThreadLocalInvoker();
/*     */   
/*     */ 
/*     */   private WebConfig config;
/*     */   
/*     */ 
/*     */   private ResourceConfig resourceConfig;
/*     */   
/* 157 */   private boolean useSetStatusOn404 = false;
/*     */   
/*     */   private WebApplication application;
/*     */   
/*     */   public WebComponent() {}
/*     */   
/*     */   public WebComponent(Application app)
/*     */   {
/* 165 */     if (app == null) {
/* 166 */       throw new IllegalArgumentException();
/*     */     }
/* 168 */     if ((app instanceof ResourceConfig)) {
/* 169 */       this.resourceConfig = ((ResourceConfig)app);
/*     */     } else {
/* 171 */       this.resourceConfig = new ApplicationAdapter(app);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WebConfig getWebConfig()
/*     */   {
/* 181 */     return this.config;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceConfig getResourceConfig()
/*     */   {
/* 190 */     return this.resourceConfig;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void init(WebConfig webConfig)
/*     */     throws ServletException
/*     */   {
/* 200 */     this.config = webConfig;
/*     */     
/* 202 */     if (this.resourceConfig == null) {
/* 203 */       this.resourceConfig = createResourceConfig(this.config);
/*     */     }
/* 205 */     if ((this.config.getConfigType() == WebConfig.ConfigType.FilterConfig) && (this.resourceConfig.getFeature("com.sun.jersey.config.feature.FilterForwardOn404")))
/*     */     {
/* 207 */       this.useSetStatusOn404 = true;
/*     */     }
/*     */     
/* 210 */     load();
/*     */     
/* 212 */     Object o = this.resourceConfig.getProperties().get("com.sun.jersey.spi.container.ContainerNotifier");
/*     */     
/* 214 */     if ((o instanceof List)) {
/* 215 */       List list = (List)o;
/* 216 */       for (Object elem : list) {
/* 217 */         if ((elem instanceof ContainerNotifier)) {
/* 218 */           ContainerNotifier crf = (ContainerNotifier)elem;
/* 219 */           crf.addListener(this);
/*     */         }
/*     */       }
/* 222 */     } else if ((o instanceof ContainerNotifier)) {
/* 223 */       ContainerNotifier crf = (ContainerNotifier)o;
/* 224 */       crf.addListener(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 234 */     if (this.application != null) {
/* 235 */       this.application.destroy();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static final class Writer
/*     */     extends OutputStream
/*     */     implements ContainerResponseWriter
/*     */   {
/*     */     final HttpServletResponse response;
/*     */     final boolean useSetStatusOn404;
/*     */     ContainerResponse cResponse;
/*     */     long contentLength;
/*     */     OutputStream out;
/* 249 */     boolean statusAndHeadersWritten = false;
/*     */     
/*     */     Writer(boolean useSetStatusOn404, HttpServletResponse response) {
/* 252 */       this.useSetStatusOn404 = useSetStatusOn404;
/* 253 */       this.response = response;
/*     */     }
/*     */     
/*     */     public OutputStream writeStatusAndHeaders(long contentLength, ContainerResponse cResponse) throws IOException
/*     */     {
/* 258 */       this.contentLength = contentLength;
/* 259 */       this.cResponse = cResponse;
/* 260 */       this.statusAndHeadersWritten = false;
/* 261 */       return this;
/*     */     }
/*     */     
/*     */     public void finish() throws IOException {
/* 265 */       if (this.statusAndHeadersWritten) {
/* 266 */         return;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 272 */       writeHeaders();
/*     */       
/* 274 */       if (this.cResponse.getStatus() >= 400) {
/* 275 */         if ((this.useSetStatusOn404) && (this.cResponse.getStatus() == 404)) {
/* 276 */           this.response.setStatus(this.cResponse.getStatus());
/*     */         } else {
/* 278 */           String reason = this.cResponse.getStatusType().getReasonPhrase();
/* 279 */           if ((reason == null) || (reason.isEmpty())) {
/* 280 */             this.response.sendError(this.cResponse.getStatus());
/*     */           } else {
/* 282 */             this.response.sendError(this.cResponse.getStatus(), reason);
/*     */           }
/*     */         }
/*     */       } else {
/* 286 */         this.response.setStatus(this.cResponse.getStatus());
/*     */       }
/*     */     }
/*     */     
/*     */     public void write(int b) throws IOException {
/* 291 */       initiate();
/* 292 */       this.out.write(b);
/*     */     }
/*     */     
/*     */     public void write(byte[] b) throws IOException
/*     */     {
/* 297 */       if (b.length > 0) {
/* 298 */         initiate();
/* 299 */         this.out.write(b);
/*     */       }
/*     */     }
/*     */     
/*     */     public void write(byte[] b, int off, int len) throws IOException
/*     */     {
/* 305 */       if (len > 0) {
/* 306 */         initiate();
/* 307 */         this.out.write(b, off, len);
/*     */       }
/*     */     }
/*     */     
/*     */     public void flush() throws IOException
/*     */     {
/* 313 */       writeStatusAndHeaders();
/* 314 */       if (this.out != null) {
/* 315 */         this.out.flush();
/*     */       }
/*     */     }
/*     */     
/*     */     public void close() throws IOException {
/* 320 */       initiate();
/* 321 */       this.out.close();
/*     */     }
/*     */     
/*     */     void initiate() throws IOException {
/* 325 */       if (this.out == null) {
/* 326 */         writeStatusAndHeaders();
/* 327 */         this.out = this.response.getOutputStream();
/*     */       }
/*     */     }
/*     */     
/*     */     void writeStatusAndHeaders() {
/* 332 */       if (this.statusAndHeadersWritten) {
/* 333 */         return;
/*     */       }
/* 335 */       writeHeaders();
/* 336 */       this.response.setStatus(this.cResponse.getStatus());
/* 337 */       this.statusAndHeadersWritten = true;
/*     */     }
/*     */     
/*     */     void writeHeaders() {
/* 341 */       if ((this.contentLength != -1L) && (this.contentLength < 2147483647L)) {
/* 342 */         this.response.setContentLength((int)this.contentLength);
/*     */       }
/* 344 */       MultivaluedMap<String, Object> headers = this.cResponse.getHttpHeaders();
/* 345 */       for (Iterator i$ = headers.entrySet().iterator(); i$.hasNext();) { e = (Map.Entry)i$.next();
/* 346 */         for (Object v : (List)e.getValue()) {
/* 347 */           this.response.addHeader((String)e.getKey(), ContainerResponse.getHeaderValue(v));
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       Map.Entry<String, List<Object>> e;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int service(URI baseUri, URI requestUri, final HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 378 */     WebApplication _application = this.application;
/*     */     
/* 380 */     ContainerRequest cRequest = createRequest(_application, request, baseUri, requestUri);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 386 */     cRequest.setSecurityContext(new SecurityContext() {
/*     */       public Principal getUserPrincipal() {
/* 388 */         return request.getUserPrincipal();
/*     */       }
/*     */       
/*     */       public boolean isUserInRole(String role) {
/* 392 */         return request.isUserInRole(role);
/*     */       }
/*     */       
/*     */       public boolean isSecure() {
/* 396 */         return request.isSecure();
/*     */       }
/*     */       
/*     */       public String getAuthenticationScheme() {
/* 400 */         return request.getAuthType();
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 406 */     });
/* 407 */     filterFormParameters(request, cRequest);
/*     */     try
/*     */     {
/* 410 */       UriRuleProbeProvider.requestStart(requestUri);
/*     */       
/* 412 */       this.requestInvoker.set(request);
/* 413 */       this.responseInvoker.set(response);
/*     */       
/* 415 */       Writer w = new Writer(this.useSetStatusOn404, response);
/* 416 */       _application.handleRequest(cRequest, w);
/* 417 */       return w.cResponse.getStatus();
/*     */     } catch (MappableContainerException ex) {
/* 419 */       traceOnException(cRequest, response);
/* 420 */       throw new ServletException(ex.getCause());
/*     */     } catch (ContainerException ex) {
/* 422 */       traceOnException(cRequest, response);
/*     */       
/*     */ 
/* 425 */       throw new ServletException(ex);
/*     */     } catch (RuntimeException ex) {
/* 427 */       traceOnException(cRequest, response);
/*     */       
/*     */ 
/* 430 */       throw ex;
/*     */     } finally {
/* 432 */       UriRuleProbeProvider.requestEnd();
/* 433 */       this.requestInvoker.set(null);
/* 434 */       this.responseInvoker.set(null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ContainerRequest createRequest(WebApplication app, HttpServletRequest request, URI baseUri, URI requestUri)
/*     */     throws IOException
/*     */   {
/* 450 */     return new ContainerRequest(app, request.getMethod(), baseUri, requestUri, getHeaders(request), request.getInputStream());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void traceOnException(ContainerRequest cRequest, final HttpServletResponse response)
/*     */   {
/* 460 */     if (cRequest.isTracingEnabled()) {
/* 461 */       TraceInformation ti = (TraceInformation)cRequest.getProperties().get(TraceInformation.class.getName());
/*     */       
/*     */ 
/* 464 */       ti.addTraceHeaders(new TraceInformation.TraceHeaderListener() {
/*     */         public void onHeader(String name, String value) {
/* 466 */           response.addHeader(name, value);
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected WebApplication create()
/*     */   {
/* 478 */     return WebApplicationFactory.createWebApplication();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static class ContextInjectableProvider<T>
/*     */     extends SingletonTypeInjectableProvider<javax.ws.rs.core.Context, T>
/*     */   {
/*     */     protected ContextInjectableProvider(Type type, T instance)
/*     */     {
/* 497 */       super(instance);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void configure(WebConfig wc, ResourceConfig rc, WebApplication wa)
/*     */   {
/* 534 */     configureJndiResources(rc);
/*     */     
/* 536 */     rc.getSingletons().add(new ContextInjectableProvider(HttpServletRequest.class, (HttpServletRequest)Proxy.newProxyInstance(getClass().getClassLoader(), new Class[] { HttpServletRequest.class }, this.requestInvoker)));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 543 */     rc.getSingletons().add(new ContextInjectableProvider(HttpServletResponse.class, (HttpServletResponse)Proxy.newProxyInstance(getClass().getClassLoader(), new Class[] { HttpServletResponse.class }, this.responseInvoker)));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 550 */     GenericEntity<ThreadLocal<HttpServletRequest>> requestThreadLocal = new GenericEntity(this.requestInvoker.getImmutableThreadLocal()) {};
/* 553 */     rc.getSingletons().add(new ContextInjectableProvider(requestThreadLocal.getType(), requestThreadLocal.getEntity()));
/*     */     
/*     */ 
/* 556 */     GenericEntity<ThreadLocal<HttpServletResponse>> responseThreadLocal = new GenericEntity(this.responseInvoker.getImmutableThreadLocal()) {};
/* 559 */     rc.getSingletons().add(new ContextInjectableProvider(responseThreadLocal.getType(), responseThreadLocal.getEntity()));
/*     */     
/*     */ 
/* 562 */     rc.getSingletons().add(new ContextInjectableProvider(ServletContext.class, wc.getServletContext()));
/*     */     
/*     */ 
/*     */ 
/* 566 */     rc.getSingletons().add(new ContextInjectableProvider(WebConfig.class, wc));
/*     */     
/*     */ 
/*     */ 
/* 570 */     rc.getClasses().add(JSPTemplateProcessor.class);
/*     */     
/*     */ 
/*     */ 
/* 574 */     EJBComponentProviderFactoryInitilizer.initialize(rc);
/*     */     
/* 576 */     CDIComponentProviderFactoryInitializer.initialize(rc, wa);
/*     */     
/*     */ 
/*     */ 
/* 580 */     ManagedBeanComponentProviderFactoryInitilizer.initialize(rc);
/*     */     
/* 582 */     GlassFishMonitoringInitializer.initialize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initiate(ResourceConfig rc, WebApplication wa)
/*     */   {
/* 598 */     wa.initiate(rc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void load()
/*     */   {
/* 607 */     WebApplication _application = create();
/* 608 */     configure(this.config, this.resourceConfig, _application);
/* 609 */     initiate(this.resourceConfig, _application);
/* 610 */     this.application = _application;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResourceConfig getDefaultResourceConfig(Map<String, Object> props, WebConfig wc)
/*     */     throws ServletException
/*     */   {
/* 633 */     return getWebAppResourceConfig(props, wc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onReload()
/*     */   {
/* 654 */     WebApplication oldApplication = this.application;
/* 655 */     WebApplication newApplication = create();
/* 656 */     initiate(this.resourceConfig, newApplication);
/* 657 */     this.application = newApplication;
/*     */     
/* 659 */     if ((this.resourceConfig instanceof ReloadListener)) {
/* 660 */       ((ReloadListener)this.resourceConfig).onReload();
/*     */     }
/* 662 */     oldApplication.destroy();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   ResourceConfig getWebAppResourceConfig(Map<String, Object> props, WebConfig webConfig)
/*     */     throws ServletException
/*     */   {
/* 672 */     return new WebAppResourceConfig(props, webConfig.getServletContext());
/*     */   }
/*     */   
/*     */   private ResourceConfig createResourceConfig(WebConfig webConfig) throws ServletException
/*     */   {
/* 677 */     Map<String, Object> props = getInitParams(webConfig);
/* 678 */     ResourceConfig rc = createResourceConfig(webConfig, props);
/* 679 */     rc.setPropertiesAndFeatures(props);
/* 680 */     return rc;
/*     */   }
/*     */   
/*     */   private ResourceConfig createResourceConfig(WebConfig webConfig, Map<String, Object> props)
/*     */     throws ServletException
/*     */   {
/* 686 */     String resourceConfigClassName = webConfig.getInitParameter("com.sun.jersey.config.property.resourceConfigClass");
/*     */     
/*     */ 
/* 689 */     if (resourceConfigClassName == null) {
/* 690 */       resourceConfigClassName = webConfig.getInitParameter("javax.ws.rs.Application");
/*     */     }
/*     */     
/* 693 */     if (resourceConfigClassName == null)
/*     */     {
/*     */ 
/* 696 */       String packages = webConfig.getInitParameter("com.sun.jersey.config.property.packages");
/*     */       
/* 698 */       if (packages != null) {
/* 699 */         props.put("com.sun.jersey.config.property.packages", packages);
/* 700 */         return new PackagesResourceConfig(props);
/*     */       }
/*     */       
/* 703 */       ResourceConfig defaultConfig = webConfig.getDefaultResourceConfig(props);
/* 704 */       if (defaultConfig != null) {
/* 705 */         return defaultConfig;
/*     */       }
/* 707 */       return getDefaultResourceConfig(props, webConfig);
/*     */     }
/*     */     try
/*     */     {
/* 711 */       Class<?> resourceConfigClass = ReflectionHelper.classForNameWithException(resourceConfigClassName);
/*     */       
/*     */ 
/*     */ 
/* 715 */       if (resourceConfigClass == ClasspathResourceConfig.class) {
/* 716 */         String[] paths = getPaths(webConfig.getInitParameter("com.sun.jersey.config.property.classpath"));
/*     */         
/* 718 */         props.put("com.sun.jersey.config.property.classpath", paths);
/* 719 */         return new ClasspathResourceConfig(props); }
/* 720 */       if (ResourceConfig.class.isAssignableFrom(resourceConfigClass)) {
/*     */         try {
/* 722 */           Constructor constructor = resourceConfigClass.getConstructor(new Class[] { Map.class });
/* 723 */           if (ClasspathResourceConfig.class.isAssignableFrom(resourceConfigClass)) {
/* 724 */             String[] paths = getPaths(webConfig.getInitParameter("com.sun.jersey.config.property.classpath"));
/*     */             
/* 726 */             props.put("com.sun.jersey.config.property.classpath", paths);
/*     */           }
/* 728 */           return (ResourceConfig)constructor.newInstance(new Object[] { props });
/*     */         }
/*     */         catch (NoSuchMethodException ex) {}catch (Exception e)
/*     */         {
/* 732 */           throw new ServletException(e);
/*     */         }
/*     */         
/* 735 */         return new DeferredResourceConfig(resourceConfigClass.asSubclass(ResourceConfig.class)); }
/* 736 */       if (Application.class.isAssignableFrom(resourceConfigClass)) {
/* 737 */         return new DeferredResourceConfig(resourceConfigClass.asSubclass(Application.class));
/*     */       }
/* 739 */       String message = "Resource configuration class, " + resourceConfigClassName + ", is not a super class of " + Application.class;
/*     */       
/* 741 */       throw new ServletException(message);
/*     */     }
/*     */     catch (ClassNotFoundException e) {
/* 744 */       String message = "Resource configuration class, " + resourceConfigClassName + ", could not be loaded";
/*     */       
/* 746 */       throw new ServletException(message, e);
/*     */     }
/*     */   }
/*     */   
/*     */   private Map<String, Object> getInitParams(WebConfig webConfig) {
/* 751 */     Map<String, Object> props = new HashMap();
/* 752 */     Enumeration names = webConfig.getInitParameterNames();
/* 753 */     while (names.hasMoreElements()) {
/* 754 */       String name = (String)names.nextElement();
/* 755 */       props.put(name, webConfig.getInitParameter(name));
/*     */     }
/* 757 */     return props;
/*     */   }
/*     */   
/*     */   private String[] getPaths(String classpath) throws ServletException {
/* 761 */     ServletContext context = this.config.getServletContext();
/* 762 */     if (classpath == null) {
/* 763 */       String[] paths = { context.getRealPath("/WEB-INF/lib"), context.getRealPath("/WEB-INF/classes") };
/*     */       
/*     */ 
/*     */ 
/* 767 */       if ((paths[0] == null) && (paths[1] == null)) {
/* 768 */         String message = "The default deployment configuration that scans for classes in /WEB-INF/lib and /WEB-INF/classes is not supported for the application server.Try using the package scanning configuration, see the JavaDoc for " + PackagesResourceConfig.class.getName() + " and the property " + "com.sun.jersey.config.property.packages" + ".";
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 774 */         throw new ServletException(message);
/*     */       }
/* 776 */       return paths;
/*     */     }
/* 778 */     String[] virtualPaths = classpath.split(";");
/* 779 */     List<String> resourcePaths = new ArrayList();
/* 780 */     for (String virtualPath : virtualPaths) {
/* 781 */       virtualPath = virtualPath.trim();
/* 782 */       if (virtualPath.length() != 0) {
/* 783 */         String path = context.getRealPath(virtualPath);
/* 784 */         if (path != null) resourcePaths.add(path);
/*     */       } }
/* 786 */     if (resourcePaths.isEmpty()) {
/* 787 */       String message = "None of the declared classpath locations, " + classpath + ", could be resolved. " + "This could be because the default deployment configuration that scans for " + "classes in classpath locations is not supported. " + "Try using the package scanning configuration, see the JavaDoc for " + PackagesResourceConfig.class.getName() + " and the property " + "com.sun.jersey.config.property.packages" + ".";
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 795 */       throw new ServletException(message);
/*     */     }
/* 797 */     return (String[])resourcePaths.toArray(new String[resourcePaths.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void configureJndiResources(ResourceConfig rc)
/*     */   {
/* 805 */     javax.naming.Context x = InitialContextHelper.getInitialContext();
/* 806 */     if (x != null) {
/* 807 */       Iterator<Class<?>> i = rc.getClasses().iterator();
/* 808 */       while (i.hasNext()) {
/* 809 */         Class<?> c = (Class)i.next();
/* 810 */         if (c.isInterface()) {
/*     */           try
/*     */           {
/* 813 */             Object o = x.lookup(c.getName());
/* 814 */             if (o != null) {
/* 815 */               i.remove();
/* 816 */               rc.getSingletons().add(o);
/* 817 */               LOGGER.log(Level.INFO, "An instance of the class " + c.getName() + " is found by JNDI look up using the class name as the JNDI name. " + "The instance will be registered as a singleton.");
/*     */             }
/*     */             
/*     */           }
/*     */           catch (NamingException ex)
/*     */           {
/* 823 */             LOGGER.log(Level.CONFIG, "JNDI lookup failed for Jersey application resource " + c.getName(), ex);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void filterFormParameters(HttpServletRequest hsr, ContainerRequest cr) throws IOException
/*     */   {
/* 832 */     if ((cr.getMethod().equals("POST")) && (MediaTypes.typeEquals(MediaType.APPLICATION_FORM_URLENCODED_TYPE, cr.getMediaType())) && (!isEntityPresent(cr)))
/*     */     {
/*     */ 
/* 835 */       Form f = new Form();
/*     */       
/* 837 */       Enumeration e = hsr.getParameterNames();
/* 838 */       while (e.hasMoreElements()) {
/* 839 */         String name = (String)e.nextElement();
/* 840 */         String[] values = hsr.getParameterValues(name);
/*     */         
/* 842 */         f.put(name, Arrays.asList(values));
/*     */       }
/*     */       
/* 845 */       if (!f.isEmpty()) {
/* 846 */         cr.getProperties().put("com.sun.jersey.api.representation.form", f);
/* 847 */         if (LOGGER.isLoggable(Level.WARNING)) {
/* 848 */           LOGGER.log(Level.WARNING, "A servlet POST request, to the URI " + cr.getRequestUri() + ", " + "contains form parameters in " + "the request body but the request body has been consumed " + "by the servlet or a servlet filter accessing the request " + "parameters. Only resource methods using @FormParam " + "will work as expected. Resource methods consuming the " + "request body by other means will not work as expected.");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isEntityPresent(ContainerRequest cr)
/*     */     throws IOException
/*     */   {
/* 862 */     InputStream in = cr.getEntityInputStream();
/* 863 */     if (!in.markSupported()) {
/* 864 */       in = new BufferedInputStream(in, ReaderWriter.BUFFER_SIZE);
/* 865 */       cr.setEntityInputStream(in);
/*     */     }
/*     */     
/* 868 */     in.mark(1);
/* 869 */     if (in.read() == -1) {
/* 870 */       return false;
/*     */     }
/* 872 */     in.reset();
/* 873 */     return true;
/*     */   }
/*     */   
/*     */   private InBoundHeaders getHeaders(HttpServletRequest request)
/*     */   {
/* 878 */     InBoundHeaders rh = new InBoundHeaders();
/*     */     
/* 880 */     for (Enumeration<String> names = request.getHeaderNames(); names.hasMoreElements();) {
/* 881 */       String name = (String)names.nextElement();
/* 882 */       List<String> valueList = new LinkedList();
/* 883 */       for (Enumeration<String> values = request.getHeaders(name); values.hasMoreElements();) {
/* 884 */         valueList.add(values.nextElement());
/*     */       }
/* 886 */       rh.put(name, valueList);
/*     */     }
/*     */     
/* 889 */     return rh;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\container\servlet\WebComponent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */