package com.sun.jersey.api.core;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.StatusType;

public abstract interface HttpResponseContext
{
  public abstract Response getResponse();
  
  public abstract void setResponse(Response paramResponse);
  
  public abstract boolean isResponseSet();
  
  public abstract Throwable getMappedThrowable();
  
  public abstract Response.StatusType getStatusType();
  
  public abstract void setStatusType(Response.StatusType paramStatusType);
  
  public abstract int getStatus();
  
  public abstract void setStatus(int paramInt);
  
  public abstract Object getEntity();
  
  public abstract Type getEntityType();
  
  public abstract Object getOriginalEntity();
  
  public abstract void setEntity(Object paramObject);
  
  public abstract Annotation[] getAnnotations();
  
  public abstract void setAnnotations(Annotation[] paramArrayOfAnnotation);
  
  public abstract MultivaluedMap<String, Object> getHttpHeaders();
  
  public abstract MediaType getMediaType();
  
  public abstract OutputStream getOutputStream()
    throws IOException;
  
  public abstract boolean isCommitted();
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\core\HttpResponseContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */