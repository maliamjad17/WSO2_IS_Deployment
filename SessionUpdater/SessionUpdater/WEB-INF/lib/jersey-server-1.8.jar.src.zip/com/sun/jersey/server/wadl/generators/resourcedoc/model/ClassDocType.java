/*     */ package com.sun.jersey.server.wadl.generators.resourcedoc.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlAnyElement;
/*     */ import javax.xml.bind.annotation.XmlElementWrapper;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name="classDoc", propOrder={})
/*     */ public class ClassDocType
/*     */ {
/*     */   private String className;
/*     */   private String commentText;
/*     */   @XmlElementWrapper(name="methodDocs")
/*     */   private List<MethodDocType> methodDoc;
/*     */   @XmlAnyElement(lax=true)
/*     */   private List<Object> any;
/*     */   
/*     */   public List<MethodDocType> getMethodDocs()
/*     */   {
/*  71 */     if (this.methodDoc == null) {
/*  72 */       this.methodDoc = new ArrayList();
/*     */     }
/*  74 */     return this.methodDoc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<Object> getAny()
/*     */   {
/*  81 */     if (this.any == null) {
/*  82 */       this.any = new ArrayList();
/*     */     }
/*  84 */     return this.any;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getCommentText()
/*     */   {
/*  91 */     return this.commentText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setCommentText(String commentText)
/*     */   {
/*  98 */     this.commentText = commentText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getClassName()
/*     */   {
/* 105 */     return this.className;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setClassName(String className)
/*     */   {
/* 112 */     this.className = className;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\wadl\generators\resourcedoc\model\ClassDocType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */