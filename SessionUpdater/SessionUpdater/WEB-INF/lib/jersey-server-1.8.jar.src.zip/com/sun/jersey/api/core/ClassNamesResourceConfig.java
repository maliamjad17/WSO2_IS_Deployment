/*     */ package com.sun.jersey.api.core;
/*     */ 
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassNamesResourceConfig
/*     */   extends DefaultResourceConfig
/*     */ {
/*     */   public static final String PROPERTY_CLASSNAMES = "com.sun.jersey.config.property.classnames";
/*     */   
/*     */   public ClassNamesResourceConfig(Class... classes)
/*     */   {
/*  69 */     for (Class c : classes) {
/*  70 */       getClasses().add(c);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClassNamesResourceConfig(String... classNames)
/*     */   {
/*  79 */     super(getClasses(classNames));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClassNamesResourceConfig(Map<String, Object> props)
/*     */   {
/*  90 */     super(getClasses(props));
/*  91 */     setPropertiesAndFeatures(props);
/*     */   }
/*     */   
/*     */   private static Set<Class<?>> getClasses(Map<String, Object> props) {
/*  95 */     Object v = props.get("com.sun.jersey.config.property.classnames");
/*  96 */     if (v == null) {
/*  97 */       throw new IllegalArgumentException("com.sun.jersey.config.property.classnames property is missing");
/*     */     }
/*  99 */     Set<Class<?>> s = getClasses(v);
/* 100 */     if (s.isEmpty()) {
/* 101 */       throw new IllegalArgumentException("com.sun.jersey.config.property.classnames contains no classes");
/*     */     }
/* 103 */     return s;
/*     */   }
/*     */   
/*     */   private static Set<Class<?>> getClasses(Object param) {
/* 107 */     return convertToSet(_getClasses(param));
/*     */   }
/*     */   
/*     */   private static Set<Class<?>> getClasses(String[] elements) {
/* 111 */     return convertToSet(getElements(elements));
/*     */   }
/*     */   
/*     */   private static Set<Class<?>> convertToSet(String[] classes) {
/* 115 */     Set<Class<?>> s = new LinkedHashSet();
/* 116 */     for (String c : classes) {
/*     */       try {
/* 118 */         s.add(getClassLoader().loadClass(c));
/*     */       } catch (ClassNotFoundException e) {
/* 120 */         throw new RuntimeException(e);
/*     */       }
/*     */     }
/* 123 */     return s;
/*     */   }
/*     */   
/*     */   private static String[] _getClasses(Object param) {
/* 127 */     if ((param instanceof String))
/* 128 */       return getElements(new String[] { (String)param }, " ,;");
/* 129 */     if ((param instanceof String[])) {
/* 130 */       return getElements((String[])param, " ,;");
/*     */     }
/* 132 */     throw new IllegalArgumentException("com.sun.jersey.config.property.classnames must have a property value of type String or String[]");
/*     */   }
/*     */   
/*     */ 
/*     */   private static ClassLoader getClassLoader()
/*     */   {
/* 138 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/* 139 */     return classLoader == null ? ClassNamesResourceConfig.class.getClassLoader() : classLoader;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\core\ClassNamesResourceConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */