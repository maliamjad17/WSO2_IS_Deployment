/*     */ package com.sun.jersey.server.impl;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThreadLocalInvoker<T>
/*     */   implements InvocationHandler
/*     */ {
/*  53 */   private ThreadLocal<T> threadLocalInstance = new ThreadLocal();
/*     */   private ThreadLocal<T> immutableThreadLocalInstance;
/*     */   
/*     */   public void set(T threadLocalInstance)
/*     */   {
/*  58 */     this.threadLocalInstance.set(threadLocalInstance);
/*     */   }
/*     */   
/*     */   public T get() {
/*  62 */     return (T)this.threadLocalInstance.get();
/*     */   }
/*     */   
/*     */   public ThreadLocal<T> getThreadLocal() {
/*  66 */     return this.threadLocalInstance;
/*     */   }
/*     */   
/*     */   public ThreadLocal<T> getImmutableThreadLocal() {
/*  70 */     if (this.immutableThreadLocalInstance == null) {
/*  71 */       this.immutableThreadLocalInstance = new ThreadLocal()
/*     */       {
/*     */         public T get() {
/*  74 */           return (T)ThreadLocalInvoker.this.get();
/*     */         }
/*     */         
/*     */         public void remove()
/*     */         {
/*  79 */           throw new IllegalStateException();
/*     */         }
/*     */         
/*     */         public void set(T t)
/*     */         {
/*  84 */           throw new IllegalStateException();
/*     */         }
/*     */       };
/*     */     }
/*  88 */     return this.immutableThreadLocalInstance;
/*     */   }
/*     */   
/*     */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*  92 */     if (this.threadLocalInstance.get() == null) {
/*  93 */       throw new IllegalStateException("No thread local value in scope for proxy of " + proxy.getClass());
/*     */     }
/*     */     try {
/*  96 */       return method.invoke(this.threadLocalInstance.get(), args);
/*     */     } catch (IllegalAccessException ex) {
/*  98 */       throw new IllegalStateException(ex);
/*     */     } catch (InvocationTargetException ex) {
/* 100 */       throw ex.getTargetException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\ThreadLocalInvoker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */