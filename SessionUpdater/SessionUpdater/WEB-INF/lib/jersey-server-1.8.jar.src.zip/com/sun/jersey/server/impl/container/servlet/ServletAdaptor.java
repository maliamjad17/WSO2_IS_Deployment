/*     */ package com.sun.jersey.server.impl.container.servlet;
/*     */ 
/*     */ import com.sun.jersey.api.container.ContainerException;
/*     */ import com.sun.jersey.api.core.ResourceConfig;
/*     */ import com.sun.jersey.core.spi.component.ComponentContext;
/*     */ import com.sun.jersey.core.spi.component.ComponentScope;
/*     */ import com.sun.jersey.server.impl.ThreadLocalNamedInvoker;
/*     */ import com.sun.jersey.spi.container.WebApplication;
/*     */ import com.sun.jersey.spi.container.servlet.ServletContainer;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import com.sun.jersey.spi.inject.InjectableProvider;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.persistence.EntityManagerFactory;
/*     */ import javax.persistence.PersistenceUnit;
/*     */ import javax.servlet.ServletConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletAdaptor
/*     */   extends ServletContainer
/*     */ {
/*  88 */   private Map<String, String> persistenceUnits = new HashMap();
/*     */   
/*     */ 
/*     */   protected void configure(ServletConfig servletConfig, ResourceConfig rc, WebApplication wa)
/*     */   {
/*  93 */     super.configure(servletConfig, rc, wa);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  98 */     for (Enumeration e = servletConfig.getInitParameterNames(); e.hasMoreElements();) {
/*  99 */       String key = (String)e.nextElement();
/* 100 */       String value = servletConfig.getInitParameter(key);
/* 101 */       if (key.startsWith("unit:")) {
/* 102 */         this.persistenceUnits.put(key.substring(5), "java:comp/env/" + value);
/*     */       }
/*     */     }
/*     */     
/* 106 */     rc.getSingletons().add(new InjectableProvider()
/*     */     {
/*     */       public ComponentScope getScope() {
/* 109 */         return ComponentScope.Singleton;
/*     */       }
/*     */       
/*     */       public Injectable<EntityManagerFactory> getInjectable(ComponentContext ic, PersistenceUnit pu, Type c)
/*     */       {
/* 114 */         if (!c.equals(EntityManagerFactory.class)) {
/* 115 */           return null;
/*     */         }
/*     */         
/* 118 */         if (!ServletAdaptor.this.persistenceUnits.containsKey(pu.unitName())) {
/* 119 */           throw new ContainerException("Persistence unit '" + pu.unitName() + "' is not configured as a servlet parameter in web.xml");
/*     */         }
/*     */         
/* 122 */         String jndiName = (String)ServletAdaptor.this.persistenceUnits.get(pu.unitName());
/* 123 */         ThreadLocalNamedInvoker<EntityManagerFactory> emfHandler = new ThreadLocalNamedInvoker(jndiName);
/*     */         
/* 125 */         final EntityManagerFactory emf = (EntityManagerFactory)Proxy.newProxyInstance(getClass().getClassLoader(), new Class[] { EntityManagerFactory.class }, emfHandler);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 130 */         new Injectable()
/*     */         {
/*     */           public EntityManagerFactory getValue() {
/* 133 */             return emf;
/*     */           }
/*     */         };
/*     */       }
/*     */     });
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\container\servlet\ServletAdaptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */