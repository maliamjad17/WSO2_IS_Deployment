/*    */ package com.sun.jersey.api;
/*    */ 
/*    */ import com.sun.jersey.core.spi.factory.ResponseImpl;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JResponseAsResponse
/*    */   extends ResponseImpl
/*    */ {
/*    */   private final JResponse<?> jr;
/*    */   
/*    */   JResponseAsResponse(JResponse<?> jr)
/*    */   {
/* 56 */     this(jr, jr.getType());
/*    */   }
/*    */   
/*    */   JResponseAsResponse(JResponse<?> jr, Type type) {
/* 60 */     super(jr.getStatusType(), jr.getMetadata(), jr.getEntity(), type);
/* 61 */     this.jr = jr;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public JResponse<?> getJResponse()
/*    */   {
/* 70 */     return this.jr;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\JResponseAsResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */