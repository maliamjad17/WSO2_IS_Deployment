package com.sun.jersey.spi.container;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public abstract interface JavaMethodInvoker
{
  public abstract Object invoke(Method paramMethod, Object paramObject, Object... paramVarArgs)
    throws InvocationTargetException, IllegalAccessException;
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\container\JavaMethodInvoker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */