/*     */ package com.sun.jersey.server.impl.uri.rules;
/*     */ 
/*     */ import com.sun.jersey.api.container.ContainerException;
/*     */ import com.sun.jersey.api.container.MappableContainerException;
/*     */ import com.sun.jersey.api.core.ExtendedUriInfo;
/*     */ import com.sun.jersey.api.model.AbstractSubResourceLocator;
/*     */ import com.sun.jersey.api.uri.UriTemplate;
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*     */ import com.sun.jersey.server.impl.inject.AbstractHttpContextInjectable;
/*     */ import com.sun.jersey.server.probes.UriRuleProbeProvider;
/*     */ import com.sun.jersey.spi.container.ContainerRequest;
/*     */ import com.sun.jersey.spi.container.ContainerRequestFilter;
/*     */ import com.sun.jersey.spi.container.ContainerResponseFilter;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import com.sun.jersey.spi.monitoring.DispatchingListener;
/*     */ import com.sun.jersey.spi.uri.rules.UriRule;
/*     */ import com.sun.jersey.spi.uri.rules.UriRuleContext;
/*     */ import com.sun.jersey.spi.uri.rules.UriRules;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.ws.rs.WebApplicationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SubLocatorRule
/*     */   extends BaseRule
/*     */ {
/*     */   private final List<AbstractHttpContextInjectable> is;
/*     */   private final Method m;
/*     */   private final List<ContainerRequestFilter> requestFilters;
/*     */   private final List<ContainerResponseFilter> responseFilters;
/*     */   private final DispatchingListener dispatchingListener;
/*     */   private final AbstractSubResourceLocator locator;
/*     */   
/*     */   public SubLocatorRule(UriTemplate template, List<Injectable> is, List<ContainerRequestFilter> requestFilters, List<ContainerResponseFilter> responseFilters, DispatchingListener dispatchingListener, AbstractSubResourceLocator locator)
/*     */   {
/*  89 */     super(template);
/*  90 */     this.is = AbstractHttpContextInjectable.transform(is);
/*  91 */     this.requestFilters = requestFilters;
/*  92 */     this.responseFilters = responseFilters;
/*  93 */     this.dispatchingListener = dispatchingListener;
/*  94 */     this.locator = locator;
/*  95 */     this.m = locator.getMethod();
/*     */   }
/*     */   
/*     */   public boolean accept(CharSequence path, Object resource, UriRuleContext context)
/*     */   {
/* 100 */     UriRuleProbeProvider.ruleAccept(SubLocatorRule.class.getSimpleName(), path, resource);
/*     */     
/*     */ 
/*     */ 
/* 104 */     pushMatch(context);
/*     */     
/*     */ 
/* 107 */     Object subResource = invokeSubLocator(resource, context);
/*     */     
/* 109 */     if (subResource == null) {
/* 110 */       if (context.isTracingEnabled()) {
/* 111 */         trace(resource, subResource, context);
/*     */       }
/* 113 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 117 */     if ((subResource instanceof Class))
/*     */     {
/* 119 */       subResource = context.getResource((Class)subResource);
/*     */     }
/*     */     
/* 122 */     this.dispatchingListener.onSubResource(Thread.currentThread().getId(), subResource.getClass());
/*     */     
/* 124 */     context.pushResource(subResource);
/*     */     
/* 126 */     if (context.isTracingEnabled()) {
/* 127 */       trace(resource, subResource, context);
/*     */     }
/*     */     
/*     */ 
/* 131 */     Iterator<UriRule> matches = context.getRules(subResource.getClass()).match(path, context);
/*     */     
/* 133 */     while (matches.hasNext()) {
/* 134 */       if (((UriRule)matches.next()).accept(path, subResource, context))
/* 135 */         return true;
/*     */     }
/* 137 */     return false;
/*     */   }
/*     */   
/*     */   private void trace(Object resource, Object subResource, UriRuleContext context) {
/* 141 */     String prevPath = (String)context.getUriInfo().getMatchedURIs().get(1);
/* 142 */     String currentPath = (String)context.getUriInfo().getMatchedURIs().get(0);
/*     */     
/* 144 */     context.trace(String.format("accept sub-resource locator: \"%s\" : \"%s\" -> @Path(\"%s\") %s = %s", new Object[] { prevPath, currentPath.substring(prevPath.length()), getTemplate().getTemplate(), ReflectionHelper.methodInstanceToString(resource, this.m), subResource }));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object invokeSubLocator(Object resource, UriRuleContext context)
/*     */   {
/* 156 */     context.pushContainerResponseFilters(this.responseFilters);
/*     */     
/*     */     ContainerRequest containerRequest;
/* 159 */     if (!this.requestFilters.isEmpty()) {
/* 160 */       containerRequest = context.getContainerRequest();
/* 161 */       for (ContainerRequestFilter f : this.requestFilters) {
/* 162 */         containerRequest = f.filter(containerRequest);
/* 163 */         context.setContainerRequest(containerRequest);
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 169 */       if (this.is.isEmpty()) {
/* 170 */         this.dispatchingListener.onSubResourceLocator(Thread.currentThread().getId(), this.locator);
/* 171 */         return this.m.invoke(resource, new Object[0]);
/*     */       }
/* 173 */       Object[] params = new Object[this.is.size()];
/* 174 */       int index = 0;
/* 175 */       for (AbstractHttpContextInjectable i : this.is) {
/* 176 */         params[(index++)] = i.getValue(context);
/*     */       }
/*     */       
/* 179 */       this.dispatchingListener.onSubResourceLocator(Thread.currentThread().getId(), this.locator);
/* 180 */       return this.m.invoke(resource, params);
/*     */     }
/*     */     catch (InvocationTargetException e)
/*     */     {
/* 184 */       throw new MappableContainerException(e.getTargetException());
/*     */     } catch (IllegalAccessException e) {
/* 186 */       throw new ContainerException(e);
/*     */     } catch (WebApplicationException e) {
/* 188 */       throw e;
/*     */     } catch (RuntimeException e) {
/* 190 */       throw new ContainerException("Exception injecting parameters for sub-locator method: " + this.m, e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\uri\rules\SubLocatorRule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */