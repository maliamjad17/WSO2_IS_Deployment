/*    */ package com.sun.jersey.server.impl.model.method.dispatch;
/*    */ 
/*    */ import com.sun.jersey.api.container.ContainerException;
/*    */ import com.sun.jersey.api.container.MappableContainerException;
/*    */ import com.sun.jersey.api.core.HttpContext;
/*    */ import com.sun.jersey.api.core.HttpResponseContext;
/*    */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*    */ import com.sun.jersey.spi.container.JavaMethodInvoker;
/*    */ import com.sun.jersey.spi.dispatch.RequestDispatcher;
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ResourceJavaMethodDispatcher
/*    */   implements RequestDispatcher
/*    */ {
/*    */   protected final JavaMethodInvoker invoker;
/*    */   protected final Method method;
/*    */   private final Annotation[] annotations;
/*    */   
/*    */   public ResourceJavaMethodDispatcher(AbstractResourceMethod abstractResourceMethod, JavaMethodInvoker invoker)
/*    */   {
/* 66 */     this.method = abstractResourceMethod.getMethod();
/* 67 */     this.annotations = abstractResourceMethod.getAnnotations();
/* 68 */     this.invoker = invoker;
/*    */   }
/*    */   
/*    */   public final void dispatch(Object resource, HttpContext context)
/*    */   {
/*    */     try
/*    */     {
/* 75 */       _dispatch(resource, context);
/*    */       
/*    */ 
/* 78 */       if (context.getResponse().getEntity() != null) {
/* 79 */         context.getResponse().setAnnotations(this.annotations);
/*    */       }
/*    */     } catch (InvocationTargetException e) {
/* 82 */       throw new MappableContainerException(e.getTargetException());
/*    */     } catch (IllegalAccessException e) {
/* 84 */       throw new ContainerException(e);
/*    */     }
/*    */   }
/*    */   
/*    */   protected abstract void _dispatch(Object paramObject, HttpContext paramHttpContext) throws InvocationTargetException, IllegalAccessException;
/*    */   
/*    */   public String toString()
/*    */   {
/* 92 */     return this.method.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\method\dispatch\ResourceJavaMethodDispatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */