/*     */ package com.sun.jersey.server.impl.cdi;
/*     */ 
/*     */ import com.sun.jersey.api.core.ExtendedUriInfo;
/*     */ import com.sun.jersey.api.core.HttpContext;
/*     */ import com.sun.jersey.api.core.HttpRequestContext;
/*     */ import com.sun.jersey.api.core.HttpResponseContext;
/*     */ import com.sun.jersey.api.core.ResourceConfig;
/*     */ import com.sun.jersey.api.core.ResourceContext;
/*     */ import com.sun.jersey.api.model.Parameter;
/*     */ import com.sun.jersey.api.model.Parameter.Source;
/*     */ import com.sun.jersey.core.spi.component.ComponentScope;
/*     */ import com.sun.jersey.core.util.FeaturesAndProperties;
/*     */ import com.sun.jersey.server.impl.InitialContextHelper;
/*     */ import com.sun.jersey.server.impl.inject.AbstractHttpContextInjectable;
/*     */ import com.sun.jersey.server.impl.inject.ServerInjectableProviderFactory;
/*     */ import com.sun.jersey.spi.MessageBodyWorkers;
/*     */ import com.sun.jersey.spi.container.ExceptionMapperContext;
/*     */ import com.sun.jersey.spi.container.WebApplication;
/*     */ import com.sun.jersey.spi.inject.Errors;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Logger;
/*     */ import javax.enterprise.context.spi.CreationalContext;
/*     */ import javax.enterprise.event.Observes;
/*     */ import javax.enterprise.inject.spi.AfterBeanDiscovery;
/*     */ import javax.enterprise.inject.spi.AnnotatedCallable;
/*     */ import javax.enterprise.inject.spi.AnnotatedConstructor;
/*     */ import javax.enterprise.inject.spi.AnnotatedField;
/*     */ import javax.enterprise.inject.spi.AnnotatedMethod;
/*     */ import javax.enterprise.inject.spi.AnnotatedParameter;
/*     */ import javax.enterprise.inject.spi.AnnotatedType;
/*     */ import javax.enterprise.inject.spi.Bean;
/*     */ import javax.enterprise.inject.spi.BeanManager;
/*     */ import javax.enterprise.inject.spi.BeforeBeanDiscovery;
/*     */ import javax.enterprise.inject.spi.Extension;
/*     */ import javax.enterprise.inject.spi.InjectionPoint;
/*     */ import javax.enterprise.inject.spi.ProcessAnnotatedType;
/*     */ import javax.enterprise.inject.spi.ProcessInjectionTarget;
/*     */ import javax.enterprise.inject.spi.ProcessManagedBean;
/*     */ import javax.enterprise.util.AnnotationLiteral;
/*     */ import javax.inject.Inject;
/*     */ import javax.inject.Provider;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.Name;
/*     */ import javax.naming.NameParser;
/*     */ import javax.naming.NamingException;
/*     */ import javax.ws.rs.CookieParam;
/*     */ import javax.ws.rs.DefaultValue;
/*     */ import javax.ws.rs.Encoded;
/*     */ import javax.ws.rs.FormParam;
/*     */ import javax.ws.rs.HeaderParam;
/*     */ import javax.ws.rs.MatrixParam;
/*     */ import javax.ws.rs.PathParam;
/*     */ import javax.ws.rs.QueryParam;
/*     */ import javax.ws.rs.core.Application;
/*     */ import javax.ws.rs.core.HttpHeaders;
/*     */ import javax.ws.rs.core.Request;
/*     */ import javax.ws.rs.core.SecurityContext;
/*     */ import javax.ws.rs.core.UriInfo;
/*     */ import javax.ws.rs.ext.Providers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CDIExtension
/*     */   implements Extension
/*     */ {
/*     */   private static class ContextAnnotationLiteral
/*     */     extends AnnotationLiteral<javax.ws.rs.core.Context>
/*     */     implements javax.ws.rs.core.Context
/*     */   {}
/*     */   
/* 119 */   private static final Logger LOGGER = Logger.getLogger(CDIExtension.class.getName());
/*     */   
/*     */ 
/* 122 */   private final javax.ws.rs.core.Context contextAnnotationLiteral = new ContextAnnotationLiteral(null);
/*     */   
/*     */ 
/* 125 */   private final Inject injectAnnotationLiteral = new InjectAnnotationLiteral(null);
/*     */   
/*     */   private static class InjectAnnotationLiteral extends AnnotationLiteral<Inject> implements Inject
/*     */   {}
/*     */   
/*     */   private static class SyntheticQualifierAnnotationImpl extends AnnotationLiteral<SyntheticQualifier> implements SyntheticQualifier {
/* 131 */     public SyntheticQualifierAnnotationImpl(int value) { this.value = value; }
/*     */     
/*     */ 
/*     */ 
/* 135 */     public int value() { return this.value; }
/*     */     
/*     */     private int value;
/*     */   }
/*     */   
/*     */   private WebApplication webApplication;
/*     */   private ResourceConfig resourceConfig;
/*     */   private Set<Class<? extends Annotation>> knownParameterQualifiers;
/*     */   private Set<Class<?>> staticallyDefinedContextBeans;
/*     */   private Map<Class<? extends Annotation>, Parameter.Source> paramQualifiersMap;
/*     */   private Map<Class<? extends Annotation>, Set<DiscoveredParameter>> discoveredParameterMap;
/*     */   private Map<DiscoveredParameter, SyntheticQualifier> syntheticQualifierMap;
/* 147 */   private int nextSyntheticQualifierValue = 0;
/*     */   
/*     */   private List<InitializedLater> toBeInitializedLater;
/*     */   
/* 151 */   private static String JNDI_CDIEXTENSION_NAME = "CDIExtension";
/* 152 */   private static String JNDI_CDIEXTENSION_CTX = "com/sun/jersey/config";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String LOOKUP_EXTENSION_IN_BEAN_MANAGER_SYSTEM_PROPERTY = "com.sun.jersey.server.impl.cdi.lookupExtensionInBeanManager";
/*     */   
/*     */ 
/*     */ 
/* 160 */   public static final boolean lookupExtensionInBeanManager = getLookupExtensionInBeanManager();
/*     */   
/*     */   private static boolean getLookupExtensionInBeanManager() {
/* 163 */     return Boolean.parseBoolean(System.getProperty("com.sun.jersey.server.impl.cdi.lookupExtensionInBeanManager", "false"));
/*     */   }
/*     */   
/*     */ 
/*     */   public static CDIExtension getInitializedExtension()
/*     */   {
/*     */     try
/*     */     {
/* 171 */       InitialContext ic = InitialContextHelper.getInitialContext();
/* 172 */       if (ic == null) {
/* 173 */         throw new RuntimeException();
/*     */       }
/* 175 */       return (CDIExtension)lookupJerseyConfigJNDIContext(ic).lookup(JNDI_CDIEXTENSION_NAME);
/*     */     } catch (NamingException ex) {
/* 177 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initialize(BeanManager manager)
/*     */   {
/* 188 */     if (!lookupExtensionInBeanManager) {
/*     */       try {
/* 190 */         InitialContext ic = InitialContextHelper.getInitialContext();
/* 191 */         if (ic != null) {
/* 192 */           javax.naming.Context jerseyConfigJNDIContext = createJerseyConfigJNDIContext(ic);
/* 193 */           jerseyConfigJNDIContext.rebind(JNDI_CDIEXTENSION_NAME, this);
/*     */         }
/*     */       } catch (NamingException ex) {
/* 196 */         throw new RuntimeException(ex);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 201 */     Set<Class<? extends Annotation>> set = new HashSet();
/* 202 */     set.add(CookieParam.class);
/* 203 */     set.add(FormParam.class);
/* 204 */     set.add(HeaderParam.class);
/* 205 */     set.add(MatrixParam.class);
/* 206 */     set.add(PathParam.class);
/* 207 */     set.add(QueryParam.class);
/* 208 */     set.add(javax.ws.rs.core.Context.class);
/* 209 */     this.knownParameterQualifiers = Collections.unmodifiableSet(set);
/*     */     
/*     */ 
/* 212 */     Map<Class<? extends Annotation>, Parameter.Source> map = new HashMap();
/* 213 */     map.put(CookieParam.class, Parameter.Source.COOKIE);
/* 214 */     map.put(FormParam.class, Parameter.Source.FORM);
/* 215 */     map.put(HeaderParam.class, Parameter.Source.HEADER);
/* 216 */     map.put(MatrixParam.class, Parameter.Source.MATRIX);
/* 217 */     map.put(PathParam.class, Parameter.Source.PATH);
/* 218 */     map.put(QueryParam.class, Parameter.Source.QUERY);
/* 219 */     map.put(javax.ws.rs.core.Context.class, Parameter.Source.CONTEXT);
/* 220 */     this.paramQualifiersMap = Collections.unmodifiableMap(map);
/*     */     
/*     */ 
/* 223 */     Set<Class<?>> set3 = new HashSet();
/*     */     
/* 225 */     set3.add(Application.class);
/* 226 */     set3.add(HttpHeaders.class);
/* 227 */     set3.add(Providers.class);
/* 228 */     set3.add(Request.class);
/* 229 */     set3.add(SecurityContext.class);
/* 230 */     set3.add(UriInfo.class);
/*     */     
/* 232 */     set3.add(ExceptionMapperContext.class);
/* 233 */     set3.add(ExtendedUriInfo.class);
/* 234 */     set3.add(FeaturesAndProperties.class);
/* 235 */     set3.add(HttpContext.class);
/* 236 */     set3.add(HttpRequestContext.class);
/* 237 */     set3.add(HttpResponseContext.class);
/* 238 */     set3.add(MessageBodyWorkers.class);
/* 239 */     set3.add(ResourceContext.class);
/* 240 */     set3.add(WebApplication.class);
/* 241 */     this.staticallyDefinedContextBeans = Collections.unmodifiableSet(set3);
/*     */     
/*     */ 
/* 244 */     Map<Class<? extends Annotation>, Set<DiscoveredParameter>> map2 = new HashMap();
/* 245 */     for (Class<? extends Annotation> qualifier : this.knownParameterQualifiers) {
/* 246 */       map2.put(qualifier, new HashSet());
/*     */     }
/* 248 */     this.discoveredParameterMap = Collections.unmodifiableMap(map2);
/*     */     
/*     */ 
/*     */ 
/* 252 */     this.syntheticQualifierMap = new HashMap();
/*     */     
/*     */ 
/*     */ 
/* 256 */     this.toBeInitializedLater = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static javax.naming.Context diveIntoJNDIContext(javax.naming.Context initialContext, JNDIContextDiver diver)
/*     */     throws NamingException
/*     */   {
/* 264 */     Name jerseyConfigCtxName = initialContext.getNameParser("").parse(JNDI_CDIEXTENSION_CTX);
/* 265 */     javax.naming.Context currentContext = initialContext;
/* 266 */     for (int i = 0; i < jerseyConfigCtxName.size(); i++) {
/* 267 */       currentContext = diver.stepInto(currentContext, jerseyConfigCtxName.get(i));
/*     */     }
/* 269 */     return currentContext;
/*     */   }
/*     */   
/*     */   private static javax.naming.Context createJerseyConfigJNDIContext(javax.naming.Context initialContext) throws NamingException {
/* 273 */     diveIntoJNDIContext(initialContext, new JNDIContextDiver()
/*     */     {
/*     */       public javax.naming.Context stepInto(javax.naming.Context ctx, String name) throws NamingException
/*     */       {
/*     */         try {
/* 278 */           return (javax.naming.Context)ctx.lookup(name);
/*     */         } catch (NamingException e) {}
/* 280 */         return ctx.createSubcontext(name);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private static javax.naming.Context lookupJerseyConfigJNDIContext(javax.naming.Context initialContext) throws NamingException
/*     */   {
/* 287 */     diveIntoJNDIContext(initialContext, new JNDIContextDiver()
/*     */     {
/*     */       public javax.naming.Context stepInto(javax.naming.Context ctx, String name) throws NamingException {
/* 290 */         return (javax.naming.Context)ctx.lookup(name);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   void beforeBeanDiscovery(@Observes BeforeBeanDiscovery event, BeanManager manager) {
/* 296 */     LOGGER.fine("Handling BeforeBeanDiscovery event");
/* 297 */     initialize(manager);
/*     */     
/*     */ 
/* 300 */     for (Class<? extends Annotation> qualifier : this.knownParameterQualifiers)
/* 301 */       event.addQualifier(qualifier);
/*     */   }
/*     */   
/*     */   private static abstract interface JNDIContextDiver {
/*     */     public abstract javax.naming.Context stepInto(javax.naming.Context paramContext, String paramString) throws NamingException;
/*     */   }
/*     */   
/*     */   private static class PatchInformation {
/*     */     private DiscoveredParameter parameter;
/*     */     private SyntheticQualifier syntheticQualifier;
/*     */     private Annotation annotation;
/*     */     private boolean mustAddInject;
/*     */     
/*     */     public PatchInformation(DiscoveredParameter parameter, SyntheticQualifier syntheticQualifier, boolean mustAddInject) {
/* 315 */       this(parameter, syntheticQualifier, null, mustAddInject);
/*     */     }
/*     */     
/*     */     public PatchInformation(DiscoveredParameter parameter, SyntheticQualifier syntheticQualifier, Annotation annotation, boolean mustAddInject) {
/* 319 */       this.parameter = parameter;
/* 320 */       this.syntheticQualifier = syntheticQualifier;
/* 321 */       this.annotation = annotation;
/* 322 */       this.mustAddInject = mustAddInject;
/*     */     }
/*     */     
/*     */     public DiscoveredParameter getParameter() {
/* 326 */       return this.parameter;
/*     */     }
/*     */     
/*     */     public SyntheticQualifier getSyntheticQualifier() {
/* 330 */       return this.syntheticQualifier;
/*     */     }
/*     */     
/*     */     public Annotation getAnnotation() {
/* 334 */       return this.annotation;
/*     */     }
/*     */     
/*     */     public boolean mustAddInject() {
/* 338 */       return this.mustAddInject;
/*     */     }
/*     */   }
/*     */   
/*     */   <T> void processAnnotatedType(@Observes ProcessAnnotatedType<T> event) {
/* 343 */     LOGGER.fine("Handling ProcessAnnotatedType event for " + event.getAnnotatedType().getJavaClass().getName());
/*     */     
/* 345 */     AnnotatedType<T> type = event.getAnnotatedType();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 367 */     boolean classHasEncodedAnnotation = type.isAnnotationPresent(Encoded.class);
/*     */     
/* 369 */     Set<AnnotatedConstructor<T>> mustPatchConstructors = new HashSet();
/* 370 */     Map<AnnotatedParameter<? super T>, PatchInformation> parameterToPatchInfoMap = new HashMap();
/*     */     
/* 372 */     for (AnnotatedConstructor<T> constructor : type.getConstructors()) {
/* 373 */       if (processAnnotatedConstructor(constructor, classHasEncodedAnnotation, parameterToPatchInfoMap)) {
/* 374 */         mustPatchConstructors.add(constructor);
/*     */       }
/*     */     }
/*     */     
/* 378 */     Set<AnnotatedField<? super T>> mustPatchFields = new HashSet();
/* 379 */     Map<AnnotatedField<? super T>, PatchInformation> fieldToPatchInfoMap = new HashMap();
/*     */     
/* 381 */     for (AnnotatedField<? super T> field : type.getFields()) {
/* 382 */       if (processAnnotatedField(field, type.getJavaClass(), classHasEncodedAnnotation, fieldToPatchInfoMap)) {
/* 383 */         mustPatchFields.add(field);
/*     */       }
/*     */     }
/*     */     
/* 387 */     Set<AnnotatedMethod<? super T>> mustPatchMethods = new HashSet();
/* 388 */     Set<AnnotatedMethod<? super T>> setterMethodsWithoutInject = new HashSet();
/*     */     
/* 390 */     for (AnnotatedMethod<? super T> method : type.getMethods()) {
/* 391 */       if (processAnnotatedMethod(method, type.getJavaClass(), classHasEncodedAnnotation, parameterToPatchInfoMap, setterMethodsWithoutInject)) {
/* 392 */         mustPatchMethods.add(method);
/*     */       }
/*     */     }
/*     */     
/* 396 */     boolean typeNeedsPatching = (!mustPatchConstructors.isEmpty()) || (!mustPatchFields.isEmpty()) || (!mustPatchMethods.isEmpty());
/*     */     
/*     */ 
/* 399 */     if (typeNeedsPatching) {
/* 400 */       AnnotatedTypeImpl<T> newType = new AnnotatedTypeImpl(type);
/*     */       
/* 402 */       Set<AnnotatedConstructor<T>> newConstructors = new HashSet();
/* 403 */       for (AnnotatedConstructor<T> constructor : type.getConstructors()) {
/* 404 */         AnnotatedConstructorImpl<T> newConstructor = new AnnotatedConstructorImpl(constructor, newType);
/* 405 */         if (mustPatchConstructors.contains(constructor)) {
/* 406 */           patchAnnotatedCallable(constructor, newConstructor, parameterToPatchInfoMap);
/*     */         }
/*     */         else {
/* 409 */           copyParametersOfAnnotatedCallable(constructor, newConstructor);
/*     */         }
/* 411 */         newConstructors.add(newConstructor);
/*     */       }
/*     */       
/* 414 */       Set<AnnotatedField<? super T>> newFields = new HashSet();
/* 415 */       for (AnnotatedField<? super T> field : type.getFields()) {
/* 416 */         if (mustPatchFields.contains(field)) {
/* 417 */           PatchInformation patchInfo = (PatchInformation)fieldToPatchInfoMap.get(field);
/* 418 */           Set<Annotation> annotations = new HashSet();
/* 419 */           if (patchInfo.mustAddInject())
/* 420 */             annotations.add(this.injectAnnotationLiteral);
/*     */           Annotation skippedQualifier;
/* 422 */           if (patchInfo.getSyntheticQualifier() != null) {
/* 423 */             annotations.add(patchInfo.getSyntheticQualifier());
/* 424 */             skippedQualifier = patchInfo.getParameter().getAnnotation();
/* 425 */             for (Annotation annotation : field.getAnnotations()) {
/* 426 */               if (annotation != skippedQualifier) {
/* 427 */                 annotations.add(annotation);
/*     */               }
/*     */             }
/*     */           }
/*     */           else {
/* 432 */             annotations.addAll(field.getAnnotations());
/*     */           }
/* 434 */           if (patchInfo.getAnnotation() != null) {
/* 435 */             annotations.add(patchInfo.getAnnotation());
/*     */           }
/* 437 */           newFields.add(new AnnotatedFieldImpl(field, annotations, newType));
/*     */         }
/*     */         else
/*     */         {
/* 441 */           newFields.add(new AnnotatedFieldImpl(field, newType));
/*     */         }
/*     */       }
/*     */       
/* 445 */       Set<AnnotatedMethod<? super T>> newMethods = new HashSet();
/* 446 */       for (AnnotatedMethod<? super T> method : type.getMethods()) {
/* 447 */         if (mustPatchMethods.contains(method)) {
/* 448 */           if (setterMethodsWithoutInject.contains(method)) {
/* 449 */             Set<Annotation> annotations = new HashSet();
/* 450 */             annotations.add(this.injectAnnotationLiteral);
/* 451 */             for (Annotation annotation : method.getAnnotations()) {
/* 452 */               if (!this.knownParameterQualifiers.contains(annotation.annotationType())) {
/* 453 */                 annotations.add(annotation);
/*     */               }
/*     */             }
/* 456 */             AnnotatedMethodImpl<T> newMethod = new AnnotatedMethodImpl(method, annotations, newType);
/* 457 */             patchAnnotatedCallable(method, newMethod, parameterToPatchInfoMap);
/* 458 */             newMethods.add(newMethod);
/*     */           }
/*     */           else {
/* 461 */             AnnotatedMethodImpl<T> newMethod = new AnnotatedMethodImpl(method, newType);
/* 462 */             patchAnnotatedCallable(method, newMethod, parameterToPatchInfoMap);
/* 463 */             newMethods.add(newMethod);
/*     */           }
/*     */         }
/*     */         else {
/* 467 */           AnnotatedMethodImpl<T> newMethod = new AnnotatedMethodImpl(method, newType);
/* 468 */           copyParametersOfAnnotatedCallable(method, newMethod);
/* 469 */           newMethods.add(newMethod);
/*     */         }
/*     */       }
/*     */       
/* 473 */       newType.setConstructors(newConstructors);
/* 474 */       newType.setFields(newFields);
/* 475 */       newType.setMethods(newMethods);
/* 476 */       event.setAnnotatedType(newType);
/*     */       
/* 478 */       LOGGER.fine("  replaced annotated type for " + type.getJavaClass());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private <T> boolean processAnnotatedConstructor(AnnotatedConstructor<T> constructor, boolean classHasEncodedAnnotation, Map<AnnotatedParameter<? super T>, PatchInformation> parameterToPatchInfoMap)
/*     */   {
/* 485 */     boolean mustPatch = false;
/*     */     boolean methodHasEncodedAnnotation;
/* 487 */     Iterator i$; if (constructor.getAnnotation(Inject.class) != null) {
/* 488 */       methodHasEncodedAnnotation = constructor.isAnnotationPresent(Encoded.class);
/* 489 */       for (i$ = constructor.getParameters().iterator(); i$.hasNext();) { parameter = (AnnotatedParameter)i$.next();
/* 490 */         for (Annotation annotation : parameter.getAnnotations()) {
/* 491 */           Set<DiscoveredParameter> discovered = (Set)this.discoveredParameterMap.get(annotation.annotationType());
/* 492 */           if ((discovered != null) && 
/* 493 */             (this.knownParameterQualifiers.contains(annotation.annotationType()))) {
/* 494 */             if ((methodHasEncodedAnnotation) || (classHasEncodedAnnotation) || (parameter.isAnnotationPresent(DefaultValue.class)))
/*     */             {
/*     */ 
/* 497 */               mustPatch = true;
/*     */             }
/*     */             
/* 500 */             boolean encoded = (parameter.isAnnotationPresent(Encoded.class)) || (methodHasEncodedAnnotation) || (classHasEncodedAnnotation);
/* 501 */             DefaultValue defaultValue = (DefaultValue)parameter.getAnnotation(DefaultValue.class);
/* 502 */             if (defaultValue != null) {
/* 503 */               mustPatch = true;
/*     */             }
/* 505 */             DiscoveredParameter jerseyParameter = new DiscoveredParameter(annotation, parameter.getBaseType(), defaultValue, encoded);
/* 506 */             discovered.add(jerseyParameter);
/* 507 */             LOGGER.fine("  recorded " + jerseyParameter);
/* 508 */             parameterToPatchInfoMap.put(parameter, new PatchInformation(jerseyParameter, getSyntheticQualifierFor(jerseyParameter), false));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     AnnotatedParameter<T> parameter;
/* 515 */     return mustPatch;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private <T> boolean processAnnotatedMethod(AnnotatedMethod<? super T> method, Class<T> token, boolean classHasEncodedAnnotation, Map<AnnotatedParameter<? super T>, PatchInformation> parameterToPatchInfoMap, Set<AnnotatedMethod<? super T>> setterMethodsWithoutInject)
/*     */   {
/* 523 */     boolean mustPatch = false;
/*     */     boolean methodHasEncodedAnnotation;
/* 525 */     Iterator i$; AnnotatedParameter<? super T> parameter; boolean methodHasEncodedAnnotation; if (method.getAnnotation(Inject.class) != null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 530 */       methodHasEncodedAnnotation = method.isAnnotationPresent(Encoded.class);
/* 531 */       for (i$ = method.getParameters().iterator(); i$.hasNext();) { parameter = (AnnotatedParameter)i$.next();
/* 532 */         for (Annotation annotation : parameter.getAnnotations()) {
/* 533 */           Set<DiscoveredParameter> discovered = (Set)this.discoveredParameterMap.get(annotation.annotationType());
/* 534 */           if ((discovered != null) && 
/* 535 */             (this.knownParameterQualifiers.contains(annotation.annotationType()))) {
/* 536 */             if ((methodHasEncodedAnnotation) || (classHasEncodedAnnotation) || (parameter.isAnnotationPresent(DefaultValue.class)))
/*     */             {
/*     */ 
/* 539 */               mustPatch = true;
/*     */             }
/*     */             
/* 542 */             boolean encoded = (parameter.isAnnotationPresent(Encoded.class)) || (methodHasEncodedAnnotation) || (classHasEncodedAnnotation);
/* 543 */             DefaultValue defaultValue = (DefaultValue)parameter.getAnnotation(DefaultValue.class);
/* 544 */             if (defaultValue != null) {
/* 545 */               mustPatch = true;
/*     */             }
/* 547 */             DiscoveredParameter jerseyParameter = new DiscoveredParameter(annotation, parameter.getBaseType(), defaultValue, encoded);
/* 548 */             discovered.add(jerseyParameter);
/* 549 */             LOGGER.fine("  recorded " + jerseyParameter);
/* 550 */             parameterToPatchInfoMap.put(parameter, new PatchInformation(jerseyParameter, getSyntheticQualifierFor(jerseyParameter), false));
/*     */ 
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */ 
/*     */     }
/* 560 */     else if (isSetterMethod(method)) {
/* 561 */       methodHasEncodedAnnotation = method.isAnnotationPresent(Encoded.class);
/* 562 */       for (Annotation annotation : method.getAnnotations()) {
/* 563 */         Set<DiscoveredParameter> discovered = (Set)this.discoveredParameterMap.get(annotation.annotationType());
/* 564 */         if ((discovered != null) && 
/* 565 */           (this.knownParameterQualifiers.contains(annotation.annotationType()))) {
/* 566 */           mustPatch = true;
/* 567 */           setterMethodsWithoutInject.add(method);
/* 568 */           for (AnnotatedParameter<? super T> parameter : method.getParameters()) {
/* 569 */             boolean encoded = (parameter.isAnnotationPresent(Encoded.class)) || (methodHasEncodedAnnotation) || (classHasEncodedAnnotation);
/* 570 */             DefaultValue defaultValue = (DefaultValue)parameter.getAnnotation(DefaultValue.class);
/* 571 */             if (defaultValue == null) {
/* 572 */               defaultValue = (DefaultValue)method.getAnnotation(DefaultValue.class);
/*     */             }
/* 574 */             DiscoveredParameter jerseyParameter = new DiscoveredParameter(annotation, parameter.getBaseType(), defaultValue, encoded);
/* 575 */             discovered.add(jerseyParameter);
/* 576 */             LOGGER.fine("  recorded " + jerseyParameter);
/* 577 */             SyntheticQualifier syntheticQualifier = getSyntheticQualifierFor(jerseyParameter);
/*     */             
/* 579 */             Annotation addedAnnotation = syntheticQualifier == null ? annotation : null;
/* 580 */             parameterToPatchInfoMap.put(parameter, new PatchInformation(jerseyParameter, syntheticQualifier, addedAnnotation, false));
/*     */           }
/* 582 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 589 */     return mustPatch;
/*     */   }
/*     */   
/*     */   private <T> boolean isSetterMethod(AnnotatedMethod<T> method) {
/* 593 */     Method javaMethod = method.getJavaMember();
/* 594 */     if (((javaMethod.getModifiers() & 0x1) != 0) && (javaMethod.getReturnType() == Void.TYPE) && (javaMethod.getName().startsWith("set")))
/*     */     {
/*     */ 
/* 597 */       List<AnnotatedParameter<T>> parameters = method.getParameters();
/* 598 */       if (parameters.size() == 1) {
/* 599 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 603 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private <T> boolean processAnnotatedField(AnnotatedField<? super T> field, Class<T> token, boolean classHasEncodedAnnotation, Map<AnnotatedField<? super T>, PatchInformation> fieldToPatchInfoMap)
/*     */   {
/* 610 */     boolean mustPatch = false;
/* 611 */     for (Annotation annotation : field.getAnnotations()) {
/* 612 */       if (this.knownParameterQualifiers.contains(annotation.annotationType())) {
/* 613 */         boolean mustAddInjectAnnotation = !field.isAnnotationPresent(Inject.class);
/*     */         
/* 615 */         if ((field.isAnnotationPresent(Encoded.class)) || (classHasEncodedAnnotation) || (mustAddInjectAnnotation) || (field.isAnnotationPresent(DefaultValue.class)))
/*     */         {
/*     */ 
/*     */ 
/* 619 */           mustPatch = true;
/*     */         }
/*     */         
/* 622 */         Set<DiscoveredParameter> discovered = (Set)this.discoveredParameterMap.get(annotation.annotationType());
/* 623 */         if (discovered != null) {
/* 624 */           boolean encoded = (field.isAnnotationPresent(Encoded.class)) || (classHasEncodedAnnotation);
/* 625 */           DefaultValue defaultValue = (DefaultValue)field.getAnnotation(DefaultValue.class);
/* 626 */           DiscoveredParameter parameter = new DiscoveredParameter(annotation, field.getBaseType(), defaultValue, encoded);
/* 627 */           discovered.add(parameter);
/* 628 */           LOGGER.fine("  recorded " + parameter);
/* 629 */           fieldToPatchInfoMap.put(field, new PatchInformation(parameter, getSyntheticQualifierFor(parameter), mustAddInjectAnnotation));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 634 */     return mustPatch;
/*     */   }
/*     */   
/*     */ 
/*     */   private <T> void patchAnnotatedCallable(AnnotatedCallable<? super T> callable, AnnotatedCallableImpl<T> newCallable, Map<AnnotatedParameter<? super T>, PatchInformation> parameterToPatchInfoMap)
/*     */   {
/* 640 */     List<AnnotatedParameter<T>> newParams = new ArrayList();
/* 641 */     for (AnnotatedParameter<? super T> parameter : callable.getParameters()) {
/* 642 */       PatchInformation patchInfo = (PatchInformation)parameterToPatchInfoMap.get(parameter);
/* 643 */       if (patchInfo != null) {
/* 644 */         Set<Annotation> annotations = new HashSet();
/*     */         
/* 646 */         if (patchInfo.mustAddInject()) {
/* 647 */           annotations.add(this.injectAnnotationLiteral);
/*     */         }
/*     */         Annotation skippedQualifier;
/* 650 */         if (patchInfo.getSyntheticQualifier() != null) {
/* 651 */           annotations.add(patchInfo.getSyntheticQualifier());
/* 652 */           skippedQualifier = patchInfo.getParameter().getAnnotation();
/* 653 */           for (Annotation annotation : parameter.getAnnotations()) {
/* 654 */             if (annotation != skippedQualifier) {
/* 655 */               annotations.add(annotation);
/*     */             }
/*     */           }
/*     */         }
/*     */         else {
/* 660 */           annotations.addAll(parameter.getAnnotations());
/*     */         }
/* 662 */         if (patchInfo.getAnnotation() != null) {
/* 663 */           annotations.add(patchInfo.getAnnotation());
/*     */         }
/* 665 */         newParams.add(new AnnotatedParameterImpl(parameter, annotations, newCallable));
/*     */       }
/*     */       else {
/* 668 */         newParams.add(new AnnotatedParameterImpl(parameter, newCallable));
/*     */       }
/*     */     }
/* 671 */     newCallable.setParameters(newParams);
/*     */   }
/*     */   
/*     */   private <T> void copyParametersOfAnnotatedCallable(AnnotatedCallable<? super T> callable, AnnotatedCallableImpl<T> newCallable)
/*     */   {
/* 676 */     List<AnnotatedParameter<T>> newParams = new ArrayList();
/* 677 */     for (AnnotatedParameter<? super T> parameter : callable.getParameters()) {
/* 678 */       newParams.add(new AnnotatedParameterImpl(parameter, newCallable));
/*     */     }
/* 680 */     newCallable.setParameters(newParams);
/*     */   }
/*     */   
/*     */   private SyntheticQualifier getSyntheticQualifierFor(DiscoveredParameter parameter) {
/* 684 */     SyntheticQualifier result = (SyntheticQualifier)this.syntheticQualifierMap.get(parameter);
/* 685 */     if (result == null)
/*     */     {
/*     */ 
/*     */ 
/* 689 */       if ((parameter.isEncoded()) || (parameter.getDefaultValue() != null)) {
/* 690 */         result = new SyntheticQualifierAnnotationImpl(this.nextSyntheticQualifierValue++);
/* 691 */         this.syntheticQualifierMap.put(parameter, result);
/* 692 */         LOGGER.fine("  created synthetic qualifier " + result);
/*     */       }
/*     */     }
/* 695 */     return result;
/*     */   }
/*     */   
/*     */   private static Class getClassOfType(Type type)
/*     */   {
/* 700 */     if ((type instanceof Class))
/* 701 */       return (Class)type;
/* 702 */     if ((type instanceof GenericArrayType)) {
/* 703 */       GenericArrayType arrayType = (GenericArrayType)type;
/* 704 */       Type t = arrayType.getGenericComponentType();
/* 705 */       if ((t instanceof Class)) {
/* 706 */         Class c = (Class)t;
/*     */         
/*     */         try
/*     */         {
/* 710 */           Object o = Array.newInstance(c, 0);
/* 711 */           return o.getClass();
/*     */         } catch (Exception e) {
/* 713 */           throw new IllegalArgumentException(e);
/*     */         }
/*     */       }
/* 716 */     } else if ((type instanceof ParameterizedType)) {
/* 717 */       ParameterizedType subType = (ParameterizedType)type;
/* 718 */       Type t = subType.getRawType();
/* 719 */       if ((t instanceof Class)) {
/* 720 */         return (Class)t;
/*     */       }
/*     */     }
/* 723 */     return null;
/*     */   }
/*     */   
/*     */   <T> void processInjectionTarget(@Observes ProcessInjectionTarget<T> event) {
/* 727 */     LOGGER.fine("Handling ProcessInjectionTarget event for " + event.getAnnotatedType().getJavaClass().getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void processManagedBean(@Observes ProcessManagedBean<?> event)
/*     */   {
/* 737 */     LOGGER.fine("Handling ProcessManagedBean event for " + event.getBean().getBeanClass().getName());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 742 */     Bean<?> bean = event.getBean();
/* 743 */     for (InjectionPoint injectionPoint : bean.getInjectionPoints()) {
/* 744 */       StringBuilder sb = new StringBuilder();
/* 745 */       sb.append("  found injection point ");
/* 746 */       sb.append(injectionPoint.getType());
/* 747 */       for (Annotation annotation : injectionPoint.getQualifiers()) {
/* 748 */         sb.append(" ");
/* 749 */         sb.append(annotation);
/*     */       }
/* 751 */       LOGGER.fine(sb.toString());
/*     */     }
/*     */   }
/*     */   
/*     */   void afterBeanDiscovery(@Observes AfterBeanDiscovery event) {
/* 756 */     LOGGER.fine("Handling AfterBeanDiscovery event");
/*     */     
/* 758 */     addPredefinedContextBeans(event);
/*     */     
/*     */ 
/*     */ 
/* 762 */     BeanGenerator beanGenerator = new BeanGenerator("com/sun/jersey/server/impl/cdi/generated/Bean");
/*     */     
/* 764 */     for (Map.Entry<Class<? extends Annotation>, Set<DiscoveredParameter>> entry : this.discoveredParameterMap.entrySet()) {
/* 765 */       Class<? extends Annotation> qualifier = (Class)entry.getKey();
/* 766 */       for (DiscoveredParameter parameter : (Set)entry.getValue()) {
/* 767 */         Annotation annotation = parameter.getAnnotation();
/* 768 */         Class<?> klass = getClassOfType(parameter.getType());
/*     */         
/* 770 */         if ((annotation.annotationType() != javax.ws.rs.core.Context.class) || (!this.staticallyDefinedContextBeans.contains(klass)) || (parameter.isEncoded()) || (parameter.getDefaultValue() != null))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 777 */           SyntheticQualifier syntheticQualifier = (SyntheticQualifier)this.syntheticQualifierMap.get(parameter);
/* 778 */           Annotation theQualifier = syntheticQualifier != null ? syntheticQualifier : annotation;
/*     */           
/* 780 */           Set<Annotation> annotations = new HashSet();
/* 781 */           annotations.add(theQualifier);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 791 */           Parameter jerseyParameter = new Parameter(new Annotation[] { annotation }, annotation, (Parameter.Source)this.paramQualifiersMap.get(annotation.annotationType()), parameter.getValue(), parameter.getType(), klass, parameter.isEncoded(), parameter.getDefaultValue() == null ? null : parameter.getDefaultValue().value());
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 800 */           Class<?> beanClass = beanGenerator.createBeanClass();
/* 801 */           ParameterBean bean = new ParameterBean(beanClass, parameter.getType(), annotations, parameter, jerseyParameter);
/* 802 */           this.toBeInitializedLater.add(bean);
/* 803 */           event.addBean(bean);
/* 804 */           LOGGER.fine("Added bean for parameter " + parameter + " and qualifier " + theQualifier);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addPredefinedContextBeans(AfterBeanDiscovery event)
/*     */   {
/* 817 */     event.addBean(new PredefinedBean(Application.class, this.contextAnnotationLiteral));
/*     */     
/*     */ 
/* 820 */     event.addBean(new PredefinedBean(HttpHeaders.class, this.contextAnnotationLiteral));
/*     */     
/*     */ 
/* 823 */     event.addBean(new PredefinedBean(Providers.class, this.contextAnnotationLiteral));
/*     */     
/*     */ 
/* 826 */     event.addBean(new PredefinedBean(Request.class, this.contextAnnotationLiteral));
/*     */     
/*     */ 
/* 829 */     event.addBean(new PredefinedBean(SecurityContext.class, this.contextAnnotationLiteral));
/*     */     
/*     */ 
/* 832 */     event.addBean(new PredefinedBean(UriInfo.class, this.contextAnnotationLiteral));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 837 */     event.addBean(new PredefinedBean(ExceptionMapperContext.class, this.contextAnnotationLiteral));
/*     */     
/*     */ 
/* 840 */     event.addBean(new PredefinedBean(ExtendedUriInfo.class, this.contextAnnotationLiteral));
/*     */     
/*     */ 
/* 843 */     event.addBean(new PredefinedBean(FeaturesAndProperties.class, this.contextAnnotationLiteral));
/*     */     
/*     */ 
/* 846 */     event.addBean(new PredefinedBean(HttpContext.class, this.contextAnnotationLiteral));
/*     */     
/*     */ 
/* 849 */     event.addBean(new PredefinedBean(HttpRequestContext.class, this.contextAnnotationLiteral));
/*     */     
/*     */ 
/* 852 */     event.addBean(new PredefinedBean(HttpResponseContext.class, this.contextAnnotationLiteral));
/*     */     
/*     */ 
/* 855 */     event.addBean(new PredefinedBean(MessageBodyWorkers.class, this.contextAnnotationLiteral));
/*     */     
/*     */ 
/* 858 */     event.addBean(new PredefinedBean(ResourceContext.class, this.contextAnnotationLiteral));
/*     */     
/*     */ 
/* 861 */     event.addBean(new ProviderBasedBean(WebApplication.class, new Provider()
/*     */     {
/* 863 */       public WebApplication get() { return CDIExtension.this.webApplication; } }, this.contextAnnotationLiteral));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void setWebApplication(WebApplication wa)
/*     */   {
/* 870 */     this.webApplication = wa;
/*     */   }
/*     */   
/*     */   WebApplication getWebApplication() {
/* 874 */     return this.webApplication;
/*     */   }
/*     */   
/*     */   void setResourceConfig(ResourceConfig rc) {
/* 878 */     this.resourceConfig = rc;
/*     */   }
/*     */   
/*     */   ResourceConfig getResourceConfig() {
/* 882 */     return this.resourceConfig;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void lateInitialize()
/*     */   {
/*     */     try
/*     */     {
/* 894 */       for (InitializedLater object : this.toBeInitializedLater)
/* 895 */         object.later();
/*     */       InitialContext ic;
/*     */       InitialContext ic;
/*     */       return;
/*     */     } finally {
/* 900 */       if (!lookupExtensionInBeanManager) {
/*     */         try {
/* 902 */           ic = InitialContextHelper.getInitialContext();
/* 903 */           if (ic != null) {
/* 904 */             lookupJerseyConfigJNDIContext(ic).unbind(JNDI_CDIEXTENSION_NAME);
/*     */           }
/*     */         } catch (NamingException ex) {
/* 907 */           throw new RuntimeException(ex);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   class PredefinedBean<T>
/*     */     extends AbstractBean<T>
/*     */   {
/*     */     private Annotation qualifier;
/*     */     
/*     */     public PredefinedBean(Annotation klass)
/*     */     {
/* 921 */       super(qualifier);
/* 922 */       this.qualifier = qualifier;
/*     */     }
/*     */     
/*     */     public T create(CreationalContext<T> creationalContext)
/*     */     {
/* 927 */       Injectable<T> injectable = CDIExtension.this.webApplication.getServerInjectableProviderFactory().getInjectable(this.qualifier.annotationType(), null, this.qualifier, getBeanClass(), ComponentScope.Singleton);
/*     */       
/* 929 */       if (injectable == null) {
/* 930 */         Errors.error("No injectable for " + getBeanClass().getName());
/* 931 */         return null;
/*     */       }
/* 933 */       return (T)injectable.getValue();
/*     */     }
/*     */   }
/*     */   
/*     */   class ParameterBean<T>
/*     */     extends AbstractBean<T>
/*     */     implements InitializedLater
/*     */   {
/*     */     private DiscoveredParameter discoveredParameter;
/*     */     private Parameter parameter;
/*     */     private Injectable<T> injectable;
/* 944 */     private boolean processed = false;
/*     */     
/*     */     public ParameterBean(Type klass, Set<Annotation> type, DiscoveredParameter qualifiers, Parameter discoveredParameter)
/*     */     {
/* 948 */       super(type, qualifiers);
/* 949 */       this.discoveredParameter = discoveredParameter;
/* 950 */       this.parameter = parameter;
/*     */     }
/*     */     
/*     */     public void later() {
/* 954 */       if (this.injectable != null) {
/* 955 */         return;
/*     */       }
/* 957 */       if (this.processed) {
/* 958 */         return;
/*     */       }
/* 960 */       this.processed = true;
/* 961 */       boolean registered = CDIExtension.this.webApplication.getServerInjectableProviderFactory().isParameterTypeRegistered(this.parameter);
/*     */       
/* 963 */       if (!registered) {
/* 964 */         Errors.error("Parameter type not registered " + this.discoveredParameter);
/*     */       }
/*     */       
/* 967 */       this.injectable = CDIExtension.this.webApplication.getServerInjectableProviderFactory().getInjectable(this.parameter, ComponentScope.PerRequest);
/*     */       
/* 969 */       if (this.injectable == null) {
/* 970 */         Errors.error("No injectable for parameter " + this.discoveredParameter);
/*     */       }
/*     */     }
/*     */     
/*     */     public T create(CreationalContext<T> creationalContext)
/*     */     {
/* 976 */       if (this.injectable == null) {
/* 977 */         later();
/* 978 */         if (this.injectable == null) {
/* 979 */           return null;
/*     */         }
/*     */       }
/*     */       try
/*     */       {
/* 984 */         return (T)this.injectable.getValue();
/*     */       } catch (IllegalStateException e) {
/* 986 */         if ((this.injectable instanceof AbstractHttpContextInjectable)) {
/* 987 */           return (T)((AbstractHttpContextInjectable)this.injectable).getValue(CDIExtension.this.webApplication.getThreadLocalHttpContext());
/*     */         }
/*     */         
/* 990 */         throw e;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\cdi\CDIExtension.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */