package com.sun.jersey.api.model;

public abstract interface AbstractModelVisitor
{
  public abstract void visitAbstractResource(AbstractResource paramAbstractResource);
  
  public abstract void visitAbstractField(AbstractField paramAbstractField);
  
  public abstract void visitAbstractSetterMethod(AbstractSetterMethod paramAbstractSetterMethod);
  
  public abstract void visitAbstractResourceMethod(AbstractResourceMethod paramAbstractResourceMethod);
  
  public abstract void visitAbstractSubResourceMethod(AbstractSubResourceMethod paramAbstractSubResourceMethod);
  
  public abstract void visitAbstractSubResourceLocator(AbstractSubResourceLocator paramAbstractSubResourceLocator);
  
  public abstract void visitAbstractResourceConstructor(AbstractResourceConstructor paramAbstractResourceConstructor);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\model\AbstractModelVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */