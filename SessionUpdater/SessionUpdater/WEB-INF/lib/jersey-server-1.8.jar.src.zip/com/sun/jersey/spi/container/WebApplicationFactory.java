/*    */ package com.sun.jersey.spi.container;
/*    */ 
/*    */ import com.sun.jersey.api.container.ContainerException;
/*    */ import com.sun.jersey.spi.service.ServiceFinder;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WebApplicationFactory
/*    */ {
/*    */   public static WebApplication createWebApplication()
/*    */     throws ContainerException
/*    */   {
/* 64 */     Iterator i$ = ServiceFinder.find(WebApplicationProvider.class).iterator(); if (i$.hasNext()) { WebApplicationProvider wap = (WebApplicationProvider)i$.next();
/*    */       
/* 66 */       return wap.createWebApplication();
/*    */     }
/*    */     
/* 69 */     throw new ContainerException("No WebApplication provider is present");
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\container\WebApplicationFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */