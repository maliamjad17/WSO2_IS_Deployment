/*     */ package com.sun.jersey.server.impl.model.parameter;
/*     */ 
/*     */ import com.sun.jersey.api.ParamException.MatrixParamException;
/*     */ import com.sun.jersey.api.core.ExtendedUriInfo;
/*     */ import com.sun.jersey.api.core.HttpContext;
/*     */ import com.sun.jersey.api.model.Parameter;
/*     */ import com.sun.jersey.core.spi.component.ComponentContext;
/*     */ import com.sun.jersey.server.impl.inject.AbstractHttpContextInjectable;
/*     */ import com.sun.jersey.server.impl.model.parameter.multivalued.ExtractorContainerException;
/*     */ import com.sun.jersey.server.impl.model.parameter.multivalued.MultivaluedParameterExtractor;
/*     */ import com.sun.jersey.server.impl.model.parameter.multivalued.MultivaluedParameterExtractorProvider;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import java.util.List;
/*     */ import javax.ws.rs.MatrixParam;
/*     */ import javax.ws.rs.core.PathSegment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MatrixParamInjectableProvider
/*     */   extends BaseParamInjectableProvider<MatrixParam>
/*     */ {
/*     */   private static final class MatrixParamInjectable
/*     */     extends AbstractHttpContextInjectable<Object>
/*     */   {
/*     */     private final MultivaluedParameterExtractor extractor;
/*     */     private final boolean decode;
/*     */     
/*     */     MatrixParamInjectable(MultivaluedParameterExtractor extractor, boolean decode)
/*     */     {
/*  68 */       this.extractor = extractor;
/*  69 */       this.decode = decode;
/*     */     }
/*     */     
/*     */     public Object getValue(HttpContext context)
/*     */     {
/*  74 */       List<PathSegment> l = context.getUriInfo().getPathSegments(this.decode);
/*  75 */       PathSegment p = (PathSegment)l.get(l.size() - 1);
/*     */       try {
/*  77 */         return this.extractor.extract(p.getMatrixParameters());
/*     */       } catch (ExtractorContainerException e) {
/*  79 */         throw new ParamException.MatrixParamException(e.getCause(), this.extractor.getName(), this.extractor.getDefaultStringValue());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public MatrixParamInjectableProvider(MultivaluedParameterExtractorProvider w)
/*     */   {
/*  86 */     super(w);
/*     */   }
/*     */   
/*     */   public Injectable getInjectable(ComponentContext ic, MatrixParam a, Parameter c)
/*     */   {
/*  91 */     String parameterName = c.getSourceName();
/*  92 */     if ((parameterName == null) || (parameterName.length() == 0))
/*     */     {
/*  94 */       return null;
/*     */     }
/*     */     
/*  97 */     MultivaluedParameterExtractor e = get(c);
/*  98 */     if (e == null) {
/*  99 */       return null;
/*     */     }
/* 101 */     return new MatrixParamInjectable(e, !c.isEncoded());
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\parameter\MatrixParamInjectableProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */