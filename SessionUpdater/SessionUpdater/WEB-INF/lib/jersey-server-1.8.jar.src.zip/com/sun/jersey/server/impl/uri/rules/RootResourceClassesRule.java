/*    */ package com.sun.jersey.server.impl.uri.rules;
/*    */ 
/*    */ import com.sun.jersey.server.impl.uri.PathPattern;
/*    */ import com.sun.jersey.server.probes.UriRuleProbeProvider;
/*    */ import com.sun.jersey.spi.uri.rules.UriRule;
/*    */ import com.sun.jersey.spi.uri.rules.UriRuleContext;
/*    */ import com.sun.jersey.spi.uri.rules.UriRules;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RootResourceClassesRule
/*    */   implements UriRule
/*    */ {
/*    */   private final UriRules<UriRule> rules;
/*    */   
/*    */   public RootResourceClassesRule(Map<PathPattern, UriRule> rulesMap)
/*    */   {
/* 65 */     this.rules = UriRulesFactory.create(rulesMap);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean accept(CharSequence path, Object resource, UriRuleContext context)
/*    */   {
/* 72 */     UriRuleProbeProvider.ruleAccept(RootResourceClassesRule.class.getSimpleName(), path, resource);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 78 */     if (context.isTracingEnabled()) {
/* 79 */       context.trace("accept root resource classes: \"" + path + "\"");
/*    */     }
/*    */     
/* 82 */     Iterator<UriRule> matches = this.rules.match(path, context);
/* 83 */     while (matches.hasNext()) {
/* 84 */       if (((UriRule)matches.next()).accept(path, resource, context))
/* 85 */         return true;
/*    */     }
/* 87 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\uri\rules\RootResourceClassesRule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */