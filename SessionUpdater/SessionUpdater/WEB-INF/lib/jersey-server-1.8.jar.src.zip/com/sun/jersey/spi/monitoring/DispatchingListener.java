package com.sun.jersey.spi.monitoring;

import com.sun.jersey.api.model.AbstractResourceMethod;
import com.sun.jersey.api.model.AbstractSubResourceLocator;

public abstract interface DispatchingListener
{
  public abstract void onSubResource(long paramLong, Class paramClass);
  
  public abstract void onSubResourceLocator(long paramLong, AbstractSubResourceLocator paramAbstractSubResourceLocator);
  
  public abstract void onResourceMethod(long paramLong, AbstractResourceMethod paramAbstractResourceMethod);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\monitoring\DispatchingListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */