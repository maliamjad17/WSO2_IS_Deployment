package com.sun.jersey.server.wadl.generators.resourcedoc.xhtml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="valueType", propOrder={})
@XmlRootElement(name="valueType")
public class XhtmlValueType
{
  @XmlValue
  protected String value;
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\wadl\generators\resourcedoc\xhtml\XhtmlValueType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */