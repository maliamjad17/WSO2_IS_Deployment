package com.sun.jersey.server.impl.model.parameter.multivalued;

import javax.ws.rs.core.MultivaluedMap;

public abstract interface MultivaluedParameterExtractor
{
  public abstract String getName();
  
  public abstract String getDefaultStringValue();
  
  public abstract Object extract(MultivaluedMap<String, String> paramMultivaluedMap);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\parameter\multivalued\MultivaluedParameterExtractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */