/*    */ package com.sun.jersey.server.impl.uri;
/*    */ 
/*    */ import com.sun.jersey.api.uri.UriComponent;
/*    */ import com.sun.jersey.api.uri.UriComponent.Type;
/*    */ import com.sun.jersey.api.uri.UriTemplate;
/*    */ import com.sun.jersey.api.uri.UriTemplateParser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PathTemplate
/*    */   extends UriTemplate
/*    */ {
/*    */   private static final class PathTemplateParser
/*    */     extends UriTemplateParser
/*    */   {
/*    */     public PathTemplateParser(String path)
/*    */     {
/* 66 */       super();
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */     protected String encodeLiteralCharacters(String literalCharacters)
/*    */     {
/* 73 */       return UriComponent.contextualEncode(literalCharacters, UriComponent.Type.PATH);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PathTemplate(String path)
/*    */   {
/* 87 */     super(new PathTemplateParser(prefixWithSlash(path)));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static String prefixWithSlash(String path)
/*    */   {
/* 98 */     return "/" + path;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\uri\PathTemplate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */