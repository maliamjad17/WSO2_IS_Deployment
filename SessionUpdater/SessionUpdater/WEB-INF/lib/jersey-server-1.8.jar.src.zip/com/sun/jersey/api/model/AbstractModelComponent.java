package com.sun.jersey.api.model;

import java.util.List;

public abstract interface AbstractModelComponent
{
  public abstract void accept(AbstractModelVisitor paramAbstractModelVisitor);
  
  public abstract List<AbstractModelComponent> getComponents();
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\model\AbstractModelComponent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */