/*    */ package com.sun.jersey.server.wadl.generators.resourcedoc.model;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElementWrapper;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="annotationDoc", propOrder={})
/*    */ public class AnnotationDocType
/*    */ {
/*    */   private String annotationTypeName;
/*    */   @XmlElementWrapper(name="attributes")
/*    */   protected List<NamedValueType> attribute;
/*    */   
/*    */   public List<NamedValueType> getAttributeDocs()
/*    */   {
/* 69 */     if (this.attribute == null) {
/* 70 */       this.attribute = new ArrayList();
/*    */     }
/* 72 */     return this.attribute;
/*    */   }
/*    */   
/*    */   public boolean hasAttributeDocs() {
/* 76 */     return (this.attribute != null) && (!this.attribute.isEmpty());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getAnnotationTypeName()
/*    */   {
/* 83 */     return this.annotationTypeName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setAnnotationTypeName(String annotationTypeName)
/*    */   {
/* 90 */     this.annotationTypeName = annotationTypeName;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\wadl\generators\resourcedoc\model\AnnotationDocType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */