/*     */ package com.sun.jersey.server.impl.uri.rules.automata;
/*     */ 
/*     */ import com.sun.jersey.api.uri.UriPattern;
/*     */ import com.sun.jersey.api.uri.UriTemplate;
/*     */ import com.sun.jersey.server.impl.uri.PathPattern;
/*     */ import com.sun.jersey.server.impl.uri.rules.PatternRulePair;
/*     */ import com.sun.jersey.spi.uri.rules.UriMatchResultContext;
/*     */ import com.sun.jersey.spi.uri.rules.UriRules;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AutomataMatchingUriTemplateRules<R>
/*     */   implements UriRules<R>
/*     */ {
/*     */   private final TrieNode<R> automata;
/*     */   
/*     */   public AutomataMatchingUriTemplateRules(List<PatternRulePair<R>> rules)
/*     */   {
/*  68 */     this.automata = initTrie(rules);
/*     */   }
/*     */   
/*     */   public Iterator<R> match(CharSequence path, UriMatchResultContext resultContext) {
/*  72 */     List<String> capturingGroupValues = new ArrayList();
/*  73 */     TrieNode<R> node = find(path, capturingGroupValues);
/*  74 */     if (node != null) {
/*  75 */       return node.getValue();
/*     */     }
/*  77 */     return new TrieNodeValue.EmptyIterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private TrieNode<R> initTrie(List<PatternRulePair<R>> rules)
/*     */   {
/*  84 */     TrieNode<R> a = new TrieNode();
/*  85 */     for (PatternRulePair<R> prp : rules) {
/*  86 */       if ((prp.p instanceof PathPattern)) {
/*  87 */         PathPattern p = (PathPattern)prp.p;
/*  88 */         a.add(p.getTemplate().getTemplate(), prp.r, prp.p);
/*     */       } else {
/*  90 */         throw new IllegalArgumentException("The automata matching algorithm currently only worksfor UriPattern instance that are instances of PathPattern");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  96 */     a.pack();
/*  97 */     return a;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final class SearchState<E>
/*     */   {
/*     */     final TrieNode<E> node;
/*     */     
/*     */ 
/*     */     final TrieArc<E> arc;
/*     */     
/*     */ 
/*     */     final int i;
/*     */     
/*     */ 
/*     */ 
/*     */     public SearchState(TrieNode<E> node, TrieArc<E> arc, int i)
/*     */     {
/* 116 */       this.node = node;
/* 117 */       this.arc = arc;
/* 118 */       this.i = i;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private TrieNode<R> find(CharSequence uri, List<String> templateValues)
/*     */   {
/* 129 */     int length = uri.length();
/*     */     
/*     */ 
/* 132 */     Stack<SearchState<R>> stack = new Stack();
/*     */     
/*     */ 
/* 135 */     Stack<TrieNode<R>> candidates = new Stack();
/*     */     
/*     */ 
/* 138 */     Set<TrieArc<R>> visitedArcs = new HashSet();
/*     */     
/*     */ 
/* 141 */     TrieNode<R> node = this.automata;
/*     */     
/*     */ 
/* 144 */     TrieArc<R> nextArc = node.getFirstArc();
/*     */     
/*     */ 
/* 147 */     int i = 0;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     for (;;)
/*     */     {
/* 157 */       if (i >= length)
/*     */       {
/*     */ 
/* 160 */         if (node.hasValue()) {
/*     */           break;
/*     */         }
/* 163 */         nextArc = null;
/* 164 */         while ((!stack.isEmpty()) && (nextArc == null)) {
/* 165 */           SearchState<R> state = (SearchState)stack.pop();
/* 166 */           nextArc = state.arc.next;
/* 167 */           node = state.node;
/* 168 */           i = state.i;
/*     */         }
/*     */         
/*     */ 
/* 172 */         if (nextArc != null) {
/* 173 */           while (visitedArcs.contains(nextArc)) {
/* 174 */             nextArc = nextArc.next;
/*     */           }
/* 176 */           if (nextArc != null) { visitedArcs.add(nextArc);
/*     */           }
/*     */         }
/*     */         
/* 180 */         if (nextArc == null)
/*     */         {
/*     */           break;
/*     */ 
/*     */         }
/*     */         
/*     */ 
/*     */       }
/* 188 */       else if ((nextArc == null) && (node.isWildcard())) {
/* 189 */         int p = 0;
/* 190 */         TrieArc<R> exitArc = null;
/*     */         
/* 192 */         while ((i + p < length) && ((exitArc = node.matchExitArc(uri, i + p)) == null)) p++;
/* 193 */         if (exitArc != null) {
/* 194 */           nextArc = exitArc;
/*     */         }
/* 196 */         i += p;
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 201 */         if ((nextArc == null) && (!node.isWildcard())) {
/*     */           break;
/*     */         }
/*     */         
/*     */ 
/* 206 */         if ((nextArc.next != null) && (node.isWildcard())) {
/* 207 */           stack.push(new SearchState(node, nextArc, i));
/*     */         }
/*     */         
/*     */ 
/* 211 */         if (node.hasValue()) {
/* 212 */           candidates.push(node);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 219 */         if ((node.isWildcard()) && (nextArc.match(uri, i) > 0)) {
/* 220 */           i += nextArc.length();
/* 221 */           node = nextArc.target;
/* 222 */           nextArc = node.getFirstArc();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 229 */         else if ((node.isWildcard()) && (nextArc.match(uri, i) == 0)) {
/* 230 */           nextArc = nextArc.next;
/* 231 */           if (nextArc == null) {
/* 232 */             i++;
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */         }
/* 239 */         else if ((!node.isWildcard()) && (nextArc.match(uri, i) > 0)) {
/* 240 */           i += nextArc.length();
/* 241 */           node = nextArc.target;
/* 242 */           nextArc = node.getFirstArc();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 248 */         else if ((!node.isWildcard()) && (nextArc.match(uri, i) == 0)) {
/* 249 */           nextArc = nextArc.next;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 260 */     if ((node.hasValue()) && 
/* 261 */       (node.getPattern().match(uri, templateValues))) {
/* 262 */       return node;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 267 */     while (!candidates.isEmpty()) {
/* 268 */       TrieNode<R> s = (TrieNode)candidates.pop();
/* 269 */       if (s.getPattern().match(uri, templateValues)) {
/* 270 */         return s;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 275 */     templateValues.clear();
/* 276 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\uri\rules\automata\AutomataMatchingUriTemplateRules.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */