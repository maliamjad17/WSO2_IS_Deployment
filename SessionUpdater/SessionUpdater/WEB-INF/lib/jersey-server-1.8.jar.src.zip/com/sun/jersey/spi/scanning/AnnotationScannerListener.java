/*     */ package com.sun.jersey.spi.scanning;
/*     */ 
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*     */ import com.sun.jersey.core.spi.scanning.ScannerListener;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.objectweb.asm.AnnotationVisitor;
/*     */ import org.objectweb.asm.Attribute;
/*     */ import org.objectweb.asm.ClassReader;
/*     */ import org.objectweb.asm.ClassVisitor;
/*     */ import org.objectweb.asm.FieldVisitor;
/*     */ import org.objectweb.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationScannerListener
/*     */   implements ScannerListener
/*     */ {
/*     */   private final ClassLoader classloader;
/*     */   private final Set<Class<?>> classes;
/*     */   private final Set<String> annotations;
/*     */   private final AnnotatedClassVisitor classVisitor;
/*     */   
/*     */   public AnnotationScannerListener(Class<? extends Annotation>... annotations)
/*     */   {
/*  89 */     this(ReflectionHelper.getContextClassLoader(), annotations);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationScannerListener(ClassLoader classloader, Class<? extends Annotation>... annotations)
/*     */   {
/* 103 */     this.classloader = classloader;
/* 104 */     this.classes = new LinkedHashSet();
/* 105 */     this.annotations = getAnnotationSet(annotations);
/* 106 */     this.classVisitor = new AnnotatedClassVisitor(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<Class<?>> getAnnotatedClasses()
/*     */   {
/* 115 */     return this.classes;
/*     */   }
/*     */   
/*     */   private Set<String> getAnnotationSet(Class<? extends Annotation>... annotations) {
/* 119 */     Set<String> a = new HashSet();
/* 120 */     for (Class c : annotations) {
/* 121 */       a.add("L" + c.getName().replaceAll("\\.", "/") + ";");
/*     */     }
/* 123 */     return a;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean onAccept(String name)
/*     */   {
/* 129 */     return name.endsWith(".class");
/*     */   }
/*     */   
/*     */   public void onProcess(String name, InputStream in) throws IOException {
/* 133 */     new ClassReader(in).accept(this.classVisitor, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private final class AnnotatedClassVisitor
/*     */     implements ClassVisitor
/*     */   {
/*     */     private String className;
/*     */     
/*     */ 
/*     */     private boolean isScoped;
/*     */     
/*     */ 
/*     */     private boolean isAnnotated;
/*     */     
/*     */ 
/*     */     private AnnotatedClassVisitor() {}
/*     */     
/*     */ 
/*     */     public void visit(int version, int access, String name, String signature, String superName, String[] interfaces)
/*     */     {
/* 155 */       this.className = name;
/* 156 */       this.isScoped = ((access & 0x1) != 0);
/* 157 */       this.isAnnotated = false;
/*     */     }
/*     */     
/*     */     public AnnotationVisitor visitAnnotation(String desc, boolean visible) {
/* 161 */       this.isAnnotated |= AnnotationScannerListener.this.annotations.contains(desc);
/* 162 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void visitInnerClass(String name, String outerName, String innerName, int access)
/*     */     {
/* 171 */       if (this.className.equals(name)) {
/* 172 */         this.isScoped = ((access & 0x1) != 0);
/*     */         
/*     */ 
/* 175 */         this.isScoped &= (access & 0x8) == 8;
/*     */       }
/*     */     }
/*     */     
/*     */     public void visitEnd() {
/* 180 */       if ((this.isScoped) && (this.isAnnotated))
/*     */       {
/*     */ 
/* 183 */         AnnotationScannerListener.this.classes.add(getClassForName(this.className.replaceAll("/", ".")));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void visitOuterClass(String string, String string0, String string1) {}
/*     */     
/*     */ 
/*     */ 
/*     */     public FieldVisitor visitField(int i, String string, String string0, String string1, Object object)
/*     */     {
/* 195 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void visitSource(String string, String string0) {}
/*     */     
/*     */ 
/*     */ 
/*     */     public void visitAttribute(Attribute attribute) {}
/*     */     
/*     */ 
/*     */     public MethodVisitor visitMethod(int i, String string, String string0, String string1, String[] string2)
/*     */     {
/* 209 */       return null;
/*     */     }
/*     */     
/*     */     private Class getClassForName(String className) {
/*     */       try {
/* 214 */         return ReflectionHelper.classForNameWithException(className, AnnotationScannerListener.this.classloader);
/*     */       } catch (ClassNotFoundException ex) {
/* 216 */         String s = "A class file of the class name, " + className + "is identified but the class could not be found";
/*     */         
/*     */ 
/* 219 */         throw new RuntimeException(s, ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\scanning\AnnotationScannerListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */