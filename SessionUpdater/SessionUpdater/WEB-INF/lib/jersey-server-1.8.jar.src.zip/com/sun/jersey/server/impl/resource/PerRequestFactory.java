/*     */ package com.sun.jersey.server.impl.resource;
/*     */ 
/*     */ import com.sun.jersey.api.container.ContainerException;
/*     */ import com.sun.jersey.api.container.MappableContainerException;
/*     */ import com.sun.jersey.api.core.HttpContext;
/*     */ import com.sun.jersey.api.model.AbstractResource;
/*     */ import com.sun.jersey.core.spi.component.ComponentScope;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCComponentProvider;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCDestroyable;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCInstantiatedComponentProvider;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCProxiedComponentProvider;
/*     */ import com.sun.jersey.server.impl.inject.ServerInjectableProviderContext;
/*     */ import com.sun.jersey.server.spi.component.ResourceComponentConstructor;
/*     */ import com.sun.jersey.server.spi.component.ResourceComponentDestructor;
/*     */ import com.sun.jersey.server.spi.component.ResourceComponentInjector;
/*     */ import com.sun.jersey.server.spi.component.ResourceComponentProvider;
/*     */ import com.sun.jersey.server.spi.component.ResourceComponentProviderFactory;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.ws.rs.WebApplicationException;
/*     */ import javax.ws.rs.core.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PerRequestFactory
/*     */   implements ResourceComponentProviderFactory
/*     */ {
/*  71 */   private static final Logger LOGGER = Logger.getLogger(PerRequestFactory.class.getName());
/*     */   private final ServerInjectableProviderContext sipc;
/*     */   private final HttpContext threadLocalHc;
/*     */   private static final String SCOPE_PER_REQUEST = "com.sun.jersey.scope.PerRequest";
/*     */   
/*     */   public static void destroy(HttpContext hc)
/*     */   {
/*  78 */     Map<AbstractPerRequest, Object> m = (Map)hc.getProperties().get("com.sun.jersey.scope.PerRequest");
/*     */     
/*  80 */     if (m != null) {
/*  81 */       for (Map.Entry<AbstractPerRequest, Object> e : m.entrySet()) {
/*     */         try {
/*  83 */           ((AbstractPerRequest)e.getKey()).destroy(e.getValue());
/*     */         } catch (ContainerException ex) {
/*  85 */           LOGGER.log(Level.SEVERE, "Unable to destroy resource", ex);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public PerRequestFactory(@Context ServerInjectableProviderContext sipc, @Context HttpContext threadLocalHc)
/*     */   {
/*  94 */     this.sipc = sipc;
/*  95 */     this.threadLocalHc = threadLocalHc;
/*     */   }
/*     */   
/*     */   public ComponentScope getScope(Class c) {
/*  99 */     return ComponentScope.PerRequest;
/*     */   }
/*     */   
/*     */   public ResourceComponentProvider getComponentProvider(Class c) {
/* 103 */     return new PerRequest(null);
/*     */   }
/*     */   
/*     */   public ResourceComponentProvider getComponentProvider(IoCComponentProvider icp, Class c) {
/* 107 */     if ((icp instanceof IoCInstantiatedComponentProvider))
/* 108 */       return new PerRequestInstantiated((IoCInstantiatedComponentProvider)icp);
/* 109 */     if ((icp instanceof IoCProxiedComponentProvider)) {
/* 110 */       return new PerRequestProxied((IoCProxiedComponentProvider)icp);
/*     */     }
/* 112 */     throw new IllegalStateException();
/*     */   }
/*     */   
/*     */   private abstract class AbstractPerRequest implements ResourceComponentProvider
/*     */   {
/*     */     private ResourceComponentDestructor rcd;
/*     */     
/*     */     private AbstractPerRequest() {}
/*     */     
/*     */     public final Object getInstance() {
/* 122 */       return getInstance(PerRequestFactory.this.threadLocalHc);
/*     */     }
/*     */     
/*     */     public final ComponentScope getScope() {
/* 126 */       return ComponentScope.PerRequest;
/*     */     }
/*     */     
/*     */     public void init(AbstractResource abstractResource) {
/* 130 */       this.rcd = new ResourceComponentDestructor(abstractResource);
/*     */     }
/*     */     
/*     */     public final Object getInstance(HttpContext hc) {
/* 134 */       Map<AbstractPerRequest, Object> m = (Map)hc.getProperties().get("com.sun.jersey.scope.PerRequest");
/*     */       
/* 136 */       if (m == null) {
/* 137 */         m = new HashMap();
/* 138 */         hc.getProperties().put("com.sun.jersey.scope.PerRequest", m);
/*     */       } else {
/* 140 */         Object o = m.get(this);
/* 141 */         if (o != null) { return o;
/*     */         }
/*     */       }
/* 144 */       Object o = _getInstance(hc);
/* 145 */       m.put(this, o);
/* 146 */       return o;
/*     */     }
/*     */     
/*     */     public final void destroy() {}
/*     */     
/*     */     protected abstract Object _getInstance(HttpContext paramHttpContext);
/*     */     
/*     */     public void destroy(Object o)
/*     */     {
/*     */       try {
/* 156 */         this.rcd.destroy(o);
/*     */       } catch (IllegalAccessException ex) {
/* 158 */         throw new ContainerException("Unable to destroy resource", ex);
/*     */       } catch (InvocationTargetException ex) {
/* 160 */         throw new ContainerException("Unable to destroy resource", ex);
/*     */       } catch (RuntimeException ex) {
/* 162 */         throw new ContainerException("Unable to destroy resource", ex);
/*     */       } } }
/*     */   
/*     */   private final class PerRequest extends PerRequestFactory.AbstractPerRequest { private ResourceComponentConstructor rcc;
/*     */     
/* 167 */     private PerRequest() { super(null); }
/*     */     
/*     */ 
/*     */     public void init(AbstractResource abstractResource)
/*     */     {
/* 172 */       super.init(abstractResource);
/*     */       
/* 174 */       this.rcc = new ResourceComponentConstructor(PerRequestFactory.this.sipc, ComponentScope.PerRequest, abstractResource);
/*     */     }
/*     */     
/*     */ 
/*     */     protected Object _getInstance(HttpContext hc)
/*     */     {
/*     */       try
/*     */       {
/* 182 */         return this.rcc.construct(hc);
/*     */       } catch (InstantiationException ex) {
/* 184 */         throw new ContainerException("Unable to create resource " + this.rcc.getResourceClass(), ex);
/*     */       } catch (IllegalAccessException ex) {
/* 186 */         throw new ContainerException("Unable to create resource " + this.rcc.getResourceClass(), ex);
/*     */       }
/*     */       catch (InvocationTargetException ex) {
/* 189 */         throw new MappableContainerException(ex.getTargetException());
/*     */       } catch (WebApplicationException ex) {
/* 191 */         throw ex;
/*     */       } catch (RuntimeException ex) {
/* 193 */         throw new ContainerException("Unable to create resource " + this.rcc.getResourceClass(), ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private final class PerRequestInstantiated extends PerRequestFactory.AbstractPerRequest
/*     */   {
/*     */     private final IoCInstantiatedComponentProvider iicp;
/*     */     private final IoCDestroyable destroyable;
/*     */     private ResourceComponentInjector rci;
/*     */     
/*     */     PerRequestInstantiated(IoCInstantiatedComponentProvider iicp) {
/* 205 */       super(null);
/* 206 */       this.iicp = iicp;
/* 207 */       this.destroyable = ((iicp instanceof IoCDestroyable) ? (IoCDestroyable)iicp : null);
/*     */     }
/*     */     
/*     */ 
/*     */     public void init(AbstractResource abstractResource)
/*     */     {
/* 213 */       super.init(abstractResource);
/* 214 */       if (this.destroyable == null) {
/* 215 */         this.rci = new ResourceComponentInjector(PerRequestFactory.this.sipc, ComponentScope.PerRequest, abstractResource);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Object _getInstance(HttpContext hc)
/*     */     {
/* 223 */       Object o = this.iicp.getInstance();
/* 224 */       if (this.destroyable == null) {
/* 225 */         this.rci.inject(hc, this.iicp.getInjectableInstance(o));
/*     */       }
/* 227 */       return o;
/*     */     }
/*     */     
/*     */     public void destroy(Object o)
/*     */     {
/* 232 */       if (this.destroyable != null) {
/* 233 */         this.destroyable.destroy(o);
/*     */       } else {
/* 235 */         super.destroy(o);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private final class PerRequestProxied extends PerRequestFactory.AbstractPerRequest {
/*     */     private final IoCProxiedComponentProvider ipcp;
/*     */     private ResourceComponentConstructor rcc;
/*     */     
/*     */     PerRequestProxied(IoCProxiedComponentProvider ipcp) {
/* 245 */       super(null);
/* 246 */       this.ipcp = ipcp;
/*     */     }
/*     */     
/*     */     public void init(AbstractResource abstractResource)
/*     */     {
/* 251 */       super.init(abstractResource);
/*     */       
/* 253 */       this.rcc = new ResourceComponentConstructor(PerRequestFactory.this.sipc, ComponentScope.PerRequest, abstractResource);
/*     */     }
/*     */     
/*     */ 
/*     */     public Object _getInstance(HttpContext hc)
/*     */     {
/*     */       try
/*     */       {
/* 261 */         return this.ipcp.proxy(this.rcc.construct(hc));
/*     */       } catch (InstantiationException ex) {
/* 263 */         throw new ContainerException("Unable to create resource", ex);
/*     */       } catch (IllegalAccessException ex) {
/* 265 */         throw new ContainerException("Unable to create resource", ex);
/*     */       }
/*     */       catch (InvocationTargetException ex) {
/* 268 */         throw new MappableContainerException(ex.getTargetException());
/*     */       } catch (WebApplicationException ex) {
/* 270 */         throw ex;
/*     */       } catch (RuntimeException ex) {
/* 272 */         throw new ContainerException("Unable to create resource", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\resource\PerRequestFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */