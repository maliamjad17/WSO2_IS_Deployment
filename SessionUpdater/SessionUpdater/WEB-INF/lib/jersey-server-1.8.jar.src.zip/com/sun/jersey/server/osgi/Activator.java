/*    */ package com.sun.jersey.server.osgi;
/*    */ 
/*    */ import com.sun.jersey.server.impl.provider.RuntimeDelegateImpl;
/*    */ import java.util.logging.Logger;
/*    */ import javax.ws.rs.ext.RuntimeDelegate;
/*    */ import org.osgi.framework.BundleActivator;
/*    */ import org.osgi.framework.BundleContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Activator
/*    */   implements BundleActivator
/*    */ {
/* 58 */   private static final Logger LOGGER = Logger.getLogger(Activator.class.getName());
/*    */   
/*    */   public void start(BundleContext bc) throws Exception
/*    */   {
/* 62 */     LOGGER.config("jersey-server bundle activator registers JAX-RS RuntimeDelegate instance");
/* 63 */     RuntimeDelegate.setInstance(new RuntimeDelegateImpl());
/*    */   }
/*    */   
/*    */   public void stop(BundleContext bc)
/*    */     throws Exception
/*    */   {}
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\osgi\Activator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */