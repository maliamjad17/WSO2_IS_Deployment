/*    */ package com.sun.jersey.server.impl.cdi;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Set;
/*    */ import javax.enterprise.inject.spi.AnnotatedConstructor;
/*    */ import javax.enterprise.inject.spi.AnnotatedType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnotatedConstructorImpl<T>
/*    */   extends AnnotatedCallableImpl<T>
/*    */   implements AnnotatedConstructor<T>
/*    */ {
/*    */   private Constructor<T> javaMember;
/*    */   
/*    */   public AnnotatedConstructorImpl(Type baseType, Set<Type> typeClosure, Set<Annotation> annotations, AnnotatedType<T> declaringType, Constructor javaMember, boolean isStatic)
/*    */   {
/* 65 */     super(baseType, typeClosure, annotations, declaringType, javaMember, isStatic);
/* 66 */     this.javaMember = javaMember;
/*    */   }
/*    */   
/*    */   public AnnotatedConstructorImpl(AnnotatedConstructor<T> constructor, AnnotatedType<T> declaringType) {
/* 70 */     this(constructor.getBaseType(), constructor.getTypeClosure(), constructor.getAnnotations(), declaringType, constructor.getJavaMember(), constructor.isStatic());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Constructor<T> getJavaMember()
/*    */   {
/* 80 */     return this.javaMember;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\cdi\AnnotatedConstructorImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */