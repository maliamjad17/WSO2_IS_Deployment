/*    */ package com.sun.jersey.api.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PathValue
/*    */ {
/*    */   private String value;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PathValue(String path)
/*    */   {
/* 50 */     this.value = path;
/*    */   }
/*    */   
/*    */   public String getValue() {
/* 54 */     return this.value;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 59 */     return getClass().getSimpleName() + "(" + (null == getValue() ? "null" : new StringBuilder().append("\"").append(getValue()).append("\"").toString()) + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\model\PathValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */