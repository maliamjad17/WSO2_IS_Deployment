package com.sun.jersey.spi.monitoring;

public abstract interface GlassfishMonitoringProvider
{
  public abstract void register();
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\monitoring\GlassfishMonitoringProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */