/*     */ package com.sun.jersey.server.impl.model.parameter.multivalued;
/*     */ 
/*     */ import com.sun.jersey.spi.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class CollectionStringReaderExtractor<V extends Collection>
/*     */   extends AbstractStringReaderExtractor
/*     */ {
/*     */   protected CollectionStringReaderExtractor(StringReader sr, String parameter, String defaultStringValue)
/*     */   {
/*  60 */     super(sr, parameter, defaultStringValue);
/*     */   }
/*     */   
/*     */   public Object extract(MultivaluedMap<String, String> parameters) {
/*  64 */     List<String> stringList = (List)parameters.get(this.parameter);
/*  65 */     if (stringList != null) {
/*  66 */       V valueList = getInstance();
/*  67 */       for (String v : stringList) {
/*  68 */         valueList.add(v.length() == 0 ? null : this.sr.fromString(v));
/*     */       }
/*     */       
/*  71 */       return valueList; }
/*  72 */     if (this.defaultStringValue != null) {
/*  73 */       V valueList = getInstance();
/*  74 */       valueList.add(this.sr.fromString(this.defaultStringValue));
/*  75 */       return valueList;
/*     */     }
/*  77 */     return getInstance();
/*     */   }
/*     */   
/*     */   protected abstract V getInstance();
/*     */   
/*     */   private static final class ListValueOf extends CollectionStringReaderExtractor<List>
/*     */   {
/*     */     ListValueOf(StringReader sr, String parameter, String defaultValueString)
/*     */     {
/*  86 */       super(parameter, defaultValueString);
/*     */     }
/*     */     
/*     */     protected List getInstance() {
/*  90 */       return new ArrayList();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class SetValueOf extends CollectionStringReaderExtractor<Set>
/*     */   {
/*     */     SetValueOf(StringReader sr, String parameter, String defaultValueString) {
/*  97 */       super(parameter, defaultValueString);
/*     */     }
/*     */     
/*     */     protected Set getInstance() {
/* 101 */       return new HashSet();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class SortedSetValueOf extends CollectionStringReaderExtractor<SortedSet>
/*     */   {
/*     */     SortedSetValueOf(StringReader sr, String parameter, String defaultValueString) {
/* 108 */       super(parameter, defaultValueString);
/*     */     }
/*     */     
/*     */     protected SortedSet getInstance() {
/* 112 */       return new TreeSet();
/*     */     }
/*     */   }
/*     */   
/*     */   static MultivaluedParameterExtractor getInstance(Class c, StringReader sr, String parameter, String defaultValueString)
/*     */   {
/* 118 */     if (List.class == c)
/* 119 */       return new ListValueOf(sr, parameter, defaultValueString);
/* 120 */     if (Set.class == c)
/* 121 */       return new SetValueOf(sr, parameter, defaultValueString);
/* 122 */     if (SortedSet.class == c) {
/* 123 */       return new SortedSetValueOf(sr, parameter, defaultValueString);
/*     */     }
/* 125 */     throw new RuntimeException();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\parameter\multivalued\CollectionStringReaderExtractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */