/*     */ package com.sun.jersey.server.impl.model.parameter;
/*     */ 
/*     */ import com.sun.jersey.api.ParamException.PathParamException;
/*     */ import com.sun.jersey.api.core.ExtendedUriInfo;
/*     */ import com.sun.jersey.api.core.HttpContext;
/*     */ import com.sun.jersey.api.model.Parameter;
/*     */ import com.sun.jersey.core.spi.component.ComponentContext;
/*     */ import com.sun.jersey.server.impl.inject.AbstractHttpContextInjectable;
/*     */ import com.sun.jersey.server.impl.model.parameter.multivalued.ExtractorContainerException;
/*     */ import com.sun.jersey.server.impl.model.parameter.multivalued.MultivaluedParameterExtractor;
/*     */ import com.sun.jersey.server.impl.model.parameter.multivalued.MultivaluedParameterExtractorProvider;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.List;
/*     */ import javax.ws.rs.PathParam;
/*     */ import javax.ws.rs.core.PathSegment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PathParamInjectableProvider
/*     */   extends BaseParamInjectableProvider<PathParam>
/*     */ {
/*     */   private static final class PathParamInjectable
/*     */     extends AbstractHttpContextInjectable<Object>
/*     */   {
/*     */     private final MultivaluedParameterExtractor extractor;
/*     */     private final boolean decode;
/*     */     
/*     */     PathParamInjectable(MultivaluedParameterExtractor extractor, boolean decode)
/*     */     {
/*  71 */       this.extractor = extractor;
/*  72 */       this.decode = decode;
/*     */     }
/*     */     
/*     */     public Object getValue(HttpContext context) {
/*     */       try {
/*  77 */         return this.extractor.extract(context.getUriInfo().getPathParameters(this.decode));
/*     */       } catch (ExtractorContainerException e) {
/*  79 */         throw new ParamException.PathParamException(e.getCause(), this.extractor.getName(), this.extractor.getDefaultStringValue());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class PathParamPathSegmentInjectable extends AbstractHttpContextInjectable<PathSegment>
/*     */   {
/*     */     private final String name;
/*     */     private final boolean decode;
/*     */     
/*     */     PathParamPathSegmentInjectable(String name, boolean decode) {
/*  90 */       this.name = name;
/*  91 */       this.decode = decode;
/*     */     }
/*     */     
/*     */     public PathSegment getValue(HttpContext context) {
/*  95 */       List<PathSegment> ps = context.getUriInfo().getPathSegments(this.name, this.decode);
/*  96 */       if (ps.isEmpty())
/*  97 */         return null;
/*  98 */       return (PathSegment)ps.get(ps.size() - 1);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class PathParamListPathSegmentInjectable extends AbstractHttpContextInjectable<List<PathSegment>> {
/*     */     private final String name;
/*     */     private final boolean decode;
/*     */     
/*     */     PathParamListPathSegmentInjectable(String name, boolean decode) {
/* 107 */       this.name = name;
/* 108 */       this.decode = decode;
/*     */     }
/*     */     
/*     */     public List<PathSegment> getValue(HttpContext context) {
/* 112 */       return context.getUriInfo().getPathSegments(this.name, this.decode);
/*     */     }
/*     */   }
/*     */   
/*     */   public PathParamInjectableProvider(MultivaluedParameterExtractorProvider w) {
/* 117 */     super(w);
/*     */   }
/*     */   
/*     */   public Injectable<?> getInjectable(ComponentContext ic, PathParam a, Parameter c) {
/* 121 */     String parameterName = c.getSourceName();
/* 122 */     if ((parameterName == null) || (parameterName.length() == 0))
/*     */     {
/* 124 */       return null;
/*     */     }
/*     */     
/* 127 */     if (c.getParameterClass() == PathSegment.class) {
/* 128 */       return new PathParamPathSegmentInjectable(parameterName, !c.isEncoded());
/*     */     }
/* 130 */     if ((c.getParameterClass() == List.class) && ((c.getParameterType() instanceof ParameterizedType)))
/*     */     {
/* 132 */       ParameterizedType pt = (ParameterizedType)c.getParameterType();
/* 133 */       Type[] targs = pt.getActualTypeArguments();
/* 134 */       if ((targs.length == 1) && (targs[0] == PathSegment.class)) {
/* 135 */         return new PathParamListPathSegmentInjectable(parameterName, !c.isEncoded());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 140 */     MultivaluedParameterExtractor e = getWithoutDefaultValue(c);
/* 141 */     if (e == null) {
/* 142 */       return null;
/*     */     }
/* 144 */     return new PathParamInjectable(e, !c.isEncoded());
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\parameter\PathParamInjectableProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */