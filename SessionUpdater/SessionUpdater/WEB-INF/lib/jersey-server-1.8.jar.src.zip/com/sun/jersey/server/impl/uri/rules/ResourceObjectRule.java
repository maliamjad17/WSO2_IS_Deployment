/*     */ package com.sun.jersey.server.impl.uri.rules;
/*     */ 
/*     */ import com.sun.jersey.api.core.ExtendedUriInfo;
/*     */ import com.sun.jersey.api.uri.UriTemplate;
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*     */ import com.sun.jersey.server.probes.UriRuleProbeProvider;
/*     */ import com.sun.jersey.spi.uri.rules.UriRule;
/*     */ import com.sun.jersey.spi.uri.rules.UriRuleContext;
/*     */ import com.sun.jersey.spi.uri.rules.UriRules;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResourceObjectRule
/*     */   extends BaseRule
/*     */ {
/*     */   private final Object resourceObject;
/*     */   
/*     */   public ResourceObjectRule(UriTemplate template, Object resourceObject)
/*     */   {
/*  65 */     super(template);
/*  66 */     this.resourceObject = resourceObject;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean accept(CharSequence path, Object resource, UriRuleContext context)
/*     */   {
/*  75 */     pushMatch(context);
/*     */     
/*  77 */     if (context.isTracingEnabled()) {
/*  78 */       context.trace(String.format("accept resource: \"%s\" -> @Path(\"%s\") %s", new Object[] { context.getUriInfo().getMatchedURIs().get(0), getTemplate().getTemplate(), ReflectionHelper.objectToString(this.resourceObject) }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  87 */     context.pushResource(this.resourceObject);
/*     */     
/*  89 */     UriRuleProbeProvider.ruleAccept(ResourceObjectRule.class.getSimpleName(), path, this.resourceObject);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */     Iterator<UriRule> matches = context.getRules(this.resourceObject.getClass()).match(path, context);
/*     */     
/*     */ 
/*  99 */     while (matches.hasNext()) {
/* 100 */       if (((UriRule)matches.next()).accept(path, this.resourceObject, context)) {
/* 101 */         return true;
/*     */       }
/*     */     }
/* 104 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\uri\rules\ResourceObjectRule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */