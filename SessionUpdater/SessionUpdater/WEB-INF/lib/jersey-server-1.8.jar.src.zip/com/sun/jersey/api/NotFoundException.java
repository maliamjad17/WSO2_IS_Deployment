/*     */ package com.sun.jersey.api;
/*     */ 
/*     */ import java.net.URI;
/*     */ import javax.ws.rs.WebApplicationException;
/*     */ import javax.ws.rs.core.Response.ResponseBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NotFoundException
/*     */   extends WebApplicationException
/*     */ {
/*     */   private final URI notFoundUri;
/*     */   
/*     */   public NotFoundException()
/*     */   {
/*  59 */     this((URI)null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NotFoundException(URI notFoundUri)
/*     */   {
/*  68 */     super(Responses.notFound().build());
/*  69 */     this.notFoundUri = notFoundUri;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NotFoundException(String message)
/*     */   {
/*  78 */     this(message, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NotFoundException(String message, URI notFoundUri)
/*     */   {
/*  88 */     super(Responses.notFound().entity(message).type("text/plain").build());
/*     */     
/*  90 */     this.notFoundUri = notFoundUri;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public URI getNotFoundUri()
/*     */   {
/*  99 */     return this.notFoundUri;
/*     */   }
/*     */   
/*     */   public String getMessage()
/*     */   {
/* 104 */     return super.getMessage() + " for uri: " + this.notFoundUri;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\NotFoundException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */