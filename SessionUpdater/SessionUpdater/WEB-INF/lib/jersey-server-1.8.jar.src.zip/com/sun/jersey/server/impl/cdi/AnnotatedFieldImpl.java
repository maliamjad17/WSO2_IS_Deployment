/*    */ package com.sun.jersey.server.impl.cdi;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Set;
/*    */ import javax.enterprise.inject.spi.AnnotatedField;
/*    */ import javax.enterprise.inject.spi.AnnotatedType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnotatedFieldImpl<T>
/*    */   extends AnnotatedMemberImpl<T>
/*    */   implements AnnotatedField<T>
/*    */ {
/*    */   private Field javaMember;
/*    */   
/*    */   public AnnotatedFieldImpl(Type baseType, Set<Type> typeClosure, Set<Annotation> annotations, AnnotatedType<T> declaringType, Field javaMember, boolean isStatic)
/*    */   {
/* 65 */     super(baseType, typeClosure, annotations, declaringType, javaMember, isStatic);
/* 66 */     this.javaMember = javaMember;
/*    */   }
/*    */   
/*    */   public AnnotatedFieldImpl(AnnotatedField<? super T> field, AnnotatedType<T> declaringType) {
/* 70 */     this(field.getBaseType(), field.getTypeClosure(), field.getAnnotations(), declaringType, field.getJavaMember(), field.isStatic());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public AnnotatedFieldImpl(AnnotatedField<? super T> field, Set<Annotation> annotations, AnnotatedType<T> declaringType)
/*    */   {
/* 79 */     this(field.getBaseType(), field.getTypeClosure(), annotations, declaringType, field.getJavaMember(), field.isStatic());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Field getJavaMember()
/*    */   {
/* 89 */     return this.javaMember;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\cdi\AnnotatedFieldImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */