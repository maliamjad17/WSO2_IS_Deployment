/*     */ package com.sun.jersey.spi.container;
/*     */ 
/*     */ import com.sun.jersey.api.MessageException;
/*     */ import com.sun.jersey.api.Responses;
/*     */ import com.sun.jersey.api.container.MappableContainerException;
/*     */ import com.sun.jersey.api.core.HttpResponseContext;
/*     */ import com.sun.jersey.api.core.TraceInformation;
/*     */ import com.sun.jersey.core.header.OutBoundHeaders;
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*     */ import com.sun.jersey.core.spi.factory.ResponseImpl;
/*     */ import com.sun.jersey.spi.MessageBodyWorkers;
/*     */ import com.sun.jersey.spi.monitoring.ResponseListener;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.URI;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.ws.rs.WebApplicationException;
/*     */ import javax.ws.rs.core.GenericEntity;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.core.Response;
/*     */ import javax.ws.rs.core.Response.ResponseBuilder;
/*     */ import javax.ws.rs.core.Response.Status;
/*     */ import javax.ws.rs.core.Response.StatusType;
/*     */ import javax.ws.rs.core.UriBuilder;
/*     */ import javax.ws.rs.ext.ExceptionMapper;
/*     */ import javax.ws.rs.ext.MessageBodyWriter;
/*     */ import javax.ws.rs.ext.RuntimeDelegate;
/*     */ import javax.ws.rs.ext.RuntimeDelegate.HeaderDelegate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContainerResponse
/*     */   implements HttpResponseContext
/*     */ {
/*  84 */   private static final Annotation[] EMPTY_ANNOTATIONS = new Annotation[0];
/*     */   
/*  86 */   private static final Logger LOGGER = Logger.getLogger(ContainerResponse.class.getName());
/*     */   
/*  88 */   private static final RuntimeDelegate rd = RuntimeDelegate.getInstance();
/*     */   
/*     */   private final WebApplication wa;
/*     */   
/*     */   private ContainerRequest request;
/*     */   
/*     */   private ContainerResponseWriter responseWriter;
/*     */   
/*     */   private Response response;
/*     */   
/*     */   private Throwable mappedThrowable;
/*     */   
/*     */   private Response.StatusType statusType;
/*     */   
/*     */   private MultivaluedMap<String, Object> headers;
/*     */   
/*     */   private Object originalEntity;
/*     */   
/*     */   private Object entity;
/*     */   
/*     */   private Type entityType;
/*     */   
/*     */   private boolean isCommitted;
/*     */   
/*     */   private CommittingOutputStream out;
/*     */   
/* 114 */   private Annotation[] annotations = EMPTY_ANNOTATIONS;
/*     */   
/*     */   private final class CommittingOutputStream extends OutputStream
/*     */   {
/*     */     private final long size;
/*     */     private OutputStream o;
/*     */     
/*     */     CommittingOutputStream(long size) {
/* 122 */       this.size = size;
/*     */     }
/*     */     
/*     */     public void write(byte[] b) throws IOException
/*     */     {
/* 127 */       commitWrite();
/* 128 */       this.o.write(b);
/*     */     }
/*     */     
/*     */     public void write(byte[] b, int off, int len) throws IOException
/*     */     {
/* 133 */       commitWrite();
/* 134 */       this.o.write(b, off, len);
/*     */     }
/*     */     
/*     */     public void write(int b) throws IOException {
/* 138 */       commitWrite();
/* 139 */       this.o.write(b);
/*     */     }
/*     */     
/*     */     public void flush() throws IOException
/*     */     {
/* 144 */       commitWrite();
/* 145 */       this.o.flush();
/*     */     }
/*     */     
/*     */     public void close() throws IOException
/*     */     {
/* 150 */       commitClose();
/* 151 */       this.o.close();
/*     */     }
/*     */     
/*     */     private void commitWrite() throws IOException {
/* 155 */       if (!ContainerResponse.this.isCommitted) {
/* 156 */         if (ContainerResponse.this.getStatus() == 204)
/* 157 */           ContainerResponse.this.setStatus(200);
/* 158 */         ContainerResponse.this.isCommitted = true;
/* 159 */         this.o = ContainerResponse.this.responseWriter.writeStatusAndHeaders(this.size, ContainerResponse.this);
/*     */       }
/*     */     }
/*     */     
/*     */     private void commitClose() throws IOException {
/* 164 */       if (!ContainerResponse.this.isCommitted) {
/* 165 */         ContainerResponse.this.isCommitted = true;
/* 166 */         this.o = ContainerResponse.this.responseWriter.writeStatusAndHeaders(-1L, ContainerResponse.this);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContainerResponse(WebApplication wa, ContainerRequest request, ContainerResponseWriter responseWriter)
/*     */   {
/* 182 */     this.wa = wa;
/* 183 */     this.request = request;
/* 184 */     this.responseWriter = responseWriter;
/* 185 */     this.statusType = Response.Status.NO_CONTENT;
/*     */   }
/*     */   
/*     */   ContainerResponse(ContainerResponse acr)
/*     */   {
/* 190 */     this.wa = acr.wa;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getHeaderValue(Object headerValue)
/*     */   {
/* 211 */     RuntimeDelegate.HeaderDelegate hp = rd.createHeaderDelegate(headerValue.getClass());
/*     */     
/* 213 */     return hp != null ? hp.toString(headerValue) : headerValue.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write()
/*     */     throws IOException
/*     */   {
/* 231 */     if (this.isCommitted) {
/* 232 */       return;
/*     */     }
/* 234 */     if (this.request.isTracingEnabled()) {
/* 235 */       configureTrace(this.responseWriter);
/*     */     }
/*     */     
/* 238 */     if (this.entity == null) {
/* 239 */       this.isCommitted = true;
/* 240 */       this.responseWriter.writeStatusAndHeaders(-1L, this);
/* 241 */       this.responseWriter.finish();
/* 242 */       return;
/*     */     }
/*     */     
/* 245 */     if (!getHttpHeaders().containsKey("Vary")) {
/* 246 */       String varyHeader = (String)this.request.getProperties().get("Vary");
/* 247 */       if (varyHeader != null) {
/* 248 */         getHttpHeaders().add("Vary", varyHeader);
/*     */       }
/*     */     }
/*     */     
/* 252 */     MediaType contentType = getMediaType();
/* 253 */     if (contentType == null) {
/* 254 */       contentType = getMessageBodyWorkers().getMessageBodyWriterMediaType(this.entity.getClass(), this.entityType, this.annotations, this.request.getAcceptableMediaTypes());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 259 */       if ((contentType == null) || (contentType.isWildcardType()) || (contentType.isWildcardSubtype()))
/*     */       {
/* 261 */         contentType = MediaType.APPLICATION_OCTET_STREAM_TYPE;
/*     */       }
/* 263 */       getHttpHeaders().putSingle("Content-Type", contentType);
/*     */     }
/*     */     
/* 266 */     MessageBodyWriter p = getMessageBodyWorkers().getMessageBodyWriter(this.entity.getClass(), this.entityType, this.annotations, contentType);
/*     */     
/*     */ 
/* 269 */     if (p == null) {
/* 270 */       String message = "A message body writer for Java class " + this.entity.getClass().getName() + ", and Java type " + this.entityType + ", and MIME media type " + contentType + " was not found";
/*     */       
/*     */ 
/* 273 */       LOGGER.severe(message);
/* 274 */       Map<MediaType, List<MessageBodyWriter>> m = getMessageBodyWorkers().getWriters(contentType);
/*     */       
/* 276 */       LOGGER.severe("The registered message body writers compatible with the MIME media type are:\n" + getMessageBodyWorkers().writersToString(m));
/*     */       
/*     */ 
/* 279 */       if (this.request.getMethod().equals("HEAD")) {
/* 280 */         this.isCommitted = true;
/* 281 */         this.responseWriter.writeStatusAndHeaders(-1L, this);
/* 282 */         this.responseWriter.finish();
/* 283 */         return;
/*     */       }
/* 285 */       throw new WebApplicationException(new MessageException(message), 500);
/*     */     }
/*     */     
/*     */ 
/* 289 */     long size = p.getSize(this.entity, this.entity.getClass(), this.entityType, this.annotations, contentType);
/*     */     
/* 291 */     if (this.request.getMethod().equals("HEAD")) {
/* 292 */       if (size != -1L)
/* 293 */         getHttpHeaders().putSingle("Content-Length", Long.toString(size));
/* 294 */       this.isCommitted = true;
/* 295 */       this.responseWriter.writeStatusAndHeaders(0L, this);
/*     */     } else {
/* 297 */       if (this.request.isTracingEnabled()) {
/* 298 */         this.request.trace(String.format("matched message body writer: %s, \"%s\" -> %s", new Object[] { ReflectionHelper.objectToString(this.entity), contentType, ReflectionHelper.objectToString(p) }));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 304 */       if (this.out == null)
/* 305 */         this.out = new CommittingOutputStream(size);
/* 306 */       p.writeTo(this.entity, this.entity.getClass(), this.entityType, this.annotations, contentType, getHttpHeaders(), this.out);
/*     */       
/*     */ 
/* 309 */       if (!this.isCommitted) {
/* 310 */         this.isCommitted = true;
/* 311 */         this.responseWriter.writeStatusAndHeaders(-1L, this);
/*     */       }
/*     */     }
/* 314 */     this.responseWriter.finish();
/*     */   }
/*     */   
/*     */   private void configureTrace(final ContainerResponseWriter crw) {
/* 318 */     final TraceInformation ti = (TraceInformation)this.request.getProperties().get(TraceInformation.class.getName());
/*     */     
/* 320 */     setContainerResponseWriter(new ContainerResponseWriter()
/*     */     {
/*     */       public OutputStream writeStatusAndHeaders(long contentLength, ContainerResponse response) throws IOException {
/* 323 */         ti.addTraceHeaders();
/* 324 */         return crw.writeStatusAndHeaders(contentLength, response);
/*     */       }
/*     */       
/*     */       public void finish() throws IOException {
/* 328 */         crw.finish();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/* 337 */     setResponse(Responses.noContent().build());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContainerRequest getContainerRequest()
/*     */   {
/* 346 */     return this.request;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContainerRequest(ContainerRequest request)
/*     */   {
/* 355 */     this.request = request;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContainerResponseWriter getContainerResponseWriter()
/*     */   {
/* 364 */     return this.responseWriter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContainerResponseWriter(ContainerResponseWriter responseWriter)
/*     */   {
/* 373 */     this.responseWriter = responseWriter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MessageBodyWorkers getMessageBodyWorkers()
/*     */   {
/* 382 */     return this.wa.getMessageBodyWorkers();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void mapMappableContainerException(MappableContainerException e)
/*     */   {
/* 396 */     Throwable cause = e.getCause();
/*     */     
/* 398 */     if ((cause instanceof WebApplicationException)) {
/* 399 */       mapWebApplicationException((WebApplicationException)cause);
/* 400 */     } else if (!mapException(cause)) {
/* 401 */       if ((cause instanceof RuntimeException)) {
/* 402 */         LOGGER.log(Level.SEVERE, "The RuntimeException could not be mapped to a response, re-throwing to the HTTP container", cause);
/*     */         
/* 404 */         throw ((RuntimeException)cause);
/*     */       }
/* 406 */       LOGGER.log(Level.SEVERE, "The exception contained within MappableContainerException could not be mapped to a response, re-throwing to the HTTP container", cause);
/*     */       
/*     */ 
/* 409 */       throw e;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void mapWebApplicationException(WebApplicationException e)
/*     */   {
/* 420 */     if (e.getResponse().getEntity() != null) {
/* 421 */       onException(e, e.getResponse(), false);
/*     */     }
/* 423 */     else if (!mapException(e)) {
/* 424 */       onException(e, e.getResponse(), false);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean mapException(Throwable e)
/*     */   {
/* 436 */     ExceptionMapper em = this.wa.getExceptionMapperContext().find(e.getClass());
/* 437 */     if (em == null) { return false;
/*     */     }
/* 439 */     this.wa.getResponseListener().onMappedException(Thread.currentThread().getId(), e, em);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 445 */     if (this.request.isTracingEnabled()) {
/* 446 */       this.request.trace(String.format("matched exception mapper: %s -> %s", new Object[] { ReflectionHelper.objectToString(e), ReflectionHelper.objectToString(em) }));
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 452 */       Response r = em.toResponse(e);
/* 453 */       if (r == null)
/* 454 */         r = Response.noContent().build();
/* 455 */       onException(e, r, true);
/*     */     }
/*     */     catch (MappableContainerException ex)
/*     */     {
/* 459 */       throw ex;
/*     */     } catch (RuntimeException ex) {
/* 461 */       LOGGER.severe("Exception mapper " + em + " for Throwable " + e + " threw a RuntimeException when " + "attempting to obtain the response");
/*     */       
/*     */ 
/*     */ 
/* 465 */       Response r = Response.serverError().build();
/* 466 */       onException(ex, r, false);
/*     */     }
/* 468 */     return true;
/*     */   }
/*     */   
/*     */   private void onException(Throwable e, Response r, boolean mapped) {
/* 472 */     if (this.request.isTracingEnabled()) {
/* 473 */       Response.Status s = Response.Status.fromStatusCode(r.getStatus());
/* 474 */       if (s != null) {
/* 475 */         this.request.trace(String.format("mapped exception to response: %s -> %d (%s)", new Object[] { ReflectionHelper.objectToString(e), Integer.valueOf(r.getStatus()), s.getReasonPhrase() }));
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 480 */         this.request.trace(String.format("mapped exception to response: %s -> %d", new Object[] { ReflectionHelper.objectToString(e), Integer.valueOf(r.getStatus()) }));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 486 */     if ((!mapped) && (r.getStatus() >= 500)) {
/* 487 */       logException(e, r, Level.SEVERE);
/* 488 */     } else if (LOGGER.isLoggable(Level.FINE)) {
/* 489 */       logException(e, r, Level.FINE);
/*     */     }
/*     */     
/* 492 */     setResponse(r);
/*     */     
/* 494 */     this.mappedThrowable = e;
/*     */     
/* 496 */     if ((getEntity() != null) && (getHttpHeaders().getFirst("Content-Type") == null))
/*     */     {
/* 498 */       Object m = this.request.getProperties().get("com.sun.jersey.server.impl.uri.rules.HttpMethodRule.Content-Type");
/* 499 */       if (m != null) {
/* 500 */         this.request.getProperties().remove("com.sun.jersey.server.impl.uri.rules.HttpMethodRule.Content-Type");
/* 501 */         getHttpHeaders().putSingle("Content-Type", m);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void logException(Throwable e, Response r, Level l) {
/* 507 */     Response.Status s = Response.Status.fromStatusCode(r.getStatus());
/* 508 */     if (s != null) {
/* 509 */       LOGGER.log(l, "Mapped exception to response: " + r.getStatus() + " (" + s.getReasonPhrase() + ")", e);
/*     */     }
/*     */     else
/*     */     {
/* 513 */       LOGGER.log(l, "Mapped exception to response: " + r.getStatus(), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Response getResponse()
/*     */   {
/* 522 */     if (this.response == null) {
/* 523 */       setResponse((Response)null);
/*     */     }
/*     */     
/* 526 */     return this.response;
/*     */   }
/*     */   
/*     */   public void setResponse(Response response) {
/* 530 */     this.isCommitted = false;
/* 531 */     this.out = null;
/* 532 */     this.response = (response = response != null ? response : Responses.noContent().build());
/* 533 */     this.mappedThrowable = null;
/*     */     
/* 535 */     if ((response instanceof ResponseImpl)) {
/* 536 */       ResponseImpl responseImpl = (ResponseImpl)response;
/* 537 */       setStatusType(responseImpl.getStatusType());
/* 538 */       setHeaders(response.getMetadata());
/* 539 */       setEntity(responseImpl.getEntity(), responseImpl.getEntityType());
/*     */     } else {
/* 541 */       setStatus(response.getStatus());
/* 542 */       setHeaders(response.getMetadata());
/* 543 */       setEntity(response.getEntity());
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isResponseSet() {
/* 548 */     return this.response != null;
/*     */   }
/*     */   
/*     */   public Throwable getMappedThrowable() {
/* 552 */     return this.mappedThrowable;
/*     */   }
/*     */   
/*     */   public Response.StatusType getStatusType() {
/* 556 */     return this.statusType;
/*     */   }
/*     */   
/*     */   public void setStatusType(Response.StatusType statusType) {
/* 560 */     this.statusType = statusType;
/*     */   }
/*     */   
/*     */   public int getStatus() {
/* 564 */     return this.statusType.getStatusCode();
/*     */   }
/*     */   
/*     */   public void setStatus(int status) {
/* 568 */     this.statusType = ResponseImpl.toStatusType(status);
/*     */   }
/*     */   
/*     */   public Object getEntity() {
/* 572 */     return this.entity;
/*     */   }
/*     */   
/*     */   public Type getEntityType() {
/* 576 */     return this.entityType;
/*     */   }
/*     */   
/*     */   public Object getOriginalEntity() {
/* 580 */     return this.originalEntity;
/*     */   }
/*     */   
/*     */   public void setEntity(Object entity) {
/* 584 */     setEntity(entity, entity == null ? null : entity.getClass());
/*     */   }
/*     */   
/*     */   public void setEntity(Object entity, Type entityType) {
/* 588 */     this.originalEntity = (this.entity = entity);
/* 589 */     this.entityType = entityType;
/* 590 */     if ((this.entity instanceof GenericEntity)) {
/* 591 */       GenericEntity ge = (GenericEntity)this.entity;
/* 592 */       this.entity = ge.getEntity();
/* 593 */       this.entityType = ge.getType();
/*     */     }
/*     */   }
/*     */   
/*     */   public Annotation[] getAnnotations() {
/* 598 */     return this.annotations;
/*     */   }
/*     */   
/*     */   public void setAnnotations(Annotation[] annotations) {
/* 602 */     this.annotations = (annotations != null ? annotations : EMPTY_ANNOTATIONS);
/*     */   }
/*     */   
/*     */   public MultivaluedMap<String, Object> getHttpHeaders() {
/* 606 */     if (this.headers == null)
/* 607 */       this.headers = new OutBoundHeaders();
/* 608 */     return this.headers;
/*     */   }
/*     */   
/*     */   public MediaType getMediaType() {
/* 612 */     Object mediaTypeHeader = getHttpHeaders().getFirst("Content-Type");
/* 613 */     if ((mediaTypeHeader instanceof MediaType))
/* 614 */       return (MediaType)mediaTypeHeader;
/* 615 */     if (mediaTypeHeader != null) {
/* 616 */       return MediaType.valueOf(mediaTypeHeader.toString());
/*     */     }
/*     */     
/* 619 */     return null;
/*     */   }
/*     */   
/*     */   public OutputStream getOutputStream() throws IOException {
/* 623 */     if (this.out == null) {
/* 624 */       this.out = new CommittingOutputStream(-1L);
/*     */     }
/* 626 */     return this.out;
/*     */   }
/*     */   
/*     */   public boolean isCommitted() {
/* 630 */     return this.isCommitted;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void setHeaders(MultivaluedMap<String, Object> headers)
/*     */   {
/* 637 */     this.headers = headers;
/* 638 */     Object location = headers.getFirst("Location");
/* 639 */     if ((location != null) && 
/* 640 */       ((location instanceof URI))) {
/* 641 */       URI locationUri = (URI)location;
/* 642 */       if (!locationUri.isAbsolute()) {
/* 643 */         URI base = this.statusType.getStatusCode() == Response.Status.CREATED.getStatusCode() ? this.request.getAbsolutePath() : this.request.getBaseUri();
/*     */         
/*     */ 
/* 646 */         location = UriBuilder.fromUri(base).path(locationUri.getRawPath()).replaceQuery(locationUri.getRawQuery()).fragment(locationUri.getRawFragment()).build(new Object[0]);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 652 */       headers.putSingle("Location", location);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\container\ContainerResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */