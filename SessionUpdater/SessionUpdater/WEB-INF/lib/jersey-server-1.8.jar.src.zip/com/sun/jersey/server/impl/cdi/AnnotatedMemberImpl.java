/*    */ package com.sun.jersey.server.impl.cdi;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Member;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Set;
/*    */ import javax.enterprise.inject.spi.AnnotatedMember;
/*    */ import javax.enterprise.inject.spi.AnnotatedType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnotatedMemberImpl<T>
/*    */   extends AnnotatedImpl
/*    */   implements AnnotatedMember<T>
/*    */ {
/*    */   private AnnotatedType<T> declaringType;
/*    */   private Member javaMember;
/*    */   private boolean isStatic;
/*    */   
/*    */   public AnnotatedMemberImpl(Type baseType, Set<Type> typeClosure, Set<Annotation> annotations, AnnotatedType<T> declaringType, Member javaMember, boolean isStatic)
/*    */   {
/* 67 */     super(baseType, typeClosure, annotations);
/* 68 */     this.declaringType = declaringType;
/* 69 */     this.javaMember = javaMember;
/* 70 */     this.isStatic = isStatic;
/*    */   }
/*    */   
/*    */   public AnnotatedType<T> getDeclaringType() {
/* 74 */     return this.declaringType;
/*    */   }
/*    */   
/*    */   public Member getJavaMember() {
/* 78 */     return this.javaMember;
/*    */   }
/*    */   
/*    */   public boolean isStatic() {
/* 82 */     return this.isStatic;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\cdi\AnnotatedMemberImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */