package com.sun.jersey.spi.monitoring;

public abstract interface RequestListenerAdapter
{
  public abstract RequestListener adapt(RequestListener paramRequestListener);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\monitoring\RequestListenerAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */