/*     */ package com.sun.jersey.spi.template;
/*     */ 
/*     */ import com.sun.jersey.api.view.Viewable;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResolvedViewable<T>
/*     */   extends Viewable
/*     */ {
/*     */   private final ViewProcessor<T> vp;
/*     */   private final T templateObject;
/*     */   
/*     */   public ResolvedViewable(ViewProcessor<T> vp, T t, Viewable v)
/*     */   {
/*  72 */     this(vp, t, v, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResolvedViewable(ViewProcessor<T> vp, T t, Viewable v, Class<?> resolvingClass)
/*     */   {
/*  86 */     super(v.getTemplateName(), v.getModel(), resolvingClass);
/*     */     
/*  88 */     this.vp = vp;
/*  89 */     this.templateObject = t;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeTo(OutputStream out)
/*     */     throws IOException
/*     */   {
/* 103 */     this.vp.writeTo(this.templateObject, this, out);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\template\ResolvedViewable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */