package com.sun.jersey.api.model;

public abstract interface AbstractResourceModelListener
{
  public abstract void onLoaded(AbstractResourceModelContext paramAbstractResourceModelContext);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\model\AbstractResourceModelListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */