package com.sun.jersey.api.core;

import com.sun.jersey.api.container.ContainerException;
import java.net.URI;

public abstract interface ResourceContext
{
  public abstract ExtendedUriInfo matchUriInfo(URI paramURI)
    throws ContainerException;
  
  public abstract Object matchResource(URI paramURI)
    throws ContainerException;
  
  public abstract <T> T matchResource(URI paramURI, Class<T> paramClass)
    throws ContainerException, ClassCastException;
  
  public abstract <T> T getResource(Class<T> paramClass)
    throws ContainerException;
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\core\ResourceContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */