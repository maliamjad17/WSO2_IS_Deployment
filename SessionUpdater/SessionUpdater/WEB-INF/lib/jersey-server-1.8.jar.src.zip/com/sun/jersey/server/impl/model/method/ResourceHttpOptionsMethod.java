/*    */ package com.sun.jersey.server.impl.model.method;
/*    */ 
/*    */ import com.sun.jersey.api.core.HttpContext;
/*    */ import com.sun.jersey.api.core.HttpResponseContext;
/*    */ import com.sun.jersey.api.uri.UriTemplate;
/*    */ import com.sun.jersey.core.header.MediaTypes;
/*    */ import com.sun.jersey.spi.dispatch.RequestDispatcher;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import javax.ws.rs.core.Response;
/*    */ import javax.ws.rs.core.Response.ResponseBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ResourceHttpOptionsMethod
/*    */   extends ResourceMethod
/*    */ {
/*    */   public static class OptionsRequestDispatcher
/*    */     implements RequestDispatcher
/*    */   {
/*    */     protected final String allow;
/*    */     
/*    */     public OptionsRequestDispatcher(Map<String, List<ResourceMethod>> methods)
/*    */     {
/* 61 */       this.allow = getAllow(methods);
/*    */     }
/*    */     
/*    */     private String getAllow(Map<String, List<ResourceMethod>> methods) {
/* 65 */       StringBuilder s = new StringBuilder("OPTIONS");
/* 66 */       for (String method : methods.keySet()) {
/* 67 */         s.append(',').append(method);
/*    */       }
/*    */       
/* 70 */       return s.toString();
/*    */     }
/*    */     
/*    */     public void dispatch(Object resource, HttpContext context) {
/* 74 */       Response r = Response.noContent().header("Allow", this.allow).build();
/* 75 */       context.getResponse().setResponse(r);
/*    */     }
/*    */   }
/*    */   
/*    */   public ResourceHttpOptionsMethod(Map<String, List<ResourceMethod>> methods) {
/* 80 */     super("OPTIONS", UriTemplate.EMPTY, MediaTypes.GENERAL_MEDIA_TYPE_LIST, MediaTypes.GENERAL_MEDIA_TYPE_LIST, false, new OptionsRequestDispatcher(methods));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 90 */     return "OPTIONS";
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\method\ResourceHttpOptionsMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */