/*    */ package com.sun.jersey.server.impl.model.method.dispatch;
/*    */ 
/*    */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*    */ import com.sun.jersey.api.model.Parameter;
/*    */ import com.sun.jersey.spi.container.JavaMethodInvoker;
/*    */ import com.sun.jersey.spi.container.JavaMethodInvokerFactory;
/*    */ import com.sun.jersey.spi.dispatch.RequestDispatcher;
/*    */ import com.sun.jersey.spi.inject.Injectable;
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.List;
/*    */ import java.util.logging.Logger;
/*    */ import javax.ws.rs.FormParam;
/*    */ import javax.ws.rs.core.MediaType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MultipartFormDispatchProvider
/*    */   extends FormDispatchProvider
/*    */ {
/* 60 */   private static final Logger LOGGER = Logger.getLogger(MultipartFormDispatchProvider.class.getName());
/*    */   
/* 62 */   private static MediaType MULTIPART_FORM_DATA = new MediaType("multipart", "form-data");
/*    */   
/*    */   public RequestDispatcher create(AbstractResourceMethod method)
/*    */   {
/* 66 */     return create(method, JavaMethodInvokerFactory.getDefault());
/*    */   }
/*    */   
/*    */   public RequestDispatcher create(AbstractResourceMethod method, JavaMethodInvoker invoker)
/*    */   {
/* 71 */     boolean found = false;
/* 72 */     for (MediaType m : method.getSupportedInputTypes()) {
/* 73 */       found = (!m.isWildcardSubtype()) && (m.isCompatible(MULTIPART_FORM_DATA));
/* 74 */       if (found) break;
/*    */     }
/* 76 */     if (!found) {
/* 77 */       return null;
/*    */     }
/* 79 */     return super.create(method, invoker);
/*    */   }
/*    */   
/*    */   protected List<Injectable> getInjectables(AbstractResourceMethod method)
/*    */   {
/* 84 */     for (int i = 0; i < method.getParameters().size(); i++) {
/* 85 */       Parameter p = (Parameter)method.getParameters().get(i);
/*    */       
/* 87 */       if (p.getAnnotation().annotationType() == FormParam.class) {
/* 88 */         LOGGER.severe("Resource methods utilizing @FormParam and consuming \"multipart/form-data\" are no longer supported. See @FormDataParam.");
/*    */       }
/*    */     }
/*    */     
/* 92 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\method\dispatch\MultipartFormDispatchProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */