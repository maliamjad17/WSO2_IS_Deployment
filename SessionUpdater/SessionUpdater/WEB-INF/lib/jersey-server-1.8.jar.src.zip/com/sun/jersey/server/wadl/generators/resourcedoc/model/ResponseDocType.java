/*     */ package com.sun.jersey.server.wadl.generators.resourcedoc.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElementWrapper;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name="responseDoc", propOrder={})
/*     */ public class ResponseDocType
/*     */ {
/*     */   private String returnDoc;
/*     */   @XmlElementWrapper(name="wadlParams")
/*     */   protected List<WadlParamType> wadlParam;
/*     */   @XmlElementWrapper(name="representations")
/*     */   protected List<RepresentationDocType> representation;
/*     */   
/*     */   public List<WadlParamType> getWadlParams()
/*     */   {
/*  69 */     if (this.wadlParam == null) {
/*  70 */       this.wadlParam = new ArrayList();
/*     */     }
/*  72 */     return this.wadlParam;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<RepresentationDocType> getRepresentations()
/*     */   {
/*  79 */     if (this.representation == null) {
/*  80 */       this.representation = new ArrayList();
/*     */     }
/*  82 */     return this.representation;
/*     */   }
/*     */   
/*     */   public boolean hasRepresentations() {
/*  86 */     return (this.representation != null) && (!this.representation.isEmpty());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getReturnDoc()
/*     */   {
/*  93 */     return this.returnDoc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setReturnDoc(String returnDoc)
/*     */   {
/* 100 */     this.returnDoc = returnDoc;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\wadl\generators\resourcedoc\model\ResponseDocType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */