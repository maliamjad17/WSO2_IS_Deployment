/*     */ package com.sun.jersey.server.impl.container.filter;
/*     */ 
/*     */ import com.sun.jersey.api.core.ResourceConfig;
/*     */ import com.sun.jersey.api.model.AbstractMethod;
/*     */ import com.sun.jersey.core.spi.component.ProviderFactory;
/*     */ import com.sun.jersey.core.spi.component.ProviderServices;
/*     */ import com.sun.jersey.spi.container.ContainerRequestFilter;
/*     */ import com.sun.jersey.spi.container.ContainerResponseFilter;
/*     */ import com.sun.jersey.spi.container.ResourceFilter;
/*     */ import com.sun.jersey.spi.container.ResourceFilterFactory;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FilterFactory
/*     */ {
/*  59 */   private static final Logger LOGGER = Logger.getLogger(FilterFactory.class.getName());
/*     */   
/*     */   private final ProviderServices providerServices;
/*     */   
/*  63 */   private final List<ContainerRequestFilter> requestFilters = new LinkedList();
/*     */   
/*  65 */   private final List<ContainerResponseFilter> responseFilters = new LinkedList();
/*     */   
/*  67 */   private final List<ResourceFilterFactory> resourceFilterFactories = new LinkedList();
/*     */   
/*     */   public FilterFactory(ProviderServices providerServices) {
/*  70 */     this.providerServices = providerServices;
/*     */   }
/*     */   
/*     */   public void init(ResourceConfig resourceConfig)
/*     */   {
/*  75 */     this.requestFilters.addAll(getFilters(ContainerRequestFilter.class, resourceConfig.getContainerRequestFilters()));
/*     */     
/*     */ 
/*     */ 
/*  79 */     this.requestFilters.addAll(this.providerServices.getServices(ContainerRequestFilter.class));
/*     */     
/*     */ 
/*  82 */     this.responseFilters.addAll(getFilters(ContainerResponseFilter.class, resourceConfig.getContainerResponseFilters()));
/*     */     
/*     */ 
/*     */ 
/*  86 */     this.responseFilters.addAll(this.providerServices.getServices(ContainerResponseFilter.class));
/*     */     
/*     */ 
/*  89 */     this.resourceFilterFactories.addAll(getFilters(ResourceFilterFactory.class, resourceConfig.getResourceFilterFactories()));
/*     */     
/*     */ 
/*     */ 
/*  93 */     this.resourceFilterFactories.addAll(this.providerServices.getServices(ResourceFilterFactory.class));
/*  94 */     this.resourceFilterFactories.add(new AnnotationResourceFilterFactory(this));
/*     */   }
/*     */   
/*     */   public List<ContainerRequestFilter> getRequestFilters() {
/*  98 */     return this.requestFilters;
/*     */   }
/*     */   
/*     */   public List<ContainerResponseFilter> getResponseFilters() {
/* 102 */     return this.responseFilters;
/*     */   }
/*     */   
/*     */   public List<ResourceFilter> getResourceFilters(AbstractMethod am) {
/* 106 */     List<ResourceFilter> resourceFilters = new LinkedList();
/* 107 */     for (ResourceFilterFactory rff : this.resourceFilterFactories) {
/* 108 */       List<ResourceFilter> rfs = rff.create(am);
/* 109 */       if (rfs != null)
/* 110 */         resourceFilters.addAll(rfs);
/*     */     }
/* 112 */     return resourceFilters;
/*     */   }
/*     */   
/*     */   public List<ResourceFilter> getResourceFilters(Class<? extends ResourceFilter>[] classes) {
/* 116 */     if ((classes == null) || (classes.length == 0)) {
/* 117 */       return Collections.EMPTY_LIST;
/*     */     }
/* 119 */     return this.providerServices.getInstances(ResourceFilter.class, classes);
/*     */   }
/*     */   
/*     */   public static List<ContainerRequestFilter> getRequestFilters(List<ResourceFilter> resourceFilters) {
/* 123 */     List<ContainerRequestFilter> filters = new LinkedList();
/* 124 */     for (ResourceFilter rf : resourceFilters) {
/* 125 */       ContainerRequestFilter crf = rf.getRequestFilter();
/* 126 */       if (crf != null)
/* 127 */         filters.add(crf);
/*     */     }
/* 129 */     return filters;
/*     */   }
/*     */   
/*     */   public static List<ContainerResponseFilter> getResponseFilters(List<ResourceFilter> resourceFilters) {
/* 133 */     List<ContainerResponseFilter> filters = new LinkedList();
/* 134 */     for (ResourceFilter rf : resourceFilters) {
/* 135 */       ContainerResponseFilter crf = rf.getResponseFilter();
/* 136 */       if (crf != null)
/* 137 */         filters.add(crf);
/*     */     }
/* 139 */     return filters;
/*     */   }
/*     */   
/*     */   private <T> List<T> getFilters(Class<T> c, List<?> l) {
/* 143 */     List<T> f = new LinkedList();
/* 144 */     for (Object o : l) {
/* 145 */       if ((o instanceof String)) {
/* 146 */         f.addAll(this.providerServices.getInstances(c, ResourceConfig.getElements(new String[] { (String)o }, " ,;")));
/*     */       }
/* 148 */       else if ((o instanceof String[])) {
/* 149 */         f.addAll(this.providerServices.getInstances(c, ResourceConfig.getElements((String[])o, " ,;")));
/*     */       }
/* 151 */       else if (c.isInstance(o)) {
/* 152 */         f.add(c.cast(o));
/* 153 */       } else if ((o instanceof Class)) {
/* 154 */         Class fc = (Class)o;
/* 155 */         if (c.isAssignableFrom(fc)) {
/* 156 */           f.addAll(this.providerServices.getInstances(c, new Class[] { fc }));
/*     */         } else {
/* 158 */           LOGGER.severe("The filter, of type" + o.getClass().getName() + ", MUST be of the type Class<? extends" + c.getName() + ">" + ". The filter is ignored.");
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 164 */         LOGGER.severe("The filter, of type" + o.getClass().getName() + ", MUST be of the type String, String[], Class<? extends " + c.getName() + ">, or an instance of " + c.getName() + ". The filter is ignored.");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 170 */     this.providerServices.getComponentProviderFactory().injectOnProviderInstances(f);
/* 171 */     return f;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\container\filter\FilterFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */