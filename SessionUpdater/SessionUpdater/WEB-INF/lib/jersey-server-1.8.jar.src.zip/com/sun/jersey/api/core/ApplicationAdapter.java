/*    */ package com.sun.jersey.api.core;
/*    */ 
/*    */ import java.util.Set;
/*    */ import javax.ws.rs.core.Application;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApplicationAdapter
/*    */   extends DefaultResourceConfig
/*    */ {
/*    */   public ApplicationAdapter(Application ac)
/*    */   {
/* 54 */     if (ac.getClasses() != null)
/* 55 */       getClasses().addAll(ac.getClasses());
/* 56 */     if (ac.getSingletons() != null) {
/* 57 */       getSingletons().addAll(ac.getSingletons());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\core\ApplicationAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */