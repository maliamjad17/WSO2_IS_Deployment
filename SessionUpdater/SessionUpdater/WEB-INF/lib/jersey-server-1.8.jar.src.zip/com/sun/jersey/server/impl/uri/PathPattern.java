/*     */ package com.sun.jersey.server.impl.uri;
/*     */ 
/*     */ import com.sun.jersey.api.uri.UriPattern;
/*     */ import com.sun.jersey.api.uri.UriTemplate;
/*     */ import java.util.Comparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PathPattern
/*     */   extends UriPattern
/*     */ {
/*  58 */   public static final PathPattern EMPTY_PATH = new PathPattern();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String RIGHT_HAND_SIDE = "(/.*)?";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  69 */   public static final Comparator<PathPattern> COMPARATOR = new Comparator() {
/*     */     public int compare(PathPattern o1, PathPattern o2) {
/*  71 */       return UriTemplate.COMPARATOR.compare(o1.template, o2.template);
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final UriTemplate template;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private PathPattern()
/*     */   {
/*  89 */     this.template = UriTemplate.EMPTY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PathPattern(UriTemplate template)
/*     */   {
/*  97 */     super(postfixWithCapturingGroup(template.getPattern().getRegex()), indexCapturingGroup(template.getPattern().getGroupIndexes()));
/*     */     
/*     */ 
/*     */ 
/* 101 */     this.template = template;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PathPattern(UriTemplate template, String rightHandSide)
/*     */   {
/* 110 */     super(postfixWithCapturingGroup(template.getPattern().getRegex(), rightHandSide), indexCapturingGroup(template.getPattern().getGroupIndexes()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 117 */     this.template = template;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriTemplate getTemplate()
/*     */   {
/* 125 */     return this.template;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String postfixWithCapturingGroup(String regex)
/*     */   {
/* 135 */     return postfixWithCapturingGroup(regex, "(/.*)?");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String postfixWithCapturingGroup(String regex, String rightHandSide)
/*     */   {
/* 149 */     return (regex.endsWith("/") ? regex.substring(0, regex.length() - 1) : regex) + rightHandSide;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int[] indexCapturingGroup(int[] indexes)
/*     */   {
/* 162 */     if (indexes.length == 0) {
/* 163 */       return indexes;
/*     */     }
/* 165 */     int[] cgIndexes = new int[indexes.length + 1];
/* 166 */     System.arraycopy(indexes, 0, cgIndexes, 0, indexes.length);
/* 167 */     cgIndexes[indexes.length] = (cgIndexes[(indexes.length - 1)] + 1);
/* 168 */     return cgIndexes;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\uri\PathPattern.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */