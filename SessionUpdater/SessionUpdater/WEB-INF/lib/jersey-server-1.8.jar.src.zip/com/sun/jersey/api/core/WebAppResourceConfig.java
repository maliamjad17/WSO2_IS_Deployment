/*     */ package com.sun.jersey.api.core;
/*     */ 
/*     */ import com.sun.jersey.spi.scanning.WebAppResourcesScanner;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.servlet.ServletContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebAppResourceConfig
/*     */   extends ScanningResourceConfig
/*     */ {
/*  63 */   private static final Logger LOGGER = Logger.getLogger(WebAppResourceConfig.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WebAppResourceConfig(Map<String, Object> props, ServletContext sc)
/*     */   {
/*  72 */     this(getPaths(props), sc);
/*     */     
/*  74 */     setPropertiesAndFeatures(props);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WebAppResourceConfig(String[] paths, ServletContext sc)
/*     */   {
/*  83 */     if ((paths == null) || (paths.length == 0)) {
/*  84 */       throw new IllegalArgumentException("Array of paths must not be null or empty");
/*     */     }
/*     */     
/*  87 */     init(paths, sc);
/*     */   }
/*     */   
/*     */   private void init(String[] paths, ServletContext sc) {
/*  91 */     if (LOGGER.isLoggable(Level.INFO)) {
/*  92 */       StringBuilder b = new StringBuilder();
/*  93 */       b.append("Scanning for root resource and provider classes in the Web app resource paths:");
/*  94 */       for (String p : paths) {
/*  95 */         b.append('\n').append("  ").append(p);
/*     */       }
/*  97 */       LOGGER.log(Level.INFO, b.toString());
/*     */     }
/*     */     
/* 100 */     init(new WebAppResourcesScanner(paths, sc));
/*     */   }
/*     */   
/*     */   private static String[] getPaths(Map<String, Object> props) {
/* 104 */     Object v = props.get("com.sun.jersey.config.property.classpath");
/* 105 */     if (v == null) {
/* 106 */       return new String[] { "/WEB-INF/lib", "/WEB-INF/classes" };
/*     */     }
/*     */     
/* 109 */     String[] paths = getPaths(v);
/* 110 */     if (paths.length == 0) {
/* 111 */       throw new IllegalArgumentException("com.sun.jersey.config.property.classpath contains no paths");
/*     */     }
/*     */     
/*     */ 
/* 115 */     return paths;
/*     */   }
/*     */   
/*     */   private static String[] getPaths(Object param) {
/* 119 */     if ((param instanceof String))
/* 120 */       return getElements(new String[] { (String)param });
/* 121 */     if ((param instanceof String[])) {
/* 122 */       return getElements((String[])param);
/*     */     }
/* 124 */     throw new IllegalArgumentException("com.sun.jersey.config.property.classpath must have a property value of type String or String[]");
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\core\WebAppResourceConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */