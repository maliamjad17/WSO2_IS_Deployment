/*    */ package com.sun.jersey.api.model;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.AnnotatedElement;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractMethod
/*    */   implements AnnotatedElement
/*    */ {
/*    */   private Method method;
/*    */   private Annotation[] annotations;
/*    */   private AbstractResource resource;
/*    */   
/*    */   public AbstractMethod(AbstractResource resource, Method method, Annotation[] annotations)
/*    */   {
/* 58 */     this.method = method;
/* 59 */     this.annotations = annotations;
/* 60 */     this.resource = resource;
/*    */   }
/*    */   
/*    */   public AbstractResource getResource() {
/* 64 */     return this.resource;
/*    */   }
/*    */   
/*    */   public Method getMethod() {
/* 68 */     return this.method;
/*    */   }
/*    */   
/*    */   public <T extends Annotation> T getAnnotation(Class<T> annotationType)
/*    */   {
/* 73 */     for (Annotation a : this.annotations) {
/* 74 */       if (annotationType == a.annotationType())
/* 75 */         return (Annotation)annotationType.cast(a);
/*    */     }
/* 77 */     return null;
/*    */   }
/*    */   
/*    */   public Annotation[] getAnnotations()
/*    */   {
/* 82 */     return (Annotation[])this.annotations.clone();
/*    */   }
/*    */   
/*    */   public Annotation[] getDeclaredAnnotations()
/*    */   {
/* 87 */     return (Annotation[])this.annotations.clone();
/*    */   }
/*    */   
/*    */   public boolean isAnnotationPresent(Class<? extends Annotation> annotationType)
/*    */   {
/* 92 */     return getAnnotation(annotationType) != null;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\model\AbstractMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */