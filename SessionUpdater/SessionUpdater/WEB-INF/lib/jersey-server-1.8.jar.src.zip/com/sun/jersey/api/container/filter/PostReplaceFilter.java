/*    */ package com.sun.jersey.api.container.filter;
/*    */ 
/*    */ import com.sun.jersey.spi.container.ContainerRequest;
/*    */ import com.sun.jersey.spi.container.ContainerRequestFilter;
/*    */ import javax.ws.rs.core.MultivaluedMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PostReplaceFilter
/*    */   implements ContainerRequestFilter
/*    */ {
/*    */   public ContainerRequest filter(ContainerRequest request)
/*    */   {
/* 74 */     if (!request.getMethod().equalsIgnoreCase("POST")) {
/* 75 */       return request;
/*    */     }
/* 77 */     String override = (String)request.getRequestHeaders().getFirst("X-HTTP-Method-Override");
/* 78 */     if (override == null)
/* 79 */       return request;
/* 80 */     override = override.trim();
/* 81 */     if (override.length() == 0) {
/* 82 */       return request;
/*    */     }
/* 84 */     request.setMethod(override);
/* 85 */     return request;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\container\filter\PostReplaceFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */