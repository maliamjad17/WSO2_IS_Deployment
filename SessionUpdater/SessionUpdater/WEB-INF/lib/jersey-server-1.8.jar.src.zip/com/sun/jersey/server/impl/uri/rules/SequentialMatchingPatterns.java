/*     */ package com.sun.jersey.server.impl.uri.rules;
/*     */ 
/*     */ import com.sun.jersey.api.uri.UriPattern;
/*     */ import com.sun.jersey.spi.uri.rules.UriMatchResultContext;
/*     */ import com.sun.jersey.spi.uri.rules.UriRules;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.regex.MatchResult;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SequentialMatchingPatterns<R>
/*     */   implements UriRules<R>
/*     */ {
/*     */   private final List<PatternRulePair<R>> rules;
/*     */   
/*     */   public SequentialMatchingPatterns(List<PatternRulePair<R>> rules)
/*     */   {
/*  61 */     this.rules = rules;
/*     */   }
/*     */   
/*     */   public Iterator<R> match(CharSequence path, UriMatchResultContext resultContext) {
/*  65 */     return new XInterator(path, resultContext);
/*     */   }
/*     */   
/*     */   private final class XInterator implements Iterator<R>
/*     */   {
/*     */     private final CharSequence path;
/*     */     private final UriMatchResultContext resultContext;
/*     */     private final Iterator<PatternRulePair<R>> i;
/*     */     private R r;
/*     */     
/*     */     XInterator(CharSequence path, UriMatchResultContext resultContext) {
/*  76 */       this.path = path;
/*  77 */       this.resultContext = resultContext;
/*  78 */       this.i = SequentialMatchingPatterns.this.rules.iterator();
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/*  82 */       if (this.r != null) { return true;
/*     */       }
/*  84 */       while (this.i.hasNext()) {
/*  85 */         PatternRulePair<R> prp = (PatternRulePair)this.i.next();
/*  86 */         MatchResult mr = prp.p.match(this.path);
/*  87 */         if (mr != null) {
/*  88 */           this.resultContext.setMatchResult(mr);
/*  89 */           this.r = prp.r;
/*  90 */           return true;
/*     */         }
/*     */       }
/*  93 */       this.r = null;
/*  94 */       return false;
/*     */     }
/*     */     
/*     */     public R next() {
/*  98 */       if (!hasNext()) { throw new NoSuchElementException();
/*     */       }
/* 100 */       R _r = this.r;
/* 101 */       this.r = null;
/* 102 */       return _r;
/*     */     }
/*     */     
/*     */     public void remove() {
/* 106 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\uri\rules\SequentialMatchingPatterns.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */