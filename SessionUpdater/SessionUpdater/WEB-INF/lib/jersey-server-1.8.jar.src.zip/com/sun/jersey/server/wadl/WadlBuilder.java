/*     */ package com.sun.jersey.server.wadl;
/*     */ 
/*     */ import com.sun.jersey.api.model.AbstractMethod;
/*     */ import com.sun.jersey.api.model.AbstractResource;
/*     */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*     */ import com.sun.jersey.api.model.AbstractSubResourceLocator;
/*     */ import com.sun.jersey.api.model.AbstractSubResourceMethod;
/*     */ import com.sun.jersey.api.model.Parameter;
/*     */ import com.sun.jersey.api.model.Parameter.Source;
/*     */ import com.sun.jersey.api.model.Parameterized;
/*     */ import com.sun.jersey.api.model.PathValue;
/*     */ import com.sun.jersey.server.impl.BuildId;
/*     */ import com.sun.jersey.server.impl.modelapi.annotation.IntrospectionModeller;
/*     */ import com.sun.research.ws.wadl.Application;
/*     */ import com.sun.research.ws.wadl.Doc;
/*     */ import com.sun.research.ws.wadl.Param;
/*     */ import com.sun.research.ws.wadl.ParamStyle;
/*     */ import com.sun.research.ws.wadl.RepresentationType;
/*     */ import com.sun.research.ws.wadl.Request;
/*     */ import com.sun.research.ws.wadl.Resource;
/*     */ import com.sun.research.ws.wadl.Resources;
/*     */ import com.sun.research.ws.wadl.Response;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.ws.rs.FormParam;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WadlBuilder
/*     */ {
/*     */   private WadlGenerator _wadlGenerator;
/*     */   
/*     */   public WadlBuilder()
/*     */   {
/*  87 */     this(new WadlGeneratorImpl());
/*     */   }
/*     */   
/*     */   public WadlBuilder(WadlGenerator wadlGenerator) {
/*  91 */     this._wadlGenerator = wadlGenerator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Application generate(Set<AbstractResource> resources)
/*     */   {
/* 100 */     Application wadlApplication = this._wadlGenerator.createApplication();
/* 101 */     Resources wadlResources = this._wadlGenerator.createResources();
/*     */     
/*     */ 
/* 104 */     for (AbstractResource r : resources) {
/* 105 */       Resource wadlResource = generateResource(r, null);
/* 106 */       wadlResources.getResource().add(wadlResource);
/*     */     }
/* 108 */     wadlApplication.setResources(wadlResources);
/*     */     
/* 110 */     addVersion(wadlApplication);
/* 111 */     return wadlApplication;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Application generate(AbstractResource resource)
/*     */   {
/* 120 */     Application wadlApplication = this._wadlGenerator.createApplication();
/* 121 */     Resources wadlResources = this._wadlGenerator.createResources();
/* 122 */     Resource wadlResource = generateResource(resource, null);
/* 123 */     wadlResources.getResource().add(wadlResource);
/* 124 */     wadlApplication.setResources(wadlResources);
/*     */     
/* 126 */     addVersion(wadlApplication);
/* 127 */     return wadlApplication;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Application generate(AbstractResource resource, String path)
/*     */   {
/* 138 */     Application wadlApplication = this._wadlGenerator.createApplication();
/* 139 */     Resources wadlResources = this._wadlGenerator.createResources();
/* 140 */     Resource wadlResource = generateSubResource(resource, path);
/* 141 */     wadlResources.getResource().add(wadlResource);
/* 142 */     wadlApplication.setResources(wadlResources);
/*     */     
/* 144 */     addVersion(wadlApplication);
/* 145 */     return wadlApplication;
/*     */   }
/*     */   
/*     */   private void addVersion(Application wadlApplication)
/*     */   {
/* 150 */     Doc d = new Doc();
/* 151 */     d.getOtherAttributes().put(new QName("http://jersey.java.net/", "generatedBy", "jersey"), BuildId.getBuildId());
/*     */     
/* 153 */     wadlApplication.getDoc().add(0, d);
/*     */   }
/*     */   
/*     */   private com.sun.research.ws.wadl.Method generateMethod(AbstractResource r, Map<String, Param> wadlResourceParams, AbstractResourceMethod m) {
/* 157 */     com.sun.research.ws.wadl.Method wadlMethod = this._wadlGenerator.createMethod(r, m);
/*     */     
/* 159 */     Request wadlRequest = generateRequest(r, m, wadlResourceParams);
/* 160 */     if (wadlRequest != null) {
/* 161 */       wadlMethod.setRequest(wadlRequest);
/*     */     }
/*     */     
/* 164 */     Response wadlResponse = generateResponse(r, m);
/* 165 */     if (wadlResponse != null) {
/* 166 */       wadlMethod.setResponse(wadlResponse);
/*     */     }
/* 168 */     return wadlMethod;
/*     */   }
/*     */   
/*     */   private Request generateRequest(AbstractResource r, AbstractResourceMethod m, Map<String, Param> wadlResourceParams)
/*     */   {
/* 173 */     if (m.getParameters().isEmpty()) {
/* 174 */       return null;
/*     */     }
/*     */     
/* 177 */     Request wadlRequest = this._wadlGenerator.createRequest(r, m);
/*     */     
/* 179 */     for (Parameter p : m.getParameters()) {
/* 180 */       if (p.getSource() == Parameter.Source.ENTITY) {
/* 181 */         for (MediaType mediaType : m.getSupportedInputTypes()) {
/* 182 */           setRepresentationForMediaType(r, m, mediaType, wadlRequest);
/*     */         }
/* 184 */       } else if (p.getAnnotation().annotationType() == FormParam.class)
/*     */       {
/* 186 */         List<MediaType> supportedInputTypes = m.getSupportedInputTypes();
/* 187 */         if ((supportedInputTypes.isEmpty()) || ((supportedInputTypes.size() == 1) && (((MediaType)supportedInputTypes.get(0)).isWildcardType())))
/*     */         {
/* 189 */           supportedInputTypes = Collections.singletonList(MediaType.APPLICATION_FORM_URLENCODED_TYPE);
/*     */         }
/*     */         
/* 192 */         for (MediaType mediaType : supportedInputTypes) {
/* 193 */           RepresentationType wadlRepresentation = setRepresentationForMediaType(r, m, mediaType, wadlRequest);
/* 194 */           if (getParamByName(wadlRepresentation.getParam(), p.getSourceName()) == null) {
/* 195 */             Param wadlParam = generateParam(r, m, p);
/* 196 */             if (wadlParam != null) {
/* 197 */               wadlRepresentation.getParam().add(wadlParam);
/*     */             }
/*     */           }
/*     */         }
/*     */       } else {
/* 202 */         Param wadlParam = generateParam(r, m, p);
/* 203 */         if (wadlParam != null)
/*     */         {
/*     */ 
/* 206 */           if (wadlParam.getStyle() == ParamStyle.TEMPLATE) {
/* 207 */             wadlResourceParams.put(wadlParam.getName(), wadlParam);
/*     */           } else
/* 209 */             wadlRequest.getParam().add(wadlParam);
/*     */         }
/*     */       }
/*     */     }
/* 213 */     if (wadlRequest.getRepresentation().size() + wadlRequest.getParam().size() == 0) {
/* 214 */       return null;
/*     */     }
/* 216 */     return wadlRequest;
/*     */   }
/*     */   
/*     */   private Param getParamByName(List<Param> params, String name)
/*     */   {
/* 221 */     for (Param param : params) {
/* 222 */       if (param.getName().equals(name)) {
/* 223 */         return param;
/*     */       }
/*     */     }
/* 226 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private RepresentationType setRepresentationForMediaType(AbstractResource r, AbstractResourceMethod m, MediaType mediaType, Request wadlRequest)
/*     */   {
/* 242 */     RepresentationType wadlRepresentation = getRepresentationByMediaType(wadlRequest.getRepresentation(), mediaType);
/* 243 */     if (wadlRepresentation == null) {
/* 244 */       wadlRepresentation = this._wadlGenerator.createRequestRepresentation(r, m, mediaType);
/* 245 */       wadlRequest.getRepresentation().add(wadlRepresentation);
/*     */     }
/* 247 */     return wadlRepresentation;
/*     */   }
/*     */   
/*     */   private RepresentationType getRepresentationByMediaType(List<RepresentationType> representations, MediaType mediaType)
/*     */   {
/* 252 */     for (RepresentationType representation : representations) {
/* 253 */       if (mediaType.toString().equals(representation.getMediaType())) {
/* 254 */         return representation;
/*     */       }
/*     */     }
/* 257 */     return null;
/*     */   }
/*     */   
/*     */   private Param generateParam(AbstractResource r, AbstractMethod m, Parameter p) {
/* 261 */     if ((p.getSource() == Parameter.Source.ENTITY) || (p.getSource() == Parameter.Source.CONTEXT)) {
/* 262 */       return null;
/*     */     }
/* 264 */     Param wadlParam = this._wadlGenerator.createParam(r, m, p);
/* 265 */     return wadlParam;
/*     */   }
/*     */   
/*     */   private Resource generateResource(AbstractResource r, String path) {
/* 269 */     return generateResource(r, path, Collections.emptySet());
/*     */   }
/*     */   
/*     */   private Resource generateResource(AbstractResource r, String path, Set<Class<?>> visitedClasses) {
/* 273 */     Resource wadlResource = this._wadlGenerator.createResource(r, path);
/*     */     
/*     */ 
/* 276 */     if (visitedClasses.contains(r.getResourceClass())) {
/* 277 */       return wadlResource;
/*     */     }
/* 279 */     visitedClasses = new HashSet(visitedClasses);
/* 280 */     visitedClasses.add(r.getResourceClass());
/*     */     
/*     */ 
/* 283 */     Map<String, Param> wadlResourceParams = new HashMap();
/*     */     
/*     */ 
/*     */ 
/* 287 */     List<Parameterized> fieldsOrSetters = new LinkedList();
/*     */     
/* 289 */     if (r.getFields() != null) {
/* 290 */       fieldsOrSetters.addAll(r.getFields());
/*     */     }
/* 292 */     if (r.getSetterMethods() != null) {
/* 293 */       fieldsOrSetters.addAll(r.getSetterMethods());
/*     */     }
/*     */     
/* 296 */     for (Parameterized f : fieldsOrSetters) {
/* 297 */       for (Parameter fp : f.getParameters()) {
/* 298 */         Param wadlParam = generateParam(r, null, fp);
/* 299 */         if (wadlParam != null) {
/* 300 */           wadlResource.getParam().add(wadlParam);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 305 */     for (AbstractResourceMethod m : r.getResourceMethods()) {
/* 306 */       com.sun.research.ws.wadl.Method wadlMethod = generateMethod(r, wadlResourceParams, m);
/* 307 */       wadlResource.getMethodOrResource().add(wadlMethod);
/*     */     }
/*     */     
/* 310 */     for (Param wadlParam : wadlResourceParams.values()) {
/* 311 */       wadlResource.getParam().add(wadlParam);
/*     */     }
/*     */     
/*     */ 
/* 315 */     Map<String, Resource> wadlSubResources = new HashMap();
/* 316 */     Map<String, Map<String, Param>> wadlSubResourcesParams = new HashMap();
/*     */     
/* 318 */     for (AbstractSubResourceMethod m : r.getSubResourceMethods())
/*     */     {
/* 320 */       String template = m.getPath().getValue();
/* 321 */       Resource wadlSubResource = (Resource)wadlSubResources.get(template);
/* 322 */       Map<String, Param> wadlSubResourceParams = (Map)wadlSubResourcesParams.get(template);
/* 323 */       if (wadlSubResource == null) {
/* 324 */         wadlSubResource = new Resource();
/* 325 */         wadlSubResource.setPath(template);
/* 326 */         wadlSubResources.put(template, wadlSubResource);
/* 327 */         wadlSubResourceParams = new HashMap();
/* 328 */         wadlSubResourcesParams.put(template, wadlSubResourceParams);
/* 329 */         wadlResource.getMethodOrResource().add(wadlSubResource);
/*     */       }
/* 331 */       com.sun.research.ws.wadl.Method wadlMethod = generateMethod(r, wadlSubResourceParams, m);
/* 332 */       wadlSubResource.getMethodOrResource().add(wadlMethod);
/*     */     }
/*     */     
/* 335 */     for (Map.Entry<String, Resource> e : wadlSubResources.entrySet()) {
/* 336 */       String template = (String)e.getKey();
/* 337 */       wadlSubResource = (Resource)e.getValue();
/* 338 */       Map<String, Param> wadlSubResourceParams = (Map)wadlSubResourcesParams.get(template);
/* 339 */       for (Param wadlParam : wadlSubResourceParams.values()) {
/* 340 */         wadlSubResource.getParam().add(wadlParam);
/*     */       }
/*     */     }
/*     */     
/*     */     Resource wadlSubResource;
/* 345 */     for (Iterator i$ = r.getSubResourceLocators().iterator(); i$.hasNext();) { l = (AbstractSubResourceLocator)i$.next();
/* 346 */       AbstractResource subResource = IntrospectionModeller.createResource(l.getMethod().getReturnType());
/*     */       
/* 348 */       wadlSubResource = generateResource(subResource, l.getPath().getValue(), visitedClasses);
/*     */       
/* 350 */       wadlResource.getMethodOrResource().add(wadlSubResource);
/*     */       
/* 352 */       for (Parameter p : l.getParameters()) {
/* 353 */         Param wadlParam = generateParam(r, l, p);
/* 354 */         if ((wadlParam != null) && (wadlParam.getStyle() == ParamStyle.TEMPLATE))
/* 355 */           wadlSubResource.getParam().add(wadlParam);
/*     */       } }
/*     */     AbstractSubResourceLocator l;
/*     */     Resource wadlSubResource;
/* 359 */     return wadlResource;
/*     */   }
/*     */   
/*     */   private Resource generateSubResource(AbstractResource r, String path) {
/* 363 */     Resource wadlResource = new Resource();
/* 364 */     if (r.isRootResource()) {
/* 365 */       StringBuilder b = new StringBuilder(r.getPath().getValue());
/* 366 */       if ((!r.getPath().getValue().endsWith("/")) && (!path.startsWith("/"))) {
/* 367 */         b.append("/");
/*     */       }
/* 369 */       b.append(path);
/* 370 */       wadlResource.setPath(b.toString());
/*     */     }
/*     */     
/* 373 */     Map<String, Param> wadlSubResourceParams = new HashMap();
/* 374 */     for (AbstractSubResourceMethod m : r.getSubResourceMethods())
/*     */     {
/* 376 */       String template = m.getPath().getValue();
/* 377 */       if (template.equals(path))
/*     */       {
/*     */ 
/* 380 */         com.sun.research.ws.wadl.Method wadlMethod = generateMethod(r, wadlSubResourceParams, m);
/* 381 */         wadlResource.getMethodOrResource().add(wadlMethod);
/*     */       }
/*     */     }
/* 384 */     for (Param wadlParam : wadlSubResourceParams.values()) {
/* 385 */       wadlResource.getParam().add(wadlParam);
/*     */     }
/*     */     
/* 388 */     return wadlResource;
/*     */   }
/*     */   
/*     */   private Response generateResponse(AbstractResource r, AbstractResourceMethod m) {
/* 392 */     if (m.getMethod().getReturnType() == Void.TYPE) {
/* 393 */       return null;
/*     */     }
/* 395 */     Response wadlResponse = this._wadlGenerator.createResponse(r, m);
/* 396 */     return wadlResponse;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\wadl\WadlBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */