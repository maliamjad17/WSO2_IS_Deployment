/*     */ package com.sun.jersey.server.impl.model.method.dispatch;
/*     */ 
/*     */ import com.sun.jersey.api.JResponse;
/*     */ import com.sun.jersey.api.core.HttpContext;
/*     */ import com.sun.jersey.api.core.HttpResponseContext;
/*     */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*     */ import com.sun.jersey.core.spi.factory.ResponseBuilderImpl;
/*     */ import com.sun.jersey.server.impl.inject.InjectableValuesProvider;
/*     */ import com.sun.jersey.server.impl.inject.ServerInjectableProviderContext;
/*     */ import com.sun.jersey.spi.container.JavaMethodInvoker;
/*     */ import com.sun.jersey.spi.container.JavaMethodInvokerFactory;
/*     */ import com.sun.jersey.spi.container.ResourceMethodCustomInvokerDispatchProvider;
/*     */ import com.sun.jersey.spi.container.ResourceMethodDispatchProvider;
/*     */ import com.sun.jersey.spi.dispatch.RequestDispatcher;
/*     */ import com.sun.jersey.spi.inject.Errors;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.List;
/*     */ import javax.ws.rs.core.Context;
/*     */ import javax.ws.rs.core.GenericEntity;
/*     */ import javax.ws.rs.core.Response;
/*     */ import javax.ws.rs.core.Response.ResponseBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractResourceMethodDispatchProvider
/*     */   implements ResourceMethodDispatchProvider, ResourceMethodCustomInvokerDispatchProvider
/*     */ {
/*     */   @Context
/*     */   private ServerInjectableProviderContext sipc;
/*     */   
/*     */   public RequestDispatcher create(AbstractResourceMethod abstractResourceMethod)
/*     */   {
/*  78 */     return create(abstractResourceMethod, JavaMethodInvokerFactory.getDefault());
/*     */   }
/*     */   
/*     */ 
/*     */   public RequestDispatcher create(AbstractResourceMethod abstractResourceMethod, JavaMethodInvoker invoker)
/*     */   {
/*  84 */     InjectableValuesProvider pp = getInjectableValuesProvider(abstractResourceMethod);
/*  85 */     if (pp == null) {
/*  86 */       return null;
/*     */     }
/*     */     
/*  89 */     if (pp.getInjectables().contains(null))
/*     */     {
/*  91 */       for (int i = 0; i < pp.getInjectables().size(); i++) {
/*  92 */         if (pp.getInjectables().get(i) == null) {
/*  93 */           Errors.missingDependency(abstractResourceMethod.getMethod(), i);
/*     */         }
/*     */       }
/*  96 */       return null;
/*     */     }
/*     */     
/*  99 */     Class<?> returnType = abstractResourceMethod.getReturnType();
/* 100 */     if (Response.class.isAssignableFrom(returnType))
/* 101 */       return new ResponseOutInvoker(abstractResourceMethod, pp, invoker);
/* 102 */     if (JResponse.class.isAssignableFrom(returnType))
/* 103 */       return new JResponseOutInvoker(abstractResourceMethod, pp, invoker);
/* 104 */     if (returnType != Void.TYPE) {
/* 105 */       if ((returnType == Object.class) || (GenericEntity.class.isAssignableFrom(returnType))) {
/* 106 */         return new ObjectOutInvoker(abstractResourceMethod, pp, invoker);
/*     */       }
/* 108 */       return new TypeOutInvoker(abstractResourceMethod, pp, invoker);
/*     */     }
/*     */     
/* 111 */     return new VoidOutInvoker(abstractResourceMethod, pp, invoker);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ServerInjectableProviderContext getInjectableProviderContext()
/*     */   {
/* 123 */     return this.sipc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract InjectableValuesProvider getInjectableValuesProvider(AbstractResourceMethod paramAbstractResourceMethod);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static abstract class EntityParamInInvoker
/*     */     extends ResourceJavaMethodDispatcher
/*     */   {
/*     */     private final InjectableValuesProvider pp;
/*     */     
/*     */ 
/*     */ 
/*     */     EntityParamInInvoker(AbstractResourceMethod abstractResourceMethod, InjectableValuesProvider pp)
/*     */     {
/* 143 */       this(abstractResourceMethod, pp, JavaMethodInvokerFactory.getDefault());
/*     */     }
/*     */     
/*     */     EntityParamInInvoker(AbstractResourceMethod abstractResourceMethod, InjectableValuesProvider pp, JavaMethodInvoker invoker)
/*     */     {
/* 148 */       super(invoker);
/* 149 */       this.pp = pp;
/*     */     }
/*     */     
/*     */     final Object[] getParams(HttpContext context) {
/* 153 */       return this.pp.getInjectableValues(context);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class VoidOutInvoker extends AbstractResourceMethodDispatchProvider.EntityParamInInvoker
/*     */   {
/*     */     VoidOutInvoker(AbstractResourceMethod abstractResourceMethod, InjectableValuesProvider pp, JavaMethodInvoker invoker) {
/* 160 */       super(pp, invoker);
/*     */     }
/*     */     
/*     */     public void _dispatch(Object resource, HttpContext context)
/*     */       throws IllegalAccessException, InvocationTargetException
/*     */     {
/* 166 */       Object[] params = getParams(context);
/* 167 */       this.invoker.invoke(this.method, resource, params);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class TypeOutInvoker extends AbstractResourceMethodDispatchProvider.EntityParamInInvoker
/*     */   {
/*     */     private final Type t;
/*     */     
/*     */     TypeOutInvoker(AbstractResourceMethod abstractResourceMethod, InjectableValuesProvider pp, JavaMethodInvoker invoker) {
/* 176 */       super(pp, invoker);
/* 177 */       this.t = abstractResourceMethod.getGenericReturnType();
/*     */     }
/*     */     
/*     */     public void _dispatch(Object resource, HttpContext context)
/*     */       throws IllegalAccessException, InvocationTargetException
/*     */     {
/* 183 */       Object[] params = getParams(context);
/*     */       
/* 185 */       Object o = this.invoker.invoke(this.method, resource, params);
/* 186 */       if (o != null) {
/* 187 */         Response r = new ResponseBuilderImpl().entityWithType(o, this.t).status(200).build();
/*     */         
/* 189 */         context.getResponse().setResponse(r);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class ResponseOutInvoker extends AbstractResourceMethodDispatchProvider.EntityParamInInvoker
/*     */   {
/*     */     ResponseOutInvoker(AbstractResourceMethod abstractResourceMethod, InjectableValuesProvider pp, JavaMethodInvoker invoker) {
/* 197 */       super(pp, invoker);
/*     */     }
/*     */     
/*     */     public void _dispatch(Object resource, HttpContext context)
/*     */       throws IllegalAccessException, InvocationTargetException
/*     */     {
/* 203 */       Object[] params = getParams(context);
/*     */       
/* 205 */       Response r = (Response)this.invoker.invoke(this.method, resource, params);
/* 206 */       if (r != null) {
/* 207 */         context.getResponse().setResponse(r);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class JResponseOutInvoker extends AbstractResourceMethodDispatchProvider.EntityParamInInvoker
/*     */   {
/*     */     private final Type t;
/*     */     
/*     */     JResponseOutInvoker(AbstractResourceMethod abstractResourceMethod, InjectableValuesProvider pp, JavaMethodInvoker invoker) {
/* 217 */       super(pp);
/* 218 */       Type jResponseType = abstractResourceMethod.getGenericReturnType();
/* 219 */       if ((jResponseType instanceof ParameterizedType)) {
/* 220 */         ParameterizedType pt = (ParameterizedType)jResponseType;
/* 221 */         if (pt.getRawType().equals(JResponse.class)) {
/* 222 */           this.t = ((ParameterizedType)jResponseType).getActualTypeArguments()[0];
/*     */         } else {
/* 224 */           this.t = null;
/*     */         }
/*     */       } else {
/* 227 */         this.t = null;
/*     */       }
/*     */     }
/*     */     
/*     */     public void _dispatch(Object resource, HttpContext context)
/*     */       throws IllegalAccessException, InvocationTargetException
/*     */     {
/* 234 */       Object[] params = getParams(context);
/*     */       
/* 236 */       JResponse<?> r = (JResponse)this.invoker.invoke(this.method, resource, params);
/* 237 */       if (r != null) {
/* 238 */         if (this.t == null) {
/* 239 */           context.getResponse().setResponse(r.toResponse());
/*     */         } else {
/* 241 */           context.getResponse().setResponse(r.toResponse(this.t));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class ObjectOutInvoker extends AbstractResourceMethodDispatchProvider.EntityParamInInvoker
/*     */   {
/*     */     ObjectOutInvoker(AbstractResourceMethod abstractResourceMethod, InjectableValuesProvider pp, JavaMethodInvoker invoker) {
/* 250 */       super(pp, invoker);
/*     */     }
/*     */     
/*     */     public void _dispatch(Object resource, HttpContext context)
/*     */       throws IllegalAccessException, InvocationTargetException
/*     */     {
/* 256 */       Object[] params = getParams(context);
/*     */       
/* 258 */       Object o = this.invoker.invoke(this.method, resource, params);
/*     */       
/* 260 */       if ((o instanceof Response)) {
/* 261 */         context.getResponse().setResponse((Response)o);
/* 262 */       } else if ((o instanceof JResponse)) {
/* 263 */         context.getResponse().setResponse(((JResponse)o).toResponse());
/* 264 */       } else if (o != null) {
/* 265 */         Response r = new ResponseBuilderImpl().status(200).entity(o).build();
/* 266 */         context.getResponse().setResponse(r);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\method\dispatch\AbstractResourceMethodDispatchProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */