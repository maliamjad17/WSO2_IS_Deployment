/*     */ package com.sun.jersey.server.impl.model.parameter.multivalued;
/*     */ 
/*     */ import com.sun.jersey.api.container.ContainerException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.ws.rs.WebApplicationException;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PrimitiveValueOfExtractor
/*     */   implements MultivaluedParameterExtractor
/*     */ {
/*     */   final Method valueOf;
/*     */   final String parameter;
/*     */   final String defaultStringValue;
/*     */   final Object defaultValue;
/*     */   final Object defaultDefaultValue;
/*     */   
/*     */   public PrimitiveValueOfExtractor(Method valueOf, String parameter, String defaultStringValue, Object defaultDefaultValue)
/*     */     throws IllegalAccessException, InvocationTargetException
/*     */   {
/*  64 */     this.valueOf = valueOf;
/*  65 */     this.parameter = parameter;
/*  66 */     this.defaultStringValue = defaultStringValue;
/*  67 */     this.defaultValue = (defaultStringValue != null ? getValue(defaultStringValue) : null);
/*     */     
/*  69 */     this.defaultDefaultValue = defaultDefaultValue;
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/*  74 */     return this.parameter;
/*     */   }
/*     */   
/*     */   public String getDefaultStringValue()
/*     */   {
/*  79 */     return this.defaultStringValue;
/*     */   }
/*     */   
/*     */   private Object getValue(String v) {
/*     */     try {
/*  84 */       return this.valueOf.invoke(null, new Object[] { v });
/*     */     } catch (InvocationTargetException ex) {
/*  86 */       Throwable target = ex.getTargetException();
/*  87 */       if ((target instanceof WebApplicationException)) {
/*  88 */         throw ((WebApplicationException)target);
/*     */       }
/*  90 */       throw new ExtractorContainerException(target);
/*     */     }
/*     */     catch (RuntimeException ex) {
/*  93 */       throw new ContainerException(ex);
/*     */     } catch (Exception ex) {
/*  95 */       throw new ContainerException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object extract(MultivaluedMap<String, String> parameters)
/*     */   {
/* 101 */     String v = (String)parameters.getFirst(this.parameter);
/* 102 */     if ((v != null) && (!v.trim().isEmpty()))
/* 103 */       return getValue(v);
/* 104 */     if (this.defaultValue != null)
/*     */     {
/* 106 */       return this.defaultValue;
/*     */     }
/*     */     
/* 109 */     return this.defaultDefaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\parameter\multivalued\PrimitiveValueOfExtractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */