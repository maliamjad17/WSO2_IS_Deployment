/*    */ package com.sun.jersey.server.impl.template;
/*    */ 
/*    */ import com.sun.jersey.api.view.Viewable;
/*    */ import com.sun.jersey.spi.inject.ConstrainedTo;
/*    */ import com.sun.jersey.spi.inject.ServerSide;
/*    */ import com.sun.jersey.spi.template.ResolvedViewable;
/*    */ import com.sun.jersey.spi.template.TemplateContext;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Type;
/*    */ import javax.ws.rs.core.Context;
/*    */ import javax.ws.rs.core.MediaType;
/*    */ import javax.ws.rs.core.MultivaluedMap;
/*    */ import javax.ws.rs.core.UriInfo;
/*    */ import javax.ws.rs.ext.MessageBodyWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConstrainedTo(ServerSide.class)
/*    */ public final class ViewableMessageBodyWriter
/*    */   implements MessageBodyWriter<Viewable>
/*    */ {
/*    */   @Context
/*    */   UriInfo ui;
/*    */   @Context
/*    */   TemplateContext tc;
/*    */   
/*    */   public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType)
/*    */   {
/* 70 */     return Viewable.class.isAssignableFrom(type);
/*    */   }
/*    */   
/*    */ 
/*    */   public void writeTo(Viewable v, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, OutputStream entityStream)
/*    */     throws IOException
/*    */   {
/* 77 */     ResolvedViewable rv = resolve(v);
/* 78 */     if (rv == null) {
/* 79 */       throw new IOException("The template name, " + v.getTemplateName() + ", could not be resolved to a fully qualified template name");
/*    */     }
/*    */     
/*    */ 
/* 83 */     rv.writeTo(entityStream);
/*    */   }
/*    */   
/*    */   private ResolvedViewable resolve(Viewable v) {
/* 87 */     if ((v instanceof ResolvedViewable)) {
/* 88 */       return (ResolvedViewable)v;
/*    */     }
/* 90 */     return this.tc.resolveViewable(v, this.ui);
/*    */   }
/*    */   
/*    */   public long getSize(Viewable t, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType)
/*    */   {
/* 95 */     return -1L;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\template\ViewableMessageBodyWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */