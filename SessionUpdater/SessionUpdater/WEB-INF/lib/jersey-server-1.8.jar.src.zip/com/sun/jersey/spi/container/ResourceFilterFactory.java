package com.sun.jersey.spi.container;

import com.sun.jersey.api.model.AbstractMethod;
import java.util.List;

public abstract interface ResourceFilterFactory
{
  public abstract List<ResourceFilter> create(AbstractMethod paramAbstractMethod);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\container\ResourceFilterFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */