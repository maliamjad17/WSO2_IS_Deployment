package com.sun.jersey.spi.uri.rules;

public abstract interface UriRule
{
  public abstract boolean accept(CharSequence paramCharSequence, Object paramObject, UriRuleContext paramUriRuleContext);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\uri\rules\UriRule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */