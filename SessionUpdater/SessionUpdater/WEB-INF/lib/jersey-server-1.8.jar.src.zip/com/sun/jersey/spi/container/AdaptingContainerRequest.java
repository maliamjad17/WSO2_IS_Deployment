/*     */ package com.sun.jersey.spi.container;
/*     */ 
/*     */ import com.sun.jersey.api.representation.Form;
/*     */ import com.sun.jersey.core.header.InBoundHeaders;
/*     */ import com.sun.jersey.core.header.QualitySourceMediaType;
/*     */ import com.sun.jersey.spi.MessageBodyWorkers;
/*     */ import java.io.InputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.URI;
/*     */ import java.security.Principal;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import javax.ws.rs.WebApplicationException;
/*     */ import javax.ws.rs.core.Cookie;
/*     */ import javax.ws.rs.core.EntityTag;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.core.PathSegment;
/*     */ import javax.ws.rs.core.Response.ResponseBuilder;
/*     */ import javax.ws.rs.core.SecurityContext;
/*     */ import javax.ws.rs.core.UriBuilder;
/*     */ import javax.ws.rs.core.Variant;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AdaptingContainerRequest
/*     */   extends ContainerRequest
/*     */ {
/*     */   protected final ContainerRequest acr;
/*     */   
/*     */   protected AdaptingContainerRequest(ContainerRequest acr)
/*     */   {
/*  85 */     super(acr);
/*  86 */     this.acr = acr;
/*     */   }
/*     */   
/*     */   public Map<String, Object> getProperties()
/*     */   {
/*  91 */     return this.acr.getProperties();
/*     */   }
/*     */   
/*     */   public void setMethod(String method)
/*     */   {
/*  96 */     this.acr.setMethod(method);
/*     */   }
/*     */   
/*     */   public void setUris(URI baseUri, URI requestUri)
/*     */   {
/* 101 */     this.acr.setUris(baseUri, requestUri);
/*     */   }
/*     */   
/*     */   public InputStream getEntityInputStream()
/*     */   {
/* 106 */     return this.acr.getEntityInputStream();
/*     */   }
/*     */   
/*     */   public void setEntityInputStream(InputStream entity)
/*     */   {
/* 111 */     this.acr.setEntityInputStream(entity);
/*     */   }
/*     */   
/*     */   public void setHeaders(InBoundHeaders headers)
/*     */   {
/* 116 */     this.acr.setHeaders(headers);
/*     */   }
/*     */   
/*     */   public void setSecurityContext(SecurityContext securityContext)
/*     */   {
/* 121 */     this.acr.setSecurityContext(securityContext);
/*     */   }
/*     */   
/*     */   public MessageBodyWorkers getMessageBodyWorkers()
/*     */   {
/* 126 */     return this.acr.getMessageBodyWorkers();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isTracingEnabled()
/*     */   {
/* 133 */     return this.acr.isTracingEnabled();
/*     */   }
/*     */   
/*     */   public void trace(String message)
/*     */   {
/* 138 */     this.acr.trace(message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public URI getBaseUri()
/*     */   {
/* 145 */     return this.acr.getBaseUri();
/*     */   }
/*     */   
/*     */   public UriBuilder getBaseUriBuilder()
/*     */   {
/* 150 */     return this.acr.getBaseUriBuilder();
/*     */   }
/*     */   
/*     */   public URI getRequestUri()
/*     */   {
/* 155 */     return this.acr.getRequestUri();
/*     */   }
/*     */   
/*     */   public UriBuilder getRequestUriBuilder()
/*     */   {
/* 160 */     return this.acr.getRequestUriBuilder();
/*     */   }
/*     */   
/*     */   public URI getAbsolutePath()
/*     */   {
/* 165 */     return this.acr.getAbsolutePath();
/*     */   }
/*     */   
/*     */   public UriBuilder getAbsolutePathBuilder()
/*     */   {
/* 170 */     return this.acr.getAbsolutePathBuilder();
/*     */   }
/*     */   
/*     */   public String getPath()
/*     */   {
/* 175 */     return this.acr.getPath();
/*     */   }
/*     */   
/*     */   public String getPath(boolean decode)
/*     */   {
/* 180 */     return this.acr.getPath(decode);
/*     */   }
/*     */   
/*     */   public List<PathSegment> getPathSegments()
/*     */   {
/* 185 */     return this.acr.getPathSegments();
/*     */   }
/*     */   
/*     */   public List<PathSegment> getPathSegments(boolean decode)
/*     */   {
/* 190 */     return this.acr.getPathSegments(decode);
/*     */   }
/*     */   
/*     */   public MultivaluedMap<String, String> getQueryParameters()
/*     */   {
/* 195 */     return this.acr.getQueryParameters();
/*     */   }
/*     */   
/*     */   public MultivaluedMap<String, String> getQueryParameters(boolean decode)
/*     */   {
/* 200 */     return this.acr.getQueryParameters(decode);
/*     */   }
/*     */   
/*     */   public String getHeaderValue(String name)
/*     */   {
/* 205 */     return this.acr.getHeaderValue(name);
/*     */   }
/*     */   
/*     */   public MediaType getAcceptableMediaType(List<MediaType> mediaTypes)
/*     */   {
/* 210 */     return this.acr.getAcceptableMediaType(mediaTypes);
/*     */   }
/*     */   
/*     */   public List<MediaType> getAcceptableMediaTypes(List<QualitySourceMediaType> priorityMediaTypes)
/*     */   {
/* 215 */     return this.acr.getAcceptableMediaTypes(priorityMediaTypes);
/*     */   }
/*     */   
/*     */   public MultivaluedMap<String, String> getCookieNameValueMap()
/*     */   {
/* 220 */     return this.acr.getCookieNameValueMap();
/*     */   }
/*     */   
/*     */   public <T> T getEntity(Class<T> type) throws WebApplicationException
/*     */   {
/* 225 */     return (T)this.acr.getEntity(type);
/*     */   }
/*     */   
/*     */   public <T> T getEntity(Class<T> type, Type genericType, Annotation[] as) throws WebApplicationException
/*     */   {
/* 230 */     return (T)this.acr.getEntity(type, genericType, as);
/*     */   }
/*     */   
/*     */   public Form getFormParameters()
/*     */   {
/* 235 */     return this.acr.getFormParameters();
/*     */   }
/*     */   
/*     */   public List<String> getRequestHeader(String name)
/*     */   {
/* 240 */     return this.acr.getRequestHeader(name);
/*     */   }
/*     */   
/*     */   public MultivaluedMap<String, String> getRequestHeaders()
/*     */   {
/* 245 */     return this.acr.getRequestHeaders();
/*     */   }
/*     */   
/*     */   public List<MediaType> getAcceptableMediaTypes()
/*     */   {
/* 250 */     return this.acr.getAcceptableMediaTypes();
/*     */   }
/*     */   
/*     */   public List<Locale> getAcceptableLanguages()
/*     */   {
/* 255 */     return this.acr.getAcceptableLanguages();
/*     */   }
/*     */   
/*     */   public MediaType getMediaType()
/*     */   {
/* 260 */     return this.acr.getMediaType();
/*     */   }
/*     */   
/*     */   public Locale getLanguage()
/*     */   {
/* 265 */     return this.acr.getLanguage();
/*     */   }
/*     */   
/*     */   public Map<String, Cookie> getCookies()
/*     */   {
/* 270 */     return this.acr.getCookies();
/*     */   }
/*     */   
/*     */   public String getMethod()
/*     */   {
/* 275 */     return this.acr.getMethod();
/*     */   }
/*     */   
/*     */   public Variant selectVariant(List<Variant> variants) throws IllegalArgumentException
/*     */   {
/* 280 */     return this.acr.selectVariant(variants);
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder evaluatePreconditions(EntityTag eTag)
/*     */   {
/* 285 */     return this.acr.evaluatePreconditions(eTag);
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder evaluatePreconditions(Date lastModified)
/*     */   {
/* 290 */     return this.acr.evaluatePreconditions(lastModified);
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder evaluatePreconditions(Date lastModified, EntityTag eTag)
/*     */   {
/* 295 */     return this.acr.evaluatePreconditions(lastModified, eTag);
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder evaluatePreconditions()
/*     */   {
/* 300 */     return this.acr.evaluatePreconditions();
/*     */   }
/*     */   
/*     */   public Principal getUserPrincipal()
/*     */   {
/* 305 */     return this.acr.getUserPrincipal();
/*     */   }
/*     */   
/*     */   public boolean isUserInRole(String role)
/*     */   {
/* 310 */     return this.acr.isUserInRole(role);
/*     */   }
/*     */   
/*     */   public boolean isSecure()
/*     */   {
/* 315 */     return this.acr.isSecure();
/*     */   }
/*     */   
/*     */   public String getAuthenticationScheme()
/*     */   {
/* 320 */     return this.acr.getAuthenticationScheme();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\container\AdaptingContainerRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */