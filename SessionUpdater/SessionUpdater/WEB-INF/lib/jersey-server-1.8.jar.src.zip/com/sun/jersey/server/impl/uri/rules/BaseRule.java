/*    */ package com.sun.jersey.server.impl.uri.rules;
/*    */ 
/*    */ import com.sun.jersey.api.uri.UriTemplate;
/*    */ import com.sun.jersey.spi.uri.rules.UriRule;
/*    */ import com.sun.jersey.spi.uri.rules.UriRuleContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BaseRule
/*    */   implements UriRule
/*    */ {
/*    */   private final UriTemplate template;
/*    */   
/*    */   public BaseRule(UriTemplate template)
/*    */   {
/* 63 */     assert (template != null);
/* 64 */     this.template = template;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected final void pushMatch(UriRuleContext context)
/*    */   {
/* 72 */     context.pushMatch(this.template, this.template.getTemplateVariables());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected final UriTemplate getTemplate()
/*    */   {
/* 83 */     return this.template;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\uri\rules\BaseRule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */