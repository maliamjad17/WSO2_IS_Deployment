/*    */ package com.sun.jersey.spi.container;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JavaMethodInvokerFactory
/*    */ {
/*    */   public static JavaMethodInvoker getDefault()
/*    */   {
/* 53 */     return defaultInstance;
/*    */   }
/*    */   
/* 56 */   static JavaMethodInvoker defaultInstance = new JavaMethodInvoker()
/*    */   {
/*    */     public Object invoke(Method m, Object o, Object... parameters) throws InvocationTargetException, IllegalAccessException
/*    */     {
/* 60 */       return m.invoke(o, parameters);
/*    */     }
/*    */   };
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\container\JavaMethodInvokerFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */