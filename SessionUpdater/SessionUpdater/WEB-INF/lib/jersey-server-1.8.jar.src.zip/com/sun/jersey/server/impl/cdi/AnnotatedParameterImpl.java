/*    */ package com.sun.jersey.server.impl.cdi;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Set;
/*    */ import javax.enterprise.inject.spi.AnnotatedCallable;
/*    */ import javax.enterprise.inject.spi.AnnotatedParameter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnotatedParameterImpl<T>
/*    */   extends AnnotatedImpl
/*    */   implements AnnotatedParameter<T>
/*    */ {
/*    */   private AnnotatedCallable<T> declaringCallable;
/*    */   private int position;
/*    */   
/*    */   public AnnotatedParameterImpl(Type baseType, Set<Type> typeClosure, Set<Annotation> annotations, AnnotatedCallable<T> declaringCallable, int position)
/*    */   {
/* 64 */     super(baseType, typeClosure, annotations);
/* 65 */     this.declaringCallable = declaringCallable;
/* 66 */     this.position = position;
/*    */   }
/*    */   
/*    */   public AnnotatedParameterImpl(AnnotatedParameter<? super T> param, AnnotatedCallable<T> declaringCallable) {
/* 70 */     this(param.getBaseType(), param.getTypeClosure(), param.getAnnotations(), declaringCallable, param.getPosition());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public AnnotatedParameterImpl(AnnotatedParameter<? super T> param, Set<Annotation> annotations, AnnotatedCallable<T> declaringCallable)
/*    */   {
/* 78 */     this(param.getBaseType(), param.getTypeClosure(), annotations, declaringCallable, param.getPosition());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public AnnotatedCallable<T> getDeclaringCallable()
/*    */   {
/* 86 */     return this.declaringCallable;
/*    */   }
/*    */   
/*    */   public int getPosition() {
/* 90 */     return this.position;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\cdi\AnnotatedParameterImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */