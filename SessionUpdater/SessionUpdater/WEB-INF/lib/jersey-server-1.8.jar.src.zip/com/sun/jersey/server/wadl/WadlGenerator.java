package com.sun.jersey.server.wadl;

import com.sun.jersey.api.model.AbstractMethod;
import com.sun.jersey.api.model.AbstractResource;
import com.sun.jersey.api.model.AbstractResourceMethod;
import com.sun.jersey.api.model.Parameter;
import com.sun.research.ws.wadl.Application;
import com.sun.research.ws.wadl.Method;
import com.sun.research.ws.wadl.Param;
import com.sun.research.ws.wadl.RepresentationType;
import com.sun.research.ws.wadl.Request;
import com.sun.research.ws.wadl.Resource;
import com.sun.research.ws.wadl.Resources;
import com.sun.research.ws.wadl.Response;
import javax.ws.rs.core.MediaType;

public abstract interface WadlGenerator
{
  public abstract void setWadlGeneratorDelegate(WadlGenerator paramWadlGenerator);
  
  public abstract void init()
    throws Exception;
  
  public abstract String getRequiredJaxbContextPath();
  
  public abstract Application createApplication();
  
  public abstract Resources createResources();
  
  public abstract Resource createResource(AbstractResource paramAbstractResource, String paramString);
  
  public abstract Method createMethod(AbstractResource paramAbstractResource, AbstractResourceMethod paramAbstractResourceMethod);
  
  public abstract Request createRequest(AbstractResource paramAbstractResource, AbstractResourceMethod paramAbstractResourceMethod);
  
  public abstract RepresentationType createRequestRepresentation(AbstractResource paramAbstractResource, AbstractResourceMethod paramAbstractResourceMethod, MediaType paramMediaType);
  
  public abstract Response createResponse(AbstractResource paramAbstractResource, AbstractResourceMethod paramAbstractResourceMethod);
  
  public abstract Param createParam(AbstractResource paramAbstractResource, AbstractMethod paramAbstractMethod, Parameter paramParameter);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\wadl\WadlGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */