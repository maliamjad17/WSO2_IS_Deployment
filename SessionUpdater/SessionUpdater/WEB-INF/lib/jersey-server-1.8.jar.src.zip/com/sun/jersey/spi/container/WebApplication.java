package com.sun.jersey.spi.container;

import com.sun.jersey.api.container.ContainerException;
import com.sun.jersey.api.core.HttpContext;
import com.sun.jersey.api.core.ResourceConfig;
import com.sun.jersey.api.core.Traceable;
import com.sun.jersey.core.spi.component.ioc.IoCComponentProviderFactory;
import com.sun.jersey.core.util.FeaturesAndProperties;
import com.sun.jersey.server.impl.inject.ServerInjectableProviderFactory;
import com.sun.jersey.spi.MessageBodyWorkers;
import com.sun.jersey.spi.monitoring.DispatchingListener;
import com.sun.jersey.spi.monitoring.RequestListener;
import com.sun.jersey.spi.monitoring.ResponseListener;
import java.io.IOException;
import javax.ws.rs.ext.Providers;

public abstract interface WebApplication
  extends Traceable
{
  public abstract boolean isInitiated();
  
  public abstract void initiate(ResourceConfig paramResourceConfig)
    throws IllegalArgumentException, ContainerException;
  
  public abstract void initiate(ResourceConfig paramResourceConfig, IoCComponentProviderFactory paramIoCComponentProviderFactory)
    throws IllegalArgumentException, ContainerException;
  
  public abstract WebApplication clone();
  
  public abstract FeaturesAndProperties getFeaturesAndProperties();
  
  public abstract Providers getProviders();
  
  public abstract MessageBodyWorkers getMessageBodyWorkers();
  
  public abstract ExceptionMapperContext getExceptionMapperContext();
  
  public abstract HttpContext getThreadLocalHttpContext();
  
  public abstract ServerInjectableProviderFactory getServerInjectableProviderFactory();
  
  public abstract RequestListener getRequestListener();
  
  public abstract DispatchingListener getDispatchingListener();
  
  public abstract ResponseListener getResponseListener();
  
  public abstract void handleRequest(ContainerRequest paramContainerRequest, ContainerResponseWriter paramContainerResponseWriter)
    throws IOException;
  
  public abstract void handleRequest(ContainerRequest paramContainerRequest, ContainerResponse paramContainerResponse)
    throws IOException;
  
  public abstract void destroy();
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\container\WebApplication.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */