/*     */ package com.sun.jersey.server.impl.wadl;
/*     */ 
/*     */ import com.sun.jersey.api.core.HttpContext;
/*     */ import com.sun.jersey.api.core.HttpResponseContext;
/*     */ import com.sun.jersey.api.model.AbstractResource;
/*     */ import com.sun.jersey.api.uri.UriTemplate;
/*     */ import com.sun.jersey.core.header.MediaTypes;
/*     */ import com.sun.jersey.server.impl.model.method.ResourceHttpOptionsMethod.OptionsRequestDispatcher;
/*     */ import com.sun.jersey.server.impl.model.method.ResourceMethod;
/*     */ import com.sun.jersey.server.wadl.WadlApplicationContext;
/*     */ import com.sun.jersey.server.wadl.WadlBuilder;
/*     */ import com.sun.jersey.server.wadl.WadlGenerator;
/*     */ import com.sun.research.ws.wadl.Application;
/*     */ import com.sun.research.ws.wadl.Resource;
/*     */ import com.sun.research.ws.wadl.Resources;
/*     */ import java.net.URI;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.ws.rs.core.Response;
/*     */ import javax.ws.rs.core.Response.ResponseBuilder;
/*     */ import javax.ws.rs.core.Response.Status;
/*     */ import javax.ws.rs.core.UriInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WadlMethodFactory
/*     */ {
/*     */   public static final class WadlOptionsMethod
/*     */     extends ResourceMethod
/*     */   {
/*     */     public WadlOptionsMethod(Map<String, List<ResourceMethod>> methods, AbstractResource resource, String path, WadlGenerator wadlGenerator, WadlApplicationContext wadlApplicationContext)
/*     */     {
/*  70 */       super(UriTemplate.EMPTY, MediaTypes.GENERAL_MEDIA_TYPE_LIST, MediaTypes.GENERAL_MEDIA_TYPE_LIST, false, new WadlMethodFactory.WadlOptionsMethodDispatcher(methods, resource, path, wadlGenerator, wadlApplicationContext));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/*  80 */       return "WADL OPTIONS method";
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class WadlOptionsMethodDispatcher
/*     */     extends ResourceHttpOptionsMethod.OptionsRequestDispatcher
/*     */   {
/*     */     private final AbstractResource resource;
/*     */     private final String path;
/*     */     private final WadlGenerator wadlGenerator;
/*     */     private final WadlApplicationContext wadlApplicationContext;
/*     */     
/*     */     WadlOptionsMethodDispatcher(Map<String, List<ResourceMethod>> methods, AbstractResource resource, String path, WadlGenerator wadlGenerator, WadlApplicationContext wadlApplicationContext)
/*     */     {
/*  94 */       super();
/*  95 */       this.resource = resource;
/*  96 */       this.path = path;
/*  97 */       this.wadlGenerator = wadlGenerator;
/*  98 */       this.wadlApplicationContext = wadlApplicationContext;
/*     */     }
/*     */     
/*     */     public void dispatch(Object o, HttpContext context)
/*     */     {
/* 103 */       if (this.wadlApplicationContext.isWadlGenerationEnabled()) {
/* 104 */         Application a = WadlMethodFactory.generateApplication(context.getUriInfo(), this.resource, this.path, this.wadlGenerator);
/*     */         
/*     */ 
/* 107 */         context.getResponse().setResponse(Response.ok(a, MediaTypes.WADL).header("Allow", this.allow).build());
/*     */ 
/*     */       }
/* 110 */       else if (!this.wadlApplicationContext.isWadlGenerationEnabled()) {
/* 111 */         context.getResponse().setResponse(Response.status(Response.Status.NO_CONTENT).header("Allow", this.allow).build());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static Application generateApplication(UriInfo info, AbstractResource resource, String path, WadlGenerator wadlGenerator)
/*     */   {
/* 118 */     Application a = path == null ? new WadlBuilder(wadlGenerator).generate(resource) : new WadlBuilder(wadlGenerator).generate(resource, path);
/*     */     
/*     */ 
/* 121 */     a.getResources().setBase(info.getBaseUri().toString());
/*     */     
/* 123 */     Resource r = (Resource)a.getResources().getResource().get(0);
/* 124 */     r.setPath(info.getBaseUri().relativize(info.getAbsolutePath()).toString());
/*     */     
/*     */ 
/*     */ 
/* 128 */     r.getParam().clear();
/*     */     
/* 130 */     return a;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\wadl\WadlMethodFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */