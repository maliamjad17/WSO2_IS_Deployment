/*     */ package com.sun.jersey.server.impl.cdi;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import javax.enterprise.context.spi.CreationalContext;
/*     */ import javax.enterprise.inject.AmbiguousResolutionException;
/*     */ import javax.enterprise.inject.spi.Bean;
/*     */ import javax.enterprise.inject.spi.BeanManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Utils
/*     */ {
/*     */   public static Bean<?> getBean(BeanManager bm, Class<?> c)
/*     */   {
/*  61 */     Set<Bean<?>> bs = bm.getBeans(c, new Annotation[0]);
/*  62 */     if (bs.isEmpty()) {
/*  63 */       return null;
/*     */     }
/*     */     try
/*     */     {
/*  67 */       return bm.resolve(bs);
/*     */     }
/*     */     catch (AmbiguousResolutionException ex)
/*     */     {
/*  71 */       if (isSharedBaseClass(c, bs))
/*     */         try {
/*  73 */           return bm.resolve(getBaseClassSubSet(c, bs));
/*     */         } catch (AmbiguousResolutionException ex2) {
/*  75 */           return null;
/*     */         }
/*     */     }
/*  78 */     return null;
/*     */   }
/*     */   
/*     */   public static <T> T getInstance(BeanManager bm, Class<T> c)
/*     */   {
/*  83 */     Bean<?> b = getBean(bm, c);
/*  84 */     if (b == null) {
/*  85 */       return null;
/*     */     }
/*     */     
/*  88 */     CreationalContext<?> cc = bm.createCreationalContext(b);
/*  89 */     return (T)c.cast(bm.getReference(b, c, cc));
/*     */   }
/*     */   
/*     */   private static boolean isSharedBaseClass(Class<?> c, Set<Bean<?>> bs) {
/*  93 */     for (Bean<?> b : bs) {
/*  94 */       if (!c.isAssignableFrom(b.getBeanClass())) {
/*  95 */         return false;
/*     */       }
/*     */     }
/*  98 */     return true;
/*     */   }
/*     */   
/*     */   private static Set<Bean<?>> getBaseClassSubSet(Class<?> c, Set<Bean<?>> bs) {
/* 102 */     for (Bean<?> b : bs) {
/* 103 */       if (c == b.getBeanClass()) {
/* 104 */         return Collections.singleton(b);
/*     */       }
/*     */     }
/* 107 */     return bs;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\cdi\Utils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */