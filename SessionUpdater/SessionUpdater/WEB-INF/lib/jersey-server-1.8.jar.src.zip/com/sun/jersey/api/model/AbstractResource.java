/*     */ package com.sun.jersey.api.model;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AbstractResource
/*     */   implements PathAnnotated, AbstractModelComponent, AnnotatedElement
/*     */ {
/*     */   private final Class<?> resourceClass;
/*     */   private final PathValue uriPath;
/*     */   private final List<AbstractResourceConstructor> constructors;
/*     */   private final List<AbstractField> fields;
/*     */   private final List<AbstractSetterMethod> setterMethods;
/*     */   private final List<AbstractResourceMethod> resourceMethods;
/*     */   private final List<AbstractSubResourceMethod> subResourceMethods;
/*     */   private final List<AbstractSubResourceLocator> subResourceLocators;
/*     */   private final List<Method> postConstructMethods;
/*     */   private final List<Method> preDestroyMethods;
/*     */   
/*     */   public AbstractResource(Class<?> resourceClass)
/*     */   {
/*  69 */     this(resourceClass, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public AbstractResource(Class<?> resourceClass, PathValue uriPath)
/*     */   {
/*  76 */     this.resourceClass = resourceClass;
/*  77 */     this.uriPath = uriPath;
/*  78 */     this.constructors = new ArrayList(4);
/*  79 */     this.fields = new ArrayList(4);
/*  80 */     this.setterMethods = new ArrayList(2);
/*  81 */     this.resourceMethods = new ArrayList(4);
/*  82 */     this.subResourceLocators = new ArrayList(4);
/*  83 */     this.subResourceMethods = new ArrayList(4);
/*  84 */     this.postConstructMethods = new ArrayList(1);
/*  85 */     this.preDestroyMethods = new ArrayList(1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractResource(String path, AbstractResource ar)
/*     */   {
/*  96 */     this.uriPath = new PathValue(path);
/*     */     
/*  98 */     this.resourceClass = ar.resourceClass;
/*  99 */     this.constructors = ar.constructors;
/* 100 */     this.fields = ar.fields;
/* 101 */     this.setterMethods = ar.setterMethods;
/* 102 */     this.resourceMethods = ar.resourceMethods;
/* 103 */     this.subResourceMethods = ar.subResourceMethods;
/* 104 */     this.subResourceLocators = ar.subResourceLocators;
/* 105 */     this.postConstructMethods = ar.postConstructMethods;
/* 106 */     this.preDestroyMethods = ar.preDestroyMethods;
/*     */   }
/*     */   
/*     */   public Class<?> getResourceClass() {
/* 110 */     return this.resourceClass;
/*     */   }
/*     */   
/*     */   public boolean isSubResource() {
/* 114 */     return this.uriPath == null;
/*     */   }
/*     */   
/*     */   public boolean isRootResource() {
/* 118 */     return this.uriPath != null;
/*     */   }
/*     */   
/*     */   public PathValue getPath()
/*     */   {
/* 123 */     return this.uriPath;
/*     */   }
/*     */   
/*     */   public List<AbstractResourceConstructor> getConstructors() {
/* 127 */     return this.constructors;
/*     */   }
/*     */   
/*     */   public List<AbstractField> getFields() {
/* 131 */     return this.fields;
/*     */   }
/*     */   
/*     */   public List<AbstractSetterMethod> getSetterMethods() {
/* 135 */     return this.setterMethods;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<AbstractResourceMethod> getResourceMethods()
/*     */   {
/* 144 */     return this.resourceMethods;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<AbstractSubResourceMethod> getSubResourceMethods()
/*     */   {
/* 153 */     return this.subResourceMethods;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<AbstractSubResourceLocator> getSubResourceLocators()
/*     */   {
/* 162 */     return this.subResourceLocators;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<Method> getPostConstructMethods()
/*     */   {
/* 169 */     return this.postConstructMethods;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<Method> getPreDestroyMethods()
/*     */   {
/* 176 */     return this.preDestroyMethods;
/*     */   }
/*     */   
/*     */   public void accept(AbstractModelVisitor visitor)
/*     */   {
/* 181 */     visitor.visitAbstractResource(this);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isAnnotationPresent(Class<? extends Annotation> a)
/*     */   {
/* 187 */     return this.resourceClass.isAnnotationPresent(a);
/*     */   }
/*     */   
/*     */   public <T extends Annotation> T getAnnotation(Class<T> a)
/*     */   {
/* 192 */     return this.resourceClass.getAnnotation(a);
/*     */   }
/*     */   
/*     */   public Annotation[] getAnnotations()
/*     */   {
/* 197 */     return this.resourceClass.getAnnotations();
/*     */   }
/*     */   
/*     */   public Annotation[] getDeclaredAnnotations()
/*     */   {
/* 202 */     return this.resourceClass.getDeclaredAnnotations();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 207 */     return "AbstractResource(" + (null == getPath() ? "" : new StringBuilder().append("\"").append(getPath().getValue()).append("\", - ").toString()) + getResourceClass().getSimpleName() + ": " + getConstructors().size() + " constructors, " + getFields().size() + " fields, " + getSetterMethods().size() + " setter methods, " + getResourceMethods().size() + " res methods, " + getSubResourceMethods().size() + " subres methods, " + getSubResourceLocators().size() + " subres locators " + ")";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<AbstractModelComponent> getComponents()
/*     */   {
/* 220 */     List<AbstractModelComponent> components = new LinkedList();
/* 221 */     components.addAll(getConstructors());
/* 222 */     components.addAll(getFields());
/* 223 */     components.addAll(getSetterMethods());
/* 224 */     components.addAll(getResourceMethods());
/* 225 */     components.addAll(getSubResourceMethods());
/* 226 */     components.addAll(getSubResourceLocators());
/* 227 */     return components;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\model\AbstractResource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */