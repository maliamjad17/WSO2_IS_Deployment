/*    */ package com.sun.jersey.spi.container.servlet;
/*    */ 
/*    */ import com.sun.jersey.api.core.ResourceConfig;
/*    */ import java.util.Enumeration;
/*    */ import java.util.Map;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebServletConfig
/*    */   implements WebConfig
/*    */ {
/*    */   private final ServletContainer servlet;
/*    */   
/*    */   public WebServletConfig(ServletContainer servlet)
/*    */   {
/* 62 */     this.servlet = servlet;
/*    */   }
/*    */   
/*    */   public WebConfig.ConfigType getConfigType() {
/* 66 */     return WebConfig.ConfigType.ServletConfig;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 70 */     return this.servlet.getServletName();
/*    */   }
/*    */   
/*    */   public String getInitParameter(String name) {
/* 74 */     return this.servlet.getInitParameter(name);
/*    */   }
/*    */   
/*    */   public Enumeration getInitParameterNames() {
/* 78 */     return this.servlet.getInitParameterNames();
/*    */   }
/*    */   
/*    */   public ServletContext getServletContext() {
/* 82 */     return this.servlet.getServletContext();
/*    */   }
/*    */   
/*    */   public ResourceConfig getDefaultResourceConfig(Map<String, Object> props) throws ServletException
/*    */   {
/* 87 */     return this.servlet.getDefaultResourceConfig(props, this.servlet.getServletConfig());
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\container\servlet\WebServletConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */