/*    */ package com.sun.jersey.spi.scanning;
/*    */ 
/*    */ import javax.ws.rs.Path;
/*    */ import javax.ws.rs.ext.Provider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PathProviderScannerListener
/*    */   extends AnnotationScannerListener
/*    */ {
/*    */   public PathProviderScannerListener()
/*    */   {
/* 59 */     super(new Class[] { Path.class, Provider.class });
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PathProviderScannerListener(ClassLoader classloader)
/*    */   {
/* 70 */     super(classloader, new Class[] { Path.class, Provider.class });
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\scanning\PathProviderScannerListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */