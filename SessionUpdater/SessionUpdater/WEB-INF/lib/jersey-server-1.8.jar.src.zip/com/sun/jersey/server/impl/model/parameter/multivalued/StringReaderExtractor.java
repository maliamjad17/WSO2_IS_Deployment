/*    */ package com.sun.jersey.server.impl.model.parameter.multivalued;
/*    */ 
/*    */ import com.sun.jersey.api.container.ContainerException;
/*    */ import com.sun.jersey.spi.StringReader;
/*    */ import javax.ws.rs.WebApplicationException;
/*    */ import javax.ws.rs.core.MultivaluedMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StringReaderExtractor
/*    */   extends AbstractStringReaderExtractor
/*    */ {
/*    */   public StringReaderExtractor(StringReader sr, String parameter, String defaultStringValue)
/*    */   {
/* 55 */     super(sr, parameter, defaultStringValue);
/*    */   }
/*    */   
/*    */   public Object extract(MultivaluedMap<String, String> parameters) {
/* 59 */     String v = (String)parameters.getFirst(this.parameter);
/* 60 */     if (v != null)
/*    */       try {
/* 62 */         return this.sr.fromString(v);
/*    */       } catch (WebApplicationException ex) {
/* 64 */         throw ex;
/*    */       } catch (ContainerException ex) {
/* 66 */         throw ex;
/*    */       } catch (Exception ex) {
/* 68 */         throw new ExtractorContainerException(ex);
/*    */       }
/* 70 */     if (this.defaultStringValue != null) {
/* 71 */       return this.sr.fromString(this.defaultStringValue);
/*    */     }
/*    */     
/* 74 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\parameter\multivalued\StringReaderExtractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */