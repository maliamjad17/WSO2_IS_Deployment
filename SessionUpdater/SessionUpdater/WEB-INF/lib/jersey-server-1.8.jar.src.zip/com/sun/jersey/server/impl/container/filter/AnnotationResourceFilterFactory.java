/*    */ package com.sun.jersey.server.impl.container.filter;
/*    */ 
/*    */ import com.sun.jersey.api.model.AbstractMethod;
/*    */ import com.sun.jersey.api.model.AbstractResource;
/*    */ import com.sun.jersey.spi.container.ResourceFilter;
/*    */ import com.sun.jersey.spi.container.ResourceFilterFactory;
/*    */ import com.sun.jersey.spi.container.ResourceFilters;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AnnotationResourceFilterFactory
/*    */   implements ResourceFilterFactory
/*    */ {
/*    */   private FilterFactory ff;
/*    */   
/*    */   public AnnotationResourceFilterFactory(FilterFactory ff)
/*    */   {
/* 57 */     this.ff = ff;
/*    */   }
/*    */   
/*    */   public List<ResourceFilter> create(AbstractMethod am) {
/* 61 */     ResourceFilters rfs = (ResourceFilters)am.getAnnotation(ResourceFilters.class);
/* 62 */     if (rfs == null)
/* 63 */       rfs = (ResourceFilters)am.getResource().getAnnotation(ResourceFilters.class);
/* 64 */     if (rfs == null) {
/* 65 */       return null;
/*    */     }
/* 67 */     return getResourceFilters(rfs.value());
/*    */   }
/*    */   
/*    */   private List<ResourceFilter> getResourceFilters(Class<? extends ResourceFilter>[] classes) {
/* 71 */     if ((classes == null) || (classes.length == 0)) {
/* 72 */       return null;
/*    */     }
/* 74 */     return this.ff.getResourceFilters(classes);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\container\filter\AnnotationResourceFilterFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */