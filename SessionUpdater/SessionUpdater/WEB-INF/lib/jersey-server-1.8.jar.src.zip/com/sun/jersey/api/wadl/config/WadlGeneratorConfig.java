/*     */ package com.sun.jersey.api.wadl.config;
/*     */ 
/*     */ import com.sun.jersey.server.wadl.WadlGenerator;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class WadlGeneratorConfig
/*     */ {
/*     */   private WadlGenerator _wadlGenerator;
/*     */   
/*     */   public WadlGeneratorConfig() {}
/*     */   
/*     */   public WadlGeneratorConfig(WadlGenerator wadlGenerator)
/*     */   {
/* 172 */     if (wadlGenerator == null) {
/* 173 */       throw new IllegalArgumentException("The wadl generator must not be null.");
/*     */     }
/* 175 */     this._wadlGenerator = wadlGenerator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract List<WadlGeneratorDescription> configure();
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized WadlGenerator getWadlGenerator()
/*     */   {
/* 186 */     if (this._wadlGenerator == null) {
/* 187 */       List<WadlGeneratorDescription> wadlGeneratorDescriptions = configure();
/*     */       try {
/* 189 */         this._wadlGenerator = WadlGeneratorLoader.loadWadlGeneratorDescriptions(wadlGeneratorDescriptions);
/*     */       } catch (Exception e) {
/* 191 */         throw new RuntimeException("Could not load wadl generators from wadlGeneratorDescriptions.", e);
/*     */       }
/*     */     }
/* 194 */     return this._wadlGenerator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static WadlGeneratorConfigDescriptionBuilder generator(Class<? extends WadlGenerator> generatorClass)
/*     */   {
/* 210 */     return new WadlGeneratorConfigDescriptionBuilder().generator(generatorClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static WadlGeneratorConfigBuilder generator(WadlGenerator generator)
/*     */   {
/* 220 */     return new WadlGeneratorConfigBuilder().generator(generator);
/*     */   }
/*     */   
/*     */   public static class WadlGeneratorConfigDescriptionBuilder
/*     */   {
/*     */     private List<WadlGeneratorDescription> _descriptions;
/*     */     private WadlGeneratorDescription _description;
/*     */     
/*     */     public WadlGeneratorConfigDescriptionBuilder() {
/* 229 */       this._descriptions = new ArrayList();
/*     */     }
/*     */     
/*     */     public WadlGeneratorConfigDescriptionBuilder generator(Class<? extends WadlGenerator> generatorClass) {
/* 233 */       if (this._description != null) {
/* 234 */         this._descriptions.add(this._description);
/*     */       }
/* 236 */       this._description = new WadlGeneratorDescription();
/* 237 */       this._description.setGeneratorClass(generatorClass);
/* 238 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public WadlGeneratorConfigDescriptionBuilder prop(String propName, Object propValue)
/*     */     {
/* 286 */       if (this._description.getProperties() == null) {
/* 287 */         this._description.setProperties(new Properties());
/*     */       }
/* 289 */       this._description.getProperties().put(propName, propValue);
/* 290 */       return this;
/*     */     }
/*     */     
/*     */     public List<WadlGeneratorDescription> descriptions() {
/* 294 */       if (this._description != null) {
/* 295 */         this._descriptions.add(this._description);
/*     */       }
/* 297 */       return this._descriptions;
/*     */     }
/*     */     
/*     */     public WadlGeneratorConfig build() {
/* 301 */       if (this._description != null) {
/* 302 */         this._descriptions.add(this._description);
/*     */       }
/* 304 */       return new WadlGeneratorConfig.WadlGeneratorConfigImpl(this._descriptions);
/*     */     }
/*     */   }
/*     */   
/*     */   static class WadlGeneratorConfigImpl
/*     */     extends WadlGeneratorConfig
/*     */   {
/*     */     public List<WadlGeneratorDescription> _descriptions;
/*     */     
/*     */     public WadlGeneratorConfigImpl(List<WadlGeneratorDescription> descriptions)
/*     */     {
/* 315 */       this._descriptions = descriptions;
/*     */     }
/*     */     
/*     */     public List<WadlGeneratorDescription> configure()
/*     */     {
/* 320 */       return this._descriptions;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class WadlGeneratorConfigBuilder
/*     */   {
/*     */     private List<WadlGenerator> _generators;
/*     */     
/*     */     public WadlGeneratorConfigBuilder()
/*     */     {
/* 330 */       this._generators = new ArrayList();
/*     */     }
/*     */     
/*     */     public WadlGeneratorConfigBuilder generator(WadlGenerator generator) {
/* 334 */       if (generator == null) {
/* 335 */         throw new IllegalArgumentException("The wadl generator must not be null.");
/*     */       }
/* 337 */       this._generators.add(generator);
/* 338 */       return this;
/*     */     }
/*     */     
/*     */     public WadlGeneratorConfig build() {
/*     */       try {
/* 343 */         WadlGenerator wadlGenerator = WadlGeneratorLoader.loadWadlGenerators(this._generators);
/* 344 */         new WadlGeneratorConfig.WadlGeneratorConfigGeneratorImpl(wadlGenerator) {};
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 348 */         throw new RuntimeException("Could not load wadl generators.", e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   static class WadlGeneratorConfigGeneratorImpl extends WadlGeneratorConfig
/*     */   {
/*     */     private final WadlGenerator _wadlGenerator;
/*     */     
/*     */     public WadlGeneratorConfigGeneratorImpl(WadlGenerator wadlGenerator)
/*     */     {
/* 359 */       this._wadlGenerator = wadlGenerator;
/*     */     }
/*     */     
/*     */     public List<WadlGeneratorDescription> configure()
/*     */     {
/* 364 */       throw new UnsupportedOperationException("Must not be called");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public synchronized WadlGenerator getWadlGenerator()
/*     */     {
/* 372 */       return this._wadlGenerator;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\wadl\config\WadlGeneratorConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */