/*    */ package com.sun.jersey.server.impl.model.parameter.multivalued;
/*    */ 
/*    */ import com.sun.jersey.core.spi.component.ProviderServices;
/*    */ import com.sun.jersey.spi.StringReader;
/*    */ import com.sun.jersey.spi.StringReaderProvider;
/*    */ import com.sun.jersey.spi.StringReaderWorkers;
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringReaderFactory
/*    */   implements StringReaderWorkers
/*    */ {
/*    */   private Set<StringReaderProvider> readers;
/*    */   
/*    */   public void init(ProviderServices providerServices)
/*    */   {
/* 60 */     this.readers = providerServices.getProvidersAndServices(StringReaderProvider.class);
/*    */   }
/*    */   
/*    */   public <T> StringReader<T> getStringReader(Class<T> type, Type genericType, Annotation[] annotations) {
/* 64 */     for (StringReaderProvider<T> srp : this.readers) {
/* 65 */       StringReader<T> sr = srp.getStringReader(type, genericType, annotations);
/* 66 */       if (sr != null)
/* 67 */         return sr;
/*    */     }
/* 69 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\parameter\multivalued\StringReaderFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */