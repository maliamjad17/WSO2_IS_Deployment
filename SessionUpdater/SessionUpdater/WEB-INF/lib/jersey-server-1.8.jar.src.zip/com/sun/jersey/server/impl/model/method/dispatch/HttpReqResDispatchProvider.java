/*    */ package com.sun.jersey.server.impl.model.method.dispatch;
/*    */ 
/*    */ import com.sun.jersey.api.core.HttpContext;
/*    */ import com.sun.jersey.api.core.HttpRequestContext;
/*    */ import com.sun.jersey.api.core.HttpResponseContext;
/*    */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*    */ import com.sun.jersey.spi.container.JavaMethodInvoker;
/*    */ import com.sun.jersey.spi.container.JavaMethodInvokerFactory;
/*    */ import com.sun.jersey.spi.container.ResourceMethodCustomInvokerDispatchProvider;
/*    */ import com.sun.jersey.spi.container.ResourceMethodDispatchProvider;
/*    */ import com.sun.jersey.spi.dispatch.RequestDispatcher;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpReqResDispatchProvider
/*    */   implements ResourceMethodDispatchProvider, ResourceMethodCustomInvokerDispatchProvider
/*    */ {
/* 65 */   private static final Class[] EXPECTED_METHOD_PARAMS = { HttpRequestContext.class, HttpResponseContext.class };
/*    */   
/*    */   static final class HttpReqResDispatcher extends ResourceJavaMethodDispatcher {
/*    */     HttpReqResDispatcher(AbstractResourceMethod abstractResourceMethod) {
/* 69 */       this(abstractResourceMethod, JavaMethodInvokerFactory.getDefault());
/*    */     }
/*    */     
/*    */     HttpReqResDispatcher(AbstractResourceMethod abstractResourceMethod, JavaMethodInvoker invoker) {
/* 73 */       super(invoker);
/*    */     }
/*    */     
/*    */     public void _dispatch(Object resource, HttpContext context) throws InvocationTargetException, IllegalAccessException
/*    */     {
/* 78 */       this.invoker.invoke(this.method, resource, new Object[] { context.getRequest(), context.getResponse() });
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public RequestDispatcher create(AbstractResourceMethod abstractResourceMethod)
/*    */   {
/* 85 */     return create(abstractResourceMethod, JavaMethodInvokerFactory.getDefault());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public RequestDispatcher create(AbstractResourceMethod abstractResourceMethod, JavaMethodInvoker invoker)
/*    */   {
/* 92 */     if (abstractResourceMethod.getMethod().getReturnType() != Void.TYPE) { return null;
/*    */     }
/*    */     
/* 95 */     Class<?>[] parameters = abstractResourceMethod.getMethod().getParameterTypes();
/* 96 */     if (!Arrays.deepEquals(parameters, EXPECTED_METHOD_PARAMS)) { return null;
/*    */     }
/* 98 */     return new HttpReqResDispatcher(abstractResourceMethod, invoker);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\method\dispatch\HttpReqResDispatchProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */