/*     */ package com.sun.jersey.server.impl.uri;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import javax.ws.rs.core.UriBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UriHelper
/*     */ {
/*     */   public static URI normalize(URI uri, boolean preserveContdSlashes)
/*     */   {
/*  64 */     if (!uri.getRawPath().contains("//")) {
/*  65 */       return uri.normalize();
/*     */     }
/*  67 */     String np = removeDotSegments(uri.getRawPath(), preserveContdSlashes);
/*     */     
/*     */ 
/*     */ 
/*  71 */     if (np.equals(uri.getRawPath())) {
/*  72 */       return uri;
/*     */     }
/*  74 */     return UriBuilder.fromUri(uri).replacePath(np).build(new Object[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String removeLeadingSlashesIfNeeded(String path, boolean preserveSlashes)
/*     */   {
/*  87 */     if (preserveSlashes) {
/*  88 */       return path;
/*     */     }
/*  90 */     String trimmed = path;
/*  91 */     while (trimmed.startsWith("/")) {
/*  92 */       trimmed = trimmed.substring(1);
/*     */     }
/*  94 */     return trimmed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String removeDotSegments(String path, boolean preserveContdSlashes)
/*     */   {
/* 121 */     if (null == path) {
/* 122 */       return null;
/*     */     }
/*     */     
/* 125 */     List<String> outputSegments = new LinkedList();
/* 126 */     while (path.length() > 0) {
/* 127 */       if (path.startsWith("../")) {
/* 128 */         path = removeLeadingSlashesIfNeeded(path.substring(3), preserveContdSlashes);
/* 129 */       } else if (path.startsWith("./")) {
/* 130 */         path = removeLeadingSlashesIfNeeded(path.substring(2), preserveContdSlashes);
/* 131 */       } else if (path.startsWith("/./")) {
/* 132 */         path = "/" + removeLeadingSlashesIfNeeded(path.substring(3), preserveContdSlashes);
/* 133 */       } else if ("/.".equals(path)) {
/* 134 */         path = "/";
/* 135 */       } else if (path.startsWith("/../")) {
/* 136 */         path = "/" + removeLeadingSlashesIfNeeded(path.substring(4), preserveContdSlashes);
/* 137 */         if (!outputSegments.isEmpty()) {
/* 138 */           outputSegments.remove(outputSegments.size() - 1);
/*     */         }
/* 140 */       } else if ("/..".equals(path)) {
/* 141 */         path = "/";
/* 142 */         if (!outputSegments.isEmpty()) {
/* 143 */           outputSegments.remove(outputSegments.size() - 1);
/*     */         }
/* 145 */       } else if (("..".equals(path)) || (".".equals(path))) {
/* 146 */         path = "";
/*     */       } else { int slashStartSearchIndex;
/*     */         int slashStartSearchIndex;
/* 149 */         if (path.startsWith("/")) {
/* 150 */           path = "/" + removeLeadingSlashesIfNeeded(path.substring(1), preserveContdSlashes);
/* 151 */           slashStartSearchIndex = 1;
/*     */         } else {
/* 153 */           slashStartSearchIndex = 0;
/*     */         }
/* 155 */         int segLength = path.indexOf('/', slashStartSearchIndex);
/* 156 */         if (-1 == segLength) {
/* 157 */           segLength = path.length();
/*     */         }
/* 159 */         outputSegments.add(path.substring(0, segLength));
/* 160 */         path = path.substring(segLength);
/*     */       }
/*     */     }
/*     */     
/* 164 */     StringBuffer result = new StringBuffer();
/* 165 */     for (String segment : outputSegments) {
/* 166 */       result.append(segment);
/*     */     }
/* 168 */     return result.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\uri\UriHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */