/*    */ package com.sun.jersey.server.impl.container.servlet;
/*    */ 
/*    */ import com.sun.jersey.api.core.HttpContext;
/*    */ import com.sun.jersey.api.view.Viewable;
/*    */ import java.io.IOException;
/*    */ import javax.servlet.RequestDispatcher;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RequestDispatcherWrapper
/*    */   implements RequestDispatcher
/*    */ {
/*    */   private final RequestDispatcher d;
/*    */   private final String basePath;
/*    */   private final HttpContext hc;
/*    */   private final Viewable v;
/*    */   
/*    */   public RequestDispatcherWrapper(RequestDispatcher d, String basePath, HttpContext hc, Viewable v)
/*    */   {
/* 65 */     this.d = d;
/* 66 */     this.basePath = basePath;
/* 67 */     this.hc = hc;
/* 68 */     this.v = v;
/*    */   }
/*    */   
/*    */   public void forward(ServletRequest req, ServletResponse rsp) throws ServletException, IOException {
/* 72 */     Object oldIt = req.getAttribute("it");
/* 73 */     Object oldResolvingClass = req.getAttribute("resolvingClass");
/*    */     
/* 75 */     req.setAttribute("resolvingClass", this.v.getResolvingClass());
/* 76 */     req.setAttribute("it", this.v.getModel());
/* 77 */     req.setAttribute("httpContext", this.hc);
/* 78 */     req.setAttribute("_basePath", this.basePath);
/* 79 */     req.setAttribute("_request", req);
/* 80 */     req.setAttribute("_response", rsp);
/*    */     
/* 82 */     this.d.forward(req, rsp);
/*    */     
/* 84 */     req.setAttribute("resolvingClass", oldResolvingClass);
/* 85 */     req.setAttribute("it", oldIt);
/*    */   }
/*    */   
/*    */   public void include(ServletRequest req, ServletResponse rsp) throws ServletException, IOException {
/* 89 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\container\servlet\RequestDispatcherWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */