/*      */ package com.sun.jersey.api;
/*      */ 
/*      */ import com.sun.jersey.core.header.OutBoundHeaders;
/*      */ import com.sun.jersey.core.spi.factory.ResponseImpl;
/*      */ import java.lang.reflect.ParameterizedType;
/*      */ import java.lang.reflect.Type;
/*      */ import java.net.URI;
/*      */ import java.util.Date;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Set;
/*      */ import javax.ws.rs.core.CacheControl;
/*      */ import javax.ws.rs.core.EntityTag;
/*      */ import javax.ws.rs.core.MediaType;
/*      */ import javax.ws.rs.core.MultivaluedMap;
/*      */ import javax.ws.rs.core.NewCookie;
/*      */ import javax.ws.rs.core.Response;
/*      */ import javax.ws.rs.core.Response.Status;
/*      */ import javax.ws.rs.core.Response.StatusType;
/*      */ import javax.ws.rs.core.Variant;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JResponse<E>
/*      */ {
/*      */   private final Response.StatusType statusType;
/*      */   private final E entity;
/*      */   private final OutBoundHeaders headers;
/*      */   
/*      */   public JResponse(Response.StatusType statusType, OutBoundHeaders headers, E entity)
/*      */   {
/*   99 */     this.statusType = statusType;
/*  100 */     this.entity = entity;
/*  101 */     this.headers = headers;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JResponse(int status, OutBoundHeaders headers, E entity)
/*      */   {
/*  113 */     this(ResponseImpl.toStatusType(status), headers, entity);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JResponse(JResponse<E> that)
/*      */   {
/*  123 */     this(that.statusType, that.headers != null ? new OutBoundHeaders(that.headers) : null, that.entity);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JResponse(AJResponseBuilder<E, ?> b)
/*      */   {
/*  134 */     this.statusType = b.getStatusType();
/*  135 */     this.entity = b.getEntity();
/*  136 */     this.headers = b.getMetadata();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JResponseAsResponse toResponse()
/*      */   {
/*  145 */     return new JResponseAsResponse(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JResponseAsResponse toResponse(Type type)
/*      */   {
/*  155 */     return new JResponseAsResponse(this, type);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Response.StatusType getStatusType()
/*      */   {
/*  164 */     return this.statusType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getStatus()
/*      */   {
/*  173 */     return this.statusType.getStatusCode();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public OutBoundHeaders getMetadata()
/*      */   {
/*  188 */     return this.headers;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public E getEntity()
/*      */   {
/*  199 */     return (E)this.entity;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Type getType()
/*      */   {
/*  208 */     return getSuperclassTypeParameter(getClass());
/*      */   }
/*      */   
/*      */   private static Type getSuperclassTypeParameter(Class<?> subclass) {
/*  212 */     Type superclass = subclass.getGenericSuperclass();
/*  213 */     if (!(superclass instanceof ParameterizedType)) {
/*  214 */       return Object.class;
/*      */     }
/*  216 */     ParameterizedType parameterized = (ParameterizedType)superclass;
/*  217 */     return parameterized.getActualTypeArguments()[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <E> JResponseBuilder<E> fromResponse(Response response)
/*      */   {
/*  233 */     JResponseBuilder b = status(response.getStatus());
/*  234 */     b.entity(response.getEntity());
/*  235 */     for (Iterator i$ = response.getMetadata().keySet().iterator(); i$.hasNext();) { headerName = (String)i$.next();
/*  236 */       List<Object> headerValues = (List)response.getMetadata().get(headerName);
/*  237 */       for (Object headerValue : headerValues)
/*  238 */         b.header(headerName, headerValue);
/*      */     }
/*      */     String headerName;
/*  241 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <E> JResponseBuilder<E> fromResponse(JResponse<E> response)
/*      */   {
/*  256 */     JResponseBuilder<E> b = status(response.getStatus());
/*  257 */     b.entity(response.getEntity());
/*  258 */     for (Iterator i$ = response.getMetadata().keySet().iterator(); i$.hasNext();) { headerName = (String)i$.next();
/*  259 */       List<Object> headerValues = (List)response.getMetadata().get(headerName);
/*  260 */       for (Object headerValue : headerValues)
/*  261 */         b.header(headerName, headerValue);
/*      */     }
/*      */     String headerName;
/*  264 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <E> JResponseBuilder<E> status(Response.StatusType status)
/*      */   {
/*  276 */     JResponseBuilder<E> b = new JResponseBuilder();
/*  277 */     b.status(status);
/*  278 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <E> JResponseBuilder<E> status(Response.Status status)
/*      */   {
/*  290 */     return status(status);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <E> JResponseBuilder<E> status(int status)
/*      */   {
/*  303 */     JResponseBuilder<E> b = new JResponseBuilder();
/*  304 */     b.status(status);
/*  305 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <E> JResponseBuilder<E> ok()
/*      */   {
/*  315 */     JResponseBuilder b = status(Response.Status.OK);
/*  316 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <E> JResponseBuilder<E> ok(E entity)
/*      */   {
/*  327 */     JResponseBuilder<E> b = ok();
/*  328 */     b.entity(entity);
/*  329 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <E> JResponseBuilder<E> ok(E entity, MediaType type)
/*      */   {
/*  341 */     JResponseBuilder<E> b = ok();
/*  342 */     b.entity(entity);
/*  343 */     b.type(type);
/*  344 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <E> JResponseBuilder<E> ok(E entity, String type)
/*      */   {
/*  356 */     JResponseBuilder<E> b = ok();
/*  357 */     b.entity(entity);
/*  358 */     b.type(type);
/*  359 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <E> JResponseBuilder<E> ok(E entity, Variant variant)
/*      */   {
/*  371 */     JResponseBuilder<E> b = ok();
/*  372 */     b.entity(entity);
/*  373 */     b.variant(variant);
/*  374 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <E> JResponseBuilder<E> serverError()
/*      */   {
/*  384 */     JResponseBuilder<E> b = status(Response.Status.INTERNAL_SERVER_ERROR);
/*  385 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <E> JResponseBuilder<E> created(URI location)
/*      */   {
/*  400 */     JResponseBuilder<E> b = (JResponseBuilder)status(Response.Status.CREATED).location(location);
/*  401 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <E> JResponseBuilder<E> noContent()
/*      */   {
/*  411 */     JResponseBuilder<E> b = status(Response.Status.NO_CONTENT);
/*  412 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <E> JResponseBuilder<E> notModified()
/*      */   {
/*  422 */     JResponseBuilder<E> b = status(Response.Status.NOT_MODIFIED);
/*  423 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <E> JResponseBuilder<E> notModified(EntityTag tag)
/*      */   {
/*  435 */     JResponseBuilder<E> b = notModified();
/*  436 */     b.tag(tag);
/*  437 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <E> JResponseBuilder<E> notModified(String tag)
/*      */   {
/*  452 */     JResponseBuilder b = notModified();
/*  453 */     b.tag(tag);
/*  454 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <E> JResponseBuilder<E> seeOther(URI location)
/*      */   {
/*  470 */     JResponseBuilder<E> b = (JResponseBuilder)status(Response.Status.SEE_OTHER).location(location);
/*  471 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <E> JResponseBuilder<E> temporaryRedirect(URI location)
/*      */   {
/*  486 */     JResponseBuilder<E> b = (JResponseBuilder)status(Response.Status.TEMPORARY_REDIRECT).location(location);
/*  487 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <E> JResponseBuilder<E> notAcceptable(List<Variant> variants)
/*      */   {
/*  499 */     JResponseBuilder<E> b = (JResponseBuilder)status(Response.Status.NOT_ACCEPTABLE).variants(variants);
/*  500 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final class JResponseBuilder<E>
/*      */     extends JResponse.AJResponseBuilder<E, JResponseBuilder<E>>
/*      */   {
/*      */     public JResponseBuilder() {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public JResponseBuilder(JResponseBuilder<E> that)
/*      */     {
/*  539 */       super();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public JResponseBuilder<E> clone()
/*      */     {
/*  550 */       return new JResponseBuilder(this);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public JResponse<E> build()
/*      */     {
/*  561 */       JResponse<E> r = new JResponse(this);
/*  562 */       reset();
/*  563 */       return r;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static abstract class AJResponseBuilder<E, B extends AJResponseBuilder>
/*      */   {
/*  579 */     protected Response.StatusType statusType = Response.Status.NO_CONTENT;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     protected OutBoundHeaders headers;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     protected E entity;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected AJResponseBuilder() {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected AJResponseBuilder(AJResponseBuilder<E, ?> that)
/*      */     {
/*  603 */       this.statusType = that.statusType;
/*  604 */       this.entity = that.entity;
/*  605 */       if (that.headers != null) {
/*  606 */         this.headers = new OutBoundHeaders(that.headers);
/*      */       } else {
/*  608 */         this.headers = null;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     protected void reset()
/*      */     {
/*  616 */       this.statusType = Response.Status.NO_CONTENT;
/*  617 */       this.entity = null;
/*  618 */       this.headers = null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected Response.StatusType getStatusType()
/*      */     {
/*  627 */       return this.statusType;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected int getStatus()
/*      */     {
/*  636 */       return this.statusType.getStatusCode();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected OutBoundHeaders getMetadata()
/*      */     {
/*  645 */       if (this.headers == null)
/*  646 */         this.headers = new OutBoundHeaders();
/*  647 */       return this.headers;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected E getEntity()
/*      */     {
/*  656 */       return (E)this.entity;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public B status(int status)
/*      */     {
/*  668 */       return status(ResponseImpl.toStatusType(status));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public B status(Response.StatusType status)
/*      */     {
/*  679 */       if (status == null)
/*  680 */         throw new IllegalArgumentException();
/*  681 */       this.statusType = status;
/*  682 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public B status(Response.Status status)
/*      */     {
/*  693 */       return status(status);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public B entity(E entity)
/*      */     {
/*  703 */       this.entity = entity;
/*  704 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public B type(MediaType type)
/*      */     {
/*  715 */       headerSingle("Content-Type", type);
/*  716 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public B type(String type)
/*      */     {
/*  728 */       return type(type == null ? null : MediaType.valueOf(type));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public B variant(Variant variant)
/*      */     {
/*  741 */       if (variant == null) {
/*  742 */         type((MediaType)null);
/*  743 */         language((String)null);
/*  744 */         encoding(null);
/*  745 */         return this;
/*      */       }
/*      */       
/*  748 */       type(variant.getMediaType());
/*      */       
/*  750 */       language(variant.getLanguage());
/*  751 */       encoding(variant.getEncoding());
/*      */       
/*  753 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public B variants(List<Variant> variants)
/*      */     {
/*  764 */       if (variants == null) {
/*  765 */         header("Vary", null);
/*  766 */         return this;
/*      */       }
/*      */       
/*  769 */       if (variants.isEmpty()) {
/*  770 */         return this;
/*      */       }
/*  772 */       MediaType accept = ((Variant)variants.get(0)).getMediaType();
/*  773 */       boolean vAccept = false;
/*      */       
/*  775 */       Locale acceptLanguage = ((Variant)variants.get(0)).getLanguage();
/*  776 */       boolean vAcceptLanguage = false;
/*      */       
/*  778 */       String acceptEncoding = ((Variant)variants.get(0)).getEncoding();
/*  779 */       boolean vAcceptEncoding = false;
/*      */       
/*  781 */       for (Variant v : variants) {
/*  782 */         vAccept |= ((!vAccept) && (vary(v.getMediaType(), accept)));
/*  783 */         vAcceptLanguage |= ((!vAcceptLanguage) && (vary(v.getLanguage(), acceptLanguage)));
/*  784 */         vAcceptEncoding |= ((!vAcceptEncoding) && (vary(v.getEncoding(), acceptEncoding)));
/*      */       }
/*      */       
/*  787 */       StringBuilder vary = new StringBuilder();
/*  788 */       append(vary, vAccept, "Accept");
/*  789 */       append(vary, vAcceptLanguage, "Accept-Language");
/*  790 */       append(vary, vAcceptEncoding, "Accept-Encoding");
/*      */       
/*  792 */       if (vary.length() > 0)
/*  793 */         header("Vary", vary.toString());
/*  794 */       return this;
/*      */     }
/*      */     
/*      */     private boolean vary(MediaType v, MediaType vary) {
/*  798 */       return (v != null) && (!v.equals(vary));
/*      */     }
/*      */     
/*      */     private boolean vary(Locale v, Locale vary) {
/*  802 */       return (v != null) && (!v.equals(vary));
/*      */     }
/*      */     
/*      */     private boolean vary(String v, String vary) {
/*  806 */       return (v != null) && (!v.equalsIgnoreCase(vary));
/*      */     }
/*      */     
/*      */     private void append(StringBuilder sb, boolean v, String s) {
/*  810 */       if (v) {
/*  811 */         if (sb.length() > 0)
/*  812 */           sb.append(',');
/*  813 */         sb.append(s);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public B language(String language)
/*      */     {
/*  825 */       headerSingle("Content-Language", language);
/*  826 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public B language(Locale language)
/*      */     {
/*  837 */       headerSingle("Content-Language", language);
/*  838 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public B location(URI location)
/*      */     {
/*  852 */       headerSingle("Location", location);
/*  853 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public B contentLocation(URI location)
/*      */     {
/*  865 */       headerSingle("Content-Location", location);
/*  866 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public B encoding(String encoding)
/*      */     {
/*  877 */       headerSingle("Content-Encoding", encoding);
/*  878 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public B tag(EntityTag tag)
/*      */     {
/*  889 */       headerSingle("ETag", tag);
/*  890 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public B tag(String tag)
/*      */     {
/*  903 */       return tag(tag == null ? null : new EntityTag(tag));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public B lastModified(Date lastModified)
/*      */     {
/*  914 */       headerSingle("Last-Modified", lastModified);
/*  915 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public B cacheControl(CacheControl cacheControl)
/*      */     {
/*  926 */       headerSingle("Cache-Control", cacheControl);
/*  927 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public B expires(Date expires)
/*      */     {
/*  938 */       headerSingle("Expires", expires);
/*  939 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public B cookie(NewCookie... cookies)
/*      */     {
/*  951 */       if (cookies != null) {
/*  952 */         for (NewCookie cookie : cookies)
/*  953 */           header("Set-Cookie", cookie);
/*      */       } else {
/*  955 */         header("Set-Cookie", null);
/*      */       }
/*  957 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public B header(String name, Object value)
/*      */     {
/*  974 */       return header(name, value, false);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public B headerSingle(String name, Object value)
/*      */     {
/*  991 */       return header(name, value, true);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public B header(String name, Object value, boolean single)
/*      */     {
/* 1010 */       if (value != null) {
/* 1011 */         if (single) {
/* 1012 */           getMetadata().putSingle(name, value);
/*      */         } else {
/* 1014 */           getMetadata().add(name, value);
/*      */         }
/*      */       } else {
/* 1017 */         getMetadata().remove(name);
/*      */       }
/* 1019 */       return this;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\JResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */