/*    */ package com.sun.jersey.api;
/*    */ 
/*    */ import javax.ws.rs.WebApplicationException;
/*    */ import javax.ws.rs.core.Response;
/*    */ import javax.ws.rs.core.Response.ResponseBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConflictException
/*    */   extends WebApplicationException
/*    */ {
/*    */   public ConflictException()
/*    */   {
/* 57 */     super(Responses.conflict().build());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ConflictException(String message)
/*    */   {
/* 65 */     super(Response.status(409).entity(message).type("text/plain").build());
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\ConflictException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */