/*     */ package com.sun.jersey.api.model;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AbstractResourceMethod
/*     */   extends AbstractMethod
/*     */   implements Parameterized, AbstractModelComponent
/*     */ {
/*     */   private String httpMethod;
/*     */   private List<MediaType> consumeMimeList;
/*     */   private List<MediaType> produceMimeList;
/*     */   private List<Parameter> parameters;
/*     */   private Class returnType;
/*     */   private Type genericReturnType;
/*     */   private boolean isConsumesDeclared;
/*     */   private boolean isProducesDeclared;
/*     */   
/*     */   public AbstractResourceMethod(AbstractResource resource, Method method, Class returnType, Type genericReturnType, String httpMethod, Annotation[] annotations)
/*     */   {
/*  70 */     super(resource, method, annotations);
/*     */     
/*  72 */     this.httpMethod = httpMethod.toUpperCase();
/*  73 */     this.consumeMimeList = new ArrayList();
/*  74 */     this.produceMimeList = new ArrayList();
/*  75 */     this.returnType = returnType;
/*  76 */     this.genericReturnType = genericReturnType;
/*  77 */     this.parameters = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */   public AbstractResource getDeclaringResource()
/*     */   {
/*  83 */     return getResource();
/*     */   }
/*     */   
/*     */   public Class getReturnType() {
/*  87 */     return this.returnType;
/*     */   }
/*     */   
/*     */   public Type getGenericReturnType() {
/*  91 */     return this.genericReturnType;
/*     */   }
/*     */   
/*     */   public List<MediaType> getSupportedInputTypes() {
/*  95 */     return this.consumeMimeList;
/*     */   }
/*     */   
/*     */   public void setAreInputTypesDeclared(boolean declared) {
/*  99 */     this.isConsumesDeclared = declared;
/*     */   }
/*     */   
/*     */   public boolean areInputTypesDeclared() {
/* 103 */     return this.isConsumesDeclared;
/*     */   }
/*     */   
/*     */   public List<MediaType> getSupportedOutputTypes() {
/* 107 */     return this.produceMimeList;
/*     */   }
/*     */   
/*     */   public void setAreOutputTypesDeclared(boolean declared) {
/* 111 */     this.isProducesDeclared = declared;
/*     */   }
/*     */   
/*     */   public boolean areOutputTypesDeclared() {
/* 115 */     return this.isProducesDeclared;
/*     */   }
/*     */   
/*     */   public String getHttpMethod() {
/* 119 */     return this.httpMethod;
/*     */   }
/*     */   
/*     */   public boolean hasEntity() {
/* 123 */     for (Parameter p : getParameters()) {
/* 124 */       if (Parameter.Source.ENTITY == p.getSource()) {
/* 125 */         return true;
/*     */       }
/*     */     }
/* 128 */     return false;
/*     */   }
/*     */   
/*     */   public List<Parameter> getParameters()
/*     */   {
/* 133 */     return this.parameters;
/*     */   }
/*     */   
/*     */   public void accept(AbstractModelVisitor visitor)
/*     */   {
/* 138 */     visitor.visitAbstractResourceMethod(this);
/*     */   }
/*     */   
/*     */   public List<AbstractModelComponent> getComponents()
/*     */   {
/* 143 */     return null;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 148 */     return "AbstractResourceMethod(" + getMethod().getDeclaringClass().getSimpleName() + "#" + getMethod().getName() + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\model\AbstractResourceMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */