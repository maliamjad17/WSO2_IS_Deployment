package com.sun.jersey.spi.template;

import com.sun.jersey.api.view.Viewable;
import java.io.IOException;
import java.io.OutputStream;

public abstract interface ViewProcessor<T>
{
  public abstract T resolve(String paramString);
  
  public abstract void writeTo(T paramT, Viewable paramViewable, OutputStream paramOutputStream)
    throws IOException;
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\template\ViewProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */