/*     */ package com.sun.jersey.server.impl.wadl;
/*     */ 
/*     */ import com.sun.jersey.server.wadl.WadlApplicationContext;
/*     */ import com.sun.jersey.spi.resource.Singleton;
/*     */ import com.sun.research.ws.wadl.Application;
/*     */ import com.sun.research.ws.wadl.Resources;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.net.URI;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.ws.rs.GET;
/*     */ import javax.ws.rs.Produces;
/*     */ import javax.ws.rs.core.Context;
/*     */ import javax.ws.rs.core.Response;
/*     */ import javax.ws.rs.core.Response.ResponseBuilder;
/*     */ import javax.ws.rs.core.Response.Status;
/*     */ import javax.ws.rs.core.UriInfo;
/*     */ import javax.xml.bind.JAXBContext;
/*     */ import javax.xml.bind.Marshaller;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Produces({"application/vnd.sun.wadl+xml", "application/xml"})
/*     */ @Singleton
/*     */ public final class WadlResource
/*     */ {
/*  67 */   private static final Logger LOGGER = Logger.getLogger(WadlResource.class.getName());
/*     */   
/*     */   private WadlApplicationContext wadlContext;
/*     */   
/*     */   private Application application;
/*     */   private byte[] wadlXmlRepresentation;
/*     */   
/*     */   public WadlResource(@Context WadlApplicationContext wadlContext)
/*     */   {
/*  76 */     this.wadlContext = wadlContext;
/*  77 */     this.application = wadlContext.getApplication();
/*     */   }
/*     */   
/*     */   @GET
/*     */   public synchronized Response getWadl(@Context UriInfo uriInfo) {
/*  82 */     if (!this.wadlContext.isWadlGenerationEnabled()) {
/*  83 */       return Response.status(Response.Status.NOT_FOUND).build();
/*     */     }
/*     */     
/*  86 */     if (this.wadlXmlRepresentation == null) {
/*  87 */       if (this.application.getResources().getBase() == null) {
/*  88 */         this.application.getResources().setBase(uriInfo.getBaseUri().toString());
/*     */       }
/*     */       try {
/*  91 */         Marshaller marshaller = this.wadlContext.getJAXBContext().createMarshaller();
/*  92 */         marshaller.setProperty("jaxb.formatted.output", Boolean.valueOf(true));
/*  93 */         ByteArrayOutputStream os = new ByteArrayOutputStream();
/*  94 */         marshaller.marshal(this.application, os);
/*  95 */         this.wadlXmlRepresentation = os.toByteArray();
/*  96 */         os.close();
/*     */       } catch (Exception e) {
/*  98 */         LOGGER.log(Level.WARNING, "Could not marshal wadl Application.", e);
/*  99 */         return Response.ok(this.application).build();
/*     */       }
/*     */     }
/*     */     
/* 103 */     return Response.ok(new ByteArrayInputStream(this.wadlXmlRepresentation)).build();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\wadl\WadlResource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */