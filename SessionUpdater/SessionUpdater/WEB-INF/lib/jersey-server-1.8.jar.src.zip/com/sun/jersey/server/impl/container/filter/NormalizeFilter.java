/*    */ package com.sun.jersey.server.impl.container.filter;
/*    */ 
/*    */ import com.sun.jersey.api.core.ResourceConfig;
/*    */ import com.sun.jersey.server.impl.uri.UriHelper;
/*    */ import com.sun.jersey.spi.container.ContainerRequest;
/*    */ import com.sun.jersey.spi.container.ContainerRequestFilter;
/*    */ import java.net.URI;
/*    */ import javax.ws.rs.WebApplicationException;
/*    */ import javax.ws.rs.core.Context;
/*    */ import javax.ws.rs.core.Response;
/*    */ import javax.ws.rs.core.Response.ResponseBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NormalizeFilter
/*    */   implements ContainerRequestFilter
/*    */ {
/*    */   @Context
/*    */   ResourceConfig resourceConfig;
/*    */   
/*    */   public ContainerRequest filter(ContainerRequest request)
/*    */   {
/* 59 */     if (this.resourceConfig.getFeature("com.sun.jersey.config.feature.NormalizeURI")) {
/* 60 */       URI uri = request.getRequestUri();
/* 61 */       URI normalizedUri = UriHelper.normalize(uri, !this.resourceConfig.getFeature("com.sun.jersey.config.feature.CanonicalizeURIPath"));
/*    */       
/*    */ 
/* 64 */       if (uri != normalizedUri) {
/* 65 */         if (this.resourceConfig.getFeature("com.sun.jersey.config.feature.Redirect")) {
/* 66 */           throw new WebApplicationException(Response.temporaryRedirect(normalizedUri).build());
/*    */         }
/*    */         
/* 69 */         URI baseUri = UriHelper.normalize(request.getBaseUri(), !this.resourceConfig.getFeature("com.sun.jersey.config.feature.CanonicalizeURIPath"));
/*    */         
/* 71 */         request.setUris(baseUri, normalizedUri);
/*    */       }
/*    */     }
/*    */     
/* 75 */     return request;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\container\filter\NormalizeFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */