/*     */ package com.sun.jersey.api.container.filter;
/*     */ 
/*     */ import com.sun.jersey.api.core.ExtendedUriInfo;
/*     */ import com.sun.jersey.api.core.HttpContext;
/*     */ import com.sun.jersey.api.model.AbstractMethod;
/*     */ import com.sun.jersey.api.model.AbstractResource;
/*     */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*     */ import com.sun.jersey.api.model.AbstractSubResourceLocator;
/*     */ import com.sun.jersey.api.model.AbstractSubResourceMethod;
/*     */ import com.sun.jersey.api.model.PathValue;
/*     */ import com.sun.jersey.spi.container.ContainerRequest;
/*     */ import com.sun.jersey.spi.container.ContainerRequestFilter;
/*     */ import com.sun.jersey.spi.container.ContainerResponseFilter;
/*     */ import com.sun.jersey.spi.container.ResourceFilter;
/*     */ import com.sun.jersey.spi.container.ResourceFilterFactory;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.ws.rs.core.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceDebuggingFilterFactory
/*     */   implements ResourceFilterFactory
/*     */ {
/*     */   private final HttpContext context;
/*     */   
/*  82 */   public ResourceDebuggingFilterFactory(@Context HttpContext hc) { this.context = hc; }
/*     */   
/*     */   abstract class AbstractRequestFilter implements ResourceFilter, ContainerRequestFilter {
/*     */     AbstractRequestFilter() {}
/*     */     
/*  87 */     protected Logger LOGGER = Logger.getLogger(AbstractRequestFilter.class.getCanonicalName());
/*     */     
/*     */     public ContainerRequestFilter getRequestFilter() {
/*  90 */       return this;
/*     */     }
/*     */     
/*     */     public ContainerResponseFilter getResponseFilter() {
/*  94 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   private class ResourceMethodFilter extends ResourceDebuggingFilterFactory.AbstractRequestFilter {
/*     */     private final AbstractResourceMethod arm;
/*     */     
/*     */     public ResourceMethodFilter(AbstractResourceMethod arm) {
/* 102 */       super();
/* 103 */       this.arm = arm;
/*     */     }
/*     */     
/*     */     public ContainerRequest filter(ContainerRequest request) {
/* 107 */       this.LOGGER.log(Level.INFO, "Resource Method matched.\n HttpMethod: " + this.arm.getHttpMethod() + "\n Resource: " + this.arm.getDeclaringResource().getResourceClass().getName() + "\n Method: " + this.arm.getMethod().toGenericString());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 113 */       return request;
/*     */     }
/*     */   }
/*     */   
/*     */   private class SubResourceMethodFilter extends ResourceDebuggingFilterFactory.AbstractRequestFilter {
/*     */     private final AbstractSubResourceMethod asrm;
/*     */     
/*     */     public SubResourceMethodFilter(AbstractSubResourceMethod asrm) {
/* 121 */       super();
/* 122 */       this.asrm = asrm;
/*     */     }
/*     */     
/*     */     public ContainerRequest filter(ContainerRequest request) {
/* 126 */       this.LOGGER.log(Level.INFO, "Sub-Resource Method matched.\n Path: " + this.asrm.getPath().getValue() + (ResourceDebuggingFilterFactory.this.context != null ? "\n Matched Result: " + ResourceDebuggingFilterFactory.this.context.getUriInfo().getMatchedResults().get(0) : "") + "\n HttpMethod: " + this.asrm.getHttpMethod() + "\n Resource: " + this.asrm.getDeclaringResource().getResourceClass().getName() + "\n Method: " + this.asrm.getMethod().toGenericString());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 134 */       return request;
/*     */     }
/*     */   }
/*     */   
/*     */   private class SubResourceLocatorFilter extends ResourceDebuggingFilterFactory.AbstractRequestFilter {
/*     */     private final AbstractSubResourceLocator asrl;
/*     */     
/*     */     public SubResourceLocatorFilter(AbstractSubResourceLocator asrl) {
/* 142 */       super();
/* 143 */       this.asrl = asrl;
/*     */     }
/*     */     
/*     */     public ContainerRequest filter(ContainerRequest request) {
/* 147 */       this.LOGGER.log(Level.INFO, "Sub-Resource Locator matched. \n Path: " + this.asrl.getPath().getValue() + (ResourceDebuggingFilterFactory.this.context != null ? "\n Matched Result: " + ResourceDebuggingFilterFactory.this.context.getUriInfo().getMatchedResults().get(0) : "") + "\n Resource: " + this.asrl.getResource().getResourceClass().getName() + "\n Method: " + this.asrl.getMethod().toGenericString());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 154 */       return request;
/*     */     }
/*     */   }
/*     */   
/*     */   public List<ResourceFilter> create(AbstractMethod am)
/*     */   {
/* 160 */     if ((am instanceof AbstractSubResourceMethod))
/* 161 */       return Collections.singletonList(new SubResourceMethodFilter((AbstractSubResourceMethod)am));
/* 162 */     if ((am instanceof AbstractResourceMethod))
/* 163 */       return Collections.singletonList(new ResourceMethodFilter((AbstractResourceMethod)am));
/* 164 */     if ((am instanceof AbstractSubResourceLocator)) {
/* 165 */       return Collections.singletonList(new SubResourceLocatorFilter((AbstractSubResourceLocator)am));
/*     */     }
/* 167 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\container\filter\ResourceDebuggingFilterFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */