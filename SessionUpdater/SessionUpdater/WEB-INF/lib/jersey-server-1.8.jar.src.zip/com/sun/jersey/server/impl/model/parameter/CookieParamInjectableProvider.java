/*     */ package com.sun.jersey.server.impl.model.parameter;
/*     */ 
/*     */ import com.sun.jersey.api.ParamException.CookieParamException;
/*     */ import com.sun.jersey.api.core.HttpContext;
/*     */ import com.sun.jersey.api.core.HttpRequestContext;
/*     */ import com.sun.jersey.api.model.Parameter;
/*     */ import com.sun.jersey.core.spi.component.ComponentContext;
/*     */ import com.sun.jersey.server.impl.inject.AbstractHttpContextInjectable;
/*     */ import com.sun.jersey.server.impl.model.parameter.multivalued.ExtractorContainerException;
/*     */ import com.sun.jersey.server.impl.model.parameter.multivalued.MultivaluedParameterExtractor;
/*     */ import com.sun.jersey.server.impl.model.parameter.multivalued.MultivaluedParameterExtractorProvider;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import java.util.Map;
/*     */ import javax.ws.rs.CookieParam;
/*     */ import javax.ws.rs.core.Cookie;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CookieParamInjectableProvider
/*     */   extends BaseParamInjectableProvider<CookieParam>
/*     */ {
/*     */   private static final class CookieParamInjectable
/*     */     extends AbstractHttpContextInjectable<Object>
/*     */   {
/*     */     private final MultivaluedParameterExtractor extractor;
/*     */     
/*     */     CookieParamInjectable(MultivaluedParameterExtractor extractor)
/*     */     {
/*  66 */       this.extractor = extractor;
/*     */     }
/*     */     
/*     */     public Object getValue(HttpContext context) {
/*     */       try {
/*  71 */         return this.extractor.extract(context.getRequest().getCookieNameValueMap());
/*     */       } catch (ExtractorContainerException e) {
/*  73 */         throw new ParamException.CookieParamException(e.getCause(), this.extractor.getName(), this.extractor.getDefaultStringValue());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class CookieTypeParamInjectable extends AbstractHttpContextInjectable<Cookie>
/*     */   {
/*     */     private final String name;
/*     */     
/*     */     CookieTypeParamInjectable(String name) {
/*  83 */       this.name = name;
/*     */     }
/*     */     
/*     */     public Cookie getValue(HttpContext context) {
/*  87 */       return (Cookie)context.getRequest().getCookies().get(this.name);
/*     */     }
/*     */   }
/*     */   
/*     */   public CookieParamInjectableProvider(MultivaluedParameterExtractorProvider w) {
/*  92 */     super(w);
/*     */   }
/*     */   
/*     */   public Injectable getInjectable(ComponentContext ic, CookieParam a, Parameter c) {
/*  96 */     String parameterName = c.getSourceName();
/*  97 */     if ((parameterName == null) || (parameterName.length() == 0))
/*     */     {
/*  99 */       return null;
/*     */     }
/*     */     
/* 102 */     if (c.getParameterClass() == Cookie.class) {
/* 103 */       return new CookieTypeParamInjectable(parameterName);
/*     */     }
/* 105 */     MultivaluedParameterExtractor e = get(c);
/*     */     
/* 107 */     if (e == null)
/* 108 */       return null;
/* 109 */     return new CookieParamInjectable(e);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\parameter\CookieParamInjectableProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */