/*     */ package com.sun.jersey.server.wadl.generators;
/*     */ 
/*     */ import com.sun.jersey.api.model.AbstractMethod;
/*     */ import com.sun.jersey.api.model.AbstractResource;
/*     */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*     */ import com.sun.jersey.api.model.Parameter;
/*     */ import com.sun.jersey.server.wadl.WadlGenerator;
/*     */ import com.sun.research.ws.wadl.Application;
/*     */ import com.sun.research.ws.wadl.Method;
/*     */ import com.sun.research.ws.wadl.Param;
/*     */ import com.sun.research.ws.wadl.RepresentationType;
/*     */ import com.sun.research.ws.wadl.Request;
/*     */ import com.sun.research.ws.wadl.Resource;
/*     */ import com.sun.research.ws.wadl.Resources;
/*     */ import com.sun.research.ws.wadl.Response;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.util.List;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.xml.bind.JAXBContext;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WadlGeneratorApplicationDoc
/*     */   implements WadlGenerator
/*     */ {
/*     */   private WadlGenerator _delegate;
/*     */   private File _applicationDocsFile;
/*     */   private InputStream _applicationDocsStream;
/*     */   private ApplicationDocs _applicationDocs;
/*     */   
/*     */   public WadlGeneratorApplicationDoc() {}
/*     */   
/*     */   public WadlGeneratorApplicationDoc(WadlGenerator wadlGenerator, ApplicationDocs applicationDocs)
/*     */   {
/*  94 */     this._delegate = wadlGenerator;
/*  95 */     this._applicationDocs = applicationDocs;
/*     */   }
/*     */   
/*     */   public void setWadlGeneratorDelegate(WadlGenerator delegate) {
/*  99 */     this._delegate = delegate;
/*     */   }
/*     */   
/*     */   public String getRequiredJaxbContextPath() {
/* 103 */     return this._delegate.getRequiredJaxbContextPath();
/*     */   }
/*     */   
/*     */   public void setApplicationDocsFile(File applicationDocsFile) {
/* 107 */     if (this._applicationDocsStream != null) {
/* 108 */       throw new IllegalStateException("The applicationDocsStream property is already set, therefore you cannot set the applicationDocsFile property. Only one of both can be set at a time.");
/*     */     }
/*     */     
/* 111 */     this._applicationDocsFile = applicationDocsFile;
/*     */   }
/*     */   
/*     */   public void setApplicationDocsStream(InputStream applicationDocsStream) {
/* 115 */     if (this._applicationDocsFile != null) {
/* 116 */       throw new IllegalStateException("The applicationDocsFile property is already set, therefore you cannot set the applicationDocsStream property. Only one of both can be set at a time.");
/*     */     }
/*     */     
/* 119 */     this._applicationDocsStream = applicationDocsStream;
/*     */   }
/*     */   
/*     */   public void init() throws Exception {
/* 123 */     if ((this._applicationDocsFile == null) && (this._applicationDocsStream == null)) {
/* 124 */       throw new IllegalStateException("Neither the applicationDocsFile nor the applicationDocsStream is set, one of both is required.");
/*     */     }
/*     */     
/* 127 */     this._delegate.init();
/* 128 */     String name = ApplicationDocs.class.getName();
/* 129 */     int i = name.lastIndexOf('.');
/* 130 */     name = i != -1 ? name.substring(0, i) : "";
/* 131 */     JAXBContext c = JAXBContext.newInstance(name, Thread.currentThread().getContextClassLoader());
/*     */     
/* 133 */     Unmarshaller m = c.createUnmarshaller();
/* 134 */     Object obj = this._applicationDocsFile != null ? m.unmarshal(this._applicationDocsFile) : m.unmarshal(this._applicationDocsStream);
/*     */     
/* 136 */     this._applicationDocs = ((ApplicationDocs)ApplicationDocs.class.cast(obj));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Application createApplication()
/*     */   {
/* 144 */     Application result = this._delegate.createApplication();
/* 145 */     if ((this._applicationDocs != null) && (this._applicationDocs.getDocs() != null) && (!this._applicationDocs.getDocs().isEmpty()))
/*     */     {
/* 147 */       result.getDoc().addAll(this._applicationDocs.getDocs());
/*     */     }
/* 149 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Method createMethod(AbstractResource r, AbstractResourceMethod m)
/*     */   {
/* 159 */     return this._delegate.createMethod(r, m);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RepresentationType createRequestRepresentation(AbstractResource r, AbstractResourceMethod m, MediaType mediaType)
/*     */   {
/* 171 */     return this._delegate.createRequestRepresentation(r, m, mediaType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Request createRequest(AbstractResource r, AbstractResourceMethod m)
/*     */   {
/* 181 */     return this._delegate.createRequest(r, m);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Param createParam(AbstractResource r, AbstractMethod m, Parameter p)
/*     */   {
/* 193 */     return this._delegate.createParam(r, m, p);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Resource createResource(AbstractResource r, String path)
/*     */   {
/* 203 */     return this._delegate.createResource(r, path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Response createResponse(AbstractResource r, AbstractResourceMethod m)
/*     */   {
/* 213 */     return this._delegate.createResponse(r, m);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Resources createResources()
/*     */   {
/* 221 */     return this._delegate.createResources();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\wadl\generators\WadlGeneratorApplicationDoc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */