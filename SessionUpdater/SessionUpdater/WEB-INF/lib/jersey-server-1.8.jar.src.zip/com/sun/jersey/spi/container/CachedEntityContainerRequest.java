/*    */ package com.sun.jersey.spi.container;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CachedEntityContainerRequest
/*    */   extends AdaptingContainerRequest
/*    */ {
/*    */   Object entity;
/*    */   
/*    */   public CachedEntityContainerRequest(ContainerRequest acr)
/*    */   {
/* 59 */     super(acr);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public <T> T getEntity(Class<T> type)
/*    */     throws ClassCastException
/*    */   {
/* 73 */     if (this.entity == null) {
/* 74 */       T t = this.acr.getEntity(type);
/* 75 */       this.entity = t;
/* 76 */       return t;
/*    */     }
/* 78 */     return (T)type.cast(this.entity);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public <T> T getEntity(Class<T> type, Type genericType, Annotation[] as)
/*    */     throws ClassCastException
/*    */   {
/* 93 */     if (this.entity == null) {
/* 94 */       T t = this.acr.getEntity(type, genericType, as);
/* 95 */       this.entity = t;
/* 96 */       return t;
/*    */     }
/* 98 */     return (T)type.cast(this.entity);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\container\CachedEntityContainerRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */