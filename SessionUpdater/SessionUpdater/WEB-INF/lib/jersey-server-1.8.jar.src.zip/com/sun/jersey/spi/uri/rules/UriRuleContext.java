package com.sun.jersey.spi.uri.rules;

import com.sun.jersey.api.core.HttpContext;
import com.sun.jersey.api.model.AbstractResourceMethod;
import com.sun.jersey.api.uri.UriTemplate;
import com.sun.jersey.spi.container.ContainerRequest;
import com.sun.jersey.spi.container.ContainerResponse;
import com.sun.jersey.spi.container.ContainerResponseFilter;
import java.util.List;

public abstract interface UriRuleContext
  extends HttpContext, UriMatchResultContext
{
  public abstract ContainerRequest getContainerRequest();
  
  public abstract void setContainerRequest(ContainerRequest paramContainerRequest);
  
  public abstract ContainerResponse getContainerResponse();
  
  public abstract void setContainerResponse(ContainerResponse paramContainerResponse);
  
  public abstract void pushContainerResponseFilters(List<ContainerResponseFilter> paramList);
  
  public abstract Object getResource(Class paramClass);
  
  public abstract UriRules<UriRule> getRules(Class paramClass);
  
  public abstract void pushMatch(UriTemplate paramUriTemplate, List<String> paramList);
  
  public abstract void pushResource(Object paramObject);
  
  public abstract void pushMethod(AbstractResourceMethod paramAbstractResourceMethod);
  
  public abstract void pushRightHandPathLength(int paramInt);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\uri\rules\UriRuleContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */