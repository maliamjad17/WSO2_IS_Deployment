/*     */ package com.sun.jersey.api.wadl;
/*     */ 
/*     */ import com.sun.jersey.api.core.ClasspathResourceConfig;
/*     */ import com.sun.jersey.api.core.ResourceConfig;
/*     */ import com.sun.jersey.api.model.AbstractResource;
/*     */ import com.sun.jersey.server.impl.modelapi.annotation.IntrospectionModeller;
/*     */ import com.sun.jersey.server.wadl.WadlBuilder;
/*     */ import com.sun.research.ws.wadl.Application;
/*     */ import com.sun.research.ws.wadl.Resources;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.xml.bind.JAXBContext;
/*     */ import javax.xml.bind.Marshaller;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.Task;
/*     */ import org.apache.tools.ant.types.Path;
/*     */ import org.apache.tools.ant.types.Reference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WadlGeneratorTask
/*     */   extends Task
/*     */ {
/*     */   private Path classpath;
/*     */   private File wadlFile;
/*     */   private String baseUri;
/*     */   
/*     */   public Path getClasspath()
/*     */   {
/*  83 */     return this.classpath;
/*     */   }
/*     */   
/*     */   public void setClasspath(Path classpath) {
/*  87 */     if (this.classpath == null) {
/*  88 */       this.classpath = classpath;
/*     */     } else {
/*  90 */       this.classpath.append(classpath);
/*     */     }
/*     */   }
/*     */   
/*     */   public Path createClasspath() {
/*  95 */     if (this.classpath == null) {
/*  96 */       this.classpath = new Path(getProject());
/*     */     }
/*  98 */     return this.classpath.createPath();
/*     */   }
/*     */   
/*     */   public void setClasspathRef(Reference r) {
/* 102 */     createClasspath().setRefid(r);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public File getDestfile()
/*     */   {
/* 109 */     return this.wadlFile;
/*     */   }
/*     */   
/*     */   public void setDestfile(File wadlFile) {
/* 113 */     this.wadlFile = wadlFile;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getbaseUri()
/*     */   {
/* 119 */     return this.baseUri;
/*     */   }
/*     */   
/*     */   public void setBaseUri(String baseUri) {
/* 123 */     this.baseUri = baseUri;
/*     */   }
/*     */   
/*     */   public void execute() throws BuildException
/*     */   {
/* 128 */     if (this.classpath == null) {
/* 129 */       throw new BuildException("The classpath is not defined");
/*     */     }
/* 131 */     if (this.wadlFile == null) {
/* 132 */       throw new BuildException("destfile attribute required", getLocation());
/*     */     }
/*     */     
/* 135 */     if ((this.baseUri == null) || (this.baseUri.length() == 0)) {
/* 136 */       throw new BuildException("baseUri attribute required", getLocation());
/*     */     }
/*     */     try
/*     */     {
/* 140 */       Application a = createApplication(this.classpath.list());
/* 141 */       a.getResources().setBase(this.baseUri);
/* 142 */       JAXBContext c = JAXBContext.newInstance("com.sun.research.ws.wadl", getClass().getClassLoader());
/*     */       
/* 144 */       Marshaller m = c.createMarshaller();
/* 145 */       OutputStream out = new BufferedOutputStream(new FileOutputStream(this.wadlFile));
/* 146 */       m.marshal(a, out);
/* 147 */       out.close();
/*     */     } catch (Exception e) {
/* 149 */       throw new BuildException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   private Application createApplication(String[] paths) {
/* 154 */     ClassLoader cl = Thread.currentThread().getContextClassLoader();
/* 155 */     ClassLoader ncl = new Loader(this.classpath.list(), getClass().getClassLoader());
/* 156 */     Thread.currentThread().setContextClassLoader(ncl);
/*     */     try {
/* 158 */       ResourceConfig rc = new ClasspathResourceConfig(this.classpath.list());
/* 159 */       rc.validate();
/* 160 */       Set<AbstractResource> s = new HashSet();
/* 161 */       for (Class c : rc.getRootResourceClasses()) {
/* 162 */         s.add(IntrospectionModeller.createResource(c));
/*     */       }
/* 164 */       return new WadlBuilder().generate(s);
/*     */     } catch (Exception e) {
/* 166 */       throw new BuildException(e);
/*     */     } finally {
/* 168 */       Thread.currentThread().setContextClassLoader(cl);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Loader extends URLClassLoader {
/*     */     Loader(String[] paths, ClassLoader parent) {
/* 174 */       super(parent);
/*     */     }
/*     */     
/*     */     Loader(String[] paths) {
/* 178 */       super();
/*     */     }
/*     */     
/*     */     public Class findClass(String name) throws ClassNotFoundException
/*     */     {
/* 183 */       Class c = super.findClass(name);
/* 184 */       return c;
/*     */     }
/*     */     
/*     */     private static URL[] getURLs(String[] paths) {
/* 188 */       List<URL> urls = new ArrayList();
/* 189 */       for (String path : paths) {
/*     */         try {
/* 191 */           urls.add(new File(path).toURI().toURL());
/*     */         } catch (MalformedURLException e) {
/* 193 */           throw new RuntimeException(e);
/*     */         }
/*     */       }
/*     */       
/* 197 */       URL[] us = (URL[])urls.toArray(new URL[0]);
/* 198 */       return us;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\wadl\WadlGeneratorTask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */