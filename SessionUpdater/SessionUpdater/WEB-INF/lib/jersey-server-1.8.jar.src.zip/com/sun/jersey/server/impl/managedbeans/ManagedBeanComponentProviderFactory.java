/*     */ package com.sun.jersey.server.impl.managedbeans;
/*     */ 
/*     */ import com.sun.jersey.api.container.ContainerException;
/*     */ import com.sun.jersey.core.spi.component.ComponentContext;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCComponentProvider;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCComponentProviderFactory;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCDestroyable;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCInstantiatedComponentProvider;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.logging.Logger;
/*     */ import javax.annotation.ManagedBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ManagedBeanComponentProviderFactory
/*     */   implements IoCComponentProviderFactory
/*     */ {
/*  59 */   private static final Logger LOGGER = Logger.getLogger(ManagedBeanComponentProviderFactory.class.getName());
/*     */   
/*     */   private final Object injectionMgr;
/*     */   
/*     */   private final Method createManagedObjectMethod;
/*     */   
/*     */   private final Method destroyManagedObjectMethod;
/*     */   
/*     */ 
/*     */   public ManagedBeanComponentProviderFactory(Object injectionMgr, Method createManagedObjectMethod, Method destroyManagedObjectMethod)
/*     */   {
/*  70 */     this.injectionMgr = injectionMgr;
/*  71 */     this.createManagedObjectMethod = createManagedObjectMethod;
/*  72 */     this.destroyManagedObjectMethod = destroyManagedObjectMethod;
/*     */   }
/*     */   
/*     */ 
/*     */   public IoCComponentProvider getComponentProvider(Class<?> c)
/*     */   {
/*  78 */     return getComponentProvider(null, c);
/*     */   }
/*     */   
/*     */   public IoCComponentProvider getComponentProvider(ComponentContext cc, Class<?> c) {
/*  82 */     if (!isManagedBean(c)) {
/*  83 */       return null;
/*     */     }
/*  85 */     LOGGER.info("Binding the Managed bean class " + c.getName() + " to ManagedBeanComponentProvider");
/*     */     
/*     */ 
/*  88 */     return new ManagedBeanComponentProvider(c);
/*     */   }
/*     */   
/*     */   private boolean isManagedBean(Class<?> c) {
/*  92 */     return c.isAnnotationPresent(ManagedBean.class);
/*     */   }
/*     */   
/*     */   private class ManagedBeanComponentProvider implements IoCInstantiatedComponentProvider, IoCDestroyable
/*     */   {
/*     */     private final Class<?> c;
/*     */     
/*     */     ManagedBeanComponentProvider() {
/* 100 */       this.c = c;
/*     */     }
/*     */     
/*     */     public Object getInstance()
/*     */     {
/*     */       try
/*     */       {
/* 107 */         return ManagedBeanComponentProviderFactory.this.createManagedObjectMethod.invoke(ManagedBeanComponentProviderFactory.this.injectionMgr, new Object[] { this.c });
/*     */       } catch (Exception ex) {
/* 109 */         throw new ContainerException(ex);
/*     */       }
/*     */     }
/*     */     
/*     */     public Object getInjectableInstance(Object o) {
/* 114 */       return o;
/*     */     }
/*     */     
/*     */     public void destroy(Object o)
/*     */     {
/*     */       try
/*     */       {
/* 121 */         ManagedBeanComponentProviderFactory.this.destroyManagedObjectMethod.invoke(ManagedBeanComponentProviderFactory.this.injectionMgr, new Object[] { o });
/*     */       } catch (Exception ex) {
/* 123 */         throw new ContainerException(ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\managedbeans\ManagedBeanComponentProviderFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */