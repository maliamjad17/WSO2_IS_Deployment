/*     */ package com.sun.jersey.server.impl.ejb;
/*     */ 
/*     */ import com.sun.jersey.api.model.AbstractResource;
/*     */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*     */ import com.sun.jersey.spi.container.JavaMethodInvoker;
/*     */ import com.sun.jersey.spi.container.ResourceMethodCustomInvokerDispatchFactory;
/*     */ import com.sun.jersey.spi.container.ResourceMethodDispatchProvider;
/*     */ import com.sun.jersey.spi.dispatch.RequestDispatcher;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.ejb.Local;
/*     */ import javax.ejb.Remote;
/*     */ import javax.ejb.Stateful;
/*     */ import javax.ejb.Stateless;
/*     */ import javax.ws.rs.core.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EJBRequestDispatcherProvider
/*     */   implements ResourceMethodDispatchProvider
/*     */ {
/*     */   @Context
/*     */   ResourceMethodCustomInvokerDispatchFactory rdFactory;
/*     */   
/*     */   public RequestDispatcher create(AbstractResourceMethod abstractResourceMethod)
/*     */   {
/*  77 */     AbstractResource declaringResource = abstractResourceMethod.getDeclaringResource();
/*     */     Method javaMethod;
/*  79 */     if (isSessionBean(declaringResource))
/*     */     {
/*  81 */       Class<?> resourceClass = declaringResource.getResourceClass();
/*  82 */       javaMethod = abstractResourceMethod.getMethod();
/*     */       
/*  84 */       for (Class iFace : remoteAndLocalIfaces(resourceClass)) {
/*     */         try {
/*  86 */           Method iFaceMethod = iFace.getDeclaredMethod(javaMethod.getName(), javaMethod.getParameterTypes());
/*  87 */           if (iFaceMethod != null) {
/*  88 */             return createDispatcher(abstractResourceMethod, iFaceMethod);
/*     */           }
/*     */         }
/*     */         catch (NoSuchMethodException ex) {}catch (SecurityException ex) {
/*  92 */           Logger.getLogger(EJBRequestDispatcherProvider.class.getName()).log(Level.SEVERE, null, ex);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  97 */     return null;
/*     */   }
/*     */   
/*     */   private List<Class> remoteAndLocalIfaces(Class<?> resourceClass) {
/* 101 */     List<Class> allLocalOrRemoteIfaces = new LinkedList();
/* 102 */     if (resourceClass.isAnnotationPresent(Remote.class)) {
/* 103 */       allLocalOrRemoteIfaces.addAll(Arrays.asList(((Remote)resourceClass.getAnnotation(Remote.class)).value()));
/*     */     }
/* 105 */     if (resourceClass.isAnnotationPresent(Local.class)) {
/* 106 */       allLocalOrRemoteIfaces.addAll(Arrays.asList(((Local)resourceClass.getAnnotation(Local.class)).value()));
/*     */     }
/* 108 */     for (Class<?> i : resourceClass.getInterfaces()) {
/* 109 */       if ((i.isAnnotationPresent(Remote.class)) || (i.isAnnotationPresent(Local.class))) {
/* 110 */         allLocalOrRemoteIfaces.add(i);
/*     */       }
/*     */     }
/* 113 */     return allLocalOrRemoteIfaces;
/*     */   }
/*     */   
/*     */   private RequestDispatcher createDispatcher(AbstractResourceMethod abstractResourceMethod, final Method iFaceMethod) {
/* 117 */     this.rdFactory.getDispatcher(abstractResourceMethod, new JavaMethodInvoker()
/*     */     {
/*     */       public Object invoke(Method m, Object o, Object... parameters) throws InvocationTargetException, IllegalAccessException
/*     */       {
/* 121 */         return iFaceMethod.invoke(o, parameters);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private boolean isSessionBean(AbstractResource ar) {
/* 127 */     return (ar.isAnnotationPresent(Stateless.class)) || (ar.isAnnotationPresent(Stateful.class));
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\ejb\EJBRequestDispatcherProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */