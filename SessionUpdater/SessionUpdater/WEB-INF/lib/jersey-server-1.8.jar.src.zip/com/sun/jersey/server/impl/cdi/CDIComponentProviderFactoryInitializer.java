/*    */ package com.sun.jersey.server.impl.cdi;
/*    */ 
/*    */ import com.sun.jersey.api.core.ResourceConfig;
/*    */ import com.sun.jersey.server.impl.InitialContextHelper;
/*    */ import com.sun.jersey.spi.container.WebApplication;
/*    */ import java.util.Set;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ import javax.naming.InitialContext;
/*    */ import javax.naming.NamingException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CDIComponentProviderFactoryInitializer
/*    */ {
/* 58 */   private static final Logger LOGGER = Logger.getLogger(CDIComponentProviderFactoryInitializer.class.getName());
/*    */   
/*    */   public static void initialize(ResourceConfig rc, WebApplication wa)
/*    */   {
/*    */     try {
/* 63 */       InitialContext ic = InitialContextHelper.getInitialContext();
/* 64 */       if (ic == null)
/* 65 */         return;
/* 66 */       Object beanManager = ic.lookup("java:comp/BeanManager");
/*    */       
/*    */ 
/*    */ 
/* 70 */       if (beanManager == null) {
/* 71 */         LOGGER.config("The CDI BeanManager is not available. JAX-RS CDI support is disabled.");
/* 72 */         return;
/*    */       }
/*    */       
/* 75 */       rc.getSingletons().add(new CDIComponentProviderFactory(beanManager, rc, wa));
/* 76 */       LOGGER.info("CDI support is enabled");
/*    */     }
/*    */     catch (NamingException ex) {
/* 79 */       LOGGER.log(Level.CONFIG, "The CDI BeanManager is not available. JAX-RS CDI support is disabled.", ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\cdi\CDIComponentProviderFactoryInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */