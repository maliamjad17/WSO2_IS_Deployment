package com.sun.jersey.spi.template;

import com.sun.jersey.api.view.Viewable;
import javax.ws.rs.core.UriInfo;

public abstract interface TemplateContext
{
  public abstract ResolvedViewable resolveViewable(Viewable paramViewable)
    throws TemplateContextException;
  
  public abstract ResolvedViewable resolveViewable(Viewable paramViewable, UriInfo paramUriInfo)
    throws TemplateContextException;
  
  public abstract ResolvedViewable resolveViewable(Viewable paramViewable, Class<?> paramClass)
    throws TemplateContextException;
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\template\TemplateContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */