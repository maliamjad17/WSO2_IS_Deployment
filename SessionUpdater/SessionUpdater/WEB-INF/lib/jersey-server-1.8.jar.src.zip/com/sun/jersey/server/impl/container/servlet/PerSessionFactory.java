/*     */ package com.sun.jersey.server.impl.container.servlet;
/*     */ 
/*     */ import com.sun.jersey.api.container.ContainerException;
/*     */ import com.sun.jersey.api.container.MappableContainerException;
/*     */ import com.sun.jersey.api.core.HttpContext;
/*     */ import com.sun.jersey.api.model.AbstractResource;
/*     */ import com.sun.jersey.core.spi.component.ComponentScope;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCComponentProvider;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCDestroyable;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCInstantiatedComponentProvider;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCProxiedComponentProvider;
/*     */ import com.sun.jersey.server.impl.inject.ServerInjectableProviderContext;
/*     */ import com.sun.jersey.server.spi.component.ResourceComponentConstructor;
/*     */ import com.sun.jersey.server.spi.component.ResourceComponentDestructor;
/*     */ import com.sun.jersey.server.spi.component.ResourceComponentInjector;
/*     */ import com.sun.jersey.server.spi.component.ResourceComponentProvider;
/*     */ import com.sun.jersey.server.spi.component.ResourceComponentProviderFactory;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.http.HttpSessionBindingEvent;
/*     */ import javax.servlet.http.HttpSessionBindingListener;
/*     */ import javax.ws.rs.WebApplicationException;
/*     */ import javax.ws.rs.core.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PerSessionFactory
/*     */   implements ResourceComponentProviderFactory
/*     */ {
/*     */   private final ServerInjectableProviderContext sipc;
/*     */   private final ServletContext sc;
/*     */   private final HttpServletRequest hsr;
/*     */   private final HttpContext threadLocalHc;
/*     */   private final String abstractPerSessionMapPropertyName;
/*  85 */   private final ConcurrentHashMap<Class, AbstractPerSession> abstractPerSessionMap = new ConcurrentHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PerSessionFactory(@Context ServerInjectableProviderContext sipc, @Context ServletContext sc, @Context HttpServletRequest hsr, @Context HttpContext threadLocalHc)
/*     */   {
/*  93 */     this.hsr = hsr;
/*  94 */     this.sc = sc;
/*  95 */     this.sipc = sipc;
/*  96 */     this.threadLocalHc = threadLocalHc;
/*     */     
/*  98 */     this.abstractPerSessionMapPropertyName = toString();
/*     */     
/* 100 */     sc.setAttribute(this.abstractPerSessionMapPropertyName, this.abstractPerSessionMap);
/*     */   }
/*     */   
/*     */   public ComponentScope getScope(Class c)
/*     */   {
/* 105 */     return ComponentScope.Undefined;
/*     */   }
/*     */   
/*     */   public ResourceComponentProvider getComponentProvider(Class c)
/*     */   {
/* 110 */     return new PerSesson(null);
/*     */   }
/*     */   
/*     */   public ResourceComponentProvider getComponentProvider(IoCComponentProvider icp, Class c)
/*     */   {
/* 115 */     if ((icp instanceof IoCInstantiatedComponentProvider))
/* 116 */       return new PerSessonInstantiated((IoCInstantiatedComponentProvider)icp);
/* 117 */     if ((icp instanceof IoCProxiedComponentProvider)) {
/* 118 */       return new PerSessonProxied((IoCProxiedComponentProvider)icp);
/*     */     }
/* 120 */     throw new IllegalStateException();
/*     */   }
/*     */   
/*     */   private static class SessionMap extends HashMap<String, Object> implements HttpSessionBindingListener
/*     */   {
/*     */     private final String abstractPerSessionMapPropertyName;
/*     */     
/*     */     SessionMap(String abstractPerSessionMapPropertyName)
/*     */     {
/* 129 */       this.abstractPerSessionMapPropertyName = abstractPerSessionMapPropertyName;
/*     */     }
/*     */     
/*     */ 
/*     */     public void valueBound(HttpSessionBindingEvent hsbe) {}
/*     */     
/*     */ 
/*     */     public void valueUnbound(HttpSessionBindingEvent hsbe)
/*     */     {
/* 138 */       ServletContext sc = hsbe.getSession().getServletContext();
/* 139 */       Map<Class, PerSessionFactory.AbstractPerSession> abstractPerSessionMap = (Map)sc.getAttribute(this.abstractPerSessionMapPropertyName);
/*     */       
/*     */ 
/* 142 */       for (Object o : values()) {
/* 143 */         PerSessionFactory.AbstractPerSession aps = (PerSessionFactory.AbstractPerSession)abstractPerSessionMap.get(o.getClass());
/* 144 */         if (aps != null) {
/* 145 */           aps.destroy(o);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private abstract class AbstractPerSession implements ResourceComponentProvider
/*     */   {
/*     */     private static final String SCOPE_PER_SESSION = "com.sun.jersey.scope.PerSession";
/*     */     private ResourceComponentDestructor rcd;
/*     */     private Class c;
/*     */     
/*     */     private AbstractPerSession() {}
/*     */     
/*     */     public void init(AbstractResource abstractResource) {
/* 160 */       this.rcd = new ResourceComponentDestructor(abstractResource);
/* 161 */       this.c = abstractResource.getResourceClass();
/*     */     }
/*     */     
/*     */     public final Object getInstance()
/*     */     {
/* 166 */       return getInstance(PerSessionFactory.this.threadLocalHc);
/*     */     }
/*     */     
/*     */     public final ComponentScope getScope()
/*     */     {
/* 171 */       return ComponentScope.Undefined;
/*     */     }
/*     */     
/*     */     public final Object getInstance(HttpContext hc)
/*     */     {
/* 176 */       HttpSession hs = PerSessionFactory.this.hsr.getSession();
/*     */       
/* 178 */       synchronized (hs) {
/* 179 */         PerSessionFactory.SessionMap sm = (PerSessionFactory.SessionMap)hs.getAttribute("com.sun.jersey.scope.PerSession");
/* 180 */         if (sm == null) {
/* 181 */           sm = new PerSessionFactory.SessionMap(PerSessionFactory.this.abstractPerSessionMapPropertyName);
/* 182 */           hs.setAttribute("com.sun.jersey.scope.PerSession", sm);
/*     */         }
/*     */         
/* 185 */         PerSessionFactory.this.abstractPerSessionMap.putIfAbsent(this.c, this);
/*     */         
/* 187 */         Object o = sm.get(this.c.getName());
/* 188 */         if (o != null) {
/* 189 */           return o;
/*     */         }
/*     */         
/* 192 */         o = _getInstance(hc);
/* 193 */         sm.put(this.c.getName(), o);
/* 194 */         return o;
/*     */       }
/*     */     }
/*     */     
/*     */     protected abstract Object _getInstance(HttpContext paramHttpContext);
/*     */     
/*     */     public final void destroy() {}
/*     */     
/*     */     public void destroy(Object o)
/*     */     {
/*     */       try
/*     */       {
/* 206 */         this.rcd.destroy(o);
/*     */       } catch (IllegalAccessException ex) {
/* 208 */         throw new ContainerException("Unable to destroy resource", ex);
/*     */       } catch (InvocationTargetException ex) {
/* 210 */         throw new ContainerException("Unable to destroy resource", ex);
/*     */       } catch (RuntimeException ex) {
/* 212 */         throw new ContainerException("Unable to destroy resource", ex);
/*     */       } } }
/*     */   
/*     */   private final class PerSesson extends PerSessionFactory.AbstractPerSession { private ResourceComponentConstructor rcc;
/*     */     
/* 217 */     private PerSesson() { super(null); }
/*     */     
/*     */ 
/*     */     public void init(AbstractResource abstractResource)
/*     */     {
/* 222 */       super.init(abstractResource);
/*     */       
/* 224 */       this.rcc = new ResourceComponentConstructor(PerSessionFactory.this.sipc, ComponentScope.Undefined, abstractResource);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     protected Object _getInstance(HttpContext hc)
/*     */     {
/*     */       try
/*     */       {
/* 233 */         return this.rcc.construct(hc);
/*     */       } catch (InstantiationException ex) {
/* 235 */         throw new ContainerException("Unable to create resource", ex);
/*     */       } catch (IllegalAccessException ex) {
/* 237 */         throw new ContainerException("Unable to create resource", ex);
/*     */       }
/*     */       catch (InvocationTargetException ex) {
/* 240 */         throw new MappableContainerException(ex.getTargetException());
/*     */       } catch (WebApplicationException ex) {
/* 242 */         throw ex;
/*     */       } catch (RuntimeException ex) {
/* 244 */         throw new ContainerException("Unable to create resource", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private final class PerSessonInstantiated extends PerSessionFactory.AbstractPerSession
/*     */   {
/*     */     private final IoCInstantiatedComponentProvider iicp;
/*     */     private final IoCDestroyable destroyable;
/*     */     private ResourceComponentInjector rci;
/*     */     
/*     */     PerSessonInstantiated(IoCInstantiatedComponentProvider iicp) {
/* 256 */       super(null);
/* 257 */       this.iicp = iicp;
/* 258 */       this.destroyable = ((iicp instanceof IoCDestroyable) ? (IoCDestroyable)iicp : null);
/*     */     }
/*     */     
/*     */ 
/*     */     public void init(AbstractResource abstractResource)
/*     */     {
/* 264 */       super.init(abstractResource);
/*     */       
/* 266 */       if (this.destroyable == null) {
/* 267 */         this.rci = new ResourceComponentInjector(PerSessionFactory.this.sipc, ComponentScope.Undefined, abstractResource);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected Object _getInstance(HttpContext hc)
/*     */     {
/* 276 */       Object o = this.iicp.getInstance();
/* 277 */       if (this.destroyable == null) {
/* 278 */         this.rci.inject(hc, this.iicp.getInjectableInstance(o));
/*     */       }
/* 280 */       return o;
/*     */     }
/*     */     
/*     */     public void destroy(Object o)
/*     */     {
/* 285 */       if (this.destroyable != null) {
/* 286 */         this.destroyable.destroy(o);
/*     */       } else {
/* 288 */         super.destroy(o);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private final class PerSessonProxied extends PerSessionFactory.AbstractPerSession {
/*     */     private final IoCProxiedComponentProvider ipcp;
/*     */     private ResourceComponentConstructor rcc;
/*     */     
/*     */     PerSessonProxied(IoCProxiedComponentProvider ipcp) {
/* 298 */       super(null);
/* 299 */       this.ipcp = ipcp;
/*     */     }
/*     */     
/*     */     public void init(AbstractResource abstractResource)
/*     */     {
/* 304 */       super.init(abstractResource);
/*     */       
/* 306 */       this.rcc = new ResourceComponentConstructor(PerSessionFactory.this.sipc, ComponentScope.Undefined, abstractResource);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     protected Object _getInstance(HttpContext hc)
/*     */     {
/*     */       try
/*     */       {
/* 315 */         return this.ipcp.proxy(this.rcc.construct(hc));
/*     */       } catch (InstantiationException ex) {
/* 317 */         throw new ContainerException("Unable to create resource", ex);
/*     */       } catch (IllegalAccessException ex) {
/* 319 */         throw new ContainerException("Unable to create resource", ex);
/*     */       }
/*     */       catch (InvocationTargetException ex) {
/* 322 */         throw new MappableContainerException(ex.getTargetException());
/*     */       } catch (WebApplicationException ex) {
/* 324 */         throw ex;
/*     */       } catch (RuntimeException ex) {
/* 326 */         throw new ContainerException("Unable to create resource", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\container\servlet\PerSessionFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */