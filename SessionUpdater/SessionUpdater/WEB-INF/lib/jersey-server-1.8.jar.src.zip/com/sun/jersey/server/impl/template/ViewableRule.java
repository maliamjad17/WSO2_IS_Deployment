/*     */ package com.sun.jersey.server.impl.template;
/*     */ 
/*     */ import com.sun.jersey.api.core.HttpRequestContext;
/*     */ import com.sun.jersey.api.core.HttpResponseContext;
/*     */ import com.sun.jersey.api.view.Viewable;
/*     */ import com.sun.jersey.core.header.QualitySourceMediaType;
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*     */ import com.sun.jersey.server.impl.uri.rules.HttpMethodRule;
/*     */ import com.sun.jersey.server.probes.UriRuleProbeProvider;
/*     */ import com.sun.jersey.spi.container.ContainerRequest;
/*     */ import com.sun.jersey.spi.container.ContainerRequestFilter;
/*     */ import com.sun.jersey.spi.container.ContainerResponseFilter;
/*     */ import com.sun.jersey.spi.template.ResolvedViewable;
/*     */ import com.sun.jersey.spi.template.TemplateContext;
/*     */ import com.sun.jersey.spi.uri.rules.UriRule;
/*     */ import com.sun.jersey.spi.uri.rules.UriRuleContext;
/*     */ import java.util.List;
/*     */ import java.util.regex.MatchResult;
/*     */ import javax.ws.rs.core.Context;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ViewableRule
/*     */   implements UriRule
/*     */ {
/*     */   private final List<QualitySourceMediaType> priorityMediaTypes;
/*     */   private final List<ContainerRequestFilter> requestFilters;
/*     */   private final List<ContainerResponseFilter> responseFilters;
/*     */   @Context
/*     */   TemplateContext tc;
/*     */   
/*     */   public ViewableRule(List<QualitySourceMediaType> priorityMediaTypes, List<ContainerRequestFilter> requestFilters, List<ContainerResponseFilter> responseFilters)
/*     */   {
/*  81 */     this.priorityMediaTypes = priorityMediaTypes;
/*  82 */     this.requestFilters = requestFilters;
/*  83 */     this.responseFilters = responseFilters;
/*     */   }
/*     */   
/*     */   public final boolean accept(CharSequence path, Object resource, UriRuleContext context) {
/*  87 */     UriRuleProbeProvider.ruleAccept(ViewableRule.class.getSimpleName(), path, resource);
/*     */     
/*     */ 
/*  90 */     HttpRequestContext request = context.getRequest();
/*     */     
/*  92 */     if ((request.getMethod().equals("GET")) || (request.getMethod().equals("com.sun.jersey.MATCH_RESOURCE")))
/*     */     {
/*     */ 
/*  95 */       String templatePath = path.length() > 0 ? context.getMatchResult().group(1) : "";
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 100 */       Viewable v = new Viewable(templatePath, resource);
/* 101 */       ResolvedViewable rv = this.tc.resolveViewable(v);
/* 102 */       if (rv == null) {
/* 103 */         return false;
/*     */       }
/*     */       
/*     */ 
/* 107 */       if (request.getMethod().equals("com.sun.jersey.MATCH_RESOURCE")) {
/* 108 */         return true;
/*     */       }
/*     */       
/* 111 */       if (context.isTracingEnabled()) {
/* 112 */         context.trace(String.format("accept implicit view: \"%s\" -> %s, %s", new Object[] { templatePath, ReflectionHelper.objectToString(resource), rv.getTemplateName() }));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 119 */       context.pushContainerResponseFilters(this.responseFilters);
/*     */       
/*     */       ContainerRequest containerRequest;
/* 122 */       if (!this.requestFilters.isEmpty()) {
/* 123 */         containerRequest = context.getContainerRequest();
/* 124 */         for (ContainerRequestFilter f : this.requestFilters) {
/* 125 */           containerRequest = f.filter(containerRequest);
/* 126 */           context.setContainerRequest(containerRequest);
/*     */         }
/*     */       }
/*     */       
/* 130 */       HttpResponseContext response = context.getResponse();
/*     */       
/* 132 */       response.setStatus(200);
/*     */       
/* 134 */       response.setEntity(rv);
/*     */       
/* 136 */       if (!response.getHttpHeaders().containsKey("Content-Type")) {
/* 137 */         MediaType contentType = getContentType(request, response);
/* 138 */         response.getHttpHeaders().putSingle("Content-Type", contentType);
/*     */       }
/*     */       
/* 141 */       return true;
/*     */     }
/* 143 */     return false;
/*     */   }
/*     */   
/*     */   private MediaType getContentType(HttpRequestContext request, HttpResponseContext response)
/*     */   {
/* 148 */     List<MediaType> accept = this.priorityMediaTypes == null ? request.getAcceptableMediaTypes() : HttpMethodRule.getSpecificAcceptableMediaTypes(request.getAcceptableMediaTypes(), this.priorityMediaTypes);
/*     */     
/*     */ 
/*     */ 
/* 152 */     if (!accept.isEmpty()) {
/* 153 */       MediaType contentType = (MediaType)accept.get(0);
/*     */       
/* 155 */       if ((!contentType.isWildcardType()) && (!contentType.isWildcardSubtype())) {
/* 156 */         return contentType;
/*     */       }
/*     */     }
/* 159 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\template\ViewableRule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */