/*     */ package com.sun.jersey.server.impl.inject;
/*     */ 
/*     */ import com.sun.jersey.api.core.HttpContext;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractHttpContextInjectable<T>
/*     */   implements Injectable<T>
/*     */ {
/*     */   public T getValue()
/*     */   {
/*  61 */     throw new IllegalStateException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract T getValue(HttpContext paramHttpContext);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<AbstractHttpContextInjectable> transform(List<Injectable> l)
/*     */   {
/*  80 */     List<AbstractHttpContextInjectable> al = new ArrayList(l.size());
/*     */     
/*  82 */     for (Injectable i : l) {
/*  83 */       al.add(transform(i));
/*     */     }
/*     */     
/*  86 */     return al;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AbstractHttpContextInjectable transform(Injectable i)
/*     */   {
/*  96 */     if (i == null)
/*  97 */       return null;
/*  98 */     if ((i instanceof AbstractHttpContextInjectable)) {
/*  99 */       return (AbstractHttpContextInjectable)i;
/*     */     }
/* 101 */     new AbstractHttpContextInjectable()
/*     */     {
/*     */       public Object getValue(HttpContext c) {
/* 104 */         return this.val$i.getValue();
/*     */       }
/*     */     };
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\inject\AbstractHttpContextInjectable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */