/*    */ package com.sun.jersey.server.impl.provider;
/*    */ 
/*    */ import com.sun.jersey.api.container.ContainerFactory;
/*    */ import com.sun.jersey.api.core.ApplicationAdapter;
/*    */ import com.sun.jersey.api.core.ResourceConfig;
/*    */ import com.sun.jersey.core.spi.factory.AbstractRuntimeDelegate;
/*    */ import javax.ws.rs.core.Application;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RuntimeDelegateImpl
/*    */   extends AbstractRuntimeDelegate
/*    */ {
/*    */   public <T> T createEndpoint(Application application, Class<T> endpointType)
/*    */     throws IllegalArgumentException, UnsupportedOperationException
/*    */   {
/* 60 */     if ((application instanceof ResourceConfig)) {
/* 61 */       return (T)ContainerFactory.createContainer(endpointType, (ResourceConfig)application);
/*    */     }
/*    */     
/* 64 */     return (T)ContainerFactory.createContainer(endpointType, new ApplicationAdapter(application));
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\provider\RuntimeDelegateImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */