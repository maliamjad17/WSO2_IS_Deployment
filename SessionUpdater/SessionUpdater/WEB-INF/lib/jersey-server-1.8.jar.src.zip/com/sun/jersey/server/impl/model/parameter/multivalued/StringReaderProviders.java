/*     */ package com.sun.jersey.server.impl.model.parameter.multivalued;
/*     */ 
/*     */ import com.sun.jersey.api.container.ContainerException;
/*     */ import com.sun.jersey.core.header.HttpDateFormat;
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*     */ import com.sun.jersey.spi.StringReader;
/*     */ import com.sun.jersey.spi.StringReaderProvider;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.text.ParseException;
/*     */ import java.util.Date;
/*     */ import javax.ws.rs.WebApplicationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringReaderProviders
/*     */ {
/*     */   private static abstract class AbstractStringReader
/*     */     implements StringReader
/*     */   {
/*     */     public Object fromString(String value)
/*     */     {
/*     */       try
/*     */       {
/*  66 */         return _fromString(value);
/*     */       } catch (InvocationTargetException ex) {
/*  68 */         Throwable target = ex.getTargetException();
/*  69 */         if ((target instanceof WebApplicationException)) {
/*  70 */           throw ((WebApplicationException)target);
/*     */         }
/*  72 */         throw new ExtractorContainerException(target);
/*     */       }
/*     */       catch (Exception ex) {
/*  75 */         throw new ContainerException(ex);
/*     */       }
/*     */     }
/*     */     
/*     */     protected abstract Object _fromString(String paramString) throws Exception;
/*     */   }
/*     */   
/*     */   public static class StringConstructor implements StringReaderProvider
/*     */   {
/*     */     public StringReader getStringReader(Class type, Type genericType, Annotation[] annotations) {
/*  85 */       final Constructor constructor = ReflectionHelper.getStringConstructor(type);
/*  86 */       if (constructor == null) {
/*  87 */         return null;
/*     */       }
/*  89 */       new StringReaderProviders.AbstractStringReader(constructor) {
/*     */         protected Object _fromString(String value) throws Exception {
/*  91 */           return constructor.newInstance(new Object[] { value });
/*     */         }
/*     */       };
/*     */     }
/*     */   }
/*     */   
/*     */   public static class TypeValueOf implements StringReaderProvider
/*     */   {
/*     */     public StringReader getStringReader(Class type, Type genericType, Annotation[] annotations) {
/* 100 */       final Method valueOf = ReflectionHelper.getValueOfStringMethod(type);
/* 101 */       if (valueOf == null) {
/* 102 */         return null;
/*     */       }
/* 104 */       new StringReaderProviders.AbstractStringReader(valueOf) {
/*     */         public Object _fromString(String value) throws Exception {
/* 106 */           return valueOf.invoke(null, new Object[] { value });
/*     */         }
/*     */       };
/*     */     }
/*     */   }
/*     */   
/*     */   public static class TypeFromString implements StringReaderProvider
/*     */   {
/*     */     public StringReader getStringReader(Class type, Type genericType, Annotation[] annotations) {
/* 115 */       final Method fromString = ReflectionHelper.getFromStringStringMethod(type);
/* 116 */       if (fromString == null) {
/* 117 */         return null;
/*     */       }
/* 119 */       new StringReaderProviders.AbstractStringReader(fromString) {
/*     */         public Object _fromString(String value) throws Exception {
/* 121 */           return fromString.invoke(null, new Object[] { value });
/*     */         }
/*     */       };
/*     */     }
/*     */   }
/*     */   
/*     */   public static class TypeFromStringEnum extends StringReaderProviders.TypeFromString
/*     */   {
/*     */     public StringReader getStringReader(Class type, Type genericType, Annotation[] annotations)
/*     */     {
/* 131 */       if (!Enum.class.isAssignableFrom(type)) {
/* 132 */         return null;
/*     */       }
/* 134 */       return super.getStringReader(type, genericType, annotations);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class DateProvider implements StringReaderProvider
/*     */   {
/*     */     public StringReader getStringReader(Class type, Type genericType, Annotation[] annotations) {
/* 141 */       if (type != Date.class) {
/* 142 */         return null;
/*     */       }
/* 144 */       new StringReader() {
/*     */         public Object fromString(String value) {
/*     */           try {
/* 147 */             return HttpDateFormat.readDate(value);
/*     */           } catch (ParseException ex) {
/* 149 */             throw new ExtractorContainerException(ex);
/*     */           }
/*     */         }
/*     */       };
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\parameter\multivalued\StringReaderProviders.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */