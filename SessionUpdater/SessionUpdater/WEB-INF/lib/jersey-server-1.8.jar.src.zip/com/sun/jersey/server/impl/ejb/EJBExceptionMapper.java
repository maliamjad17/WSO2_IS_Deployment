/*    */ package com.sun.jersey.server.impl.ejb;
/*    */ 
/*    */ import com.sun.jersey.api.container.MappableContainerException;
/*    */ import javax.ejb.EJBException;
/*    */ import javax.ws.rs.WebApplicationException;
/*    */ import javax.ws.rs.core.Context;
/*    */ import javax.ws.rs.core.Response;
/*    */ import javax.ws.rs.ext.ExceptionMapper;
/*    */ import javax.ws.rs.ext.Providers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EJBExceptionMapper
/*    */   implements ExceptionMapper<EJBException>
/*    */ {
/*    */   private final Providers providers;
/*    */   
/*    */   public EJBExceptionMapper(@Context Providers providers)
/*    */   {
/* 59 */     this.providers = providers;
/*    */   }
/*    */   
/*    */   public Response toResponse(EJBException exception) {
/* 63 */     Exception cause = exception.getCausedByException();
/* 64 */     if (cause != null) {
/* 65 */       ExceptionMapper mapper = this.providers.getExceptionMapper(cause.getClass());
/* 66 */       if (mapper != null)
/* 67 */         return mapper.toResponse(cause);
/* 68 */       if ((cause instanceof WebApplicationException)) {
/* 69 */         return ((WebApplicationException)cause).getResponse();
/*    */       }
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 75 */     throw new MappableContainerException(cause == null ? exception : cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\ejb\EJBExceptionMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */