/*     */ package com.sun.jersey.server.impl.model.parameter.multivalued;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class CollectionStringExtractor<V extends Collection<String>>
/*     */   implements MultivaluedParameterExtractor
/*     */ {
/*     */   final String parameter;
/*     */   final String defaultValue;
/*     */   
/*     */   protected CollectionStringExtractor(String parameter, String defaultValue)
/*     */   {
/*  62 */     this.parameter = parameter;
/*  63 */     this.defaultValue = defaultValue;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  67 */     return this.parameter;
/*     */   }
/*     */   
/*     */   public String getDefaultStringValue() {
/*  71 */     return this.defaultValue;
/*     */   }
/*     */   
/*     */   public Object extract(MultivaluedMap<String, String> parameters) {
/*  75 */     List<String> stringList = (List)parameters.get(this.parameter);
/*  76 */     if (stringList != null) {
/*  77 */       V copy = getInstance();
/*  78 */       copy.addAll(stringList);
/*  79 */       return copy; }
/*  80 */     if (this.defaultValue != null) {
/*  81 */       V l = getInstance();
/*  82 */       l.add(this.defaultValue);
/*  83 */       return l;
/*     */     }
/*     */     
/*  86 */     return getInstance();
/*     */   }
/*     */   
/*     */   protected abstract V getInstance();
/*     */   
/*     */   private static final class ListString extends CollectionStringExtractor<List<String>> {
/*     */     public ListString(String parameter, String defaultValue) {
/*  93 */       super(defaultValue);
/*     */     }
/*     */     
/*     */     protected List<String> getInstance()
/*     */     {
/*  98 */       return new ArrayList();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class SetString extends CollectionStringExtractor<Set<String>> {
/*     */     public SetString(String parameter, String defaultValue) {
/* 104 */       super(defaultValue);
/*     */     }
/*     */     
/*     */     protected Set<String> getInstance()
/*     */     {
/* 109 */       return new HashSet();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class SortedSetString extends CollectionStringExtractor<SortedSet<String>> {
/*     */     public SortedSetString(String parameter, String defaultValue) {
/* 115 */       super(defaultValue);
/*     */     }
/*     */     
/*     */     protected SortedSet<String> getInstance()
/*     */     {
/* 120 */       return new TreeSet();
/*     */     }
/*     */   }
/*     */   
/*     */   static MultivaluedParameterExtractor getInstance(Class c, String parameter, String defaultValue)
/*     */   {
/* 126 */     if (List.class == c)
/* 127 */       return new ListString(parameter, defaultValue);
/* 128 */     if (Set.class == c)
/* 129 */       return new SetString(parameter, defaultValue);
/* 130 */     if (SortedSet.class == c) {
/* 131 */       return new SortedSetString(parameter, defaultValue);
/*     */     }
/* 133 */     throw new RuntimeException();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\parameter\multivalued\CollectionStringExtractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */