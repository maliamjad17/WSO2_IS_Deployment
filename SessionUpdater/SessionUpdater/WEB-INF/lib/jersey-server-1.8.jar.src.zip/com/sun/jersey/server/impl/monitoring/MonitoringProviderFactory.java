/*     */ package com.sun.jersey.server.impl.monitoring;
/*     */ 
/*     */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*     */ import com.sun.jersey.api.model.AbstractSubResourceLocator;
/*     */ import com.sun.jersey.core.spi.component.ProviderServices;
/*     */ import com.sun.jersey.spi.container.ContainerRequest;
/*     */ import com.sun.jersey.spi.container.ContainerResponse;
/*     */ import com.sun.jersey.spi.monitoring.DispatchingListener;
/*     */ import com.sun.jersey.spi.monitoring.DispatchingListenerAdapter;
/*     */ import com.sun.jersey.spi.monitoring.RequestListener;
/*     */ import com.sun.jersey.spi.monitoring.RequestListenerAdapter;
/*     */ import com.sun.jersey.spi.monitoring.ResponseListener;
/*     */ import com.sun.jersey.spi.monitoring.ResponseListenerAdapter;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import javax.ws.rs.ext.ExceptionMapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MonitoringProviderFactory
/*     */ {
/*     */   private static class EmptyListener
/*     */     implements RequestListener, ResponseListener, DispatchingListener
/*     */   {
/*     */     public void onSubResource(long id, Class subResource) {}
/*     */     
/*     */     public void onSubResourceLocator(long id, AbstractSubResourceLocator locator) {}
/*     */     
/*     */     public void onResourceMethod(long id, AbstractResourceMethod method) {}
/*     */     
/*     */     public void onRequest(long id, ContainerRequest request) {}
/*     */     
/*     */     public void onError(long id, Throwable ex) {}
/*     */     
/*     */     public void onResponse(long id, ContainerResponse response) {}
/*     */     
/*     */     public void onMappedException(long id, Throwable exception, ExceptionMapper mapper) {}
/*     */   }
/*     */   
/*     */   private static class AggregatedRequestListener
/*     */     implements RequestListener
/*     */   {
/*     */     private final Set<RequestListener> listeners;
/*     */     
/*     */     private AggregatedRequestListener(Set<RequestListener> listeners)
/*     */     {
/* 100 */       this.listeners = Collections.unmodifiableSet(listeners);
/*     */     }
/*     */     
/*     */     public void onRequest(long id, ContainerRequest request)
/*     */     {
/* 105 */       for (RequestListener requestListener : this.listeners) {
/* 106 */         requestListener.onRequest(id, request);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static class AggregatedResponseListener implements ResponseListener
/*     */   {
/*     */     private final Set<ResponseListener> listeners;
/*     */     
/*     */     private AggregatedResponseListener(Set<ResponseListener> listeners) {
/* 116 */       this.listeners = Collections.unmodifiableSet(listeners);
/*     */     }
/*     */     
/*     */     public void onError(long id, Throwable ex)
/*     */     {
/* 121 */       for (ResponseListener responseListener : this.listeners) {
/* 122 */         responseListener.onError(id, ex);
/*     */       }
/*     */     }
/*     */     
/*     */     public void onResponse(long id, ContainerResponse response)
/*     */     {
/* 128 */       for (ResponseListener responseListener : this.listeners) {
/* 129 */         responseListener.onResponse(id, response);
/*     */       }
/*     */     }
/*     */     
/*     */     public void onMappedException(long id, Throwable exception, ExceptionMapper mapper)
/*     */     {
/* 135 */       for (ResponseListener responseListener : this.listeners) {
/* 136 */         responseListener.onMappedException(id, exception, mapper);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static class AggregatedDispatchingListener implements DispatchingListener
/*     */   {
/*     */     private final Set<DispatchingListener> listeners;
/*     */     
/*     */     private AggregatedDispatchingListener(Set<DispatchingListener> listeners)
/*     */     {
/* 147 */       this.listeners = Collections.unmodifiableSet(listeners);
/*     */     }
/*     */     
/*     */     public void onSubResource(long id, Class subResource)
/*     */     {
/* 152 */       for (DispatchingListener dispatchingListener : this.listeners) {
/* 153 */         dispatchingListener.onSubResource(id, subResource);
/*     */       }
/*     */     }
/*     */     
/*     */     public void onSubResourceLocator(long id, AbstractSubResourceLocator locator)
/*     */     {
/* 159 */       for (DispatchingListener dispatchingListener : this.listeners) {
/* 160 */         dispatchingListener.onSubResourceLocator(id, locator);
/*     */       }
/*     */     }
/*     */     
/*     */     public void onResourceMethod(long id, AbstractResourceMethod method)
/*     */     {
/* 166 */       for (DispatchingListener dispatchingListener : this.listeners) {
/* 167 */         dispatchingListener.onResourceMethod(id, method);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/* 173 */   private static final EmptyListener EMPTY_LISTENER = new EmptyListener(null);
/*     */   
/*     */   public static RequestListener createRequestListener(ProviderServices providerServices)
/*     */   {
/* 177 */     Set<RequestListener> listeners = providerServices.getProvidersAndServices(RequestListener.class);
/* 178 */     RequestListener requestListener = listeners.isEmpty() ? EMPTY_LISTENER : new AggregatedRequestListener(listeners, null);
/*     */     
/* 180 */     for (RequestListenerAdapter a : providerServices.getProvidersAndServices(RequestListenerAdapter.class)) {
/* 181 */       requestListener = a.adapt(requestListener);
/*     */     }
/*     */     
/* 184 */     return requestListener;
/*     */   }
/*     */   
/*     */   public static DispatchingListener createDispatchingListener(ProviderServices providerServices)
/*     */   {
/* 189 */     Set<DispatchingListener> listeners = providerServices.getProvidersAndServices(DispatchingListener.class);
/* 190 */     DispatchingListener dispatchingListener = listeners.isEmpty() ? EMPTY_LISTENER : new AggregatedDispatchingListener(listeners, null);
/*     */     
/* 192 */     for (DispatchingListenerAdapter a : providerServices.getProvidersAndServices(DispatchingListenerAdapter.class)) {
/* 193 */       dispatchingListener = a.adapt(dispatchingListener);
/*     */     }
/*     */     
/* 196 */     return dispatchingListener;
/*     */   }
/*     */   
/*     */   public static ResponseListener createResponseListener(ProviderServices providerServices)
/*     */   {
/* 201 */     Set<ResponseListener> listeners = providerServices.getProvidersAndServices(ResponseListener.class);
/* 202 */     ResponseListener responseListener = listeners.isEmpty() ? EMPTY_LISTENER : new AggregatedResponseListener(listeners, null);
/*     */     
/* 204 */     for (ResponseListenerAdapter a : providerServices.getProvidersAndServices(ResponseListenerAdapter.class)) {
/* 205 */       responseListener = a.adapt(responseListener);
/*     */     }
/*     */     
/* 208 */     return responseListener;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\monitoring\MonitoringProviderFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */