/*     */ package com.sun.jersey.server.impl.wadl;
/*     */ 
/*     */ import com.sun.jersey.api.core.ResourceConfig;
/*     */ import com.sun.jersey.api.model.AbstractResource;
/*     */ import com.sun.jersey.api.uri.UriTemplate;
/*     */ import com.sun.jersey.api.wadl.config.WadlGeneratorConfigLoader;
/*     */ import com.sun.jersey.core.spi.factory.InjectableProviderFactory;
/*     */ import com.sun.jersey.server.impl.model.method.ResourceMethod;
/*     */ import com.sun.jersey.server.impl.uri.PathPattern;
/*     */ import com.sun.jersey.server.wadl.WadlApplicationContext;
/*     */ import com.sun.jersey.server.wadl.WadlGenerator;
/*     */ import com.sun.jersey.spi.inject.SingletonTypeInjectableProvider;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Logger;
/*     */ import javax.ws.rs.core.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WadlFactory
/*     */ {
/*  65 */   private static final Logger LOGGER = Logger.getLogger(WadlFactory.class.getName());
/*     */   
/*     */   private final boolean isWadlEnabled;
/*     */   
/*     */   private final WadlGenerator wadlGenerator;
/*     */   private WadlApplicationContext wadlApplicationContext;
/*     */   
/*     */   public WadlFactory(ResourceConfig resourceConfig)
/*     */   {
/*  74 */     this.isWadlEnabled = isWadlEnabled(resourceConfig);
/*     */     
/*  76 */     if (this.isWadlEnabled) {
/*  77 */       this.wadlGenerator = WadlGeneratorConfigLoader.loadWadlGeneratorsFromConfig(resourceConfig);
/*     */     }
/*     */     else {
/*  80 */       this.wadlGenerator = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isSupported() {
/*  85 */     return this.isWadlEnabled;
/*     */   }
/*     */   
/*     */   public WadlApplicationContext createWadlApplicationContext(Set<AbstractResource> rootResources) {
/*  89 */     if (!isSupported()) { return null;
/*     */     }
/*  91 */     return new WadlApplicationContextImpl(rootResources, this.wadlGenerator);
/*     */   }
/*     */   
/*     */   public void init(InjectableProviderFactory ipf, Set<AbstractResource> rootResources) {
/*  95 */     if (!isSupported()) { return;
/*     */     }
/*  97 */     this.wadlApplicationContext = new WadlApplicationContextImpl(rootResources, this.wadlGenerator);
/*     */     
/*  99 */     ipf.add(new SingletonTypeInjectableProvider(WadlApplicationContext.class, this.wadlApplicationContext) {});
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceMethod createWadlOptionsMethod(Map<String, List<ResourceMethod>> methods, AbstractResource resource, PathPattern p)
/*     */   {
/* 116 */     if (!isSupported()) { return null;
/*     */     }
/* 118 */     if (p == null) {
/* 119 */       return new WadlMethodFactory.WadlOptionsMethod(methods, resource, null, this.wadlGenerator, this.wadlApplicationContext);
/*     */     }
/*     */     
/* 122 */     String path = p.getTemplate().getTemplate().substring(1);
/* 123 */     return new WadlMethodFactory.WadlOptionsMethod(methods, resource, path, this.wadlGenerator, this.wadlApplicationContext);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isWadlEnabled(ResourceConfig resourceConfig)
/*     */   {
/* 134 */     return !resourceConfig.getFeature("com.sun.jersey.config.feature.DisableWADL");
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\wadl\WadlFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */