/*    */ package com.sun.jersey.api.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceModelIssue
/*    */ {
/*    */   Object source;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   String message;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   boolean fatal;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ResourceModelIssue(Object source, String message)
/*    */   {
/* 55 */     this(source, message, false);
/*    */   }
/*    */   
/*    */   public ResourceModelIssue(Object source, String message, boolean fatal) {
/* 59 */     this.source = source;
/* 60 */     this.message = message;
/* 61 */     this.fatal = fatal;
/*    */   }
/*    */   
/*    */   public String getMessage()
/*    */   {
/* 66 */     return this.message;
/*    */   }
/*    */   
/*    */   public boolean isFatal()
/*    */   {
/* 71 */     return this.fatal;
/*    */   }
/*    */   
/*    */   public Object getSource()
/*    */   {
/* 76 */     return this.source;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\model\ResourceModelIssue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */