package com.sun.jersey.server.spi.component;

import com.sun.jersey.api.core.HttpContext;
import com.sun.jersey.api.model.AbstractResource;
import com.sun.jersey.core.spi.component.ComponentProvider;
import com.sun.jersey.core.spi.component.ComponentScope;

public abstract interface ResourceComponentProvider
  extends ComponentProvider
{
  public abstract void init(AbstractResource paramAbstractResource);
  
  public abstract ComponentScope getScope();
  
  public abstract Object getInstance(HttpContext paramHttpContext);
  
  public abstract void destroy();
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\spi\component\ResourceComponentProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */