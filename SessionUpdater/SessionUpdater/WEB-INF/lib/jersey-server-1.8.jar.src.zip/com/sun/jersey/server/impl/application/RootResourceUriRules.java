/*     */ package com.sun.jersey.server.impl.application;
/*     */ 
/*     */ import com.sun.jersey.api.container.ContainerException;
/*     */ import com.sun.jersey.api.core.ResourceConfig;
/*     */ import com.sun.jersey.api.model.AbstractResource;
/*     */ import com.sun.jersey.api.model.PathValue;
/*     */ import com.sun.jersey.api.uri.UriTemplate;
/*     */ import com.sun.jersey.core.spi.component.ComponentInjector;
/*     */ import com.sun.jersey.core.spi.factory.InjectableProviderFactory;
/*     */ import com.sun.jersey.impl.ImplMessages;
/*     */ import com.sun.jersey.server.impl.model.RulesMap;
/*     */ import com.sun.jersey.server.impl.model.RulesMap.ConflictClosure;
/*     */ import com.sun.jersey.server.impl.uri.PathPattern;
/*     */ import com.sun.jersey.server.impl.uri.PathTemplate;
/*     */ import com.sun.jersey.server.impl.uri.rules.ResourceClassRule;
/*     */ import com.sun.jersey.server.impl.uri.rules.ResourceObjectRule;
/*     */ import com.sun.jersey.server.impl.uri.rules.RightHandPathRule;
/*     */ import com.sun.jersey.server.impl.wadl.WadlFactory;
/*     */ import com.sun.jersey.server.impl.wadl.WadlResource;
/*     */ import com.sun.jersey.spi.inject.Errors;
/*     */ import com.sun.jersey.spi.uri.rules.UriRule;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RootResourceUriRules
/*     */ {
/*  69 */   private static final Logger LOGGER = Logger.getLogger(RootResourceUriRules.class.getName());
/*     */   
/*  71 */   private final RulesMap<UriRule> rules = new RulesMap();
/*     */   
/*     */ 
/*     */   private final WebApplicationImpl wa;
/*     */   
/*     */ 
/*     */   private final WadlFactory wadlFactory;
/*     */   
/*     */   private final ResourceConfig resourceConfig;
/*     */   
/*     */   private final InjectableProviderFactory injectableFactory;
/*     */   
/*     */ 
/*     */   public RootResourceUriRules(WebApplicationImpl wa, ResourceConfig resourceConfig, WadlFactory wadlFactory, InjectableProviderFactory injectableFactory)
/*     */   {
/*  86 */     this.wa = wa;
/*  87 */     this.resourceConfig = resourceConfig;
/*  88 */     this.wadlFactory = wadlFactory;
/*  89 */     this.injectableFactory = injectableFactory;
/*     */     
/*  91 */     Set<Class<?>> classes = resourceConfig.getRootResourceClasses();
/*     */     
/*  93 */     Set<Object> singletons = resourceConfig.getRootResourceSingletons();
/*     */     
/*  95 */     if ((classes.isEmpty()) && (singletons.isEmpty()) && (resourceConfig.getExplicitRootResources().isEmpty()))
/*     */     {
/*     */ 
/*  98 */       LOGGER.severe(ImplMessages.NO_ROOT_RES_IN_RES_CFG());
/*  99 */       throw new ContainerException(ImplMessages.NO_ROOT_RES_IN_RES_CFG());
/*     */     }
/*     */     
/* 102 */     Set<AbstractResource> rootResourcesSet = wa.getAbstractRootResources();
/* 103 */     Map<String, AbstractResource> explicitRootResources = wa.getExplicitAbstractRootResources();
/*     */     
/*     */ 
/* 106 */     initWadl(rootResourcesSet);
/*     */     
/*     */ 
/* 109 */     for (Object o : singletons) {
/* 110 */       AbstractResource ar = wa.getAbstractResource(o);
/*     */       
/* 112 */       wa.initiateResource(ar, o);
/*     */       
/* 114 */       ComponentInjector ci = new ComponentInjector(injectableFactory, o.getClass());
/* 115 */       ci.inject(o);
/*     */       
/* 117 */       addRule(ar.getPath().getValue(), o);
/*     */     }
/*     */     
/*     */ 
/* 121 */     for (Class<?> c : classes) {
/* 122 */       AbstractResource ar = wa.getAbstractResource(c);
/*     */       
/* 124 */       wa.initiateResource(ar);
/*     */       
/* 126 */       addRule(ar.getPath().getValue(), c);
/*     */     }
/*     */     
/*     */ 
/* 130 */     for (Map.Entry<String, Object> e : resourceConfig.getExplicitRootResources().entrySet()) {
/* 131 */       String path = (String)e.getKey();
/* 132 */       Object o = e.getValue();
/* 133 */       if ((o instanceof Class)) {
/* 134 */         Class c = (Class)o;
/*     */         
/*     */ 
/* 137 */         wa.initiateResource((AbstractResource)explicitRootResources.get(path));
/*     */         
/* 139 */         addRule(path, c);
/*     */       }
/*     */       else {
/* 142 */         wa.initiateResource((AbstractResource)explicitRootResources.get(path));
/*     */         
/* 144 */         ComponentInjector ci = new ComponentInjector(injectableFactory, o.getClass());
/* 145 */         ci.inject(o);
/*     */         
/* 147 */         addRule(path, o);
/*     */       }
/*     */     }
/*     */     
/* 151 */     this.rules.processConflicts(new RulesMap.ConflictClosure() {
/*     */       public void onConflict(PathPattern p1, PathPattern p2) {
/* 153 */         Errors.error(String.format("Conflicting URI templates. The URI templates %s and %s for root resource classes transform to the same regular expression %s", new Object[] { p1.getTemplate().getTemplate(), p2.getTemplate().getTemplate(), p1 }));
/*     */ 
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 161 */     });
/* 162 */     initWadlResource();
/*     */   }
/*     */   
/*     */   private void initWadl(Set<AbstractResource> rootResources) {
/* 166 */     if (!this.wadlFactory.isSupported()) {
/* 167 */       return;
/*     */     }
/* 169 */     this.wadlFactory.init(this.injectableFactory, rootResources);
/*     */   }
/*     */   
/*     */   private void initWadlResource() {
/* 173 */     if (!this.wadlFactory.isSupported()) {
/* 174 */       return;
/*     */     }
/* 176 */     PathPattern p = new PathPattern(new PathTemplate("application.wadl"));
/*     */     
/*     */ 
/*     */ 
/* 180 */     if (this.rules.containsKey(p)) {
/* 181 */       return;
/*     */     }
/*     */     
/* 184 */     this.wa.initiateResource(WadlResource.class);
/*     */     
/* 186 */     this.rules.put(p, new RightHandPathRule(this.resourceConfig.getFeature("com.sun.jersey.config.feature.Redirect"), p.getTemplate().endsWithSlash(), new ResourceClassRule(p.getTemplate(), WadlResource.class)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void addRule(String path, Class c)
/*     */   {
/* 193 */     PathPattern p = getPattern(path, c);
/* 194 */     if (isPatternValid(p, c)) {
/* 195 */       this.rules.put(p, new RightHandPathRule(this.resourceConfig.getFeature("com.sun.jersey.config.feature.Redirect"), p.getTemplate().endsWithSlash(), new ResourceClassRule(p.getTemplate(), c)));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void addRule(String path, Object o)
/*     */   {
/* 203 */     PathPattern p = getPattern(path, o.getClass());
/* 204 */     if (isPatternValid(p, o.getClass())) {
/* 205 */       this.rules.put(p, new RightHandPathRule(this.resourceConfig.getFeature("com.sun.jersey.config.feature.Redirect"), p.getTemplate().endsWithSlash(), new ResourceObjectRule(p.getTemplate(), o)));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private PathPattern getPattern(String path, Class c)
/*     */   {
/* 213 */     PathPattern p = null;
/*     */     try {
/* 215 */       p = new PathPattern(new PathTemplate(path));
/*     */     } catch (IllegalArgumentException ex) {
/* 217 */       Errors.error("Illegal URI template for root resource class " + c.getName() + ": " + ex.getMessage());
/*     */     }
/*     */     
/* 220 */     return p;
/*     */   }
/*     */   
/*     */   private boolean isPatternValid(PathPattern p, Class c) {
/* 224 */     if (p == null) {
/* 225 */       return false;
/*     */     }
/* 227 */     PathPattern conflict = this.rules.hasConflict(p);
/* 228 */     if (conflict != null) {
/* 229 */       Errors.error(String.format("Conflicting URI templates. The URI template %s for root resource class %s and the URI template %s transform to the same regular expression %s", new Object[] { p.getTemplate().getTemplate(), c.getName(), conflict.getTemplate().getTemplate(), p }));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 236 */       return false;
/*     */     }
/* 238 */     return true;
/*     */   }
/*     */   
/*     */   public RulesMap<UriRule> getRules()
/*     */   {
/* 243 */     return this.rules;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\application\RootResourceUriRules.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */