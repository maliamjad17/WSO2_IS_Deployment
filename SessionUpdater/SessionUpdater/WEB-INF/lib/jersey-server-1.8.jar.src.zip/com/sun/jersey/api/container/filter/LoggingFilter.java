/*     */ package com.sun.jersey.api.container.filter;
/*     */ 
/*     */ import com.sun.jersey.api.container.ContainerException;
/*     */ import com.sun.jersey.api.core.HttpContext;
/*     */ import com.sun.jersey.api.core.ResourceConfig;
/*     */ import com.sun.jersey.core.util.ReaderWriter;
/*     */ import com.sun.jersey.spi.container.ContainerRequest;
/*     */ import com.sun.jersey.spi.container.ContainerRequestFilter;
/*     */ import com.sun.jersey.spi.container.ContainerResponse;
/*     */ import com.sun.jersey.spi.container.ContainerResponseFilter;
/*     */ import com.sun.jersey.spi.container.ContainerResponseWriter;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URI;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.logging.Logger;
/*     */ import javax.ws.rs.core.Context;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoggingFilter
/*     */   implements ContainerRequestFilter, ContainerResponseFilter
/*     */ {
/*     */   public static final String FEATURE_LOGGING_DISABLE_ENTITY = "com.sun.jersey.config.feature.logging.DisableEntitylogging";
/* 105 */   private static final Logger LOGGER = Logger.getLogger(LoggingFilter.class.getName());
/*     */   
/*     */   private static final String NOTIFICATION_PREFIX = "* ";
/*     */   
/*     */   private static final String REQUEST_PREFIX = "> ";
/*     */   
/*     */   private static final String RESPONSE_PREFIX = "< ";
/*     */   
/*     */   private final Logger logger;
/*     */   
/*     */   @Context
/*     */   private HttpContext hc;
/*     */   @Context
/*     */   private ResourceConfig rc;
/* 119 */   private long id = 0L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LoggingFilter()
/*     */   {
/* 127 */     this(LOGGER);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LoggingFilter(Logger logger)
/*     */   {
/* 137 */     this.logger = logger;
/*     */   }
/*     */   
/*     */   private synchronized void setId() {
/* 141 */     if (this.hc.getProperties().get("request-id") == null) {
/* 142 */       this.hc.getProperties().put("request-id", Long.toString(++this.id));
/*     */     }
/*     */   }
/*     */   
/*     */   private StringBuilder prefixId(StringBuilder b) {
/* 147 */     b.append(this.hc.getProperties().get("request-id").toString()).append(" ");
/*     */     
/* 149 */     return b;
/*     */   }
/*     */   
/*     */   public ContainerRequest filter(ContainerRequest request) {
/* 153 */     setId();
/*     */     
/* 155 */     StringBuilder b = new StringBuilder();
/* 156 */     printRequestLine(b, request);
/* 157 */     printRequestHeaders(b, request.getRequestHeaders());
/*     */     
/* 159 */     if (this.rc.getFeature("com.sun.jersey.config.feature.logging.DisableEntitylogging")) {
/* 160 */       this.logger.info(b.toString());
/* 161 */       return request;
/*     */     }
/* 163 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 164 */     InputStream in = request.getEntityInputStream();
/*     */     try { byte[] requestEntity;
/* 166 */       if (in.available() > 0) {
/* 167 */         ReaderWriter.writeTo(in, out);
/*     */         
/* 169 */         requestEntity = out.toByteArray();
/* 170 */         printEntity(b, requestEntity);
/*     */         
/* 172 */         request.setEntityInputStream(new ByteArrayInputStream(requestEntity));
/*     */       }
/* 174 */       return request;
/*     */     } catch (IOException ex) {
/* 176 */       throw new ContainerException(ex);
/*     */     } finally {
/* 178 */       this.logger.info(b.toString());
/*     */     }
/*     */   }
/*     */   
/*     */   private void printRequestLine(StringBuilder b, ContainerRequest request)
/*     */   {
/* 184 */     prefixId(b).append("* ").append("Server in-bound request").append('\n');
/* 185 */     prefixId(b).append("> ").append(request.getMethod()).append(" ").append(request.getRequestUri().toASCIIString()).append('\n');
/*     */   }
/*     */   
/*     */   private void printRequestHeaders(StringBuilder b, MultivaluedMap<String, String> headers)
/*     */   {
/* 190 */     for (Map.Entry<String, List<String>> e : headers.entrySet()) {
/* 191 */       header = (String)e.getKey();
/* 192 */       for (String value : (List)e.getValue()) {
/* 193 */         prefixId(b).append("> ").append(header).append(": ").append(value).append('\n');
/*     */       }
/*     */     }
/*     */     String header;
/* 197 */     prefixId(b).append("> ").append('\n');
/*     */   }
/*     */   
/*     */   private void printEntity(StringBuilder b, byte[] entity) throws IOException {
/* 201 */     if (entity.length == 0)
/* 202 */       return;
/* 203 */     b.append(new String(entity)).append("\n");
/*     */   }
/*     */   
/*     */ 
/*     */   private final class Adapter
/*     */     implements ContainerResponseWriter
/*     */   {
/*     */     private final ContainerResponseWriter crw;
/*     */     
/*     */     private final boolean disableEntity;
/*     */     
/*     */     private long contentLength;
/*     */     private ContainerResponse response;
/*     */     private ByteArrayOutputStream baos;
/* 217 */     private StringBuilder b = new StringBuilder();
/*     */     
/*     */     Adapter(ContainerResponseWriter crw) {
/* 220 */       this.crw = crw;
/* 221 */       this.disableEntity = LoggingFilter.this.rc.getFeature("com.sun.jersey.config.feature.logging.DisableEntitylogging");
/*     */     }
/*     */     
/*     */     public OutputStream writeStatusAndHeaders(long contentLength, ContainerResponse response) throws IOException {
/* 225 */       LoggingFilter.this.printResponseLine(this.b, response);
/* 226 */       LoggingFilter.this.printResponseHeaders(this.b, response.getHttpHeaders());
/*     */       
/* 228 */       if (this.disableEntity) {
/* 229 */         LoggingFilter.this.logger.info(this.b.toString());
/* 230 */         return this.crw.writeStatusAndHeaders(contentLength, response);
/*     */       }
/* 232 */       this.contentLength = contentLength;
/* 233 */       this.response = response;
/* 234 */       return this.baos = new ByteArrayOutputStream();
/*     */     }
/*     */     
/*     */     public void finish() throws IOException
/*     */     {
/* 239 */       if (!this.disableEntity) {
/* 240 */         byte[] entity = this.baos.toByteArray();
/* 241 */         LoggingFilter.this.printEntity(this.b, entity);
/*     */         
/*     */ 
/* 244 */         LoggingFilter.this.logger.info(this.b.toString());
/*     */         
/*     */ 
/* 247 */         OutputStream out = this.crw.writeStatusAndHeaders(this.contentLength, this.response);
/* 248 */         out.write(entity);
/*     */       }
/* 250 */       this.crw.finish();
/*     */     }
/*     */   }
/*     */   
/*     */   public ContainerResponse filter(ContainerRequest request, ContainerResponse response) {
/* 255 */     setId();
/* 256 */     response.setContainerResponseWriter(new Adapter(response.getContainerResponseWriter()));
/*     */     
/* 258 */     return response;
/*     */   }
/*     */   
/*     */   private void printResponseLine(StringBuilder b, ContainerResponse response) {
/* 262 */     prefixId(b).append("* ").append("Server out-bound response").append('\n');
/*     */     
/* 264 */     prefixId(b).append("< ").append(Integer.toString(response.getStatus())).append('\n');
/*     */   }
/*     */   
/*     */   private void printResponseHeaders(StringBuilder b, MultivaluedMap<String, Object> headers) {
/* 268 */     for (Map.Entry<String, List<Object>> e : headers.entrySet()) {
/* 269 */       header = (String)e.getKey();
/* 270 */       for (Object value : (List)e.getValue()) {
/* 271 */         prefixId(b).append("< ").append(header).append(": ").append(ContainerResponse.getHeaderValue(value)).append('\n');
/*     */       }
/*     */     }
/*     */     String header;
/* 275 */     prefixId(b).append("< ").append('\n');
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\container\filter\LoggingFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */