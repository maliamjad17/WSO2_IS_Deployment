/*     */ package com.sun.jersey.server.spi.component;
/*     */ 
/*     */ import com.sun.jersey.api.container.ContainerException;
/*     */ import com.sun.jersey.api.core.HttpContext;
/*     */ import com.sun.jersey.api.model.AbstractField;
/*     */ import com.sun.jersey.api.model.AbstractResource;
/*     */ import com.sun.jersey.api.model.AbstractSetterMethod;
/*     */ import com.sun.jersey.api.model.Parameter;
/*     */ import com.sun.jersey.core.spi.component.ComponentScope;
/*     */ import com.sun.jersey.server.impl.inject.AbstractHttpContextInjectable;
/*     */ import com.sun.jersey.server.impl.inject.ServerInjectableProviderContext;
/*     */ import com.sun.jersey.spi.inject.Errors;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import com.sun.jersey.spi.inject.InjectableProviderContext.InjectableScopePair;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResourceComponentInjector
/*     */ {
/*     */   private Field[] singletonFields;
/*     */   private Object[] singletonFieldValues;
/*     */   private Field[] perRequestFields;
/*     */   private AbstractHttpContextInjectable<?>[] perRequestFieldInjectables;
/*     */   private Method[] singletonSetters;
/*     */   private Object[] singletonSetterValues;
/*     */   private Method[] perRequestSetters;
/*     */   private AbstractHttpContextInjectable<?>[] perRequestSetterInjectables;
/*     */   
/*     */   public ResourceComponentInjector(ServerInjectableProviderContext ipc, ComponentScope s, AbstractResource resource)
/*     */   {
/*  93 */     processFields(ipc, s, resource.getFields());
/*  94 */     processSetters(ipc, s, resource.getSetterMethods());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasInjectableArtifacts()
/*     */   {
/* 103 */     return (this.singletonFields.length > 0) || (this.perRequestFields.length > 0) || (this.singletonSetters.length > 0) || (this.perRequestSetters.length > 0);
/*     */   }
/*     */   
/*     */ 
/*     */   private void processFields(ServerInjectableProviderContext ipc, ComponentScope s, List<AbstractField> fields)
/*     */   {
/* 109 */     Map<Field, Injectable<?>> singletons = new HashMap();
/* 110 */     Map<Field, Injectable<?>> perRequest = new HashMap();
/*     */     
/* 112 */     for (AbstractField af : fields) {
/* 113 */       Parameter p = (Parameter)af.getParameters().get(0);
/*     */       
/* 115 */       InjectableProviderContext.InjectableScopePair isp = ipc.getInjectableiWithScope(af.getField(), p, s);
/* 116 */       if (isp != null) {
/* 117 */         configureField(af.getField());
/* 118 */         if ((s == ComponentScope.PerRequest) && (isp.cs != ComponentScope.Singleton)) {
/* 119 */           perRequest.put(af.getField(), isp.i);
/*     */         } else {
/* 121 */           singletons.put(af.getField(), isp.i);
/*     */         }
/* 123 */       } else if (ipc.isParameterTypeRegistered(p))
/*     */       {
/* 125 */         Errors.missingDependency(af.getField());
/*     */       }
/*     */     }
/*     */     
/* 129 */     int size = singletons.entrySet().size();
/* 130 */     this.singletonFields = new Field[size];
/* 131 */     this.singletonFieldValues = new Object[size];
/* 132 */     int i = 0;
/* 133 */     for (Map.Entry<Field, Injectable<?>> e : singletons.entrySet()) {
/* 134 */       this.singletonFields[i] = ((Field)e.getKey());
/* 135 */       this.singletonFieldValues[(i++)] = ((Injectable)e.getValue()).getValue();
/*     */     }
/*     */     
/* 138 */     size = perRequest.entrySet().size();
/* 139 */     this.perRequestFields = new Field[size];
/* 140 */     this.perRequestFieldInjectables = new AbstractHttpContextInjectable[size];
/* 141 */     i = 0;
/* 142 */     for (Map.Entry<Field, Injectable<?>> e : perRequest.entrySet()) {
/* 143 */       this.perRequestFields[i] = ((Field)e.getKey());
/* 144 */       this.perRequestFieldInjectables[(i++)] = AbstractHttpContextInjectable.transform((Injectable)e.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureField(final Field f) {
/* 149 */     if (!f.isAccessible()) {
/* 150 */       AccessController.doPrivileged(new PrivilegedAction()
/*     */       {
/*     */         public Object run() {
/* 153 */           f.setAccessible(true);
/* 154 */           return null;
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */   
/*     */   private void processSetters(ServerInjectableProviderContext ipc, ComponentScope s, List<AbstractSetterMethod> setterMethods)
/*     */   {
/* 162 */     Map<Method, Injectable<?>> singletons = new HashMap();
/* 163 */     Map<Method, Injectable<?>> perRequest = new HashMap();
/*     */     
/* 165 */     int methodIndex = 0;
/* 166 */     for (AbstractSetterMethod sm : setterMethods) {
/* 167 */       Parameter p = (Parameter)sm.getParameters().get(0);
/*     */       
/* 169 */       InjectableProviderContext.InjectableScopePair isp = ipc.getInjectableiWithScope(sm.getMethod(), p, s);
/* 170 */       if (isp != null) {
/* 171 */         if ((s == ComponentScope.PerRequest) && (isp.cs != ComponentScope.Singleton)) {
/* 172 */           perRequest.put(sm.getMethod(), isp.i);
/*     */         } else {
/* 174 */           singletons.put(sm.getMethod(), isp.i);
/*     */         }
/* 176 */       } else if (ipc.isParameterTypeRegistered(p))
/*     */       {
/* 178 */         Errors.missingDependency(sm.getMethod(), methodIndex);
/*     */       }
/* 180 */       methodIndex++;
/*     */     }
/*     */     
/* 183 */     int size = singletons.entrySet().size();
/* 184 */     this.singletonSetters = new Method[size];
/* 185 */     this.singletonSetterValues = new Object[size];
/* 186 */     int i = 0;
/* 187 */     for (Map.Entry<Method, Injectable<?>> e : singletons.entrySet()) {
/* 188 */       this.singletonSetters[i] = ((Method)e.getKey());
/* 189 */       this.singletonSetterValues[(i++)] = ((Injectable)e.getValue()).getValue();
/*     */     }
/*     */     
/* 192 */     size = perRequest.entrySet().size();
/* 193 */     this.perRequestSetters = new Method[size];
/* 194 */     this.perRequestSetterInjectables = new AbstractHttpContextInjectable[size];
/* 195 */     i = 0;
/* 196 */     for (Map.Entry<Method, Injectable<?>> e : perRequest.entrySet()) {
/* 197 */       this.perRequestSetters[i] = ((Method)e.getKey());
/* 198 */       this.perRequestSetterInjectables[(i++)] = AbstractHttpContextInjectable.transform((Injectable)e.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void inject(HttpContext c, Object o)
/*     */   {
/* 210 */     int i = 0;
/* 211 */     for (Field f : this.singletonFields) {
/*     */       try {
/* 213 */         f.set(o, this.singletonFieldValues[(i++)]);
/*     */       } catch (IllegalAccessException ex) {
/* 215 */         throw new ContainerException(ex);
/*     */       }
/*     */     }
/*     */     
/* 219 */     i = 0;
/* 220 */     for (Field f : this.perRequestFields) {
/*     */       try {
/* 222 */         f.set(o, this.perRequestFieldInjectables[(i++)].getValue(c));
/*     */       } catch (IllegalAccessException ex) {
/* 224 */         throw new ContainerException(ex);
/*     */       }
/*     */     }
/*     */     
/* 228 */     i = 0;
/* 229 */     for (Method m : this.singletonSetters) {
/*     */       try {
/* 231 */         m.invoke(o, new Object[] { this.singletonSetterValues[(i++)] });
/*     */       } catch (Exception ex) {
/* 233 */         throw new ContainerException(ex);
/*     */       }
/*     */     }
/*     */     
/* 237 */     i = 0;
/* 238 */     for (Method m : this.perRequestSetters) {
/*     */       try {
/* 240 */         m.invoke(o, new Object[] { this.perRequestSetterInjectables[(i++)].getValue(c) });
/*     */       } catch (Exception ex) {
/* 242 */         throw new ContainerException(ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\spi\component\ResourceComponentInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */