/*     */ package com.sun.jersey.server.impl.uri.rules;
/*     */ 
/*     */ import com.sun.jersey.spi.uri.rules.UriMatchResultContext;
/*     */ import com.sun.jersey.spi.uri.rules.UriRules;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CombiningMatchingPatterns<R>
/*     */   implements UriRules<R>
/*     */ {
/*     */   private final List<UriRules<R>> rs;
/*     */   
/*     */   public CombiningMatchingPatterns(List<UriRules<R>> rs)
/*     */   {
/*  58 */     this.rs = rs;
/*     */   }
/*     */   
/*     */   public Iterator<R> match(CharSequence path, UriMatchResultContext resultContext) {
/*  62 */     return new XInterator(path, resultContext);
/*     */   }
/*     */   
/*     */   private final class XInterator implements Iterator<R>
/*     */   {
/*     */     private final CharSequence path;
/*     */     private final UriMatchResultContext resultContext;
/*     */     private Iterator<R> ruleIterator;
/*     */     private Iterator<UriRules<R>> rulesIterator;
/*     */     private R r;
/*     */     
/*     */     XInterator(CharSequence path, UriMatchResultContext resultContext) {
/*  74 */       this.path = path;
/*  75 */       this.resultContext = resultContext;
/*  76 */       this.rulesIterator = CombiningMatchingPatterns.this.rs.iterator();
/*  77 */       this.ruleIterator = ((UriRules)this.rulesIterator.next()).match(path, resultContext);
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/*  81 */       if (this.r != null) { return true;
/*     */       }
/*  83 */       if (this.ruleIterator.hasNext()) {
/*  84 */         this.r = this.ruleIterator.next();
/*  85 */         return true;
/*     */       }
/*     */       
/*  88 */       while (this.rulesIterator.hasNext()) {
/*  89 */         this.ruleIterator = ((UriRules)this.rulesIterator.next()).match(this.path, this.resultContext);
/*  90 */         if (this.ruleIterator.hasNext()) {
/*  91 */           this.r = this.ruleIterator.next();
/*  92 */           return true;
/*     */         }
/*     */       }
/*     */       
/*  96 */       return false;
/*     */     }
/*     */     
/*     */     public R next() {
/* 100 */       if (!hasNext()) { throw new NoSuchElementException();
/*     */       }
/* 102 */       R _r = this.r;
/* 103 */       this.r = null;
/* 104 */       return _r;
/*     */     }
/*     */     
/*     */     public void remove() {
/* 108 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\uri\rules\CombiningMatchingPatterns.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */