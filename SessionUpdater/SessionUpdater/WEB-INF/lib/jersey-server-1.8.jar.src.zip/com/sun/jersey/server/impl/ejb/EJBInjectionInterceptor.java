/*     */ package com.sun.jersey.server.impl.ejb;
/*     */ 
/*     */ import com.sun.jersey.core.spi.component.ComponentScope;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCComponentProcessor;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCComponentProcessorFactory;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import javax.annotation.ManagedBean;
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.interceptor.InvocationContext;
/*     */ import javax.ws.rs.ext.Provider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class EJBInjectionInterceptor
/*     */ {
/*     */   private IoCComponentProcessorFactory cpf;
/*  56 */   private final ConcurrentMap<Class, IoCComponentProcessor> componentProcessorMap = new ConcurrentHashMap();
/*     */   
/*     */   public void setFactory(IoCComponentProcessorFactory cpf)
/*     */   {
/*  60 */     this.cpf = cpf;
/*     */   }
/*     */   
/*     */   @PostConstruct
/*     */   private void init(InvocationContext context) throws Exception {
/*  65 */     if (this.cpf == null)
/*     */     {
/*  67 */       return;
/*     */     }
/*     */     
/*  70 */     Object beanInstance = context.getTarget();
/*  71 */     IoCComponentProcessor icp = get(beanInstance.getClass());
/*  72 */     if (icp != null) {
/*  73 */       icp.postConstruct(beanInstance);
/*     */     }
/*     */     
/*  76 */     context.proceed();
/*     */   }
/*     */   
/*  79 */   private static final IoCComponentProcessor NULL_COMPONENT_PROCESSOR = new IoCComponentProcessor()
/*     */   {
/*     */     public void preConstruct() {}
/*     */     
/*     */     public void postConstruct(Object o) {}
/*     */   };
/*     */   
/*     */   private IoCComponentProcessor get(Class c)
/*     */   {
/*  88 */     IoCComponentProcessor cp = (IoCComponentProcessor)this.componentProcessorMap.get(c);
/*  89 */     if (cp != null) {
/*  90 */       return cp == NULL_COMPONENT_PROCESSOR ? null : cp;
/*     */     }
/*     */     
/*  93 */     synchronized (this.componentProcessorMap) {
/*  94 */       cp = (IoCComponentProcessor)this.componentProcessorMap.get(c);
/*  95 */       if (cp != null) {
/*  96 */         return cp == NULL_COMPONENT_PROCESSOR ? null : cp;
/*     */       }
/*     */       
/*  99 */       ComponentScope cs = c.isAnnotationPresent(ManagedBean.class) ? this.cpf.getScope(c) : c.isAnnotationPresent(Provider.class) ? ComponentScope.Singleton : ComponentScope.Singleton;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 104 */       cp = this.cpf.get(c, cs);
/* 105 */       if (cp != null) {
/* 106 */         this.componentProcessorMap.put(c, cp);
/*     */       } else {
/* 108 */         this.componentProcessorMap.put(c, NULL_COMPONENT_PROCESSOR);
/*     */       }
/*     */     }
/* 111 */     return cp;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\ejb\EJBInjectionInterceptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */