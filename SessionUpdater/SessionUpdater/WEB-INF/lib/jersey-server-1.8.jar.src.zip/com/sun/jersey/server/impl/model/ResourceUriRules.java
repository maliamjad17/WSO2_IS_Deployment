/*     */ package com.sun.jersey.server.impl.model;
/*     */ 
/*     */ import com.sun.jersey.api.core.ResourceConfig;
/*     */ import com.sun.jersey.api.model.AbstractImplicitViewMethod;
/*     */ import com.sun.jersey.api.model.AbstractResource;
/*     */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*     */ import com.sun.jersey.api.model.AbstractSubResourceLocator;
/*     */ import com.sun.jersey.api.model.AbstractSubResourceMethod;
/*     */ import com.sun.jersey.api.model.PathValue;
/*     */ import com.sun.jersey.api.uri.UriPattern;
/*     */ import com.sun.jersey.api.uri.UriTemplate;
/*     */ import com.sun.jersey.api.view.ImplicitProduces;
/*     */ import com.sun.jersey.core.header.MediaTypes;
/*     */ import com.sun.jersey.core.header.QualitySourceMediaType;
/*     */ import com.sun.jersey.core.spi.component.ComponentInjector;
/*     */ import com.sun.jersey.core.spi.component.ComponentScope;
/*     */ import com.sun.jersey.server.impl.container.filter.FilterFactory;
/*     */ import com.sun.jersey.server.impl.inject.ServerInjectableProviderContext;
/*     */ import com.sun.jersey.server.impl.model.method.ResourceHeadWrapperMethod;
/*     */ import com.sun.jersey.server.impl.model.method.ResourceHttpMethod;
/*     */ import com.sun.jersey.server.impl.model.method.ResourceHttpOptionsMethod;
/*     */ import com.sun.jersey.server.impl.model.method.ResourceMethod;
/*     */ import com.sun.jersey.server.impl.template.ViewResourceMethod;
/*     */ import com.sun.jersey.server.impl.template.ViewableRule;
/*     */ import com.sun.jersey.server.impl.uri.PathPattern;
/*     */ import com.sun.jersey.server.impl.uri.PathTemplate;
/*     */ import com.sun.jersey.server.impl.uri.rules.CombiningMatchingPatterns;
/*     */ import com.sun.jersey.server.impl.uri.rules.HttpMethodRule;
/*     */ import com.sun.jersey.server.impl.uri.rules.PatternRulePair;
/*     */ import com.sun.jersey.server.impl.uri.rules.RightHandPathRule;
/*     */ import com.sun.jersey.server.impl.uri.rules.SequentialMatchingPatterns;
/*     */ import com.sun.jersey.server.impl.uri.rules.SubLocatorRule;
/*     */ import com.sun.jersey.server.impl.uri.rules.TerminatingRule;
/*     */ import com.sun.jersey.server.impl.uri.rules.UriRulesFactory;
/*     */ import com.sun.jersey.server.impl.wadl.WadlFactory;
/*     */ import com.sun.jersey.spi.container.ResourceFilter;
/*     */ import com.sun.jersey.spi.container.ResourceMethodDispatchProvider;
/*     */ import com.sun.jersey.spi.inject.Errors;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import com.sun.jersey.spi.monitoring.DispatchingListener;
/*     */ import com.sun.jersey.spi.uri.rules.UriRule;
/*     */ import com.sun.jersey.spi.uri.rules.UriRules;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResourceUriRules
/*     */ {
/*     */   private final UriRules<UriRule> rules;
/*     */   private final ResourceConfig resourceConfig;
/*     */   private final ResourceMethodDispatchProvider dp;
/*     */   private final ServerInjectableProviderContext injectableContext;
/*     */   private final FilterFactory ff;
/*     */   private final WadlFactory wadlFactory;
/*     */   private final DispatchingListener dispatchingListener;
/*     */   
/*     */   public ResourceUriRules(ResourceConfig resourceConfig, ResourceMethodDispatchProvider dp, ServerInjectableProviderContext injectableContext, FilterFactory ff, WadlFactory wadlFactory, DispatchingListener dispatchingListener, final AbstractResource resource)
/*     */   {
/* 117 */     this.resourceConfig = resourceConfig;
/* 118 */     this.dp = dp;
/* 119 */     this.injectableContext = injectableContext;
/* 120 */     this.ff = ff;
/* 121 */     this.wadlFactory = wadlFactory;
/*     */     
/* 123 */     this.dispatchingListener = dispatchingListener;
/*     */     
/* 125 */     boolean implicitViewables = resourceConfig.getFeature("com.sun.jersey.config.feature.ImplicitViewables");
/*     */     
/* 127 */     List<QualitySourceMediaType> implictProduces = null;
/* 128 */     if (implicitViewables) {
/* 129 */       ImplicitProduces ip = (ImplicitProduces)resource.getAnnotation(ImplicitProduces.class);
/* 130 */       if ((ip != null) && (ip.value() != null) && (ip.value().length > 0)) {
/* 131 */         implictProduces = MediaTypes.createQualitySourceMediaTypes(ip.value());
/*     */       }
/*     */     }
/*     */     
/* 135 */     RulesMap<UriRule> rulesMap = new RulesMap();
/*     */     
/* 137 */     processSubResourceLocators(resource, rulesMap);
/*     */     
/* 139 */     processSubResourceMethods(resource, implictProduces, rulesMap);
/*     */     
/* 141 */     processMethods(resource, implictProduces, rulesMap);
/*     */     
/*     */ 
/* 144 */     rulesMap.processConflicts(new RulesMap.ConflictClosure() {
/*     */       public void onConflict(PathPattern p1, PathPattern p2) {
/* 146 */         Errors.error(String.format("Conflicting URI templates. The URI templates %s and %s for sub-resource methods and/or sub-resource locators of resource class %s transform to the same regular expression %s", new Object[] { p1.getTemplate().getTemplate(), p2.getTemplate().getTemplate(), resource.getResourceClass().getName(), p1 }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 157 */     });
/* 158 */     UriRules<UriRule> atomicRules = UriRulesFactory.create(rulesMap);
/*     */     
/*     */ 
/* 161 */     List<PatternRulePair<UriRule>> patterns = new ArrayList();
/* 162 */     if (resourceConfig.getFeature("com.sun.jersey.config.feature.ImplicitViewables")) {
/* 163 */       AbstractImplicitViewMethod method = new AbstractImplicitViewMethod(resource);
/* 164 */       List<ResourceFilter> resourceFilters = ff.getResourceFilters(method);
/* 165 */       ViewableRule r = new ViewableRule(implictProduces, FilterFactory.getRequestFilters(resourceFilters), FilterFactory.getResponseFilters(resourceFilters));
/*     */       
/*     */ 
/*     */ 
/* 169 */       ComponentInjector<ViewableRule> ci = new ComponentInjector(injectableContext, ViewableRule.class);
/*     */       
/* 171 */       ci.inject(r);
/*     */       
/*     */ 
/* 174 */       patterns.add(new PatternRulePair(new UriPattern("/([^/]+)"), r));
/*     */       
/*     */ 
/* 177 */       patterns.add(new PatternRulePair(UriPattern.EMPTY, r));
/*     */     }
/*     */     
/*     */ 
/* 181 */     patterns.add(new PatternRulePair(new UriPattern(".*"), new TerminatingRule()));
/*     */     
/*     */ 
/* 184 */     patterns.add(new PatternRulePair(UriPattern.EMPTY, new TerminatingRule()));
/*     */     
/*     */ 
/* 187 */     UriRules<UriRule> sequentialRules = new SequentialMatchingPatterns(patterns);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 192 */     UriRules<UriRule> combiningRules = new CombiningMatchingPatterns(Arrays.asList(new UriRules[] { atomicRules, sequentialRules }));
/*     */     
/*     */ 
/*     */ 
/* 196 */     this.rules = combiningRules;
/*     */   }
/*     */   
/*     */   public UriRules<UriRule> getRules() {
/* 200 */     return this.rules;
/*     */   }
/*     */   
/*     */ 
/*     */   private void processSubResourceLocators(AbstractResource resource, RulesMap<UriRule> rulesMap)
/*     */   {
/* 206 */     for (AbstractSubResourceLocator locator : resource.getSubResourceLocators()) {
/* 207 */       PathPattern p = null;
/*     */       try {
/* 209 */         p = new PathPattern(new PathTemplate(locator.getPath().getValue()));
/*     */       } catch (IllegalArgumentException ex) {
/* 211 */         Errors.error(String.format("Illegal URI template for sub-resource locator %s: %s", new Object[] { locator.getMethod(), ex.getMessage() }));
/*     */       }
/* 213 */       continue;
/*     */       
/*     */ 
/* 216 */       PathPattern conflict = rulesMap.hasConflict(p);
/* 217 */       if (conflict != null) {
/* 218 */         Errors.error(String.format("Conflicting URI templates. The URI template %s for sub-resource locator %s and the URI template %s transform to the same regular expression %s", new Object[] { p.getTemplate().getTemplate(), locator.getMethod(), conflict.getTemplate().getTemplate(), p }));
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 228 */         List<Injectable> is = this.injectableContext.getInjectable(locator.getMethod(), locator.getParameters(), ComponentScope.PerRequest);
/*     */         
/* 230 */         if (is.contains(null))
/*     */         {
/* 232 */           for (int i = 0; i < is.size(); i++) {
/* 233 */             if (is.get(i) == null) {
/* 234 */               Errors.missingDependency(locator.getMethod(), i);
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 239 */         List<ResourceFilter> resourceFilters = this.ff.getResourceFilters(locator);
/* 240 */         UriRule r = new SubLocatorRule(p.getTemplate(), is, FilterFactory.getRequestFilters(resourceFilters), FilterFactory.getResponseFilters(resourceFilters), this.dispatchingListener, locator);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 248 */         rulesMap.put(p, new RightHandPathRule(this.resourceConfig.getFeature("com.sun.jersey.config.feature.Redirect"), p.getTemplate().endsWithSlash(), r));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void processSubResourceMethods(AbstractResource resource, List<QualitySourceMediaType> implictProduces, RulesMap<UriRule> rulesMap)
/*     */   {
/* 260 */     Map<PathPattern, ResourceMethodMap> patternMethodMap = new HashMap();
/*     */     
/*     */ 
/* 263 */     for (AbstractSubResourceMethod method : resource.getSubResourceMethods())
/*     */     {
/*     */       PathPattern p;
/*     */       try {
/* 267 */         p = new PathPattern(new PathTemplate(method.getPath().getValue()), "(/)?");
/*     */       } catch (IllegalArgumentException ex) {
/* 269 */         Errors.error(String.format("Illegal URI template for sub-resource method %s: %s", new Object[] { method.getMethod(), ex.getMessage() }));
/*     */       }
/* 271 */       continue;
/*     */       
/*     */ 
/* 274 */       ResourceMethod rm = new ResourceHttpMethod(this.dp, this.ff, p.getTemplate(), method);
/* 275 */       ResourceMethodMap rmm = (ResourceMethodMap)patternMethodMap.get(p);
/* 276 */       if (rmm == null) {
/* 277 */         rmm = new ResourceMethodMap();
/* 278 */         patternMethodMap.put(p, rmm);
/*     */       }
/*     */       
/* 281 */       if (isValidResourceMethod(rm, rmm)) {
/* 282 */         rmm.put(rm);
/*     */       }
/*     */       
/* 285 */       rmm.put(rm);
/*     */     }
/*     */     
/*     */ 
/* 289 */     for (Map.Entry<PathPattern, ResourceMethodMap> e : patternMethodMap.entrySet()) {
/* 290 */       addImplicitMethod(implictProduces, (ResourceMethodMap)e.getValue());
/*     */       
/* 292 */       PathPattern p = (PathPattern)e.getKey();
/* 293 */       ResourceMethodMap rmm = (ResourceMethodMap)e.getValue();
/*     */       
/* 295 */       processHead(rmm);
/* 296 */       processOptions(rmm, resource, p);
/*     */       
/* 298 */       rmm.sort();
/*     */       
/* 300 */       rulesMap.put(p, new RightHandPathRule(this.resourceConfig.getFeature("com.sun.jersey.config.feature.Redirect"), p.getTemplate().endsWithSlash(), new HttpMethodRule(rmm, true, this.dispatchingListener)));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void processMethods(AbstractResource resource, List<QualitySourceMediaType> implictProduces, RulesMap<UriRule> rulesMap)
/*     */   {
/* 312 */     ResourceMethodMap rmm = new ResourceMethodMap();
/* 313 */     for (AbstractResourceMethod resourceMethod : resource.getResourceMethods()) {
/* 314 */       ResourceMethod rm = new ResourceHttpMethod(this.dp, this.ff, resourceMethod);
/*     */       
/* 316 */       if (isValidResourceMethod(rm, rmm)) {
/* 317 */         rmm.put(rm);
/*     */       }
/*     */     }
/*     */     
/* 321 */     addImplicitMethod(implictProduces, rmm);
/*     */     
/* 323 */     processHead(rmm);
/* 324 */     processOptions(rmm, resource, null);
/*     */     
/*     */ 
/* 327 */     rmm.sort();
/* 328 */     if (!rmm.isEmpty())
/*     */     {
/*     */ 
/* 331 */       rulesMap.put(PathPattern.EMPTY_PATH, new HttpMethodRule(rmm, this.dispatchingListener));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void addImplicitMethod(List<QualitySourceMediaType> implictProduces, ResourceMethodMap rmm)
/*     */   {
/* 338 */     if (implictProduces != null) {
/* 339 */       List<ResourceMethod> getList = (List)rmm.get("GET");
/* 340 */       if ((getList != null) && (!getList.isEmpty())) {
/* 341 */         rmm.put(new ViewResourceMethod(implictProduces));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean isValidResourceMethod(ResourceMethod rm, ResourceMethodMap rmm)
/*     */   {
/* 349 */     List<ResourceMethod> rml = (List)rmm.get(rm.getHttpMethod());
/* 350 */     if (rml != null) {
/* 351 */       boolean conflict = false;
/* 352 */       ResourceMethod erm = null;
/* 353 */       for (int i = 0; (i < rml.size()) && (!conflict); i++) {
/* 354 */         erm = (ResourceMethod)rml.get(i);
/*     */         
/* 356 */         conflict = (MediaTypes.intersects(rm.getConsumes(), erm.getConsumes())) && (MediaTypes.intersects(rm.getProduces(), erm.getProduces()));
/*     */       }
/*     */       
/*     */ 
/* 360 */       if (conflict) {
/* 361 */         if (rm.getAbstractResourceMethod().hasEntity()) {
/* 362 */           Errors.error(String.format("Consuming media type conflict. The resource methods %s and %s can consume the same media type", new Object[] { rm.getAbstractResourceMethod().getMethod(), erm.getAbstractResourceMethod().getMethod() }));
/*     */         }
/*     */         else
/*     */         {
/* 366 */           Errors.error(String.format("Producing media type conflict. The resource methods %s and %s can produce the same media type", new Object[] { rm.getAbstractResourceMethod().getMethod(), erm.getAbstractResourceMethod().getMethod() }));
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 372 */       if (conflict) {
/* 373 */         return false;
/*     */       }
/*     */     }
/* 376 */     return true;
/*     */   }
/*     */   
/*     */   private void processHead(ResourceMethodMap methodMap) {
/* 380 */     List<ResourceMethod> getList = (List)methodMap.get("GET");
/* 381 */     if ((getList == null) || (getList.isEmpty())) {
/* 382 */       return;
/*     */     }
/*     */     
/* 385 */     List<ResourceMethod> headList = (List)methodMap.get("HEAD");
/* 386 */     if (headList == null) {
/* 387 */       headList = new ArrayList();
/*     */     }
/*     */     
/* 390 */     for (ResourceMethod getMethod : getList) {
/* 391 */       if (!containsMediaOfMethod(headList, getMethod)) {
/* 392 */         ResourceMethod headMethod = new ResourceHeadWrapperMethod(getMethod);
/* 393 */         methodMap.put(headMethod);
/* 394 */         headList = (List)methodMap.get("HEAD");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean containsMediaOfMethod(List<ResourceMethod> methods, ResourceMethod method)
/*     */   {
/* 410 */     for (ResourceMethod m : methods) {
/* 411 */       if (method.mediaEquals(m)) {
/* 412 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 416 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void processOptions(ResourceMethodMap methodMap, AbstractResource resource, PathPattern p)
/*     */   {
/* 423 */     List<ResourceMethod> l = (List)methodMap.get("OPTIONS");
/* 424 */     if (l != null) {
/* 425 */       return;
/*     */     }
/*     */     
/* 428 */     ResourceMethod optionsMethod = this.wadlFactory.createWadlOptionsMethod(methodMap, resource, p);
/* 429 */     if (optionsMethod == null) {
/* 430 */       optionsMethod = new ResourceHttpOptionsMethod(methodMap);
/*     */     }
/* 432 */     methodMap.put(optionsMethod);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\ResourceUriRules.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */