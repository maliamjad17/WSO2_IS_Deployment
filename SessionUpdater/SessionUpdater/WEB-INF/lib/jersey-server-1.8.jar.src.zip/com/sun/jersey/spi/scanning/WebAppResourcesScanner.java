/*     */ package com.sun.jersey.spi.scanning;
/*     */ 
/*     */ import com.sun.jersey.core.spi.scanning.JarFileScanner;
/*     */ import com.sun.jersey.core.spi.scanning.Scanner;
/*     */ import com.sun.jersey.core.spi.scanning.ScannerException;
/*     */ import com.sun.jersey.core.spi.scanning.ScannerListener;
/*     */ import com.sun.jersey.core.util.Closing;
/*     */ import com.sun.jersey.core.util.Closing.Closure;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebAppResourcesScanner
/*     */   implements Scanner
/*     */ {
/*     */   private final String[] paths;
/*     */   private final ServletContext sc;
/*     */   
/*     */   public WebAppResourcesScanner(String[] paths, ServletContext sc)
/*     */   {
/*  71 */     this.paths = paths;
/*  72 */     this.sc = sc;
/*     */   }
/*     */   
/*     */ 
/*     */   public void scan(ScannerListener cfl)
/*     */   {
/*  78 */     for (String path : this.paths) {
/*  79 */       scan(path, cfl);
/*     */     }
/*     */   }
/*     */   
/*     */   private void scan(String root, final ScannerListener cfl) {
/*  84 */     Set<String> resourcePaths = this.sc.getResourcePaths(root);
/*  85 */     if (resourcePaths == null)
/*  86 */       return;
/*  87 */     for (final String resourcePath : resourcePaths) {
/*  88 */       if (resourcePath.endsWith("/")) {
/*  89 */         scan(resourcePath, cfl);
/*  90 */       } else if (resourcePath.endsWith(".jar")) {
/*     */         try {
/*  92 */           new Closing(this.sc.getResourceAsStream(resourcePath)).f(new Closing.Closure() {
/*     */             public void f(InputStream in) throws IOException {
/*  94 */               JarFileScanner.scan(in, "", cfl);
/*     */             }
/*     */           });
/*     */         } catch (IOException ex) {
/*  98 */           throw new ScannerException("IO error scanning jar " + resourcePath, ex);
/*     */         }
/* 100 */       } else if (cfl.onAccept(resourcePath)) {
/*     */         try {
/* 102 */           new Closing(this.sc.getResourceAsStream(resourcePath)).f(new Closing.Closure() {
/*     */             public void f(InputStream in) throws IOException {
/* 104 */               cfl.onProcess(resourcePath, in);
/*     */             }
/*     */           });
/*     */         } catch (IOException ex) {
/* 108 */           throw new ScannerException("IO error scanning resource " + resourcePath, ex);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\scanning\WebAppResourcesScanner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */