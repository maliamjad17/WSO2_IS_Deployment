/*    */ package com.sun.jersey.server.impl.container.httpserver;
/*    */ 
/*    */ import com.sun.jersey.api.container.ContainerException;
/*    */ import com.sun.jersey.api.core.ResourceConfig;
/*    */ import com.sun.jersey.spi.container.ContainerProvider;
/*    */ import com.sun.jersey.spi.container.WebApplication;
/*    */ import com.sun.net.httpserver.HttpHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HttpHandlerContainerProvider
/*    */   implements ContainerProvider<HttpHandler>
/*    */ {
/*    */   public HttpHandler createContainer(Class<HttpHandler> type, ResourceConfig resourceConfig, WebApplication application)
/*    */     throws ContainerException
/*    */   {
/* 60 */     if (type != HttpHandler.class) {
/* 61 */       return null;
/*    */     }
/* 63 */     return new HttpHandlerContainer(application);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\container\httpserver\HttpHandlerContainerProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */