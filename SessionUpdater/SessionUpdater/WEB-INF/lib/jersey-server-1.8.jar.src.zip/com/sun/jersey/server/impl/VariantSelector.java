/*     */ package com.sun.jersey.server.impl;
/*     */ 
/*     */ import com.sun.jersey.core.header.AcceptableLanguageTag;
/*     */ import com.sun.jersey.core.header.AcceptableMediaType;
/*     */ import com.sun.jersey.core.header.AcceptableToken;
/*     */ import com.sun.jersey.core.header.QualityFactor;
/*     */ import com.sun.jersey.core.header.QualitySourceMediaType;
/*     */ import com.sun.jersey.server.impl.model.HttpHelper;
/*     */ import com.sun.jersey.spi.container.ContainerRequest;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.Variant;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class VariantSelector
/*     */ {
/* 105 */   private static final DimensionChecker<AcceptableMediaType, MediaType> MEDIA_TYPE_DC = new DimensionChecker()
/*     */   {
/*     */     public MediaType getDimension(VariantSelector.VariantHolder v) {
/* 108 */       return v.v.getMediaType();
/*     */     }
/*     */     
/*     */     public boolean isCompatible(AcceptableMediaType t, MediaType u) {
/* 112 */       return t.isCompatible(u);
/*     */     }
/*     */     
/*     */     public int getQualitySource(VariantSelector.VariantHolder v, MediaType u) {
/* 116 */       return v.mediaTypeQs;
/*     */     }
/*     */     
/*     */     public String getVaryHeaderValue() {
/* 120 */       return "Accept";
/*     */     }
/*     */   };
/*     */   
/* 124 */   private static final DimensionChecker<AcceptableLanguageTag, Locale> LANGUAGE_TAG_DC = new DimensionChecker()
/*     */   {
/*     */     public Locale getDimension(VariantSelector.VariantHolder v) {
/* 127 */       return v.v.getLanguage();
/*     */     }
/*     */     
/*     */     public boolean isCompatible(AcceptableLanguageTag t, Locale u) {
/* 131 */       return t.isCompatible(u);
/*     */     }
/*     */     
/*     */     public int getQualitySource(VariantSelector.VariantHolder qsv, Locale u) {
/* 135 */       return 0;
/*     */     }
/*     */     
/*     */     public String getVaryHeaderValue() {
/* 139 */       return "Accept-Language";
/*     */     }
/*     */   };
/*     */   
/* 143 */   private static final DimensionChecker<AcceptableToken, String> CHARSET_DC = new DimensionChecker()
/*     */   {
/*     */     public String getDimension(VariantSelector.VariantHolder v) {
/* 146 */       MediaType m = v.v.getMediaType();
/* 147 */       return m != null ? (String)m.getParameters().get("charset") : null;
/*     */     }
/*     */     
/*     */     public boolean isCompatible(AcceptableToken t, String u) {
/* 151 */       return t.isCompatible(u);
/*     */     }
/*     */     
/*     */     public int getQualitySource(VariantSelector.VariantHolder qsv, String u) {
/* 155 */       return 0;
/*     */     }
/*     */     
/*     */     public String getVaryHeaderValue() {
/* 159 */       return "Accept-Charset";
/*     */     }
/*     */   };
/*     */   
/* 163 */   private static final DimensionChecker<AcceptableToken, String> ENCODING_DC = new DimensionChecker()
/*     */   {
/*     */     public String getDimension(VariantSelector.VariantHolder v) {
/* 166 */       return v.v.getEncoding();
/*     */     }
/*     */     
/*     */     public boolean isCompatible(AcceptableToken t, String u) {
/* 170 */       return t.isCompatible(u);
/*     */     }
/*     */     
/*     */     public int getQualitySource(VariantSelector.VariantHolder qsv, String u) {
/* 174 */       return 0;
/*     */     }
/*     */     
/*     */     public String getVaryHeaderValue() {
/* 178 */       return "Accept-Encoding";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static <T extends QualityFactor, U> LinkedList<VariantHolder> selectVariants(LinkedList<VariantHolder> vs, List<T> as, DimensionChecker<T, U> dc, Set<String> vary)
/*     */   {
/* 197 */     int cq = 0;
/* 198 */     int cqs = 0;
/*     */     
/* 200 */     LinkedList<VariantHolder> selected = new LinkedList();
/*     */     
/*     */ 
/*     */ 
/* 204 */     for (T a : as) {
/* 205 */       int q = a.getQuality();
/*     */       
/* 207 */       Iterator<VariantHolder> iv = vs.iterator();
/* 208 */       while (iv.hasNext()) {
/* 209 */         VariantHolder v = (VariantHolder)iv.next();
/*     */         
/*     */ 
/* 212 */         U d = dc.getDimension(v);
/*     */         
/* 214 */         if (d != null) {
/* 215 */           vary.add(dc.getVaryHeaderValue());
/*     */           
/*     */ 
/* 218 */           int qs = dc.getQualitySource(v, d);
/* 219 */           if ((qs >= cqs) && (dc.isCompatible(a, d))) {
/* 220 */             if (qs > cqs) {
/* 221 */               cqs = qs;
/* 222 */               cq = q;
/*     */               
/* 224 */               selected.clear();
/* 225 */               selected.add(v);
/* 226 */             } else if (q > cq) {
/* 227 */               cq = q;
/*     */               
/* 229 */               selected.addFirst(v);
/* 230 */             } else if (q == cq)
/*     */             {
/*     */ 
/* 233 */               selected.add(v);
/*     */             }
/* 235 */             iv.remove();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 243 */     for (VariantHolder v : vs) {
/* 244 */       if (dc.getDimension(v) == null)
/* 245 */         selected.add(v);
/*     */     }
/* 247 */     return selected;
/*     */   }
/*     */   
/*     */   private static class VariantHolder
/*     */   {
/*     */     private final Variant v;
/*     */     private final int mediaTypeQs;
/*     */     
/*     */     public VariantHolder(Variant v) {
/* 256 */       this(v, 1000);
/*     */     }
/*     */     
/*     */     public VariantHolder(Variant v, int mediaTypeQs) {
/* 260 */       this.v = v;
/* 261 */       this.mediaTypeQs = mediaTypeQs;
/*     */     }
/*     */   }
/*     */   
/*     */   private static LinkedList<VariantHolder> getVariantHolderList(List<Variant> variants) {
/* 266 */     LinkedList<VariantHolder> l = new LinkedList();
/* 267 */     for (Variant v : variants) {
/* 268 */       MediaType mt = v.getMediaType();
/* 269 */       if (mt != null) {
/* 270 */         if (((mt instanceof QualitySourceMediaType)) || (mt.getParameters().containsKey("qs")))
/*     */         {
/* 272 */           int qs = QualitySourceMediaType.getQualitySource(mt);
/* 273 */           l.add(new VariantHolder(v, qs));
/*     */         } else {
/* 275 */           l.add(new VariantHolder(v));
/*     */         }
/*     */       } else {
/* 278 */         l.add(new VariantHolder(v));
/*     */       }
/*     */     }
/*     */     
/* 282 */     return l;
/*     */   }
/*     */   
/*     */   public static Variant selectVariant(ContainerRequest r, List<Variant> variants) {
/* 286 */     LinkedList<VariantHolder> vhs = getVariantHolderList(variants);
/*     */     
/* 288 */     Set<String> vary = new HashSet();
/* 289 */     vhs = selectVariants(vhs, HttpHelper.getAccept(r), MEDIA_TYPE_DC, vary);
/* 290 */     vhs = selectVariants(vhs, HttpHelper.getAcceptLanguage(r), LANGUAGE_TAG_DC, vary);
/* 291 */     vhs = selectVariants(vhs, HttpHelper.getAcceptCharset(r), CHARSET_DC, vary);
/* 292 */     vhs = selectVariants(vhs, HttpHelper.getAcceptEncoding(r), ENCODING_DC, vary);
/*     */     
/*     */ 
/* 295 */     if (vhs.isEmpty()) {
/* 296 */       return null;
/*     */     }
/* 298 */     StringBuilder varyHeader = new StringBuilder();
/* 299 */     for (String v : vary) {
/* 300 */       if (varyHeader.length() > 0) {
/* 301 */         varyHeader.append(',');
/*     */       }
/* 303 */       varyHeader.append(v);
/*     */     }
/* 305 */     r.getProperties().put("Vary", varyHeader.toString());
/* 306 */     return ((VariantHolder)vhs.iterator().next()).v;
/*     */   }
/*     */   
/*     */   private static abstract interface DimensionChecker<T, U>
/*     */   {
/*     */     public abstract U getDimension(VariantSelector.VariantHolder paramVariantHolder);
/*     */     
/*     */     public abstract int getQualitySource(VariantSelector.VariantHolder paramVariantHolder, U paramU);
/*     */     
/*     */     public abstract boolean isCompatible(T paramT, U paramU);
/*     */     
/*     */     public abstract String getVaryHeaderValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\VariantSelector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */