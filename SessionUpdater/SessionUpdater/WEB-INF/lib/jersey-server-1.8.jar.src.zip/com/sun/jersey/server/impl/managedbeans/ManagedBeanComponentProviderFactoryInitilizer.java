/*    */ package com.sun.jersey.server.impl.managedbeans;
/*    */ 
/*    */ import com.sun.jersey.api.core.ResourceConfig;
/*    */ import com.sun.jersey.server.impl.InitialContextHelper;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Set;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ import javax.naming.InitialContext;
/*    */ import javax.naming.NamingException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ManagedBeanComponentProviderFactoryInitilizer
/*    */ {
/* 56 */   private static final Logger LOGGER = Logger.getLogger(ManagedBeanComponentProviderFactoryInitilizer.class.getName());
/*    */   
/*    */   public static void initialize(ResourceConfig rc)
/*    */   {
/*    */     try {
/* 61 */       InitialContext ic = InitialContextHelper.getInitialContext();
/* 62 */       if (ic == null) {
/* 63 */         return;
/*    */       }
/* 65 */       Object injectionMgr = ic.lookup("com.sun.enterprise.container.common.spi.util.InjectionManager");
/*    */       
/*    */ 
/*    */ 
/*    */ 
/* 70 */       if (injectionMgr == null) {
/* 71 */         LOGGER.config("The managed beans injection manager API is not available. JAX-RS managed beans support is disabled.");
/* 72 */         return;
/*    */       }
/*    */       
/* 75 */       Method createManagedObjectMethod = injectionMgr.getClass().getMethod("createManagedObject", new Class[] { Class.class });
/*    */       
/*    */ 
/* 78 */       Method destroyManagedObjectMethod = injectionMgr.getClass().getMethod("destroyManagedObject", new Class[] { Object.class });
/*    */       
/*    */ 
/* 81 */       rc.getSingletons().add(new ManagedBeanComponentProviderFactory(injectionMgr, createManagedObjectMethod, destroyManagedObjectMethod));
/*    */     }
/*    */     catch (NamingException ex) {
/* 84 */       LOGGER.log(Level.CONFIG, "The managed beans injection manager API is not available. JAX-RS managed beans support is disabled.", ex);
/*    */     } catch (NoSuchMethodException ex) {
/* 86 */       LOGGER.log(Level.SEVERE, "The managed beans injection manager API does not conform to what is expected. JAX-RS managed beans support is disabled.", ex);
/*    */     } catch (SecurityException ex) {
/* 88 */       LOGGER.log(Level.SEVERE, "Security issue when configuring to use the managed beans injection manager API. JAX-RS managed beans support is disabled.", ex);
/*    */     } catch (LinkageError ex) {
/* 90 */       LOGGER.log(Level.SEVERE, "Linkage error when configuring to use the managed beans injection manager API. JAX-RS managed beans support is disabled.", ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\managedbeans\ManagedBeanComponentProviderFactoryInitilizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */