/*    */ package com.sun.jersey.server.impl.model;
/*    */ 
/*    */ import com.sun.jersey.api.container.ContainerException;
/*    */ import com.sun.jersey.impl.ImplMessages;
/*    */ import java.lang.reflect.Method;
/*    */ import javax.ws.rs.Consumes;
/*    */ import javax.ws.rs.HttpMethod;
/*    */ import javax.ws.rs.Produces;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ErrorHelper
/*    */ {
/*    */   public static ContainerException objectNotAWebResource(Class resourceClass)
/*    */   {
/* 58 */     return new ContainerException(ImplMessages.OBJECT_NOT_A_WEB_RESOURCE(resourceClass.getName()));
/*    */   }
/*    */   
/*    */   public static ContainerException badClassConsumes(Exception e, Class resourceClass, Consumes c) {
/* 62 */     return new ContainerException(ImplMessages.BAD_CLASS_CONSUMEMIME(resourceClass, c.value()), e);
/*    */   }
/*    */   
/*    */   public static ContainerException badClassProduces(Exception e, Class resourceClass, Produces p)
/*    */   {
/* 67 */     return new ContainerException(ImplMessages.BAD_CLASS_PRODUCEMIME(resourceClass, p.value()), e);
/*    */   }
/*    */   
/*    */   public static ContainerException badMethodHttpMethod(Class resourceClass, Method m, HttpMethod hm)
/*    */   {
/* 72 */     return new ContainerException(ImplMessages.BAD_METHOD_HTTPMETHOD(resourceClass, hm.value(), m.toString()));
/*    */   }
/*    */   
/*    */ 
/*    */   public static ContainerException badMethodConsumes(Exception e, Class resourceClass, Method m, Consumes c)
/*    */   {
/* 78 */     return new ContainerException(ImplMessages.BAD_METHOD_CONSUMEMIME(resourceClass, c.value(), m.toString()), e);
/*    */   }
/*    */   
/*    */ 
/*    */   public static ContainerException badMethodProduces(Exception e, Class resourceClass, Method m, Produces p)
/*    */   {
/* 84 */     return new ContainerException(ImplMessages.BAD_METHOD_PRODUCEMIME(resourceClass, p.value(), m.toString()), e);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\ErrorHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */