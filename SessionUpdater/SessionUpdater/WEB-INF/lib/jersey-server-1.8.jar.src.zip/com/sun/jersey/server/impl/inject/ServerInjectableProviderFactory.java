/*     */ package com.sun.jersey.server.impl.inject;
/*     */ 
/*     */ import com.sun.jersey.api.model.Parameter;
/*     */ import com.sun.jersey.core.spi.component.AnnotatedContext;
/*     */ import com.sun.jersey.core.spi.component.ComponentContext;
/*     */ import com.sun.jersey.core.spi.component.ComponentScope;
/*     */ import com.sun.jersey.core.spi.factory.InjectableProviderFactory;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import com.sun.jersey.spi.inject.InjectableProviderContext.InjectableScopePair;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AccessibleObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ServerInjectableProviderFactory
/*     */   extends InjectableProviderFactory
/*     */   implements ServerInjectableProviderContext
/*     */ {
/*     */   public boolean isParameterTypeRegistered(Parameter p)
/*     */   {
/*  61 */     if (p.getAnnotation() == null) { return false;
/*     */     }
/*  63 */     if (isAnnotationRegistered(p.getAnnotation().annotationType(), p.getClass())) { return true;
/*     */     }
/*  65 */     return isAnnotationRegistered(p.getAnnotation().annotationType(), p.getParameterType().getClass());
/*     */   }
/*     */   
/*     */   public InjectableProviderContext.InjectableScopePair getInjectableiWithScope(Parameter p, ComponentScope s)
/*     */   {
/*  70 */     return getInjectableiWithScope(null, p, s);
/*     */   }
/*     */   
/*     */   public InjectableProviderContext.InjectableScopePair getInjectableiWithScope(AccessibleObject ao, Parameter p, ComponentScope s)
/*     */   {
/*  75 */     if (p.getAnnotation() == null) { return null;
/*     */     }
/*  77 */     ComponentContext ic = new AnnotatedContext(ao, p.getAnnotations());
/*     */     
/*  79 */     if (s == ComponentScope.PerRequest)
/*     */     {
/*  81 */       Injectable i = getInjectable(p.getAnnotation().annotationType(), ic, p.getAnnotation(), p, ComponentScope.PerRequest);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  87 */       if (i != null) { return new InjectableProviderContext.InjectableScopePair(i, ComponentScope.PerRequest);
/*     */       }
/*     */       
/*  90 */       return getInjectableWithScope(p.getAnnotation().annotationType(), ic, p.getAnnotation(), p.getParameterType(), ComponentScope.PERREQUEST_UNDEFINED_SINGLETON);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */     return getInjectableWithScope(p.getAnnotation().annotationType(), ic, p.getAnnotation(), p.getParameterType(), ComponentScope.UNDEFINED_SINGLETON);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Injectable getInjectable(Parameter p, ComponentScope s)
/*     */   {
/* 111 */     return getInjectable(null, p, s);
/*     */   }
/*     */   
/*     */   public Injectable getInjectable(AccessibleObject ao, Parameter p, ComponentScope s)
/*     */   {
/* 116 */     InjectableProviderContext.InjectableScopePair isp = getInjectableiWithScope(ao, p, s);
/* 117 */     if (isp == null)
/* 118 */       return null;
/* 119 */     return isp.i;
/*     */   }
/*     */   
/*     */   public List<Injectable> getInjectable(List<Parameter> ps, ComponentScope s)
/*     */   {
/* 124 */     return getInjectable(null, ps, s);
/*     */   }
/*     */   
/*     */   public List<Injectable> getInjectable(AccessibleObject ao, List<Parameter> ps, ComponentScope s)
/*     */   {
/* 129 */     List<Injectable> is = new ArrayList();
/* 130 */     for (Parameter p : ps)
/* 131 */       is.add(getInjectable(ao, p, s));
/* 132 */     return is;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\inject\ServerInjectableProviderFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */