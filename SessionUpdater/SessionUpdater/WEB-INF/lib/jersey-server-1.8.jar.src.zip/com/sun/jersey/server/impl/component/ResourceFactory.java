/*     */ package com.sun.jersey.server.impl.component;
/*     */ 
/*     */ import com.sun.jersey.api.container.ContainerException;
/*     */ import com.sun.jersey.api.core.ResourceConfig;
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*     */ import com.sun.jersey.core.spi.component.ComponentConstructor;
/*     */ import com.sun.jersey.core.spi.component.ComponentContext;
/*     */ import com.sun.jersey.core.spi.component.ComponentInjector;
/*     */ import com.sun.jersey.core.spi.component.ComponentScope;
/*     */ import com.sun.jersey.server.impl.inject.ServerInjectableProviderContext;
/*     */ import com.sun.jersey.server.impl.resource.PerRequestFactory;
/*     */ import com.sun.jersey.server.spi.component.ResourceComponentProvider;
/*     */ import com.sun.jersey.server.spi.component.ResourceComponentProviderFactory;
/*     */ import com.sun.jersey.server.spi.component.ResourceComponentProviderFactoryClass;
/*     */ import com.sun.jersey.spi.inject.Errors;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceFactory
/*     */ {
/*     */   private final ResourceConfig config;
/*     */   private final ServerInjectableProviderContext ipc;
/*     */   private final Map<Class, ResourceComponentProviderFactory> factories;
/*     */   
/*     */   public ResourceFactory(ResourceConfig config, ServerInjectableProviderContext ipc)
/*     */   {
/*  69 */     this.config = config;
/*  70 */     this.ipc = ipc;
/*  71 */     this.factories = new HashMap();
/*     */   }
/*     */   
/*     */   public ServerInjectableProviderContext getInjectableProviderContext() {
/*  75 */     return this.ipc;
/*     */   }
/*     */   
/*     */   public ComponentScope getScope(Class c) {
/*  79 */     return getComponentProviderFactory(c).getScope(c);
/*     */   }
/*     */   
/*     */   public ResourceComponentProvider getComponentProvider(ComponentContext cc, Class c) {
/*  83 */     return (ResourceComponentProvider)getComponentProviderFactory(c).getComponentProvider(c);
/*     */   }
/*     */   
/*     */   protected ResourceComponentProviderFactory getComponentProviderFactory(Class c) {
/*  87 */     Class<? extends ResourceComponentProviderFactory> providerFactoryClass = null;
/*  88 */     Class<? extends Annotation> scope = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  93 */     for (Annotation a : c.getAnnotations()) {
/*  94 */       Class<? extends Annotation> annotationType = a.annotationType();
/*  95 */       ResourceComponentProviderFactoryClass rf = (ResourceComponentProviderFactoryClass)annotationType.getAnnotation(ResourceComponentProviderFactoryClass.class);
/*     */       
/*  97 */       if ((rf != null) && (providerFactoryClass == null)) {
/*  98 */         providerFactoryClass = rf.value();
/*  99 */         scope = annotationType;
/* 100 */       } else if ((rf != null) && (providerFactoryClass != null)) {
/* 101 */         Errors.error("Class " + c.getName() + " is annotated with multiple scopes: " + scope.getName() + " and " + annotationType.getName());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 106 */     if (providerFactoryClass == null) {
/* 107 */       Object v = this.config.getProperties().get("com.sun.jersey.config.property.DefaultResourceComponentProviderFactoryClass");
/*     */       
/* 109 */       if (v == null)
/*     */       {
/* 111 */         providerFactoryClass = PerRequestFactory.class;
/* 112 */       } else if ((v instanceof String)) {
/*     */         try {
/* 114 */           providerFactoryClass = getSubclass(ReflectionHelper.classForNameWithException((String)v));
/*     */         } catch (ClassNotFoundException ex) {
/* 116 */           throw new ContainerException(ex);
/*     */         }
/* 118 */       } else if ((v instanceof Class)) {
/* 119 */         providerFactoryClass = getSubclass((Class)v);
/*     */       } else {
/* 121 */         throw new IllegalArgumentException("Property value for com.sun.jersey.config.property.DefaultResourceComponentProviderFactoryClass of type Class or String");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 127 */     ResourceComponentProviderFactory rcpf = (ResourceComponentProviderFactory)this.factories.get(providerFactoryClass);
/* 128 */     if (rcpf == null) {
/* 129 */       rcpf = getInstance(providerFactoryClass);
/* 130 */       this.factories.put(providerFactoryClass, rcpf);
/*     */     }
/*     */     
/* 133 */     return rcpf;
/*     */   }
/*     */   
/*     */   private Class<? extends ResourceComponentProviderFactory> getSubclass(Class<?> c) {
/* 137 */     if (ResourceComponentProviderFactory.class.isAssignableFrom(c)) {
/* 138 */       return c.asSubclass(ResourceComponentProviderFactory.class);
/*     */     }
/* 140 */     throw new IllegalArgumentException("Property value for com.sun.jersey.config.property.DefaultResourceComponentProviderFactoryClass of type " + c + " not of a subclass of " + ResourceComponentProviderFactory.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ResourceComponentProviderFactory getInstance(Class<? extends ResourceComponentProviderFactory> providerFactoryClass)
/*     */   {
/*     */     try
/*     */     {
/* 150 */       ComponentInjector<ResourceComponentProviderFactory> ci = new ComponentInjector(this.ipc, providerFactoryClass);
/*     */       
/*     */ 
/* 153 */       ComponentConstructor<ResourceComponentProviderFactory> cc = new ComponentConstructor(this.ipc, providerFactoryClass, ci);
/*     */       
/*     */ 
/* 156 */       return (ResourceComponentProviderFactory)cc.getInstance();
/*     */     } catch (Exception ex) {
/* 158 */       throw new ContainerException("Unable to create resource component provider", ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\component\ResourceFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */