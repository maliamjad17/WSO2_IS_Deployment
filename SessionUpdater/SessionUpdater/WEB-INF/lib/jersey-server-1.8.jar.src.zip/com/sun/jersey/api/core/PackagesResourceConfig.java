/*     */ package com.sun.jersey.api.core;
/*     */ 
/*     */ import com.sun.jersey.core.spi.scanning.PackageNamesScanner;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PackagesResourceConfig
/*     */   extends ScanningResourceConfig
/*     */ {
/*     */   public static final String PROPERTY_PACKAGES = "com.sun.jersey.config.property.packages";
/*  65 */   private static final Logger LOGGER = Logger.getLogger(PackagesResourceConfig.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PackagesResourceConfig(String... packages)
/*     */   {
/*  75 */     if ((packages == null) || (packages.length == 0)) {
/*  76 */       throw new IllegalArgumentException("Array of packages must not be null or empty");
/*     */     }
/*  78 */     init((String[])packages.clone());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PackagesResourceConfig(Map<String, Object> props)
/*     */   {
/*  89 */     this(getPackages(props));
/*     */     
/*  91 */     setPropertiesAndFeatures(props);
/*     */   }
/*     */   
/*     */   private void init(String[] packages) {
/*  95 */     if (LOGGER.isLoggable(Level.INFO)) {
/*  96 */       StringBuilder b = new StringBuilder();
/*  97 */       b.append("Scanning for root resource and provider classes in the packages:");
/*  98 */       for (String p : packages) {
/*  99 */         b.append('\n').append("  ").append(p);
/*     */       }
/* 101 */       LOGGER.log(Level.INFO, b.toString());
/*     */     }
/*     */     
/* 104 */     init(new PackageNamesScanner(packages));
/*     */   }
/*     */   
/*     */   private static String[] getPackages(Map<String, Object> props) {
/* 108 */     Object v = props.get("com.sun.jersey.config.property.packages");
/* 109 */     if (v == null) {
/* 110 */       throw new IllegalArgumentException("com.sun.jersey.config.property.packages property is missing");
/*     */     }
/*     */     
/* 113 */     String[] packages = getPackages(v);
/* 114 */     if (packages.length == 0) {
/* 115 */       throw new IllegalArgumentException("com.sun.jersey.config.property.packages contains no packages");
/*     */     }
/*     */     
/* 118 */     return packages;
/*     */   }
/*     */   
/*     */   private static String[] getPackages(Object param) {
/* 122 */     if ((param instanceof String))
/* 123 */       return getElements(new String[] { (String)param }, " ,;");
/* 124 */     if ((param instanceof String[])) {
/* 125 */       return getElements((String[])param, " ,;");
/*     */     }
/* 127 */     throw new IllegalArgumentException("com.sun.jersey.config.property.packages must have a property value of type String or String[]");
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\core\PackagesResourceConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */