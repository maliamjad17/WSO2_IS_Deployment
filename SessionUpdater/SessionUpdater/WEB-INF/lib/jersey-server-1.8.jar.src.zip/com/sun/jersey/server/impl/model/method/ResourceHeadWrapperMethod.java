/*    */ package com.sun.jersey.server.impl.model.method;
/*    */ 
/*    */ import com.sun.jersey.api.container.ContainerException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ResourceHeadWrapperMethod
/*    */   extends ResourceMethod
/*    */ {
/*    */   private final ResourceMethod m;
/*    */   
/*    */   public ResourceHeadWrapperMethod(ResourceMethod m)
/*    */   {
/* 53 */     super("HEAD", m.getTemplate(), m.getConsumes(), m.getProduces(), m.isProducesDeclared(), m.getDispatcher(), m.getRequestFilters(), m.getResponseFilters());
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 62 */     if (!m.getHttpMethod().equals("GET")) {
/* 63 */       throw new ContainerException("");
/*    */     }
/*    */     
/* 66 */     this.m = m;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 71 */     return this.m.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\method\ResourceHeadWrapperMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */