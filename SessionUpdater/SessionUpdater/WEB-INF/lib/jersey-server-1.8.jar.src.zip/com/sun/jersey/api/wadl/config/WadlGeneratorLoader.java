/*     */ package com.sun.jersey.api.wadl.config;
/*     */ 
/*     */ import com.sun.jersey.server.wadl.WadlGenerator;
/*     */ import com.sun.jersey.server.wadl.WadlGeneratorImpl;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WadlGeneratorLoader
/*     */ {
/*  87 */   private static final Logger LOGGER = Logger.getLogger(WadlGeneratorLoader.class.getName());
/*     */   
/*     */   static WadlGenerator loadWadlGenerators(List<WadlGenerator> wadlGenerators) throws Exception
/*     */   {
/*  91 */     WadlGenerator wadlGenerator = new WadlGeneratorImpl();
/*  92 */     if ((wadlGenerators != null) && (!wadlGenerators.isEmpty())) {
/*  93 */       for (WadlGenerator generator : wadlGenerators) {
/*  94 */         generator.setWadlGeneratorDelegate(wadlGenerator);
/*  95 */         wadlGenerator = generator;
/*     */       }
/*     */     }
/*  98 */     wadlGenerator.init();
/*  99 */     return wadlGenerator;
/*     */   }
/*     */   
/*     */   static WadlGenerator loadWadlGeneratorDescriptions(WadlGeneratorDescription... wadlGeneratorDescriptions) throws Exception {
/* 103 */     List<WadlGeneratorDescription> list = wadlGeneratorDescriptions != null ? Arrays.asList(wadlGeneratorDescriptions) : null;
/* 104 */     return loadWadlGeneratorDescriptions(list);
/*     */   }
/*     */   
/*     */   static WadlGenerator loadWadlGeneratorDescriptions(List<WadlGeneratorDescription> wadlGeneratorDescriptions) throws Exception {
/* 108 */     WadlGenerator wadlGenerator = new WadlGeneratorImpl();
/*     */     
/* 110 */     CallbackList callbacks = new CallbackList(null);
/*     */     try {
/* 112 */       if ((wadlGeneratorDescriptions != null) && (!wadlGeneratorDescriptions.isEmpty())) {
/* 113 */         for (WadlGeneratorDescription wadlGeneratorDescription : wadlGeneratorDescriptions) {
/* 114 */           WadlGeneratorControl control = loadWadlGenerator(wadlGeneratorDescription, wadlGenerator);
/* 115 */           wadlGenerator = control.wadlGenerator;
/* 116 */           callbacks.add(control.callback);
/*     */         }
/*     */       }
/* 119 */       wadlGenerator.init();
/*     */     } finally {
/* 121 */       callbacks.callback();
/*     */     }
/*     */     
/* 124 */     return wadlGenerator;
/*     */   }
/*     */   
/*     */ 
/*     */   private static WadlGeneratorControl loadWadlGenerator(WadlGeneratorDescription wadlGeneratorDescription, WadlGenerator wadlGeneratorDelegate)
/*     */     throws Exception
/*     */   {
/* 131 */     LOGGER.info("Loading wadlGenerator " + wadlGeneratorDescription.getGeneratorClass().getName());
/* 132 */     WadlGenerator generator = (WadlGenerator)wadlGeneratorDescription.getGeneratorClass().newInstance();
/* 133 */     generator.setWadlGeneratorDelegate(wadlGeneratorDelegate);
/* 134 */     CallbackList callbacks = null;
/* 135 */     if ((wadlGeneratorDescription.getProperties() != null) && (!wadlGeneratorDescription.getProperties().isEmpty()))
/*     */     {
/* 137 */       callbacks = new CallbackList(null);
/* 138 */       for (Map.Entry<Object, Object> entry : wadlGeneratorDescription.getProperties().entrySet()) {
/* 139 */         Callback callback = setProperty(generator, entry.getKey().toString(), entry.getValue());
/* 140 */         callbacks.add(callback);
/*     */       }
/*     */     }
/*     */     
/* 144 */     return new WadlGeneratorControl(generator, callbacks);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Callback setProperty(Object generator, String propertyName, Object propertyValue)
/*     */     throws Exception
/*     */   {
/* 158 */     Callback result = null;
/*     */     
/* 160 */     String methodName = "set" + propertyName.substring(0, 1).toUpperCase() + propertyName.substring(1);
/* 161 */     Method method = getMethodByName(methodName, generator.getClass());
/* 162 */     if (method.getParameterTypes().length != 1) {
/* 163 */       throw new RuntimeException("Method " + methodName + " is no setter, it does not expect exactly one parameter, but " + method.getParameterTypes().length);
/*     */     }
/* 165 */     Class<?> paramClazz = method.getParameterTypes()[0];
/* 166 */     if (paramClazz == propertyValue.getClass()) {
/* 167 */       method.invoke(generator, new Object[] { propertyValue });
/* 168 */     } else if ((File.class.equals(paramClazz)) && ((propertyValue instanceof String)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 175 */       LOGGER.warning("Configuring the " + method.getDeclaringClass().getSimpleName() + " with the file based property " + propertyName + " is deprecated and will be removed" + " in future versions of jersey! You should use the InputStream based property instead.");
/*     */       
/*     */ 
/*     */ 
/* 179 */       String filename = propertyValue.toString();
/* 180 */       if (filename.startsWith("classpath:")) {
/* 181 */         String strippedFilename = filename.substring("classpath:".length());
/* 182 */         URL resource = generator.getClass().getResource(strippedFilename);
/* 183 */         if (resource == null) {
/* 184 */           throw new RuntimeException("The file '" + strippedFilename + "' does not exist in the classpath." + " It's loaded by the generator class, so if you use a relative filename it's relative to" + " the generator class, otherwise you might want to load it via an absolute classpath reference like" + " classpath:/somefile.xml");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 189 */         File file = new File(resource.toURI());
/* 190 */         method.invoke(generator, new Object[] { file });
/*     */       } else {
/* 192 */         method.invoke(generator, new Object[] { new File(filename) });
/*     */       }
/* 194 */     } else if ((InputStream.class.equals(paramClazz)) && ((propertyValue instanceof String))) {
/* 195 */       final String resource = propertyValue.toString();
/* 196 */       ClassLoader loader = Thread.currentThread().getContextClassLoader();
/* 197 */       if (loader == null) {
/* 198 */         loader = WadlGeneratorLoader.class.getClassLoader();
/*     */       }
/* 200 */       InputStream is = loader.getResourceAsStream(resource);
/* 201 */       if (is == null) {
/* 202 */         String message = "The resource '" + resource + "' does not exist.";
/* 203 */         throw new RuntimeException(message);
/*     */       }
/* 205 */       result = new Callback()
/*     */       {
/*     */         public void callback() {
/*     */           try {
/* 209 */             this.val$is.close();
/*     */           } catch (IOException e) {
/* 211 */             WadlGeneratorLoader.LOGGER.log(Level.WARNING, "Could not close InputStream from resource " + resource, e);
/*     */           }
/*     */         }
/*     */       };
/*     */       
/*     */ 
/*     */       try
/*     */       {
/* 219 */         method.invoke(generator, new Object[] { is });
/*     */       } catch (Exception e) {
/* 221 */         is.close();
/* 222 */         throw e;
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 227 */       Constructor<?> paramTypeConstructor = paramClazz.getConstructor(new Class[] { propertyValue.getClass() });
/* 228 */       if (paramTypeConstructor != null) {
/* 229 */         Object typedPropertyValue = paramTypeConstructor.newInstance(new Object[] { propertyValue });
/* 230 */         method.invoke(generator, new Object[] { typedPropertyValue });
/*     */       } else {
/* 232 */         throw new RuntimeException("The property '" + propertyName + "' could not be set" + " because the expected parameter is neither of type " + propertyValue.getClass() + " nor of any type that provides a constructor expecting a " + propertyValue.getClass() + "." + " The expected parameter is of type " + paramClazz.getName());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 239 */     return result;
/*     */   }
/*     */   
/*     */   private static Method getMethodByName(String methodName, Class<?> clazz) {
/* 243 */     for (Method method : clazz.getMethods()) {
/* 244 */       if (method.getName().equals(methodName)) {
/* 245 */         return method;
/*     */       }
/*     */     }
/* 248 */     throw new RuntimeException("Method '" + methodName + "' not found for class " + clazz.getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class WadlGeneratorControl
/*     */   {
/*     */     WadlGenerator wadlGenerator;
/*     */     
/*     */ 
/*     */     WadlGeneratorLoader.Callback callback;
/*     */     
/*     */ 
/*     */     public WadlGeneratorControl(WadlGenerator wadlGenerator, WadlGeneratorLoader.Callback callback)
/*     */     {
/* 263 */       this.wadlGenerator = wadlGenerator;
/* 264 */       this.callback = callback;
/*     */     }
/*     */   }
/*     */   
/*     */   private static abstract interface Callback
/*     */   {
/*     */     public abstract void callback();
/*     */   }
/*     */   
/*     */   private static class CallbackList
/*     */     extends ArrayList<WadlGeneratorLoader.Callback>
/*     */     implements WadlGeneratorLoader.Callback
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     public void callback()
/*     */     {
/* 281 */       for (WadlGeneratorLoader.Callback callback : this) {
/* 282 */         callback.callback();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean add(WadlGeneratorLoader.Callback e)
/*     */     {
/* 294 */       return e != null ? super.add(e) : false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\wadl\config\WadlGeneratorLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */