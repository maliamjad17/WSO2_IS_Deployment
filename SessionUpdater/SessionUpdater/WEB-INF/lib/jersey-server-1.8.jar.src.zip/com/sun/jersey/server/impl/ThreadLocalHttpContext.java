/*     */ package com.sun.jersey.server.impl;
/*     */ 
/*     */ import com.sun.jersey.api.core.ExtendedUriInfo;
/*     */ import com.sun.jersey.api.core.HttpContext;
/*     */ import com.sun.jersey.api.core.HttpRequestContext;
/*     */ import com.sun.jersey.api.core.HttpResponseContext;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ThreadLocalHttpContext
/*     */   implements HttpContext
/*     */ {
/*  57 */   private ThreadLocal<HttpContext> context = new ThreadLocal();
/*     */   
/*     */ 
/*     */ 
/*     */   public void set(HttpContext context)
/*     */   {
/*  63 */     this.context.set(context);
/*     */   }
/*     */   
/*     */   public HttpContext get() {
/*  67 */     return (HttpContext)this.context.get();
/*     */   }
/*     */   
/*     */   public ExtendedUriInfo getUriInfo() {
/*     */     try {
/*  72 */       return ((HttpContext)this.context.get()).getUriInfo();
/*     */     } catch (NullPointerException ex) {
/*  74 */       throw new IllegalStateException();
/*     */     }
/*     */   }
/*     */   
/*     */   public HttpRequestContext getRequest() {
/*     */     try {
/*  80 */       return ((HttpContext)this.context.get()).getRequest();
/*     */     } catch (NullPointerException ex) {
/*  82 */       throw new IllegalStateException();
/*     */     }
/*     */   }
/*     */   
/*     */   public HttpResponseContext getResponse() {
/*     */     try {
/*  88 */       return ((HttpContext)this.context.get()).getResponse();
/*     */     } catch (NullPointerException ex) {
/*  90 */       throw new IllegalStateException();
/*     */     }
/*     */   }
/*     */   
/*     */   public Map<String, Object> getProperties() {
/*     */     try {
/*  96 */       return ((HttpContext)this.context.get()).getProperties();
/*     */     } catch (NullPointerException ex) {
/*  98 */       throw new IllegalStateException();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isTracingEnabled() {
/*     */     try {
/* 104 */       return ((HttpContext)this.context.get()).isTracingEnabled();
/*     */     } catch (NullPointerException ex) {
/* 106 */       throw new IllegalStateException();
/*     */     }
/*     */   }
/*     */   
/*     */   public void trace(String message) {
/*     */     try {
/* 112 */       ((HttpContext)this.context.get()).trace(message);
/*     */     } catch (NullPointerException ex) {
/* 114 */       throw new IllegalStateException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\ThreadLocalHttpContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */