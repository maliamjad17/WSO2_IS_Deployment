/*    */ package com.sun.jersey.spi.container;
/*    */ 
/*    */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*    */ import com.sun.jersey.core.spi.component.ProviderServices;
/*    */ import com.sun.jersey.impl.ImplMessages;
/*    */ import com.sun.jersey.server.impl.application.ResourceMethodDispatcherFactory;
/*    */ import com.sun.jersey.spi.dispatch.RequestDispatcher;
/*    */ import com.sun.jersey.spi.inject.Errors;
/*    */ import java.util.Set;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceMethodCustomInvokerDispatchFactory
/*    */ {
/* 59 */   private static final Logger LOGGER = Logger.getLogger(ResourceMethodDispatcherFactory.class.getName());
/*    */   final Set<ResourceMethodCustomInvokerDispatchProvider> customInvokerDispatchProviders;
/*    */   
/*    */   public ResourceMethodCustomInvokerDispatchFactory(ProviderServices providerServices)
/*    */   {
/* 64 */     this.customInvokerDispatchProviders = providerServices.getProvidersAndServices(ResourceMethodCustomInvokerDispatchProvider.class);
/*    */   }
/*    */   
/*    */ 
/*    */   public RequestDispatcher getDispatcher(AbstractResourceMethod abstractResourceMethod, JavaMethodInvoker invoker)
/*    */   {
/* 70 */     if (invoker == null) {
/* 71 */       return null;
/*    */     }
/*    */     
/* 74 */     Errors.mark();
/*    */     
/* 76 */     for (ResourceMethodCustomInvokerDispatchProvider rmdp : this.customInvokerDispatchProviders) {
/*    */       try
/*    */       {
/* 79 */         RequestDispatcher d = rmdp.create(abstractResourceMethod, invoker);
/* 80 */         if (d != null)
/*    */         {
/*    */ 
/* 83 */           Errors.reset();
/* 84 */           return d;
/*    */         }
/*    */       } catch (Exception e) {
/* 87 */         LOGGER.log(Level.SEVERE, ImplMessages.ERROR_PROCESSING_METHOD(abstractResourceMethod.getMethod(), rmdp.getClass().getName()), e);
/*    */       }
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 93 */     Errors.unmark();
/* 94 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\container\ResourceMethodCustomInvokerDispatchFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */