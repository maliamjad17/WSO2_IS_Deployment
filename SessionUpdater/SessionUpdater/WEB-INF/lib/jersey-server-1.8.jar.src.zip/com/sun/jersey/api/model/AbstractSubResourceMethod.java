/*    */ package com.sun.jersey.api.model;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AbstractSubResourceMethod
/*    */   extends AbstractResourceMethod
/*    */   implements PathAnnotated
/*    */ {
/*    */   private PathValue uriPath;
/*    */   
/*    */   public AbstractSubResourceMethod(AbstractResource resource, Method method, Class returnType, Type genericReturnType, PathValue uriPath, String httpMethod, Annotation[] annotations)
/*    */   {
/* 62 */     super(resource, method, returnType, genericReturnType, httpMethod, annotations);
/* 63 */     this.uriPath = uriPath;
/*    */   }
/*    */   
/*    */   public PathValue getPath() {
/* 67 */     return this.uriPath;
/*    */   }
/*    */   
/*    */   public void accept(AbstractModelVisitor visitor)
/*    */   {
/* 72 */     visitor.visitAbstractSubResourceMethod(this);
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 77 */     return "AbstractSubResourceMethod(" + getMethod().getDeclaringClass().getSimpleName() + "#" + getMethod().getName() + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\model\AbstractSubResourceMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */