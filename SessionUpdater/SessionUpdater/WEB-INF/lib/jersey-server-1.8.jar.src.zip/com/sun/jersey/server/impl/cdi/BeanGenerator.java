/*     */ package com.sun.jersey.server.impl.cdi;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import org.objectweb.asm.ClassWriter;
/*     */ import org.objectweb.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanGenerator
/*     */ {
/*  63 */   private static final Logger LOGGER = Logger.getLogger(CDIExtension.class.getName());
/*     */   private String prefix;
/*     */   private Method defineClassMethod;
/*  66 */   private int generatedClassCounter = 0;
/*     */   
/*     */   BeanGenerator(String prefix) {
/*  69 */     this.prefix = prefix;
/*     */     
/*  71 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*     */     try {
/*  73 */       this.defineClassMethod = ((Method)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */       {
/*     */         public Method run() throws Exception {
/*  76 */           Class classLoaderClass = Class.forName("java.lang.ClassLoader");
/*  77 */           Method method = classLoaderClass.getDeclaredMethod("defineClass", new Class[] { String.class, byte[].class, Integer.TYPE, Integer.TYPE });
/*     */           
/*     */ 
/*  80 */           method.setAccessible(true);
/*  81 */           return method;
/*     */         }
/*     */       }));
/*     */     }
/*     */     catch (PrivilegedActionException e) {
/*  86 */       LOGGER.log(Level.SEVERE, "failed to access method ClassLoader.defineClass", e);
/*     */       
/*  88 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   Class<?> createBeanClass() {
/*  93 */     ClassWriter writer = new ClassWriter(0);
/*  94 */     String name = this.prefix + Integer.toString(this.generatedClassCounter++);
/*  95 */     writer.visit(50, 1, name, null, "java/lang/Object", null);
/*  96 */     MethodVisitor methodVisitor = writer.visitMethod(1, "<init>", "()V", null, null);
/*  97 */     methodVisitor.visitCode();
/*  98 */     methodVisitor.visitVarInsn(25, 0);
/*  99 */     methodVisitor.visitMethodInsn(183, "java/lang/Object", "<init>", "()V");
/* 100 */     methodVisitor.visitInsn(177);
/* 101 */     methodVisitor.visitMaxs(1, 1);
/* 102 */     methodVisitor.visitEnd();
/* 103 */     writer.visitEnd();
/* 104 */     byte[] bytecode = writer.toByteArray();
/* 105 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*     */     try {
/* 107 */       Class<?> result = (Class)this.defineClassMethod.invoke(classLoader, new Object[] { name.replace("/", "."), bytecode, Integer.valueOf(0), Integer.valueOf(bytecode.length) });
/* 108 */       LOGGER.fine("Created class " + result.getName());
/* 109 */       return result;
/*     */     }
/*     */     catch (Throwable t) {
/* 112 */       LOGGER.log(Level.SEVERE, "error calling ClassLoader.defineClass", t); }
/* 113 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\cdi\BeanGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */