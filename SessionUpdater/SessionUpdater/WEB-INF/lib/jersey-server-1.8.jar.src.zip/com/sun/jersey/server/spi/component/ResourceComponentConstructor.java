/*     */ package com.sun.jersey.server.spi.component;
/*     */ 
/*     */ import com.sun.jersey.api.core.HttpContext;
/*     */ import com.sun.jersey.api.model.AbstractResource;
/*     */ import com.sun.jersey.api.model.AbstractResourceConstructor;
/*     */ import com.sun.jersey.core.spi.component.ComponentScope;
/*     */ import com.sun.jersey.server.impl.inject.AbstractHttpContextInjectable;
/*     */ import com.sun.jersey.server.impl.inject.ServerInjectableProviderContext;
/*     */ import com.sun.jersey.spi.inject.Errors;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceComponentConstructor
/*     */ {
/*     */   private final Class c;
/*     */   private final ResourceComponentInjector rci;
/*     */   private final Constructor constructor;
/*  73 */   private final List<Method> postConstructs = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final List<AbstractHttpContextInjectable> injectables;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class ConstructorInjectablePair
/*     */   {
/*     */     private final Constructor con;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private final List<Injectable> is;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private ConstructorInjectablePair(Constructor con, List<Injectable> is)
/*     */     {
/* 102 */       this.con = con;
/* 103 */       this.is = is;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ConstructorComparator<T> implements Comparator<ResourceComponentConstructor.ConstructorInjectablePair> {
/*     */     public int compare(ResourceComponentConstructor.ConstructorInjectablePair o1, ResourceComponentConstructor.ConstructorInjectablePair o2) {
/* 109 */       int p = Collections.frequency(ResourceComponentConstructor.ConstructorInjectablePair.access$000(o1), null) - Collections.frequency(ResourceComponentConstructor.ConstructorInjectablePair.access$000(o2), null);
/* 110 */       if (p != 0) {
/* 111 */         return p;
/*     */       }
/* 113 */       return ResourceComponentConstructor.ConstructorInjectablePair.access$100(o2).getParameterTypes().length - ResourceComponentConstructor.ConstructorInjectablePair.access$100(o1).getParameterTypes().length;
/*     */     }
/*     */   }
/*     */   
/*     */   public ResourceComponentConstructor(ServerInjectableProviderContext sipc, ComponentScope scope, AbstractResource ar)
/*     */   {
/* 119 */     this.c = ar.getResourceClass();
/*     */     
/* 121 */     int modifiers = this.c.getModifiers();
/* 122 */     if (!Modifier.isPublic(modifiers)) {
/* 123 */       Errors.nonPublicClass(this.c);
/*     */     }
/*     */     
/* 126 */     if (Modifier.isAbstract(modifiers)) {
/* 127 */       if (Modifier.isInterface(modifiers)) {
/* 128 */         Errors.interfaceClass(this.c);
/*     */       } else {
/* 130 */         Errors.abstractClass(this.c);
/*     */       }
/*     */     }
/*     */     
/* 134 */     if ((this.c.getEnclosingClass() != null) && (!Modifier.isStatic(modifiers))) {
/* 135 */       Errors.innerClass(this.c);
/*     */     }
/*     */     
/* 138 */     if ((Modifier.isPublic(modifiers)) && (!Modifier.isAbstract(modifiers)) && 
/* 139 */       (this.c.getConstructors().length == 0)) {
/* 140 */       Errors.nonPublicConstructor(this.c);
/*     */     }
/*     */     
/*     */ 
/* 144 */     this.rci = new ResourceComponentInjector(sipc, scope, ar);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 149 */     this.postConstructs.addAll(ar.getPostConstructMethods());
/*     */     
/* 151 */     ConstructorInjectablePair cip = getConstructor(sipc, scope, ar);
/* 152 */     if (cip == null) {
/* 153 */       this.constructor = null;
/* 154 */       this.injectables = null;
/* 155 */     } else if (cip.is.isEmpty()) {
/* 156 */       this.constructor = cip.con;
/* 157 */       this.injectables = null;
/*     */     } else {
/* 159 */       if (cip.is.contains(null))
/*     */       {
/* 161 */         for (int i = 0; i < cip.is.size(); i++) {
/* 162 */           if (cip.is.get(i) == null) {
/* 163 */             Errors.missingDependency(cip.con, i);
/*     */           }
/*     */         }
/*     */       }
/* 167 */       this.constructor = cip.con;
/* 168 */       this.injectables = AbstractHttpContextInjectable.transform(cip.is);
/*     */     }
/*     */   }
/*     */   
/*     */   public Class getResourceClass() {
/* 173 */     return this.c;
/*     */   }
/*     */   
/*     */   public Object construct(HttpContext hc)
/*     */     throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
/*     */   {
/* 179 */     Object o = _construct(hc);
/* 180 */     this.rci.inject(hc, o);
/* 181 */     for (Method postConstruct : this.postConstructs) {
/* 182 */       postConstruct.invoke(o, new Object[0]);
/*     */     }
/* 184 */     return o;
/*     */   }
/*     */   
/*     */   private Object _construct(HttpContext hc)
/*     */     throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
/*     */   {
/* 190 */     if (this.injectables == null) {
/* 191 */       return this.constructor != null ? this.constructor.newInstance(new Object[0]) : this.c.newInstance();
/*     */     }
/* 193 */     Object[] params = new Object[this.injectables.size()];
/* 194 */     int i = 0;
/* 195 */     for (AbstractHttpContextInjectable injectable : this.injectables) {
/* 196 */       params[(i++)] = (injectable != null ? injectable.getValue(hc) : null);
/*     */     }
/* 198 */     return this.constructor.newInstance(params);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private <T> ConstructorInjectablePair getConstructor(ServerInjectableProviderContext sipc, ComponentScope scope, AbstractResource ar)
/*     */   {
/* 219 */     if (ar.getConstructors().isEmpty()) {
/* 220 */       return null;
/*     */     }
/* 222 */     SortedSet<ConstructorInjectablePair> cs = new TreeSet(new ConstructorComparator(null));
/*     */     
/* 224 */     for (AbstractResourceConstructor arc : ar.getConstructors()) {
/* 225 */       List<Injectable> is = sipc.getInjectable(arc.getCtor(), arc.getParameters(), scope);
/* 226 */       cs.add(new ConstructorInjectablePair(arc.getCtor(), is, null));
/*     */     }
/*     */     
/* 229 */     return (ConstructorInjectablePair)cs.first();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\spi\component\ResourceComponentConstructor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */