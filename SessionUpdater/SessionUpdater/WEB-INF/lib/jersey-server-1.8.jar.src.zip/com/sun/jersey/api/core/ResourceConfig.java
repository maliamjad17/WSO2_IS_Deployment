/*     */ package com.sun.jersey.api.core;
/*     */ 
/*     */ import com.sun.jersey.api.uri.UriComponent;
/*     */ import com.sun.jersey.api.uri.UriComponent.Type;
/*     */ import com.sun.jersey.core.header.LanguageTag;
/*     */ import com.sun.jersey.core.util.FeaturesAndProperties;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.ws.rs.Path;
/*     */ import javax.ws.rs.core.Application;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.ext.Provider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ResourceConfig
/*     */   extends Application
/*     */   implements FeaturesAndProperties
/*     */ {
/*  77 */   private static final Logger LOGGER = Logger.getLogger(ResourceConfig.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String FEATURE_NORMALIZE_URI = "com.sun.jersey.config.feature.NormalizeURI";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String FEATURE_CANONICALIZE_URI_PATH = "com.sun.jersey.config.feature.CanonicalizeURIPath";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String FEATURE_REDIRECT = "com.sun.jersey.config.feature.Redirect";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String FEATURE_MATCH_MATRIX_PARAMS = "com.sun.jersey.config.feature.IgnoreMatrixParams";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String FEATURE_IMPLICIT_VIEWABLES = "com.sun.jersey.config.feature.ImplicitViewables";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String FEATURE_DISABLE_WADL = "com.sun.jersey.config.feature.DisableWADL";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String FEATURE_TRACE = "com.sun.jersey.config.feature.Trace";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String FEATURE_TRACE_PER_REQUEST = "com.sun.jersey.config.feature.TracePerRequest";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String PROPERTY_MEDIA_TYPE_MAPPINGS = "com.sun.jersey.config.property.MediaTypeMappings";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String PROPERTY_LANGUAGE_MAPPINGS = "com.sun.jersey.config.property.LanguageMappings";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String PROPERTY_DEFAULT_RESOURCE_COMPONENT_PROVIDER_FACTORY_CLASS = "com.sun.jersey.config.property.DefaultResourceComponentProviderFactoryClass";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String PROPERTY_CONTAINER_NOTIFIER = "com.sun.jersey.spi.container.ContainerNotifier";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String PROPERTY_CONTAINER_REQUEST_FILTERS = "com.sun.jersey.spi.container.ContainerRequestFilters";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String PROPERTY_CONTAINER_RESPONSE_FILTERS = "com.sun.jersey.spi.container.ContainerResponseFilters";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String PROPERTY_RESOURCE_FILTER_FACTORIES = "com.sun.jersey.spi.container.ResourceFilters";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String PROPERTY_WADL_GENERATOR_CONFIG = "com.sun.jersey.config.property.WadlGeneratorConfig";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String COMMON_DELIMITERS = " ,;";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Map<String, Boolean> getFeatures();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean getFeature(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Map<String, Object> getProperties();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Object getProperty(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, MediaType> getMediaTypeMappings()
/*     */   {
/* 415 */     return Collections.emptyMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, String> getLanguageMappings()
/*     */   {
/* 431 */     return Collections.emptyMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, Object> getExplicitRootResources()
/*     */   {
/* 457 */     return Collections.emptyMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validate()
/*     */   {
/* 485 */     Iterator<Class<?>> i = getClasses().iterator();
/* 486 */     Class<?> c; while (i.hasNext()) {
/* 487 */       c = (Class)i.next();
/* 488 */       for (Object o : getSingletons()) {
/* 489 */         if (c.isInstance(o)) {
/* 490 */           i.remove();
/* 491 */           LOGGER.log(Level.WARNING, "Class " + c.getName() + " is ignored as an instance is registered in the set of singletons");
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 499 */     Set<Class<?>> objectClassSet = new HashSet();
/* 500 */     Set<Class<?>> conflictSet = new HashSet();
/* 501 */     for (Object o : getSingletons()) {
/* 502 */       if (o.getClass().isAnnotationPresent(Path.class)) {
/* 503 */         if (objectClassSet.contains(o.getClass())) {
/* 504 */           conflictSet.add(o.getClass());
/*     */         } else {
/* 506 */           objectClassSet.add(o.getClass());
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 511 */     if (!conflictSet.isEmpty()) {
/* 512 */       for (Class<?> c : conflictSet) {
/* 513 */         LOGGER.log(Level.SEVERE, "Root resource class " + c.getName() + " is instantiated more than once in the set of registered singletons");
/*     */       }
/*     */       
/*     */ 
/* 517 */       throw new IllegalArgumentException("The set of registered singletons contains more than one instance of the same root resource class");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 523 */     parseAndValidateMappings("com.sun.jersey.config.property.MediaTypeMappings", getMediaTypeMappings(), new TypeParser()
/*     */     {
/*     */       public MediaType valueOf(String value) {
/* 526 */         return MediaType.valueOf(value);
/*     */       }
/*     */       
/*     */ 
/* 530 */     });
/* 531 */     parseAndValidateMappings("com.sun.jersey.config.property.LanguageMappings", getLanguageMappings(), new TypeParser()
/*     */     {
/*     */       public String valueOf(String value) {
/* 534 */         return LanguageTag.valueOf(value).toString();
/*     */       }
/*     */       
/*     */ 
/* 538 */     });
/* 539 */     encodeKeys(getMediaTypeMappings());
/* 540 */     encodeKeys(getLanguageMappings());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private <T> void parseAndValidateMappings(String property, Map<String, T> mappingsMap, TypeParser<T> parser)
/*     */   {
/* 549 */     Object mappings = getProperty(property);
/* 550 */     if (mappings == null) {
/* 551 */       return;
/*     */     }
/* 553 */     if ((mappings instanceof String)) {
/* 554 */       parseMappings(property, (String)mappings, mappingsMap, parser);
/* 555 */     } else if ((mappings instanceof String[])) {
/* 556 */       String[] mappingsArray = (String[])mappings;
/* 557 */       for (int i = 0; i < mappingsArray.length; i++)
/* 558 */         parseMappings(property, mappingsArray[i], mappingsMap, parser);
/*     */     } else {
/* 560 */       throw new IllegalArgumentException("Provided " + property + " mappings is invalid. Acceptable types are String" + " and String[].");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private <T> void parseMappings(String property, String mappings, Map<String, T> mappingsMap, TypeParser<T> parser)
/*     */   {
/* 568 */     if (mappings == null) {
/* 569 */       return;
/*     */     }
/* 571 */     String[] records = mappings.split(",");
/*     */     
/* 573 */     for (int i = 0; i < records.length; i++) {
/* 574 */       String[] record = records[i].split(":");
/* 575 */       if (record.length != 2) {
/* 576 */         throw new IllegalArgumentException("Provided " + property + " mapping \"" + mappings + "\" is invalid. It " + "should contain two parts, key and value, separated by ':'.");
/*     */       }
/*     */       
/*     */ 
/* 580 */       String trimmedSegment = record[0].trim();
/* 581 */       String trimmedValue = record[1].trim();
/*     */       
/* 583 */       if (trimmedSegment.length() == 0) {
/* 584 */         throw new IllegalArgumentException("The key in " + property + " mappings record \"" + records[i] + "\" is empty.");
/*     */       }
/* 586 */       if (trimmedValue.length() == 0) {
/* 587 */         throw new IllegalArgumentException("The value in " + property + " mappings record \"" + records[i] + "\" is empty.");
/*     */       }
/*     */       
/* 590 */       mappingsMap.put(trimmedSegment, parser.valueOf(trimmedValue));
/*     */     }
/*     */   }
/*     */   
/*     */   private <T> void encodeKeys(Map<String, T> map) {
/* 595 */     Map<String, T> tempMap = new HashMap();
/* 596 */     for (Map.Entry<String, T> entry : map.entrySet())
/* 597 */       tempMap.put(UriComponent.contextualEncode((String)entry.getKey(), UriComponent.Type.PATH_SEGMENT), entry.getValue());
/* 598 */     map.clear();
/* 599 */     map.putAll(tempMap);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<Class<?>> getRootResourceClasses()
/*     */   {
/* 611 */     Set<Class<?>> s = new LinkedHashSet();
/*     */     
/* 613 */     for (Class<?> c : getClasses()) {
/* 614 */       if (isRootResourceClass(c)) {
/* 615 */         s.add(c);
/*     */       }
/*     */     }
/* 618 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<Class<?>> getProviderClasses()
/*     */   {
/* 630 */     Set<Class<?>> s = new LinkedHashSet();
/*     */     
/* 632 */     for (Class<?> c : getClasses()) {
/* 633 */       if (!isRootResourceClass(c)) {
/* 634 */         s.add(c);
/*     */       }
/*     */     }
/* 637 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<Object> getRootResourceSingletons()
/*     */   {
/* 649 */     Set<Object> s = new LinkedHashSet();
/*     */     
/* 651 */     for (Object o : getSingletons()) {
/* 652 */       if (isRootResourceClass(o.getClass())) {
/* 653 */         s.add(o);
/*     */       }
/*     */     }
/* 656 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<Object> getProviderSingletons()
/*     */   {
/* 668 */     Set<Object> s = new LinkedHashSet();
/*     */     
/* 670 */     for (Object o : getSingletons()) {
/* 671 */       if (!isRootResourceClass(o.getClass())) {
/* 672 */         s.add(o);
/*     */       }
/*     */     }
/* 675 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isRootResourceClass(Class<?> c)
/*     */   {
/* 686 */     if (c == null) {
/* 687 */       return false;
/*     */     }
/* 689 */     if (c.isAnnotationPresent(Path.class)) { return true;
/*     */     }
/* 691 */     for (Class i : c.getInterfaces()) {
/* 692 */       if (i.isAnnotationPresent(Path.class)) return true;
/*     */     }
/* 694 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isProviderClass(Class<?> c)
/*     */   {
/* 705 */     return (c != null) && (c.isAnnotationPresent(Provider.class));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getContainerRequestFilters()
/*     */   {
/* 719 */     return getFilterList("com.sun.jersey.spi.container.ContainerRequestFilters");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getContainerResponseFilters()
/*     */   {
/* 733 */     return getFilterList("com.sun.jersey.spi.container.ContainerResponseFilters");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getResourceFilterFactories()
/*     */   {
/* 747 */     return getFilterList("com.sun.jersey.spi.container.ResourceFilters");
/*     */   }
/*     */   
/*     */   private List getFilterList(String propertyName) {
/* 751 */     Object o = getProperty(propertyName);
/* 752 */     if (o == null) {
/* 753 */       List l = new ArrayList();
/* 754 */       getProperties().put(propertyName, l);
/* 755 */       return l; }
/* 756 */     if ((o instanceof List)) {
/* 757 */       return (List)o;
/*     */     }
/* 759 */     List l = new ArrayList();
/* 760 */     l.add(o);
/* 761 */     getProperties().put(propertyName, l);
/* 762 */     return l;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPropertiesAndFeatures(Map<String, Object> entries)
/*     */   {
/* 781 */     for (Map.Entry<String, Object> e : entries.entrySet()) {
/* 782 */       if (!getProperties().containsKey(e.getKey())) {
/* 783 */         getProperties().put(e.getKey(), e.getValue());
/*     */       }
/*     */       
/* 786 */       if (!getFeatures().containsKey(e.getKey())) {
/* 787 */         Object v = e.getValue();
/* 788 */         if ((v instanceof String)) {
/* 789 */           String sv = ((String)v).trim();
/* 790 */           if (sv.equalsIgnoreCase("true")) {
/* 791 */             getFeatures().put(e.getKey(), Boolean.valueOf(true));
/* 792 */           } else if (sv.equalsIgnoreCase("false")) {
/* 793 */             getFeatures().put(e.getKey(), Boolean.valueOf(false));
/*     */           }
/* 795 */         } else if ((v instanceof Boolean)) {
/* 796 */           getFeatures().put(e.getKey(), (Boolean)v);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(Application app)
/*     */   {
/* 808 */     if (app.getClasses() != null)
/* 809 */       addAllFirst(getClasses(), app.getClasses());
/* 810 */     if (app.getSingletons() != null) {
/* 811 */       addAllFirst(getSingletons(), app.getSingletons());
/*     */     }
/* 813 */     if ((app instanceof ResourceConfig)) {
/* 814 */       ResourceConfig rc = (ResourceConfig)app;
/*     */       
/* 816 */       getExplicitRootResources().putAll(rc.getExplicitRootResources());
/*     */       
/* 818 */       getLanguageMappings().putAll(rc.getLanguageMappings());
/* 819 */       getMediaTypeMappings().putAll(rc.getMediaTypeMappings());
/*     */       
/* 821 */       getFeatures().putAll(rc.getFeatures());
/* 822 */       getProperties().putAll(rc.getProperties());
/*     */     }
/*     */   }
/*     */   
/*     */   private <T> void addAllFirst(Set<T> a, Set<T> b) {
/* 827 */     Set<T> x = new LinkedHashSet();
/* 828 */     x.addAll(b);
/* 829 */     x.addAll(a);
/*     */     
/* 831 */     a.clear();
/* 832 */     a.addAll(x);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceConfig clone()
/*     */   {
/* 847 */     ResourceConfig that = new DefaultResourceConfig();
/*     */     
/* 849 */     that.getClasses().addAll(getClasses());
/* 850 */     that.getSingletons().addAll(getSingletons());
/*     */     
/* 852 */     that.getExplicitRootResources().putAll(getExplicitRootResources());
/*     */     
/* 854 */     that.getLanguageMappings().putAll(getLanguageMappings());
/* 855 */     that.getMediaTypeMappings().putAll(getMediaTypeMappings());
/*     */     
/* 857 */     that.getFeatures().putAll(getFeatures());
/* 858 */     that.getProperties().putAll(getProperties());
/*     */     
/* 860 */     return that;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String[] getElements(String[] elements)
/*     */   {
/* 874 */     return getElements(elements, ";");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String[] getElements(String[] elements, String delimiters)
/*     */   {
/* 890 */     List<String> es = new LinkedList();
/* 891 */     for (String element : elements) {
/* 892 */       if (element != null) {
/* 893 */         element = element.trim();
/* 894 */         if (element.length() != 0)
/* 895 */           for (String subElement : getElements(element, delimiters))
/* 896 */             if ((subElement != null) && (subElement.length() != 0))
/* 897 */               es.add(subElement);
/*     */       }
/*     */     }
/* 900 */     return (String[])es.toArray(new String[es.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String[] getElements(String elements, String delimiters)
/*     */   {
/* 915 */     String regex = "[";
/* 916 */     for (char c : delimiters.toCharArray())
/* 917 */       regex = regex + Pattern.quote(String.valueOf(c));
/* 918 */     regex = regex + "]";
/*     */     
/* 920 */     String[] es = elements.split(regex);
/* 921 */     for (int i = 0; i < es.length; i++) {
/* 922 */       es[i] = es[i].trim();
/*     */     }
/* 924 */     return es;
/*     */   }
/*     */   
/*     */   private static abstract interface TypeParser<T>
/*     */   {
/*     */     public abstract T valueOf(String paramString);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\core\ResourceConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */