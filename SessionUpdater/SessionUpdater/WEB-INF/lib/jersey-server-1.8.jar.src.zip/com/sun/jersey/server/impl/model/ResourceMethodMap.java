/*    */ package com.sun.jersey.server.impl.model;
/*    */ 
/*    */ import com.sun.jersey.server.impl.model.method.ResourceMethod;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map.Entry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ResourceMethodMap
/*    */   extends HashMap<String, List<ResourceMethod>>
/*    */ {
/*    */   public void put(ResourceMethod method)
/*    */   {
/* 63 */     List<ResourceMethod> l = (List)get(method.getHttpMethod());
/* 64 */     if (l == null) {
/* 65 */       l = new ArrayList();
/* 66 */       put(method.getHttpMethod(), l);
/*    */     }
/* 68 */     l.add(method);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void sort()
/*    */   {
/* 75 */     for (Map.Entry<String, List<ResourceMethod>> e : entrySet()) {
/* 76 */       Collections.sort((List)e.getValue(), ResourceMethod.COMPARATOR);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\ResourceMethodMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */