/*     */ package com.sun.jersey.server.impl.uri.rules.automata;
/*     */ 
/*     */ import com.sun.jersey.api.uri.UriPattern;
/*     */ import java.util.Iterator;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TrieNode<T>
/*     */ {
/*  56 */   public static final Pattern PARAMETER_PATTERN = Pattern.compile("\\{([\\w-\\._~]+?)\\}");
/*     */   
/*     */ 
/*     */ 
/*     */   private static final char WILDCARD_CHAR = '\000';
/*     */   
/*     */ 
/*     */   private TrieArc<T> firstArc;
/*     */   
/*     */ 
/*     */   private TrieArc<T> lastArc;
/*     */   
/*     */ 
/*  69 */   private int arcs = 0;
/*     */   
/*     */ 
/*  72 */   private TrieNodeValue<T> value = new TrieNodeValue();
/*     */   
/*     */ 
/*     */   private UriPattern pattern;
/*     */   
/*     */ 
/*  78 */   private boolean wildcard = false;
/*     */   
/*     */ 
/*     */ 
/*     */   protected void setWildcard(boolean b)
/*     */   {
/*  84 */     this.wildcard = b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setValue(T value, UriPattern pattern)
/*     */   {
/*  92 */     this.value.set(value);
/*  93 */     this.pattern = pattern;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected TrieNode() {}
/*     */   
/*     */ 
/*     */ 
/*     */   protected TrieNode(T value)
/*     */   {
/* 105 */     this.value.set(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected TrieArc<T> matchExitArc(CharSequence seq, int i)
/*     */   {
/* 113 */     TrieArc<T> arc = this.firstArc;
/* 114 */     while (arc != null) {
/* 115 */       if (arc.match(seq, i) > 0) {
/* 116 */         return arc;
/*     */       }
/* 118 */       arc = arc.next;
/*     */     }
/* 120 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean hasValue()
/*     */   {
/* 127 */     return !this.value.isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addArc(TrieArc<T> arc)
/*     */   {
/* 135 */     if (this.firstArc == null) {
/* 136 */       this.firstArc = arc;
/*     */     }
/*     */     else {
/* 139 */       this.lastArc.next = arc;
/*     */     }
/* 141 */     this.lastArc = arc;
/* 142 */     this.arcs += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean add(CharSequence path, int i, T value, UriPattern pattern)
/*     */   {
/* 156 */     if (i >= path.length()) {
/* 157 */       setValue(value, pattern);
/* 158 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 162 */     char input = path.charAt(i);
/* 163 */     boolean added = false;
/* 164 */     TrieArc<T> arc = this.firstArc;
/* 165 */     while (arc != null) {
/* 166 */       if (arc.match(path, i) > 0) {
/* 167 */         added = arc.target.add(path, i + 1, value, pattern);
/* 168 */         if (added) {
/* 169 */           return added;
/*     */         }
/*     */       }
/* 172 */       arc = arc.next;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 177 */     if (input == 0) {
/* 178 */       setWildcard(true);
/* 179 */       return add(path, i + 1, value, pattern);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 184 */     TrieNode<T> node = new TrieNode();
/* 185 */     addArc(new TrieArc(node, input));
/* 186 */     return node.add(path, i + 1, value, pattern);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void add(String path, T value, UriPattern pattern)
/*     */   {
/* 200 */     Matcher matcher = PARAMETER_PATTERN.matcher(path);
/* 201 */     String uri = matcher.replaceAll(String.valueOf('\000'));
/*     */     
/*     */ 
/* 204 */     if ((uri.endsWith("/")) && (uri.length() > 1)) {
/* 205 */       add(uri.substring(0, uri.length() - 1), 0, value, pattern);
/*     */     }
/*     */     
/*     */ 
/* 209 */     add(uri, 0, value, pattern);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 217 */     StringBuilder out = new StringBuilder();
/* 218 */     toStringRepresentation(out, 0, new char[] { '\000' });
/* 219 */     return out.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void toStringRepresentation(StringBuilder out, int level, char[] c)
/*     */   {
/* 229 */     for (int i = 0; i < level; i++) out.append(' ');
/* 230 */     out.append("ARC(" + new String(c) + ") ->");
/* 231 */     out.append(getClass().getSimpleName() + (this.wildcard ? "*" : ""));
/* 232 */     out.append(" ");
/* 233 */     out.append(this.value);
/* 234 */     out.append('\n');
/* 235 */     TrieArc<T> arc = this.firstArc;
/* 236 */     while (arc != null) {
/* 237 */       arc.target.toStringRepresentation(out, level + 2, arc.code);
/* 238 */       arc = arc.next;
/*     */     }
/*     */   }
/*     */   
/*     */   public UriPattern getPattern()
/*     */   {
/* 244 */     return this.pattern;
/*     */   }
/*     */   
/*     */   public Iterator<T> getValue()
/*     */   {
/* 249 */     return this.value.getIterator();
/*     */   }
/*     */   
/*     */   protected boolean isWildcard()
/*     */   {
/* 254 */     return this.wildcard;
/*     */   }
/*     */   
/*     */   protected TrieArc<T> getFirstArc()
/*     */   {
/* 259 */     return this.firstArc;
/*     */   }
/*     */   
/*     */   public int getArcs()
/*     */   {
/* 264 */     return this.arcs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void pack()
/*     */   {
/* 271 */     TrieArc<T> arc = this.firstArc;
/* 272 */     while (arc != null) {
/* 273 */       arc.pack();
/* 274 */       arc = arc.next;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\uri\rules\automata\TrieNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */