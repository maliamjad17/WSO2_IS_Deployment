/*     */ package com.sun.jersey.api.model;
/*     */ 
/*     */ import com.sun.jersey.spi.container.ParamQualifier;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Parameter
/*     */   implements AnnotatedElement
/*     */ {
/*     */   private final Annotation[] annotations;
/*     */   private final Annotation annotation;
/*     */   private final Source source;
/*     */   private final String sourceName;
/*     */   private final boolean encoded;
/*     */   private final String defaultValue;
/*     */   private final Type type;
/*     */   private final Class<?> clazz;
/*     */   
/*     */   public static enum Source
/*     */   {
/*  53 */     ENTITY,  QUERY,  MATRIX,  PATH,  COOKIE,  HEADER,  CONTEXT,  FORM,  UNKNOWN;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private Source() {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Parameter(Annotation[] as, Annotation a, Source source, String sourceName, Type type, Class<?> clazz)
/*     */   {
/*  65 */     this(as, a, source, sourceName, type, clazz, false, null);
/*     */   }
/*     */   
/*     */   public Parameter(Annotation[] as, Annotation a, Source source, String sourceName, Type type, Class<?> clazz, boolean encoded) {
/*  69 */     this(as, a, source, sourceName, type, clazz, encoded, null);
/*     */   }
/*     */   
/*     */   public Parameter(Annotation[] as, Annotation a, Source source, String sourceName, Type type, Class<?> clazz, String defaultValue) {
/*  73 */     this(as, a, source, sourceName, type, clazz, false, defaultValue);
/*     */   }
/*     */   
/*     */   public Parameter(Annotation[] as, Annotation a, Source source, String sourceName, Type type, Class<?> clazz, boolean encoded, String defaultValue) {
/*  77 */     this.annotations = as;
/*  78 */     this.annotation = a;
/*  79 */     this.source = source;
/*  80 */     this.sourceName = sourceName;
/*  81 */     this.type = type;
/*  82 */     this.clazz = clazz;
/*  83 */     this.encoded = encoded;
/*  84 */     this.defaultValue = defaultValue;
/*     */   }
/*     */   
/*     */   public Annotation getAnnotation() {
/*  88 */     return this.annotation;
/*     */   }
/*     */   
/*     */   public Source getSource() {
/*  92 */     return this.source;
/*     */   }
/*     */   
/*     */   public String getSourceName() {
/*  96 */     return this.sourceName;
/*     */   }
/*     */   
/*     */   public boolean isEncoded() {
/* 100 */     return this.encoded;
/*     */   }
/*     */   
/*     */   public boolean hasDefaultValue() {
/* 104 */     return this.defaultValue != null;
/*     */   }
/*     */   
/*     */   public String getDefaultValue() {
/* 108 */     return this.defaultValue;
/*     */   }
/*     */   
/*     */   public Class<?> getParameterClass() {
/* 112 */     return this.clazz;
/*     */   }
/*     */   
/*     */   public Type getParameterType() {
/* 116 */     return this.type;
/*     */   }
/*     */   
/*     */   public boolean isQualified() {
/* 120 */     for (Annotation a : getAnnotations()) {
/* 121 */       if (a.annotationType().isAnnotationPresent(ParamQualifier.class)) {
/* 122 */         return true;
/*     */       }
/*     */     }
/* 125 */     return false;
/*     */   }
/*     */   
/*     */   public <T extends Annotation> T getAnnotation(Class<T> annotationType) {
/* 129 */     for (Annotation a : this.annotations) {
/* 130 */       if (annotationType == a.annotationType())
/* 131 */         return (Annotation)annotationType.cast(a);
/*     */     }
/* 133 */     return null;
/*     */   }
/*     */   
/*     */   public Annotation[] getAnnotations() {
/* 137 */     return (Annotation[])this.annotations.clone();
/*     */   }
/*     */   
/*     */   public Annotation[] getDeclaredAnnotations() {
/* 141 */     return (Annotation[])this.annotations.clone();
/*     */   }
/*     */   
/*     */   public boolean isAnnotationPresent(Class<? extends Annotation> annotationType) {
/* 145 */     return getAnnotation(annotationType) != null;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\model\Parameter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */