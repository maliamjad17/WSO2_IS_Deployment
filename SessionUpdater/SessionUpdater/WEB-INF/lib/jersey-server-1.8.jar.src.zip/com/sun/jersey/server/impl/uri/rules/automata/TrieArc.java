/*     */ package com.sun.jersey.server.impl.uri.rules.automata;
/*     */ 
/*     */ import com.sun.jersey.api.uri.UriPattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrieArc<T>
/*     */ {
/*     */   protected char[] code;
/*     */   protected TrieNode<T> target;
/*     */   protected TrieArc<T> next;
/*     */   
/*     */   public TrieArc(TrieNode<T> target, char code)
/*     */   {
/*  64 */     this.target = target;
/*  65 */     this.code = new char[] { code };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void merge(TrieArc<T> arc)
/*     */   {
/*  72 */     int p = this.code.length;
/*     */     
/*     */ 
/*  75 */     this.code = copyOf(this.code, this.code.length + arc.code.length);
/*  76 */     System.arraycopy(arc.code, 0, this.code, p, arc.code.length);
/*  77 */     this.target = arc.target;
/*  78 */     if ((this.target.getArcs() == 1) && (!this.target.hasValue()) && (!this.target.isWildcard())) {
/*  79 */       merge(this.target.getFirstArc());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void pack()
/*     */   {
/*  87 */     if ((this.target.getArcs() == 1) && (!this.target.hasValue()) && (!this.target.isWildcard())) {
/*  88 */       merge(this.target.getFirstArc());
/*     */     }
/*  90 */     this.target.pack();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int length()
/*     */   {
/*  97 */     return this.code.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int match(CharSequence seq, int i)
/*     */   {
/* 104 */     if (i + this.code.length > seq.length()) return 0;
/* 105 */     for (int j = 0; j < this.code.length; j++) {
/* 106 */       if (this.code[j] != seq.charAt(i++)) return 0;
/*     */     }
/* 108 */     return this.code.length;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 112 */     if (this.target.hasValue()) {
/* 113 */       return "ARC(" + new String(this.code) + ") --> " + this.target.getPattern().getRegex();
/*     */     }
/*     */     
/* 116 */     return "ARC(" + new String(this.code) + ") --> null";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static char[] copyOf(char[] original, int newLength)
/*     */   {
/* 139 */     char[] copy = new char[newLength];
/* 140 */     System.arraycopy(original, 0, copy, 0, Math.min(original.length, newLength));
/*     */     
/* 142 */     return copy;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\uri\rules\automata\TrieArc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */