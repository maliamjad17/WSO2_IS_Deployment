package com.sun.jersey.spi.container;

import com.sun.jersey.api.model.AbstractResourceMethod;
import com.sun.jersey.spi.dispatch.RequestDispatcher;

public abstract interface ResourceMethodDispatchProvider
{
  public abstract RequestDispatcher create(AbstractResourceMethod paramAbstractResourceMethod);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\container\ResourceMethodDispatchProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */