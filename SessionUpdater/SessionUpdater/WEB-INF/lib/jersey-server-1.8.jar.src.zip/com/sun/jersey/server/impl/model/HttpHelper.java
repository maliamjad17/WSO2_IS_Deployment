/*     */ package com.sun.jersey.server.impl.model;
/*     */ 
/*     */ import com.sun.jersey.api.core.HttpRequestContext;
/*     */ import com.sun.jersey.core.header.AcceptableLanguageTag;
/*     */ import com.sun.jersey.core.header.AcceptableMediaType;
/*     */ import com.sun.jersey.core.header.AcceptableToken;
/*     */ import com.sun.jersey.core.header.LanguageTag;
/*     */ import com.sun.jersey.core.header.MatchingEntityTag;
/*     */ import com.sun.jersey.core.header.MediaTypes;
/*     */ import com.sun.jersey.core.header.QualitySourceMediaType;
/*     */ import com.sun.jersey.core.header.reader.HttpHeaderReader;
/*     */ import com.sun.jersey.impl.ImplMessages;
/*     */ import java.text.ParseException;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import javax.ws.rs.WebApplicationException;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.core.Response;
/*     */ import javax.ws.rs.core.Response.ResponseBuilder;
/*     */ import javax.ws.rs.core.Response.Status;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpHelper
/*     */ {
/*     */   public static MediaType getContentType(HttpRequestContext request)
/*     */   {
/*  77 */     return getContentType((String)request.getRequestHeaders().getFirst("Content-Type"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MediaType getContentType(String contentTypeString)
/*     */   {
/*     */     try
/*     */     {
/*  89 */       return contentTypeString != null ? MediaType.valueOf(contentTypeString) : null;
/*     */     } catch (IllegalArgumentException e) {
/*  91 */       throw clientError("Bad Content-Type header value: '" + contentTypeString + "'", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MediaType getContentType(Object contentType)
/*     */   {
/* 103 */     if (contentType == null) {
/* 104 */       return null;
/*     */     }
/* 106 */     if ((contentType instanceof MediaType)) {
/* 107 */       return (MediaType)contentType;
/*     */     }
/* 109 */     return MediaType.valueOf(contentType.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Locale getContentLanguageAsLocale(HttpRequestContext request)
/*     */   {
/* 119 */     return getLanguageTagAsLocale((String)request.getRequestHeaders().getFirst("Content-Language"));
/*     */   }
/*     */   
/*     */ 
/*     */   public static Locale getLanguageTagAsLocale(String language)
/*     */   {
/* 125 */     if (language == null) {
/* 126 */       return null;
/*     */     }
/*     */     try {
/* 129 */       return new LanguageTag(language).getAsLocale();
/*     */     } catch (ParseException e) {
/* 131 */       throw clientError("Bad Content-Language header value: '" + language + "'", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Set<MatchingEntityTag> getIfMatch(HttpRequestContext request) {
/* 136 */     String ifMatch = request.getHeaderValue("If-Match");
/* 137 */     if ((ifMatch == null) || (ifMatch.length() == 0)) {
/* 138 */       return null;
/*     */     }
/*     */     try {
/* 141 */       return HttpHeaderReader.readMatchingEntityTag(ifMatch);
/*     */     } catch (ParseException e) {
/* 143 */       throw clientError("Bad If-Match header value: '" + ifMatch + "'", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Set<MatchingEntityTag> getIfNoneMatch(HttpRequestContext request) {
/* 148 */     String ifNoneMatch = request.getHeaderValue("If-None-Match");
/* 149 */     if ((ifNoneMatch == null) || (ifNoneMatch.length() == 0)) {
/* 150 */       return null;
/*     */     }
/*     */     try {
/* 153 */       return HttpHeaderReader.readMatchingEntityTag(ifNoneMatch);
/*     */     } catch (ParseException e) {
/* 155 */       throw clientError("Bad If-None-Match header value: '" + ifNoneMatch + "'", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<AcceptableMediaType> getAccept(HttpRequestContext request)
/*     */   {
/* 170 */     String accept = request.getHeaderValue("Accept");
/* 171 */     if ((accept == null) || (accept.length() == 0)) {
/* 172 */       return MediaTypes.GENERAL_ACCEPT_MEDIA_TYPE_LIST;
/*     */     }
/*     */     try {
/* 175 */       return HttpHeaderReader.readAcceptMediaType(accept);
/*     */     } catch (ParseException e) {
/* 177 */       throw clientError(ImplMessages.BAD_ACCEPT_FIELD(accept), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public static List<AcceptableMediaType> getAccept(HttpRequestContext request, List<QualitySourceMediaType> priorityMediaTypes)
/*     */   {
/* 183 */     String accept = request.getHeaderValue("Accept");
/* 184 */     if ((accept == null) || (accept.length() == 0)) {
/* 185 */       return MediaTypes.GENERAL_ACCEPT_MEDIA_TYPE_LIST;
/*     */     }
/*     */     try {
/* 188 */       return HttpHeaderReader.readAcceptMediaType(accept, priorityMediaTypes);
/*     */     } catch (ParseException e) {
/* 190 */       throw clientError(ImplMessages.BAD_ACCEPT_FIELD(accept), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static List<AcceptableLanguageTag> getAcceptLangauge(HttpRequestContext request)
/*     */   {
/* 204 */     return getAcceptLanguage(request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<AcceptableLanguageTag> getAcceptLanguage(HttpRequestContext request)
/*     */   {
/* 215 */     String acceptLanguage = request.getHeaderValue("Accept-Language");
/* 216 */     if ((acceptLanguage == null) || (acceptLanguage.length() == 0)) {
/* 217 */       return Collections.singletonList(new AcceptableLanguageTag("*", null));
/*     */     }
/*     */     try {
/* 220 */       return HttpHeaderReader.readAcceptLanguage(acceptLanguage);
/*     */     } catch (ParseException e) {
/* 222 */       throw clientError("Bad Accept-Language header value: '" + acceptLanguage + "'", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<AcceptableToken> getAcceptCharset(HttpRequestContext request)
/*     */   {
/* 234 */     String acceptCharset = request.getHeaderValue("Accept-Charset");
/*     */     try {
/* 236 */       if ((acceptCharset == null) || (acceptCharset.length() == 0)) {
/* 237 */         return Collections.singletonList(new AcceptableToken("*"));
/*     */       }
/* 239 */       return HttpHeaderReader.readAcceptToken(acceptCharset);
/*     */     } catch (ParseException e) {
/* 241 */       throw clientError("Bad Accept-Charset header value: '" + acceptCharset + "'", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<AcceptableToken> getAcceptEncoding(HttpRequestContext request)
/*     */   {
/* 253 */     String acceptEncoding = request.getHeaderValue("Accept-Encoding");
/*     */     try {
/* 255 */       if ((acceptEncoding == null) || (acceptEncoding.length() == 0)) {
/* 256 */         return Collections.singletonList(new AcceptableToken("*"));
/*     */       }
/* 258 */       return HttpHeaderReader.readAcceptToken(acceptEncoding);
/*     */     } catch (ParseException e) {
/* 260 */       throw clientError("Bad Accept-Encoding header value: '" + acceptEncoding + "'", e);
/*     */     }
/*     */   }
/*     */   
/*     */   private static WebApplicationException clientError(String message, Exception e) {
/* 265 */     return new WebApplicationException(e, Response.status(Response.Status.BAD_REQUEST).entity(message).type("text/plain").build());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean produces(MediaType contentType, List<MediaType> accept)
/*     */   {
/* 280 */     for (MediaType a : accept) {
/* 281 */       if (a.getType().equals("*")) { return true;
/*     */       }
/* 283 */       if (contentType.isCompatible(a)) { return true;
/*     */       }
/*     */     }
/* 286 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\HttpHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */