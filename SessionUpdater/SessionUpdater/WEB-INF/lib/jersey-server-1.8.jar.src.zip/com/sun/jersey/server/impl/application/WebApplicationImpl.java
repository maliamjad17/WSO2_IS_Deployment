/*      */ package com.sun.jersey.server.impl.application;
/*      */ 
/*      */ import com.sun.jersey.api.NotFoundException;
/*      */ import com.sun.jersey.api.container.ContainerException;
/*      */ import com.sun.jersey.api.container.MappableContainerException;
/*      */ import com.sun.jersey.api.container.filter.UriConnegFilter;
/*      */ import com.sun.jersey.api.core.ExtendedUriInfo;
/*      */ import com.sun.jersey.api.core.HttpContext;
/*      */ import com.sun.jersey.api.core.InjectParam;
/*      */ import com.sun.jersey.api.core.ParentRef;
/*      */ import com.sun.jersey.api.core.ResourceConfig;
/*      */ import com.sun.jersey.api.core.ResourceConfigurator;
/*      */ import com.sun.jersey.api.core.ResourceContext;
/*      */ import com.sun.jersey.api.model.AbstractResource;
/*      */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*      */ import com.sun.jersey.api.model.AbstractResourceModelContext;
/*      */ import com.sun.jersey.api.model.AbstractResourceModelListener;
/*      */ import com.sun.jersey.api.model.AbstractSubResourceLocator;
/*      */ import com.sun.jersey.api.model.ResourceModelIssue;
/*      */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*      */ import com.sun.jersey.core.spi.component.ComponentContext;
/*      */ import com.sun.jersey.core.spi.component.ComponentScope;
/*      */ import com.sun.jersey.core.spi.component.ProviderFactory;
/*      */ import com.sun.jersey.core.spi.component.ProviderServices;
/*      */ import com.sun.jersey.core.spi.component.ioc.IoCComponentProcessor;
/*      */ import com.sun.jersey.core.spi.component.ioc.IoCComponentProcessorFactory;
/*      */ import com.sun.jersey.core.spi.component.ioc.IoCComponentProcessorFactoryInitializer;
/*      */ import com.sun.jersey.core.spi.component.ioc.IoCComponentProviderFactory;
/*      */ import com.sun.jersey.core.spi.component.ioc.IoCProviderFactory;
/*      */ import com.sun.jersey.core.spi.factory.ContextResolverFactory;
/*      */ import com.sun.jersey.core.spi.factory.MessageBodyFactory;
/*      */ import com.sun.jersey.core.util.FeaturesAndProperties;
/*      */ import com.sun.jersey.impl.ImplMessages;
/*      */ import com.sun.jersey.server.impl.BuildId;
/*      */ import com.sun.jersey.server.impl.ThreadLocalHttpContext;
/*      */ import com.sun.jersey.server.impl.component.IoCResourceFactory;
/*      */ import com.sun.jersey.server.impl.component.ResourceFactory;
/*      */ import com.sun.jersey.server.impl.container.filter.FilterFactory;
/*      */ import com.sun.jersey.server.impl.inject.ServerInjectableProviderContext;
/*      */ import com.sun.jersey.server.impl.inject.ServerInjectableProviderFactory;
/*      */ import com.sun.jersey.server.impl.model.ResourceUriRules;
/*      */ import com.sun.jersey.server.impl.model.RulesMap;
/*      */ import com.sun.jersey.server.impl.model.parameter.CookieParamInjectableProvider;
/*      */ import com.sun.jersey.server.impl.model.parameter.FormParamInjectableProvider;
/*      */ import com.sun.jersey.server.impl.model.parameter.HeaderParamInjectableProvider;
/*      */ import com.sun.jersey.server.impl.model.parameter.HttpContextInjectableProvider;
/*      */ import com.sun.jersey.server.impl.model.parameter.MatrixParamInjectableProvider;
/*      */ import com.sun.jersey.server.impl.model.parameter.PathParamInjectableProvider;
/*      */ import com.sun.jersey.server.impl.model.parameter.QueryParamInjectableProvider;
/*      */ import com.sun.jersey.server.impl.model.parameter.multivalued.MultivaluedParameterExtractorFactory;
/*      */ import com.sun.jersey.server.impl.model.parameter.multivalued.MultivaluedParameterExtractorProvider;
/*      */ import com.sun.jersey.server.impl.model.parameter.multivalued.StringReaderFactory;
/*      */ import com.sun.jersey.server.impl.modelapi.annotation.IntrospectionModeller;
/*      */ import com.sun.jersey.server.impl.modelapi.validation.BasicValidator;
/*      */ import com.sun.jersey.server.impl.monitoring.MonitoringProviderFactory;
/*      */ import com.sun.jersey.server.impl.resource.PerRequestFactory;
/*      */ import com.sun.jersey.server.impl.template.TemplateFactory;
/*      */ import com.sun.jersey.server.impl.uri.rules.RootResourceClassesRule;
/*      */ import com.sun.jersey.server.impl.wadl.WadlFactory;
/*      */ import com.sun.jersey.server.spi.component.ResourceComponentInjector;
/*      */ import com.sun.jersey.server.spi.component.ResourceComponentProvider;
/*      */ import com.sun.jersey.spi.MessageBodyWorkers;
/*      */ import com.sun.jersey.spi.StringReaderWorkers;
/*      */ import com.sun.jersey.spi.container.ContainerRequest;
/*      */ import com.sun.jersey.spi.container.ContainerRequestFilter;
/*      */ import com.sun.jersey.spi.container.ContainerResponse;
/*      */ import com.sun.jersey.spi.container.ContainerResponseFilter;
/*      */ import com.sun.jersey.spi.container.ContainerResponseWriter;
/*      */ import com.sun.jersey.spi.container.ExceptionMapperContext;
/*      */ import com.sun.jersey.spi.container.ResourceMethodCustomInvokerDispatchFactory;
/*      */ import com.sun.jersey.spi.container.ResourceMethodDispatchProvider;
/*      */ import com.sun.jersey.spi.container.WebApplication;
/*      */ import com.sun.jersey.spi.container.WebApplicationListener;
/*      */ import com.sun.jersey.spi.inject.Errors;
/*      */ import com.sun.jersey.spi.inject.Errors.Closure;
/*      */ import com.sun.jersey.spi.inject.Inject;
/*      */ import com.sun.jersey.spi.inject.Injectable;
/*      */ import com.sun.jersey.spi.inject.InjectableProvider;
/*      */ import com.sun.jersey.spi.inject.InjectableProviderContext;
/*      */ import com.sun.jersey.spi.inject.ServerSide;
/*      */ import com.sun.jersey.spi.inject.SingletonTypeInjectableProvider;
/*      */ import com.sun.jersey.spi.monitoring.DispatchingListener;
/*      */ import com.sun.jersey.spi.monitoring.RequestListener;
/*      */ import com.sun.jersey.spi.monitoring.ResponseListener;
/*      */ import com.sun.jersey.spi.service.ServiceFinder;
/*      */ import com.sun.jersey.spi.template.TemplateContext;
/*      */ import com.sun.jersey.spi.uri.rules.UriRule;
/*      */ import com.sun.jersey.spi.uri.rules.UriRules;
/*      */ import java.io.IOException;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.reflect.InvocationHandler;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.ParameterizedType;
/*      */ import java.lang.reflect.Proxy;
/*      */ import java.lang.reflect.Type;
/*      */ import java.net.URI;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import javax.ws.rs.WebApplicationException;
/*      */ import javax.ws.rs.core.Application;
/*      */ import javax.ws.rs.core.Context;
/*      */ import javax.ws.rs.core.HttpHeaders;
/*      */ import javax.ws.rs.core.MediaType;
/*      */ import javax.ws.rs.core.Request;
/*      */ import javax.ws.rs.core.Response;
/*      */ import javax.ws.rs.core.SecurityContext;
/*      */ import javax.ws.rs.core.UriInfo;
/*      */ import javax.ws.rs.ext.ContextResolver;
/*      */ import javax.ws.rs.ext.ExceptionMapper;
/*      */ import javax.ws.rs.ext.MessageBodyReader;
/*      */ import javax.ws.rs.ext.MessageBodyWriter;
/*      */ import javax.ws.rs.ext.Providers;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class WebApplicationImpl
/*      */   implements WebApplication
/*      */ {
/*  171 */   private static final Logger LOGGER = Logger.getLogger(WebApplicationImpl.class.getName());
/*      */   
/*  173 */   private final Map<Class, AbstractResource> abstractResourceMap = new HashMap();
/*      */   
/*      */ 
/*  176 */   private final ConcurrentMap<Class, UriRules<UriRule>> rulesMap = new ConcurrentHashMap();
/*      */   
/*      */ 
/*  179 */   private final ConcurrentMap<Class, ResourceComponentProvider> providerMap = new ConcurrentHashMap();
/*      */   
/*      */   private static class ClassAnnotationKey
/*      */   {
/*      */     private final Class c;
/*      */     private final Set<Annotation> as;
/*      */     
/*      */     public ClassAnnotationKey(Class c, Annotation[] as)
/*      */     {
/*  188 */       this.c = c;
/*  189 */       this.as = new HashSet(Arrays.asList(as));
/*      */     }
/*      */     
/*      */     public int hashCode()
/*      */     {
/*  194 */       int hash = 5;
/*  195 */       hash = 67 * hash + (this.c != null ? this.c.hashCode() : 0);
/*  196 */       hash = 67 * hash + (this.as != null ? this.as.hashCode() : 0);
/*  197 */       return hash;
/*      */     }
/*      */     
/*      */     public boolean equals(Object obj)
/*      */     {
/*  202 */       if (obj == null) {
/*  203 */         return false;
/*      */       }
/*  205 */       if (getClass() != obj.getClass()) {
/*  206 */         return false;
/*      */       }
/*  208 */       ClassAnnotationKey other = (ClassAnnotationKey)obj;
/*  209 */       if ((this.c != other.c) && ((this.c == null) || (!this.c.equals(other.c)))) {
/*  210 */         return false;
/*      */       }
/*  212 */       if ((this.as != other.as) && ((this.as == null) || (!this.as.equals(other.as)))) {
/*  213 */         return false;
/*      */       }
/*  215 */       return true;
/*      */     }
/*      */   }
/*      */   
/*  219 */   private final ConcurrentMap<ClassAnnotationKey, ResourceComponentProvider> providerWithAnnotationKeyMap = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */   private final ThreadLocalHttpContext context;
/*      */   
/*      */   private final CloseableServiceFactory closeableFactory;
/*      */   
/*      */   private boolean initiated;
/*      */   
/*      */   private ResourceConfig resourceConfig;
/*      */   
/*      */   private RootResourceClassesRule rootsRule;
/*      */   
/*      */   private ServerInjectableProviderFactory injectableFactory;
/*      */   
/*      */   private ProviderFactory cpFactory;
/*      */   
/*      */   private ResourceFactory rcpFactory;
/*      */   
/*      */   private IoCComponentProviderFactory provider;
/*      */   
/*      */   private List<IoCComponentProviderFactory> providerFactories;
/*      */   
/*      */   private Providers providers;
/*      */   
/*      */   private MessageBodyFactory bodyFactory;
/*      */   
/*      */   private StringReaderFactory stringReaderFactory;
/*      */   
/*      */   private TemplateContext templateContext;
/*      */   
/*      */   private ExceptionMapperFactory exceptionFactory;
/*      */   
/*      */   private ResourceMethodDispatchProvider dispatcherFactory;
/*      */   
/*      */   private ResourceContext resourceContext;
/*      */   
/*      */   private Set<AbstractResource> abstractRootResources;
/*      */   
/*      */   private Map<String, AbstractResource> explicitAbstractRootResources;
/*      */   
/*  260 */   private final AbstractResourceModelContext armContext = new AbstractResourceModelContext()
/*      */   {
/*      */     public Set<AbstractResource> getAbstractRootResources()
/*      */     {
/*  264 */       return WebApplicationImpl.this.abstractRootResources;
/*      */     }
/*      */   };
/*      */   
/*      */   private FilterFactory filterFactory;
/*      */   
/*      */   private WadlFactory wadlFactory;
/*      */   
/*      */   private boolean isTraceEnabled;
/*      */   
/*      */   private RequestListener requestListener;
/*      */   
/*      */   private DispatchingListenerProxy dispatchingListener;
/*      */   private ResponseListener responseListener;
/*      */   
/*      */   public WebApplicationImpl()
/*      */   {
/*  281 */     this.context = new ThreadLocalHttpContext();
/*      */     
/*  283 */     InvocationHandler requestHandler = new InvocationHandler()
/*      */     {
/*      */       public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*      */         try {
/*  287 */           return method.invoke(WebApplicationImpl.this.context.getRequest(), args);
/*      */         } catch (IllegalAccessException ex) {
/*  289 */           throw new IllegalStateException(ex);
/*      */         } catch (InvocationTargetException ex) {
/*  291 */           throw ex.getTargetException();
/*      */         }
/*      */       }
/*  294 */     };
/*  295 */     InvocationHandler uriInfoHandler = new InvocationHandler()
/*      */     {
/*      */       public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*      */         try {
/*  299 */           return method.invoke(WebApplicationImpl.this.context.getUriInfo(), args);
/*      */         } catch (IllegalAccessException ex) {
/*  301 */           throw new IllegalStateException(ex);
/*      */         } catch (InvocationTargetException ex) {
/*  303 */           throw ex.getTargetException();
/*      */         }
/*      */         
/*      */       }
/*      */       
/*  308 */     };
/*  309 */     this.injectableFactory = new ServerInjectableProviderFactory();
/*  310 */     this.injectableFactory.add(new ContextInjectableProvider(InjectableProviderContext.class, this.injectableFactory));
/*      */     
/*  312 */     this.injectableFactory.add(new ContextInjectableProvider(ServerInjectableProviderContext.class, this.injectableFactory));
/*      */     
/*      */ 
/*      */ 
/*  316 */     final Map<Type, Object> m = new HashMap();
/*  317 */     m.put(HttpContext.class, this.context);
/*  318 */     m.put(HttpHeaders.class, createProxy(HttpHeaders.class, requestHandler));
/*  319 */     m.put(UriInfo.class, createProxy(UriInfo.class, uriInfoHandler));
/*  320 */     m.put(ExtendedUriInfo.class, createProxy(ExtendedUriInfo.class, uriInfoHandler));
/*  321 */     m.put(Request.class, createProxy(Request.class, requestHandler));
/*  322 */     m.put(SecurityContext.class, createProxy(SecurityContext.class, requestHandler));
/*  323 */     this.injectableFactory.add(new InjectableProvider()
/*      */     {
/*      */       public ComponentScope getScope() {
/*  326 */         return ComponentScope.Singleton;
/*      */       }
/*      */       
/*      */       public Injectable getInjectable(ComponentContext ic, Context a, Type c)
/*      */       {
/*  331 */         final Object o = m.get(c);
/*  332 */         if (o != null) {
/*  333 */           new Injectable()
/*      */           {
/*      */             public Object getValue() {
/*  336 */               return o;
/*      */             }
/*      */           };
/*      */         }
/*  340 */         return null;
/*      */       }
/*      */       
/*  343 */     });
/*  344 */     this.injectableFactory.add(new InjectableProvider()
/*      */     {
/*      */       public ComponentScope getScope() {
/*  347 */         return ComponentScope.Singleton;
/*      */       }
/*      */       
/*      */       public Injectable<Injectable> getInjectable(ComponentContext ic, Context a, Type c)
/*      */       {
/*  352 */         if ((c instanceof ParameterizedType)) {
/*  353 */           ParameterizedType pt = (ParameterizedType)c;
/*  354 */           if ((pt.getRawType() == Injectable.class) && 
/*  355 */             (pt.getActualTypeArguments().length == 1)) {
/*  356 */             final Injectable<?> i = WebApplicationImpl.this.injectableFactory.getInjectable(a.annotationType(), ic, a, pt.getActualTypeArguments()[0], ComponentScope.PERREQUEST_UNDEFINED_SINGLETON);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  362 */             if (i == null)
/*  363 */               return null;
/*  364 */             new Injectable()
/*      */             {
/*      */               public Injectable getValue() {
/*  367 */                 return i;
/*      */               }
/*      */             };
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*  374 */         return null;
/*      */       }
/*      */       
/*  377 */     });
/*  378 */     this.injectableFactory.add(new InjectableProvider()
/*      */     {
/*      */       public ComponentScope getScope() {
/*  381 */         return ComponentScope.Singleton;
/*      */       }
/*      */       
/*      */       public Injectable<Injectable> getInjectable(ComponentContext ic, Inject a, Type c)
/*      */       {
/*  386 */         if ((c instanceof ParameterizedType)) {
/*  387 */           ParameterizedType pt = (ParameterizedType)c;
/*  388 */           if ((pt.getRawType() == Injectable.class) && 
/*  389 */             (pt.getActualTypeArguments().length == 1)) {
/*  390 */             final Injectable<?> i = WebApplicationImpl.this.injectableFactory.getInjectable(a.annotationType(), ic, a, pt.getActualTypeArguments()[0], ComponentScope.PERREQUEST_UNDEFINED_SINGLETON);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  396 */             if (i == null)
/*  397 */               return null;
/*  398 */             new Injectable()
/*      */             {
/*      */               public Injectable getValue() {
/*  401 */                 return i;
/*      */               }
/*      */             };
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*  408 */         return null;
/*      */       }
/*      */       
/*  411 */     });
/*  412 */     this.injectableFactory.add(new InjectableProvider()
/*      */     {
/*      */       public ComponentScope getScope() {
/*  415 */         return ComponentScope.Singleton;
/*      */       }
/*      */       
/*      */       public Injectable<Injectable> getInjectable(ComponentContext ic, InjectParam a, Type c)
/*      */       {
/*  420 */         if ((c instanceof ParameterizedType)) {
/*  421 */           ParameterizedType pt = (ParameterizedType)c;
/*  422 */           if ((pt.getRawType() == Injectable.class) && 
/*  423 */             (pt.getActualTypeArguments().length == 1)) {
/*  424 */             final Injectable<?> i = WebApplicationImpl.this.injectableFactory.getInjectable(a.annotationType(), ic, a, pt.getActualTypeArguments()[0], ComponentScope.PERREQUEST_UNDEFINED_SINGLETON);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  430 */             if (i == null)
/*  431 */               return null;
/*  432 */             new Injectable()
/*      */             {
/*      */               public Injectable getValue() {
/*  435 */                 return i;
/*      */               }
/*      */             };
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*  442 */         return null;
/*      */       }
/*      */       
/*  445 */     });
/*  446 */     this.closeableFactory = new CloseableServiceFactory(this.context);
/*  447 */     this.injectableFactory.add(this.closeableFactory);
/*      */   }
/*      */   
/*      */   private class ComponentProcessorImpl implements IoCComponentProcessor {
/*      */     private final ResourceComponentInjector rci;
/*      */     
/*      */     ComponentProcessorImpl(ResourceComponentInjector rci) {
/*  454 */       this.rci = rci;
/*      */     }
/*      */     
/*      */ 
/*      */     public void preConstruct() {}
/*      */     
/*      */ 
/*      */     public void postConstruct(Object o)
/*      */     {
/*  463 */       this.rci.inject(WebApplicationImpl.this.context.get(), o);
/*      */     }
/*      */   }
/*      */   
/*  467 */   private static final IoCComponentProcessor NULL_COMPONENT_PROCESSOR = new IoCComponentProcessor()
/*      */   {
/*      */     public void preConstruct() {}
/*      */     
/*      */ 
/*      */     public void postConstruct(Object o) {}
/*      */   };
/*      */   
/*      */   private class ComponentProcessorFactoryImpl
/*      */     implements IoCComponentProcessorFactory
/*      */   {
/*  478 */     private final ConcurrentMap<Class, IoCComponentProcessor> componentProcessorMap = new ConcurrentHashMap();
/*      */     
/*      */     private ComponentProcessorFactoryImpl() {}
/*      */     
/*      */     public ComponentScope getScope(Class c) {
/*  483 */       return WebApplicationImpl.this.rcpFactory.getScope(c);
/*      */     }
/*      */     
/*      */     public IoCComponentProcessor get(final Class c, final ComponentScope scope)
/*      */     {
/*  488 */       IoCComponentProcessor cp = (IoCComponentProcessor)this.componentProcessorMap.get(c);
/*  489 */       if (cp != null) {
/*  490 */         return cp == WebApplicationImpl.NULL_COMPONENT_PROCESSOR ? null : cp;
/*      */       }
/*      */       
/*  493 */       synchronized (WebApplicationImpl.this.abstractResourceMap) {
/*  494 */         cp = (IoCComponentProcessor)this.componentProcessorMap.get(c);
/*  495 */         if (cp != null) {
/*  496 */           return cp == WebApplicationImpl.NULL_COMPONENT_PROCESSOR ? null : cp;
/*      */         }
/*      */         
/*  499 */         ResourceComponentInjector rci = (ResourceComponentInjector)Errors.processWithErrors(new Errors.Closure()
/*      */         {
/*      */           public ResourceComponentInjector f() {
/*  502 */             return new ResourceComponentInjector(WebApplicationImpl.this.injectableFactory, scope, WebApplicationImpl.this.getAbstractResource(c));
/*      */           }
/*      */         });
/*      */         
/*      */ 
/*  507 */         if (rci.hasInjectableArtifacts()) {
/*  508 */           cp = new WebApplicationImpl.ComponentProcessorImpl(WebApplicationImpl.this, rci);
/*  509 */           this.componentProcessorMap.put(c, cp);
/*      */         } else {
/*  511 */           cp = null;
/*  512 */           this.componentProcessorMap.put(c, WebApplicationImpl.NULL_COMPONENT_PROCESSOR);
/*      */         }
/*      */       }
/*  515 */       return cp;
/*      */     }
/*      */   }
/*      */   
/*      */   public FeaturesAndProperties getFeaturesAndProperties()
/*      */   {
/*  521 */     return this.resourceConfig;
/*      */   }
/*      */   
/*      */   public WebApplication clone()
/*      */   {
/*  526 */     WebApplicationImpl wa = new WebApplicationImpl();
/*  527 */     wa.initiate(this.resourceConfig, this.provider);
/*  528 */     return wa;
/*      */   }
/*      */   
/*      */   UriRules<UriRule> getUriRules(final Class c) {
/*  532 */     assert (c != null);
/*      */     
/*      */ 
/*  535 */     UriRules<UriRule> r = (UriRules)this.rulesMap.get(c);
/*  536 */     if (r != null) {
/*  537 */       return r;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  542 */     synchronized (this.abstractResourceMap)
/*      */     {
/*      */ 
/*  545 */       r = (UriRules)this.rulesMap.get(c);
/*  546 */       if (r != null) {
/*  547 */         return r;
/*      */       }
/*      */       
/*  550 */       r = ((ResourceUriRules)Errors.processWithErrors(new Errors.Closure()
/*      */       {
/*      */         public ResourceUriRules f() {
/*  553 */           return WebApplicationImpl.this.newResourceUriRules(WebApplicationImpl.this.getAbstractResource(c));
/*      */         }
/*  555 */       })).getRules();
/*  556 */       this.rulesMap.put(c, r);
/*      */     }
/*  558 */     return r;
/*      */   }
/*      */   
/*      */   ResourceComponentProvider getResourceComponentProvider(final Class c) {
/*  562 */     assert (c != null);
/*      */     
/*      */ 
/*  565 */     ResourceComponentProvider rcp = (ResourceComponentProvider)this.providerMap.get(c);
/*  566 */     if (rcp != null) {
/*  567 */       return rcp;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  572 */     synchronized (this.abstractResourceMap)
/*      */     {
/*      */ 
/*  575 */       rcp = (ResourceComponentProvider)this.providerMap.get(c);
/*  576 */       if (rcp != null) {
/*  577 */         return rcp;
/*      */       }
/*      */       
/*  580 */       final ResourceComponentProvider _rcp = rcp = this.rcpFactory.getComponentProvider(null, c);
/*  581 */       Errors.processWithErrors(new Errors.Closure()
/*      */       {
/*      */         public Void f() {
/*  584 */           _rcp.init(WebApplicationImpl.this.getAbstractResource(c));
/*  585 */           return null;
/*      */         }
/*      */         
/*  588 */       });
/*  589 */       this.providerMap.put(c, rcp);
/*      */     }
/*  591 */     return rcp;
/*      */   }
/*      */   
/*      */   ResourceComponentProvider getResourceComponentProvider(ComponentContext cc, final Class c) {
/*  595 */     assert (c != null);
/*      */     
/*  597 */     if ((cc == null) || (cc.getAnnotations().length == 0)) {
/*  598 */       return getResourceComponentProvider(c);
/*      */     }
/*  600 */     if (cc.getAnnotations().length == 1) {
/*  601 */       Annotation a = cc.getAnnotations()[0];
/*  602 */       if (a.annotationType() == Inject.class) {
/*  603 */         Inject i = (Inject)Inject.class.cast(a);
/*  604 */         String value = i.value() != null ? i.value().trim() : "";
/*      */         
/*      */ 
/*  607 */         if (value.isEmpty())
/*  608 */           return getResourceComponentProvider(c);
/*  609 */       } else if (a.annotationType() == InjectParam.class) {
/*  610 */         InjectParam i = (InjectParam)InjectParam.class.cast(a);
/*  611 */         String value = i.value() != null ? i.value().trim() : "";
/*      */         
/*      */ 
/*  614 */         if (value.isEmpty()) {
/*  615 */           return getResourceComponentProvider(c);
/*      */         }
/*      */       }
/*      */     }
/*  619 */     ClassAnnotationKey cak = new ClassAnnotationKey(c, cc.getAnnotations());
/*      */     
/*      */ 
/*      */ 
/*  623 */     ResourceComponentProvider rcp = (ResourceComponentProvider)this.providerWithAnnotationKeyMap.get(cak);
/*  624 */     if (rcp != null) {
/*  625 */       return rcp;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  630 */     synchronized (this.abstractResourceMap)
/*      */     {
/*      */ 
/*  633 */       rcp = (ResourceComponentProvider)this.providerWithAnnotationKeyMap.get(cak);
/*  634 */       if (rcp != null) {
/*  635 */         return rcp;
/*      */       }
/*      */       
/*  638 */       final ResourceComponentProvider _rcp = rcp = this.rcpFactory.getComponentProvider(cc, c);
/*  639 */       Errors.processWithErrors(new Errors.Closure()
/*      */       {
/*      */         public Void f() {
/*  642 */           _rcp.init(WebApplicationImpl.this.getAbstractResource(c));
/*  643 */           return null;
/*      */         }
/*      */         
/*  646 */       });
/*  647 */       this.providerWithAnnotationKeyMap.put(cak, rcp);
/*      */     }
/*  649 */     return rcp;
/*      */   }
/*      */   
/*      */   void initiateResource(AbstractResource ar) {
/*  653 */     initiateResource(ar.getResourceClass());
/*      */   }
/*      */   
/*      */   void initiateResource(Class c) {
/*  657 */     getUriRules(c);
/*  658 */     getResourceComponentProvider(c);
/*      */   }
/*      */   
/*      */   void initiateResource(AbstractResource ar, final Object resource) {
/*  662 */     Class c = ar.getResourceClass();
/*  663 */     getUriRules(c);
/*      */     
/*  665 */     if (!this.providerMap.containsKey(c)) {
/*  666 */       this.providerMap.put(c, new ResourceComponentProvider()
/*      */       {
/*      */         public void init(AbstractResource abstractResource) {}
/*      */         
/*      */ 
/*      */         public ComponentScope getScope()
/*      */         {
/*  673 */           return ComponentScope.Singleton;
/*      */         }
/*      */         
/*      */         public Object getInstance(HttpContext hc)
/*      */         {
/*  678 */           return getInstance();
/*      */         }
/*      */         
/*      */ 
/*      */         public void destroy() {}
/*      */         
/*      */ 
/*      */         public Object getInstance()
/*      */         {
/*  687 */           return resource;
/*      */         }
/*      */       });
/*      */     }
/*      */   }
/*      */   
/*      */   Set<AbstractResource> getAbstractRootResources() {
/*  694 */     return this.abstractRootResources;
/*      */   }
/*      */   
/*      */   Map<String, AbstractResource> getExplicitAbstractRootResources() {
/*  698 */     return this.explicitAbstractRootResources;
/*      */   }
/*      */   
/*      */   private ResourceUriRules newResourceUriRules(AbstractResource ar) {
/*  702 */     assert (null != ar);
/*      */     
/*  704 */     BasicValidator validator = new BasicValidator();
/*  705 */     validator.validate(ar);
/*  706 */     for (ResourceModelIssue issue : validator.getIssueList()) {
/*  707 */       Errors.error(issue.getMessage(), issue.isFatal());
/*      */     }
/*  709 */     return new ResourceUriRules(this.resourceConfig, getDispatchProvider(), this.injectableFactory, this.filterFactory, this.wadlFactory, this.dispatchingListener, ar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ResourceMethodDispatchProvider getDispatchProvider()
/*      */   {
/*  720 */     return this.dispatcherFactory;
/*      */   }
/*      */   
/*      */   public RequestListener getRequestListener()
/*      */   {
/*  725 */     return this.requestListener;
/*      */   }
/*      */   
/*      */   public DispatchingListener getDispatchingListener()
/*      */   {
/*  730 */     return this.dispatchingListener;
/*      */   }
/*      */   
/*      */   public ResponseListener getResponseListener()
/*      */   {
/*  735 */     return this.responseListener;
/*      */   }
/*      */   
/*      */   AbstractResource getAbstractResource(Object o) {
/*  739 */     return getAbstractResource(o.getClass());
/*      */   }
/*      */   
/*      */   AbstractResource getAbstractResource(Class c) {
/*  743 */     AbstractResource ar = (AbstractResource)this.abstractResourceMap.get(c);
/*  744 */     if (ar == null) {
/*  745 */       ar = IntrospectionModeller.createResource(c);
/*  746 */       this.abstractResourceMap.put(c, ar);
/*      */     }
/*      */     
/*  749 */     return ar;
/*      */   }
/*      */   
/*      */   private static class ContextInjectableProvider<T> extends SingletonTypeInjectableProvider<Context, T>
/*      */   {
/*      */     ContextInjectableProvider(Type type, T instance) {
/*  755 */       super(instance);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isInitiated()
/*      */   {
/*  761 */     return this.initiated;
/*      */   }
/*      */   
/*      */   public void initiate(ResourceConfig resourceConfig)
/*      */   {
/*  766 */     initiate(resourceConfig, null);
/*      */   }
/*      */   
/*      */   public void initiate(final ResourceConfig rc, final IoCComponentProviderFactory _provider)
/*      */   {
/*  771 */     Errors.processWithErrors(new Errors.Closure()
/*      */     {
/*      */       public Void f() {
/*  774 */         Errors.setReportMissingDependentFieldOrMethod(false);
/*  775 */         WebApplicationImpl.this._initiate(rc, _provider);
/*  776 */         return null;
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */   private void _initiate(ResourceConfig rc, IoCComponentProviderFactory _provider) {
/*  782 */     if (rc == null) {
/*  783 */       throw new IllegalArgumentException("ResourceConfig instance MUST NOT be null");
/*      */     }
/*      */     
/*  786 */     if (this.initiated) {
/*  787 */       throw new ContainerException(ImplMessages.WEB_APP_ALREADY_INITIATED());
/*      */     }
/*  789 */     this.initiated = true;
/*      */     
/*  791 */     LOGGER.info("Initiating Jersey application, version '" + BuildId.getBuildId() + "'");
/*      */     
/*      */ 
/*      */ 
/*  795 */     Class<?>[] components = ServiceFinder.find("jersey-server-components").toClassArray();
/*  796 */     if (components.length > 0) {
/*  797 */       if (LOGGER.isLoggable(Level.INFO)) {
/*  798 */         StringBuilder b = new StringBuilder();
/*  799 */         b.append("Adding the following classes declared in META-INF/services/jersey-server-components to the resource configuration:");
/*  800 */         for (Class c : components)
/*  801 */           b.append('\n').append("  ").append(c);
/*  802 */         LOGGER.log(Level.INFO, b.toString());
/*      */       }
/*      */       
/*  805 */       this.resourceConfig = rc.clone();
/*  806 */       this.resourceConfig.getClasses().addAll(Arrays.asList(components));
/*      */     } else {
/*  808 */       this.resourceConfig = rc;
/*      */     }
/*      */     
/*  811 */     this.provider = _provider;
/*      */     
/*  813 */     this.providerFactories = new ArrayList(2);
/*      */     
/*  815 */     for (Object o : this.resourceConfig.getProviderSingletons()) {
/*  816 */       if ((o instanceof IoCComponentProviderFactory)) {
/*  817 */         this.providerFactories.add((IoCComponentProviderFactory)o);
/*      */       }
/*      */     }
/*      */     
/*  821 */     if (_provider != null) {
/*  822 */       this.providerFactories.add(_provider);
/*      */     }
/*      */     
/*      */ 
/*  826 */     this.cpFactory = (this.providerFactories.isEmpty() ? new ProviderFactory(this.injectableFactory) : new IoCProviderFactory(this.injectableFactory, this.providerFactories));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  831 */     this.rcpFactory = (this.providerFactories.isEmpty() ? new ResourceFactory(this.resourceConfig, this.injectableFactory) : new IoCResourceFactory(this.resourceConfig, this.injectableFactory, this.providerFactories));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  836 */     for (IoCComponentProviderFactory f : this.providerFactories)
/*      */     {
/*  838 */       if ((f instanceof IoCComponentProcessorFactoryInitializer)) {
/*  839 */         IoCComponentProcessorFactory cpf = new ComponentProcessorFactoryImpl(null);
/*  840 */         IoCComponentProcessorFactoryInitializer i = (IoCComponentProcessorFactoryInitializer)f;
/*  841 */         i.init(cpf);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  846 */     this.resourceContext = new ResourceContext()
/*      */     {
/*      */       public ExtendedUriInfo matchUriInfo(URI u) throws ContainerException {
/*      */         try {
/*  850 */           return WebApplicationImpl.this.handleMatchResourceRequest(u);
/*      */         } catch (ContainerException ex) {
/*  852 */           throw ex;
/*      */         } catch (WebApplicationException ex) {
/*  854 */           if (ex.getResponse().getStatus() == 404) {
/*  855 */             return null;
/*      */           }
/*  857 */           throw new ContainerException(ex);
/*      */         }
/*      */         catch (RuntimeException ex) {
/*  860 */           throw new ContainerException(ex);
/*      */         }
/*      */       }
/*      */       
/*      */       public Object matchResource(URI u) throws ContainerException
/*      */       {
/*  866 */         ExtendedUriInfo ui = matchUriInfo(u);
/*  867 */         return ui != null ? ui.getMatchedResources().get(0) : null;
/*      */       }
/*      */       
/*      */       public <T> T matchResource(URI u, Class<T> c) throws ContainerException, ClassCastException
/*      */       {
/*  872 */         return (T)c.cast(matchResource(u));
/*      */       }
/*      */       
/*      */       public <T> T getResource(Class<T> c)
/*      */       {
/*  877 */         return (T)c.cast(WebApplicationImpl.this.getResourceComponentProvider(c).getInstance(WebApplicationImpl.this.context));
/*      */       }
/*      */       
/*  880 */     };
/*  881 */     ProviderServices providerServices = new ProviderServices(ServerSide.class, this.cpFactory, this.resourceConfig.getProviderClasses(), this.resourceConfig.getProviderSingletons());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  887 */     this.injectableFactory.add(new ContextInjectableProvider(ProviderServices.class, providerServices));
/*      */     
/*      */ 
/*  890 */     this.injectableFactory.add(new ContextInjectableProvider(ResourceMethodCustomInvokerDispatchFactory.class, new ResourceMethodCustomInvokerDispatchFactory(providerServices)));
/*      */     
/*      */ 
/*      */ 
/*  894 */     this.injectableFactory.add(new InjectableProvider()
/*      */     {
/*      */       public ComponentScope getScope()
/*      */       {
/*  898 */         return ComponentScope.PerRequest;
/*      */       }
/*      */       
/*      */       public Injectable<Object> getInjectable(ComponentContext cc, ParentRef a, Type t)
/*      */       {
/*  903 */         if (!(t instanceof Class)) {
/*  904 */           return null;
/*      */         }
/*  906 */         final Class target = ReflectionHelper.getDeclaringClass(cc.getAccesibleObject());
/*  907 */         final Class inject = (Class)t;
/*  908 */         new Injectable()
/*      */         {
/*      */           public Object getValue() {
/*  911 */             UriInfo ui = WebApplicationImpl.this.context.getUriInfo();
/*  912 */             List l = ui.getMatchedResources();
/*      */             
/*  914 */             Object parent = getParent(l, target);
/*  915 */             if (parent == null) return null;
/*      */             try {
/*  917 */               return inject.cast(parent);
/*      */             } catch (ClassCastException ex) {
/*  919 */               throw new ContainerException("The parent resource is expected to be of class " + inject.getName() + " but is of class " + parent.getClass().getName(), ex);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */           private Object getParent(List l, Class target)
/*      */           {
/*  927 */             if (l.isEmpty())
/*  928 */               return null;
/*  929 */             if (l.size() == 1) {
/*  930 */               return l.get(0).getClass() == target ? null : l.get(0);
/*      */             }
/*  932 */             return l.get(0).getClass() == target ? l.get(1) : l.get(0);
/*      */ 
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */         };
/*      */       }
/*      */       
/*      */ 
/*  942 */     });
/*  943 */     this.injectableFactory.add(new InjectableProvider()
/*      */     {
/*      */       public ComponentScope getScope()
/*      */       {
/*  947 */         return ComponentScope.PerRequest;
/*      */       }
/*      */       
/*      */       public Injectable<Object> getInjectable(ComponentContext cc, Inject a, Type t)
/*      */       {
/*  952 */         if (!(t instanceof Class)) {
/*  953 */           return null;
/*      */         }
/*  955 */         final ResourceComponentProvider rcp = WebApplicationImpl.this.getResourceComponentProvider(cc, (Class)t);
/*      */         
/*  957 */         new Injectable()
/*      */         {
/*      */           public Object getValue() {
/*  960 */             return rcp.getInstance(WebApplicationImpl.this.context);
/*      */           }
/*      */           
/*      */ 
/*      */         };
/*      */       }
/*  966 */     });
/*  967 */     this.injectableFactory.add(new InjectableProvider()
/*      */     {
/*      */       public ComponentScope getScope()
/*      */       {
/*  971 */         return ComponentScope.Undefined;
/*      */       }
/*      */       
/*      */       public Injectable<Object> getInjectable(ComponentContext cc, Inject a, Type t)
/*      */       {
/*  976 */         if (!(t instanceof Class)) {
/*  977 */           return null;
/*      */         }
/*  979 */         final ResourceComponentProvider rcp = WebApplicationImpl.this.getResourceComponentProvider(cc, (Class)t);
/*  980 */         if (rcp.getScope() == ComponentScope.PerRequest) {
/*  981 */           return null;
/*      */         }
/*  983 */         new Injectable()
/*      */         {
/*      */           public Object getValue() {
/*  986 */             return rcp.getInstance(WebApplicationImpl.this.context);
/*      */           }
/*      */           
/*      */ 
/*      */         };
/*      */       }
/*  992 */     });
/*  993 */     this.injectableFactory.add(new InjectableProvider()
/*      */     {
/*      */       public ComponentScope getScope()
/*      */       {
/*  997 */         return ComponentScope.Singleton;
/*      */       }
/*      */       
/*      */       public Injectable<Object> getInjectable(ComponentContext cc, Inject a, Type t)
/*      */       {
/* 1002 */         if (!(t instanceof Class)) {
/* 1003 */           return null;
/*      */         }
/* 1005 */         final ResourceComponentProvider rcp = WebApplicationImpl.this.getResourceComponentProvider(cc, (Class)t);
/* 1006 */         if (rcp.getScope() != ComponentScope.Singleton) {
/* 1007 */           return null;
/*      */         }
/* 1009 */         new Injectable()
/*      */         {
/*      */           public Object getValue() {
/* 1012 */             return rcp.getInstance(WebApplicationImpl.this.context);
/*      */           }
/*      */           
/*      */ 
/*      */         };
/*      */       }
/*      */       
/*      */ 
/* 1020 */     });
/* 1021 */     this.injectableFactory.add(new InjectableProvider()
/*      */     {
/*      */       public ComponentScope getScope()
/*      */       {
/* 1025 */         return ComponentScope.PerRequest;
/*      */       }
/*      */       
/*      */       public Injectable<Object> getInjectable(ComponentContext cc, InjectParam a, Type t)
/*      */       {
/* 1030 */         if (!(t instanceof Class)) {
/* 1031 */           return null;
/*      */         }
/* 1033 */         final ResourceComponentProvider rcp = WebApplicationImpl.this.getResourceComponentProvider(cc, (Class)t);
/*      */         
/* 1035 */         new Injectable()
/*      */         {
/*      */           public Object getValue() {
/* 1038 */             return rcp.getInstance(WebApplicationImpl.this.context);
/*      */           }
/*      */           
/*      */ 
/*      */         };
/*      */       }
/* 1044 */     });
/* 1045 */     this.injectableFactory.add(new InjectableProvider()
/*      */     {
/*      */       public ComponentScope getScope()
/*      */       {
/* 1049 */         return ComponentScope.Undefined;
/*      */       }
/*      */       
/*      */       public Injectable<Object> getInjectable(ComponentContext cc, InjectParam a, Type t)
/*      */       {
/* 1054 */         if (!(t instanceof Class)) {
/* 1055 */           return null;
/*      */         }
/* 1057 */         final ResourceComponentProvider rcp = WebApplicationImpl.this.getResourceComponentProvider(cc, (Class)t);
/* 1058 */         if (rcp.getScope() == ComponentScope.PerRequest) {
/* 1059 */           return null;
/*      */         }
/* 1061 */         new Injectable()
/*      */         {
/*      */           public Object getValue() {
/* 1064 */             return rcp.getInstance(WebApplicationImpl.this.context);
/*      */           }
/*      */           
/*      */ 
/*      */         };
/*      */       }
/* 1070 */     });
/* 1071 */     this.injectableFactory.add(new InjectableProvider()
/*      */     {
/*      */       public ComponentScope getScope()
/*      */       {
/* 1075 */         return ComponentScope.Singleton;
/*      */       }
/*      */       
/*      */       public Injectable<Object> getInjectable(ComponentContext cc, InjectParam a, Type t)
/*      */       {
/* 1080 */         if (!(t instanceof Class)) {
/* 1081 */           return null;
/*      */         }
/* 1083 */         final ResourceComponentProvider rcp = WebApplicationImpl.this.getResourceComponentProvider(cc, (Class)t);
/* 1084 */         if (rcp.getScope() != ComponentScope.Singleton) {
/* 1085 */           return null;
/*      */         }
/* 1087 */         new Injectable()
/*      */         {
/*      */           public Object getValue() {
/* 1090 */             return rcp.getInstance(WebApplicationImpl.this.context);
/*      */           }
/*      */           
/*      */ 
/*      */         };
/*      */       }
/*      */       
/* 1097 */     });
/* 1098 */     this.injectableFactory.add(new ContextInjectableProvider(FeaturesAndProperties.class, this.resourceConfig));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1104 */     this.injectableFactory.add(new InjectableProvider()
/*      */     {
/*      */       public ComponentScope getScope()
/*      */       {
/* 1108 */         return ComponentScope.Singleton;
/*      */       }
/*      */       
/*      */       public Injectable<ResourceConfig> getInjectable(ComponentContext cc, Context a, Type t)
/*      */       {
/* 1113 */         if (t != ResourceConfig.class)
/* 1114 */           return null;
/* 1115 */         new Injectable()
/*      */         {
/*      */           public ResourceConfig getValue() {
/* 1118 */             return WebApplicationImpl.this.resourceConfig;
/*      */           }
/*      */           
/*      */ 
/*      */         };
/*      */       }
/* 1124 */     });
/* 1125 */     this.injectableFactory.add(new ContextInjectableProvider(ResourceContext.class, this.resourceContext));
/*      */     
/*      */ 
/*      */ 
/* 1129 */     this.injectableFactory.configure(providerServices);
/*      */     
/* 1131 */     boolean updateRequired = false;
/*      */     
/*      */ 
/* 1134 */     if ((rc instanceof DeferredResourceConfig)) {
/* 1135 */       DeferredResourceConfig drc = (DeferredResourceConfig)rc;
/*      */       
/* 1137 */       if (this.resourceConfig == drc) {
/* 1138 */         this.resourceConfig = drc.clone();
/*      */       }
/* 1140 */       DeferredResourceConfig.ApplicationHolder da = drc.getApplication(this.cpFactory);
/* 1141 */       this.resourceConfig.add(da.getApplication());
/* 1142 */       updateRequired = true;
/*      */       
/* 1144 */       this.injectableFactory.add(new ContextInjectableProvider(Application.class, da.getOriginalApplication()));
/*      */     }
/*      */     else {
/* 1147 */       this.injectableFactory.add(new ContextInjectableProvider(Application.class, this.resourceConfig));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1152 */     for (ResourceConfigurator configurator : providerServices.getProviders(ResourceConfigurator.class)) {
/* 1153 */       configurator.configure(this.resourceConfig);
/* 1154 */       updateRequired = true;
/*      */     }
/*      */     
/*      */ 
/* 1158 */     this.resourceConfig.validate();
/*      */     
/* 1160 */     if (updateRequired)
/*      */     {
/* 1162 */       providerServices.update(this.resourceConfig.getProviderClasses(), this.resourceConfig.getProviderSingletons(), this.injectableFactory);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1167 */     this.templateContext = new TemplateFactory(providerServices);
/*      */     
/* 1169 */     this.injectableFactory.add(new ContextInjectableProvider(TemplateContext.class, this.templateContext));
/*      */     
/*      */ 
/*      */ 
/* 1173 */     final ContextResolverFactory crf = new ContextResolverFactory();
/*      */     
/*      */ 
/* 1176 */     this.exceptionFactory = new ExceptionMapperFactory();
/*      */     
/*      */ 
/* 1179 */     this.bodyFactory = new MessageBodyFactory(providerServices, getFeaturesAndProperties().getFeature("com.sun.jersey.config.feature.Pre14ProviderPrecedence"));
/*      */     
/* 1181 */     this.injectableFactory.add(new ContextInjectableProvider(MessageBodyWorkers.class, this.bodyFactory));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1186 */     this.providers = new Providers()
/*      */     {
/*      */       public <T> MessageBodyReader<T> getMessageBodyReader(Class<T> c, Type t, Annotation[] as, MediaType m)
/*      */       {
/* 1190 */         return WebApplicationImpl.this.bodyFactory.getMessageBodyReader(c, t, as, m);
/*      */       }
/*      */       
/*      */ 
/*      */       public <T> MessageBodyWriter<T> getMessageBodyWriter(Class<T> c, Type t, Annotation[] as, MediaType m)
/*      */       {
/* 1196 */         return WebApplicationImpl.this.bodyFactory.getMessageBodyWriter(c, t, as, m);
/*      */       }
/*      */       
/*      */       public <T extends Throwable> ExceptionMapper<T> getExceptionMapper(Class<T> c)
/*      */       {
/* 1201 */         if (Throwable.class.isAssignableFrom(c)) {
/* 1202 */           return WebApplicationImpl.this.exceptionFactory.find(c);
/*      */         }
/* 1204 */         return null;
/*      */       }
/*      */       
/*      */       public <T> ContextResolver<T> getContextResolver(Class<T> ct, MediaType m)
/*      */       {
/* 1209 */         return crf.resolve(ct, m);
/*      */       }
/* 1211 */     };
/* 1212 */     this.injectableFactory.add(new ContextInjectableProvider(Providers.class, this.providers));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1217 */     this.stringReaderFactory = new StringReaderFactory();
/* 1218 */     this.injectableFactory.add(new ContextInjectableProvider(StringReaderWorkers.class, this.stringReaderFactory));
/*      */     
/*      */ 
/*      */ 
/* 1222 */     MultivaluedParameterExtractorProvider mpep = new MultivaluedParameterExtractorFactory(this.stringReaderFactory);
/*      */     
/*      */ 
/* 1225 */     this.injectableFactory.add(new ContextInjectableProvider(MultivaluedParameterExtractorProvider.class, mpep));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1230 */     this.injectableFactory.add(new CookieParamInjectableProvider(mpep));
/* 1231 */     this.injectableFactory.add(new HeaderParamInjectableProvider(mpep));
/* 1232 */     this.injectableFactory.add(new HttpContextInjectableProvider());
/* 1233 */     this.injectableFactory.add(new MatrixParamInjectableProvider(mpep));
/* 1234 */     this.injectableFactory.add(new PathParamInjectableProvider(mpep));
/* 1235 */     this.injectableFactory.add(new QueryParamInjectableProvider(mpep));
/* 1236 */     this.injectableFactory.add(new FormParamInjectableProvider(mpep));
/*      */     
/*      */ 
/* 1239 */     this.filterFactory = new FilterFactory(providerServices);
/*      */     
/*      */ 
/* 1242 */     this.dispatcherFactory = ResourceMethodDispatcherFactory.create(providerServices);
/*      */     
/* 1244 */     this.dispatchingListener = new DispatchingListenerProxy(null);
/*      */     
/*      */ 
/* 1247 */     this.wadlFactory = new WadlFactory(this.resourceConfig);
/*      */     
/*      */ 
/* 1250 */     this.filterFactory.init(this.resourceConfig);
/* 1251 */     if ((!this.resourceConfig.getMediaTypeMappings().isEmpty()) || (!this.resourceConfig.getLanguageMappings().isEmpty()))
/*      */     {
/* 1253 */       boolean present = false;
/* 1254 */       for (ContainerRequestFilter f : this.filterFactory.getRequestFilters()) {
/* 1255 */         present |= f instanceof UriConnegFilter;
/*      */       }
/*      */       
/* 1258 */       if (!present) {
/* 1259 */         this.filterFactory.getRequestFilters().add(new UriConnegFilter(this.resourceConfig.getMediaTypeMappings(), this.resourceConfig.getLanguageMappings()));
/*      */       }
/*      */       else
/*      */       {
/* 1263 */         LOGGER.warning("The media type and language mappings declared in the ResourceConfig are ignored because there is an instance of " + UriConnegFilter.class.getName() + "present in the list of request filters.");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1271 */     crf.init(providerServices, this.injectableFactory);
/*      */     
/*      */ 
/* 1274 */     this.exceptionFactory.init(providerServices);
/*      */     
/*      */ 
/* 1277 */     this.bodyFactory.init();
/*      */     
/*      */ 
/* 1280 */     this.stringReaderFactory.init(providerServices);
/*      */     
/*      */ 
/* 1283 */     Errors.setReportMissingDependentFieldOrMethod(true);
/* 1284 */     this.cpFactory.injectOnAllComponents();
/* 1285 */     this.cpFactory.injectOnProviderInstances(this.resourceConfig.getProviderSingletons());
/*      */     
/*      */ 
/* 1288 */     for (IoCComponentProviderFactory providerFactory : this.providerFactories) {
/* 1289 */       if ((providerFactory instanceof WebApplicationListener)) {
/* 1290 */         WebApplicationListener listener = (WebApplicationListener)providerFactory;
/* 1291 */         listener.onWebApplicationReady();
/*      */       }
/*      */     }
/*      */     
/* 1295 */     createAbstractResourceModelStructures();
/*      */     
/*      */ 
/* 1298 */     RulesMap<UriRule> rootRules = new RootResourceUriRules(this, this.resourceConfig, this.wadlFactory, this.injectableFactory).getRules();
/*      */     
/* 1300 */     this.rootsRule = new RootResourceClassesRule(rootRules);
/*      */     
/* 1302 */     this.requestListener = MonitoringProviderFactory.createRequestListener(providerServices);
/* 1303 */     this.responseListener = MonitoringProviderFactory.createResponseListener(providerServices);
/* 1304 */     this.dispatchingListener.init(providerServices);
/*      */     
/* 1306 */     callAbstractResourceModelListenersOnLoaded(providerServices);
/*      */     
/* 1308 */     this.isTraceEnabled = (this.resourceConfig.getFeature("com.sun.jersey.config.feature.Trace") | this.resourceConfig.getFeature("com.sun.jersey.config.feature.TracePerRequest"));
/*      */   }
/*      */   
/*      */ 
/*      */   public Providers getProviders()
/*      */   {
/* 1314 */     return this.providers;
/*      */   }
/*      */   
/*      */   public MessageBodyWorkers getMessageBodyWorkers()
/*      */   {
/* 1319 */     return this.bodyFactory;
/*      */   }
/*      */   
/*      */   public ExceptionMapperContext getExceptionMapperContext()
/*      */   {
/* 1324 */     return this.exceptionFactory;
/*      */   }
/*      */   
/*      */   public ServerInjectableProviderFactory getServerInjectableProviderFactory()
/*      */   {
/* 1329 */     return this.injectableFactory;
/*      */   }
/*      */   
/*      */   public void handleRequest(ContainerRequest request, ContainerResponseWriter responseWriter)
/*      */     throws IOException
/*      */   {
/* 1335 */     ContainerResponse response = new ContainerResponse(this, request, responseWriter);
/*      */     
/*      */ 
/*      */ 
/* 1339 */     handleRequest(request, response);
/*      */   }
/*      */   
/*      */   public void handleRequest(ContainerRequest request, ContainerResponse response) throws IOException
/*      */   {
/* 1344 */     WebApplicationContext localContext = new WebApplicationContext(this, request, response);
/*      */     
/*      */ 
/* 1347 */     this.context.set(localContext);
/*      */     try {
/* 1349 */       _handleRequest(localContext, request, response);
/*      */     } finally {
/* 1351 */       PerRequestFactory.destroy(localContext);
/* 1352 */       this.closeableFactory.close(localContext);
/* 1353 */       this.context.set(null);
/*      */     }
/*      */   }
/*      */   
/*      */   private WebApplicationContext handleMatchResourceRequest(URI u) {
/* 1358 */     WebApplicationContext oldContext = (WebApplicationContext)this.context.get();
/*      */     
/* 1360 */     WebApplicationContext newContext = oldContext.createMatchResourceContext(u);
/*      */     
/* 1362 */     this.context.set(newContext);
/*      */     try {
/* 1364 */       _handleRequest(newContext, newContext.getContainerRequest());
/* 1365 */       return newContext;
/*      */     } finally {
/* 1367 */       this.context.set(oldContext);
/*      */     }
/*      */   }
/*      */   
/*      */   public void destroy()
/*      */   {
/* 1373 */     for (ResourceComponentProvider rcp : this.providerMap.values()) {
/* 1374 */       rcp.destroy();
/*      */     }
/*      */     
/* 1377 */     for (ResourceComponentProvider rcp : this.providerWithAnnotationKeyMap.values()) {
/* 1378 */       rcp.destroy();
/*      */     }
/*      */     
/* 1381 */     this.cpFactory.destroy();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isTracingEnabled()
/*      */   {
/* 1388 */     return this.isTraceEnabled;
/*      */   }
/*      */   
/*      */   public void trace(String message)
/*      */   {
/* 1393 */     this.context.get().trace(message);
/*      */   }
/*      */   
/*      */   private void _handleRequest(WebApplicationContext localContext, ContainerRequest request, ContainerResponse response) throws IOException
/*      */   {
/*      */     try {
/* 1399 */       this.requestListener.onRequest(Thread.currentThread().getId(), request);
/* 1400 */       _handleRequest(localContext, request);
/*      */     } catch (WebApplicationException e) {
/* 1402 */       response.mapWebApplicationException(e);
/*      */     } catch (MappableContainerException e) {
/* 1404 */       response.mapMappableContainerException(e);
/*      */     } catch (RuntimeException e) {
/* 1406 */       if (!response.mapException(e)) {
/* 1407 */         LOGGER.log(Level.SEVERE, "The RuntimeException could not be mapped to a response, re-throwing to the HTTP container", e);
/*      */         
/* 1409 */         throw e;
/*      */       }
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1415 */       for (ContainerResponseFilter f : localContext.getResponseFilters()) {
/* 1416 */         response = f.filter(request, response);
/* 1417 */         localContext.setContainerResponse(response);
/*      */       }
/*      */       
/* 1420 */       for (ContainerResponseFilter f : this.filterFactory.getResponseFilters()) {
/* 1421 */         response = f.filter(request, response);
/* 1422 */         localContext.setContainerResponse(response);
/*      */       }
/*      */     } catch (WebApplicationException e) {
/* 1425 */       response.mapWebApplicationException(e);
/*      */     } catch (MappableContainerException e) {
/* 1427 */       response.mapMappableContainerException(e);
/*      */     } catch (RuntimeException e) {
/* 1429 */       if (!response.mapException(e)) {
/* 1430 */         LOGGER.log(Level.SEVERE, "The RuntimeException could not be mapped to a response, re-throwing to the HTTP container", e);
/*      */         
/* 1432 */         throw e;
/*      */       }
/*      */     }
/*      */     try
/*      */     {
/* 1437 */       response.write();
/* 1438 */       this.responseListener.onResponse(Thread.currentThread().getId(), response);
/*      */     } catch (WebApplicationException e) {
/* 1440 */       if (response.isCommitted()) {
/* 1441 */         LOGGER.log(Level.SEVERE, "The response of the WebApplicationException cannot be utilized as the response is already committed. Re-throwing to the HTTP container", e);
/*      */         
/* 1443 */         throw e;
/*      */       }
/* 1445 */       response.mapWebApplicationException(e);
/* 1446 */       response.write();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void _handleRequest(WebApplicationContext localContext, ContainerRequest request)
/*      */   {
/* 1453 */     for (ContainerRequestFilter f : this.filterFactory.getRequestFilters()) {
/* 1454 */       request = f.filter(request);
/* 1455 */       localContext.setContainerRequest(request);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1462 */     StringBuilder path = new StringBuilder();
/* 1463 */     path.append("/").append(request.getPath(false));
/*      */     
/* 1465 */     if (!this.resourceConfig.getFeature("com.sun.jersey.config.feature.IgnoreMatrixParams")) {
/* 1466 */       path = stripMatrixParams(path);
/*      */     }
/*      */     
/* 1469 */     if (!this.rootsRule.accept(path, null, localContext)) {
/* 1470 */       throw new NotFoundException(request.getRequestUri());
/*      */     }
/*      */   }
/*      */   
/*      */   public HttpContext getThreadLocalHttpContext()
/*      */   {
/* 1476 */     return this.context;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private StringBuilder stripMatrixParams(StringBuilder path)
/*      */   {
/* 1483 */     int e = path.indexOf(";");
/* 1484 */     if (e == -1) {
/* 1485 */       return path;
/*      */     }
/*      */     
/* 1488 */     int s = 0;
/* 1489 */     StringBuilder sb = new StringBuilder();
/*      */     do
/*      */     {
/* 1492 */       sb.append(path, s, e);
/*      */       
/*      */ 
/* 1495 */       s = path.indexOf("/", e + 1);
/* 1496 */       if (s == -1) {
/*      */         break;
/*      */       }
/* 1499 */       e = path.indexOf(";", s);
/* 1500 */     } while (e != -1);
/*      */     
/* 1502 */     if (s != -1)
/*      */     {
/* 1504 */       sb.append(path, s, path.length());
/*      */     }
/*      */     
/* 1507 */     return sb;
/*      */   }
/*      */   
/*      */ 
/*      */   private void createAbstractResourceModelStructures()
/*      */   {
/* 1513 */     Set<AbstractResource> rootARs = new HashSet();
/*      */     
/*      */ 
/* 1516 */     for (Object o : this.resourceConfig.getRootResourceSingletons()) {
/* 1517 */       rootARs.add(getAbstractResource(o));
/*      */     }
/*      */     
/*      */ 
/* 1521 */     for (Class<?> c : this.resourceConfig.getRootResourceClasses()) {
/* 1522 */       rootARs.add(getAbstractResource(c));
/*      */     }
/*      */     
/*      */ 
/* 1526 */     Map<String, AbstractResource> explicitRootARs = new HashMap();
/*      */     
/* 1528 */     for (Map.Entry<String, Object> e : this.resourceConfig.getExplicitRootResources().entrySet()) {
/* 1529 */       Object o = e.getValue();
/* 1530 */       Class c = (o instanceof Class) ? (Class)o : o.getClass();
/*      */       
/* 1532 */       AbstractResource ar = new AbstractResource((String)e.getKey(), getAbstractResource(c));
/*      */       
/*      */ 
/* 1535 */       rootARs.add(ar);
/* 1536 */       explicitRootARs.put(e.getKey(), ar);
/*      */     }
/*      */     
/* 1539 */     this.abstractRootResources = Collections.unmodifiableSet(rootARs);
/* 1540 */     this.explicitAbstractRootResources = Collections.unmodifiableMap(explicitRootARs);
/*      */   }
/*      */   
/*      */   private void callAbstractResourceModelListenersOnLoaded(ProviderServices providerServices) {
/* 1544 */     for (AbstractResourceModelListener aml : providerServices.getProviders(AbstractResourceModelListener.class)) {
/* 1545 */       aml.onLoaded(this.armContext);
/*      */     }
/*      */   }
/*      */   
/*      */   private <T> T createProxy(Class<T> c, InvocationHandler i) {
/* 1550 */     return (T)c.cast(Proxy.newProxyInstance(getClass().getClassLoader(), new Class[] { c }, i));
/*      */   }
/*      */   
/*      */   private class DispatchingListenerProxy implements DispatchingListener
/*      */   {
/*      */     private DispatchingListener dispatchingListener;
/*      */     
/*      */     private DispatchingListenerProxy() {}
/*      */     
/*      */     public void onSubResource(long id, Class subResource)
/*      */     {
/* 1561 */       this.dispatchingListener.onSubResource(id, subResource);
/*      */     }
/*      */     
/*      */     public void onSubResourceLocator(long id, AbstractSubResourceLocator locator)
/*      */     {
/* 1566 */       this.dispatchingListener.onSubResourceLocator(id, locator);
/*      */     }
/*      */     
/*      */     public void onResourceMethod(long id, AbstractResourceMethod method)
/*      */     {
/* 1571 */       this.dispatchingListener.onResourceMethod(id, method);
/*      */     }
/*      */     
/*      */     public void init(ProviderServices providerServices) {
/* 1575 */       this.dispatchingListener = MonitoringProviderFactory.createDispatchingListener(providerServices);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\application\WebApplicationImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */