package com.sun.jersey.api.core;

import com.sun.jersey.api.representation.Form;
import com.sun.jersey.core.header.QualitySourceMediaType;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.net.URI;
import java.util.List;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.PathSegment;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.core.UriBuilder;

public abstract interface HttpRequestContext
  extends HttpHeaders, Request, SecurityContext, Traceable
{
  public abstract URI getBaseUri();
  
  public abstract UriBuilder getBaseUriBuilder();
  
  public abstract URI getRequestUri();
  
  public abstract UriBuilder getRequestUriBuilder();
  
  public abstract URI getAbsolutePath();
  
  public abstract UriBuilder getAbsolutePathBuilder();
  
  public abstract String getPath();
  
  public abstract String getPath(boolean paramBoolean);
  
  public abstract List<PathSegment> getPathSegments();
  
  public abstract List<PathSegment> getPathSegments(boolean paramBoolean);
  
  public abstract MultivaluedMap<String, String> getQueryParameters();
  
  public abstract MultivaluedMap<String, String> getQueryParameters(boolean paramBoolean);
  
  public abstract String getHeaderValue(String paramString);
  
  @Deprecated
  public abstract MediaType getAcceptableMediaType(List<MediaType> paramList);
  
  @Deprecated
  public abstract List<MediaType> getAcceptableMediaTypes(List<QualitySourceMediaType> paramList);
  
  public abstract MultivaluedMap<String, String> getCookieNameValueMap();
  
  public abstract <T> T getEntity(Class<T> paramClass)
    throws WebApplicationException;
  
  public abstract <T> T getEntity(Class<T> paramClass, Type paramType, Annotation[] paramArrayOfAnnotation)
    throws WebApplicationException;
  
  public abstract Form getFormParameters();
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\core\HttpRequestContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */