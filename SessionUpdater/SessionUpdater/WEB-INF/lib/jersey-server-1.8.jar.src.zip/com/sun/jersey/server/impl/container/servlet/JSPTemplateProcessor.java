/*     */ package com.sun.jersey.server.impl.container.servlet;
/*     */ 
/*     */ import com.sun.jersey.api.container.ContainerException;
/*     */ import com.sun.jersey.api.core.HttpContext;
/*     */ import com.sun.jersey.api.core.ResourceConfig;
/*     */ import com.sun.jersey.api.view.Viewable;
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*     */ import com.sun.jersey.spi.template.ViewProcessor;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.Map;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.ws.rs.core.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSPTemplateProcessor
/*     */   implements ViewProcessor<String>
/*     */ {
/*     */   @Context
/*     */   private HttpContext hc;
/*     */   @Context
/*     */   private ServletContext servletContext;
/*     */   @Context
/*     */   private ThreadLocal<HttpServletRequest> requestInvoker;
/*     */   @Context
/*     */   private ThreadLocal<HttpServletResponse> responseInvoker;
/*     */   private final String basePath;
/*     */   
/*     */   public JSPTemplateProcessor(@Context ResourceConfig resourceConfig)
/*     */   {
/*  78 */     String path = (String)resourceConfig.getProperties().get("com.sun.jersey.config.property.JSPTemplatesBasePath");
/*     */     
/*  80 */     if (path == null) {
/*  81 */       this.basePath = "";
/*  82 */     } else if (path.charAt(0) == '/') {
/*  83 */       this.basePath = path;
/*     */     } else {
/*  85 */       this.basePath = ("/" + path);
/*     */     }
/*     */   }
/*     */   
/*     */   public String resolve(String path) {
/*  90 */     if (this.servletContext == null) {
/*  91 */       return null;
/*     */     }
/*  93 */     if (this.basePath != "") {
/*  94 */       path = this.basePath + path;
/*     */     }
/*     */     try {
/*  97 */       if (this.servletContext.getResource(path) != null) {
/*  98 */         return path;
/*     */       }
/*     */       
/* 101 */       if (!path.endsWith(".jsp")) {
/* 102 */         path = path + ".jsp";
/* 103 */         if (this.servletContext.getResource(path) != null) {
/* 104 */           return path;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (MalformedURLException ex) {}
/*     */     
/*     */ 
/* 111 */     return null;
/*     */   }
/*     */   
/*     */   public void writeTo(String resolvedPath, Viewable viewable, OutputStream out) throws IOException {
/* 115 */     if (this.hc.isTracingEnabled()) {
/* 116 */       this.hc.trace(String.format("forwarding view to JSP page: \"%s\", it = %s", new Object[] { resolvedPath, ReflectionHelper.objectToString(viewable.getModel()) }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 122 */     out.flush();
/*     */     
/* 124 */     RequestDispatcher d = this.servletContext.getRequestDispatcher(resolvedPath);
/* 125 */     if (d == null) {
/* 126 */       throw new ContainerException("No request dispatcher for: " + resolvedPath);
/*     */     }
/*     */     
/* 129 */     d = new RequestDispatcherWrapper(d, this.basePath, this.hc, viewable);
/*     */     try
/*     */     {
/* 132 */       d.forward((ServletRequest)this.requestInvoker.get(), (ServletResponse)this.responseInvoker.get());
/*     */     } catch (Exception e) {
/* 134 */       throw new ContainerException(e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\container\servlet\JSPTemplateProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */