/*     */ package com.sun.jersey.server.impl.modelapi.annotation;
/*     */ 
/*     */ import com.sun.jersey.api.model.AbstractField;
/*     */ import com.sun.jersey.api.model.AbstractResource;
/*     */ import com.sun.jersey.api.model.AbstractResourceConstructor;
/*     */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*     */ import com.sun.jersey.api.model.AbstractSetterMethod;
/*     */ import com.sun.jersey.api.model.AbstractSubResourceLocator;
/*     */ import com.sun.jersey.api.model.AbstractSubResourceMethod;
/*     */ import com.sun.jersey.api.model.Parameter;
/*     */ import com.sun.jersey.api.model.Parameter.Source;
/*     */ import com.sun.jersey.api.model.Parameterized;
/*     */ import com.sun.jersey.api.model.PathValue;
/*     */ import com.sun.jersey.core.header.MediaTypes;
/*     */ import com.sun.jersey.core.reflection.AnnotatedMethod;
/*     */ import com.sun.jersey.core.reflection.MethodList;
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper.ClassTypePair;
/*     */ import com.sun.jersey.impl.ImplMessages;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.ws.rs.Consumes;
/*     */ import javax.ws.rs.CookieParam;
/*     */ import javax.ws.rs.DefaultValue;
/*     */ import javax.ws.rs.Encoded;
/*     */ import javax.ws.rs.FormParam;
/*     */ import javax.ws.rs.HeaderParam;
/*     */ import javax.ws.rs.HttpMethod;
/*     */ import javax.ws.rs.MatrixParam;
/*     */ import javax.ws.rs.Path;
/*     */ import javax.ws.rs.PathParam;
/*     */ import javax.ws.rs.Produces;
/*     */ import javax.ws.rs.QueryParam;
/*     */ import javax.ws.rs.core.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntrospectionModeller
/*     */ {
/*  92 */   private static final Logger LOGGER = Logger.getLogger(IntrospectionModeller.class.getName());
/*     */   
/*     */   public static AbstractResource createResource(Class<?> resourceClass) {
/*  95 */     Class<?> annotatedResourceClass = getAnnotatedResourceClass(resourceClass);
/*  96 */     Path rPathAnnotation = (Path)annotatedResourceClass.getAnnotation(Path.class);
/*  97 */     boolean isRootResourceClass = null != rPathAnnotation;
/*     */     
/*  99 */     boolean isEncodedAnotOnClass = null != annotatedResourceClass.getAnnotation(Encoded.class);
/*     */     
/*     */     AbstractResource resource;
/*     */     
/*     */     AbstractResource resource;
/* 104 */     if (isRootResourceClass) {
/* 105 */       resource = new AbstractResource(resourceClass, new PathValue(rPathAnnotation.value()));
/*     */     }
/*     */     else {
/* 108 */       resource = new AbstractResource(resourceClass);
/*     */     }
/*     */     
/* 111 */     workOutConstructorsList(resource, resourceClass.getConstructors(), isEncodedAnotOnClass);
/*     */     
/*     */ 
/* 114 */     workOutFieldsList(resource, isEncodedAnotOnClass);
/*     */     
/* 116 */     MethodList methodList = new MethodList(resourceClass);
/*     */     
/* 118 */     workOutSetterMethodsList(resource, methodList, isEncodedAnotOnClass);
/*     */     
/* 120 */     Consumes classScopeConsumesAnnotation = (Consumes)annotatedResourceClass.getAnnotation(Consumes.class);
/*     */     
/* 122 */     Produces classScopeProducesAnnotation = (Produces)annotatedResourceClass.getAnnotation(Produces.class);
/*     */     
/* 124 */     workOutResourceMethodsList(resource, methodList, isEncodedAnotOnClass, classScopeConsumesAnnotation, classScopeProducesAnnotation);
/*     */     
/* 126 */     workOutSubResourceMethodsList(resource, methodList, isEncodedAnotOnClass, classScopeConsumesAnnotation, classScopeProducesAnnotation);
/*     */     
/* 128 */     workOutSubResourceLocatorsList(resource, methodList, isEncodedAnotOnClass);
/*     */     
/* 130 */     workOutPostConstructPreDestroy(resource);
/*     */     
/* 132 */     if (LOGGER.isLoggable(Level.FINEST)) {
/* 133 */       LOGGER.finest(ImplMessages.NEW_AR_CREATED_BY_INTROSPECTION_MODELER(resource.toString()));
/*     */     }
/*     */     
/*     */ 
/* 137 */     return resource;
/*     */   }
/*     */   
/*     */   private static Class getAnnotatedResourceClass(Class rc) {
/* 141 */     if (rc.isAnnotationPresent(Path.class)) { return rc;
/*     */     }
/* 143 */     for (Class i : rc.getInterfaces()) {
/* 144 */       if (i.isAnnotationPresent(Path.class)) return i;
/*     */     }
/* 146 */     return rc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void addConsumes(AnnotatedMethod am, AbstractResourceMethod resourceMethod, Consumes consumeMimeAnnotation)
/*     */   {
/* 154 */     if (am.isAnnotationPresent(Consumes.class)) {
/* 155 */       consumeMimeAnnotation = (Consumes)am.getAnnotation(Consumes.class);
/*     */     }
/* 157 */     resourceMethod.setAreInputTypesDeclared(consumeMimeAnnotation != null);
/* 158 */     resourceMethod.getSupportedInputTypes().addAll(MediaTypes.createMediaTypes(consumeMimeAnnotation));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void addProduces(AnnotatedMethod am, AbstractResourceMethod resourceMethod, Produces produceMimeAnnotation)
/*     */   {
/* 167 */     if (am.isAnnotationPresent(Produces.class)) {
/* 168 */       produceMimeAnnotation = (Produces)am.getAnnotation(Produces.class);
/*     */     }
/* 170 */     resourceMethod.setAreOutputTypesDeclared(produceMimeAnnotation != null);
/* 171 */     resourceMethod.getSupportedOutputTypes().addAll(MediaTypes.createQualitySourceMediaTypes(produceMimeAnnotation));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void workOutConstructorsList(AbstractResource resource, Constructor[] ctorArray, boolean isEncoded)
/*     */   {
/* 179 */     if (null != ctorArray) {
/* 180 */       for (Constructor ctor : ctorArray) {
/* 181 */         AbstractResourceConstructor aCtor = new AbstractResourceConstructor(ctor);
/*     */         
/* 183 */         processParameters(resource.getResourceClass(), ctor.getDeclaringClass(), aCtor, ctor, isEncoded);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 189 */         resource.getConstructors().add(aCtor);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static void workOutFieldsList(AbstractResource resource, boolean isEncoded)
/*     */   {
/* 197 */     Class c = resource.getResourceClass();
/* 198 */     if (c.isInterface()) {
/* 199 */       return;
/*     */     }
/* 201 */     while (c != Object.class) {
/* 202 */       for (Field f : c.getDeclaredFields()) {
/* 203 */         if (f.getDeclaredAnnotations().length > 0) {
/* 204 */           AbstractField af = new AbstractField(f);
/* 205 */           Parameter p = createParameter(resource.getResourceClass(), f.getDeclaringClass(), isEncoded, f.getType(), f.getGenericType(), f.getAnnotations());
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 212 */           if (null != p) {
/* 213 */             af.getParameters().add(p);
/* 214 */             resource.getFields().add(af);
/*     */           }
/*     */         }
/*     */       }
/* 218 */       c = c.getSuperclass();
/*     */     }
/*     */   }
/*     */   
/*     */   private static void workOutPostConstructPreDestroy(AbstractResource resource) {
/* 223 */     Class postConstruct = ReflectionHelper.classForName("javax.annotation.PostConstruct");
/* 224 */     if (postConstruct == null) {
/* 225 */       return;
/*     */     }
/* 227 */     Class preDestroy = ReflectionHelper.classForName("javax.annotation.PreDestroy");
/*     */     
/* 229 */     MethodList methodList = new MethodList(resource.getResourceClass(), true);
/* 230 */     HashSet<String> names = new HashSet();
/* 231 */     for (AnnotatedMethod m : methodList.hasAnnotation(postConstruct).hasNumParams(0).hasReturnType(Void.TYPE))
/*     */     {
/*     */ 
/*     */ 
/* 235 */       Method method = m.getMethod();
/*     */       
/* 237 */       if (names.add(method.getName())) {
/* 238 */         ReflectionHelper.setAccessibleMethod(method);
/* 239 */         resource.getPostConstructMethods().add(0, method);
/*     */       }
/*     */     }
/*     */     
/* 243 */     names = new HashSet();
/* 244 */     for (AnnotatedMethod m : methodList.hasAnnotation(preDestroy).hasNumParams(0).hasReturnType(Void.TYPE))
/*     */     {
/*     */ 
/*     */ 
/* 248 */       Method method = m.getMethod();
/*     */       
/* 250 */       if (names.add(method.getName())) {
/* 251 */         ReflectionHelper.setAccessibleMethod(method);
/* 252 */         resource.getPreDestroyMethods().add(method);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static void workOutSetterMethodsList(AbstractResource resource, MethodList methodList, boolean isEncoded)
/*     */   {
/* 261 */     for (AnnotatedMethod m : methodList.hasNotMetaAnnotation(HttpMethod.class).hasNotAnnotation(Path.class).hasNumParams(1).hasReturnType(Void.TYPE).nameStartsWith("set"))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 268 */       AbstractSetterMethod asm = new AbstractSetterMethod(resource, m.getMethod(), m.getAnnotations());
/* 269 */       Parameter p = createParameter(resource.getResourceClass(), m.getMethod().getDeclaringClass(), isEncoded, m.getParameterTypes()[0], m.getGenericParameterTypes()[0], m.getAnnotations());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 276 */       if (null != p) {
/* 277 */         asm.getParameters().add(p);
/* 278 */         resource.getSetterMethods().add(asm);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void workOutResourceMethodsList(AbstractResource resource, MethodList methodList, boolean isEncoded, Consumes classScopeConsumesAnnotation, Produces classScopeProducesAnnotation)
/*     */   {
/* 289 */     for (AnnotatedMethod m : methodList.hasMetaAnnotation(HttpMethod.class).hasNotAnnotation(Path.class))
/*     */     {
/*     */ 
/* 292 */       ReflectionHelper.ClassTypePair ct = getGenericReturnType(resource.getResourceClass(), m.getMethod());
/* 293 */       AbstractResourceMethod resourceMethod = new AbstractResourceMethod(resource, m.getMethod(), ct.c, ct.t, ((HttpMethod)m.getMetaMethodAnnotations(HttpMethod.class).get(0)).value(), m.getAnnotations());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 300 */       addConsumes(m, resourceMethod, classScopeConsumesAnnotation);
/* 301 */       addProduces(m, resourceMethod, classScopeProducesAnnotation);
/* 302 */       processParameters(resourceMethod.getResource().getResourceClass(), resourceMethod.getMethod().getDeclaringClass(), resourceMethod, m, isEncoded);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 307 */       resource.getResourceMethods().add(resourceMethod);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static ReflectionHelper.ClassTypePair getGenericReturnType(Class concreteClass, Method m)
/*     */   {
/* 314 */     return getGenericType(concreteClass, m.getDeclaringClass(), m.getReturnType(), m.getGenericReturnType());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void workOutSubResourceMethodsList(AbstractResource resource, MethodList methodList, boolean isEncoded, Consumes classScopeConsumesAnnotation, Produces classScopeProducesAnnotation)
/*     */   {
/* 324 */     for (AnnotatedMethod m : methodList.hasMetaAnnotation(HttpMethod.class).hasAnnotation(Path.class))
/*     */     {
/* 326 */       Path mPathAnnotation = (Path)m.getAnnotation(Path.class);
/* 327 */       PathValue pv = new PathValue(mPathAnnotation.value());
/*     */       
/* 329 */       boolean emptySegmentCase = ("/".equals(pv.getValue())) || ("".equals(pv.getValue()));
/*     */       
/* 331 */       if (!emptySegmentCase) {
/* 332 */         ReflectionHelper.ClassTypePair ct = getGenericReturnType(resource.getResourceClass(), m.getMethod());
/* 333 */         AbstractSubResourceMethod abstractSubResourceMethod = new AbstractSubResourceMethod(resource, m.getMethod(), ct.c, ct.t, pv, ((HttpMethod)m.getMetaMethodAnnotations(HttpMethod.class).get(0)).value(), m.getAnnotations());
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 341 */         addConsumes(m, abstractSubResourceMethod, classScopeConsumesAnnotation);
/* 342 */         addProduces(m, abstractSubResourceMethod, classScopeProducesAnnotation);
/* 343 */         processParameters(abstractSubResourceMethod.getResource().getResourceClass(), abstractSubResourceMethod.getMethod().getDeclaringClass(), abstractSubResourceMethod, m, isEncoded);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 348 */         resource.getSubResourceMethods().add(abstractSubResourceMethod);
/*     */       }
/*     */       else {
/* 351 */         ReflectionHelper.ClassTypePair ct = getGenericReturnType(resource.getResourceClass(), m.getMethod());
/* 352 */         AbstractResourceMethod abstractResourceMethod = new AbstractResourceMethod(resource, m.getMethod(), ct.c, ct.t, ((HttpMethod)m.getMetaMethodAnnotations(HttpMethod.class).get(0)).value(), m.getAnnotations());
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 359 */         addConsumes(m, abstractResourceMethod, classScopeConsumesAnnotation);
/* 360 */         addProduces(m, abstractResourceMethod, classScopeProducesAnnotation);
/* 361 */         processParameters(abstractResourceMethod.getResource().getResourceClass(), abstractResourceMethod.getMethod().getDeclaringClass(), abstractResourceMethod, m, isEncoded);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 366 */         resource.getResourceMethods().add(abstractResourceMethod);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void workOutSubResourceLocatorsList(AbstractResource resource, MethodList methodList, boolean isEncoded)
/*     */   {
/* 376 */     for (AnnotatedMethod m : methodList.hasNotMetaAnnotation(HttpMethod.class).hasAnnotation(Path.class))
/*     */     {
/* 378 */       Path mPathAnnotation = (Path)m.getAnnotation(Path.class);
/* 379 */       AbstractSubResourceLocator subResourceLocator = new AbstractSubResourceLocator(resource, m.getMethod(), new PathValue(mPathAnnotation.value()), m.getAnnotations());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 386 */       processParameters(subResourceLocator.getResource().getResourceClass(), subResourceLocator.getMethod().getDeclaringClass(), subResourceLocator, m, isEncoded);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 391 */       resource.getSubResourceLocators().add(subResourceLocator);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void processParameters(Class concreteClass, Class declaringClass, Parameterized parametrized, Constructor ctor, boolean isEncoded)
/*     */   {
/* 401 */     Class[] parameterTypes = ctor.getParameterTypes();
/* 402 */     Type[] genericParameterTypes = ctor.getGenericParameterTypes();
/*     */     
/* 404 */     if (parameterTypes.length != genericParameterTypes.length) {
/* 405 */       Type[] _genericParameterTypes = new Type[parameterTypes.length];
/* 406 */       _genericParameterTypes[0] = parameterTypes[0];
/* 407 */       System.arraycopy(genericParameterTypes, 0, _genericParameterTypes, 1, genericParameterTypes.length);
/* 408 */       genericParameterTypes = _genericParameterTypes;
/*     */     }
/*     */     
/* 411 */     processParameters(concreteClass, declaringClass, parametrized, (null != ctor.getAnnotation(Encoded.class)) || (isEncoded), parameterTypes, genericParameterTypes, ctor.getParameterAnnotations());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void processParameters(Class concreteClass, Class declaringClass, Parameterized parametrized, AnnotatedMethod method, boolean isEncoded)
/*     */   {
/* 426 */     processParameters(concreteClass, declaringClass, parametrized, (null != method.getAnnotation(Encoded.class)) || (isEncoded), method.getParameterTypes(), method.getGenericParameterTypes(), method.getParameterAnnotations());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void processParameters(Class concreteClass, Class declaringClass, Parameterized parametrized, boolean isEncoded, Class[] parameterTypes, Type[] genericParameterTypes, Annotation[][] parameterAnnotations)
/*     */   {
/* 444 */     for (int i = 0; i < parameterTypes.length; i++) {
/* 445 */       Parameter parameter = createParameter(concreteClass, declaringClass, isEncoded, parameterTypes[i], genericParameterTypes[i], parameterAnnotations[i]);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 450 */       if (null != parameter) {
/* 451 */         parametrized.getParameters().add(parameter);
/*     */       }
/*     */       else {
/* 454 */         parametrized.getParameters().removeAll(parametrized.getParameters());
/* 455 */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Map<Class, ParamAnnotationHelper> createParamAnotHelperMap()
/*     */   {
/* 468 */     Map<Class, ParamAnnotationHelper> m = new WeakHashMap();
/* 469 */     m.put(Context.class, new ParamAnnotationHelper()
/*     */     {
/*     */       public String getValueOf(Context a)
/*     */       {
/* 473 */         return null;
/*     */       }
/*     */       
/*     */       public Parameter.Source getSource()
/*     */       {
/* 478 */         return Parameter.Source.CONTEXT;
/*     */       }
/* 480 */     });
/* 481 */     m.put(HeaderParam.class, new ParamAnnotationHelper()
/*     */     {
/*     */       public String getValueOf(HeaderParam a)
/*     */       {
/* 485 */         return a.value();
/*     */       }
/*     */       
/*     */       public Parameter.Source getSource()
/*     */       {
/* 490 */         return Parameter.Source.HEADER;
/*     */       }
/* 492 */     });
/* 493 */     m.put(CookieParam.class, new ParamAnnotationHelper()
/*     */     {
/*     */       public String getValueOf(CookieParam a)
/*     */       {
/* 497 */         return a.value();
/*     */       }
/*     */       
/*     */       public Parameter.Source getSource()
/*     */       {
/* 502 */         return Parameter.Source.COOKIE;
/*     */       }
/* 504 */     });
/* 505 */     m.put(MatrixParam.class, new ParamAnnotationHelper()
/*     */     {
/*     */       public String getValueOf(MatrixParam a)
/*     */       {
/* 509 */         return a.value();
/*     */       }
/*     */       
/*     */       public Parameter.Source getSource()
/*     */       {
/* 514 */         return Parameter.Source.MATRIX;
/*     */       }
/* 516 */     });
/* 517 */     m.put(QueryParam.class, new ParamAnnotationHelper()
/*     */     {
/*     */       public String getValueOf(QueryParam a)
/*     */       {
/* 521 */         return a.value();
/*     */       }
/*     */       
/*     */       public Parameter.Source getSource()
/*     */       {
/* 526 */         return Parameter.Source.QUERY;
/*     */       }
/* 528 */     });
/* 529 */     m.put(PathParam.class, new ParamAnnotationHelper()
/*     */     {
/*     */       public String getValueOf(PathParam a)
/*     */       {
/* 533 */         return a.value();
/*     */       }
/*     */       
/*     */       public Parameter.Source getSource()
/*     */       {
/* 538 */         return Parameter.Source.PATH;
/*     */       }
/* 540 */     });
/* 541 */     m.put(FormParam.class, new ParamAnnotationHelper()
/*     */     {
/*     */       public String getValueOf(FormParam a)
/*     */       {
/* 545 */         return a.value();
/*     */       }
/*     */       
/*     */       public Parameter.Source getSource()
/*     */       {
/* 550 */         return Parameter.Source.FORM;
/*     */       }
/* 552 */     });
/* 553 */     return Collections.unmodifiableMap(m); }
/*     */   
/* 555 */   private static final Map<Class, ParamAnnotationHelper> ANOT_HELPER_MAP = createParamAnotHelperMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Parameter createParameter(Class concreteClass, Class declaringClass, boolean isEncoded, Class<?> paramClass, Type paramType, Annotation[] annotations)
/*     */   {
/* 567 */     if (null == annotations) {
/* 568 */       return null;
/*     */     }
/*     */     
/* 571 */     Annotation paramAnnotation = null;
/* 572 */     Parameter.Source paramSource = null;
/* 573 */     String paramName = null;
/* 574 */     boolean paramEncoded = isEncoded;
/* 575 */     String paramDefault = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 583 */     for (Annotation annotation : annotations) {
/* 584 */       if (ANOT_HELPER_MAP.containsKey(annotation.annotationType())) {
/* 585 */         ParamAnnotationHelper helper = (ParamAnnotationHelper)ANOT_HELPER_MAP.get(annotation.annotationType());
/* 586 */         paramAnnotation = annotation;
/* 587 */         paramSource = helper.getSource();
/* 588 */         paramName = helper.getValueOf(annotation);
/* 589 */       } else if (Encoded.class == annotation.annotationType()) {
/* 590 */         paramEncoded = true;
/* 591 */       } else if (DefaultValue.class == annotation.annotationType()) {
/* 592 */         paramDefault = ((DefaultValue)annotation).value();
/*     */       } else {
/* 594 */         paramAnnotation = annotation;
/* 595 */         paramSource = Parameter.Source.UNKNOWN;
/* 596 */         paramName = getValue(annotation);
/*     */       }
/*     */     }
/*     */     
/* 600 */     if (paramAnnotation == null) {
/* 601 */       paramSource = Parameter.Source.ENTITY;
/*     */     }
/*     */     
/* 604 */     ReflectionHelper.ClassTypePair ct = getGenericType(concreteClass, declaringClass, paramClass, paramType);
/* 605 */     paramType = ct.t;
/* 606 */     paramClass = ct.c;
/*     */     
/* 608 */     return new Parameter(annotations, paramAnnotation, paramSource, paramName, paramType, paramClass, paramEncoded, paramDefault);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static String getValue(Annotation a)
/*     */   {
/*     */     try
/*     */     {
/* 617 */       Method m = a.annotationType().getMethod("value", new Class[0]);
/* 618 */       if (m.getReturnType() != String.class)
/* 619 */         return null;
/* 620 */       return (String)m.invoke(a, new Object[0]);
/*     */     }
/*     */     catch (Exception ex) {}
/* 623 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ReflectionHelper.ClassTypePair getGenericType(Class concreteClass, Class declaringClass, Class c, Type t)
/*     */   {
/* 631 */     if ((t instanceof TypeVariable)) {
/* 632 */       ReflectionHelper.ClassTypePair ct = ReflectionHelper.resolveTypeVariable(concreteClass, declaringClass, (TypeVariable)t);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 637 */       if (ct != null) {
/* 638 */         return ct;
/*     */       }
/* 640 */     } else if ((t instanceof ParameterizedType)) {
/* 641 */       final ParameterizedType pt = (ParameterizedType)t;
/* 642 */       Type[] ptts = pt.getActualTypeArguments();
/* 643 */       boolean modified = false;
/* 644 */       for (int i = 0; i < ptts.length; i++) {
/* 645 */         ReflectionHelper.ClassTypePair ct = getGenericType(concreteClass, declaringClass, (Class)pt.getRawType(), ptts[i]);
/*     */         
/* 647 */         if (ct.t != ptts[i]) {
/* 648 */           ptts[i] = ct.t;
/* 649 */           modified = true;
/*     */         }
/*     */       }
/* 652 */       if (modified) {
/* 653 */         ParameterizedType rpt = new ParameterizedType()
/*     */         {
/*     */           public Type[] getActualTypeArguments() {
/* 656 */             return (Type[])this.val$ptts.clone();
/*     */           }
/*     */           
/*     */           public Type getRawType()
/*     */           {
/* 661 */             return pt.getRawType();
/*     */           }
/*     */           
/*     */           public Type getOwnerType()
/*     */           {
/* 666 */             return pt.getOwnerType();
/*     */           }
/* 668 */         };
/* 669 */         return new ReflectionHelper.ClassTypePair((Class)pt.getRawType(), rpt);
/*     */       }
/* 671 */     } else if ((t instanceof GenericArrayType)) {
/* 672 */       GenericArrayType gat = (GenericArrayType)t;
/* 673 */       ReflectionHelper.ClassTypePair ct = getGenericType(concreteClass, declaringClass, null, gat.getGenericComponentType());
/*     */       
/* 675 */       if (gat.getGenericComponentType() != ct.t) {
/*     */         try {
/* 677 */           Class ac = ReflectionHelper.getArrayClass(ct.c);
/* 678 */           return new ReflectionHelper.ClassTypePair(ac, ac);
/*     */         }
/*     */         catch (Exception e) {}
/*     */       }
/*     */     }
/*     */     
/* 684 */     return new ReflectionHelper.ClassTypePair(c, t);
/*     */   }
/*     */   
/*     */   private static abstract interface ParamAnnotationHelper<T extends Annotation>
/*     */   {
/*     */     public abstract String getValueOf(T paramT);
/*     */     
/*     */     public abstract Parameter.Source getSource();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\modelapi\annotation\IntrospectionModeller.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */