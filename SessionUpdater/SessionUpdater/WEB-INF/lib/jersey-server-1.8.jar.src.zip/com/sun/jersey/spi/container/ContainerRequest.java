/*     */ package com.sun.jersey.spi.container;
/*     */ 
/*     */ import com.sun.jersey.api.MessageException;
/*     */ import com.sun.jersey.api.Responses;
/*     */ import com.sun.jersey.api.container.MappableContainerException;
/*     */ import com.sun.jersey.api.core.HttpRequestContext;
/*     */ import com.sun.jersey.api.core.TraceInformation;
/*     */ import com.sun.jersey.api.representation.Form;
/*     */ import com.sun.jersey.api.uri.UriComponent;
/*     */ import com.sun.jersey.api.uri.UriComponent.Type;
/*     */ import com.sun.jersey.core.header.AcceptableLanguageTag;
/*     */ import com.sun.jersey.core.header.InBoundHeaders;
/*     */ import com.sun.jersey.core.header.MatchingEntityTag;
/*     */ import com.sun.jersey.core.header.MediaTypes;
/*     */ import com.sun.jersey.core.header.QualitySourceMediaType;
/*     */ import com.sun.jersey.core.header.reader.HttpHeaderReader;
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*     */ import com.sun.jersey.core.util.FeaturesAndProperties;
/*     */ import com.sun.jersey.core.util.MultivaluedMapImpl;
/*     */ import com.sun.jersey.core.util.ReaderWriter;
/*     */ import com.sun.jersey.server.impl.VariantSelector;
/*     */ import com.sun.jersey.server.impl.model.HttpHelper;
/*     */ import com.sun.jersey.spi.MessageBodyWorkers;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.URI;
/*     */ import java.security.Principal;
/*     */ import java.text.ParseException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Logger;
/*     */ import javax.ws.rs.WebApplicationException;
/*     */ import javax.ws.rs.core.Cookie;
/*     */ import javax.ws.rs.core.EntityTag;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.core.PathSegment;
/*     */ import javax.ws.rs.core.Response;
/*     */ import javax.ws.rs.core.Response.ResponseBuilder;
/*     */ import javax.ws.rs.core.SecurityContext;
/*     */ import javax.ws.rs.core.UriBuilder;
/*     */ import javax.ws.rs.core.Variant;
/*     */ import javax.ws.rs.ext.MessageBodyReader;
/*     */ import javax.ws.rs.ext.MessageBodyWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContainerRequest
/*     */   implements HttpRequestContext
/*     */ {
/* 111 */   private static final Logger LOGGER = Logger.getLogger(ContainerRequest.class.getName());
/*     */   
/* 113 */   private static final Annotation[] EMPTY_ANNOTATIONS = new Annotation[0];
/*     */   
/*     */ 
/*     */   public static final String VARY_HEADER = "Vary";
/*     */   
/*     */ 
/*     */   private final WebApplication wa;
/*     */   
/*     */ 
/*     */   private final boolean isTraceEnabled;
/*     */   
/*     */ 
/*     */   private Map<String, Object> properties;
/*     */   
/*     */ 
/*     */   private String method;
/*     */   
/*     */ 
/*     */   private InputStream entity;
/*     */   
/*     */ 
/*     */   private URI baseUri;
/*     */   
/*     */ 
/*     */   private URI requestUri;
/*     */   
/*     */ 
/*     */   private URI absolutePathUri;
/*     */   
/*     */ 
/*     */   private String encodedPath;
/*     */   
/*     */ 
/*     */   private String decodedPath;
/*     */   
/*     */ 
/*     */   private List<PathSegment> decodedPathSegments;
/*     */   
/*     */ 
/*     */   private List<PathSegment> encodedPathSegments;
/*     */   
/*     */ 
/*     */   private MultivaluedMap<String, String> decodedQueryParameters;
/*     */   
/*     */ 
/*     */   private MultivaluedMap<String, String> encodedQueryParameters;
/*     */   
/*     */ 
/*     */   private InBoundHeaders headers;
/*     */   
/*     */ 
/*     */   private int headersModCount;
/*     */   
/*     */ 
/*     */   private MediaType contentType;
/*     */   
/*     */ 
/*     */   private List<MediaType> accept;
/*     */   
/*     */ 
/*     */   private List<Locale> acceptLanguages;
/*     */   
/*     */ 
/*     */   private Map<String, Cookie> cookies;
/*     */   
/*     */ 
/*     */   private MultivaluedMap<String, String> cookieNames;
/*     */   
/*     */   private SecurityContext securityContext;
/*     */   
/*     */ 
/*     */   public ContainerRequest(WebApplication wa, String method, URI baseUri, URI requestUri, InBoundHeaders headers, InputStream entity)
/*     */   {
/* 186 */     this.wa = wa;
/* 187 */     this.isTraceEnabled = wa.isTracingEnabled();
/* 188 */     this.method = method;
/* 189 */     this.baseUri = baseUri;
/* 190 */     this.requestUri = requestUri;
/* 191 */     this.headers = headers;
/* 192 */     this.headersModCount = headers.getModCount();
/* 193 */     this.entity = entity;
/*     */   }
/*     */   
/*     */   ContainerRequest(ContainerRequest r) {
/* 197 */     this.wa = r.wa;
/* 198 */     this.isTraceEnabled = r.isTraceEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, Object> getProperties()
/*     */   {
/* 212 */     if (this.properties != null) {
/* 213 */       return this.properties;
/*     */     }
/*     */     
/* 216 */     return this.properties = new HashMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMethod(String method)
/*     */   {
/* 225 */     this.method = method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUris(URI baseUri, URI requestUri)
/*     */   {
/* 235 */     this.baseUri = baseUri;
/* 236 */     this.requestUri = requestUri;
/*     */     
/*     */ 
/* 239 */     this.absolutePathUri = null;
/*     */     
/* 241 */     this.encodedPath = (this.decodedPath = null);
/*     */     
/* 243 */     this.decodedPathSegments = (this.encodedPathSegments = null);
/*     */     
/* 245 */     this.decodedQueryParameters = (this.encodedQueryParameters = null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputStream getEntityInputStream()
/*     */   {
/* 254 */     return this.entity;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEntityInputStream(InputStream entity)
/*     */   {
/* 263 */     this.entity = entity;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeaders(InBoundHeaders headers)
/*     */   {
/* 272 */     this.headers = headers;
/* 273 */     this.headersModCount = headers.getModCount();
/*     */     
/*     */ 
/* 276 */     this.contentType = null;
/* 277 */     this.accept = null;
/* 278 */     this.cookies = null;
/* 279 */     this.cookieNames = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSecurityContext(SecurityContext securityContext)
/*     */   {
/* 288 */     this.securityContext = securityContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MessageBodyWorkers getMessageBodyWorkers()
/*     */   {
/* 297 */     return this.wa.getMessageBodyWorkers();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isTracingEnabled()
/*     */   {
/* 303 */     return this.isTraceEnabled;
/*     */   }
/*     */   
/*     */   public void trace(String message)
/*     */   {
/* 308 */     if (!isTracingEnabled()) {
/* 309 */       return;
/*     */     }
/* 311 */     if ((this.wa.getFeaturesAndProperties().getFeature("com.sun.jersey.config.feature.TracePerRequest")) && (!getRequestHeaders().containsKey("X-Jersey-Trace-Accept")))
/*     */     {
/* 313 */       return;
/*     */     }
/* 315 */     TraceInformation ti = (TraceInformation)getProperties().get(TraceInformation.class.getName());
/*     */     
/* 317 */     ti.trace(message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public URI getBaseUri()
/*     */   {
/* 324 */     return this.baseUri;
/*     */   }
/*     */   
/*     */   public UriBuilder getBaseUriBuilder()
/*     */   {
/* 329 */     return UriBuilder.fromUri(getBaseUri());
/*     */   }
/*     */   
/*     */   public URI getRequestUri()
/*     */   {
/* 334 */     return this.requestUri;
/*     */   }
/*     */   
/*     */   public UriBuilder getRequestUriBuilder()
/*     */   {
/* 339 */     return UriBuilder.fromUri(getRequestUri());
/*     */   }
/*     */   
/*     */   public URI getAbsolutePath()
/*     */   {
/* 344 */     if (this.absolutePathUri != null) { return this.absolutePathUri;
/*     */     }
/* 346 */     return this.absolutePathUri = UriBuilder.fromUri(this.requestUri).replaceQuery("").fragment("").build(new Object[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public UriBuilder getAbsolutePathBuilder()
/*     */   {
/* 353 */     return UriBuilder.fromUri(getAbsolutePath());
/*     */   }
/*     */   
/*     */   public String getPath()
/*     */   {
/* 358 */     return getPath(true);
/*     */   }
/*     */   
/*     */   public String getPath(boolean decode)
/*     */   {
/* 363 */     if (decode) {
/* 364 */       if (this.decodedPath != null) { return this.decodedPath;
/*     */       }
/* 366 */       return this.decodedPath = UriComponent.decode(getEncodedPath(), UriComponent.Type.PATH);
/*     */     }
/*     */     
/*     */ 
/* 370 */     return getEncodedPath();
/*     */   }
/*     */   
/*     */   private String getEncodedPath()
/*     */   {
/* 375 */     if (this.encodedPath != null) { return this.encodedPath;
/*     */     }
/* 377 */     return this.encodedPath = getRequestUri().getRawPath().substring(getBaseUri().getRawPath().length());
/*     */   }
/*     */   
/*     */ 
/*     */   public List<PathSegment> getPathSegments()
/*     */   {
/* 383 */     return getPathSegments(true);
/*     */   }
/*     */   
/*     */   public List<PathSegment> getPathSegments(boolean decode)
/*     */   {
/* 388 */     if (decode) {
/* 389 */       if (this.decodedPathSegments != null) {
/* 390 */         return this.decodedPathSegments;
/*     */       }
/* 392 */       return this.decodedPathSegments = UriComponent.decodePath(getPath(false), true);
/*     */     }
/* 394 */     if (this.encodedPathSegments != null) {
/* 395 */       return this.encodedPathSegments;
/*     */     }
/* 397 */     return this.encodedPathSegments = UriComponent.decodePath(getPath(false), false);
/*     */   }
/*     */   
/*     */ 
/*     */   public MultivaluedMap<String, String> getQueryParameters()
/*     */   {
/* 403 */     return getQueryParameters(true);
/*     */   }
/*     */   
/*     */   public MultivaluedMap<String, String> getQueryParameters(boolean decode)
/*     */   {
/* 408 */     if (decode) {
/* 409 */       if (this.decodedQueryParameters != null) {
/* 410 */         return this.decodedQueryParameters;
/*     */       }
/* 412 */       return this.decodedQueryParameters = UriComponent.decodeQuery(getRequestUri(), true);
/*     */     }
/*     */     
/* 415 */     if (this.encodedQueryParameters != null) {
/* 416 */       return this.encodedQueryParameters;
/*     */     }
/* 418 */     return this.encodedQueryParameters = UriComponent.decodeQuery(getRequestUri(), false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getHeaderValue(String name)
/*     */   {
/* 425 */     List<String> v = (List)getRequestHeaders().get(name);
/*     */     
/* 427 */     if (v == null) { return null;
/*     */     }
/* 429 */     if (v.isEmpty()) { return "";
/*     */     }
/* 431 */     if (v.size() == 1) { return (String)v.get(0);
/*     */     }
/* 433 */     StringBuilder sb = new StringBuilder((String)v.get(0));
/* 434 */     for (int i = 1; i < v.size(); i++) {
/* 435 */       String s = (String)v.get(i);
/* 436 */       if (s.length() > 0)
/* 437 */         sb.append(',').append(s);
/*     */     }
/* 439 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public <T> T getEntity(Class<T> type, Type genericType, Annotation[] as)
/*     */   {
/* 444 */     MediaType mediaType = getMediaType();
/* 445 */     if (mediaType == null) {
/* 446 */       mediaType = MediaType.APPLICATION_OCTET_STREAM_TYPE;
/*     */     }
/*     */     
/* 449 */     MessageBodyReader<T> bw = getMessageBodyWorkers().getMessageBodyReader(type, genericType, as, mediaType);
/*     */     
/*     */ 
/* 452 */     if (bw == null) {
/* 453 */       String message = "A message body reader for Java class " + type.getName() + ", and Java type " + genericType + ", and MIME media type " + mediaType + " was not found.\n";
/*     */       
/*     */ 
/* 456 */       Map<MediaType, List<MessageBodyReader>> m = getMessageBodyWorkers().getReaders(mediaType);
/*     */       
/* 458 */       message = message + "The registered message body readers compatible with the MIME media type are:\n" + getMessageBodyWorkers().readersToString(m);
/*     */       
/* 460 */       LOGGER.severe(message);
/* 461 */       throw new WebApplicationException(new MessageException(message), Responses.unsupportedMediaType().build());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 466 */     if (isTracingEnabled()) {
/* 467 */       trace(String.format("matched message body reader: %s, \"%s\" -> %s", new Object[] { genericType, mediaType, ReflectionHelper.objectToString(bw) }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 474 */       return (T)bw.readFrom(type, genericType, as, mediaType, this.headers, this.entity);
/*     */     } catch (WebApplicationException ex) {
/* 476 */       throw ex;
/*     */     } catch (Exception e) {
/* 478 */       throw new MappableContainerException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> void setEntity(Class<T> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, T entity)
/*     */   {
/* 502 */     MessageBodyWriter<T> writer = getMessageBodyWorkers().getMessageBodyWriter(type, genericType, annotations, mediaType);
/*     */     
/* 504 */     if (writer == null) {
/* 505 */       String message = "A message body writer for Java class " + type.getName() + ", and Java type " + genericType + ", and MIME media type " + mediaType + " was not found.\n";
/*     */       
/*     */ 
/* 508 */       Map<MediaType, List<MessageBodyReader>> m = getMessageBodyWorkers().getReaders(mediaType);
/*     */       
/* 510 */       message = message + "The registered message body readers compatible with the MIME media type are:\n" + getMessageBodyWorkers().readersToString(m);
/*     */       
/* 512 */       LOGGER.severe(message);
/* 513 */       throw new WebApplicationException(new MessageException(message), Responses.unsupportedMediaType().build());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 518 */     if (isTracingEnabled()) {
/* 519 */       trace(String.format("matched message body writer: %s, \"%s\" -> %s", new Object[] { genericType, mediaType, ReflectionHelper.objectToString(writer) }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 525 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */     try
/*     */     {
/* 528 */       writer.writeTo(entity, type, genericType, annotations, mediaType, httpHeaders, byteArrayOutputStream);
/*     */     } catch (IOException e) {
/* 530 */       throw new MappableContainerException(e);
/*     */     }
/*     */     
/* 533 */     this.entity = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
/*     */   }
/*     */   
/*     */   public <T> T getEntity(Class<T> type)
/*     */   {
/* 538 */     return (T)getEntity(type, type, EMPTY_ANNOTATIONS);
/*     */   }
/*     */   
/*     */   public MediaType getAcceptableMediaType(List<MediaType> mediaTypes)
/*     */   {
/* 543 */     if (mediaTypes.isEmpty()) {
/* 544 */       return (MediaType)getAcceptableMediaTypes().get(0);
/*     */     }
/* 546 */     for (Iterator i$ = getAcceptableMediaTypes().iterator(); i$.hasNext();) { a = (MediaType)i$.next();
/* 547 */       if (a.getType().equals("*")) {
/* 548 */         return (MediaType)mediaTypes.get(0);
/*     */       }
/* 550 */       for (MediaType m : mediaTypes)
/* 551 */         if ((m.isCompatible(a)) && (!m.isWildcardType()) && (!m.isWildcardSubtype()))
/* 552 */           return m; }
/*     */     MediaType a;
/* 554 */     return null;
/*     */   }
/*     */   
/*     */   public List<MediaType> getAcceptableMediaTypes(List<QualitySourceMediaType> priorityMediaTypes)
/*     */   {
/* 559 */     return new ArrayList(HttpHelper.getAccept(this, priorityMediaTypes));
/*     */   }
/*     */   
/*     */   public MultivaluedMap<String, String> getCookieNameValueMap()
/*     */   {
/* 564 */     if ((this.cookieNames == null) || (this.headersModCount != this.headers.getModCount())) {
/* 565 */       this.cookieNames = new MultivaluedMapImpl();
/* 566 */       for (Map.Entry<String, Cookie> e : getCookies().entrySet()) {
/* 567 */         this.cookieNames.putSingle(e.getKey(), ((Cookie)e.getValue()).getValue());
/*     */       }
/*     */     }
/*     */     
/* 571 */     return this.cookieNames;
/*     */   }
/*     */   
/*     */   public Form getFormParameters()
/*     */   {
/* 576 */     if (MediaTypes.typeEquals(MediaType.APPLICATION_FORM_URLENCODED_TYPE, getMediaType())) {
/* 577 */       InputStream in = getEntityInputStream();
/* 578 */       if (in.getClass() != ByteArrayInputStream.class)
/*     */       {
/* 580 */         ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */         try {
/* 582 */           ReaderWriter.writeTo(in, byteArrayOutputStream);
/*     */         } catch (IOException e) {
/* 584 */           throw new IllegalArgumentException(e);
/*     */         }
/*     */         
/* 587 */         in = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
/* 588 */         setEntityInputStream(in);
/*     */       }
/*     */       
/* 591 */       ByteArrayInputStream byteArrayInputStream = (ByteArrayInputStream)in;
/* 592 */       Form f = (Form)getEntity(Form.class);
/* 593 */       byteArrayInputStream.reset();
/* 594 */       return f;
/*     */     }
/* 596 */     return new Form();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MultivaluedMap<String, String> getRequestHeaders()
/*     */   {
/* 604 */     return this.headers;
/*     */   }
/*     */   
/*     */   public List<String> getRequestHeader(String name)
/*     */   {
/* 609 */     return (List)this.headers.get(name);
/*     */   }
/*     */   
/*     */   public List<MediaType> getAcceptableMediaTypes()
/*     */   {
/* 614 */     if ((this.accept == null) || (this.headersModCount != this.headers.getModCount())) {
/* 615 */       this.accept = new ArrayList(HttpHelper.getAccept(this));
/*     */     }
/* 617 */     return this.accept;
/*     */   }
/*     */   
/*     */   public List<Locale> getAcceptableLanguages()
/*     */   {
/* 622 */     if ((this.acceptLanguages == null) || (this.headersModCount != this.headers.getModCount())) {
/* 623 */       List<AcceptableLanguageTag> alts = HttpHelper.getAcceptLangauge(this);
/*     */       
/* 625 */       this.acceptLanguages = new ArrayList(alts.size());
/* 626 */       for (AcceptableLanguageTag alt : alts) {
/* 627 */         this.acceptLanguages.add(alt.getAsLocale());
/*     */       }
/*     */     }
/*     */     
/* 631 */     return this.acceptLanguages;
/*     */   }
/*     */   
/*     */   public MediaType getMediaType()
/*     */   {
/* 636 */     if ((this.contentType == null) || (this.headersModCount != this.headers.getModCount())) {
/* 637 */       this.contentType = HttpHelper.getContentType(this);
/*     */     }
/* 639 */     return this.contentType;
/*     */   }
/*     */   
/*     */   public Locale getLanguage()
/*     */   {
/* 644 */     return HttpHelper.getContentLanguageAsLocale(this);
/*     */   }
/*     */   
/*     */   public Map<String, Cookie> getCookies()
/*     */   {
/* 649 */     if ((this.cookies == null) || (this.headersModCount != this.headers.getModCount())) {
/* 650 */       this.cookies = new HashMap();
/*     */       
/* 652 */       List<String> cl = (List)getRequestHeaders().get("Cookie");
/* 653 */       if (cl != null) {
/* 654 */         for (String cookie : cl) {
/* 655 */           if (cookie != null) {
/* 656 */             this.cookies.putAll(HttpHeaderReader.readCookies(cookie));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 662 */     return this.cookies;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getMethod()
/*     */   {
/* 669 */     return this.method;
/*     */   }
/*     */   
/*     */   public Variant selectVariant(List<Variant> variants)
/*     */   {
/* 674 */     if ((variants == null) || (variants.isEmpty())) {
/* 675 */       throw new IllegalArgumentException("The list of variants is null or empty");
/*     */     }
/*     */     
/*     */ 
/* 679 */     return VariantSelector.selectVariant(this, variants);
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder evaluatePreconditions()
/*     */   {
/* 684 */     Set<MatchingEntityTag> matchingTags = HttpHelper.getIfMatch(this);
/* 685 */     if (matchingTags == null) {
/* 686 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 691 */     return Responses.preconditionFailed();
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder evaluatePreconditions(EntityTag eTag)
/*     */   {
/* 696 */     Response.ResponseBuilder r = evaluateIfMatch(eTag);
/* 697 */     if (r != null) {
/* 698 */       return r;
/*     */     }
/* 700 */     return evaluateIfNoneMatch(eTag);
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder evaluatePreconditions(Date lastModified)
/*     */   {
/* 705 */     long lastModifiedTime = lastModified.getTime();
/* 706 */     Response.ResponseBuilder r = evaluateIfUnmodifiedSince(lastModifiedTime);
/* 707 */     if (r != null) {
/* 708 */       return r;
/*     */     }
/* 710 */     return evaluateIfModifiedSince(lastModifiedTime);
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder evaluatePreconditions(Date lastModified, EntityTag eTag)
/*     */   {
/* 715 */     Response.ResponseBuilder r = evaluateIfMatch(eTag);
/* 716 */     if (r != null) {
/* 717 */       return r;
/*     */     }
/* 719 */     long lastModifiedTime = lastModified.getTime();
/* 720 */     r = evaluateIfUnmodifiedSince(lastModifiedTime);
/* 721 */     if (r != null) {
/* 722 */       return r;
/*     */     }
/* 724 */     boolean isGetOrHead = (getMethod().equals("GET")) || (getMethod().equals("HEAD"));
/* 725 */     Set<MatchingEntityTag> matchingTags = HttpHelper.getIfNoneMatch(this);
/* 726 */     if (matchingTags != null) {
/* 727 */       r = evaluateIfNoneMatch(eTag, matchingTags, isGetOrHead);
/*     */       
/*     */ 
/* 730 */       if (r == null) {
/* 731 */         return r;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 738 */     String ifModifiedSinceHeader = (String)getRequestHeaders().getFirst("If-Modified-Since");
/* 739 */     if ((ifModifiedSinceHeader != null) && (isGetOrHead)) {
/* 740 */       r = evaluateIfModifiedSince(lastModifiedTime, ifModifiedSinceHeader);
/* 741 */       if (r != null) {
/* 742 */         r.tag(eTag);
/*     */       }
/*     */     }
/* 745 */     return r;
/*     */   }
/*     */   
/*     */   private Response.ResponseBuilder evaluateIfMatch(EntityTag eTag) {
/* 749 */     Set<MatchingEntityTag> matchingTags = HttpHelper.getIfMatch(this);
/* 750 */     if (matchingTags == null) {
/* 751 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 757 */     if (eTag.isWeak()) {
/* 758 */       return Responses.preconditionFailed();
/*     */     }
/*     */     
/* 761 */     if ((matchingTags != MatchingEntityTag.ANY_MATCH) && (!matchingTags.contains(eTag)))
/*     */     {
/*     */ 
/* 764 */       return Responses.preconditionFailed();
/*     */     }
/*     */     
/* 767 */     return null;
/*     */   }
/*     */   
/*     */   private Response.ResponseBuilder evaluateIfNoneMatch(EntityTag eTag) {
/* 771 */     Set<MatchingEntityTag> matchingTags = HttpHelper.getIfNoneMatch(this);
/* 772 */     if (matchingTags == null) {
/* 773 */       return null;
/*     */     }
/* 775 */     String httpMethod = getMethod();
/* 776 */     return evaluateIfNoneMatch(eTag, matchingTags, (httpMethod.equals("GET")) || (httpMethod.equals("HEAD")));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Response.ResponseBuilder evaluateIfNoneMatch(EntityTag eTag, Set<MatchingEntityTag> matchingTags, boolean isGetOrHead)
/*     */   {
/* 786 */     if (isGetOrHead) {
/* 787 */       if (matchingTags == MatchingEntityTag.ANY_MATCH)
/*     */       {
/* 789 */         return Response.notModified(eTag);
/*     */       }
/*     */       
/*     */ 
/* 793 */       if (!matchingTags.contains(eTag)) { if (!matchingTags.contains(new EntityTag(eTag.getValue(), !eTag.isWeak()))) {}
/*     */       } else {
/* 795 */         return Response.notModified(eTag);
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 803 */       if (eTag.isWeak()) {
/* 804 */         return null;
/*     */       }
/*     */       
/* 807 */       if ((matchingTags == MatchingEntityTag.ANY_MATCH) || (matchingTags.contains(eTag)))
/*     */       {
/* 809 */         return Responses.preconditionFailed();
/*     */       }
/*     */     }
/*     */     
/* 813 */     return null;
/*     */   }
/*     */   
/*     */   private Response.ResponseBuilder evaluateIfUnmodifiedSince(long lastModified) {
/* 817 */     String ifUnmodifiedSinceHeader = (String)getRequestHeaders().getFirst("If-Unmodified-Since");
/* 818 */     if (ifUnmodifiedSinceHeader != null) {
/*     */       try {
/* 820 */         long ifUnmodifiedSince = HttpHeaderReader.readDate(ifUnmodifiedSinceHeader).getTime();
/* 821 */         if (roundDown(lastModified) > ifUnmodifiedSince)
/*     */         {
/* 823 */           return Responses.preconditionFailed();
/*     */         }
/*     */       }
/*     */       catch (ParseException ex) {}
/*     */     }
/*     */     
/*     */ 
/* 830 */     return null;
/*     */   }
/*     */   
/*     */   private Response.ResponseBuilder evaluateIfModifiedSince(long lastModified) {
/* 834 */     String ifModifiedSinceHeader = (String)getRequestHeaders().getFirst("If-Modified-Since");
/* 835 */     if (ifModifiedSinceHeader == null) {
/* 836 */       return null;
/*     */     }
/* 838 */     String httpMethod = getMethod();
/* 839 */     if ((httpMethod.equals("GET")) || (httpMethod.equals("HEAD"))) {
/* 840 */       return evaluateIfModifiedSince(lastModified, ifModifiedSinceHeader);
/*     */     }
/*     */     
/*     */ 
/* 844 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   private Response.ResponseBuilder evaluateIfModifiedSince(long lastModified, String ifModifiedSinceHeader)
/*     */   {
/*     */     try
/*     */     {
/* 852 */       long ifModifiedSince = HttpHeaderReader.readDate(ifModifiedSinceHeader).getTime();
/* 853 */       if (roundDown(lastModified) <= ifModifiedSince)
/*     */       {
/* 855 */         return Responses.notModified();
/*     */       }
/*     */     }
/*     */     catch (ParseException ex) {}
/*     */     
/*     */ 
/* 861 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static long roundDown(long time)
/*     */   {
/* 871 */     return time - time % 1000L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Principal getUserPrincipal()
/*     */   {
/* 878 */     if (this.securityContext == null)
/* 879 */       throw new UnsupportedOperationException();
/* 880 */     return this.securityContext.getUserPrincipal();
/*     */   }
/*     */   
/*     */   public boolean isUserInRole(String role)
/*     */   {
/* 885 */     if (this.securityContext == null)
/* 886 */       throw new UnsupportedOperationException();
/* 887 */     return this.securityContext.isUserInRole(role);
/*     */   }
/*     */   
/*     */   public boolean isSecure()
/*     */   {
/* 892 */     if (this.securityContext == null)
/* 893 */       throw new UnsupportedOperationException();
/* 894 */     return this.securityContext.isSecure();
/*     */   }
/*     */   
/*     */   public String getAuthenticationScheme()
/*     */   {
/* 899 */     if (this.securityContext == null)
/* 900 */       throw new UnsupportedOperationException();
/* 901 */     return this.securityContext.getAuthenticationScheme();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\container\ContainerRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */