/*     */ package com.sun.jersey.api.container.filter;
/*     */ 
/*     */ import com.sun.jersey.api.container.ContainerException;
/*     */ import com.sun.jersey.spi.container.ContainerRequest;
/*     */ import com.sun.jersey.spi.container.ContainerRequestFilter;
/*     */ import com.sun.jersey.spi.container.ContainerResponse;
/*     */ import com.sun.jersey.spi.container.ContainerResponseFilter;
/*     */ import com.sun.jersey.spi.container.ContainerResponseWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import java.util.zip.GZIPOutputStream;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GZIPContentEncodingFilter
/*     */   implements ContainerRequestFilter, ContainerResponseFilter
/*     */ {
/*     */   public ContainerRequest filter(ContainerRequest request)
/*     */   {
/*  83 */     if ((request.getRequestHeaders().containsKey("Content-Encoding")) && 
/*  84 */       (((String)request.getRequestHeaders().getFirst("Content-Encoding")).trim().equals("gzip"))) {
/*  85 */       request.getRequestHeaders().remove("Content-Encoding");
/*     */       try {
/*  87 */         request.setEntityInputStream(new GZIPInputStream(request.getEntityInputStream()));
/*     */       }
/*     */       catch (IOException ex) {
/*  90 */         throw new ContainerException(ex);
/*     */       }
/*     */     }
/*     */     
/*  94 */     return request;
/*     */   }
/*     */   
/*     */   private static final class Adapter implements ContainerResponseWriter
/*     */   {
/*     */     private final ContainerResponseWriter crw;
/*     */     private GZIPOutputStream gos;
/*     */     
/*     */     Adapter(ContainerResponseWriter crw) {
/* 103 */       this.crw = crw;
/*     */     }
/*     */     
/*     */     public OutputStream writeStatusAndHeaders(long contentLength, ContainerResponse response) throws IOException {
/* 107 */       this.gos = new GZIPOutputStream(this.crw.writeStatusAndHeaders(-1L, response));
/* 108 */       return this.gos;
/*     */     }
/*     */     
/*     */     public void finish() throws IOException {
/* 112 */       this.gos.finish();
/* 113 */       this.crw.finish();
/*     */     }
/*     */   }
/*     */   
/*     */   public ContainerResponse filter(ContainerRequest request, ContainerResponse response) {
/* 118 */     if ((response.getEntity() != null) && (request.getRequestHeaders().containsKey("Accept-Encoding")) && (!response.getHttpHeaders().containsKey("Content-Encoding")))
/*     */     {
/*     */ 
/* 121 */       if (((String)request.getRequestHeaders().getFirst("Accept-Encoding")).contains("gzip")) {
/* 122 */         response.getHttpHeaders().add("Content-Encoding", "gzip");
/* 123 */         response.setContainerResponseWriter(new Adapter(response.getContainerResponseWriter()));
/*     */       }
/*     */     }
/*     */     
/* 127 */     return response;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\container\filter\GZIPContentEncodingFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */