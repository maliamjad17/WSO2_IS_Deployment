/*     */ package com.sun.jersey.server.wadl.generators;
/*     */ 
/*     */ import com.sun.jersey.api.model.AbstractMethod;
/*     */ import com.sun.jersey.api.model.AbstractResource;
/*     */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*     */ import com.sun.jersey.api.model.Parameter;
/*     */ import com.sun.jersey.server.wadl.WadlGenerator;
/*     */ import com.sun.research.ws.wadl.Application;
/*     */ import com.sun.research.ws.wadl.Grammars;
/*     */ import com.sun.research.ws.wadl.Method;
/*     */ import com.sun.research.ws.wadl.Param;
/*     */ import com.sun.research.ws.wadl.RepresentationType;
/*     */ import com.sun.research.ws.wadl.Request;
/*     */ import com.sun.research.ws.wadl.Resource;
/*     */ import com.sun.research.ws.wadl.Resources;
/*     */ import com.sun.research.ws.wadl.Response;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.util.List;
/*     */ import java.util.logging.Logger;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.xml.bind.JAXBContext;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WadlGeneratorGrammarsSupport
/*     */   implements WadlGenerator
/*     */ {
/*  86 */   private static final Logger LOG = Logger.getLogger(WadlGeneratorGrammarsSupport.class.getName());
/*     */   
/*     */   private WadlGenerator _delegate;
/*     */   
/*     */   private File _grammarsFile;
/*     */   private InputStream _grammarsStream;
/*     */   private Grammars _grammars;
/*     */   
/*     */   public WadlGeneratorGrammarsSupport() {}
/*     */   
/*     */   public WadlGeneratorGrammarsSupport(WadlGenerator delegate, Grammars grammars)
/*     */   {
/*  98 */     this._delegate = delegate;
/*  99 */     this._grammars = grammars;
/*     */   }
/*     */   
/*     */   public void setWadlGeneratorDelegate(WadlGenerator delegate) {
/* 103 */     this._delegate = delegate;
/*     */   }
/*     */   
/*     */   public String getRequiredJaxbContextPath() {
/* 107 */     return this._delegate.getRequiredJaxbContextPath();
/*     */   }
/*     */   
/*     */   public void setGrammarsFile(File grammarsFile) {
/* 111 */     if (this._grammarsStream != null) {
/* 112 */       throw new IllegalStateException("The grammarsStream property is already set, therefore you cannot set the grammarsFile property. Only one of both can be set at a time.");
/*     */     }
/*     */     
/* 115 */     this._grammarsFile = grammarsFile;
/*     */   }
/*     */   
/*     */   public void setGrammarsStream(InputStream grammarsStream) {
/* 119 */     if (this._grammarsFile != null) {
/* 120 */       throw new IllegalStateException("The grammarsFile property is already set, therefore you cannot set the grammarsStream property. Only one of both can be set at a time.");
/*     */     }
/*     */     
/* 123 */     this._grammarsStream = grammarsStream;
/*     */   }
/*     */   
/*     */   public void init() throws Exception {
/* 127 */     if ((this._grammarsFile == null) && (this._grammarsStream == null)) {
/* 128 */       throw new IllegalStateException("Neither the grammarsFile nor the grammarsStream is set, one of both is required.");
/*     */     }
/*     */     
/* 131 */     this._delegate.init();
/* 132 */     JAXBContext c = JAXBContext.newInstance(new Class[] { Grammars.class });
/* 133 */     Unmarshaller m = c.createUnmarshaller();
/* 134 */     Object obj = this._grammarsFile != null ? m.unmarshal(this._grammarsFile) : m.unmarshal(this._grammarsStream);
/* 135 */     this._grammars = ((Grammars)Grammars.class.cast(obj));
/*     */   }
/*     */   
/*     */   private <T> T loadFile(InputStream fileToLoad, Class<T> targetClass) throws JAXBException {
/* 139 */     JAXBContext c = JAXBContext.newInstance(new Class[] { targetClass });
/* 140 */     Unmarshaller m = c.createUnmarshaller();
/* 141 */     return (T)targetClass.cast(m.unmarshal(fileToLoad));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Application createApplication()
/*     */   {
/* 149 */     Application result = this._delegate.createApplication();
/* 150 */     if (result.getGrammars() != null) {
/* 151 */       LOG.info("The wadl application created by the delegate (" + this._delegate + ") already contains a grammars element," + " we're adding elements of the provided grammars file.");
/*     */       
/* 153 */       if (!this._grammars.getAny().isEmpty()) {
/* 154 */         result.getGrammars().getAny().addAll(this._grammars.getAny());
/*     */       }
/* 156 */       if (!this._grammars.getDoc().isEmpty()) {
/* 157 */         result.getGrammars().getDoc().addAll(this._grammars.getDoc());
/*     */       }
/* 159 */       if (!this._grammars.getInclude().isEmpty()) {
/* 160 */         result.getGrammars().getInclude().addAll(this._grammars.getInclude());
/*     */       }
/*     */     }
/*     */     else {
/* 164 */       result.setGrammars(this._grammars);
/*     */     }
/* 166 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Method createMethod(AbstractResource ar, AbstractResourceMethod arm)
/*     */   {
/* 177 */     return this._delegate.createMethod(ar, arm);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Request createRequest(AbstractResource ar, AbstractResourceMethod arm)
/*     */   {
/* 188 */     return this._delegate.createRequest(ar, arm);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Param createParam(AbstractResource ar, AbstractMethod am, Parameter p)
/*     */   {
/* 200 */     return this._delegate.createParam(ar, am, p);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RepresentationType createRequestRepresentation(AbstractResource ar, AbstractResourceMethod arm, MediaType mt)
/*     */   {
/* 212 */     return this._delegate.createRequestRepresentation(ar, arm, mt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Resource createResource(AbstractResource ar, String path)
/*     */   {
/* 222 */     return this._delegate.createResource(ar, path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Resources createResources()
/*     */   {
/* 230 */     return this._delegate.createResources();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Response createResponse(AbstractResource ar, AbstractResourceMethod arm)
/*     */   {
/* 241 */     return this._delegate.createResponse(ar, arm);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\wadl\generators\WadlGeneratorGrammarsSupport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */