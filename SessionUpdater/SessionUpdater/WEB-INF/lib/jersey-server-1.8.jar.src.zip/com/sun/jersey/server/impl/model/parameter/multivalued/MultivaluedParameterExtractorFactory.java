/*     */ package com.sun.jersey.server.impl.model.parameter.multivalued;
/*     */ 
/*     */ import com.sun.jersey.api.container.ContainerException;
/*     */ import com.sun.jersey.api.model.Parameter;
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper.TypeClassPair;
/*     */ import com.sun.jersey.impl.ImplMessages;
/*     */ import com.sun.jersey.spi.StringReader;
/*     */ import com.sun.jersey.spi.StringReaderWorkers;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MultivaluedParameterExtractorFactory
/*     */   implements MultivaluedParameterExtractorProvider
/*     */ {
/*     */   private final StringReaderWorkers w;
/*     */   
/*     */   public MultivaluedParameterExtractorFactory(StringReaderWorkers w)
/*     */   {
/*  65 */     this.w = w;
/*     */   }
/*     */   
/*     */   public MultivaluedParameterExtractor getWithoutDefaultValue(Parameter p)
/*     */   {
/*  70 */     return process(this.w, null, p.getParameterClass(), p.getParameterType(), p.getAnnotations(), p.getSourceName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MultivaluedParameterExtractor get(Parameter p)
/*     */   {
/*  81 */     return process(this.w, p.getDefaultValue(), p.getParameterClass(), p.getParameterType(), p.getAnnotations(), p.getSourceName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private MultivaluedParameterExtractor process(StringReaderWorkers w, String defaultValue, Class<?> parameter, Type parameterType, Annotation[] annotations, String parameterName)
/*     */   {
/*  98 */     if ((parameter == List.class) || (parameter == Set.class) || (parameter == SortedSet.class))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 103 */       ReflectionHelper.TypeClassPair tcp = ReflectionHelper.getTypeArgumentAndClass(parameterType);
/* 104 */       if ((tcp == null) || (tcp.c == String.class)) {
/* 105 */         return CollectionStringExtractor.getInstance(parameter, parameterName, defaultValue);
/*     */       }
/*     */       
/* 108 */       StringReader sr = w.getStringReader(tcp.c, tcp.t, annotations);
/* 109 */       if (sr == null) {
/* 110 */         return null;
/*     */       }
/*     */       try {
/* 113 */         return CollectionStringReaderExtractor.getInstance(parameter, sr, parameterName, defaultValue);
/*     */       }
/*     */       catch (Exception e) {
/* 116 */         throw new ContainerException("Could not process parameter type " + parameter, e);
/*     */       }
/*     */     }
/* 119 */     if (parameter == String.class)
/* 120 */       return new StringExtractor(parameterName, defaultValue);
/* 121 */     if (parameter.isPrimitive())
/*     */     {
/* 123 */       parameter = (Class)PrimitiveMapper.primitiveToClassMap.get(parameter);
/* 124 */       if (parameter == null)
/*     */       {
/* 126 */         return null;
/*     */       }
/*     */       
/*     */ 
/* 130 */       Method valueOf = ReflectionHelper.getValueOfStringMethod(parameter);
/* 131 */       if (valueOf != null) {
/*     */         try {
/* 133 */           Object defaultDefaultValue = PrimitiveMapper.primitiveToDefaultValueMap.get(parameter);
/* 134 */           return new PrimitiveValueOfExtractor(valueOf, parameterName, defaultValue, defaultDefaultValue);
/*     */         }
/*     */         catch (Exception e) {
/* 137 */           throw new ContainerException(ImplMessages.DEFAULT_COULD_NOT_PROCESS_METHOD(defaultValue, valueOf));
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 142 */       StringReader sr = w.getStringReader(parameter, parameterType, annotations);
/* 143 */       if (sr == null) {
/* 144 */         return null;
/*     */       }
/*     */       try {
/* 147 */         return new StringReaderExtractor(sr, parameterName, defaultValue);
/*     */       } catch (Exception e) {
/* 149 */         throw new ContainerException("Could not process parameter type " + parameter, e);
/*     */       }
/*     */     }
/*     */     
/* 153 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\parameter\multivalued\MultivaluedParameterExtractorFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */