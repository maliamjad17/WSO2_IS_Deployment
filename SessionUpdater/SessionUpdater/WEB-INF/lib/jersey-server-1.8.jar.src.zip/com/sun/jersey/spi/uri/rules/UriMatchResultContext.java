package com.sun.jersey.spi.uri.rules;

import com.sun.jersey.api.core.Traceable;
import java.util.regex.MatchResult;

public abstract interface UriMatchResultContext
  extends Traceable
{
  public abstract MatchResult getMatchResult();
  
  public abstract void setMatchResult(MatchResult paramMatchResult);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\uri\rules\UriMatchResultContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */