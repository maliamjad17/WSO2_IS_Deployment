/*    */ package com.sun.jersey.api.model;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AbstractResourceConstructor
/*    */   implements Parameterized, AbstractModelComponent
/*    */ {
/*    */   private Constructor ctor;
/*    */   private List<Parameter> parameters;
/*    */   
/*    */   public AbstractResourceConstructor(Constructor constructor)
/*    */   {
/* 58 */     this.ctor = constructor;
/* 59 */     this.parameters = new ArrayList();
/*    */   }
/*    */   
/*    */   public List<Parameter> getParameters() {
/* 63 */     return this.parameters;
/*    */   }
/*    */   
/*    */   public Constructor getCtor() {
/* 67 */     return this.ctor;
/*    */   }
/*    */   
/*    */   public void accept(AbstractModelVisitor visitor) {
/* 71 */     visitor.visitAbstractResourceConstructor(this);
/*    */   }
/*    */   
/*    */   public List<AbstractModelComponent> getComponents() {
/* 75 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\model\AbstractResourceConstructor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */