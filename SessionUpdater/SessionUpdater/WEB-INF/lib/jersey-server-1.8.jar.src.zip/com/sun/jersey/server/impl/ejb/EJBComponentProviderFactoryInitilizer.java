/*    */ package com.sun.jersey.server.impl.ejb;
/*    */ 
/*    */ import com.sun.jersey.api.core.ResourceConfig;
/*    */ import com.sun.jersey.server.impl.InitialContextHelper;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Set;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ import javax.naming.InitialContext;
/*    */ import javax.naming.NamingException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class EJBComponentProviderFactoryInitilizer
/*    */ {
/* 55 */   private static final Logger LOGGER = Logger.getLogger(EJBComponentProviderFactoryInitilizer.class.getName());
/*    */   
/*    */   public static void initialize(ResourceConfig rc)
/*    */   {
/*    */     try {
/* 60 */       InitialContext ic = InitialContextHelper.getInitialContext();
/* 61 */       if (ic == null) {
/* 62 */         return;
/*    */       }
/* 64 */       Object interceptorBinder = ic.lookup("java:org.glassfish.ejb.container.interceptor_binding_spi");
/*    */       
/*    */ 
/*    */ 
/*    */ 
/* 69 */       if (interceptorBinder == null) {
/* 70 */         LOGGER.config("The EJB interceptor binding API is not available. JAX-RS EJB support is disabled.");
/* 71 */         return;
/*    */       }
/*    */       
/* 74 */       Method interceptorBinderMethod = interceptorBinder.getClass().getMethod("registerInterceptor", new Class[] { Object.class });
/*    */       
/*    */ 
/* 77 */       EJBInjectionInterceptor interceptor = new EJBInjectionInterceptor();
/*    */       try
/*    */       {
/* 80 */         interceptorBinderMethod.invoke(interceptorBinder, new Object[] { interceptor });
/*    */       } catch (Exception ex) {
/* 82 */         LOGGER.log(Level.SEVERE, "Error when configuring to use the EJB interceptor binding API. JAX-RS EJB support is disabled.", ex);
/* 83 */         return;
/*    */       }
/*    */       
/* 86 */       rc.getSingletons().add(new EJBComponentProviderFactory(interceptor));
/* 87 */       rc.getClasses().add(EJBExceptionMapper.class);
/*    */     } catch (NamingException ex) {
/* 89 */       LOGGER.log(Level.CONFIG, "The EJB interceptor binding API is not available. JAX-RS EJB support is disabled.", ex);
/*    */     } catch (NoSuchMethodException ex) {
/* 91 */       LOGGER.log(Level.SEVERE, "The EJB interceptor binding API does not conform to what is expected. JAX-RS EJB support is disabled.", ex);
/*    */     } catch (SecurityException ex) {
/* 93 */       LOGGER.log(Level.SEVERE, "Security issue when configuring to use the EJB interceptor binding API. JAX-RS EJB support is disabled.", ex);
/*    */     } catch (LinkageError ex) {
/* 95 */       LOGGER.log(Level.SEVERE, "Linkage error when configuring to use the EJB interceptor binding API. JAX-RS EJB support is disabled.", ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\ejb\EJBComponentProviderFactoryInitilizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */