/*    */ package com.sun.jersey.api.model;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AbstractSetterMethod
/*    */   extends AbstractMethod
/*    */   implements Parameterized, AbstractModelComponent
/*    */ {
/*    */   private List<Parameter> parameters;
/*    */   
/*    */   public AbstractSetterMethod(AbstractResource resource, Method method, Annotation[] annotations)
/*    */   {
/* 55 */     super(resource, method, annotations);
/* 56 */     this.parameters = new ArrayList();
/*    */   }
/*    */   
/*    */   public List<Parameter> getParameters() {
/* 60 */     return this.parameters;
/*    */   }
/*    */   
/*    */   public void accept(AbstractModelVisitor visitor) {
/* 64 */     visitor.visitAbstractSetterMethod(this);
/*    */   }
/*    */   
/*    */   public List<AbstractModelComponent> getComponents() {
/* 68 */     return null;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 73 */     return "AbstractSetterMethod(" + getMethod().getDeclaringClass().getSimpleName() + "#" + getMethod().getName() + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\model\AbstractSetterMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */