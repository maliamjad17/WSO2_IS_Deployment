/*    */ package com.sun.jersey.server.impl.cdi;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Member;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import javax.enterprise.inject.spi.AnnotatedCallable;
/*    */ import javax.enterprise.inject.spi.AnnotatedParameter;
/*    */ import javax.enterprise.inject.spi.AnnotatedType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnotatedCallableImpl<T>
/*    */   extends AnnotatedMemberImpl<T>
/*    */   implements AnnotatedCallable<T>
/*    */ {
/*    */   private List<AnnotatedParameter<T>> parameters;
/*    */   
/*    */   public AnnotatedCallableImpl(Type baseType, Set<Type> typeClosure, Set<Annotation> annotations, AnnotatedType<T> declaringType, Member javaMember, boolean isStatic)
/*    */   {
/* 67 */     super(baseType, typeClosure, annotations, declaringType, javaMember, isStatic);
/*    */   }
/*    */   
/*    */   public List<AnnotatedParameter<T>> getParameters() {
/* 71 */     return this.parameters;
/*    */   }
/*    */   
/*    */   public void setParameters(List<AnnotatedParameter<T>> parameters) {
/* 75 */     this.parameters = parameters;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\cdi\AnnotatedCallableImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */