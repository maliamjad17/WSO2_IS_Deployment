/*     */ package com.sun.jersey.server.impl.uri.rules;
/*     */ 
/*     */ import com.sun.jersey.api.uri.UriPattern;
/*     */ import com.sun.jersey.spi.uri.rules.UriMatchResultContext;
/*     */ import com.sun.jersey.spi.uri.rules.UriRules;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.regex.MatchResult;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AtomicMatchingPatterns<R>
/*     */   implements UriRules<R>
/*     */ {
/*     */   private final Collection<PatternRulePair<R>> rules;
/*     */   
/*     */   public AtomicMatchingPatterns(Collection<PatternRulePair<R>> rules)
/*     */   {
/*  64 */     this.rules = rules;
/*     */   }
/*     */   
/*     */   public Iterator<R> match(CharSequence path, UriMatchResultContext resultContext) {
/*  68 */     if (resultContext.isTracingEnabled()) {
/*  69 */       StringBuilder sb = new StringBuilder();
/*  70 */       sb.append("match path \"").append(path).append("\" -> ");
/*  71 */       boolean first = true;
/*  72 */       for (PatternRulePair<R> prp : this.rules) {
/*  73 */         if (!first)
/*  74 */           sb.append(", ");
/*  75 */         sb.append("\"").append(prp.p.toString()).append("\"");
/*  76 */         first = false;
/*     */       }
/*  78 */       resultContext.trace(sb.toString());
/*     */     }
/*     */     
/*  81 */     for (PatternRulePair<R> prp : this.rules)
/*     */     {
/*  83 */       MatchResult mr = prp.p.match(path);
/*  84 */       if (mr != null) {
/*  85 */         resultContext.setMatchResult(mr);
/*  86 */         return new SingleEntryIterator(prp.r);
/*     */       }
/*     */     }
/*     */     
/*  90 */     return new EmptyIterator(null);
/*     */   }
/*     */   
/*     */   private static final class SingleEntryIterator<T> implements Iterator<T> {
/*     */     private T t;
/*     */     
/*     */     SingleEntryIterator(T t) {
/*  97 */       this.t = t;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 101 */       return this.t != null;
/*     */     }
/*     */     
/*     */     public T next() {
/* 105 */       if (hasNext()) {
/* 106 */         T _t = this.t;
/* 107 */         this.t = null;
/* 108 */         return _t;
/*     */       }
/* 110 */       throw new NoSuchElementException();
/*     */     }
/*     */     
/*     */     public void remove()
/*     */     {
/* 115 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class EmptyIterator<T> implements Iterator<T> {
/*     */     public boolean hasNext() {
/* 121 */       return false;
/*     */     }
/*     */     
/*     */     public T next() {
/* 125 */       throw new NoSuchElementException();
/*     */     }
/*     */     
/*     */     public void remove() {
/* 129 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\uri\rules\AtomicMatchingPatterns.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */