package com.sun.jersey.spi.monitoring;

import com.sun.jersey.spi.container.ContainerResponse;
import javax.ws.rs.ext.ExceptionMapper;

public abstract interface ResponseListener
{
  public abstract void onError(long paramLong, Throwable paramThrowable);
  
  public abstract void onResponse(long paramLong, ContainerResponse paramContainerResponse);
  
  public abstract void onMappedException(long paramLong, Throwable paramThrowable, ExceptionMapper paramExceptionMapper);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\monitoring\ResponseListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */