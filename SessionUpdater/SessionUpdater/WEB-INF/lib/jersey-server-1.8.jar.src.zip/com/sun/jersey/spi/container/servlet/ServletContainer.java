/*     */ package com.sun.jersey.spi.container.servlet;
/*     */ 
/*     */ import com.sun.jersey.api.container.ContainerException;
/*     */ import com.sun.jersey.api.core.ResourceConfig;
/*     */ import com.sun.jersey.api.uri.UriComponent;
/*     */ import com.sun.jersey.api.uri.UriComponent.Type;
/*     */ import com.sun.jersey.server.impl.application.DeferredResourceConfig;
/*     */ import com.sun.jersey.spi.container.ContainerNotifier;
/*     */ import com.sun.jersey.spi.container.ReloadListener;
/*     */ import com.sun.jersey.spi.container.WebApplication;
/*     */ import com.sun.jersey.spi.container.WebApplicationFactory;
/*     */ import com.sun.jersey.spi.inject.SingletonTypeInjectableProvider;
/*     */ import com.sun.jersey.spi.service.ServiceFinder;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.regex.PatternSyntaxException;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.ws.rs.core.Application;
/*     */ import javax.ws.rs.core.Context;
/*     */ import javax.ws.rs.core.UriBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletContainer
/*     */   extends HttpServlet
/*     */   implements Filter
/*     */ {
/*     */   public static final String GLASSFISH_DEFAULT_ERROR_PAGE_RESPONSE = "org.glassfish.web.isDefaultErrorPageEnabled";
/*     */   public static final String APPLICATION_CONFIG_CLASS = "javax.ws.rs.Application";
/*     */   public static final String RESOURCE_CONFIG_CLASS = "com.sun.jersey.config.property.resourceConfigClass";
/*     */   public static final String JSP_TEMPLATES_BASE_PATH = "com.sun.jersey.config.property.JSPTemplatesBasePath";
/*     */   public static final String PROPERTY_WEB_PAGE_CONTENT_REGEX = "com.sun.jersey.config.property.WebPageContentRegex";
/*     */   public static final String FEATURE_FILTER_FORWARD_ON_404 = "com.sun.jersey.config.feature.FilterForwardOn404";
/*     */   public static final String PROPERTY_FILTER_CONTEXT_PATH = "com.sun.jersey.config.feature.FilterContextPath";
/*     */   private transient WebComponent webComponent;
/*     */   private transient FilterConfig filterConfig;
/*     */   private transient Pattern staticContentPattern;
/*     */   private transient boolean forwardOn404;
/*     */   private final transient Application app;
/*     */   
/*     */   protected static class ContextInjectableProvider<T>
/*     */     extends SingletonTypeInjectableProvider<Context, T>
/*     */   {
/*     */     protected ContextInjectableProvider(Type type, T instance)
/*     */     {
/* 283 */       super(instance);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private class InternalWebComponent
/*     */     extends WebComponent
/*     */   {
/*     */     InternalWebComponent() {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     InternalWebComponent(Application app)
/*     */     {
/* 301 */       super();
/*     */     }
/*     */     
/*     */     protected WebApplication create()
/*     */     {
/* 306 */       return ServletContainer.this.create();
/*     */     }
/*     */     
/*     */     protected void configure(WebConfig wc, ResourceConfig rc, WebApplication wa)
/*     */     {
/* 311 */       super.configure(wc, rc, wa);
/*     */       
/* 313 */       ServletContainer.this.configure(wc, rc, wa);
/*     */     }
/*     */     
/*     */     protected void initiate(ResourceConfig rc, WebApplication wa)
/*     */     {
/* 318 */       ServletContainer.this.initiate(rc, wa);
/*     */     }
/*     */     
/*     */     protected ResourceConfig getDefaultResourceConfig(Map<String, Object> props, WebConfig wc)
/*     */       throws ServletException
/*     */     {
/* 324 */       return ServletContainer.this.getDefaultResourceConfig(props, wc);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public ServletContainer()
/*     */   {
/* 331 */     this.app = null;
/*     */   }
/*     */   
/*     */   public ServletContainer(Class<? extends Application> appClass) {
/* 335 */     this.app = new DeferredResourceConfig(appClass);
/*     */   }
/*     */   
/*     */   public ServletContainer(Application app) {
/* 339 */     this.app = app;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletContext getServletContext()
/*     */   {
/* 356 */     if (this.filterConfig != null) {
/* 357 */       return this.filterConfig.getServletContext();
/*     */     }
/* 359 */     return super.getServletContext();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void init(WebConfig webConfig)
/*     */     throws ServletException
/*     */   {
/* 370 */     this.webComponent = (this.app == null ? new InternalWebComponent() : new InternalWebComponent(this.app));
/*     */     
/*     */ 
/* 373 */     this.webComponent.init(webConfig);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected WebConfig getWebConfig()
/*     */   {
/* 382 */     return this.webComponent.getWebConfig();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected WebApplication create()
/*     */   {
/* 391 */     return WebApplicationFactory.createWebApplication();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResourceConfig getDefaultResourceConfig(Map<String, Object> props, WebConfig wc)
/*     */     throws ServletException
/*     */   {
/* 414 */     return this.webComponent.getWebAppResourceConfig(props, wc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void configure(WebConfig wc, ResourceConfig rc, WebApplication wa)
/*     */   {
/* 450 */     if (getServletConfig() != null) {
/* 451 */       configure(getServletConfig(), rc, wa);
/* 452 */     } else if (this.filterConfig != null) {
/* 453 */       configure(this.filterConfig, rc, wa);
/*     */     }
/* 455 */     if ((rc instanceof ReloadListener)) {
/* 456 */       List<ContainerNotifier> notifiers = new ArrayList();
/*     */       
/* 458 */       Object o = rc.getProperties().get("com.sun.jersey.spi.container.ContainerNotifier");
/*     */       
/* 460 */       if ((o instanceof ContainerNotifier)) {
/* 461 */         notifiers.add((ContainerNotifier)o);
/* 462 */       } else if ((o instanceof List)) {
/* 463 */         for (Object elem : (List)o)
/* 464 */           if ((elem instanceof ContainerNotifier))
/* 465 */             notifiers.add((ContainerNotifier)elem);
/*     */       }
/* 467 */       for (ContainerNotifier cn : ServiceFinder.find(ContainerNotifier.class)) {
/* 468 */         notifiers.add(cn);
/*     */       }
/*     */       
/* 471 */       rc.getProperties().put("com.sun.jersey.spi.container.ContainerNotifier", notifiers);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initiate(ResourceConfig rc, WebApplication wa)
/*     */   {
/* 488 */     wa.initiate(rc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void load()
/*     */   {
/* 496 */     this.webComponent.load();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reload()
/*     */   {
/* 514 */     this.webComponent.onReload();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int service(URI baseUri, URI requestUri, HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 537 */     return this.webComponent.service(baseUri, requestUri, request, response);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 546 */     if (this.webComponent != null) {
/* 547 */       this.webComponent.destroy();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void init()
/*     */     throws ServletException
/*     */   {
/* 556 */     init(new WebServletConfig(this));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected ResourceConfig getDefaultResourceConfig(Map<String, Object> props, ServletConfig servletConfig)
/*     */     throws ServletException
/*     */   {
/* 581 */     return getDefaultResourceConfig(props, getWebConfig());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void configure(ServletConfig sc, ResourceConfig rc, WebApplication wa)
/*     */   {
/* 609 */     rc.getSingletons().add(new ContextInjectableProvider(ServletConfig.class, sc));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void service(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 636 */     String servletPath = request.getServletPath();
/* 637 */     String pathInfo = request.getPathInfo();
/* 638 */     StringBuffer requestURL = request.getRequestURL();
/* 639 */     String requestURI = request.getRequestURI();
/* 640 */     boolean checkPathInfo = (pathInfo == null) || (pathInfo.isEmpty()) || (pathInfo.equals("/"));
/* 641 */     boolean checkServletPath = (servletPath == null) || (servletPath.isEmpty());
/* 642 */     if ((checkPathInfo) && (checkServletPath) && (!request.getRequestURI().endsWith("/"))) {
/* 643 */       if (this.webComponent.getResourceConfig().getFeature("com.sun.jersey.config.feature.Redirect")) {
/* 644 */         URI l = UriBuilder.fromUri(request.getRequestURL().toString()).path("/").replaceQuery(request.getQueryString()).build(new Object[0]);
/*     */         
/*     */ 
/*     */ 
/* 648 */         response.setStatus(307);
/* 649 */         response.setHeader("Location", l.toASCIIString());
/* 650 */         return;
/*     */       }
/* 652 */       pathInfo = "/";
/* 653 */       requestURL.append("/");
/* 654 */       requestURI = requestURI + "/";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 662 */     UriBuilder absoluteUriBuilder = UriBuilder.fromUri(requestURL.toString());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 675 */     String decodedBasePath = request.getContextPath() + "/";
/*     */     
/*     */ 
/*     */ 
/* 679 */     String encodedBasePath = UriComponent.encode(decodedBasePath, UriComponent.Type.PATH);
/*     */     
/*     */ 
/* 682 */     if (!decodedBasePath.equals(encodedBasePath)) {
/* 683 */       throw new ContainerException("The servlet context path and/or the servlet path contain characters that are percent encoded");
/*     */     }
/*     */     
/*     */ 
/* 687 */     URI baseUri = absoluteUriBuilder.replacePath(encodedBasePath).build(new Object[0]);
/*     */     
/*     */ 
/* 690 */     String queryParameters = request.getQueryString();
/* 691 */     if (queryParameters == null) {
/* 692 */       queryParameters = "";
/*     */     }
/*     */     
/* 695 */     URI requestUri = absoluteUriBuilder.replacePath(requestURI).replaceQuery(queryParameters).build(new Object[0]);
/*     */     
/*     */ 
/*     */ 
/* 699 */     service(baseUri, requestUri, request, response);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 705 */   private String filterContextPath = null;
/*     */   
/*     */   public void init(FilterConfig filterConfig) throws ServletException {
/* 708 */     this.filterConfig = filterConfig;
/*     */     
/* 710 */     init(new WebFilterConfig(filterConfig));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pattern getStaticContentPattern()
/*     */   {
/* 720 */     return this.staticContentPattern;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void configure(FilterConfig fc, ResourceConfig rc, WebApplication wa)
/*     */   {
/* 748 */     rc.getSingletons().add(new ContextInjectableProvider(FilterConfig.class, fc));
/*     */     
/*     */ 
/* 751 */     String regex = (String)rc.getProperty("com.sun.jersey.config.property.WebPageContentRegex");
/* 752 */     if ((regex != null) && (regex.length() > 0)) {
/*     */       try {
/* 754 */         this.staticContentPattern = Pattern.compile(regex);
/*     */       } catch (PatternSyntaxException ex) {
/* 756 */         throw new ContainerException("The syntax is invalid for the regular expression, " + regex + ", associated with the initialization parameter " + "com.sun.jersey.config.property.WebPageContentRegex", ex);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 762 */     this.forwardOn404 = rc.getFeature("com.sun.jersey.config.feature.FilterForwardOn404");
/*     */     
/* 764 */     this.filterContextPath = this.filterConfig.getInitParameter("com.sun.jersey.config.feature.FilterContextPath");
/* 765 */     if (this.filterContextPath != null) {
/* 766 */       if (this.filterContextPath.isEmpty()) {
/* 767 */         this.filterContextPath = null;
/*     */       } else {
/* 769 */         if (!this.filterContextPath.startsWith("/")) {
/* 770 */           this.filterContextPath = ('/' + this.filterContextPath);
/*     */         }
/* 772 */         if (this.filterContextPath.endsWith("/")) {
/* 773 */           this.filterContextPath = this.filterContextPath.substring(0, this.filterContextPath.length() - 1);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/*     */     try
/*     */     {
/* 795 */       doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
/*     */     } catch (ClassCastException e) {
/* 797 */       throw new ServletException("non-HTTP request or response");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/* 822 */     if (request.getAttribute("javax.servlet.include.request_uri") != null) {
/* 823 */       String includeRequestURI = (String)request.getAttribute("javax.servlet.include.request_uri");
/*     */       
/* 825 */       if (!includeRequestURI.equals(request.getRequestURI())) {
/* 826 */         doFilter(request, response, chain, includeRequestURI, (String)request.getAttribute("javax.servlet.include.servlet_path"), (String)request.getAttribute("javax.servlet.include.query_string"));
/*     */         
/*     */ 
/*     */ 
/* 830 */         return;
/*     */       }
/*     */     }
/*     */     
/* 834 */     doFilter(request, response, chain, request.getRequestURI(), request.getServletPath(), request.getQueryString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain, String requestURI, String servletPath, String queryString)
/*     */     throws IOException, ServletException
/*     */   {
/* 844 */     Pattern p = getStaticContentPattern();
/* 845 */     if ((p != null) && (p.matcher(servletPath).matches())) {
/* 846 */       chain.doFilter(request, response);
/* 847 */       return;
/*     */     }
/*     */     
/* 850 */     if (this.filterContextPath != null) {
/* 851 */       if (!servletPath.startsWith(this.filterContextPath)) {
/* 852 */         throw new ContainerException("The servlet path, \"" + servletPath + "\", does not start with the filter context path, \"" + this.filterContextPath + "\"");
/*     */       }
/* 854 */       if (servletPath.length() == this.filterContextPath.length())
/*     */       {
/* 856 */         if (this.webComponent.getResourceConfig().getFeature("com.sun.jersey.config.feature.Redirect")) {
/* 857 */           URI l = UriBuilder.fromUri(request.getRequestURL().toString()).path("/").replaceQuery(queryString).build(new Object[0]);
/*     */           
/*     */ 
/*     */ 
/* 861 */           response.setStatus(307);
/* 862 */           response.setHeader("Location", l.toASCIIString());
/* 863 */           return;
/*     */         }
/* 865 */         requestURI = requestURI + "/";
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 870 */     UriBuilder absoluteUriBuilder = UriBuilder.fromUri(request.getRequestURL().toString());
/*     */     
/*     */ 
/* 873 */     URI baseUri = this.filterContextPath == null ? absoluteUriBuilder.replacePath(request.getContextPath()).path("/").build(new Object[0]) : absoluteUriBuilder.replacePath(request.getContextPath()).path(this.filterContextPath).path("/").build(new Object[0]);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 882 */     URI requestUri = absoluteUriBuilder.replacePath(requestURI).replaceQuery(queryString).build(new Object[0]);
/*     */     
/*     */ 
/*     */ 
/* 886 */     int status = service(baseUri, requestUri, request, response);
/*     */     
/*     */ 
/*     */ 
/* 890 */     if ((this.forwardOn404) && (status == 404) && (!response.isCommitted()))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 899 */       response.setStatus(200);
/* 900 */       chain.doFilter(request, response);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\container\servlet\ServletContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */