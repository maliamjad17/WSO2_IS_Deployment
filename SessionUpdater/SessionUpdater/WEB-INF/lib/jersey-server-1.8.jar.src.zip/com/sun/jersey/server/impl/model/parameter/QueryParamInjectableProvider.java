/*    */ package com.sun.jersey.server.impl.model.parameter;
/*    */ 
/*    */ import com.sun.jersey.api.ParamException.QueryParamException;
/*    */ import com.sun.jersey.api.core.ExtendedUriInfo;
/*    */ import com.sun.jersey.api.core.HttpContext;
/*    */ import com.sun.jersey.api.model.Parameter;
/*    */ import com.sun.jersey.core.spi.component.ComponentContext;
/*    */ import com.sun.jersey.server.impl.inject.AbstractHttpContextInjectable;
/*    */ import com.sun.jersey.server.impl.model.parameter.multivalued.ExtractorContainerException;
/*    */ import com.sun.jersey.server.impl.model.parameter.multivalued.MultivaluedParameterExtractor;
/*    */ import com.sun.jersey.server.impl.model.parameter.multivalued.MultivaluedParameterExtractorProvider;
/*    */ import com.sun.jersey.spi.inject.Injectable;
/*    */ import javax.ws.rs.QueryParam;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class QueryParamInjectableProvider
/*    */   extends BaseParamInjectableProvider<QueryParam>
/*    */ {
/*    */   private static final class QueryParamInjectable
/*    */     extends AbstractHttpContextInjectable<Object>
/*    */   {
/*    */     private final MultivaluedParameterExtractor extractor;
/*    */     private final boolean decode;
/*    */     
/*    */     QueryParamInjectable(MultivaluedParameterExtractor extractor, boolean decode)
/*    */     {
/* 66 */       this.extractor = extractor;
/* 67 */       this.decode = decode;
/*    */     }
/*    */     
/*    */     public Object getValue(HttpContext context) {
/*    */       try {
/* 72 */         return this.extractor.extract(context.getUriInfo().getQueryParameters(this.decode));
/*    */       } catch (ExtractorContainerException e) {
/* 74 */         throw new ParamException.QueryParamException(e.getCause(), this.extractor.getName(), this.extractor.getDefaultStringValue());
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public QueryParamInjectableProvider(MultivaluedParameterExtractorProvider w)
/*    */   {
/* 81 */     super(w);
/*    */   }
/*    */   
/*    */   public Injectable getInjectable(ComponentContext ic, QueryParam a, Parameter c) {
/* 85 */     String parameterName = c.getSourceName();
/* 86 */     if ((parameterName == null) || (parameterName.length() == 0))
/*    */     {
/* 88 */       return null;
/*    */     }
/*    */     
/* 91 */     MultivaluedParameterExtractor e = get(c);
/* 92 */     if (e == null) {
/* 93 */       return null;
/*    */     }
/* 95 */     return new QueryParamInjectable(e, !c.isEncoded());
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\parameter\QueryParamInjectableProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */