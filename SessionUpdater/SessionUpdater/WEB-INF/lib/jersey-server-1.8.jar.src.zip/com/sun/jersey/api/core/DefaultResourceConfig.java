/*     */ package com.sun.jersey.api.core;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultResourceConfig
/*     */   extends ResourceConfig
/*     */ {
/*  60 */   private final Set<Class<?>> classes = new LinkedHashSet();
/*     */   
/*  62 */   private final Set<Object> singletons = new LinkedHashSet(1);
/*     */   
/*  64 */   private final Map<String, MediaType> mediaExtentions = new HashMap(1);
/*     */   
/*  66 */   private final Map<String, String> languageExtentions = new HashMap(1);
/*     */   
/*  68 */   private final Map<String, Object> explicitRootResources = new HashMap(1);
/*     */   
/*  70 */   private final Map<String, Boolean> features = new HashMap();
/*     */   
/*  72 */   private final Map<String, Object> properties = new HashMap();
/*     */   
/*     */ 
/*     */   public DefaultResourceConfig()
/*     */   {
/*  77 */     this((Set)null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultResourceConfig(Class<?>... classes)
/*     */   {
/*  85 */     this(new LinkedHashSet(Arrays.asList(classes)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultResourceConfig(Set<Class<?>> classes)
/*     */   {
/*  93 */     if (null != classes) {
/*  94 */       this.classes.addAll(classes);
/*     */     }
/*     */   }
/*     */   
/*     */   public Set<Class<?>> getClasses()
/*     */   {
/* 100 */     return this.classes;
/*     */   }
/*     */   
/*     */   public Set<Object> getSingletons()
/*     */   {
/* 105 */     return this.singletons;
/*     */   }
/*     */   
/*     */   public Map<String, MediaType> getMediaTypeMappings()
/*     */   {
/* 110 */     return this.mediaExtentions;
/*     */   }
/*     */   
/*     */   public Map<String, String> getLanguageMappings()
/*     */   {
/* 115 */     return this.languageExtentions;
/*     */   }
/*     */   
/*     */   public Map<String, Object> getExplicitRootResources()
/*     */   {
/* 120 */     return this.explicitRootResources;
/*     */   }
/*     */   
/*     */   public Map<String, Boolean> getFeatures()
/*     */   {
/* 125 */     return this.features;
/*     */   }
/*     */   
/*     */   public boolean getFeature(String featureName)
/*     */   {
/* 130 */     Boolean v = (Boolean)this.features.get(featureName);
/* 131 */     return v != null ? v.booleanValue() : false;
/*     */   }
/*     */   
/*     */   public Map<String, Object> getProperties()
/*     */   {
/* 136 */     return this.properties;
/*     */   }
/*     */   
/*     */   public Object getProperty(String propertyName)
/*     */   {
/* 141 */     return this.properties.get(propertyName);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\core\DefaultResourceConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */