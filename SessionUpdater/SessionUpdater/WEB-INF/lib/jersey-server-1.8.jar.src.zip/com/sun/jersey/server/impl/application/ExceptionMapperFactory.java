/*     */ package com.sun.jersey.server.impl.application;
/*     */ 
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper.ClassTypePair;
/*     */ import com.sun.jersey.core.spi.component.ProviderServices;
/*     */ import com.sun.jersey.spi.container.ExceptionMapperContext;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.ws.rs.ext.ExceptionMapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExceptionMapperFactory
/*     */   implements ExceptionMapperContext
/*     */ {
/*     */   private static class ExceptionMapperType
/*     */   {
/*     */     ExceptionMapper em;
/*     */     Class<? extends Throwable> c;
/*     */     
/*     */     public ExceptionMapperType(ExceptionMapper em, Class<? extends Throwable> c)
/*     */     {
/*  63 */       this.em = em;
/*  64 */       this.c = c;
/*     */     }
/*     */   }
/*     */   
/*  68 */   private Set<ExceptionMapperType> emts = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*     */   public void init(ProviderServices providerServices)
/*     */   {
/*  74 */     for (ExceptionMapper em : providerServices.getProviders(ExceptionMapper.class)) {
/*  75 */       Class<? extends Throwable> c = getExceptionType(em.getClass());
/*  76 */       if (c != null) {
/*  77 */         this.emts.add(new ExceptionMapperType(em, c));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public ExceptionMapper find(Class<? extends Throwable> c)
/*     */   {
/*  85 */     int distance = Integer.MAX_VALUE;
/*  86 */     ExceptionMapper selectedEm = null;
/*  87 */     for (ExceptionMapperType emt : this.emts) {
/*  88 */       int d = distance(c, emt.c);
/*  89 */       if (d < distance) {
/*  90 */         distance = d;
/*  91 */         selectedEm = emt.em;
/*  92 */         if (distance == 0)
/*     */           break;
/*     */       }
/*     */     }
/*  96 */     return selectedEm;
/*     */   }
/*     */   
/*     */   private int distance(Class<?> c, Class<?> emtc) {
/* 100 */     int distance = 0;
/* 101 */     if (!emtc.isAssignableFrom(c)) {
/* 102 */       return Integer.MAX_VALUE;
/*     */     }
/* 104 */     while (c != emtc) {
/* 105 */       c = c.getSuperclass();
/* 106 */       distance++;
/*     */     }
/*     */     
/* 109 */     return distance;
/*     */   }
/*     */   
/*     */   private Class<? extends Throwable> getExceptionType(Class<? extends ExceptionMapper> c)
/*     */   {
/* 114 */     Class<?> t = getType(c);
/* 115 */     if (Throwable.class.isAssignableFrom(t)) {
/* 116 */       return t;
/*     */     }
/*     */     
/* 119 */     return null;
/*     */   }
/*     */   
/*     */   private Class getType(Class<? extends ExceptionMapper> c) {
/* 123 */     Class _c = c;
/* 124 */     while (_c != Object.class) {
/* 125 */       Type[] ts = _c.getGenericInterfaces();
/* 126 */       for (Type t : ts) {
/* 127 */         if ((t instanceof ParameterizedType)) {
/* 128 */           ParameterizedType pt = (ParameterizedType)t;
/* 129 */           if (pt.getRawType() == ExceptionMapper.class) {
/* 130 */             return getResolvedType(pt.getActualTypeArguments()[0], c, _c);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 135 */       _c = _c.getSuperclass();
/*     */     }
/*     */     
/*     */ 
/* 139 */     return null;
/*     */   }
/*     */   
/*     */   private Class getResolvedType(Type t, Class c, Class dc) {
/* 143 */     if ((t instanceof Class))
/* 144 */       return (Class)t;
/* 145 */     if ((t instanceof TypeVariable)) {
/* 146 */       ReflectionHelper.ClassTypePair ct = ReflectionHelper.resolveTypeVariable(c, dc, (TypeVariable)t);
/*     */       
/* 148 */       if (ct != null) {
/* 149 */         return ct.c;
/*     */       }
/* 151 */       return null; }
/* 152 */     if ((t instanceof ParameterizedType)) {
/* 153 */       ParameterizedType pt = (ParameterizedType)t;
/* 154 */       return (Class)pt.getRawType();
/*     */     }
/*     */     
/* 157 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\application\ExceptionMapperFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */