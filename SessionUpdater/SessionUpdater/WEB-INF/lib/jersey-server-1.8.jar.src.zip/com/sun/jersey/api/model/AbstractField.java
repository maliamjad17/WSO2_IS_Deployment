/*    */ package com.sun.jersey.api.model;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AbstractField
/*    */   implements Parameterized, AbstractModelComponent
/*    */ {
/*    */   private List<Parameter> parameters;
/*    */   private Field field;
/*    */   
/*    */   public AbstractField(Field field)
/*    */   {
/* 56 */     assert (null != field);
/*    */     
/* 58 */     this.field = field;
/* 59 */     this.parameters = new ArrayList();
/*    */   }
/*    */   
/*    */   public Field getField() {
/* 63 */     return this.field;
/*    */   }
/*    */   
/*    */   public List<Parameter> getParameters()
/*    */   {
/* 68 */     return this.parameters;
/*    */   }
/*    */   
/*    */   public void accept(AbstractModelVisitor visitor)
/*    */   {
/* 73 */     visitor.visitAbstractField(this);
/*    */   }
/*    */   
/*    */   public List<AbstractModelComponent> getComponents()
/*    */   {
/* 78 */     return null;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 83 */     return "AbstractField(" + getField().getDeclaringClass().getSimpleName() + "#" + getField().getName() + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\model\AbstractField.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */