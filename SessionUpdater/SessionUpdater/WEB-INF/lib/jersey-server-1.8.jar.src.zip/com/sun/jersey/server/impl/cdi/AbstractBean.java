/*     */ package com.sun.jersey.server.impl.cdi;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.enterprise.context.Dependent;
/*     */ import javax.enterprise.context.spi.CreationalContext;
/*     */ import javax.enterprise.inject.spi.Bean;
/*     */ import javax.enterprise.inject.spi.InjectionPoint;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractBean<T>
/*     */   implements Bean<T>
/*     */ {
/*     */   private Class<?> klass;
/*     */   private Set<Annotation> qualifiers;
/*     */   private Set<Type> types;
/*     */   
/*     */   public AbstractBean(Class<?> klass, Annotation qualifier)
/*     */   {
/*  70 */     this(klass, klass, qualifier);
/*     */   }
/*     */   
/*     */   public AbstractBean(Class<?> klass, Set<Annotation> qualifiers) {
/*  74 */     this(klass, klass, qualifiers);
/*     */   }
/*     */   
/*     */   public AbstractBean(Class<?> klass, Type type, Annotation qualifier)
/*     */   {
/*  79 */     this.klass = klass;
/*     */     
/*  81 */     this.qualifiers = new HashSet();
/*  82 */     this.qualifiers.add(qualifier);
/*  83 */     this.types = new HashSet();
/*  84 */     this.types.add(type);
/*     */   }
/*     */   
/*     */   public AbstractBean(Class<?> klass, Type type, Set<Annotation> qualifiers) {
/*  88 */     this.klass = klass;
/*  89 */     this.qualifiers = qualifiers;
/*  90 */     this.types = new HashSet();
/*  91 */     this.types.add(type);
/*     */   }
/*     */   
/*     */   public Class<?> getBeanClass() {
/*  95 */     return this.klass;
/*     */   }
/*     */   
/*     */   public Set<InjectionPoint> getInjectionPoints() {
/*  99 */     return Collections.EMPTY_SET;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 103 */     return null;
/*     */   }
/*     */   
/*     */   public Set<Annotation> getQualifiers() {
/* 107 */     return this.qualifiers;
/*     */   }
/*     */   
/*     */   public Class<? extends Annotation> getScope() {
/* 111 */     return Dependent.class;
/*     */   }
/*     */   
/*     */   public Set<Class<? extends Annotation>> getStereotypes() {
/* 115 */     return Collections.EMPTY_SET;
/*     */   }
/*     */   
/*     */   public Set<Type> getTypes() {
/* 119 */     return this.types;
/*     */   }
/*     */   
/*     */   public boolean isAlternative() {
/* 123 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isNullable() {
/* 127 */     return false;
/*     */   }
/*     */   
/*     */   public abstract T create(CreationalContext<T> paramCreationalContext);
/*     */   
/*     */   public void destroy(T instance, CreationalContext<T> creationalContext) {}
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\cdi\AbstractBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */