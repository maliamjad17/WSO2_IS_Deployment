/*    */ package com.sun.jersey.server.impl.model.parameter;
/*    */ 
/*    */ import com.sun.jersey.api.model.Parameter;
/*    */ import com.sun.jersey.core.spi.component.ComponentScope;
/*    */ import com.sun.jersey.server.impl.model.parameter.multivalued.MultivaluedParameterExtractor;
/*    */ import com.sun.jersey.server.impl.model.parameter.multivalued.MultivaluedParameterExtractorProvider;
/*    */ import com.sun.jersey.spi.inject.InjectableProvider;
/*    */ import java.lang.annotation.Annotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BaseParamInjectableProvider<A extends Annotation>
/*    */   implements InjectableProvider<A, Parameter>
/*    */ {
/*    */   private final MultivaluedParameterExtractorProvider mpep;
/*    */   
/*    */   BaseParamInjectableProvider(MultivaluedParameterExtractorProvider mpep)
/*    */   {
/* 59 */     this.mpep = mpep;
/*    */   }
/*    */   
/*    */   public ComponentScope getScope() {
/* 63 */     return ComponentScope.PerRequest;
/*    */   }
/*    */   
/*    */   protected MultivaluedParameterExtractor getWithoutDefaultValue(Parameter p) {
/* 67 */     return this.mpep.getWithoutDefaultValue(p);
/*    */   }
/*    */   
/*    */   protected MultivaluedParameterExtractor get(Parameter p) {
/* 71 */     return this.mpep.get(p);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\parameter\BaseParamInjectableProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */