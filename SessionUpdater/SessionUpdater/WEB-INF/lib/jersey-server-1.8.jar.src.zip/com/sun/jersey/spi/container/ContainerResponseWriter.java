package com.sun.jersey.spi.container;

import java.io.IOException;
import java.io.OutputStream;

public abstract interface ContainerResponseWriter
{
  public abstract OutputStream writeStatusAndHeaders(long paramLong, ContainerResponse paramContainerResponse)
    throws IOException;
  
  public abstract void finish()
    throws IOException;
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\container\ContainerResponseWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */