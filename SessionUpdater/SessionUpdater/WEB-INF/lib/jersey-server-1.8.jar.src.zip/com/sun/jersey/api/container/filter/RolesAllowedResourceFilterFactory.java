/*     */ package com.sun.jersey.api.container.filter;
/*     */ 
/*     */ import com.sun.jersey.api.model.AbstractMethod;
/*     */ import com.sun.jersey.api.model.AbstractResource;
/*     */ import com.sun.jersey.spi.container.ContainerRequest;
/*     */ import com.sun.jersey.spi.container.ContainerRequestFilter;
/*     */ import com.sun.jersey.spi.container.ContainerResponseFilter;
/*     */ import com.sun.jersey.spi.container.ResourceFilter;
/*     */ import com.sun.jersey.spi.container.ResourceFilterFactory;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.annotation.security.DenyAll;
/*     */ import javax.annotation.security.PermitAll;
/*     */ import javax.annotation.security.RolesAllowed;
/*     */ import javax.ws.rs.WebApplicationException;
/*     */ import javax.ws.rs.core.Context;
/*     */ import javax.ws.rs.core.Response.Status;
/*     */ import javax.ws.rs.core.SecurityContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RolesAllowedResourceFilterFactory
/*     */   implements ResourceFilterFactory
/*     */ {
/*     */   @Context
/*     */   private SecurityContext sc;
/*     */   
/*     */   private class Filter
/*     */     implements ResourceFilter, ContainerRequestFilter
/*     */   {
/*     */     private final boolean denyAll;
/*     */     private final String[] rolesAllowed;
/*     */     
/*     */     protected Filter()
/*     */     {
/*  98 */       this.denyAll = true;
/*  99 */       this.rolesAllowed = null;
/*     */     }
/*     */     
/*     */     protected Filter(String[] rolesAllowed) {
/* 103 */       this.denyAll = false;
/* 104 */       this.rolesAllowed = (rolesAllowed != null ? rolesAllowed : new String[0]);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public ContainerRequestFilter getRequestFilter()
/*     */     {
/* 111 */       return this;
/*     */     }
/*     */     
/*     */     public ContainerResponseFilter getResponseFilter()
/*     */     {
/* 116 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public ContainerRequest filter(ContainerRequest request)
/*     */     {
/* 123 */       if (!this.denyAll) {
/* 124 */         for (String role : this.rolesAllowed) {
/* 125 */           if (RolesAllowedResourceFilterFactory.this.sc.isUserInRole(role)) {
/* 126 */             return request;
/*     */           }
/*     */         }
/*     */       }
/* 130 */       throw new WebApplicationException(Response.Status.FORBIDDEN);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public List<ResourceFilter> create(AbstractMethod am)
/*     */   {
/* 137 */     if (am.isAnnotationPresent(DenyAll.class)) {
/* 138 */       return Collections.singletonList(new Filter());
/*     */     }
/*     */     
/* 141 */     RolesAllowed ra = (RolesAllowed)am.getAnnotation(RolesAllowed.class);
/* 142 */     if (ra != null) {
/* 143 */       return Collections.singletonList(new Filter(ra.value()));
/*     */     }
/*     */     
/* 146 */     if (am.isAnnotationPresent(PermitAll.class)) {
/* 147 */       return null;
/*     */     }
/*     */     
/* 150 */     ra = (RolesAllowed)am.getResource().getAnnotation(RolesAllowed.class);
/* 151 */     if (ra != null) {
/* 152 */       return Collections.singletonList(new Filter(ra.value()));
/*     */     }
/*     */     
/* 155 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\container\filter\RolesAllowedResourceFilterFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */