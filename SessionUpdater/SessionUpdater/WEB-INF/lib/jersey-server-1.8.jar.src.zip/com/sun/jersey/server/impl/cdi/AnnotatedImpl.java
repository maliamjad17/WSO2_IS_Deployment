/*    */ package com.sun.jersey.server.impl.cdi;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import javax.enterprise.inject.spi.Annotated;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnotatedImpl
/*    */   implements Annotated
/*    */ {
/*    */   private Type baseType;
/*    */   private Set<Type> typeClosure;
/*    */   private Set<Annotation> annotations;
/*    */   
/*    */   public AnnotatedImpl(Type baseType, Set<Type> typeClosure, Set<Annotation> annotations)
/*    */   {
/* 61 */     this.baseType = baseType;
/* 62 */     this.typeClosure = Collections.unmodifiableSet(typeClosure);
/* 63 */     this.annotations = Collections.unmodifiableSet(annotations);
/*    */   }
/*    */   
/*    */   public <T extends Annotation> T getAnnotation(Class<T> annotationType) {
/* 67 */     for (Annotation a : this.annotations) {
/* 68 */       if (annotationType.isInstance(a)) {
/* 69 */         return (Annotation)annotationType.cast(a);
/*    */       }
/*    */     }
/* 72 */     return null;
/*    */   }
/*    */   
/*    */   public Set<Annotation> getAnnotations() {
/* 76 */     return this.annotations;
/*    */   }
/*    */   
/*    */ 
/*    */   public Type getBaseType()
/*    */   {
/* 82 */     return this.baseType;
/*    */   }
/*    */   
/*    */   public Set<Type> getTypeClosure() {
/* 86 */     return this.typeClosure;
/*    */   }
/*    */   
/*    */   public boolean isAnnotationPresent(Class<? extends Annotation> annotationType) {
/* 90 */     return getAnnotation(annotationType) != null;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\cdi\AnnotatedImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */