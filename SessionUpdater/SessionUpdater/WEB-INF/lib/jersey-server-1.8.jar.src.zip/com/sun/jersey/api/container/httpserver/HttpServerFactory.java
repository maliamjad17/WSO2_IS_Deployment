/*     */ package com.sun.jersey.api.container.httpserver;
/*     */ 
/*     */ import com.sun.jersey.api.container.ContainerFactory;
/*     */ import com.sun.jersey.api.core.ResourceConfig;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCComponentProviderFactory;
/*     */ import com.sun.net.httpserver.HttpHandler;
/*     */ import com.sun.net.httpserver.HttpServer;
/*     */ import com.sun.net.httpserver.HttpsServer;
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.util.concurrent.Executors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpServerFactory
/*     */ {
/*     */   public static HttpServer create(String u)
/*     */     throws IOException, IllegalArgumentException
/*     */   {
/*  89 */     if (u == null) {
/*  90 */       throw new IllegalArgumentException("The URI must not be null");
/*     */     }
/*  92 */     return create(URI.create(u));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HttpServer create(URI u)
/*     */     throws IOException, IllegalArgumentException
/*     */   {
/* 117 */     return create(u, (HttpHandler)ContainerFactory.createContainer(HttpHandler.class));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HttpServer create(String u, ResourceConfig rc)
/*     */     throws IOException, IllegalArgumentException
/*     */   {
/* 143 */     if (u == null) {
/* 144 */       throw new IllegalArgumentException("The URI must not be null");
/*     */     }
/* 146 */     return create(URI.create(u), rc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HttpServer create(URI u, ResourceConfig rc)
/*     */     throws IOException, IllegalArgumentException
/*     */   {
/* 172 */     return create(u, (HttpHandler)ContainerFactory.createContainer(HttpHandler.class, rc));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HttpServer create(String u, ResourceConfig rc, IoCComponentProviderFactory factory)
/*     */     throws IOException, IllegalArgumentException
/*     */   {
/* 203 */     if (u == null) {
/* 204 */       throw new IllegalArgumentException("The URI must not be null");
/*     */     }
/* 206 */     return create(URI.create(u), rc, factory);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HttpServer create(URI u, ResourceConfig rc, IoCComponentProviderFactory factory)
/*     */     throws IOException, IllegalArgumentException
/*     */   {
/* 237 */     return create(u, (HttpHandler)ContainerFactory.createContainer(HttpHandler.class, rc, factory));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HttpServer create(String u, HttpHandler handler)
/*     */     throws IOException, IllegalArgumentException
/*     */   {
/* 259 */     if (u == null) {
/* 260 */       throw new IllegalArgumentException("The URI must not be null");
/*     */     }
/* 262 */     return create(URI.create(u), handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HttpServer create(URI u, HttpHandler handler)
/*     */     throws IOException, IllegalArgumentException
/*     */   {
/* 284 */     if (u == null) {
/* 285 */       throw new IllegalArgumentException("The URI must not be null");
/*     */     }
/* 287 */     String scheme = u.getScheme();
/* 288 */     if ((!scheme.equalsIgnoreCase("http")) && (!scheme.equalsIgnoreCase("https"))) {
/* 289 */       throw new IllegalArgumentException("The URI scheme, of the URI " + u + ", must be equal (ignoring case) to 'http' or 'https'");
/*     */     }
/*     */     
/* 292 */     String path = u.getPath();
/* 293 */     if (path == null) {
/* 294 */       throw new IllegalArgumentException("The URI path, of the URI " + u + ", must be non-null");
/*     */     }
/* 296 */     if (path.length() == 0) {
/* 297 */       throw new IllegalArgumentException("The URI path, of the URI " + u + ", must be present");
/*     */     }
/* 299 */     if (path.charAt(0) != '/') {
/* 300 */       throw new IllegalArgumentException("The URI path, of the URI " + u + ". must start with a '/'");
/*     */     }
/*     */     
/* 303 */     int port = u.getPort() == -1 ? 80 : u.getPort();
/* 304 */     HttpServer server = scheme.equalsIgnoreCase("http") ? HttpServer.create(new InetSocketAddress(port), 0) : HttpsServer.create(new InetSocketAddress(port), 0);
/*     */     
/*     */ 
/*     */ 
/* 308 */     server.setExecutor(Executors.newCachedThreadPool());
/* 309 */     server.createContext(path, handler);
/* 310 */     return server;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\container\httpserver\HttpServerFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */