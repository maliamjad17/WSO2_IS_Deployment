package com.sun.jersey.spi.monitoring;

import com.sun.jersey.spi.container.ContainerRequest;

public abstract interface RequestListener
{
  public abstract void onRequest(long paramLong, ContainerRequest paramContainerRequest);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\monitoring\RequestListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */