/*     */ package com.sun.jersey.server.impl.model.parameter.multivalued;
/*     */ 
/*     */ import com.sun.jersey.api.container.ContainerException;
/*     */ import com.sun.jersey.impl.ImplMessages;
/*     */ import com.sun.jersey.spi.StringReaderProvider;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import javax.ws.rs.core.Context;
/*     */ import javax.ws.rs.ext.ContextResolver;
/*     */ import javax.ws.rs.ext.Providers;
/*     */ import javax.xml.bind.JAXBContext;
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.UnmarshalException;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JAXBStringReaderProviders
/*     */ {
/*  71 */   private static final Map<Class, JAXBContext> jaxbContexts = new WeakHashMap();
/*     */   
/*     */   private final Providers ps;
/*     */   
/*     */   private final ContextResolver<JAXBContext> context;
/*     */   
/*     */   private final ContextResolver<Unmarshaller> unmarshaller;
/*     */   
/*     */   public JAXBStringReaderProviders(Providers ps)
/*     */   {
/*  81 */     this.ps = ps;
/*     */     
/*  83 */     this.context = ps.getContextResolver(JAXBContext.class, null);
/*  84 */     this.unmarshaller = ps.getContextResolver(Unmarshaller.class, null);
/*     */   }
/*     */   
/*     */   protected final Unmarshaller getUnmarshaller(Class type) throws JAXBException {
/*  88 */     if (this.unmarshaller != null) {
/*  89 */       Unmarshaller u = (Unmarshaller)this.unmarshaller.getContext(type);
/*  90 */       if (u != null) {
/*  91 */         return u;
/*     */       }
/*     */     }
/*     */     
/*  95 */     return getJAXBContext(type).createUnmarshaller();
/*     */   }
/*     */   
/*     */   private final JAXBContext getJAXBContext(Class type) throws JAXBException {
/*  99 */     if (this.context != null) {
/* 100 */       JAXBContext c = (JAXBContext)this.context.getContext(type);
/* 101 */       if (c != null) {
/* 102 */         return c;
/*     */       }
/*     */     }
/*     */     
/* 106 */     return getStoredJAXBContext(type);
/*     */   }
/*     */   
/*     */   protected JAXBContext getStoredJAXBContext(Class type) throws JAXBException {
/* 110 */     synchronized (jaxbContexts) {
/* 111 */       JAXBContext c = (JAXBContext)jaxbContexts.get(type);
/* 112 */       if (c == null) {
/* 113 */         c = JAXBContext.newInstance(new Class[] { type });
/* 114 */         jaxbContexts.put(type, c);
/*     */       }
/* 116 */       return c;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class RootElementProvider extends JAXBStringReaderProviders implements StringReaderProvider
/*     */   {
/*     */     private final Injectable<SAXParserFactory> spf;
/*     */     
/*     */     public RootElementProvider(@Context Injectable<SAXParserFactory> spf, @Context Providers ps)
/*     */     {
/* 126 */       super();
/* 127 */       this.spf = spf;
/*     */     }
/*     */     
/*     */     public com.sun.jersey.spi.StringReader getStringReader(final Class type, Type genericType, Annotation[] annotations) {
/* 131 */       boolean supported = (type.getAnnotation(XmlRootElement.class) != null) || (type.getAnnotation(XmlType.class) != null);
/*     */       
/* 133 */       if (!supported) {
/* 134 */         return null;
/*     */       }
/*     */       
/* 137 */       new com.sun.jersey.spi.StringReader() {
/*     */         public Object fromString(String value) {
/*     */           try {
/* 140 */             SAXSource source = new SAXSource(((SAXParserFactory)JAXBStringReaderProviders.RootElementProvider.this.spf.getValue()).newSAXParser().getXMLReader(), new InputSource(new java.io.StringReader(value)));
/*     */             
/*     */ 
/*     */ 
/* 144 */             Unmarshaller u = JAXBStringReaderProviders.RootElementProvider.this.getUnmarshaller(type);
/* 145 */             if (type.isAnnotationPresent(XmlRootElement.class)) {
/* 146 */               return u.unmarshal(source);
/*     */             }
/* 148 */             return u.unmarshal(source, type).getValue();
/*     */           }
/*     */           catch (UnmarshalException ex) {
/* 151 */             throw new ExtractorContainerException(ImplMessages.ERROR_UNMARSHALLING_JAXB(type), ex);
/*     */           } catch (JAXBException ex) {
/* 153 */             throw new ContainerException(ImplMessages.ERROR_UNMARSHALLING_JAXB(type), ex);
/*     */           } catch (Exception ex) {
/* 155 */             throw new ContainerException(ImplMessages.ERROR_UNMARSHALLING_JAXB(type), ex);
/*     */           }
/*     */         }
/*     */       };
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\parameter\multivalued\JAXBStringReaderProviders.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */