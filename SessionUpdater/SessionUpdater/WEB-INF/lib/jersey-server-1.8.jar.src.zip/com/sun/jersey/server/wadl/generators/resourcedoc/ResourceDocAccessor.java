/*     */ package com.sun.jersey.server.wadl.generators.resourcedoc;
/*     */ 
/*     */ import com.sun.jersey.api.model.Parameter;
/*     */ import com.sun.jersey.server.wadl.generators.resourcedoc.model.AnnotationDocType;
/*     */ import com.sun.jersey.server.wadl.generators.resourcedoc.model.ClassDocType;
/*     */ import com.sun.jersey.server.wadl.generators.resourcedoc.model.MethodDocType;
/*     */ import com.sun.jersey.server.wadl.generators.resourcedoc.model.NamedValueType;
/*     */ import com.sun.jersey.server.wadl.generators.resourcedoc.model.ParamDocType;
/*     */ import com.sun.jersey.server.wadl.generators.resourcedoc.model.RepresentationDocType;
/*     */ import com.sun.jersey.server.wadl.generators.resourcedoc.model.RequestDocType;
/*     */ import com.sun.jersey.server.wadl.generators.resourcedoc.model.ResourceDocType;
/*     */ import com.sun.jersey.server.wadl.generators.resourcedoc.model.ResponseDocType;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceDocAccessor
/*     */ {
/*     */   private ResourceDocType _resourceDoc;
/*     */   
/*     */   public ResourceDocAccessor(ResourceDocType resourceDoc)
/*     */   {
/*  67 */     this._resourceDoc = resourceDoc;
/*     */   }
/*     */   
/*     */   public ClassDocType getClassDoc(Class<?> resourceClass) {
/*  71 */     for (ClassDocType classDocType : this._resourceDoc.getDocs()) {
/*  72 */       if (resourceClass.getName().equals(classDocType.getClassName())) {
/*  73 */         return classDocType;
/*     */       }
/*     */     }
/*  76 */     return null;
/*     */   }
/*     */   
/*     */   public MethodDocType getMethodDoc(Class<?> resourceClass, Method method) {
/*  80 */     ClassDocType classDoc = getClassDoc(resourceClass);
/*  81 */     if (classDoc != null) {
/*  82 */       for (MethodDocType methodDocType : classDoc.getMethodDocs()) {
/*  83 */         if ((method != null) && (method.getName().equals(methodDocType.getMethodName()))) {
/*  84 */           return methodDocType;
/*     */         }
/*     */       }
/*     */     }
/*  88 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ParamDocType getParamDoc(Class<?> resourceClass, Method method, Parameter p)
/*     */   {
/* 100 */     MethodDocType methodDoc = getMethodDoc(resourceClass, method);
/* 101 */     Iterator i$; if (methodDoc != null) {
/* 102 */       for (i$ = methodDoc.getParamDocs().iterator(); i$.hasNext();) { paramDocType = (ParamDocType)i$.next();
/* 103 */         for (AnnotationDocType annotationDocType : paramDocType.getAnnotationDocs()) {
/* 104 */           Class<? extends Annotation> annotationType = p.getAnnotation().annotationType();
/* 105 */           if (annotationType != null) {
/* 106 */             String sourceName = getSourceName(annotationDocType);
/* 107 */             if ((sourceName != null) && (sourceName.equals(p.getSourceName())))
/* 108 */               return paramDocType;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     ParamDocType paramDocType;
/* 114 */     return null;
/*     */   }
/*     */   
/*     */   public RepresentationDocType getRequestRepresentation(Class<?> resourceClass, Method method, String mediaType) {
/* 118 */     if (mediaType == null) {
/* 119 */       return null;
/*     */     }
/* 121 */     MethodDocType methodDoc = getMethodDoc(resourceClass, method);
/* 122 */     return (methodDoc != null) && (methodDoc.getRequestDoc() != null) && (methodDoc.getRequestDoc().getRepresentationDoc() != null) ? methodDoc.getRequestDoc().getRepresentationDoc() : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResponseDocType getResponse(Class<?> resourceClass, Method method)
/*     */   {
/* 130 */     MethodDocType methodDoc = getMethodDoc(resourceClass, method);
/* 131 */     return (methodDoc != null) && (methodDoc.getResponseDoc() != null) ? methodDoc.getResponseDoc() : null;
/*     */   }
/*     */   
/*     */   private String getSourceName(AnnotationDocType annotationDocType)
/*     */   {
/* 136 */     if (annotationDocType.hasAttributeDocs()) {
/* 137 */       for (NamedValueType namedValueType : annotationDocType.getAttributeDocs())
/*     */       {
/*     */ 
/* 140 */         if ("value".equals(namedValueType.getName())) {
/* 141 */           return namedValueType.getValue();
/*     */         }
/*     */       }
/*     */     }
/* 145 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\wadl\generators\resourcedoc\ResourceDocAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */