/*    */ package com.sun.jersey.server.impl.uri.rules;
/*    */ 
/*    */ import com.sun.jersey.api.uri.UriPattern;
/*    */ import com.sun.jersey.server.impl.uri.PathPattern;
/*    */ import com.sun.jersey.server.impl.uri.rules.automata.AutomataMatchingUriTemplateRules;
/*    */ import com.sun.jersey.spi.uri.rules.UriRule;
/*    */ import com.sun.jersey.spi.uri.rules.UriRules;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class UriRulesFactory
/*    */ {
/*    */   public static UriRules<UriRule> create(Map<PathPattern, UriRule> rulesMap)
/*    */   {
/* 60 */     return create(rulesMap, null);
/*    */   }
/*    */   
/*    */   public static UriRules<UriRule> create(Map<PathPattern, UriRule> rulesMap, List<PatternRulePair<UriRule>> rules)
/*    */   {
/* 65 */     List<PatternRulePair<UriRule>> l = new ArrayList();
/* 66 */     for (Map.Entry<PathPattern, UriRule> e : rulesMap.entrySet()) {
/* 67 */       l.add(new PatternRulePair((UriPattern)e.getKey(), e.getValue()));
/*    */     }
/* 69 */     if (rules != null) { l.addAll(rules);
/*    */     }
/* 71 */     return create(l);
/*    */   }
/*    */   
/*    */   public static UriRules<UriRule> create(List<PatternRulePair<UriRule>> rules) {
/* 75 */     if (rules.size() < Integer.MAX_VALUE) {
/* 76 */       return new AtomicMatchingPatterns(rules);
/*    */     }
/* 78 */     return new AutomataMatchingUriTemplateRules(rules);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\uri\rules\UriRulesFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */