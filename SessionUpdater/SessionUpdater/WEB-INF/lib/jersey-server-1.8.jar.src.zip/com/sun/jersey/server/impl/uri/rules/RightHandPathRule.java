/*     */ package com.sun.jersey.server.impl.uri.rules;
/*     */ 
/*     */ import com.sun.jersey.api.core.ExtendedUriInfo;
/*     */ import com.sun.jersey.api.core.HttpResponseContext;
/*     */ import com.sun.jersey.server.probes.UriRuleProbeProvider;
/*     */ import com.sun.jersey.spi.uri.rules.UriRule;
/*     */ import com.sun.jersey.spi.uri.rules.UriRuleContext;
/*     */ import java.util.regex.MatchResult;
/*     */ import javax.ws.rs.core.Response;
/*     */ import javax.ws.rs.core.Response.ResponseBuilder;
/*     */ import javax.ws.rs.core.UriBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RightHandPathRule
/*     */   implements UriRule
/*     */ {
/*     */   private final boolean redirect;
/*     */   private final boolean patternEndsInSlash;
/*     */   private final UriRule rule;
/*     */   
/*     */   public RightHandPathRule(boolean redirect, boolean patternEndsInSlash, UriRule rule)
/*     */   {
/*  82 */     assert (rule != null);
/*  83 */     this.redirect = redirect;
/*  84 */     this.patternEndsInSlash = patternEndsInSlash;
/*  85 */     this.rule = rule;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean accept(CharSequence path, Object resource, UriRuleContext context)
/*     */   {
/*  93 */     UriRuleProbeProvider.ruleAccept(RightHandPathRule.class.getSimpleName(), path, resource);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */     String rhpath = getRightHandPath(context.getMatchResult());
/*     */     
/* 101 */     if (rhpath.length() == 0)
/*     */     {
/*     */ 
/* 104 */       if ((this.patternEndsInSlash) && (this.redirect)) {
/* 105 */         if (context.isTracingEnabled()) {
/* 106 */           context.trace(String.format("accept right hand path redirect: \"%s\" to \"%s/\"", new Object[] { path, path }));
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 114 */         return redirect(context);
/*     */       }
/* 116 */       context.pushRightHandPathLength(0);
/* 117 */     } else if (rhpath.length() == 1)
/*     */     {
/*     */ 
/* 120 */       if ((!this.patternEndsInSlash) && (this.redirect)) {
/* 121 */         return false;
/*     */       }
/*     */       
/* 124 */       rhpath = "";
/* 125 */       context.pushRightHandPathLength(0);
/*     */     }
/* 127 */     else if (this.patternEndsInSlash) {
/* 128 */       context.pushRightHandPathLength(rhpath.length() - 1);
/*     */     } else {
/* 130 */       context.pushRightHandPathLength(rhpath.length());
/*     */     }
/*     */     
/*     */ 
/* 134 */     if (context.isTracingEnabled()) {
/* 135 */       CharSequence lhpath = path.subSequence(0, path.length() - rhpath.length());
/* 136 */       context.trace(String.format("accept right hand path %s: \"%s\" -> \"%s\" : \"%s\"", new Object[] { context.getMatchResult(), path, lhpath, rhpath }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 147 */     return this.rule.accept(rhpath, resource, context);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getRightHandPath(MatchResult mr)
/*     */   {
/* 159 */     String rhp = mr.groupCount() > 0 ? mr.group(mr.groupCount()) : "";
/* 160 */     return rhp != null ? rhp : "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean redirect(UriRuleContext context)
/*     */   {
/* 171 */     HttpResponseContext response = context.getResponse();
/* 172 */     response.setResponse(Response.temporaryRedirect(context.getUriInfo().getRequestUriBuilder().path("/").build(new Object[0])).build());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 177 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\uri\rules\RightHandPathRule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */