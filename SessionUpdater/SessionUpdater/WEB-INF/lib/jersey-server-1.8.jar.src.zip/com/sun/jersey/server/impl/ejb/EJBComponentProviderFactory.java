/*     */ package com.sun.jersey.server.impl.ejb;
/*     */ 
/*     */ import com.sun.jersey.api.container.ContainerException;
/*     */ import com.sun.jersey.core.spi.component.ComponentContext;
/*     */ import com.sun.jersey.core.spi.component.ComponentScope;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCComponentProcessorFactory;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCComponentProcessorFactoryInitializer;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCComponentProvider;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCComponentProviderFactory;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCFullyManagedComponentProvider;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.ejb.Singleton;
/*     */ import javax.ejb.Stateless;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class EJBComponentProviderFactory
/*     */   implements IoCComponentProviderFactory, IoCComponentProcessorFactoryInitializer
/*     */ {
/*  65 */   private static final Logger LOGGER = Logger.getLogger(EJBComponentProviderFactory.class.getName());
/*     */   
/*     */   private final EJBInjectionInterceptor interceptor;
/*     */   
/*     */   public EJBComponentProviderFactory(EJBInjectionInterceptor interceptor)
/*     */   {
/*  71 */     this.interceptor = interceptor;
/*     */   }
/*     */   
/*     */ 
/*     */   public IoCComponentProvider getComponentProvider(Class<?> c)
/*     */   {
/*  77 */     return getComponentProvider(null, c);
/*     */   }
/*     */   
/*     */   public IoCComponentProvider getComponentProvider(ComponentContext cc, Class<?> c) {
/*  81 */     String name = getName(c);
/*  82 */     if (name == null) {
/*  83 */       return null;
/*     */     }
/*     */     try
/*     */     {
/*  87 */       InitialContext ic = new InitialContext();
/*  88 */       Object o = lookup(ic, c, name);
/*     */       
/*  90 */       LOGGER.info("Binding the EJB class " + c.getName() + " to EJBManagedComponentProvider");
/*     */       
/*     */ 
/*  93 */       return new EJBManagedComponentProvider(o);
/*     */     } catch (NamingException ex) {
/*  95 */       String message = "An instance of EJB class " + c.getName() + " could not be looked up using simple form name or the fully-qualified form name." + "Ensure that the EJB/JAX-RS component implements at most one interface.";
/*     */       
/*     */ 
/*  98 */       LOGGER.log(Level.SEVERE, message, ex);
/*  99 */       throw new ContainerException(message);
/*     */     }
/*     */   }
/*     */   
/*     */   private String getName(Class<?> c) {
/* 104 */     String name = null;
/* 105 */     if (c.isAnnotationPresent(Stateless.class)) {
/* 106 */       name = ((Stateless)c.getAnnotation(Stateless.class)).name();
/* 107 */     } else if (c.isAnnotationPresent(Singleton.class)) {
/* 108 */       name = ((Singleton)c.getAnnotation(Singleton.class)).name();
/*     */     } else {
/* 110 */       return null;
/*     */     }
/*     */     
/* 113 */     if ((name == null) || (name.length() == 0)) {
/* 114 */       name = c.getSimpleName();
/*     */     }
/* 116 */     return name;
/*     */   }
/*     */   
/*     */   private Object lookup(InitialContext ic, Class<?> c, String name) throws NamingException {
/*     */     try {
/* 121 */       return lookupSimpleForm(ic, c, name);
/*     */     } catch (NamingException ex) {
/* 123 */       LOGGER.log(Level.WARNING, "An instance of EJB class " + c.getName() + " could not be looked up using simple form name. " + "Attempting to look up using the fully-qualified form name.", ex);
/*     */     }
/*     */     
/*     */ 
/* 127 */     return lookupFullyQualfiedForm(ic, c, name);
/*     */   }
/*     */   
/*     */   private Object lookupSimpleForm(InitialContext ic, Class<?> c, String name) throws NamingException
/*     */   {
/* 132 */     String jndiName = "java:module/" + name;
/* 133 */     return ic.lookup(jndiName);
/*     */   }
/*     */   
/*     */   private Object lookupFullyQualfiedForm(InitialContext ic, Class<?> c, String name) throws NamingException {
/* 137 */     String jndiName = "java:module/" + name + "!" + c.getName();
/* 138 */     return ic.lookup(jndiName);
/*     */   }
/*     */   
/*     */   private static class EJBManagedComponentProvider implements IoCFullyManagedComponentProvider
/*     */   {
/*     */     private final Object o;
/*     */     
/*     */     EJBManagedComponentProvider(Object o) {
/* 146 */       this.o = o;
/*     */     }
/*     */     
/*     */     public ComponentScope getScope() {
/* 150 */       return ComponentScope.Singleton;
/*     */     }
/*     */     
/*     */     public Object getInstance() {
/* 154 */       return this.o;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void init(IoCComponentProcessorFactory cpf)
/*     */   {
/* 161 */     this.interceptor.setFactory(cpf);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\ejb\EJBComponentProviderFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */