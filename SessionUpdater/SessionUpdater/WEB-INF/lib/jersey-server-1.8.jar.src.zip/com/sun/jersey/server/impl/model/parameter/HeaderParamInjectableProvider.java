/*    */ package com.sun.jersey.server.impl.model.parameter;
/*    */ 
/*    */ import com.sun.jersey.api.ParamException.HeaderParamException;
/*    */ import com.sun.jersey.api.core.HttpContext;
/*    */ import com.sun.jersey.api.core.HttpRequestContext;
/*    */ import com.sun.jersey.api.model.Parameter;
/*    */ import com.sun.jersey.core.spi.component.ComponentContext;
/*    */ import com.sun.jersey.server.impl.inject.AbstractHttpContextInjectable;
/*    */ import com.sun.jersey.server.impl.model.parameter.multivalued.ExtractorContainerException;
/*    */ import com.sun.jersey.server.impl.model.parameter.multivalued.MultivaluedParameterExtractor;
/*    */ import com.sun.jersey.server.impl.model.parameter.multivalued.MultivaluedParameterExtractorProvider;
/*    */ import com.sun.jersey.spi.inject.Injectable;
/*    */ import javax.ws.rs.HeaderParam;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HeaderParamInjectableProvider
/*    */   extends BaseParamInjectableProvider<HeaderParam>
/*    */ {
/*    */   private static final class HeaderParamInjectable
/*    */     extends AbstractHttpContextInjectable<Object>
/*    */   {
/*    */     private MultivaluedParameterExtractor extractor;
/*    */     
/*    */     HeaderParamInjectable(MultivaluedParameterExtractor extractor)
/*    */     {
/* 65 */       this.extractor = extractor;
/*    */     }
/*    */     
/*    */     public Object getValue(HttpContext context) {
/*    */       try {
/* 70 */         return this.extractor.extract(context.getRequest().getRequestHeaders());
/*    */       } catch (ExtractorContainerException e) {
/* 72 */         throw new ParamException.HeaderParamException(e.getCause(), this.extractor.getName(), this.extractor.getDefaultStringValue());
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public HeaderParamInjectableProvider(MultivaluedParameterExtractorProvider w)
/*    */   {
/* 79 */     super(w);
/*    */   }
/*    */   
/*    */   public Injectable getInjectable(ComponentContext ic, HeaderParam a, Parameter c) {
/* 83 */     String parameterName = c.getSourceName();
/* 84 */     if ((parameterName == null) || (parameterName.length() == 0))
/*    */     {
/* 86 */       return null;
/*    */     }
/*    */     
/* 89 */     MultivaluedParameterExtractor e = get(c);
/* 90 */     if (e == null) {
/* 91 */       return null;
/*    */     }
/* 93 */     return new HeaderParamInjectable(e);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\parameter\HeaderParamInjectableProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */