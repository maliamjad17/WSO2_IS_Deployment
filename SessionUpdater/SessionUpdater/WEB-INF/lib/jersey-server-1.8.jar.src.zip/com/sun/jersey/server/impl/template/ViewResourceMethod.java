/*    */ package com.sun.jersey.server.impl.template;
/*    */ 
/*    */ import com.sun.jersey.api.uri.UriTemplate;
/*    */ import com.sun.jersey.core.header.MediaTypes;
/*    */ import com.sun.jersey.core.header.QualitySourceMediaType;
/*    */ import com.sun.jersey.server.impl.model.method.ResourceMethod;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ViewResourceMethod
/*    */   extends ResourceMethod
/*    */ {
/*    */   public ViewResourceMethod(List<QualitySourceMediaType> produces)
/*    */   {
/* 56 */     super("GET", UriTemplate.EMPTY, MediaTypes.GENERAL_MEDIA_TYPE_LIST, produces, false, null);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\template\ViewResourceMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */