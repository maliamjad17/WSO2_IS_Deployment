/*     */ package com.sun.jersey.server.impl.uri.rules.automata;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrieNodeValue<T>
/*     */ {
/*  61 */   private Object value = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void set(T value)
/*     */   {
/*  68 */     if (this.value == null) {
/*  69 */       this.value = value;
/*     */     }
/*  71 */     else if (this.value.getClass().isArray()) {
/*  72 */       Object[] old = (Object[])this.value;
/*  73 */       Object[] copy = new Object[old.length + 1];
/*  74 */       System.arraycopy(old, 0, copy, 0, old.length + 1);
/*  75 */       copy[(copy.length - 1)] = value;
/*  76 */       this.value = copy;
/*     */     }
/*     */     else {
/*  79 */       this.value = new Object[] { this.value, value };
/*     */     }
/*     */   }
/*     */   
/*     */   public Iterator<T> getIterator()
/*     */   {
/*  85 */     if (this.value == null) {
/*  86 */       return new EmptyIterator();
/*     */     }
/*  88 */     if (this.value.getClass().isArray()) {
/*  89 */       return new ArrayIterator((Object[])this.value);
/*     */     }
/*     */     
/*  92 */     return new SingleEntryIterator(this.value);
/*     */   }
/*     */   
/*     */   public boolean isEmpty()
/*     */   {
/*  97 */     return this.value == null;
/*     */   }
/*     */   
/*     */   private static final class ArrayIterator<T>
/*     */     implements Iterator<T>
/*     */   {
/*     */     private Object[] data;
/* 104 */     private int cursor = 0;
/*     */     
/*     */     public ArrayIterator(Object[] data) {
/* 107 */       this.data = data;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 111 */       return this.cursor < this.data.length;
/*     */     }
/*     */     
/*     */     public T next()
/*     */     {
/* 116 */       if (hasNext()) {
/* 117 */         return (T)this.data[(this.cursor++)];
/*     */       }
/*     */       
/* 120 */       throw new NoSuchElementException();
/*     */     }
/*     */     
/*     */     public void remove()
/*     */     {
/* 125 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class SingleEntryIterator<T> implements Iterator<T>
/*     */   {
/*     */     private T t;
/*     */     
/*     */     SingleEntryIterator(T t) {
/* 134 */       this.t = t;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 138 */       return this.t != null;
/*     */     }
/*     */     
/*     */     public T next() {
/* 142 */       if (hasNext()) {
/* 143 */         T _t = this.t;
/* 144 */         this.t = null;
/* 145 */         return _t;
/*     */       }
/* 147 */       throw new NoSuchElementException();
/*     */     }
/*     */     
/*     */     public void remove()
/*     */     {
/* 152 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */   
/*     */   static final class EmptyIterator<T> implements Iterator<T> {
/*     */     public boolean hasNext() {
/* 158 */       return false;
/*     */     }
/*     */     
/* 161 */     public T next() { throw new NoSuchElementException(); }
/*     */     
/*     */     public void remove() {
/* 164 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\uri\rules\automata\TrieNodeValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */