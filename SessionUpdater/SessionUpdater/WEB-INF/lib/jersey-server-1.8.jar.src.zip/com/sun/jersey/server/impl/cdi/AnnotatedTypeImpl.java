/*     */ package com.sun.jersey.server.impl.cdi;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Set;
/*     */ import javax.enterprise.inject.spi.AnnotatedConstructor;
/*     */ import javax.enterprise.inject.spi.AnnotatedField;
/*     */ import javax.enterprise.inject.spi.AnnotatedMethod;
/*     */ import javax.enterprise.inject.spi.AnnotatedType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotatedTypeImpl<T>
/*     */   extends AnnotatedImpl
/*     */   implements AnnotatedType<T>
/*     */ {
/*     */   private Set<AnnotatedConstructor<T>> constructors;
/*     */   private Set<AnnotatedField<? super T>> fields;
/*     */   private Class<T> javaClass;
/*     */   private Set<AnnotatedMethod<? super T>> methods;
/*     */   
/*     */   public AnnotatedTypeImpl(Type baseType, Set<Type> typeClosure, Set<Annotation> annotations, Class<T> javaClass)
/*     */   {
/*  67 */     super(baseType, typeClosure, annotations);
/*  68 */     this.javaClass = javaClass;
/*     */   }
/*     */   
/*     */   public AnnotatedTypeImpl(AnnotatedType type) {
/*  72 */     this(type.getBaseType(), type.getTypeClosure(), type.getAnnotations(), type.getJavaClass());
/*     */   }
/*     */   
/*     */   public Set<AnnotatedConstructor<T>> getConstructors() {
/*  76 */     return this.constructors;
/*     */   }
/*     */   
/*     */   public void setConstructors(Set<AnnotatedConstructor<T>> constructors) {
/*  80 */     this.constructors = constructors;
/*     */   }
/*     */   
/*     */   public Set<AnnotatedField<? super T>> getFields() {
/*  84 */     return this.fields;
/*     */   }
/*     */   
/*     */   public void setFields(Set<AnnotatedField<? super T>> fields) {
/*  88 */     this.fields = fields;
/*     */   }
/*     */   
/*     */   public Class<T> getJavaClass() {
/*  92 */     return this.javaClass;
/*     */   }
/*     */   
/*     */   public Set<AnnotatedMethod<? super T>> getMethods() {
/*  96 */     return this.methods;
/*     */   }
/*     */   
/*     */   public void setMethods(Set<AnnotatedMethod<? super T>> methods) {
/* 100 */     this.methods = methods;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\cdi\AnnotatedTypeImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */