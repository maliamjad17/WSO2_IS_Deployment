/*     */ package com.sun.jersey.server.impl.cdi;
/*     */ 
/*     */ import com.sun.jersey.api.core.ResourceConfig;
/*     */ import com.sun.jersey.core.spi.component.ComponentContext;
/*     */ import com.sun.jersey.core.spi.component.ComponentScope;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCComponentProvider;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCComponentProviderFactory;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCDestroyable;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCFullyManagedComponentProvider;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCInstantiatedComponentProvider;
/*     */ import com.sun.jersey.spi.container.WebApplication;
/*     */ import com.sun.jersey.spi.container.WebApplicationListener;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Logger;
/*     */ import javax.annotation.ManagedBean;
/*     */ import javax.enterprise.context.ApplicationScoped;
/*     */ import javax.enterprise.context.Dependent;
/*     */ import javax.enterprise.context.RequestScoped;
/*     */ import javax.enterprise.context.spi.CreationalContext;
/*     */ import javax.enterprise.inject.spi.Bean;
/*     */ import javax.enterprise.inject.spi.BeanManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CDIComponentProviderFactory
/*     */   implements IoCComponentProviderFactory, WebApplicationListener
/*     */ {
/*  79 */   private static final Logger LOGGER = Logger.getLogger(CDIComponentProviderFactory.class.getName());
/*     */   
/*     */   private final BeanManager beanManager;
/*     */   private final CDIExtension extension;
/*     */   
/*     */   public CDIComponentProviderFactory(Object bm, ResourceConfig rc, WebApplication wa)
/*     */   {
/*  86 */     this.beanManager = ((BeanManager)bm);
/*     */     
/*  88 */     if (CDIExtension.lookupExtensionInBeanManager) {
/*  89 */       this.extension = ((CDIExtension)Utils.getInstance(this.beanManager, CDIExtension.class));
/*     */     }
/*     */     else {
/*  92 */       this.extension = CDIExtension.getInitializedExtension();
/*     */     }
/*  94 */     this.extension.setWebApplication(wa);
/*  95 */     this.extension.setResourceConfig(rc);
/*     */   }
/*     */   
/*     */   public void onWebApplicationReady() {
/*  99 */     this.extension.lateInitialize();
/*     */   }
/*     */   
/*     */   public IoCComponentProvider getComponentProvider(Class<?> c) {
/* 103 */     return getComponentProvider(null, c);
/*     */   }
/*     */   
/*     */   public IoCComponentProvider getComponentProvider(ComponentContext cc, final Class<?> c) {
/* 107 */     final Bean<?> b = Utils.getBean(this.beanManager, c);
/* 108 */     if (b == null) {
/* 109 */       return null;
/*     */     }
/*     */     
/* 112 */     Class<? extends Annotation> s = b.getScope();
/* 113 */     final ComponentScope cs = getComponentScope(b);
/*     */     
/* 115 */     if (s == Dependent.class) {
/* 116 */       if (!c.isAnnotationPresent(ManagedBean.class)) {
/* 117 */         return null;
/*     */       }
/*     */       
/* 120 */       LOGGER.fine("Binding the CDI managed bean " + c.getName() + " in scope " + s.getName() + " to CDIComponentProviderFactory");
/*     */       
/*     */ 
/*     */ 
/* 124 */       new ComponentProviderDestroyable()
/*     */       {
/*     */ 
/*     */         public Object getInjectableInstance(Object o)
/*     */         {
/* 129 */           return o;
/*     */         }
/*     */         
/*     */         public Object getInstance() {
/* 133 */           CreationalContext<?> bcc = CDIComponentProviderFactory.this.beanManager.createCreationalContext(b);
/* 134 */           return c.cast(CDIComponentProviderFactory.this.beanManager.getReference(b, c, bcc));
/*     */         }
/*     */         
/*     */ 
/*     */         public void destroy(Object o)
/*     */         {
/* 140 */           CreationalContext cc = CDIComponentProviderFactory.this.beanManager.createCreationalContext(b);
/* 141 */           b.destroy(o, cc);
/*     */         }
/*     */       };
/*     */     }
/*     */     
/* 146 */     LOGGER.fine("Binding the CDI managed bean " + c.getName() + " in scope " + s.getName() + " to CDIComponentProviderFactory in scope " + cs);
/*     */     
/*     */ 
/*     */ 
/* 150 */     new IoCFullyManagedComponentProvider() {
/*     */       public ComponentScope getScope() {
/* 152 */         return cs;
/*     */       }
/*     */       
/*     */       public Object getInstance() {
/* 156 */         CreationalContext<?> bcc = CDIComponentProviderFactory.this.beanManager.createCreationalContext(b);
/* 157 */         return c.cast(CDIComponentProviderFactory.this.beanManager.getReference(b, c, bcc));
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ComponentScope getComponentScope(Bean<?> b)
/*     */   {
/* 167 */     ComponentScope cs = (ComponentScope)this.scopeMap.get(b.getScope());
/* 168 */     return cs != null ? cs : ComponentScope.Undefined;
/*     */   }
/*     */   
/* 171 */   private final Map<Class<? extends Annotation>, ComponentScope> scopeMap = createScopeMap();
/*     */   
/*     */   private Map<Class<? extends Annotation>, ComponentScope> createScopeMap() {
/* 174 */     Map<Class<? extends Annotation>, ComponentScope> m = new HashMap();
/*     */     
/* 176 */     m.put(ApplicationScoped.class, ComponentScope.Singleton);
/* 177 */     m.put(RequestScoped.class, ComponentScope.PerRequest);
/* 178 */     m.put(Dependent.class, ComponentScope.PerRequest);
/* 179 */     return Collections.unmodifiableMap(m);
/*     */   }
/*     */   
/*     */   private static abstract interface ComponentProviderDestroyable
/*     */     extends IoCInstantiatedComponentProvider, IoCDestroyable
/*     */   {}
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\cdi\CDIComponentProviderFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */