/*     */ package com.sun.jersey.server.impl.cdi;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import javax.ws.rs.DefaultValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiscoveredParameter
/*     */ {
/*     */   private Annotation annotation;
/*     */   private Type type;
/*     */   private DefaultValue defaultValue;
/*     */   private boolean encoded;
/*     */   
/*     */   public DiscoveredParameter(Annotation annotation, Type type, DefaultValue defaultValue, boolean encoded)
/*     */   {
/*  62 */     this.annotation = annotation;
/*  63 */     this.type = type;
/*  64 */     this.defaultValue = defaultValue;
/*  65 */     this.encoded = encoded;
/*     */   }
/*     */   
/*     */   public Annotation getAnnotation() {
/*  69 */     return this.annotation;
/*     */   }
/*     */   
/*     */   public Type getType() {
/*  73 */     return this.type;
/*     */   }
/*     */   
/*     */   public DefaultValue getDefaultValue() {
/*  77 */     return this.defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isEncoded() {
/*  81 */     return this.encoded;
/*     */   }
/*     */   
/*     */   public String getValue()
/*     */   {
/*     */     try {
/*  87 */       Method valueMethod = this.annotation.annotationType().getDeclaredMethod("value", new Class[0]);
/*  88 */       return (String)valueMethod.invoke(this.annotation, new Object[0]);
/*     */     }
/*     */     catch (NoSuchMethodException e)
/*     */     {
/*  92 */       return null;
/*     */     }
/*     */     catch (IllegalAccessException e)
/*     */     {
/*  96 */       throw new RuntimeException(e);
/*     */     }
/*     */     catch (InvocationTargetException e)
/*     */     {
/* 100 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 106 */     int result = 17;
/* 107 */     result = 31 * result + (this.annotation == null ? 0 : this.annotation.hashCode());
/* 108 */     result = 31 * result + (this.type == null ? 0 : this.type.hashCode());
/* 109 */     result = 31 * result + (this.defaultValue == null ? 0 : this.defaultValue.hashCode());
/* 110 */     result = 31 * result + (this.encoded ? 7 : 11);
/* 111 */     return result;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 116 */     if (this == obj) {
/* 117 */       return true;
/*     */     }
/*     */     
/* 120 */     if (obj == null) {
/* 121 */       return false;
/*     */     }
/*     */     
/* 124 */     if (obj.getClass() != getClass()) {
/* 125 */       return false;
/*     */     }
/*     */     
/* 128 */     DiscoveredParameter that = (DiscoveredParameter)obj;
/*     */     
/* 130 */     return (this.annotation == null ? that.annotation == null : this.annotation.equals(that.annotation)) && (this.type == null ? that.type == null : this.type.equals(that.type)) && (this.defaultValue == null ? that.defaultValue == null : this.defaultValue.equals(that.defaultValue)) && (this.encoded == that.encoded);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 138 */     StringBuilder sb = new StringBuilder();
/* 139 */     sb.append("DiscoveredParameter(");
/* 140 */     sb.append(this.annotation);
/* 141 */     sb.append(',');
/* 142 */     sb.append(this.type);
/* 143 */     sb.append(',');
/* 144 */     sb.append(this.defaultValue);
/* 145 */     sb.append(',');
/* 146 */     sb.append(this.encoded);
/* 147 */     sb.append(')');
/* 148 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\cdi\DiscoveredParameter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */