/*     */ package com.sun.jersey.server.impl.template;
/*     */ 
/*     */ import com.sun.jersey.api.view.Viewable;
/*     */ import com.sun.jersey.core.spi.component.ProviderServices;
/*     */ import com.sun.jersey.spi.template.ResolvedViewable;
/*     */ import com.sun.jersey.spi.template.TemplateContext;
/*     */ import com.sun.jersey.spi.template.TemplateContextException;
/*     */ import com.sun.jersey.spi.template.TemplateProcessor;
/*     */ import com.sun.jersey.spi.template.ViewProcessor;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.ws.rs.core.UriInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TemplateFactory
/*     */   implements TemplateContext
/*     */ {
/*     */   private final Set<ViewProcessor> viewProcessors;
/*     */   
/*     */   public TemplateFactory(ProviderServices providerServices)
/*     */   {
/*  63 */     this.viewProcessors = providerServices.getProvidersAndServices(ViewProcessor.class);
/*     */     
/*     */ 
/*  66 */     Set<TemplateProcessor> templateProcessors = providerServices.getProvidersAndServices(TemplateProcessor.class);
/*     */     
/*     */ 
/*  69 */     for (TemplateProcessor tp : templateProcessors) {
/*  70 */       this.viewProcessors.add(new TemplateViewProcessor(tp));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Set<ViewProcessor> getViewProcessors()
/*     */   {
/*  80 */     return this.viewProcessors;
/*     */   }
/*     */   
/*     */ 
/*     */   public ResolvedViewable resolveViewable(Viewable v)
/*     */   {
/*  86 */     if (v.isTemplateNameAbsolute())
/*  87 */       return resolveAbsoluteViewable(v);
/*  88 */     if (v.getResolvingClass() != null) {
/*  89 */       return resolveRelativeViewable(v, v.getResolvingClass());
/*     */     }
/*  91 */     if (v.getModel() == null) {
/*  92 */       throw new TemplateContextException("The model of the view MUST not be null");
/*     */     }
/*  94 */     return resolveRelativeViewable(v, v.getModel().getClass());
/*     */   }
/*     */   
/*     */   public ResolvedViewable resolveViewable(Viewable v, UriInfo ui)
/*     */   {
/*  99 */     if (v.isTemplateNameAbsolute())
/* 100 */       return resolveAbsoluteViewable(v);
/* 101 */     if (v.getResolvingClass() != null) {
/* 102 */       return resolveRelativeViewable(v, v.getResolvingClass());
/*     */     }
/* 104 */     List<Object> mrs = ui.getMatchedResources();
/* 105 */     if ((mrs == null) || (mrs.size() == 0)) {
/* 106 */       throw new TemplateContextException("There is no last matching resource available");
/*     */     }
/* 108 */     return resolveRelativeViewable(v, mrs.get(0).getClass());
/*     */   }
/*     */   
/*     */   public ResolvedViewable resolveViewable(Viewable v, Class<?> resolvingClass)
/*     */   {
/* 113 */     if (v.isTemplateNameAbsolute())
/* 114 */       return resolveAbsoluteViewable(v);
/* 115 */     if (v.getResolvingClass() != null) {
/* 116 */       return resolveRelativeViewable(v, v.getResolvingClass());
/*     */     }
/* 118 */     if (resolvingClass == null) {
/* 119 */       throw new TemplateContextException("Resolving class MUST not be null");
/*     */     }
/* 121 */     return resolveRelativeViewable(v, resolvingClass);
/*     */   }
/*     */   
/*     */ 
/*     */   private ResolvedViewable resolveAbsoluteViewable(Viewable v)
/*     */   {
/* 127 */     for (ViewProcessor vp : getViewProcessors()) {
/* 128 */       Object resolvedTemplateObject = vp.resolve(v.getTemplateName());
/* 129 */       if (resolvedTemplateObject != null) {
/* 130 */         return new ResolvedViewable(vp, resolvedTemplateObject, v);
/*     */       }
/*     */     }
/*     */     
/* 134 */     return null;
/*     */   }
/*     */   
/*     */   private ResolvedViewable resolveRelativeViewable(Viewable v, Class<?> resolvingClass) {
/* 138 */     String path = v.getTemplateName();
/* 139 */     if ((path == null) || (path.length() == 0)) {
/* 140 */       path = "index";
/*     */     }
/*     */     String absolutePath;
/* 143 */     for (Class c = resolvingClass; c != Object.class; c = c.getSuperclass()) {
/* 144 */       absolutePath = getAbsolutePath(c, path, '/');
/*     */       
/* 146 */       for (ViewProcessor vp : getViewProcessors()) {
/* 147 */         Object resolvedTemplateObject = vp.resolve(absolutePath);
/* 148 */         if (resolvedTemplateObject != null) {
/* 149 */           return new ResolvedViewable(vp, resolvedTemplateObject, v, c);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     String absolutePath;
/* 155 */     for (Class c = resolvingClass; c != Object.class; c = c.getSuperclass()) {
/* 156 */       absolutePath = getAbsolutePath(c, path, '.');
/*     */       
/* 158 */       for (ViewProcessor vp : getViewProcessors()) {
/* 159 */         Object resolvedTemplateObject = vp.resolve(absolutePath);
/* 160 */         if (resolvedTemplateObject != null) {
/* 161 */           return new ResolvedViewable(vp, resolvedTemplateObject, v, c);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 166 */     return null;
/*     */   }
/*     */   
/*     */   private String getAbsolutePath(Class<?> resourceClass, String path, char delim) {
/* 170 */     return '/' + resourceClass.getName().replace('.', '/').replace('$', delim) + delim + path;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\template\TemplateFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */