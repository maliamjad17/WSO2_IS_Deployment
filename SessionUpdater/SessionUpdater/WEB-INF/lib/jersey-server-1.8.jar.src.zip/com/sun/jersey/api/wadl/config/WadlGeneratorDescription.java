/*     */ package com.sun.jersey.api.wadl.config;
/*     */ 
/*     */ import com.sun.jersey.server.wadl.WadlGenerator;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WadlGeneratorDescription
/*     */ {
/*     */   private Class<? extends WadlGenerator> _generatorClass;
/*     */   private Properties _properties;
/*     */   
/*     */   public WadlGeneratorDescription() {}
/*     */   
/*     */   public WadlGeneratorDescription(Class<? extends WadlGenerator> generatorClass, Properties properties)
/*     */   {
/*  87 */     this._generatorClass = generatorClass;
/*  88 */     this._properties = properties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Class<? extends WadlGenerator> getGeneratorClass()
/*     */   {
/*  95 */     return this._generatorClass;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setGeneratorClass(Class<? extends WadlGenerator> generatorClass)
/*     */   {
/* 101 */     this._generatorClass = generatorClass;
/*     */   }
/*     */   
/*     */ 
/*     */   public Properties getProperties()
/*     */   {
/* 107 */     return this._properties;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setProperties(Properties properties)
/*     */   {
/* 113 */     this._properties = properties;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\wadl\config\WadlGeneratorDescription.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */