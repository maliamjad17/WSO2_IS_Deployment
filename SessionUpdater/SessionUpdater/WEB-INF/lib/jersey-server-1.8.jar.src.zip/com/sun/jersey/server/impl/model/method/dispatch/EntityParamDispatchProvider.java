/*     */ package com.sun.jersey.server.impl.model.method.dispatch;
/*     */ 
/*     */ import com.sun.jersey.api.core.HttpContext;
/*     */ import com.sun.jersey.api.core.HttpRequestContext;
/*     */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*     */ import com.sun.jersey.api.model.Parameter;
/*     */ import com.sun.jersey.api.model.Parameter.Source;
/*     */ import com.sun.jersey.core.spi.component.ComponentScope;
/*     */ import com.sun.jersey.server.impl.inject.AbstractHttpContextInjectable;
/*     */ import com.sun.jersey.server.impl.inject.InjectableValuesProvider;
/*     */ import com.sun.jersey.server.impl.inject.ServerInjectableProviderContext;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityParamDispatchProvider
/*     */   extends AbstractResourceMethodDispatchProvider
/*     */ {
/*     */   protected InjectableValuesProvider getInjectableValuesProvider(AbstractResourceMethod abstractResourceMethod)
/*     */   {
/*  64 */     return new InjectableValuesProvider(processParameters(abstractResourceMethod));
/*     */   }
/*     */   
/*     */   private List<Injectable> processParameters(AbstractResourceMethod method)
/*     */   {
/*  69 */     if ((null == method.getParameters()) || (0 == method.getParameters().size())) {
/*  70 */       return Collections.emptyList();
/*     */     }
/*     */     
/*  73 */     boolean hasEntity = false;
/*  74 */     List<Injectable> is = new ArrayList(method.getParameters().size());
/*  75 */     for (int i = 0; i < method.getParameters().size(); i++) {
/*  76 */       Parameter parameter = (Parameter)method.getParameters().get(i);
/*     */       
/*  78 */       if (Parameter.Source.ENTITY == parameter.getSource()) {
/*  79 */         hasEntity = true;
/*  80 */         is.add(processEntityParameter(parameter, method.getMethod().getParameterAnnotations()[i]));
/*     */       }
/*     */       else
/*     */       {
/*  84 */         is.add(getInjectableProviderContext().getInjectable(method.getMethod(), parameter, ComponentScope.PerRequest));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  89 */     if (hasEntity) {
/*  90 */       return is;
/*     */     }
/*     */     
/*     */ 
/*  94 */     if (Collections.frequency(is, null) == 1) {
/*  95 */       int i = is.lastIndexOf(null);
/*  96 */       Parameter parameter = (Parameter)method.getParameters().get(i);
/*  97 */       if ((Parameter.Source.UNKNOWN == parameter.getSource()) && 
/*  98 */         (!parameter.isQualified())) {
/*  99 */         Injectable ij = processEntityParameter(parameter, method.getMethod().getParameterAnnotations()[i]);
/*     */         
/*     */ 
/* 102 */         is.set(i, ij);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 107 */     return is;
/*     */   }
/*     */   
/*     */   static final class EntityInjectable extends AbstractHttpContextInjectable<Object> {
/*     */     final Class<?> c;
/*     */     final Type t;
/*     */     final Annotation[] as;
/*     */     
/*     */     EntityInjectable(Class c, Type t, Annotation[] as) {
/* 116 */       this.c = c;
/* 117 */       this.t = t;
/* 118 */       this.as = as;
/*     */     }
/*     */     
/*     */     public Object getValue(HttpContext context)
/*     */     {
/* 123 */       return context.getRequest().getEntity(this.c, this.t, this.as);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private Injectable processEntityParameter(Parameter parameter, Annotation[] annotations)
/*     */   {
/* 130 */     return new EntityInjectable(parameter.getParameterClass(), parameter.getParameterType(), annotations);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\method\dispatch\EntityParamDispatchProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */