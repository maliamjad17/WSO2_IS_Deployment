/*    */ package com.sun.jersey.api.core;
/*    */ 
/*    */ import com.sun.jersey.server.impl.application.WebApplicationContext;
/*    */ import com.sun.jersey.spi.container.ContainerResponse;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.ws.rs.core.MultivaluedMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TraceInformation
/*    */ {
/* 52 */   private final List<String> traces = new ArrayList();
/*    */   private final WebApplicationContext c;
/*    */   
/*    */   public TraceInformation(WebApplicationContext c)
/*    */   {
/* 57 */     this.c = c;
/*    */   }
/*    */   
/*    */   public void trace(String message) {
/* 61 */     this.traces.add(message);
/*    */   }
/*    */   
/*    */   public void addTraceHeaders() {
/* 65 */     addTraceHeaders(new TraceHeaderListener() {
/*    */       public void onHeader(String name, String value) {
/* 67 */         TraceInformation.this.c.getContainerResponse().getHttpHeaders().add(name, value);
/*    */       }
/*    */     });
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void addTraceHeaders(TraceHeaderListener x)
/*    */   {
/* 77 */     for (int i = 0; i < this.traces.size(); i++) {
/* 78 */       x.onHeader(String.format("X-Jersey-Trace-%03d", new Object[] { Integer.valueOf(i) }), (String)this.traces.get(i));
/*    */     }
/*    */     
/* 81 */     this.traces.clear();
/*    */   }
/*    */   
/*    */   public static abstract interface TraceHeaderListener
/*    */   {
/*    */     public abstract void onHeader(String paramString1, String paramString2);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\core\TraceInformation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */