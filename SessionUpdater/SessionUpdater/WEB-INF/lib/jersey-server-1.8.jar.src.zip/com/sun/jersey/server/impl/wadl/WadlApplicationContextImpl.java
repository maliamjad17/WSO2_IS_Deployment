/*     */ package com.sun.jersey.server.impl.wadl;
/*     */ 
/*     */ import com.sun.jersey.api.model.AbstractResource;
/*     */ import com.sun.jersey.server.wadl.WadlApplicationContext;
/*     */ import com.sun.jersey.server.wadl.WadlBuilder;
/*     */ import com.sun.jersey.server.wadl.WadlGenerator;
/*     */ import com.sun.research.ws.wadl.Application;
/*     */ import com.sun.research.ws.wadl.Resources;
/*     */ import java.net.URI;
/*     */ import java.util.Set;
/*     */ import javax.ws.rs.core.UriInfo;
/*     */ import javax.xml.bind.JAXBContext;
/*     */ import javax.xml.bind.JAXBException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WadlApplicationContextImpl
/*     */   implements WadlApplicationContext
/*     */ {
/*  60 */   private boolean wadlGenerationEnabled = true;
/*     */   
/*     */   private final Set<AbstractResource> rootResources;
/*     */   
/*     */   private final WadlGenerator wadlGenerator;
/*     */   private JAXBContext jaxbContext;
/*     */   
/*     */   public WadlApplicationContextImpl(Set<AbstractResource> rootResources, WadlGenerator wadlGenerator)
/*     */   {
/*  69 */     this.rootResources = rootResources;
/*  70 */     this.wadlGenerator = wadlGenerator;
/*     */     try {
/*  72 */       this.jaxbContext = JAXBContext.newInstance(wadlGenerator.getRequiredJaxbContextPath());
/*     */     } catch (JAXBException ex) {
/*  74 */       this.jaxbContext = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public Application getApplication() {
/*  79 */     return getWadlBuilder().generate(this.rootResources);
/*     */   }
/*     */   
/*     */   public Application getApplication(UriInfo ui) {
/*  83 */     Application a = getWadlBuilder().generate(this.rootResources);
/*  84 */     a.getResources().setBase(ui.getBaseUri().toString());
/*  85 */     return a;
/*     */   }
/*     */   
/*     */   public JAXBContext getJAXBContext() {
/*  89 */     return this.jaxbContext;
/*     */   }
/*     */   
/*     */   public String getJAXBContextPath() {
/*  93 */     return this.wadlGenerator.getRequiredJaxbContextPath();
/*     */   }
/*     */   
/*     */   public WadlBuilder getWadlBuilder() {
/*  97 */     return this.wadlGenerationEnabled ? new WadlBuilder(this.wadlGenerator) : null;
/*     */   }
/*     */   
/*     */   public void setWadlGenerationEnabled(boolean wadlGenerationEnabled)
/*     */   {
/* 102 */     this.wadlGenerationEnabled = wadlGenerationEnabled;
/*     */   }
/*     */   
/*     */   public boolean isWadlGenerationEnabled() {
/* 106 */     return this.wadlGenerationEnabled;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\wadl\WadlApplicationContextImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */