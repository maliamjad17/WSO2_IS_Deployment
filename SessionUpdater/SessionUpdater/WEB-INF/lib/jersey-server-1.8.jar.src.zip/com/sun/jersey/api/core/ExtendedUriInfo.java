package com.sun.jersey.api.core;

import com.sun.jersey.api.model.AbstractResourceMethod;
import com.sun.jersey.api.uri.UriTemplate;
import java.util.List;
import java.util.regex.MatchResult;
import javax.ws.rs.core.PathSegment;
import javax.ws.rs.core.UriInfo;

public abstract interface ExtendedUriInfo
  extends UriInfo
{
  public abstract AbstractResourceMethod getMatchedMethod();
  
  public abstract Throwable getMappedThrowable();
  
  public abstract List<MatchResult> getMatchedResults();
  
  public abstract List<UriTemplate> getMatchedTemplates();
  
  public abstract List<PathSegment> getPathSegments(String paramString);
  
  public abstract List<PathSegment> getPathSegments(String paramString, boolean paramBoolean);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\core\ExtendedUriInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */