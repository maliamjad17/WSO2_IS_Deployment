/*     */ package com.sun.jersey.server.wadl.generators.resourcedoc.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlAnyElement;
/*     */ import javax.xml.bind.annotation.XmlElementWrapper;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name="paramDoc", propOrder={})
/*     */ public class ParamDocType
/*     */ {
/*     */   private String paramName;
/*     */   private String commentText;
/*     */   @XmlElementWrapper(name="annotationDocs")
/*     */   protected List<AnnotationDocType> annotationDoc;
/*     */   @XmlAnyElement(lax=true)
/*     */   private List<Object> any;
/*     */   
/*     */   public ParamDocType() {}
/*     */   
/*     */   public ParamDocType(String paramName, String commentText)
/*     */   {
/*  71 */     this.paramName = paramName;
/*  72 */     this.commentText = commentText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<AnnotationDocType> getAnnotationDocs()
/*     */   {
/*  79 */     if (this.annotationDoc == null) {
/*  80 */       this.annotationDoc = new ArrayList();
/*     */     }
/*  82 */     return this.annotationDoc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<Object> getAny()
/*     */   {
/*  89 */     if (this.any == null) {
/*  90 */       this.any = new ArrayList();
/*     */     }
/*  92 */     return this.any;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getCommentText()
/*     */   {
/*  99 */     return this.commentText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setCommentText(String commentText)
/*     */   {
/* 106 */     this.commentText = commentText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getParamName()
/*     */   {
/* 113 */     return this.paramName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setParamName(String paramName)
/*     */   {
/* 120 */     this.paramName = paramName;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\wadl\generators\resourcedoc\model\ParamDocType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */