/*    */ package com.sun.jersey.server.wadl.generators.resourcedoc.model;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElementWrapper;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="resourceDoc", propOrder={"classDoc"})
/*    */ @XmlRootElement(name="resourceDoc")
/*    */ public class ResourceDocType
/*    */ {
/*    */   @XmlElementWrapper(name="classDocs")
/*    */   protected List<ClassDocType> classDoc;
/*    */   
/*    */   public List<ClassDocType> getDocs()
/*    */   {
/* 70 */     if (this.classDoc == null) {
/* 71 */       this.classDoc = new ArrayList();
/*    */     }
/* 73 */     return this.classDoc;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\wadl\generators\resourcedoc\model\ResourceDocType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */