/*     */ package com.sun.jersey.server.impl.application;
/*     */ 
/*     */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*     */ import com.sun.jersey.core.spi.component.ProviderServices;
/*     */ import com.sun.jersey.impl.ImplMessages;
/*     */ import com.sun.jersey.spi.container.ResourceMethodDispatchAdapter;
/*     */ import com.sun.jersey.spi.container.ResourceMethodDispatchProvider;
/*     */ import com.sun.jersey.spi.dispatch.RequestDispatcher;
/*     */ import com.sun.jersey.spi.inject.Errors;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResourceMethodDispatcherFactory
/*     */   implements ResourceMethodDispatchProvider
/*     */ {
/*  59 */   private static final Logger LOGGER = Logger.getLogger(ResourceMethodDispatcherFactory.class.getName());
/*     */   private final Set<ResourceMethodDispatchProvider> dispatchers;
/*     */   
/*     */   private ResourceMethodDispatcherFactory(ProviderServices providerServices)
/*     */   {
/*  64 */     this.dispatchers = providerServices.getProvidersAndServices(ResourceMethodDispatchProvider.class);
/*     */   }
/*     */   
/*     */   public static ResourceMethodDispatchProvider create(ProviderServices providerServices)
/*     */   {
/*  69 */     ResourceMethodDispatchProvider p = new ResourceMethodDispatcherFactory(providerServices);
/*     */     
/*     */ 
/*  72 */     for (ResourceMethodDispatchAdapter a : providerServices.getProvidersAndServices(ResourceMethodDispatchAdapter.class)) {
/*  73 */       p = a.adapt(p);
/*     */     }
/*  75 */     return p;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public RequestDispatcher create(AbstractResourceMethod abstractResourceMethod)
/*     */   {
/*     */     
/*     */     
/*  84 */     for (ResourceMethodDispatchProvider rmdp : this.dispatchers) {
/*     */       try {
/*  86 */         RequestDispatcher d = rmdp.create(abstractResourceMethod);
/*  87 */         if (d != null)
/*     */         {
/*     */ 
/*  90 */           Errors.reset();
/*  91 */           return d;
/*     */         }
/*     */       } catch (Exception e) {
/*  94 */         LOGGER.log(Level.SEVERE, ImplMessages.ERROR_PROCESSING_METHOD(abstractResourceMethod.getMethod(), rmdp.getClass().getName()), e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 100 */     Errors.unmark();
/* 101 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\application\ResourceMethodDispatcherFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */