package com.sun.jersey.server.spi.component;

import com.sun.jersey.core.spi.component.ComponentProviderFactory;
import com.sun.jersey.core.spi.component.ComponentScope;
import com.sun.jersey.core.spi.component.ioc.IoCComponentProvider;

public abstract interface ResourceComponentProviderFactory
  extends ComponentProviderFactory<ResourceComponentProvider>
{
  public abstract ComponentScope getScope(Class paramClass);
  
  public abstract ResourceComponentProvider getComponentProvider(IoCComponentProvider paramIoCComponentProvider, Class<?> paramClass);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\spi\component\ResourceComponentProviderFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */