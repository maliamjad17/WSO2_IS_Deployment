/*    */ package com.sun.jersey.server.spi.component;
/*    */ 
/*    */ import com.sun.jersey.api.model.AbstractResource;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceComponentDestructor
/*    */ {
/* 54 */   private final List<Method> preDestroys = new ArrayList();
/*    */   
/*    */   public ResourceComponentDestructor(AbstractResource ar) {
/* 57 */     this.preDestroys.addAll(ar.getPreDestroyMethods());
/*    */   }
/*    */   
/*    */   public void destroy(Object o) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/*    */   {
/* 62 */     for (Method preDestroy : this.preDestroys) {
/* 63 */       preDestroy.invoke(o, new Object[0]);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\spi\component\ResourceComponentDestructor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */