/*     */ package com.sun.jersey.server.impl.container.servlet;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.jsp.JspContext;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.SimpleTagSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Include
/*     */   extends SimpleTagSupport
/*     */ {
/*     */   private Class<?> resolvingClass;
/*     */   private String page;
/*     */   
/*     */   public void setPage(String page)
/*     */   {
/*  97 */     this.page = page;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setResolvingClass(Class<?> resolvingClass)
/*     */   {
/* 104 */     this.resolvingClass = resolvingClass;
/*     */   }
/*     */   
/*     */   private Object getPageObject(String name) {
/* 108 */     return getJspContext().getAttribute(name, 1);
/*     */   }
/*     */   
/*     */   public void doTag() throws JspException, IOException {
/* 112 */     Class<?> resolvingClass = (Class)getJspContext().getAttribute("resolvingClass", 2);
/* 113 */     Class<?> oldResolvingClass = resolvingClass;
/* 114 */     if (this.resolvingClass != null) {
/* 115 */       resolvingClass = this.resolvingClass;
/*     */     }
/*     */     
/* 118 */     ServletConfig cfg = (ServletConfig)getPageObject("javax.servlet.jsp.jspConfig");
/* 119 */     ServletContext sc = cfg.getServletContext();
/*     */     
/* 121 */     String basePath = (String)getJspContext().getAttribute("_basePath", 2);
/* 122 */     for (Class c = resolvingClass; c != Object.class; c = c.getSuperclass()) {
/* 123 */       String name = basePath + "/" + c.getName().replace('.', '/') + '/' + this.page;
/* 124 */       if (sc.getResource(name) != null)
/*     */       {
/*     */ 
/* 127 */         RequestDispatcher disp = sc.getRequestDispatcher(name);
/* 128 */         if (disp != null) {
/* 129 */           getJspContext().setAttribute("resolvingClass", resolvingClass, 2);
/*     */           try {
/* 131 */             HttpServletRequest request = (HttpServletRequest)getPageObject("javax.servlet.jsp.jspRequest");
/* 132 */             disp.include(request, new Wrapper((HttpServletResponse)getPageObject("javax.servlet.jsp.jspResponse"), new PrintWriter(getJspContext().getOut())));
/*     */ 
/*     */           }
/*     */           catch (ServletException e)
/*     */           {
/*     */ 
/* 138 */             throw new JspException(e);
/*     */           } finally {
/* 140 */             getJspContext().setAttribute("resolvingClass", oldResolvingClass, 2);
/*     */           }
/* 142 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 147 */     throw new JspException("Unable to find '" + this.page + "' for " + resolvingClass);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\container\servlet\Include.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */