/*     */ package com.sun.jersey.api.core;
/*     */ 
/*     */ import com.sun.jersey.core.spi.scanning.Scanner;
/*     */ import com.sun.jersey.spi.container.ReloadListener;
/*     */ import com.sun.jersey.spi.scanning.AnnotationScannerListener;
/*     */ import com.sun.jersey.spi.scanning.PathProviderScannerListener;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.ws.rs.Path;
/*     */ import javax.ws.rs.ext.Provider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScanningResourceConfig
/*     */   extends DefaultResourceConfig
/*     */   implements ReloadListener
/*     */ {
/*  63 */   private static final Logger LOGGER = Logger.getLogger(ScanningResourceConfig.class.getName());
/*     */   
/*     */ 
/*     */   private Scanner scanner;
/*     */   
/*  68 */   private final Set<Class<?>> cachedClasses = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void init(Scanner scanner)
/*     */   {
/*  77 */     this.scanner = scanner;
/*     */     
/*  79 */     AnnotationScannerListener asl = new PathProviderScannerListener();
/*  80 */     scanner.scan(asl);
/*     */     
/*  82 */     getClasses().addAll(asl.getAnnotatedClasses());
/*     */     
/*  84 */     if ((LOGGER.isLoggable(Level.INFO)) && (!getClasses().isEmpty())) {
/*  85 */       Set<Class> rootResourceClasses = get(Path.class);
/*  86 */       if (rootResourceClasses.isEmpty()) {
/*  87 */         LOGGER.log(Level.INFO, "No root resource classes found.");
/*     */       } else {
/*  89 */         logClasses("Root resource classes found:", rootResourceClasses);
/*     */       }
/*     */       
/*  92 */       Set<Class> providerClasses = get(Provider.class);
/*  93 */       if (providerClasses.isEmpty()) {
/*  94 */         LOGGER.log(Level.INFO, "No provider classes found.");
/*     */       } else {
/*  96 */         logClasses("Provider classes found:", providerClasses);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 101 */     this.cachedClasses.clear();
/* 102 */     this.cachedClasses.addAll(getClasses());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void reload()
/*     */   {
/* 112 */     onReload();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onReload()
/*     */   {
/* 120 */     Set<Class<?>> classesToRemove = new HashSet();
/* 121 */     Set<Class<?>> classesToAdd = new HashSet();
/*     */     
/* 123 */     for (Class c : getClasses()) {
/* 124 */       if (!this.cachedClasses.contains(c))
/* 125 */         classesToAdd.add(c);
/*     */     }
/* 127 */     for (Class c : this.cachedClasses) {
/* 128 */       if (!getClasses().contains(c))
/* 129 */         classesToRemove.add(c);
/*     */     }
/* 131 */     getClasses().clear();
/*     */     
/* 133 */     init(this.scanner);
/*     */     
/* 135 */     getClasses().addAll(classesToAdd);
/* 136 */     getClasses().removeAll(classesToRemove);
/*     */   }
/*     */   
/*     */   private Set<Class> get(Class<? extends Annotation> ac) {
/* 140 */     Set<Class> s = new HashSet();
/* 141 */     for (Class c : getClasses())
/* 142 */       if (c.isAnnotationPresent(ac))
/* 143 */         s.add(c);
/* 144 */     return s;
/*     */   }
/*     */   
/*     */   private void logClasses(String s, Set<Class> classes) {
/* 148 */     StringBuilder b = new StringBuilder();
/* 149 */     b.append(s);
/* 150 */     for (Class c : classes) {
/* 151 */       b.append('\n').append("  ").append(c);
/*     */     }
/* 153 */     LOGGER.log(Level.INFO, b.toString());
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\core\ScanningResourceConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */