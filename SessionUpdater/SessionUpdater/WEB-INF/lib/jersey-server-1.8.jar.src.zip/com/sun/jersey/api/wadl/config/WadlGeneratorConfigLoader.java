/*     */ package com.sun.jersey.api.wadl.config;
/*     */ 
/*     */ import com.sun.jersey.api.core.ResourceConfig;
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*     */ import com.sun.jersey.server.wadl.WadlGenerator;
/*     */ import com.sun.jersey.server.wadl.WadlGeneratorImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WadlGeneratorConfigLoader
/*     */ {
/*     */   public static WadlGenerator loadWadlGeneratorsFromConfig(ResourceConfig resourceConfig)
/*     */   {
/*  72 */     Object wadlGeneratorConfigProperty = resourceConfig.getProperty("com.sun.jersey.config.property.WadlGeneratorConfig");
/*     */     
/*  74 */     if (wadlGeneratorConfigProperty == null) {
/*  75 */       WadlGenerator wadlGenerator = new WadlGeneratorImpl();
/*     */       try {
/*  77 */         wadlGenerator.init();
/*  78 */         return wadlGenerator;
/*     */       } catch (Exception e) {
/*  80 */         throw new RuntimeException("Could not init the " + wadlGenerator.getClass().getName(), e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  87 */       if ((wadlGeneratorConfigProperty instanceof WadlGeneratorConfig)) {
/*  88 */         return ((WadlGeneratorConfig)wadlGeneratorConfigProperty).getWadlGenerator();
/*     */       }
/*     */       
/*     */       Class<? extends WadlGeneratorConfig> configClazz;
/*  92 */       if ((wadlGeneratorConfigProperty instanceof Class)) {
/*  93 */         configClazz = ((Class)wadlGeneratorConfigProperty).asSubclass(WadlGeneratorConfig.class);
/*     */       } else {
/*     */         Class<? extends WadlGeneratorConfig> configClazz;
/*  96 */         if ((wadlGeneratorConfigProperty instanceof String)) {
/*  97 */           configClazz = ReflectionHelper.classForNameWithException((String)wadlGeneratorConfigProperty).asSubclass(WadlGeneratorConfig.class);
/*     */         }
/*     */         else
/*     */         {
/* 101 */           throw new RuntimeException("The property com.sun.jersey.config.property.WadlGeneratorConfig is an invalid type: " + wadlGeneratorConfigProperty.getClass().getName() + " (supported: String, Class<? extends WadlGeneratorConfiguration>," + " WadlGeneratorConfiguration)");
/*     */         }
/*     */       }
/*     */       
/*     */       Class<? extends WadlGeneratorConfig> configClazz;
/*     */       
/* 107 */       WadlGeneratorConfig config = (WadlGeneratorConfig)configClazz.newInstance();
/*     */       
/* 109 */       return config.getWadlGenerator();
/*     */     }
/*     */     catch (Exception e) {
/* 112 */       throw new RuntimeException("Could not load WadlGeneratorConfiguration, check the configuration of com.sun.jersey.config.property.WadlGeneratorConfig", e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\wadl\config\WadlGeneratorConfigLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */