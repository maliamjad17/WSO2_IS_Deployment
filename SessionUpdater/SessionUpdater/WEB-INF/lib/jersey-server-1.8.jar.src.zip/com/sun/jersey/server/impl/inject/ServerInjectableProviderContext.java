package com.sun.jersey.server.impl.inject;

import com.sun.jersey.api.model.Parameter;
import com.sun.jersey.core.spi.component.ComponentScope;
import com.sun.jersey.spi.inject.Injectable;
import com.sun.jersey.spi.inject.InjectableProviderContext;
import com.sun.jersey.spi.inject.InjectableProviderContext.InjectableScopePair;
import java.lang.reflect.AccessibleObject;
import java.util.List;

public abstract interface ServerInjectableProviderContext
  extends InjectableProviderContext
{
  public abstract boolean isParameterTypeRegistered(Parameter paramParameter);
  
  public abstract Injectable getInjectable(Parameter paramParameter, ComponentScope paramComponentScope);
  
  public abstract Injectable getInjectable(AccessibleObject paramAccessibleObject, Parameter paramParameter, ComponentScope paramComponentScope);
  
  public abstract InjectableProviderContext.InjectableScopePair getInjectableiWithScope(Parameter paramParameter, ComponentScope paramComponentScope);
  
  public abstract InjectableProviderContext.InjectableScopePair getInjectableiWithScope(AccessibleObject paramAccessibleObject, Parameter paramParameter, ComponentScope paramComponentScope);
  
  public abstract List<Injectable> getInjectable(List<Parameter> paramList, ComponentScope paramComponentScope);
  
  public abstract List<Injectable> getInjectable(AccessibleObject paramAccessibleObject, List<Parameter> paramList, ComponentScope paramComponentScope);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\inject\ServerInjectableProviderContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */