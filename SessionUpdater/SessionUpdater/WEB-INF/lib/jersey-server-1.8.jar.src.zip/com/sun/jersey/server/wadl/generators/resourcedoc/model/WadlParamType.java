/*     */ package com.sun.jersey.server.wadl.generators.resourcedoc.model;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlAttribute;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name="wadlParam", propOrder={})
/*     */ public class WadlParamType
/*     */ {
/*     */   @XmlAttribute
/*     */   private String name;
/*     */   @XmlAttribute
/*     */   private String style;
/*     */   @XmlAttribute
/*     */   private QName type;
/*     */   private String doc;
/*     */   
/*     */   public String getDoc()
/*     */   {
/*  73 */     return this.doc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDoc(String commentText)
/*     */   {
/*  80 */     this.doc = commentText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/*  87 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setName(String paramName)
/*     */   {
/*  94 */     this.name = paramName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getStyle()
/*     */   {
/* 101 */     return this.style;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setStyle(String style)
/*     */   {
/* 108 */     this.style = style;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public QName getType()
/*     */   {
/* 115 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setType(QName type)
/*     */   {
/* 122 */     this.type = type;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\wadl\generators\resourcedoc\model\WadlParamType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */