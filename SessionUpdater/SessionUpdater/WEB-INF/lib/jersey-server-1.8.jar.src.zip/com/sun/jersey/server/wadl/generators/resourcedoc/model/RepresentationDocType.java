/*     */ package com.sun.jersey.server.wadl.generators.resourcedoc.model;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlAttribute;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name="representationDoc", propOrder={})
/*     */ public class RepresentationDocType
/*     */ {
/*     */   @XmlAttribute
/*     */   private QName element;
/*     */   private String example;
/*     */   @XmlAttribute
/*     */   private Long status;
/*     */   @XmlAttribute
/*     */   private String mediaType;
/*     */   private String doc;
/*     */   
/*     */   public QName getElement()
/*     */   {
/*  74 */     return this.element;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setElement(QName element)
/*     */   {
/*  80 */     this.element = element;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getExample()
/*     */   {
/*  86 */     return this.example;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setExample(String example)
/*     */   {
/*  92 */     this.example = example;
/*     */   }
/*     */   
/*     */ 
/*     */   public Long getStatus()
/*     */   {
/*  98 */     return this.status;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setStatus(Long status)
/*     */   {
/* 104 */     this.status = status;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getMediaType()
/*     */   {
/* 110 */     return this.mediaType;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setMediaType(String mediaType)
/*     */   {
/* 116 */     this.mediaType = mediaType;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getDoc()
/*     */   {
/* 122 */     return this.doc;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setDoc(String doc)
/*     */   {
/* 128 */     this.doc = doc;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\wadl\generators\resourcedoc\model\RepresentationDocType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */