/*    */ package com.sun.jersey.server.impl.model.parameter.multivalued;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import java.util.WeakHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PrimitiveMapper
/*    */ {
/* 53 */   static final Map<Class, Class> primitiveToClassMap = ;
/*    */   
/*    */ 
/* 56 */   static final Map<Class, Object> primitiveToDefaultValueMap = getPrimitiveToDefaultValueMap();
/*    */   
/*    */   private static Map<Class, Class> getPrimitiveToClassMap()
/*    */   {
/* 60 */     Map<Class, Class> m = new WeakHashMap();
/*    */     
/*    */ 
/* 63 */     m.put(Boolean.TYPE, Boolean.class);
/* 64 */     m.put(Byte.TYPE, Byte.class);
/* 65 */     m.put(Short.TYPE, Short.class);
/* 66 */     m.put(Integer.TYPE, Integer.class);
/* 67 */     m.put(Long.TYPE, Long.class);
/* 68 */     m.put(Float.TYPE, Float.class);
/* 69 */     m.put(Double.TYPE, Double.class);
/*    */     
/* 71 */     return Collections.unmodifiableMap(m);
/*    */   }
/*    */   
/*    */   private static Map<Class, Object> getPrimitiveToDefaultValueMap() {
/* 75 */     Map<Class, Object> m = new WeakHashMap();
/* 76 */     m.put(Boolean.class, Boolean.valueOf(false));
/* 77 */     m.put(Byte.class, Byte.valueOf((byte)0));
/* 78 */     m.put(Short.class, Short.valueOf((short)0));
/* 79 */     m.put(Integer.class, Integer.valueOf(0));
/* 80 */     m.put(Long.class, Long.valueOf(0L));
/* 81 */     m.put(Float.class, Float.valueOf(0.0F));
/* 82 */     m.put(Double.class, Double.valueOf(0.0D));
/*    */     
/* 84 */     return Collections.unmodifiableMap(m);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\parameter\multivalued\PrimitiveMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */