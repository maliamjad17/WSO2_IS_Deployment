/*    */ package com.sun.jersey.spi.container.servlet;
/*    */ 
/*    */ import com.sun.jersey.api.core.ResourceConfig;
/*    */ import java.util.Enumeration;
/*    */ import java.util.Map;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface WebConfig
/*    */ {
/*    */   public abstract ConfigType getConfigType();
/*    */   
/*    */   public abstract String getName();
/*    */   
/*    */   public abstract String getInitParameter(String paramString);
/*    */   
/*    */   public abstract Enumeration getInitParameterNames();
/*    */   
/*    */   public abstract ServletContext getServletContext();
/*    */   
/*    */   public abstract ResourceConfig getDefaultResourceConfig(Map<String, Object> paramMap)
/*    */     throws ServletException;
/*    */   
/*    */   public static enum ConfigType
/*    */   {
/* 64 */     ServletConfig, 
/*    */     
/*    */ 
/*    */ 
/* 68 */     FilterConfig;
/*    */     
/*    */     private ConfigType() {}
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\container\servlet\WebConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */