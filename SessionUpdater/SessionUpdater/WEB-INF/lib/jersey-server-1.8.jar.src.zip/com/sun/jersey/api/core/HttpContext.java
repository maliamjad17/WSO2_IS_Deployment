package com.sun.jersey.api.core;

import java.util.Map;

public abstract interface HttpContext
  extends Traceable
{
  public abstract ExtendedUriInfo getUriInfo();
  
  public abstract HttpRequestContext getRequest();
  
  public abstract HttpResponseContext getResponse();
  
  public abstract Map<String, Object> getProperties();
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\core\HttpContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */