/*    */ package com.sun.jersey.server.impl.model.method.dispatch;
/*    */ 
/*    */ import com.sun.jersey.api.core.HttpContext;
/*    */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*    */ import com.sun.jersey.spi.container.JavaMethodInvoker;
/*    */ import com.sun.jersey.spi.container.JavaMethodInvokerFactory;
/*    */ import com.sun.jersey.spi.container.ResourceMethodCustomInvokerDispatchProvider;
/*    */ import com.sun.jersey.spi.container.ResourceMethodDispatchProvider;
/*    */ import com.sun.jersey.spi.dispatch.RequestDispatcher;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VoidVoidDispatchProvider
/*    */   implements ResourceMethodDispatchProvider, ResourceMethodCustomInvokerDispatchProvider
/*    */ {
/*    */   public static final class VoidVoidMethodInvoker
/*    */     extends ResourceJavaMethodDispatcher
/*    */   {
/*    */     public VoidVoidMethodInvoker(AbstractResourceMethod abstractResourceMethod)
/*    */     {
/* 61 */       this(abstractResourceMethod, JavaMethodInvokerFactory.getDefault());
/*    */     }
/*    */     
/*    */     public VoidVoidMethodInvoker(AbstractResourceMethod abstractResourceMethod, JavaMethodInvoker invoker) {
/* 65 */       super(invoker);
/*    */     }
/*    */     
/*    */     public void _dispatch(Object resource, HttpContext context)
/*    */       throws IllegalAccessException, InvocationTargetException
/*    */     {
/* 71 */       this.invoker.invoke(this.method, resource, new Object[0]);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public RequestDispatcher create(AbstractResourceMethod abstractResourceMethod)
/*    */   {
/* 78 */     return create(abstractResourceMethod, JavaMethodInvokerFactory.getDefault());
/*    */   }
/*    */   
/*    */   public RequestDispatcher create(AbstractResourceMethod abstractResourceMethod, JavaMethodInvoker invoker)
/*    */   {
/* 83 */     if (!abstractResourceMethod.getParameters().isEmpty()) return null;
/* 84 */     if (abstractResourceMethod.getReturnType() != Void.TYPE) { return null;
/*    */     }
/* 86 */     return new VoidVoidMethodInvoker(abstractResourceMethod, invoker);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\method\dispatch\VoidVoidDispatchProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */