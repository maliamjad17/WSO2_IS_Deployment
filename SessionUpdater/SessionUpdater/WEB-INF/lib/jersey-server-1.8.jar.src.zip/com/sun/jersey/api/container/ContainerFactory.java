/*     */ package com.sun.jersey.api.container;
/*     */ 
/*     */ import com.sun.jersey.api.core.ClasspathResourceConfig;
/*     */ import com.sun.jersey.api.core.DefaultResourceConfig;
/*     */ import com.sun.jersey.api.core.ResourceConfig;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCComponentProviderFactory;
/*     */ import com.sun.jersey.spi.container.ContainerListener;
/*     */ import com.sun.jersey.spi.container.ContainerNotifier;
/*     */ import com.sun.jersey.spi.container.ContainerProvider;
/*     */ import com.sun.jersey.spi.container.WebApplication;
/*     */ import com.sun.jersey.spi.container.WebApplicationFactory;
/*     */ import com.sun.jersey.spi.service.ServiceFinder;
/*     */ import java.io.File;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ContainerFactory
/*     */ {
/*     */   public static <A> A createContainer(Class<A> type, Class<?>... resourceClasses)
/*     */     throws ContainerException, IllegalArgumentException
/*     */   {
/*  88 */     Set<Class<?>> resourceClassesSet = new HashSet(Arrays.asList(resourceClasses));
/*     */     
/*     */ 
/*  91 */     return (A)createContainer(type, new DefaultResourceConfig(resourceClassesSet), null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <A> A createContainer(Class<A> type, Set<Class<?>> resourceClasses)
/*     */     throws ContainerException, IllegalArgumentException
/*     */   {
/* 113 */     return (A)createContainer(type, new DefaultResourceConfig(resourceClasses), null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <A> A createContainer(Class<A> type, ResourceConfig resourceConfig)
/*     */     throws ContainerException, IllegalArgumentException
/*     */   {
/* 134 */     return (A)createContainer(type, resourceConfig, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <A> A createContainer(Class<A> type, ResourceConfig resourceConfig, IoCComponentProviderFactory factory)
/*     */     throws ContainerException, IllegalArgumentException
/*     */   {
/* 160 */     WebApplication wa = WebApplicationFactory.createWebApplication();
/*     */     
/*     */ 
/* 163 */     LinkedList<ContainerProvider> cps = new LinkedList();
/* 164 */     for (ContainerProvider cp : ServiceFinder.find(ContainerProvider.class, true)) {
/* 165 */       cps.addFirst(cp);
/*     */     }
/* 167 */     for (ContainerProvider<A> cp : cps) {
/* 168 */       A c = cp.createContainer(type, resourceConfig, wa);
/* 169 */       if (c != null)
/*     */       {
/* 171 */         if (!wa.isInitiated()) {
/* 172 */           wa.initiate(resourceConfig, factory);
/*     */         }
/*     */         
/*     */ 
/* 176 */         Object o = resourceConfig.getProperties().get("com.sun.jersey.spi.container.ContainerNotifier");
/*     */         
/* 178 */         if ((o instanceof List)) {
/* 179 */           List list = (List)o;
/* 180 */           for (Object elem : list) {
/* 181 */             if (((elem instanceof ContainerNotifier)) && ((c instanceof ContainerListener)))
/*     */             {
/* 183 */               ContainerNotifier crf = (ContainerNotifier)elem;
/* 184 */               crf.addListener((ContainerListener)c);
/*     */             }
/*     */           }
/* 187 */         } else if (((o instanceof ContainerNotifier)) && ((c instanceof ContainerListener)))
/*     */         {
/* 189 */           ContainerNotifier crf = (ContainerNotifier)o;
/* 190 */           crf.addListener((ContainerListener)c);
/*     */         }
/* 192 */         return c;
/*     */       }
/*     */     }
/*     */     
/* 196 */     throw new IllegalArgumentException("No container provider supports the type " + type);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static <A> A createContainer(Class<A> type, String packageName)
/*     */     throws ContainerException, IllegalArgumentException
/*     */   {
/* 217 */     String resourcesClassName = packageName + ".WebResources";
/*     */     try {
/* 219 */       Class<?> resourcesClass = ContainerFactory.class.getClassLoader().loadClass(resourcesClassName);
/* 220 */       ResourceConfig config = (ResourceConfig)resourcesClass.newInstance();
/* 221 */       return (A)createContainer(type, config, null);
/*     */     } catch (ClassNotFoundException e) {
/* 223 */       throw new ContainerException(e);
/*     */     } catch (InstantiationException e) {
/* 225 */       throw new ContainerException(e);
/*     */     } catch (IllegalAccessException e) {
/* 227 */       throw new ContainerException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <A> A createContainer(Class<A> type)
/*     */   {
/* 244 */     String classPath = System.getProperty("java.class.path");
/* 245 */     String[] paths = classPath.split(File.pathSeparator);
/* 246 */     return (A)createContainer(type, paths);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <A> A createContainer(Class<A> type, String... paths)
/*     */   {
/* 263 */     ClasspathResourceConfig config = new ClasspathResourceConfig(paths);
/* 264 */     return (A)createContainer(type, config, null);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\container\ContainerFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */