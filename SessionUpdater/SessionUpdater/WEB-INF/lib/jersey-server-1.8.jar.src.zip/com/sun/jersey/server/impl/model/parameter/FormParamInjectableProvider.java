/*     */ package com.sun.jersey.server.impl.model.parameter;
/*     */ 
/*     */ import com.sun.jersey.api.ParamException.FormParamException;
/*     */ import com.sun.jersey.api.core.HttpContext;
/*     */ import com.sun.jersey.api.core.HttpRequestContext;
/*     */ import com.sun.jersey.api.model.Parameter;
/*     */ import com.sun.jersey.api.representation.Form;
/*     */ import com.sun.jersey.core.header.MediaTypes;
/*     */ import com.sun.jersey.core.spi.component.ComponentContext;
/*     */ import com.sun.jersey.server.impl.inject.AbstractHttpContextInjectable;
/*     */ import com.sun.jersey.server.impl.model.parameter.multivalued.ExtractorContainerException;
/*     */ import com.sun.jersey.server.impl.model.parameter.multivalued.MultivaluedParameterExtractor;
/*     */ import com.sun.jersey.server.impl.model.parameter.multivalued.MultivaluedParameterExtractorProvider;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import java.util.Map;
/*     */ import javax.ws.rs.FormParam;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FormParamInjectableProvider
/*     */   extends BaseParamInjectableProvider<FormParam>
/*     */ {
/*     */   private static final class FormParamInjectable
/*     */     extends AbstractHttpContextInjectable<Object>
/*     */   {
/*     */     private final MultivaluedParameterExtractor extractor;
/*     */     private final boolean decode;
/*     */     
/*     */     FormParamInjectable(MultivaluedParameterExtractor extractor, boolean decode)
/*     */     {
/*  71 */       this.extractor = extractor;
/*  72 */       this.decode = decode;
/*     */     }
/*     */     
/*     */     public Object getValue(HttpContext context) {
/*  76 */       Form form = (Form)context.getProperties().get("com.sun.jersey.api.representation.form");
/*     */       
/*  78 */       if (form == null) {
/*  79 */         form = getForm(context);
/*  80 */         if (form == null) {
/*  81 */           throw new IllegalStateException("The @FormParam is utilized when the content type of the request entity is not application/x-www-form-urlencoded");
/*     */         }
/*     */       }
/*     */       
/*     */       try
/*     */       {
/*  87 */         return this.extractor.extract(form);
/*     */       } catch (ExtractorContainerException e) {
/*  89 */         throw new ParamException.FormParamException(e.getCause(), this.extractor.getName(), this.extractor.getDefaultStringValue());
/*     */       }
/*     */     }
/*     */     
/*     */     private Form getForm(HttpContext context)
/*     */     {
/*  95 */       HttpRequestContext r = context.getRequest();
/*  96 */       if (r.getMethod().equals("GET")) {
/*  97 */         return null;
/*     */       }
/*  99 */       if (!MediaTypes.typeEquals(MediaType.APPLICATION_FORM_URLENCODED_TYPE, r.getMediaType())) {
/* 100 */         return null;
/*     */       }
/* 102 */       Form form = r.getFormParameters();
/* 103 */       context.getProperties().put("com.sun.jersey.api.representation.form", form);
/* 104 */       return form;
/*     */     }
/*     */   }
/*     */   
/*     */   public FormParamInjectableProvider(MultivaluedParameterExtractorProvider w) {
/* 109 */     super(w);
/*     */   }
/*     */   
/*     */   public Injectable getInjectable(ComponentContext ic, FormParam a, Parameter c) {
/* 113 */     String parameterName = c.getSourceName();
/* 114 */     if ((parameterName == null) || (parameterName.length() == 0))
/*     */     {
/* 116 */       return null;
/*     */     }
/*     */     
/* 119 */     MultivaluedParameterExtractor e = get(c);
/* 120 */     if (e == null) {
/* 121 */       return null;
/*     */     }
/* 123 */     return new FormParamInjectable(e, !c.isEncoded());
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\parameter\FormParamInjectableProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */