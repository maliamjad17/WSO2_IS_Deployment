/*     */ package com.sun.jersey.server.impl.application;
/*     */ 
/*     */ import com.sun.jersey.api.container.ContainerException;
/*     */ import com.sun.jersey.api.core.DefaultResourceConfig;
/*     */ import com.sun.jersey.core.spi.component.ComponentProvider;
/*     */ import com.sun.jersey.core.spi.component.ProviderFactory;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Logger;
/*     */ import javax.ws.rs.core.Application;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeferredResourceConfig
/*     */   extends DefaultResourceConfig
/*     */ {
/*  57 */   private static final Logger LOGGER = Logger.getLogger(DeferredResourceConfig.class.getName());
/*     */   
/*     */   private final Class<? extends Application> appClass;
/*     */   
/*     */   private final Set<Class<?>> defaultClasses;
/*     */   
/*     */   public DeferredResourceConfig(Class<? extends Application> appClass)
/*     */   {
/*  65 */     this(appClass, Collections.emptySet());
/*     */   }
/*     */   
/*     */   public DeferredResourceConfig(Class<? extends Application> appClass, Set<Class<?>> defaultClasses)
/*     */   {
/*  70 */     this.appClass = appClass;
/*  71 */     this.defaultClasses = defaultClasses;
/*     */   }
/*     */   
/*     */   public ApplicationHolder getApplication(ProviderFactory pf) {
/*  75 */     return new ApplicationHolder(pf, null);
/*     */   }
/*     */   
/*     */   public class ApplicationHolder
/*     */   {
/*     */     private final Application originalApp;
/*     */     private final DefaultResourceConfig adaptedApp;
/*     */     
/*     */     private ApplicationHolder(ProviderFactory pf) {
/*  84 */       ComponentProvider cp = pf.getComponentProvider(DeferredResourceConfig.this.appClass);
/*  85 */       if (cp == null) {
/*  86 */         throw new ContainerException("The Application class " + DeferredResourceConfig.this.appClass.getName() + " could not be instantiated");
/*     */       }
/*  88 */       this.originalApp = ((Application)cp.getInstance());
/*     */       
/*  90 */       if (((this.originalApp.getClasses() == null) || (this.originalApp.getClasses().isEmpty())) && ((this.originalApp.getSingletons() == null) || (this.originalApp.getSingletons().isEmpty())))
/*     */       {
/*  92 */         DeferredResourceConfig.LOGGER.info("Instantiated the Application class " + DeferredResourceConfig.this.appClass.getName() + ". The following root resource and provider classes are registered: " + DeferredResourceConfig.this.defaultClasses);
/*     */         
/*  94 */         this.adaptedApp = new DefaultResourceConfig(DeferredResourceConfig.this.defaultClasses);
/*  95 */         this.adaptedApp.add(this.originalApp);
/*     */       } else {
/*  97 */         DeferredResourceConfig.LOGGER.info("Instantiated the Application class " + DeferredResourceConfig.this.appClass.getName());
/*  98 */         this.adaptedApp = null;
/*     */       }
/*     */     }
/*     */     
/*     */     public Application getOriginalApplication()
/*     */     {
/* 104 */       return this.originalApp;
/*     */     }
/*     */     
/*     */     public Application getApplication() {
/* 108 */       return this.adaptedApp != null ? this.adaptedApp : this.originalApp;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\application\DeferredResourceConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */