package com.sun.jersey.server.wadl;

import com.sun.research.ws.wadl.Application;
import javax.ws.rs.core.UriInfo;
import javax.xml.bind.JAXBContext;

public abstract interface WadlApplicationContext
{
  public abstract WadlBuilder getWadlBuilder();
  
  public abstract Application getApplication();
  
  public abstract Application getApplication(UriInfo paramUriInfo);
  
  public abstract JAXBContext getJAXBContext();
  
  public abstract String getJAXBContextPath();
  
  public abstract void setWadlGenerationEnabled(boolean paramBoolean);
  
  public abstract boolean isWadlGenerationEnabled();
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\wadl\WadlApplicationContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */