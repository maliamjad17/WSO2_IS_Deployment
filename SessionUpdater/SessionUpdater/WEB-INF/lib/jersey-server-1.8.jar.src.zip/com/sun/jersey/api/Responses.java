/*     */ package com.sun.jersey.api;
/*     */ 
/*     */ import javax.ws.rs.core.Response;
/*     */ import javax.ws.rs.core.Response.ResponseBuilder;
/*     */ import javax.ws.rs.core.Response.Status;
/*     */ import javax.ws.rs.core.Response.Status.Family;
/*     */ import javax.ws.rs.core.Response.StatusType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Responses
/*     */ {
/*     */   public static final int NO_CONTENT = 204;
/*     */   public static final int NOT_MODIFIED = 304;
/*     */   public static final int CLIENT_ERROR = 400;
/*     */   public static final int NOT_FOUND = 404;
/*     */   public static final int METHOD_NOT_ALLOWED = 405;
/*     */   public static final int NOT_ACCEPTABLE = 406;
/*     */   public static final int CONFLICT = 409;
/*     */   public static final int PRECONDITION_FAILED = 412;
/*     */   public static final int UNSUPPORTED_MEDIA_TYPE = 415;
/*  73 */   private static Response.StatusType METHOD_NOT_ALLOWED_TYPE = new Response.StatusType()
/*     */   {
/*     */     public int getStatusCode() {
/*  76 */       return 405;
/*     */     }
/*     */     
/*     */     public Response.Status.Family getFamily()
/*     */     {
/*  81 */       return Response.Status.Family.CLIENT_ERROR;
/*     */     }
/*     */     
/*     */     public String getReasonPhrase()
/*     */     {
/*  86 */       return "Method Not Allowed";
/*     */     }
/*     */   };
/*     */   
/*     */   public static Response.ResponseBuilder noContent() {
/*  91 */     return status(Response.Status.NO_CONTENT);
/*     */   }
/*     */   
/*     */   public static Response.ResponseBuilder notModified() {
/*  95 */     return status(Response.Status.NOT_MODIFIED);
/*     */   }
/*     */   
/*     */   public static Response.ResponseBuilder clientError() {
/*  99 */     return status(Response.Status.BAD_REQUEST);
/*     */   }
/*     */   
/*     */   public static Response.ResponseBuilder notFound() {
/* 103 */     return status(Response.Status.NOT_FOUND);
/*     */   }
/*     */   
/*     */   public static Response.ResponseBuilder methodNotAllowed() {
/* 107 */     return status(METHOD_NOT_ALLOWED_TYPE);
/*     */   }
/*     */   
/*     */   public static Response.ResponseBuilder notAcceptable() {
/* 111 */     return status(Response.Status.NOT_ACCEPTABLE);
/*     */   }
/*     */   
/*     */   public static Response.ResponseBuilder conflict() {
/* 115 */     return status(Response.Status.CONFLICT);
/*     */   }
/*     */   
/*     */   public static Response.ResponseBuilder preconditionFailed() {
/* 119 */     return status(Response.Status.PRECONDITION_FAILED);
/*     */   }
/*     */   
/*     */   public static Response.ResponseBuilder unsupportedMediaType() {
/* 123 */     return status(Response.Status.UNSUPPORTED_MEDIA_TYPE);
/*     */   }
/*     */   
/*     */   private static Response.ResponseBuilder status(Response.StatusType status) {
/* 127 */     return Response.status(status);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\Responses.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */