/*    */ package com.sun.jersey.server.impl.application;
/*    */ 
/*    */ import com.sun.jersey.api.core.HttpContext;
/*    */ import com.sun.jersey.core.spi.component.ComponentContext;
/*    */ import com.sun.jersey.core.spi.component.ComponentScope;
/*    */ import com.sun.jersey.spi.CloseableService;
/*    */ import com.sun.jersey.spi.inject.Injectable;
/*    */ import com.sun.jersey.spi.inject.InjectableProvider;
/*    */ import java.io.Closeable;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.HashSet;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ import javax.ws.rs.core.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CloseableServiceFactory
/*    */   implements InjectableProvider<Context, Type>, Injectable<CloseableService>, CloseableService
/*    */ {
/* 28 */   private static final Logger LOGGER = Logger.getLogger(CloseableServiceFactory.class.getName());
/*    */   private final HttpContext context;
/*    */   
/*    */   public CloseableServiceFactory(@Context HttpContext context)
/*    */   {
/* 33 */     this.context = context;
/*    */   }
/*    */   
/*    */ 
/*    */   public ComponentScope getScope()
/*    */   {
/* 39 */     return ComponentScope.Singleton;
/*    */   }
/*    */   
/*    */   public Injectable getInjectable(ComponentContext ic, Context a, Type c) {
/* 43 */     if (c != CloseableService.class) {
/* 44 */       return null;
/*    */     }
/* 46 */     return this;
/*    */   }
/*    */   
/*    */ 
/*    */   public CloseableService getValue()
/*    */   {
/* 52 */     return this;
/*    */   }
/*    */   
/*    */ 
/*    */   public void add(Closeable c)
/*    */   {
/* 58 */     Set<Closeable> s = (Set)this.context.getProperties().get(CloseableServiceFactory.class.getName());
/*    */     
/* 60 */     if (s == null) {
/* 61 */       s = new HashSet();
/* 62 */       this.context.getProperties().put(CloseableServiceFactory.class.getName(), s);
/*    */     }
/*    */     
/* 65 */     s.add(c);
/*    */   }
/*    */   
/*    */   public void close(HttpContext context) {
/* 69 */     Set<Closeable> s = (Set)context.getProperties().get(CloseableServiceFactory.class.getName());
/*    */     
/* 71 */     if (s != null) {
/* 72 */       for (Closeable c : s) {
/*    */         try {
/* 74 */           c.close();
/*    */         } catch (Exception ex) {
/* 76 */           LOGGER.log(Level.SEVERE, "Unable to close", ex);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\application\CloseableServiceFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */