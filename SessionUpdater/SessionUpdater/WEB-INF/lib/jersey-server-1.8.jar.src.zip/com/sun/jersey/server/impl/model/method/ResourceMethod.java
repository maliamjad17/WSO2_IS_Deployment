/*     */ package com.sun.jersey.server.impl.model.method;
/*     */ 
/*     */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*     */ import com.sun.jersey.api.uri.UriTemplate;
/*     */ import com.sun.jersey.core.header.MediaTypes;
/*     */ import com.sun.jersey.spi.container.ContainerRequestFilter;
/*     */ import com.sun.jersey.spi.container.ContainerResponseFilter;
/*     */ import com.sun.jersey.spi.dispatch.RequestDispatcher;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ResourceMethod
/*     */ {
/*  69 */   public static final Comparator<ResourceMethod> COMPARATOR = new Comparator()
/*     */   {
/*     */     public int compare(ResourceMethod o1, ResourceMethod o2) {
/*  72 */       int i = MediaTypes.MEDIA_TYPE_LIST_COMPARATOR.compare(o1.consumeMime, o2.consumeMime);
/*     */       
/*  74 */       if (i == 0) {
/*  75 */         i = MediaTypes.MEDIA_TYPE_LIST_COMPARATOR.compare(o1.produceMime, o2.produceMime);
/*     */       }
/*     */       
/*  78 */       return i;
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */   private final String httpMethod;
/*     */   
/*     */ 
/*     */   private final UriTemplate template;
/*     */   
/*     */ 
/*     */   private final List<? extends MediaType> consumeMime;
/*     */   
/*     */   private final List<? extends MediaType> produceMime;
/*     */   
/*     */   private final boolean isProducesDeclared;
/*     */   
/*     */   private final RequestDispatcher dispatcher;
/*     */   
/*     */   private final List<ContainerRequestFilter> requestFilters;
/*     */   
/*     */   private final List<ContainerResponseFilter> responseFilters;
/*     */   
/*     */ 
/*     */   public ResourceMethod(String httpMethod, UriTemplate template, List<? extends MediaType> consumeMime, List<? extends MediaType> produceMime, boolean isProducesDeclared, RequestDispatcher dispatcher)
/*     */   {
/* 104 */     this(httpMethod, template, consumeMime, produceMime, isProducesDeclared, dispatcher, Collections.EMPTY_LIST, Collections.EMPTY_LIST);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceMethod(String httpMethod, UriTemplate template, List<? extends MediaType> consumeMime, List<? extends MediaType> produceMime, boolean isProducesDeclared, RequestDispatcher dispatcher, List<ContainerRequestFilter> requestFilters, List<ContainerResponseFilter> responseFilters)
/*     */   {
/* 116 */     this.httpMethod = httpMethod;
/* 117 */     this.template = template;
/* 118 */     this.consumeMime = consumeMime;
/* 119 */     this.produceMime = produceMime;
/* 120 */     this.isProducesDeclared = isProducesDeclared;
/* 121 */     this.dispatcher = dispatcher;
/* 122 */     this.requestFilters = requestFilters;
/* 123 */     this.responseFilters = responseFilters;
/*     */   }
/*     */   
/*     */   public final String getHttpMethod() {
/* 127 */     return this.httpMethod;
/*     */   }
/*     */   
/*     */   public final UriTemplate getTemplate() {
/* 131 */     return this.template;
/*     */   }
/*     */   
/*     */   public final List<? extends MediaType> getConsumes() {
/* 135 */     return this.consumeMime;
/*     */   }
/*     */   
/*     */   public final List<? extends MediaType> getProduces() {
/* 139 */     return this.produceMime;
/*     */   }
/*     */   
/*     */   public final boolean isProducesDeclared() {
/* 143 */     return this.isProducesDeclared;
/*     */   }
/*     */   
/*     */   public final RequestDispatcher getDispatcher() {
/* 147 */     return this.dispatcher;
/*     */   }
/*     */   
/*     */   public final List<ContainerRequestFilter> getRequestFilters() {
/* 151 */     return this.requestFilters;
/*     */   }
/*     */   
/*     */   public final List<ContainerResponseFilter> getResponseFilters() {
/* 155 */     return this.responseFilters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean consumes(MediaType contentType)
/*     */   {
/* 167 */     for (MediaType c : this.consumeMime) {
/* 168 */       if (c.getType().equals("*")) { return true;
/*     */       }
/* 170 */       if (contentType.isCompatible(c)) { return true;
/*     */       }
/*     */     }
/* 173 */     return false;
/*     */   }
/*     */   
/*     */   public final boolean consumesWild() {
/* 177 */     for (MediaType c : this.consumeMime) {
/* 178 */       if (c.getType().equals("*")) { return true;
/*     */       }
/*     */     }
/* 181 */     return false;
/*     */   }
/*     */   
/*     */   public final boolean mediaEquals(ResourceMethod that) {
/* 185 */     boolean v = this.consumeMime.equals(that.consumeMime);
/* 186 */     if (!v) {
/* 187 */       return false;
/*     */     }
/* 189 */     return this.produceMime.equals(that.produceMime);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractResourceMethod getAbstractResourceMethod()
/*     */   {
/* 202 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\method\ResourceMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */