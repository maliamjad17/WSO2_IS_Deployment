/*     */ package com.sun.jersey.server.impl.model.method.dispatch;
/*     */ 
/*     */ import com.sun.jersey.api.core.HttpContext;
/*     */ import com.sun.jersey.api.core.HttpRequestContext;
/*     */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*     */ import com.sun.jersey.api.model.Parameter;
/*     */ import com.sun.jersey.api.model.Parameter.Source;
/*     */ import com.sun.jersey.api.representation.Form;
/*     */ import com.sun.jersey.core.spi.component.ComponentScope;
/*     */ import com.sun.jersey.server.impl.inject.AbstractHttpContextInjectable;
/*     */ import com.sun.jersey.server.impl.inject.InjectableValuesProvider;
/*     */ import com.sun.jersey.server.impl.inject.ServerInjectableProviderContext;
/*     */ import com.sun.jersey.server.impl.model.parameter.multivalued.MultivaluedParameterExtractorProvider;
/*     */ import com.sun.jersey.spi.container.JavaMethodInvoker;
/*     */ import com.sun.jersey.spi.container.JavaMethodInvokerFactory;
/*     */ import com.sun.jersey.spi.dispatch.RequestDispatcher;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.ws.rs.FormParam;
/*     */ import javax.ws.rs.core.Context;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormDispatchProvider
/*     */   extends AbstractResourceMethodDispatchProvider
/*     */ {
/*     */   public static final String FORM_PROPERTY = "com.sun.jersey.api.representation.form";
/*     */   @Context
/*     */   private MultivaluedParameterExtractorProvider mpep;
/*     */   
/*     */   public RequestDispatcher create(AbstractResourceMethod abstractResourceMethod)
/*     */   {
/*  73 */     return create(abstractResourceMethod, JavaMethodInvokerFactory.getDefault());
/*     */   }
/*     */   
/*     */   public RequestDispatcher create(AbstractResourceMethod abstractResourceMethod, JavaMethodInvoker invoker)
/*     */   {
/*  78 */     if ("GET".equals(abstractResourceMethod.getHttpMethod())) {
/*  79 */       return null;
/*     */     }
/*     */     
/*  82 */     return super.create(abstractResourceMethod, invoker);
/*     */   }
/*     */   
/*     */   protected InjectableValuesProvider getInjectableValuesProvider(AbstractResourceMethod abstractResourceMethod)
/*     */   {
/*  87 */     List<Injectable> is = processParameters(abstractResourceMethod);
/*  88 */     if (is == null) {
/*  89 */       return null;
/*     */     }
/*  91 */     return new FormParameterProvider(is);
/*     */   }
/*     */   
/*     */ 
/*     */   protected MultivaluedParameterExtractorProvider getMultivaluedParameterExtractorProvider()
/*     */   {
/*  97 */     return this.mpep;
/*     */   }
/*     */   
/*     */   private void processForm(HttpContext context) {
/* 101 */     Form form = (Form)context.getProperties().get("com.sun.jersey.api.representation.form");
/* 102 */     if (form == null) {
/* 103 */       form = (Form)context.getRequest().getEntity(Form.class);
/* 104 */       context.getProperties().put("com.sun.jersey.api.representation.form", form);
/*     */     }
/*     */   }
/*     */   
/*     */   private final class FormParameterProvider extends InjectableValuesProvider {
/*     */     public FormParameterProvider() {
/* 110 */       super();
/*     */     }
/*     */     
/*     */     public Object[] getInjectableValues(HttpContext context)
/*     */     {
/* 115 */       FormDispatchProvider.this.processForm(context);
/*     */       
/* 117 */       return super.getInjectableValues(context);
/*     */     }
/*     */   }
/*     */   
/*     */   private List<Injectable> processParameters(AbstractResourceMethod method) {
/* 122 */     if (method.getParameters().isEmpty()) {
/* 123 */       return null;
/*     */     }
/*     */     
/* 126 */     boolean hasFormParam = false;
/* 127 */     for (int i = 0; i < method.getParameters().size(); i++) {
/* 128 */       Parameter parameter = (Parameter)method.getParameters().get(i);
/* 129 */       if (parameter.getAnnotation() != null)
/* 130 */         hasFormParam |= parameter.getAnnotation().annotationType() == FormParam.class;
/*     */     }
/* 132 */     if (!hasFormParam) {
/* 133 */       return null;
/*     */     }
/* 135 */     return getInjectables(method);
/*     */   }
/*     */   
/*     */   private static final class FormEntityInjectable extends AbstractHttpContextInjectable<Object> {
/*     */     final Class<?> c;
/*     */     final Type t;
/*     */     final Annotation[] as;
/*     */     
/*     */     FormEntityInjectable(Class c, Type t, Annotation[] as) {
/* 144 */       this.c = c;
/* 145 */       this.t = t;
/* 146 */       this.as = as;
/*     */     }
/*     */     
/*     */     public Object getValue(HttpContext context)
/*     */     {
/* 151 */       return context.getProperties().get("com.sun.jersey.api.representation.form");
/*     */     }
/*     */   }
/*     */   
/*     */   protected List<Injectable> getInjectables(AbstractResourceMethod method) {
/* 156 */     List<Injectable> is = new ArrayList(method.getParameters().size());
/* 157 */     for (int i = 0; i < method.getParameters().size(); i++) {
/* 158 */       Parameter p = (Parameter)method.getParameters().get(i);
/*     */       
/* 160 */       if (Parameter.Source.ENTITY == p.getSource()) {
/* 161 */         if (MultivaluedMap.class.isAssignableFrom(p.getParameterClass())) {
/* 162 */           is.add(new FormEntityInjectable(p.getParameterClass(), p.getParameterType(), p.getAnnotations()));
/*     */         }
/*     */         else
/* 165 */           is.add(null);
/*     */       } else {
/* 167 */         Injectable injectable = getInjectableProviderContext().getInjectable(method.getMethod(), p, ComponentScope.PerRequest);
/*     */         
/* 169 */         is.add(injectable);
/*     */       }
/*     */     }
/* 172 */     return is;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\method\dispatch\FormDispatchProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */