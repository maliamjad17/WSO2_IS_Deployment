/*    */ package com.sun.jersey.api.model;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AbstractSubResourceLocator
/*    */   extends AbstractMethod
/*    */   implements PathAnnotated, Parameterized, AbstractModelComponent
/*    */ {
/*    */   private PathValue uriPath;
/*    */   private List<Parameter> parameters;
/*    */   
/*    */   public AbstractSubResourceLocator(AbstractResource resource, Method method, PathValue uriPath, Annotation[] annotations)
/*    */   {
/* 61 */     super(resource, method, annotations);
/*    */     
/* 63 */     this.uriPath = uriPath;
/* 64 */     this.parameters = new ArrayList();
/*    */   }
/*    */   
/*    */   public PathValue getPath() {
/* 68 */     return this.uriPath;
/*    */   }
/*    */   
/*    */   public List<Parameter> getParameters() {
/* 72 */     return this.parameters;
/*    */   }
/*    */   
/*    */   public void accept(AbstractModelVisitor visitor) {
/* 76 */     visitor.visitAbstractSubResourceLocator(this);
/*    */   }
/*    */   
/*    */   public List<AbstractModelComponent> getComponents() {
/* 80 */     return null;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 85 */     return "AbstractSubResourceLocator(" + getMethod().getDeclaringClass().getSimpleName() + "#" + getMethod().getName() + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\model\AbstractSubResourceLocator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */