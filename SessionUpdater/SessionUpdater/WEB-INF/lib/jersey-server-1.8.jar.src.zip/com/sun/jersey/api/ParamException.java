/*     */ package com.sun.jersey.api;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import javax.ws.rs.CookieParam;
/*     */ import javax.ws.rs.FormParam;
/*     */ import javax.ws.rs.HeaderParam;
/*     */ import javax.ws.rs.MatrixParam;
/*     */ import javax.ws.rs.PathParam;
/*     */ import javax.ws.rs.QueryParam;
/*     */ import javax.ws.rs.WebApplicationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ParamException
/*     */   extends WebApplicationException
/*     */ {
/*     */   private final Class<? extends Annotation> parameterType;
/*     */   private final String name;
/*     */   private final String defaultStringValue;
/*     */   
/*     */   public static abstract class URIParamException
/*     */     extends ParamException
/*     */   {
/*     */     protected URIParamException(Throwable cause, Class<? extends Annotation> parameterType, String name, String defaultStringValue)
/*     */     {
/*  84 */       super(404, parameterType, name, defaultStringValue);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class PathParamException
/*     */     extends ParamException.URIParamException
/*     */   {
/*     */     public PathParamException(Throwable cause, String name, String defaultStringValue)
/*     */     {
/*  93 */       super(PathParam.class, name, defaultStringValue);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class MatrixParamException
/*     */     extends ParamException.URIParamException
/*     */   {
/*     */     public MatrixParamException(Throwable cause, String name, String defaultStringValue)
/*     */     {
/* 102 */       super(MatrixParam.class, name, defaultStringValue);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class QueryParamException
/*     */     extends ParamException.URIParamException
/*     */   {
/*     */     public QueryParamException(Throwable cause, String name, String defaultStringValue)
/*     */     {
/* 111 */       super(QueryParam.class, name, defaultStringValue);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class HeaderParamException
/*     */     extends ParamException
/*     */   {
/*     */     public HeaderParamException(Throwable cause, String name, String defaultStringValue)
/*     */     {
/* 120 */       super(400, HeaderParam.class, name, defaultStringValue);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class CookieParamException
/*     */     extends ParamException
/*     */   {
/*     */     public CookieParamException(Throwable cause, String name, String defaultStringValue)
/*     */     {
/* 129 */       super(400, CookieParam.class, name, defaultStringValue);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class FormParamException
/*     */     extends ParamException
/*     */   {
/*     */     public FormParamException(Throwable cause, String name, String defaultStringValue)
/*     */     {
/* 138 */       super(400, FormParam.class, name, defaultStringValue);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ParamException(Throwable cause, int status, Class<? extends Annotation> parameterType, String name, String defaultStringValue)
/*     */   {
/* 150 */     super(cause, status);
/* 151 */     this.parameterType = parameterType;
/* 152 */     this.name = name;
/* 153 */     this.defaultStringValue = defaultStringValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<? extends Annotation> getParameterType()
/*     */   {
/* 162 */     return this.parameterType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getParameterName()
/*     */   {
/* 171 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDefaultStringValue()
/*     */   {
/* 180 */     return this.defaultStringValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\ParamException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */