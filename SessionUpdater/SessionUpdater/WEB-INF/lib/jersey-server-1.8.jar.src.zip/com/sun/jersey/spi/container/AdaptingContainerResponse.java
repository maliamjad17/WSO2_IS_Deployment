/*     */ package com.sun.jersey.spi.container;
/*     */ 
/*     */ import com.sun.jersey.api.container.MappableContainerException;
/*     */ import com.sun.jersey.spi.MessageBodyWorkers;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import javax.ws.rs.WebApplicationException;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.core.Response;
/*     */ import javax.ws.rs.core.Response.StatusType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AdaptingContainerResponse
/*     */   extends ContainerResponse
/*     */ {
/*     */   protected final ContainerResponse acr;
/*     */   
/*     */   protected AdaptingContainerResponse(ContainerResponse acr)
/*     */   {
/*  73 */     super(acr);
/*  74 */     this.acr = acr;
/*     */   }
/*     */   
/*     */   public void write()
/*     */     throws IOException
/*     */   {
/*  80 */     this.acr.write();
/*     */   }
/*     */   
/*     */   public void reset()
/*     */   {
/*  85 */     this.acr.reset();
/*     */   }
/*     */   
/*     */   public ContainerRequest getContainerRequest()
/*     */   {
/*  90 */     return this.acr.getContainerRequest();
/*     */   }
/*     */   
/*     */   public void setContainerRequest(ContainerRequest request)
/*     */   {
/*  95 */     this.acr.setContainerRequest(request);
/*     */   }
/*     */   
/*     */   public ContainerResponseWriter getContainerResponseWriter()
/*     */   {
/* 100 */     return this.acr.getContainerResponseWriter();
/*     */   }
/*     */   
/*     */   public void setContainerResponseWriter(ContainerResponseWriter responseWriter)
/*     */   {
/* 105 */     this.acr.setContainerResponseWriter(responseWriter);
/*     */   }
/*     */   
/*     */   public MessageBodyWorkers getMessageBodyWorkers()
/*     */   {
/* 110 */     return this.acr.getMessageBodyWorkers();
/*     */   }
/*     */   
/*     */   public void mapMappableContainerException(MappableContainerException e)
/*     */   {
/* 115 */     this.acr.mapMappableContainerException(e);
/*     */   }
/*     */   
/*     */   public void mapWebApplicationException(WebApplicationException e)
/*     */   {
/* 120 */     this.acr.mapWebApplicationException(e);
/*     */   }
/*     */   
/*     */   public boolean mapException(Throwable e)
/*     */   {
/* 125 */     return this.acr.mapException(e);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Response getResponse()
/*     */   {
/* 132 */     return this.acr.getResponse();
/*     */   }
/*     */   
/*     */   public void setResponse(Response response)
/*     */   {
/* 137 */     this.acr.setResponse(response);
/*     */   }
/*     */   
/*     */   public boolean isResponseSet()
/*     */   {
/* 142 */     return this.acr.isResponseSet();
/*     */   }
/*     */   
/*     */   public Throwable getMappedThrowable()
/*     */   {
/* 147 */     return this.acr.getMappedThrowable();
/*     */   }
/*     */   
/*     */   public Response.StatusType getStatusType()
/*     */   {
/* 152 */     return this.acr.getStatusType();
/*     */   }
/*     */   
/*     */   public void setStatusType(Response.StatusType statusType)
/*     */   {
/* 157 */     this.acr.setStatusType(statusType);
/*     */   }
/*     */   
/*     */   public int getStatus()
/*     */   {
/* 162 */     return this.acr.getStatus();
/*     */   }
/*     */   
/*     */   public void setStatus(int status)
/*     */   {
/* 167 */     this.acr.setStatus(status);
/*     */   }
/*     */   
/*     */   public Object getEntity()
/*     */   {
/* 172 */     return this.acr.getEntity();
/*     */   }
/*     */   
/*     */   public Type getEntityType()
/*     */   {
/* 177 */     return this.acr.getEntityType();
/*     */   }
/*     */   
/*     */   public Object getOriginalEntity()
/*     */   {
/* 182 */     return this.acr.getOriginalEntity();
/*     */   }
/*     */   
/*     */   public void setEntity(Object entity)
/*     */   {
/* 187 */     this.acr.setEntity(entity);
/*     */   }
/*     */   
/*     */   public void setEntity(Object entity, Type entityType)
/*     */   {
/* 192 */     this.acr.setEntity(entity, entityType);
/*     */   }
/*     */   
/*     */   public Annotation[] getAnnotations()
/*     */   {
/* 197 */     return this.acr.getAnnotations();
/*     */   }
/*     */   
/*     */   public void setAnnotations(Annotation[] annotations)
/*     */   {
/* 202 */     this.acr.setAnnotations(annotations);
/*     */   }
/*     */   
/*     */   public MultivaluedMap<String, Object> getHttpHeaders()
/*     */   {
/* 207 */     return this.acr.getHttpHeaders();
/*     */   }
/*     */   
/*     */   public MediaType getMediaType()
/*     */   {
/* 212 */     return this.acr.getMediaType();
/*     */   }
/*     */   
/*     */   public OutputStream getOutputStream() throws IOException
/*     */   {
/* 217 */     return this.acr.getOutputStream();
/*     */   }
/*     */   
/*     */   public boolean isCommitted()
/*     */   {
/* 222 */     return this.acr.isCommitted();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\container\AdaptingContainerResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */