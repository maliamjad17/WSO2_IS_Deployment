/*    */ package com.sun.jersey.api.container;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MappableContainerException
/*    */   extends ContainerException
/*    */ {
/*    */   public MappableContainerException(Throwable cause)
/*    */   {
/* 62 */     super(strip(cause));
/*    */   }
/*    */   
/*    */   private static Throwable strip(Throwable cause) {
/* 66 */     if ((cause instanceof MappableContainerException)) {
/*    */       do {
/* 68 */         MappableContainerException mce = (MappableContainerException)cause;
/* 69 */         cause = mce.getCause();
/* 70 */       } while ((cause instanceof MappableContainerException));
/*    */     }
/*    */     
/* 73 */     return cause;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\container\MappableContainerException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */