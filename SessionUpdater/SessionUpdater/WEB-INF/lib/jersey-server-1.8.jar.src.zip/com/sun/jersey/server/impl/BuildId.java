/*    */ package com.sun.jersey.server.impl;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BuildId
/*    */ {
/* 50 */   private static String buildId = ;
/*    */   
/*    */   private static String _initiateBuildId() {
/* 53 */     String id = "Jersey";
/*    */     
/* 55 */     InputStream in = getIntputStream();
/* 56 */     if (in != null) {
/*    */       try {
/* 58 */         Properties p = new Properties();
/* 59 */         p.load(in);
/* 60 */         String _id = p.getProperty("Build-Id");
/* 61 */         if (_id != null) {
/* 62 */           id = id + ": " + _id;
/*    */         }
/*    */       }
/*    */       catch (Exception e) {}finally {
/* 66 */         close(in);
/*    */       }
/*    */     }
/* 69 */     return id;
/*    */   }
/*    */   
/*    */   private static void close(InputStream in) {
/*    */     try {
/* 74 */       in.close();
/*    */     }
/*    */     catch (Exception ex) {}
/*    */   }
/*    */   
/*    */   private static InputStream getIntputStream()
/*    */   {
/*    */     try {
/* 82 */       return BuildId.class.getResourceAsStream("build.properties");
/*    */     } catch (Exception ex) {}
/* 84 */     return null;
/*    */   }
/*    */   
/*    */   public static final String getBuildId()
/*    */   {
/* 89 */     return buildId;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\BuildId.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */