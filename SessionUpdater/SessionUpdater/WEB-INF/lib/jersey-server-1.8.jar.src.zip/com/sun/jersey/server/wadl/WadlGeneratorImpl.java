/*     */ package com.sun.jersey.server.wadl;
/*     */ 
/*     */ import com.sun.jersey.api.model.AbstractMethod;
/*     */ import com.sun.jersey.api.model.AbstractResource;
/*     */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*     */ import com.sun.jersey.api.model.Parameter;
/*     */ import com.sun.jersey.api.model.Parameter.Source;
/*     */ import com.sun.jersey.api.model.PathValue;
/*     */ import com.sun.research.ws.wadl.Application;
/*     */ import com.sun.research.ws.wadl.Param;
/*     */ import com.sun.research.ws.wadl.ParamStyle;
/*     */ import com.sun.research.ws.wadl.RepresentationType;
/*     */ import com.sun.research.ws.wadl.Request;
/*     */ import com.sun.research.ws.wadl.Resource;
/*     */ import com.sun.research.ws.wadl.Resources;
/*     */ import com.sun.research.ws.wadl.Response;
/*     */ import java.util.List;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WadlGeneratorImpl
/*     */   implements WadlGenerator
/*     */ {
/*     */   public String getRequiredJaxbContextPath()
/*     */   {
/*  73 */     String name = Application.class.getName();
/*  74 */     return name.substring(0, name.lastIndexOf('.'));
/*     */   }
/*     */   
/*     */   public void init()
/*     */     throws Exception
/*     */   {}
/*     */   
/*     */   public void setWadlGeneratorDelegate(WadlGenerator delegate)
/*     */   {
/*  83 */     throw new UnsupportedOperationException("No delegate supported.");
/*     */   }
/*     */   
/*     */   public Resources createResources()
/*     */   {
/*  88 */     return new Resources();
/*     */   }
/*     */   
/*     */   public Application createApplication()
/*     */   {
/*  93 */     return new Application();
/*     */   }
/*     */   
/*     */ 
/*     */   public com.sun.research.ws.wadl.Method createMethod(AbstractResource r, AbstractResourceMethod m)
/*     */   {
/*  99 */     com.sun.research.ws.wadl.Method wadlMethod = new com.sun.research.ws.wadl.Method();
/*     */     
/* 101 */     wadlMethod.setName(m.getHttpMethod());
/* 102 */     wadlMethod.setId(m.getMethod().getName());
/* 103 */     return wadlMethod;
/*     */   }
/*     */   
/*     */   public RepresentationType createRequestRepresentation(AbstractResource r, AbstractResourceMethod m, MediaType mediaType)
/*     */   {
/* 108 */     RepresentationType wadlRepresentation = new RepresentationType();
/* 109 */     wadlRepresentation.setMediaType(mediaType.toString());
/* 110 */     return wadlRepresentation;
/*     */   }
/*     */   
/*     */   public Request createRequest(AbstractResource r, AbstractResourceMethod m)
/*     */   {
/* 115 */     return new Request();
/*     */   }
/*     */   
/*     */   public Param createParam(AbstractResource r, AbstractMethod m, Parameter p)
/*     */   {
/* 120 */     if (p.getSource() == Parameter.Source.UNKNOWN) {
/* 121 */       return null;
/*     */     }
/* 123 */     Param wadlParam = new Param();
/* 124 */     wadlParam.setName(p.getSourceName());
/*     */     
/* 126 */     switch (p.getSource()) {
/*     */     case FORM: 
/* 128 */       wadlParam.setStyle(ParamStyle.QUERY);
/* 129 */       break;
/*     */     case QUERY: 
/* 131 */       wadlParam.setStyle(ParamStyle.QUERY);
/* 132 */       break;
/*     */     case MATRIX: 
/* 134 */       wadlParam.setStyle(ParamStyle.MATRIX);
/* 135 */       break;
/*     */     case PATH: 
/* 137 */       wadlParam.setStyle(ParamStyle.TEMPLATE);
/* 138 */       break;
/*     */     case HEADER: 
/* 140 */       wadlParam.setStyle(ParamStyle.HEADER);
/* 141 */       break;
/*     */     
/*     */     case COOKIE: 
/* 144 */       wadlParam.setStyle(ParamStyle.HEADER);
/* 145 */       wadlParam.setName("Cookie");
/* 146 */       wadlParam.setPath(p.getSourceName());
/* 147 */       break;
/*     */     }
/*     */     
/*     */     
/*     */ 
/* 152 */     if (p.hasDefaultValue())
/* 153 */       wadlParam.setDefault(p.getDefaultValue());
/* 154 */     Class<?> pClass = p.getParameterClass();
/* 155 */     if (pClass.isArray()) {
/* 156 */       wadlParam.setRepeating(Boolean.valueOf(true));
/* 157 */       pClass = pClass.getComponentType();
/*     */     }
/* 159 */     if ((pClass.equals(Integer.TYPE)) || (pClass.equals(Integer.class))) {
/* 160 */       wadlParam.setType(new QName("http://www.w3.org/2001/XMLSchema", "int", "xs"));
/* 161 */     } else if ((pClass.equals(Boolean.TYPE)) || (pClass.equals(Boolean.class))) {
/* 162 */       wadlParam.setType(new QName("http://www.w3.org/2001/XMLSchema", "boolean", "xs"));
/* 163 */     } else if ((pClass.equals(Long.TYPE)) || (pClass.equals(Long.class))) {
/* 164 */       wadlParam.setType(new QName("http://www.w3.org/2001/XMLSchema", "long", "xs"));
/* 165 */     } else if ((pClass.equals(Short.TYPE)) || (pClass.equals(Short.class))) {
/* 166 */       wadlParam.setType(new QName("http://www.w3.org/2001/XMLSchema", "short", "xs"));
/* 167 */     } else if ((pClass.equals(Byte.TYPE)) || (pClass.equals(Byte.class))) {
/* 168 */       wadlParam.setType(new QName("http://www.w3.org/2001/XMLSchema", "byte", "xs"));
/* 169 */     } else if ((pClass.equals(Float.TYPE)) || (pClass.equals(Float.class))) {
/* 170 */       wadlParam.setType(new QName("http://www.w3.org/2001/XMLSchema", "float", "xs"));
/* 171 */     } else if ((pClass.equals(Double.TYPE)) || (pClass.equals(Double.class))) {
/* 172 */       wadlParam.setType(new QName("http://www.w3.org/2001/XMLSchema", "double", "xs"));
/*     */     } else
/* 174 */       wadlParam.setType(new QName("http://www.w3.org/2001/XMLSchema", "string", "xs"));
/* 175 */     return wadlParam;
/*     */   }
/*     */   
/*     */   public Resource createResource(AbstractResource r, String path)
/*     */   {
/* 180 */     Resource wadlResource = new Resource();
/* 181 */     if (path != null) {
/* 182 */       wadlResource.setPath(path);
/* 183 */     } else if (r.isRootResource())
/* 184 */       wadlResource.setPath(r.getPath().getValue());
/* 185 */     return wadlResource;
/*     */   }
/*     */   
/*     */   public Response createResponse(AbstractResource r, AbstractResourceMethod m)
/*     */   {
/* 190 */     Response response = new Response();
/*     */     
/* 192 */     for (MediaType mediaType : m.getSupportedOutputTypes()) {
/* 193 */       RepresentationType wadlRepresentation = createResponseRepresentation(r, m, mediaType);
/* 194 */       JAXBElement<RepresentationType> element = new JAXBElement(new QName("http://research.sun.com/wadl/2006/10", "representation"), RepresentationType.class, wadlRepresentation);
/*     */       
/*     */ 
/*     */ 
/* 198 */       response.getRepresentationOrFault().add(element);
/*     */     }
/*     */     
/* 201 */     return response;
/*     */   }
/*     */   
/*     */   public RepresentationType createResponseRepresentation(AbstractResource r, AbstractResourceMethod m, MediaType mediaType) {
/* 205 */     RepresentationType wadlRepresentation = new RepresentationType();
/* 206 */     wadlRepresentation.setMediaType(mediaType.toString());
/* 207 */     return wadlRepresentation;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\wadl\WadlGeneratorImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */