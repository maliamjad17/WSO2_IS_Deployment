/*     */ package com.sun.jersey.server.impl.uri.rules;
/*     */ 
/*     */ import com.sun.jersey.api.Responses;
/*     */ import com.sun.jersey.api.core.ExtendedUriInfo;
/*     */ import com.sun.jersey.api.core.HttpRequestContext;
/*     */ import com.sun.jersey.api.core.HttpResponseContext;
/*     */ import com.sun.jersey.api.uri.UriTemplate;
/*     */ import com.sun.jersey.core.header.MediaTypes;
/*     */ import com.sun.jersey.core.header.QualitySourceMediaType;
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*     */ import com.sun.jersey.server.impl.model.method.ResourceMethod;
/*     */ import com.sun.jersey.server.impl.template.ViewResourceMethod;
/*     */ import com.sun.jersey.server.probes.UriRuleProbeProvider;
/*     */ import com.sun.jersey.spi.container.ContainerRequest;
/*     */ import com.sun.jersey.spi.container.ContainerRequestFilter;
/*     */ import com.sun.jersey.spi.dispatch.RequestDispatcher;
/*     */ import com.sun.jersey.spi.monitoring.DispatchingListener;
/*     */ import com.sun.jersey.spi.uri.rules.UriRule;
/*     */ import com.sun.jersey.spi.uri.rules.UriRuleContext;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.core.Response.ResponseBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpMethodRule
/*     */   implements UriRule
/*     */ {
/*     */   public static final String CONTENT_TYPE_PROPERTY = "com.sun.jersey.server.impl.uri.rules.HttpMethodRule.Content-Type";
/*     */   private final Map<String, ResourceMethodListPair> map;
/*     */   private final String allow;
/*     */   private final boolean isSubResource;
/*     */   private final DispatchingListener dispatchingListener;
/*     */   
/*     */   public HttpMethodRule(Map<String, List<ResourceMethod>> methods, DispatchingListener dispatchingListener)
/*     */   {
/*  87 */     this(methods, false, dispatchingListener);
/*     */   }
/*     */   
/*     */   private static final class ResourceMethodListPair
/*     */   {
/*     */     final List<ResourceMethod> normal;
/*     */     final List<ResourceMethod> wildPriority;
/*     */     final List<QualitySourceMediaType> priorityMediaTypes;
/*     */     
/*     */     ResourceMethodListPair(List<ResourceMethod> normal)
/*     */     {
/*  98 */       this.normal = normal;
/*  99 */       int i; if (correctOrder(normal)) {
/* 100 */         this.wildPriority = normal;
/*     */       } else {
/* 102 */         this.wildPriority = new ArrayList(normal.size());
/* 103 */         i = 0;
/* 104 */         for (ResourceMethod method : normal) {
/* 105 */           if (method.consumesWild()) {
/* 106 */             this.wildPriority.add(i++, method);
/*     */           } else {
/* 108 */             this.wildPriority.add(method);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 113 */       List<QualitySourceMediaType> pmts = new LinkedList();
/* 114 */       for (ResourceMethod m : normal) {
/* 115 */         for (MediaType mt : m.getProduces()) {
/* 116 */           pmts.add(get(mt));
/*     */         }
/*     */       }
/*     */       
/* 120 */       Collections.sort(pmts, MediaTypes.QUALITY_SOURCE_MEDIA_TYPE_COMPARATOR);
/* 121 */       this.priorityMediaTypes = (retain(pmts) ? pmts : null);
/*     */     }
/*     */     
/*     */     QualitySourceMediaType get(MediaType mt) {
/* 125 */       if ((mt instanceof QualitySourceMediaType)) {
/* 126 */         return (QualitySourceMediaType)mt;
/*     */       }
/* 128 */       return new QualitySourceMediaType(mt);
/*     */     }
/*     */     
/*     */     boolean retain(List<QualitySourceMediaType> pmts)
/*     */     {
/* 133 */       for (QualitySourceMediaType mt : pmts) {
/* 134 */         if (mt.getQualitySource() != 1000) {
/* 135 */           return true;
/*     */         }
/*     */       }
/* 138 */       return false;
/*     */     }
/*     */     
/*     */     boolean correctOrder(List<ResourceMethod> normal) {
/* 142 */       boolean consumesNonWild = false;
/* 143 */       for (ResourceMethod method : normal) {
/* 144 */         if (method.consumesWild()) {
/* 145 */           if (consumesNonWild) return false;
/*     */         } else {
/* 147 */           consumesNonWild = true;
/*     */         }
/*     */       }
/*     */       
/* 151 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public HttpMethodRule(Map<String, List<ResourceMethod>> methods, boolean isSubResource, DispatchingListener dispatchingListener)
/*     */   {
/* 159 */     this.map = new HashMap();
/* 160 */     for (Map.Entry<String, List<ResourceMethod>> e : methods.entrySet()) {
/* 161 */       this.map.put(e.getKey(), new ResourceMethodListPair((List)e.getValue()));
/*     */     }
/*     */     
/* 164 */     this.isSubResource = isSubResource;
/* 165 */     this.allow = getAllow(methods);
/* 166 */     this.dispatchingListener = dispatchingListener;
/*     */   }
/*     */   
/*     */   private String getAllow(Map<String, List<ResourceMethod>> methods) {
/* 170 */     StringBuilder s = new StringBuilder();
/* 171 */     for (String method : methods.keySet()) {
/* 172 */       if (s.length() > 0) { s.append(",");
/*     */       }
/* 174 */       s.append(method);
/*     */     }
/*     */     
/* 177 */     return s.toString();
/*     */   }
/*     */   
/*     */   public boolean accept(CharSequence path, Object resource, UriRuleContext context)
/*     */   {
/* 182 */     UriRuleProbeProvider.ruleAccept(HttpMethodRule.class.getSimpleName(), path, resource);
/*     */     
/*     */ 
/*     */ 
/* 186 */     if (path.length() > 0) { return false;
/*     */     }
/* 188 */     HttpRequestContext request = context.getRequest();
/*     */     
/*     */ 
/* 191 */     if (request.getMethod().equals("com.sun.jersey.MATCH_RESOURCE")) {
/* 192 */       return true;
/*     */     }
/*     */     
/* 195 */     if (context.isTracingEnabled()) {
/* 196 */       String currentPath = (String)context.getUriInfo().getMatchedURIs().get(0);
/* 197 */       if (this.isSubResource) {
/* 198 */         String prevPath = (String)context.getUriInfo().getMatchedURIs().get(1);
/* 199 */         context.trace(String.format("accept sub-resource methods: \"%s\" : \"%s\", %s -> %s", new Object[] { prevPath, currentPath.substring(prevPath.length()), context.getRequest().getMethod(), ReflectionHelper.objectToString(resource) }));
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 205 */         context.trace(String.format("accept resource methods: \"%s\", %s -> %s", new Object[] { currentPath, context.getRequest().getMethod(), ReflectionHelper.objectToString(resource) }));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 212 */     HttpResponseContext response = context.getResponse();
/*     */     
/*     */ 
/* 215 */     ResourceMethodListPair methods = (ResourceMethodListPair)this.map.get(request.getMethod());
/* 216 */     if (methods == null)
/*     */     {
/* 218 */       response.setResponse(Responses.methodNotAllowed().header("Allow", this.allow).build());
/*     */       
/*     */ 
/* 221 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 225 */     List<MediaType> accept = getSpecificAcceptableMediaTypes(request.getAcceptableMediaTypes(), methods.priorityMediaTypes);
/*     */     
/*     */ 
/*     */ 
/* 229 */     Matcher m = new Matcher(null);
/* 230 */     MatchStatus s = m.match(methods, request.getMediaType(), accept);
/*     */     
/* 232 */     if (s == MatchStatus.MATCH)
/*     */     {
/* 234 */       ResourceMethod method = m.rmSelected;
/*     */       
/* 236 */       if ((method instanceof ViewResourceMethod))
/*     */       {
/* 238 */         if ((!m.mSelected.isWildcardType()) && (!m.mSelected.isWildcardSubtype()))
/*     */         {
/* 240 */           response.getHttpHeaders().putSingle("Content-Type", m.mSelected);
/*     */         }
/*     */         
/*     */ 
/* 244 */         return false;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 253 */       if (this.isSubResource) {
/* 254 */         context.pushResource(resource);
/*     */         
/* 256 */         context.pushMatch(method.getTemplate(), method.getTemplate().getTemplateVariables());
/*     */       }
/*     */       
/* 259 */       if (context.isTracingEnabled()) {
/* 260 */         if (this.isSubResource) {
/* 261 */           context.trace(String.format("matched sub-resource method: @Path(\"%s\") %s", new Object[] { method.getTemplate(), method.getDispatcher() }));
/*     */         }
/*     */         else
/*     */         {
/* 265 */           context.trace(String.format("matched resource method: %s", new Object[] { method.getDispatcher() }));
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 271 */       context.pushContainerResponseFilters(method.getResponseFilters());
/*     */       
/*     */       ContainerRequest containerRequest;
/* 274 */       if (!method.getRequestFilters().isEmpty()) {
/* 275 */         containerRequest = context.getContainerRequest();
/* 276 */         for (ContainerRequestFilter f : method.getRequestFilters()) {
/* 277 */           containerRequest = f.filter(containerRequest);
/* 278 */           context.setContainerRequest(containerRequest);
/*     */         }
/*     */       }
/*     */       
/* 282 */       context.pushMethod(method.getAbstractResourceMethod());
/*     */       
/*     */       try
/*     */       {
/* 286 */         this.dispatchingListener.onResourceMethod(Thread.currentThread().getId(), method.getAbstractResourceMethod());
/*     */         
/* 288 */         method.getDispatcher().dispatch(resource, context);
/*     */       } catch (RuntimeException e) {
/* 290 */         if ((m.rmSelected.isProducesDeclared()) && (!m.mSelected.isWildcardType()) && (!m.mSelected.isWildcardSubtype()))
/*     */         {
/*     */ 
/* 293 */           context.getProperties().put("com.sun.jersey.server.impl.uri.rules.HttpMethodRule.Content-Type", m.mSelected);
/*     */         }
/*     */         
/* 296 */         throw e;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 303 */       Object contentType = response.getHttpHeaders().getFirst("Content-Type");
/* 304 */       if ((contentType == null) && (m.rmSelected.isProducesDeclared()) && (!m.mSelected.isWildcardType()) && (!m.mSelected.isWildcardSubtype()))
/*     */       {
/*     */ 
/*     */ 
/* 308 */         response.getHttpHeaders().putSingle("Content-Type", m.mSelected);
/*     */       }
/*     */       
/* 311 */       return true; }
/* 312 */     if (s == MatchStatus.NO_MATCH_FOR_CONSUME) {
/* 313 */       response.setResponse(Responses.unsupportedMediaType().build());
/*     */       
/* 315 */       return false; }
/* 316 */     if (s == MatchStatus.NO_MATCH_FOR_PRODUCE) {
/* 317 */       response.setResponse(Responses.notAcceptable().build());
/*     */       
/* 319 */       return false;
/*     */     }
/*     */     
/* 322 */     return true;
/*     */   }
/*     */   
/*     */   private static enum MatchStatus {
/* 326 */     MATCH,  NO_MATCH_FOR_CONSUME,  NO_MATCH_FOR_PRODUCE;
/*     */     
/*     */     private MatchStatus() {} }
/*     */   
/* 330 */   private static class Matcher extends LinkedList<ResourceMethod> { private MediaType mSelected = null;
/*     */     
/* 332 */     private ResourceMethod rmSelected = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private HttpMethodRule.MatchStatus match(HttpMethodRule.ResourceMethodListPair methods, MediaType contentType, List<MediaType> acceptableMediaTypes)
/*     */     {
/*     */       List<ResourceMethod> selected;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       List<ResourceMethod> selected;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 350 */       if (contentType != null)
/*     */       {
/* 352 */         for (ResourceMethod method : methods.normal) {
/* 353 */           if (method.consumes(contentType))
/* 354 */             add(method);
/*     */         }
/* 356 */         if (isEmpty()) {
/* 357 */           return HttpMethodRule.MatchStatus.NO_MATCH_FOR_CONSUME;
/*     */         }
/* 359 */         selected = this;
/*     */       } else {
/* 361 */         selected = methods.wildPriority;
/*     */       }
/*     */       
/*     */ 
/* 365 */       for (Iterator i$ = acceptableMediaTypes.iterator(); i$.hasNext();) { amt = (MediaType)i$.next();
/* 366 */         for (i$ = selected.iterator(); i$.hasNext();) { rm = (ResourceMethod)i$.next();
/* 367 */           for (MediaType p : rm.getProduces())
/* 368 */             if (p.isCompatible(amt)) {
/* 369 */               this.mSelected = MediaTypes.mostSpecific(p, amt);
/* 370 */               this.rmSelected = rm;
/* 371 */               return HttpMethodRule.MatchStatus.MATCH;
/*     */             }
/*     */         } }
/*     */       MediaType amt;
/*     */       Iterator i$;
/*     */       ResourceMethod rm;
/* 377 */       return HttpMethodRule.MatchStatus.NO_MATCH_FOR_PRODUCE;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<MediaType> getSpecificAcceptableMediaTypes(List<MediaType> acceptableMediaType, List<? extends MediaType> priorityMediaTypes)
/*     */   {
/*     */     Iterator i$;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 395 */     if (priorityMediaTypes != null) {
/* 396 */       for (i$ = priorityMediaTypes.iterator(); i$.hasNext();) { pmt = (MediaType)i$.next();
/* 397 */         for (MediaType amt : acceptableMediaType) {
/* 398 */           if (amt.isCompatible(pmt)) {
/* 399 */             return Collections.singletonList(MediaTypes.mostSpecific(amt, pmt));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     MediaType pmt;
/* 405 */     return acceptableMediaType;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\uri\rules\HttpMethodRule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */