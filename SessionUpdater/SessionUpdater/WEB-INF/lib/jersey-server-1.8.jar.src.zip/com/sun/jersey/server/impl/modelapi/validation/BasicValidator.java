/*     */ package com.sun.jersey.server.impl.modelapi.validation;
/*     */ 
/*     */ import com.sun.jersey.api.core.HttpRequestContext;
/*     */ import com.sun.jersey.api.core.HttpResponseContext;
/*     */ import com.sun.jersey.api.model.AbstractField;
/*     */ import com.sun.jersey.api.model.AbstractResource;
/*     */ import com.sun.jersey.api.model.AbstractResourceConstructor;
/*     */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*     */ import com.sun.jersey.api.model.AbstractSetterMethod;
/*     */ import com.sun.jersey.api.model.AbstractSubResourceLocator;
/*     */ import com.sun.jersey.api.model.AbstractSubResourceMethod;
/*     */ import com.sun.jersey.api.model.Parameter;
/*     */ import com.sun.jersey.api.model.Parameter.Source;
/*     */ import com.sun.jersey.api.model.Parameterized;
/*     */ import com.sun.jersey.api.model.PathValue;
/*     */ import com.sun.jersey.api.model.ResourceModelIssue;
/*     */ import com.sun.jersey.core.reflection.AnnotatedMethod;
/*     */ import com.sun.jersey.core.reflection.MethodList;
/*     */ import com.sun.jersey.impl.ImplMessages;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.ws.rs.CookieParam;
/*     */ import javax.ws.rs.HeaderParam;
/*     */ import javax.ws.rs.HttpMethod;
/*     */ import javax.ws.rs.MatrixParam;
/*     */ import javax.ws.rs.Path;
/*     */ import javax.ws.rs.PathParam;
/*     */ import javax.ws.rs.QueryParam;
/*     */ import javax.ws.rs.core.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicValidator
/*     */   extends AbstractModelValidator
/*     */ {
/*     */   public void visitAbstractResource(AbstractResource resource)
/*     */   {
/* 102 */     if ((resource.isRootResource()) && ((null == resource.getPath()) || (null == resource.getPath().getValue()))) {
/* 103 */       this.issueList.add(new ResourceModelIssue(resource, ImplMessages.ERROR_RES_URI_PATH_INVALID(resource.getResourceClass(), resource.getPath()), true));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 109 */     checkNonPublicMethods(resource);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void visitAbstractResourceConstructor(AbstractResourceConstructor constructor) {}
/*     */   
/*     */ 
/*     */   public void visitAbstractField(AbstractField field)
/*     */   {
/* 119 */     Field f = field.getField();
/* 120 */     checkParameter((Parameter)field.getParameters().get(0), f, f.toGenericString(), f.getName());
/*     */   }
/*     */   
/*     */   public void visitAbstractSetterMethod(AbstractSetterMethod setterMethod)
/*     */   {
/* 125 */     Method m = setterMethod.getMethod();
/* 126 */     checkParameter((Parameter)setterMethod.getParameters().get(0), m, m.toGenericString(), "1");
/*     */   }
/*     */   
/*     */   public void visitAbstractResourceMethod(AbstractResourceMethod method)
/*     */   {
/* 131 */     checkParameters(method, method.getMethod());
/*     */     
/* 133 */     if (("GET".equals(method.getHttpMethod())) && 
/* 134 */       (!isRequestResponseMethod(method)))
/*     */     {
/* 136 */       if (Void.TYPE == method.getMethod().getReturnType()) {
/* 137 */         this.issueList.add(new ResourceModelIssue(method, ImplMessages.ERROR_GET_RETURNS_VOID(method.getMethod()), false));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 144 */       if (method.hasEntity()) {
/* 145 */         this.issueList.add(new ResourceModelIssue(method, ImplMessages.ERROR_GET_CONSUMES_ENTITY(method.getMethod()), false));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 154 */     List<String> httpAnnotList = new LinkedList();
/* 155 */     for (Annotation a : method.getMethod().getDeclaredAnnotations()) {
/* 156 */       if (null != a.annotationType().getAnnotation(HttpMethod.class)) {
/* 157 */         httpAnnotList.add(a.toString());
/* 158 */       } else if ((a.annotationType() == Path.class) && (!(method instanceof AbstractSubResourceMethod))) {
/* 159 */         this.issueList.add(new ResourceModelIssue(method, ImplMessages.SUB_RES_METHOD_TREATED_AS_RES_METHOD(method.getMethod(), ((Path)a).value()), false));
/*     */       }
/*     */     }
/*     */     
/* 163 */     if (httpAnnotList.size() > 1) {
/* 164 */       this.issueList.add(new ResourceModelIssue(method, ImplMessages.MULTIPLE_HTTP_METHOD_DESIGNATORS(method.getMethod(), httpAnnotList.toString()), true));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 170 */     Type t = method.getGenericReturnType();
/* 171 */     if (!isConcreteType(t)) {
/* 172 */       this.issueList.add(new ResourceModelIssue(method.getMethod(), "Return type " + t + " of method " + method.getMethod().toGenericString() + " is not resolvable to a concrete type", false));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void visitAbstractSubResourceMethod(AbstractSubResourceMethod method)
/*     */   {
/* 182 */     visitAbstractResourceMethod(method);
/*     */     
/* 184 */     if ((null == method.getPath()) || (null == method.getPath().getValue()) || (method.getPath().getValue().length() == 0)) {
/* 185 */       this.issueList.add(new ResourceModelIssue(method, ImplMessages.ERROR_SUBRES_METHOD_URI_PATH_INVALID(method.getMethod(), method.getPath()), true));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void visitAbstractSubResourceLocator(AbstractSubResourceLocator locator)
/*     */   {
/* 194 */     checkParameters(locator, locator.getMethod());
/* 195 */     if (Void.TYPE == locator.getMethod().getReturnType()) {
/* 196 */       this.issueList.add(new ResourceModelIssue(locator, ImplMessages.ERROR_SUBRES_LOC_RETURNS_VOID(locator.getMethod()), true));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 201 */     if ((null == locator.getPath()) || (null == locator.getPath().getValue()) || (locator.getPath().getValue().length() == 0)) {
/* 202 */       this.issueList.add(new ResourceModelIssue(locator, ImplMessages.ERROR_SUBRES_LOC_URI_PATH_INVALID(locator.getMethod(), locator.getPath()), true));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 208 */     for (Parameter parameter : locator.getParameters()) {
/* 209 */       if (Parameter.Source.ENTITY == parameter.getSource()) {
/* 210 */         this.issueList.add(new ResourceModelIssue(locator, ImplMessages.ERROR_SUBRES_LOC_HAS_ENTITY_PARAM(locator.getMethod()), true));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 217 */   private static final Set<Class> ParamAnnotationSET = ;
/*     */   
/*     */   private static Set<Class> createParamAnnotationSet() {
/* 220 */     Set<Class> set = new HashSet(6);
/* 221 */     set.add(Context.class);
/* 222 */     set.add(HeaderParam.class);
/* 223 */     set.add(CookieParam.class);
/* 224 */     set.add(MatrixParam.class);
/* 225 */     set.add(QueryParam.class);
/* 226 */     set.add(PathParam.class);
/* 227 */     return Collections.unmodifiableSet(set);
/*     */   }
/*     */   
/*     */   private void checkParameter(Parameter p, Object source, String nameForLogging, String paramNameForLogging) {
/* 231 */     int annotCount = 0;
/* 232 */     for (Annotation a : p.getAnnotations()) {
/* 233 */       if (ParamAnnotationSET.contains(a.annotationType())) {
/* 234 */         annotCount++;
/* 235 */         if (annotCount > 1) {
/* 236 */           this.issueList.add(new ResourceModelIssue(source, ImplMessages.AMBIGUOUS_PARAMETER(nameForLogging, paramNameForLogging), false));
/*     */           
/*     */ 
/*     */ 
/* 240 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 245 */     Type t = p.getParameterType();
/* 246 */     if (!isConcreteType(t)) {
/* 247 */       this.issueList.add(new ResourceModelIssue(source, "Parameter " + paramNameForLogging + " of type " + t + " from " + nameForLogging + " is not resolvable to a concrete type", false));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean isConcreteType(Type t)
/*     */   {
/* 255 */     if ((t instanceof ParameterizedType))
/* 256 */       return isConcreteParameterizedType((ParameterizedType)t);
/* 257 */     if (!(t instanceof Class))
/*     */     {
/* 259 */       return false;
/*     */     }
/*     */     
/* 262 */     return true;
/*     */   }
/*     */   
/*     */   private boolean isConcreteParameterizedType(ParameterizedType pt) {
/* 266 */     boolean isConcrete = true;
/* 267 */     for (Type t : pt.getActualTypeArguments()) {
/* 268 */       isConcrete &= isConcreteType(t);
/*     */     }
/*     */     
/* 271 */     return isConcrete;
/*     */   }
/*     */   
/*     */   private void checkParameters(Parameterized pl, Method m) {
/* 275 */     int paramCount = 0;
/* 276 */     for (Parameter p : pl.getParameters()) {
/* 277 */       checkParameter(p, m, m.toGenericString(), Integer.toString(++paramCount));
/*     */     }
/*     */   }
/*     */   
/*     */   private List<Method> getDeclaredMethods(final Class _c)
/*     */   {
/* 283 */     final List<Method> ml = new ArrayList();
/*     */     
/* 285 */     AccessController.doPrivileged(new PrivilegedAction() {
/* 286 */       Class c = _c;
/*     */       
/*     */       public Object run() {
/* 289 */         while ((this.c != Object.class) && (this.c != null)) {
/* 290 */           ml.addAll(Arrays.asList(this.c.getDeclaredMethods()));
/* 291 */           this.c = this.c.getSuperclass();
/*     */         }
/* 293 */         return null;
/*     */       }
/*     */       
/* 296 */     });
/* 297 */     return ml;
/*     */   }
/*     */   
/*     */   private void checkNonPublicMethods(AbstractResource ar)
/*     */   {
/* 302 */     MethodList declaredMethods = new MethodList(getDeclaredMethods(ar.getResourceClass()));
/*     */     
/*     */ 
/*     */ 
/* 306 */     for (AnnotatedMethod m : declaredMethods.hasMetaAnnotation(HttpMethod.class).hasNotAnnotation(Path.class).isNotPublic())
/*     */     {
/* 308 */       this.issueList.add(new ResourceModelIssue(ar, ImplMessages.NON_PUB_RES_METHOD(m.getMethod().toGenericString()), false));
/*     */     }
/*     */     
/* 311 */     for (AnnotatedMethod m : declaredMethods.hasMetaAnnotation(HttpMethod.class).hasAnnotation(Path.class).isNotPublic())
/*     */     {
/* 313 */       this.issueList.add(new ResourceModelIssue(ar, ImplMessages.NON_PUB_SUB_RES_METHOD(m.getMethod().toGenericString()), false));
/*     */     }
/*     */     
/* 316 */     for (AnnotatedMethod m : declaredMethods.hasNotMetaAnnotation(HttpMethod.class).hasAnnotation(Path.class).isNotPublic())
/*     */     {
/* 318 */       this.issueList.add(new ResourceModelIssue(ar, ImplMessages.NON_PUB_SUB_RES_LOC(m.getMethod().toGenericString()), false));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean isRequestResponseMethod(AbstractResourceMethod method)
/*     */   {
/* 325 */     return (method.getMethod().getParameterTypes().length == 2) && (HttpRequestContext.class == method.getMethod().getParameterTypes()[0]) && (HttpResponseContext.class == method.getMethod().getParameterTypes()[1]);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\modelapi\validation\BasicValidator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */