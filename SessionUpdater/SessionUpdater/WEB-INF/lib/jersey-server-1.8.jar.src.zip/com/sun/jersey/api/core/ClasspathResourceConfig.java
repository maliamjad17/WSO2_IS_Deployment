/*     */ package com.sun.jersey.api.core;
/*     */ 
/*     */ import com.sun.jersey.core.spi.scanning.FilesScanner;
/*     */ import java.io.File;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClasspathResourceConfig
/*     */   extends ScanningResourceConfig
/*     */ {
/*     */   public static final String PROPERTY_CLASSPATH = "com.sun.jersey.config.property.classpath";
/*  75 */   private static final Logger LOGGER = Logger.getLogger(ClasspathResourceConfig.class.getName());
/*     */   
/*     */   public ClasspathResourceConfig()
/*     */   {
/*  79 */     this(getPaths());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClasspathResourceConfig(Map<String, Object> props)
/*     */   {
/*  87 */     this(getPaths(props));
/*     */     
/*  89 */     setPropertiesAndFeatures(props);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClasspathResourceConfig(String[] paths)
/*     */   {
/*  97 */     if ((paths == null) || (paths.length == 0)) {
/*  98 */       throw new IllegalArgumentException("Array of paths must not be null or empty");
/*     */     }
/*     */     
/* 101 */     init((String[])paths.clone());
/*     */   }
/*     */   
/*     */   private void init(String[] paths) {
/* 105 */     File[] files = new File[paths.length];
/* 106 */     for (int i = 0; i < paths.length; i++) {
/* 107 */       files[i] = new File(paths[i]);
/*     */     }
/*     */     
/* 110 */     if (LOGGER.isLoggable(Level.INFO)) {
/* 111 */       StringBuilder b = new StringBuilder();
/* 112 */       b.append("Scanning for root resource and provider classes in the paths:");
/* 113 */       for (String p : paths) {
/* 114 */         b.append('\n').append("  ").append(p);
/*     */       }
/* 116 */       LOGGER.log(Level.INFO, b.toString());
/*     */     }
/*     */     
/* 119 */     init(new FilesScanner(files));
/*     */   }
/*     */   
/*     */   private static String[] getPaths() {
/* 123 */     String classPath = System.getProperty("java.class.path");
/* 124 */     return classPath.split(File.pathSeparator);
/*     */   }
/*     */   
/*     */   private static String[] getPaths(Map<String, Object> props) {
/* 128 */     Object v = props.get("com.sun.jersey.config.property.classpath");
/* 129 */     if (v == null) {
/* 130 */       throw new IllegalArgumentException("com.sun.jersey.config.property.classpath property is missing");
/*     */     }
/*     */     
/* 133 */     String[] paths = getPaths(v);
/* 134 */     if (paths.length == 0) {
/* 135 */       throw new IllegalArgumentException("com.sun.jersey.config.property.classpath contains no paths");
/*     */     }
/*     */     
/* 138 */     return paths;
/*     */   }
/*     */   
/*     */   private static String[] getPaths(Object param) {
/* 142 */     if ((param instanceof String))
/* 143 */       return getElements(new String[] { (String)param }, " ,;");
/* 144 */     if ((param instanceof String[])) {
/* 145 */       return getElements((String[])param, " ,;");
/*     */     }
/* 147 */     throw new IllegalArgumentException("com.sun.jersey.config.property.classpath must have a property value of type String or String[]");
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\core\ClasspathResourceConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */