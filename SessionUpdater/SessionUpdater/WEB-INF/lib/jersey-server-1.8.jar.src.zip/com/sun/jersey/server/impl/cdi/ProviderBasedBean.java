/*    */ package com.sun.jersey.server.impl.cdi;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Type;
/*    */ import javax.enterprise.context.spi.CreationalContext;
/*    */ import javax.inject.Provider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProviderBasedBean<T>
/*    */   extends AbstractBean<T>
/*    */ {
/*    */   private Provider<T> provider;
/*    */   
/*    */   public ProviderBasedBean(Class<?> klass, Provider<T> provider, Annotation qualifier)
/*    */   {
/* 58 */     super(klass, qualifier);
/* 59 */     this.provider = provider;
/*    */   }
/*    */   
/*    */   public ProviderBasedBean(Class<?> klass, Type type, Provider<T> provider, Annotation qualifier) {
/* 63 */     super(klass, type, qualifier);
/* 64 */     this.provider = provider;
/*    */   }
/*    */   
/*    */   public T create(CreationalContext<T> creationalContext)
/*    */   {
/* 69 */     return (T)this.provider.get();
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\cdi\ProviderBasedBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */