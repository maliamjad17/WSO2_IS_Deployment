/*     */ package com.sun.jersey.server.wadl.generators.resourcedoc;
/*     */ 
/*     */ import com.sun.jersey.api.model.AbstractMethod;
/*     */ import com.sun.jersey.api.model.AbstractResource;
/*     */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*     */ import com.sun.jersey.api.model.Parameter;
/*     */ import com.sun.jersey.server.wadl.WadlGenerator;
/*     */ import com.sun.jersey.server.wadl.generators.resourcedoc.model.ClassDocType;
/*     */ import com.sun.jersey.server.wadl.generators.resourcedoc.model.MethodDocType;
/*     */ import com.sun.jersey.server.wadl.generators.resourcedoc.model.ParamDocType;
/*     */ import com.sun.jersey.server.wadl.generators.resourcedoc.model.RepresentationDocType;
/*     */ import com.sun.jersey.server.wadl.generators.resourcedoc.model.ResourceDocType;
/*     */ import com.sun.jersey.server.wadl.generators.resourcedoc.model.ResponseDocType;
/*     */ import com.sun.jersey.server.wadl.generators.resourcedoc.model.WadlParamType;
/*     */ import com.sun.jersey.server.wadl.generators.resourcedoc.xhtml.Elements;
/*     */ import com.sun.research.ws.wadl.Application;
/*     */ import com.sun.research.ws.wadl.Doc;
/*     */ import com.sun.research.ws.wadl.Method;
/*     */ import com.sun.research.ws.wadl.Param;
/*     */ import com.sun.research.ws.wadl.ParamStyle;
/*     */ import com.sun.research.ws.wadl.RepresentationType;
/*     */ import com.sun.research.ws.wadl.Request;
/*     */ import com.sun.research.ws.wadl.Resource;
/*     */ import com.sun.research.ws.wadl.Resources;
/*     */ import com.sun.research.ws.wadl.Response;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.util.List;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.xml.bind.JAXBContext;
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WadlGeneratorResourceDocSupport
/*     */   implements WadlGenerator
/*     */ {
/*     */   public static final String RESOURCE_DOC_FILE = "resourcedoc.xml";
/*     */   private WadlGenerator _delegate;
/*     */   private File _resourceDocFile;
/*     */   private InputStream _resourceDocStream;
/*     */   private ResourceDocAccessor _resourceDoc;
/*     */   
/*     */   public WadlGeneratorResourceDocSupport() {}
/*     */   
/*     */   public WadlGeneratorResourceDocSupport(WadlGenerator wadlGenerator, ResourceDocType resourceDoc)
/*     */   {
/* 106 */     this._delegate = wadlGenerator;
/* 107 */     this._resourceDoc = new ResourceDocAccessor(resourceDoc);
/*     */   }
/*     */   
/*     */   public void setWadlGeneratorDelegate(WadlGenerator delegate) {
/* 111 */     this._delegate = delegate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResourceDocFile(File resourceDocFile)
/*     */   {
/* 120 */     if (this._resourceDocStream != null) {
/* 121 */       throw new IllegalStateException("The resourceDocStream property is already set, therefore you cannot set the resourceDocFile property. Only one of both can be set at a time.");
/*     */     }
/*     */     
/* 124 */     this._resourceDocFile = resourceDocFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResourceDocStream(InputStream resourceDocStream)
/*     */   {
/* 136 */     if (this._resourceDocStream != null) {
/* 137 */       throw new IllegalStateException("The resourceDocFile property is already set, therefore you cannot set the resourceDocStream property. Only one of both can be set at a time.");
/*     */     }
/*     */     
/* 140 */     this._resourceDocStream = resourceDocStream;
/*     */   }
/*     */   
/*     */   public void init() throws Exception {
/* 144 */     if ((this._resourceDocFile == null) && (this._resourceDocStream == null)) {
/* 145 */       throw new IllegalStateException("Neither the resourceDocFile nor the resourceDocStream is set, one of both is required.");
/*     */     }
/*     */     
/* 148 */     this._delegate.init();
/* 149 */     JAXBContext c = JAXBContext.newInstance(new Class[] { ResourceDocType.class });
/* 150 */     Unmarshaller m = c.createUnmarshaller();
/* 151 */     Object resourceDocObj = this._resourceDocFile != null ? m.unmarshal(this._resourceDocFile) : m.unmarshal(this._resourceDocStream);
/*     */     
/* 153 */     ResourceDocType resourceDoc = (ResourceDocType)ResourceDocType.class.cast(resourceDocObj);
/* 154 */     this._resourceDoc = new ResourceDocAccessor(resourceDoc);
/*     */   }
/*     */   
/*     */   public String getRequiredJaxbContextPath() {
/* 158 */     String name = Elements.class.getName();
/* 159 */     name = name.substring(0, name.lastIndexOf('.'));
/*     */     
/* 161 */     return this._delegate.getRequiredJaxbContextPath() + ":" + name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Application createApplication()
/*     */   {
/* 171 */     return this._delegate.createApplication();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Resource createResource(AbstractResource r, String path)
/*     */   {
/* 181 */     Resource result = this._delegate.createResource(r, path);
/* 182 */     ClassDocType classDoc = this._resourceDoc.getClassDoc(r.getResourceClass());
/* 183 */     if ((classDoc != null) && (!isEmpty(classDoc.getCommentText()))) {
/* 184 */       Doc doc = new Doc();
/* 185 */       doc.getContent().add(classDoc.getCommentText());
/* 186 */       result.getDoc().add(doc);
/*     */     }
/* 188 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Method createMethod(AbstractResource r, AbstractResourceMethod m)
/*     */   {
/* 198 */     Method result = this._delegate.createMethod(r, m);
/* 199 */     MethodDocType methodDoc = this._resourceDoc.getMethodDoc(r.getResourceClass(), m.getMethod());
/* 200 */     if ((methodDoc != null) && (!isEmpty(methodDoc.getCommentText()))) {
/* 201 */       Doc doc = new Doc();
/* 202 */       doc.getContent().add(methodDoc.getCommentText());
/*     */       
/* 204 */       result.getDoc().add(doc);
/*     */     }
/* 206 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RepresentationType createRequestRepresentation(AbstractResource r, AbstractResourceMethod m, MediaType mediaType)
/*     */   {
/* 218 */     RepresentationType result = this._delegate.createRequestRepresentation(r, m, mediaType);
/* 219 */     RepresentationDocType requestRepresentation = this._resourceDoc.getRequestRepresentation(r.getResourceClass(), m.getMethod(), result.getMediaType());
/* 220 */     if (requestRepresentation != null) {
/* 221 */       result.setElement(requestRepresentation.getElement());
/* 222 */       addDocForExample(result.getDoc(), requestRepresentation.getExample());
/*     */     }
/* 224 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Request createRequest(AbstractResource r, AbstractResourceMethod m)
/*     */   {
/* 234 */     return this._delegate.createRequest(r, m);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Response createResponse(AbstractResource r, AbstractResourceMethod m)
/*     */   {
/* 244 */     ResponseDocType responseDoc = this._resourceDoc.getResponse(r.getResourceClass(), m.getMethod());
/*     */     
/* 246 */     if ((responseDoc != null) && (responseDoc.hasRepresentations())) {
/* 247 */       Response response = new Response();
/*     */       
/* 249 */       for (RepresentationDocType representationDoc : responseDoc.getRepresentations())
/*     */       {
/* 251 */         RepresentationType wadlRepresentation = new RepresentationType();
/* 252 */         wadlRepresentation.setElement(representationDoc.getElement());
/* 253 */         wadlRepresentation.getStatus().add(representationDoc.getStatus());
/* 254 */         wadlRepresentation.setMediaType(representationDoc.getMediaType());
/* 255 */         addDocForExample(wadlRepresentation.getDoc(), representationDoc.getExample());
/* 256 */         addDoc(wadlRepresentation.getDoc(), representationDoc.getDoc());
/*     */         
/* 258 */         JAXBElement<RepresentationType> element = new JAXBElement(new QName("http://research.sun.com/wadl/2006/10", "representation"), RepresentationType.class, wadlRepresentation);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 263 */         response.getRepresentationOrFault().add(element);
/*     */       }
/*     */       
/* 266 */       return response;
/*     */     }
/*     */     
/* 269 */     Response response = this._delegate.createResponse(r, m);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 274 */     if ((responseDoc != null) && (!responseDoc.getWadlParams().isEmpty())) {
/* 275 */       for (WadlParamType wadlParamType : responseDoc.getWadlParams()) {
/* 276 */         Param param = new Param();
/* 277 */         param.setName(wadlParamType.getName());
/* 278 */         param.setStyle(ParamStyle.fromValue(wadlParamType.getStyle()));
/* 279 */         param.setType(wadlParamType.getType());
/* 280 */         addDoc(param.getDoc(), wadlParamType.getDoc());
/* 281 */         response.getParam().add(param);
/*     */       }
/*     */     }
/*     */     
/* 285 */     if ((responseDoc != null) && (!isEmpty(responseDoc.getReturnDoc()))) {
/* 286 */       addDoc(response.getDoc(), responseDoc.getReturnDoc());
/*     */     }
/*     */     
/* 289 */     return response;
/*     */   }
/*     */   
/*     */   private void addDocForExample(List<Doc> docs, String example) {
/* 293 */     if (!isEmpty(example)) {
/* 294 */       Doc doc = new Doc();
/*     */       
/* 296 */       Elements pElement = Elements.el("p").add(new Object[] { Elements.val("h6", "Example") }).add(new Object[] { Elements.el("pre").add(new Object[] { Elements.val("code", example) }) });
/*     */       
/*     */ 
/*     */ 
/* 300 */       doc.getContent().add(pElement);
/* 301 */       docs.add(doc);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addDoc(List<Doc> docs, String text) {
/* 306 */     if (!isEmpty(text)) {
/* 307 */       Doc doc = new Doc();
/* 308 */       doc.getContent().add(text);
/* 309 */       docs.add(doc);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Param createParam(AbstractResource r, AbstractMethod m, Parameter p)
/*     */   {
/* 322 */     Param result = this._delegate.createParam(r, m, p);
/* 323 */     ParamDocType paramDoc = this._resourceDoc.getParamDoc(r.getResourceClass(), m.getMethod(), p);
/* 324 */     if ((paramDoc != null) && (!isEmpty(paramDoc.getCommentText()))) {
/* 325 */       Doc doc = new Doc();
/* 326 */       doc.getContent().add(paramDoc.getCommentText());
/* 327 */       result.getDoc().add(doc);
/*     */     }
/* 329 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Resources createResources()
/*     */   {
/* 337 */     return this._delegate.createResources();
/*     */   }
/*     */   
/*     */   private boolean isEmpty(String text) {
/* 341 */     return (text == null) || (text.length() == 0) || ("".equals(text.trim()));
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\wadl\generators\resourcedoc\WadlGeneratorResourceDocSupport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */