/*     */ package com.sun.jersey.server.impl.model.parameter;
/*     */ 
/*     */ import com.sun.jersey.api.core.ExtendedUriInfo;
/*     */ import com.sun.jersey.api.core.HttpContext;
/*     */ import com.sun.jersey.core.spi.component.ComponentContext;
/*     */ import com.sun.jersey.core.spi.component.ComponentScope;
/*     */ import com.sun.jersey.server.impl.inject.AbstractHttpContextInjectable;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import com.sun.jersey.spi.inject.InjectableProvider;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.ws.rs.core.Context;
/*     */ import javax.ws.rs.core.HttpHeaders;
/*     */ import javax.ws.rs.core.Request;
/*     */ import javax.ws.rs.core.SecurityContext;
/*     */ import javax.ws.rs.core.UriInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpContextInjectableProvider
/*     */   implements InjectableProvider<Context, Type>
/*     */ {
/*     */   private final Map<Type, Injectable> injectables;
/*     */   
/*     */   private static final class HttpContextInjectable
/*     */     extends AbstractHttpContextInjectable<Object>
/*     */   {
/*     */     public Object getValue(HttpContext context)
/*     */     {
/*  68 */       return context;
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class HttpContextRequestInjectable extends AbstractHttpContextInjectable<Object> {
/*     */     public Object getValue(HttpContext context) {
/*  74 */       return context.getRequest();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class UriInfoInjectable extends AbstractHttpContextInjectable<UriInfo> {
/*     */     public UriInfo getValue(HttpContext context) {
/*  80 */       return context.getUriInfo();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public HttpContextInjectableProvider()
/*     */   {
/*  87 */     this.injectables = new HashMap();
/*     */     
/*  89 */     HttpContextRequestInjectable re = new HttpContextRequestInjectable(null);
/*  90 */     this.injectables.put(HttpHeaders.class, re);
/*  91 */     this.injectables.put(Request.class, re);
/*  92 */     this.injectables.put(SecurityContext.class, re);
/*     */     
/*  94 */     this.injectables.put(HttpContext.class, new HttpContextInjectable(null));
/*     */     
/*  96 */     this.injectables.put(UriInfo.class, new UriInfoInjectable(null));
/*  97 */     this.injectables.put(ExtendedUriInfo.class, new UriInfoInjectable(null));
/*     */   }
/*     */   
/*     */   public ComponentScope getScope() {
/* 101 */     return ComponentScope.PerRequest;
/*     */   }
/*     */   
/*     */   public Injectable getInjectable(ComponentContext ic, Context a, Type c) {
/* 105 */     return (Injectable)this.injectables.get(c);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\parameter\HttpContextInjectableProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */