/*    */ package com.sun.jersey.server.impl.uri.rules;
/*    */ 
/*    */ import com.sun.jersey.api.core.HttpResponseContext;
/*    */ import com.sun.jersey.server.probes.UriRuleProbeProvider;
/*    */ import com.sun.jersey.spi.uri.rules.UriRule;
/*    */ import com.sun.jersey.spi.uri.rules.UriRuleContext;
/*    */ import javax.ws.rs.WebApplicationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TerminatingRule
/*    */   implements UriRule
/*    */ {
/*    */   public final boolean accept(CharSequence path, Object resource, UriRuleContext context)
/*    */   {
/* 58 */     UriRuleProbeProvider.ruleAccept(TerminatingRule.class.getSimpleName(), path, resource);
/*    */     
/*    */ 
/* 61 */     if (context.isTracingEnabled()) {
/* 62 */       context.trace("accept termination (matching failure): \"" + path + "\"");
/*    */     }
/*    */     
/* 65 */     if (context.getResponse().isResponseSet()) {
/* 66 */       throw new WebApplicationException(context.getResponse().getResponse());
/*    */     }
/* 68 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\uri\rules\TerminatingRule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */