/*     */ package com.sun.jersey.api.container.filter;
/*     */ 
/*     */ import com.sun.jersey.spi.container.ContainerRequest;
/*     */ import com.sun.jersey.spi.container.ContainerRequestFilter;
/*     */ import java.net.URI;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.core.PathSegment;
/*     */ import javax.ws.rs.core.UriBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UriConnegFilter
/*     */   implements ContainerRequestFilter
/*     */ {
/*     */   private final Map<String, MediaType> mediaExtentions;
/*     */   private final Map<String, String> languageExtentions;
/*     */   
/*     */   public UriConnegFilter(Map<String, MediaType> mediaExtentions)
/*     */   {
/* 102 */     if (mediaExtentions == null) {
/* 103 */       throw new IllegalArgumentException();
/*     */     }
/* 105 */     this.mediaExtentions = mediaExtentions;
/* 106 */     this.languageExtentions = Collections.emptyMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriConnegFilter(Map<String, MediaType> mediaExtentions, Map<String, String> languageExtentions)
/*     */   {
/* 117 */     if (mediaExtentions == null)
/* 118 */       throw new IllegalArgumentException();
/* 119 */     if (languageExtentions == null) {
/* 120 */       throw new IllegalArgumentException();
/*     */     }
/* 122 */     this.mediaExtentions = mediaExtentions;
/* 123 */     this.languageExtentions = languageExtentions;
/*     */   }
/*     */   
/*     */   public ContainerRequest filter(ContainerRequest request)
/*     */   {
/* 128 */     String path = request.getRequestUri().getRawPath();
/* 129 */     if (path.indexOf('.') == -1) {
/* 130 */       return request;
/*     */     }
/* 132 */     List<PathSegment> l = request.getPathSegments(false);
/* 133 */     if (l.isEmpty()) {
/* 134 */       return request;
/*     */     }
/*     */     
/* 137 */     PathSegment segment = null;
/* 138 */     for (int i = l.size() - 1; i >= 0; i--) {
/* 139 */       segment = (PathSegment)l.get(i);
/* 140 */       if (segment.getPath().length() > 0)
/*     */         break;
/*     */     }
/* 143 */     if (segment == null) {
/* 144 */       return request;
/*     */     }
/* 146 */     int length = path.length();
/*     */     
/* 148 */     String[] suffixes = segment.getPath().split("\\.");
/*     */     
/* 150 */     for (int i = suffixes.length - 1; i >= 1; i--) {
/* 151 */       String suffix = suffixes[i];
/* 152 */       if (suffix.length() != 0)
/*     */       {
/*     */ 
/* 155 */         MediaType accept = (MediaType)this.mediaExtentions.get(suffix);
/* 156 */         if (accept != null) {
/* 157 */           request.getRequestHeaders().putSingle("Accept", accept.toString());
/*     */           
/* 159 */           int index = path.lastIndexOf('.' + suffix);
/* 160 */           path = new StringBuilder(path).delete(index, index + suffix.length() + 1).toString();
/* 161 */           suffixes[i] = "";
/* 162 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 166 */     for (int i = suffixes.length - 1; i >= 1; i--) {
/* 167 */       String suffix = suffixes[i];
/* 168 */       if (suffix.length() != 0)
/*     */       {
/*     */ 
/* 171 */         String acceptLanguage = (String)this.languageExtentions.get(suffix);
/* 172 */         if (acceptLanguage != null) {
/* 173 */           request.getRequestHeaders().putSingle("Accept-Language", acceptLanguage);
/*     */           
/* 175 */           int index = path.lastIndexOf('.' + suffix);
/* 176 */           path = new StringBuilder(path).delete(index, index + suffix.length() + 1).toString();
/* 177 */           suffixes[i] = "";
/* 178 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 182 */     if (length != path.length()) {
/* 183 */       request.setUris(request.getBaseUri(), request.getRequestUriBuilder().replacePath(path).build(new Object[0]));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 188 */     return request;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\api\container\filter\UriConnegFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */