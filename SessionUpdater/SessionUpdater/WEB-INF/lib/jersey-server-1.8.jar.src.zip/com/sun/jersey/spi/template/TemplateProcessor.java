package com.sun.jersey.spi.template;

import java.io.IOException;
import java.io.OutputStream;

/**
 * @deprecated
 */
public abstract interface TemplateProcessor
{
  /**
   * @deprecated
   */
  public abstract String resolve(String paramString);
  
  /**
   * @deprecated
   */
  public abstract void writeTo(String paramString, Object paramObject, OutputStream paramOutputStream)
    throws IOException;
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\template\TemplateProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */