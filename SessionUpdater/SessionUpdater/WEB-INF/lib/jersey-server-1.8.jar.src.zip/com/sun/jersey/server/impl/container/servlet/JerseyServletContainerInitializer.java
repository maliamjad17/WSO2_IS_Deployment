/*     */ package com.sun.jersey.server.impl.container.servlet;
/*     */ 
/*     */ import com.sun.jersey.api.core.DefaultResourceConfig;
/*     */ import com.sun.jersey.api.core.ResourceConfig;
/*     */ import com.sun.jersey.server.impl.application.DeferredResourceConfig;
/*     */ import com.sun.jersey.spi.container.servlet.ServletContainer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Logger;
/*     */ import javax.servlet.ServletContainerInitializer;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletRegistration;
/*     */ import javax.servlet.ServletRegistration.Dynamic;
/*     */ import javax.servlet.annotation.HandlesTypes;
/*     */ import javax.ws.rs.ApplicationPath;
/*     */ import javax.ws.rs.Path;
/*     */ import javax.ws.rs.core.Application;
/*     */ import javax.ws.rs.ext.Provider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @HandlesTypes({Path.class, Provider.class, Application.class, ApplicationPath.class})
/*     */ public class JerseyServletContainerInitializer
/*     */   implements ServletContainerInitializer
/*     */ {
/* 115 */   private static final Logger LOGGER = Logger.getLogger(JerseyServletContainerInitializer.class.getName());
/*     */   
/*     */ 
/*     */   public void onStartup(Set<Class<?>> classes, ServletContext sc)
/*     */   {
/* 120 */     if (classes == null) {
/* 121 */       classes = Collections.emptySet();
/*     */     }
/* 123 */     int nOfRegisterations = sc.getServletRegistrations().size();
/* 124 */     for (Class<? extends Application> a : getApplicationClasses(classes)) {
/* 125 */       ServletRegistration appReg = sc.getServletRegistration(a.getName());
/* 126 */       if (appReg != null)
/*     */       {
/*     */ 
/* 129 */         addServletWithExistingRegistration(sc, appReg, a, classes);
/*     */       }
/*     */       else
/*     */       {
/* 133 */         List<ServletRegistration> srs = getInitParamDeclaredRegistrations(sc, a);
/* 134 */         if (!srs.isEmpty())
/*     */         {
/*     */ 
/* 137 */           for (ServletRegistration sr : srs) {
/* 138 */             addServletWithExistingRegistration(sc, sr, a, classes);
/*     */           }
/*     */         } else {
/* 141 */           addServletWithApplication(sc, a, classes);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 146 */     if (nOfRegisterations == sc.getServletRegistrations().size())
/*     */     {
/* 148 */       addServletWithDefaultConfiguration(sc, classes);
/*     */     }
/*     */   }
/*     */   
/*     */   private List<ServletRegistration> getInitParamDeclaredRegistrations(ServletContext sc, Class<? extends Application> a) {
/* 153 */     List<ServletRegistration> srs = new ArrayList(1);
/* 154 */     for (ServletRegistration sr : sc.getServletRegistrations().values())
/*     */     {
/* 156 */       Map<String, String> ips = sr.getInitParameters();
/* 157 */       if (ips.containsKey("javax.ws.rs.Application")) {
/* 158 */         if ((((String)ips.get("javax.ws.rs.Application")).equals(a.getName())) && 
/* 159 */           (sr.getClassName() == null)) {
/* 160 */           srs.add(sr);
/*     */         }
/*     */       }
/* 163 */       else if ((ips.containsKey("com.sun.jersey.config.property.resourceConfigClass")) && 
/* 164 */         (((String)ips.get("com.sun.jersey.config.property.resourceConfigClass")).equals(a.getName())) && 
/* 165 */         (sr.getClassName() == null)) {
/* 166 */         srs.add(sr);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 172 */     return srs;
/*     */   }
/*     */   
/*     */   private void addServletWithDefaultConfiguration(ServletContext sc, Set<Class<?>> classes) {
/* 176 */     ServletRegistration appReg = sc.getServletRegistration(Application.class.getName());
/* 177 */     if ((appReg != null) && (appReg.getClassName() == null)) {
/* 178 */       Set<Class<?>> x = getRootResourceAndProviderClasses(classes);
/* 179 */       ServletContainer s = new ServletContainer(new DefaultResourceConfig(x));
/*     */       
/* 181 */       appReg = sc.addServlet(appReg.getName(), s);
/*     */       
/* 183 */       if (appReg.getMappings().isEmpty())
/*     */       {
/* 185 */         LOGGER.severe("The Jersey servlet application, named " + appReg.getName() + ", has no servlet mapping");
/*     */       }
/*     */       else
/*     */       {
/* 189 */         LOGGER.info("Registering the Jersey servlet application, named " + appReg.getName() + ", with the following root resource and provider classes: " + x);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void addServletWithApplication(ServletContext sc, Class<? extends Application> a, Set<Class<?>> classes)
/*     */   {
/* 198 */     ApplicationPath ap = (ApplicationPath)a.getAnnotation(ApplicationPath.class);
/* 199 */     if (ap != null)
/*     */     {
/*     */ 
/* 202 */       ServletContainer s = new ServletContainer(new DeferredResourceConfig(a, getRootResourceAndProviderClasses(classes)));
/*     */       
/*     */ 
/* 205 */       String mapping = createMappingPath(ap);
/* 206 */       if (!mappingExists(sc, mapping)) {
/* 207 */         sc.addServlet(a.getName(), s).addMapping(new String[] { mapping });
/*     */         
/*     */ 
/* 210 */         LOGGER.info("Registering the Jersey servlet application, named " + a.getName() + ", at the servlet mapping, " + mapping + ", with the Application class of the same name");
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 216 */         LOGGER.severe("Mapping conflict. A Servlet declaration exists with same mapping as the Jersey servlet application, named " + a.getName() + ", at the servlet mapping, " + mapping + ". The Jersey servlet is not deployed.");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addServletWithExistingRegistration(ServletContext sc, ServletRegistration sr, Class<? extends Application> a, Set<Class<?>> classes)
/*     */   {
/* 228 */     if (sr.getClassName() == null)
/*     */     {
/* 230 */       ResourceConfig rc = new DeferredResourceConfig(a, getRootResourceAndProviderClasses(classes));
/* 231 */       Map<String, Object> initParams = new HashMap();
/* 232 */       for (Map.Entry<String, String> entry : sr.getInitParameters().entrySet()) {
/* 233 */         initParams.put(entry.getKey(), entry.getValue());
/*     */       }
/* 235 */       rc.setPropertiesAndFeatures(initParams);
/*     */       
/* 237 */       ServletContainer s = new ServletContainer(rc);
/* 238 */       sr = sc.addServlet(a.getName(), s);
/* 239 */       if (sr.getMappings().isEmpty()) {
/* 240 */         ApplicationPath ap = (ApplicationPath)a.getAnnotation(ApplicationPath.class);
/* 241 */         if (ap != null) {
/* 242 */           String mapping = createMappingPath(ap);
/* 243 */           if (!mappingExists(sc, mapping)) {
/* 244 */             sr.addMapping(new String[] { mapping });
/*     */             
/* 246 */             LOGGER.info("Registering the Jersey servlet application, named " + a.getName() + ", at the servlet mapping, " + mapping + ", with the Application class of the same name");
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/* 252 */             LOGGER.severe("Mapping conflict. A Servlet registration exists with same mapping as the Jersey servlet application, named " + a.getName() + ", at the servlet mapping, " + mapping + ". The Jersey servlet is not deployed.");
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/* 261 */           LOGGER.severe("The Jersey servlet application, named " + a.getName() + ", is not annotated with " + ApplicationPath.class.getSimpleName() + " " + "and has no servlet mapping");
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 267 */         LOGGER.info("Registering the Jersey servlet application, named " + a.getName() + ", with the Application class of the same name");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean mappingExists(ServletContext sc, String mapping)
/*     */   {
/* 275 */     for (ServletRegistration sr : sc.getServletRegistrations().values()) {
/* 276 */       for (String declaredMapping : sr.getMappings()) {
/* 277 */         if (mapping.equals(declaredMapping)) {
/* 278 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 283 */     return false;
/*     */   }
/*     */   
/*     */   private String createMappingPath(ApplicationPath ap) {
/* 287 */     String path = ap.value();
/* 288 */     if (!path.startsWith("/")) {
/* 289 */       path = "/" + path;
/*     */     }
/*     */     
/* 292 */     if (!path.endsWith("/*")) {
/* 293 */       if (path.endsWith("/")) {
/* 294 */         path = path + "*";
/*     */       } else {
/* 296 */         path = path + "/*";
/*     */       }
/*     */     }
/*     */     
/* 300 */     return path;
/*     */   }
/*     */   
/*     */   private Set<Class<? extends Application>> getApplicationClasses(Set<Class<?>> classes) {
/* 304 */     Set<Class<? extends Application>> s = new LinkedHashSet();
/* 305 */     for (Class<?> c : classes) {
/* 306 */       if ((Application.class != c) && (Application.class.isAssignableFrom(c))) {
/* 307 */         s.add(c.asSubclass(Application.class));
/*     */       }
/*     */     }
/*     */     
/* 311 */     return s;
/*     */   }
/*     */   
/*     */   private Set<Class<?>> getRootResourceAndProviderClasses(Set<Class<?>> classes)
/*     */   {
/* 316 */     Set<Class<?>> s = new LinkedHashSet();
/* 317 */     for (Class<?> c : classes) {
/* 318 */       if ((c.isAnnotationPresent(Path.class)) || (c.isAnnotationPresent(Provider.class))) {
/* 319 */         s.add(c);
/*     */       }
/*     */     }
/* 322 */     return s;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\container\servlet\JerseyServletContainerInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */