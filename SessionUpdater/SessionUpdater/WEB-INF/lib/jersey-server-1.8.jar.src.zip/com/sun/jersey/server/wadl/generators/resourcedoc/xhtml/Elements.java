/*     */ package com.sun.jersey.server.wadl.generators.resourcedoc.xhtml;
/*     */ 
/*     */ import java.util.List;
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Elements
/*     */   extends JAXBElement<XhtmlElementType>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public static Elements el(String elementName)
/*     */   {
/*  55 */     return createElement(elementName);
/*     */   }
/*     */   
/*     */   public static Object val(String elementName, String value) {
/*  59 */     return createElement(elementName, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Elements(QName name, Class<XhtmlElementType> clazz, XhtmlElementType element)
/*     */   {
/*  66 */     super(name, clazz, element);
/*     */   }
/*     */   
/*     */   public Elements add(Object... childNodes) {
/*  70 */     if (childNodes != null) {
/*  71 */       for (Object childNode : childNodes) {
/*  72 */         ((XhtmlElementType)getValue()).getChildNodes().add(childNode);
/*     */       }
/*     */     }
/*  75 */     return this;
/*     */   }
/*     */   
/*     */   public Elements addChild(Object child) {
/*  79 */     ((XhtmlElementType)getValue()).getChildNodes().add(child);
/*  80 */     return this;
/*     */   }
/*     */   
/*     */   private static Elements createElement(String elementName)
/*     */   {
/*     */     try {
/*  86 */       XhtmlElementType element = new XhtmlElementType();
/*     */       
/*  88 */       return new Elements(new QName("http://www.w3.org/1999/xhtml", elementName), XhtmlElementType.class, element);
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */ 
/*     */ 
/*  96 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   private static JAXBElement<XhtmlValueType> createElement(String elementName, String value)
/*     */   {
/*     */     try {
/* 103 */       XhtmlValueType element = new XhtmlValueType();
/* 104 */       element.value = value;
/*     */       
/* 106 */       return new JAXBElement(new QName("http://www.w3.org/1999/xhtml", elementName), XhtmlValueType.class, element);
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */ 
/*     */ 
/* 114 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\wadl\generators\resourcedoc\xhtml\Elements.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */