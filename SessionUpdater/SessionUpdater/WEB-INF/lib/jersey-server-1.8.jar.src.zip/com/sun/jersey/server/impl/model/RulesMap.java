/*    */ package com.sun.jersey.server.impl.model;
/*    */ 
/*    */ import com.sun.jersey.server.impl.uri.PathPattern;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.TreeMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RulesMap<R>
/*    */   extends TreeMap<PathPattern, R>
/*    */ {
/*    */   public RulesMap()
/*    */   {
/* 55 */     super(PathPattern.COMPARATOR);
/*    */   }
/*    */   
/*    */   public PathPattern hasConflict(PathPattern p) {
/* 59 */     for (PathPattern cp : keySet()) {
/* 60 */       if (cp.equals(p)) {
/* 61 */         return cp;
/*    */       }
/*    */     }
/* 64 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void processConflicts(ConflictClosure cc)
/*    */   {
/* 72 */     List<PathPattern> ks = new ArrayList(keySet());
/* 73 */     for (int i = 0; i < ks.size(); i++) {
/* 74 */       PathPattern p1 = (PathPattern)ks.get(i);
/* 75 */       for (int j = i + 1; j < ks.size(); j++) {
/* 76 */         PathPattern p2 = (PathPattern)ks.get(j);
/* 77 */         if (p1.equals(p2)) {
/* 78 */           cc.onConflict(p1, p2);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public static abstract interface ConflictClosure
/*    */   {
/*    */     public abstract void onConflict(PathPattern paramPathPattern1, PathPattern paramPathPattern2);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\RulesMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */