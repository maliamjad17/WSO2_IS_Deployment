/*     */ package com.sun.jersey.server.impl.application;
/*     */ 
/*     */ import com.sun.jersey.api.container.ContainerException;
/*     */ import com.sun.jersey.api.core.ExtendedUriInfo;
/*     */ import com.sun.jersey.api.core.HttpRequestContext;
/*     */ import com.sun.jersey.api.core.HttpResponseContext;
/*     */ import com.sun.jersey.api.core.TraceInformation;
/*     */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*     */ import com.sun.jersey.api.uri.UriComponent;
/*     */ import com.sun.jersey.api.uri.UriComponent.Type;
/*     */ import com.sun.jersey.api.uri.UriTemplate;
/*     */ import com.sun.jersey.core.header.InBoundHeaders;
/*     */ import com.sun.jersey.core.util.MultivaluedMapImpl;
/*     */ import com.sun.jersey.server.spi.component.ResourceComponentProvider;
/*     */ import com.sun.jersey.spi.container.ContainerRequest;
/*     */ import com.sun.jersey.spi.container.ContainerResponse;
/*     */ import com.sun.jersey.spi.container.ContainerResponseFilter;
/*     */ import com.sun.jersey.spi.uri.rules.UriRule;
/*     */ import com.sun.jersey.spi.uri.rules.UriRuleContext;
/*     */ import com.sun.jersey.spi.uri.rules.UriRules;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.regex.MatchResult;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.core.PathSegment;
/*     */ import javax.ws.rs.core.UriBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WebApplicationContext
/*     */   implements UriRuleContext, ExtendedUriInfo
/*     */ {
/*     */   public static final String HTTP_METHOD_MATCH_RESOURCE = "com.sun.jersey.MATCH_RESOURCE";
/*     */   private final WebApplicationImpl app;
/*     */   private final boolean isTraceEnabled;
/*     */   private ContainerRequest request;
/*     */   private ContainerResponse response;
/*     */   private List<ContainerResponseFilter> responseFilters;
/*     */   private MatchResult matchResult;
/*     */   
/*     */   public WebApplicationContext(WebApplicationImpl app, ContainerRequest request, ContainerResponse response)
/*     */   {
/*  90 */     this.app = app;
/*  91 */     this.isTraceEnabled = app.isTracingEnabled();
/*  92 */     this.request = request;
/*  93 */     this.response = response;
/*  94 */     this.responseFilters = Collections.EMPTY_LIST;
/*     */     
/*  96 */     if (isTracingEnabled()) {
/*  97 */       getProperties().put(TraceInformation.class.getName(), new TraceInformation(this));
/*     */     }
/*     */   }
/*     */   
/*     */   public WebApplicationContext createMatchResourceContext(URI u)
/*     */   {
/* 103 */     URI base = this.request.getBaseUri();
/*     */     
/* 105 */     if (u.isAbsolute())
/*     */     {
/* 107 */       URI r = base.relativize(u);
/* 108 */       if (r == u) {
/* 109 */         throw new ContainerException("The URI " + u + " is not relative to the base URI " + base);
/*     */       }
/*     */     } else {
/* 112 */       u = UriBuilder.fromUri(base).path(u.getRawPath()).replaceQuery(u.getRawQuery()).fragment(u.getRawFragment()).build(new Object[0]);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 119 */     ContainerRequest _request = new ContainerRequest(this.app, "com.sun.jersey.MATCH_RESOURCE", base, u, new InBoundHeaders(), new ByteArrayInputStream(new byte[0]));
/*     */     
/*     */ 
/*     */ 
/* 123 */     _request.setSecurityContext(this.request);
/*     */     
/*     */ 
/* 126 */     ContainerResponse _response = new ContainerResponse(this.app, _request, null);
/*     */     
/*     */ 
/* 129 */     return new WebApplicationContext(this.app, _request, _response);
/*     */   }
/*     */   
/*     */ 
/*     */   public List<ContainerResponseFilter> getResponseFilters()
/*     */   {
/* 135 */     return this.responseFilters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public HttpRequestContext getRequest()
/*     */   {
/* 142 */     return this.request;
/*     */   }
/*     */   
/*     */   public HttpResponseContext getResponse()
/*     */   {
/* 147 */     return this.response;
/*     */   }
/*     */   
/*     */   public ExtendedUriInfo getUriInfo()
/*     */   {
/* 152 */     return this;
/*     */   }
/*     */   
/*     */   public Map<String, Object> getProperties()
/*     */   {
/* 157 */     return this.request.getProperties();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isTracingEnabled()
/*     */   {
/* 164 */     return this.isTraceEnabled;
/*     */   }
/*     */   
/*     */   public void trace(String message)
/*     */   {
/* 169 */     if (!isTracingEnabled()) {
/* 170 */       return;
/*     */     }
/* 172 */     this.request.trace(message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MatchResult getMatchResult()
/*     */   {
/* 181 */     return this.matchResult;
/*     */   }
/*     */   
/*     */   public void setMatchResult(MatchResult matchResult)
/*     */   {
/* 186 */     this.matchResult = matchResult;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 192 */   private final LinkedList<Object> resources = new LinkedList();
/*     */   
/* 194 */   private final LinkedList<MatchResult> matchResults = new LinkedList();
/*     */   
/* 196 */   private final LinkedList<String> paths = new LinkedList();
/*     */   
/* 198 */   private final LinkedList<UriTemplate> templates = new LinkedList();
/*     */   private AbstractResourceMethod arm;
/*     */   private MultivaluedMapImpl encodedTemplateValues;
/*     */   private MultivaluedMapImpl decodedTemplateValues;
/*     */   
/*     */   public ContainerRequest getContainerRequest() {
/* 204 */     return this.request;
/*     */   }
/*     */   
/*     */   public void setContainerRequest(ContainerRequest request)
/*     */   {
/* 209 */     this.request = request;
/* 210 */     this.response.setContainerRequest(request);
/*     */   }
/*     */   
/*     */   public ContainerResponse getContainerResponse()
/*     */   {
/* 215 */     return this.response;
/*     */   }
/*     */   
/*     */   public void setContainerResponse(ContainerResponse response)
/*     */   {
/* 220 */     this.response = response;
/*     */   }
/*     */   
/*     */   public void pushContainerResponseFilters(List<ContainerResponseFilter> filters)
/*     */   {
/* 225 */     if (filters.isEmpty()) {
/* 226 */       return;
/*     */     }
/* 228 */     if (this.responseFilters == Collections.EMPTY_LIST) {
/* 229 */       this.responseFilters = new LinkedList();
/*     */     }
/* 231 */     for (ContainerResponseFilter f : filters) {
/* 232 */       this.responseFilters.add(0, f);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object getResource(Class resourceClass)
/*     */   {
/* 238 */     return this.app.getResourceComponentProvider(resourceClass).getInstance(this);
/*     */   }
/*     */   
/*     */   public UriRules<UriRule> getRules(Class resourceClass)
/*     */   {
/* 243 */     return this.app.getUriRules(resourceClass);
/*     */   }
/*     */   
/*     */   public void pushMatch(UriTemplate template, List<String> names)
/*     */   {
/* 248 */     this.matchResults.addFirst(this.matchResult);
/*     */     
/* 250 */     this.templates.addFirst(template);
/*     */     
/* 252 */     if (this.encodedTemplateValues == null) {
/* 253 */       this.encodedTemplateValues = new MultivaluedMapImpl();
/*     */     }
/*     */     
/* 256 */     int i = 1;
/* 257 */     for (String name : names) {
/* 258 */       String value = this.matchResult.group(i++);
/* 259 */       this.encodedTemplateValues.addFirst(name, value);
/*     */       
/* 261 */       if (this.decodedTemplateValues != null) {
/* 262 */         this.decodedTemplateValues.addFirst(UriComponent.decode(name, UriComponent.Type.PATH_SEGMENT), UriComponent.decode(value, UriComponent.Type.PATH));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void pushResource(Object resource)
/*     */   {
/* 271 */     this.resources.addFirst(resource);
/*     */   }
/*     */   
/*     */   public void pushMethod(AbstractResourceMethod arm)
/*     */   {
/* 276 */     this.arm = arm;
/*     */   }
/*     */   
/*     */   public void pushRightHandPathLength(int rhpathlen)
/*     */   {
/* 281 */     String ep = this.request.getPath(false);
/* 282 */     this.paths.addFirst(ep.substring(0, ep.length() - rhpathlen));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public URI getBaseUri()
/*     */   {
/* 295 */     return this.request.getBaseUri();
/*     */   }
/*     */   
/*     */   public UriBuilder getBaseUriBuilder()
/*     */   {
/* 300 */     return this.request.getBaseUriBuilder();
/*     */   }
/*     */   
/*     */   public URI getAbsolutePath()
/*     */   {
/* 305 */     return this.request.getAbsolutePath();
/*     */   }
/*     */   
/*     */   public UriBuilder getAbsolutePathBuilder()
/*     */   {
/* 310 */     return this.request.getAbsolutePathBuilder();
/*     */   }
/*     */   
/*     */   public URI getRequestUri()
/*     */   {
/* 315 */     return this.request.getRequestUri();
/*     */   }
/*     */   
/*     */   public UriBuilder getRequestUriBuilder()
/*     */   {
/* 320 */     return this.request.getRequestUriBuilder();
/*     */   }
/*     */   
/*     */   public String getPath()
/*     */   {
/* 325 */     return this.request.getPath(true);
/*     */   }
/*     */   
/*     */   public String getPath(boolean decode)
/*     */   {
/* 330 */     return this.request.getPath(decode);
/*     */   }
/*     */   
/*     */   public List<PathSegment> getPathSegments()
/*     */   {
/* 335 */     return this.request.getPathSegments(true);
/*     */   }
/*     */   
/*     */   public List<PathSegment> getPathSegments(boolean decode)
/*     */   {
/* 340 */     return this.request.getPathSegments(decode);
/*     */   }
/*     */   
/*     */   public MultivaluedMap<String, String> getQueryParameters()
/*     */   {
/* 345 */     return this.request.getQueryParameters(true);
/*     */   }
/*     */   
/*     */   public MultivaluedMap<String, String> getQueryParameters(boolean decode)
/*     */   {
/* 350 */     return this.request.getQueryParameters(decode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MultivaluedMap<String, String> getPathParameters()
/*     */   {
/* 358 */     return getPathParameters(true);
/*     */   }
/*     */   
/*     */   public MultivaluedMap<String, String> getPathParameters(boolean decode)
/*     */   {
/* 363 */     if (decode) {
/* 364 */       if (this.decodedTemplateValues != null) {
/* 365 */         return this.decodedTemplateValues;
/*     */       }
/*     */       
/* 368 */       this.decodedTemplateValues = new MultivaluedMapImpl();
/* 369 */       for (Map.Entry<String, List<String>> e : this.encodedTemplateValues.entrySet()) {
/* 370 */         List<String> l = new ArrayList();
/* 371 */         for (String v : (List)e.getValue()) {
/* 372 */           l.add(UriComponent.decode(v, UriComponent.Type.PATH));
/*     */         }
/* 374 */         this.decodedTemplateValues.put(UriComponent.decode((String)e.getKey(), UriComponent.Type.PATH_SEGMENT), l);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 379 */       return this.decodedTemplateValues;
/*     */     }
/* 381 */     return this.encodedTemplateValues;
/*     */   }
/*     */   
/*     */ 
/*     */   public List<String> getMatchedURIs()
/*     */   {
/* 387 */     return getMatchedURIs(true);
/*     */   }
/*     */   
/*     */   public List<String> getMatchedURIs(boolean decode) {
/*     */     List<String> result;
/*     */     List<String> result;
/* 393 */     if (decode) {
/* 394 */       result = new ArrayList(this.paths.size());
/*     */       
/* 396 */       for (String path : this.paths) {
/* 397 */         result.add(UriComponent.decode(path, UriComponent.Type.PATH));
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 402 */       result = this.paths;
/*     */     }
/* 404 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */   
/*     */   public List<Object> getMatchedResources()
/*     */   {
/* 409 */     return this.resources;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractResourceMethod getMatchedMethod()
/*     */   {
/* 417 */     return this.arm;
/*     */   }
/*     */   
/*     */   public Throwable getMappedThrowable()
/*     */   {
/* 422 */     return this.response.getMappedThrowable();
/*     */   }
/*     */   
/*     */   public List<MatchResult> getMatchedResults()
/*     */   {
/* 427 */     return this.matchResults;
/*     */   }
/*     */   
/*     */   public List<UriTemplate> getMatchedTemplates()
/*     */   {
/* 432 */     return this.templates;
/*     */   }
/*     */   
/*     */   public List<PathSegment> getPathSegments(String name)
/*     */   {
/* 437 */     return getPathSegments(name, true);
/*     */   }
/*     */   
/*     */   public List<PathSegment> getPathSegments(String name, boolean decode)
/*     */   {
/* 442 */     int[] bounds = getPathParameterBounds(name);
/* 443 */     if (bounds != null) {
/* 444 */       String path = ((MatchResult)this.matchResults.getLast()).group();
/*     */       
/*     */ 
/*     */ 
/* 448 */       int segmentsStart = 0;
/* 449 */       for (int x = 0; x < bounds[0]; x++) {
/* 450 */         if (path.charAt(x) == '/') {
/* 451 */           segmentsStart++;
/*     */         }
/*     */       }
/* 454 */       int segmentsEnd = segmentsStart;
/* 455 */       for (int x = bounds[0]; x < bounds[1]; x++) {
/* 456 */         if (path.charAt(x) == '/') {
/* 457 */           segmentsEnd++;
/*     */         }
/*     */       }
/*     */       
/* 461 */       return getPathSegments(decode).subList(segmentsStart - 1, segmentsEnd);
/*     */     }
/* 463 */     return Collections.emptyList();
/*     */   }
/*     */   
/*     */   private int[] getPathParameterBounds(String name) {
/* 467 */     Iterator<UriTemplate> iTemplate = this.templates.iterator();
/* 468 */     Iterator<MatchResult> iMatchResult = this.matchResults.iterator();
/* 469 */     while (iTemplate.hasNext()) {
/* 470 */       MatchResult mr = (MatchResult)iMatchResult.next();
/*     */       
/* 472 */       int pIndex = getLastPathParameterIndex(name, (UriTemplate)iTemplate.next());
/* 473 */       if (pIndex != -1) {
/* 474 */         int pathLength = mr.group().length();
/* 475 */         int segmentIndex = mr.end(pIndex + 1);
/* 476 */         int groupLength = segmentIndex - mr.start(pIndex + 1);
/*     */         
/*     */ 
/*     */ 
/* 480 */         while (iMatchResult.hasNext()) {
/* 481 */           mr = (MatchResult)iMatchResult.next();
/* 482 */           segmentIndex += mr.group().length() - pathLength;
/* 483 */           pathLength = mr.group().length();
/*     */         }
/* 485 */         int[] bounds = { segmentIndex - groupLength, segmentIndex };
/* 486 */         return bounds;
/*     */       }
/*     */     }
/* 489 */     return null;
/*     */   }
/*     */   
/*     */   private int getLastPathParameterIndex(String name, UriTemplate t) {
/* 493 */     int i = 0;
/* 494 */     int pIndex = -1;
/* 495 */     for (String parameterName : t.getTemplateVariables()) {
/* 496 */       if (parameterName.equals(name)) {
/* 497 */         pIndex = i;
/*     */       }
/* 499 */       i++;
/*     */     }
/* 501 */     return pIndex;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\application\WebApplicationContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */