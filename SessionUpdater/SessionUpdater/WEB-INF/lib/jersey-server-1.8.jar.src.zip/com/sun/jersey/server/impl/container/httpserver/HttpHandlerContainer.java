/*     */ package com.sun.jersey.server.impl.container.httpserver;
/*     */ 
/*     */ import com.sun.jersey.api.container.ContainerException;
/*     */ import com.sun.jersey.core.header.InBoundHeaders;
/*     */ import com.sun.jersey.spi.container.ContainerListener;
/*     */ import com.sun.jersey.spi.container.ContainerRequest;
/*     */ import com.sun.jersey.spi.container.ContainerResponse;
/*     */ import com.sun.jersey.spi.container.ContainerResponseWriter;
/*     */ import com.sun.jersey.spi.container.ReloadListener;
/*     */ import com.sun.jersey.spi.container.WebApplication;
/*     */ import com.sun.net.httpserver.Headers;
/*     */ import com.sun.net.httpserver.HttpContext;
/*     */ import com.sun.net.httpserver.HttpExchange;
/*     */ import com.sun.net.httpserver.HttpHandler;
/*     */ import com.sun.net.httpserver.HttpsExchange;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.core.UriBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpHandlerContainer
/*     */   implements HttpHandler, ContainerListener
/*     */ {
/*     */   private WebApplication application;
/*     */   
/*     */   public HttpHandlerContainer(WebApplication app)
/*     */     throws ContainerException
/*     */   {
/*  78 */     this.application = app;
/*     */   }
/*     */   
/*     */   private static final class Writer implements ContainerResponseWriter {
/*     */     final HttpExchange exchange;
/*     */     
/*     */     Writer(HttpExchange exchange) {
/*  85 */       this.exchange = exchange;
/*     */     }
/*     */     
/*     */     public OutputStream writeStatusAndHeaders(long contentLength, ContainerResponse cResponse) throws IOException
/*     */     {
/*  90 */       Headers eh = this.exchange.getResponseHeaders();
/*  91 */       for (Map.Entry<String, List<Object>> e : cResponse.getHttpHeaders().entrySet()) {
/*  92 */         List<String> values = new ArrayList();
/*  93 */         for (Object v : (List)e.getValue())
/*  94 */           values.add(ContainerResponse.getHeaderValue(v));
/*  95 */         eh.put((String)e.getKey(), values);
/*     */       }
/*     */       
/*  98 */       if (cResponse.getStatus() == 204)
/*     */       {
/*     */ 
/* 101 */         this.exchange.sendResponseHeaders(cResponse.getStatus(), -1L);
/*     */       } else {
/* 103 */         this.exchange.sendResponseHeaders(cResponse.getStatus(), getResponseLength(contentLength));
/*     */       }
/*     */       
/* 106 */       return this.exchange.getResponseBody();
/*     */     }
/*     */     
/*     */     public void finish() throws IOException
/*     */     {}
/*     */     
/*     */     private long getResponseLength(long contentLength) {
/* 113 */       if (contentLength == 0L)
/* 114 */         return -1L;
/* 115 */       if (contentLength < 0L)
/* 116 */         return 0L;
/* 117 */       return contentLength;
/*     */     }
/*     */   }
/*     */   
/*     */   public void handle(HttpExchange exchange) throws IOException {
/* 122 */     WebApplication _application = this.application;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 128 */     URI exchangeUri = exchange.getRequestURI();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 134 */     String decodedBasePath = exchange.getHttpContext().getPath();
/*     */     
/*     */ 
/* 137 */     if (!decodedBasePath.endsWith("/")) {
/* 138 */       if (decodedBasePath.equals(exchangeUri.getPath()))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 148 */         exchangeUri = UriBuilder.fromUri(exchangeUri).path("/").build(new Object[0]);
/*     */       }
/*     */       
/* 151 */       decodedBasePath = decodedBasePath + "/";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 161 */     String scheme = (exchange instanceof HttpsExchange) ? "https" : "http";
/*     */     
/* 163 */     URI baseUri = null;
/*     */     try {
/* 165 */       List<String> hostHeader = exchange.getRequestHeaders().get("Host");
/* 166 */       if (hostHeader != null) {
/* 167 */         StringBuilder sb = new StringBuilder(scheme);
/* 168 */         sb.append("://").append((String)hostHeader.get(0)).append(decodedBasePath);
/* 169 */         baseUri = new URI(sb.toString());
/*     */       } else {
/* 171 */         InetSocketAddress addr = exchange.getLocalAddress();
/* 172 */         baseUri = new URI(scheme, null, addr.getHostName(), addr.getPort(), decodedBasePath, null, null);
/*     */       }
/*     */     }
/*     */     catch (URISyntaxException ex) {
/* 176 */       throw new IllegalArgumentException(ex);
/*     */     }
/*     */     
/* 179 */     URI requestUri = baseUri.resolve(exchangeUri);
/*     */     
/* 181 */     ContainerRequest cRequest = new ContainerRequest(_application, exchange.getRequestMethod(), baseUri, requestUri, getHeaders(exchange), exchange.getRequestBody());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 191 */       _application.handleRequest(cRequest, new Writer(exchange));
/*     */     } catch (RuntimeException e) {
/* 193 */       e.printStackTrace();
/* 194 */       exchange.getResponseHeaders().clear();
/* 195 */       exchange.sendResponseHeaders(500, -1L);
/*     */     } catch (IOException ex) {
/* 197 */       ex.printStackTrace();
/* 198 */       exchange.getResponseHeaders().clear();
/* 199 */       exchange.sendResponseHeaders(500, -1L);
/* 200 */       throw ex;
/*     */     }
/* 202 */     exchange.getResponseBody().flush();
/* 203 */     exchange.close();
/*     */   }
/*     */   
/*     */   private InBoundHeaders getHeaders(HttpExchange exchange) {
/* 207 */     InBoundHeaders rh = new InBoundHeaders();
/*     */     
/* 209 */     Headers eh = exchange.getRequestHeaders();
/* 210 */     for (Map.Entry<String, List<String>> e : eh.entrySet()) {
/* 211 */       rh.put(e.getKey(), e.getValue());
/*     */     }
/*     */     
/* 214 */     return rh;
/*     */   }
/*     */   
/*     */ 
/*     */   public void onReload()
/*     */   {
/* 220 */     WebApplication oldApplication = this.application;
/* 221 */     this.application = this.application.clone();
/*     */     
/* 223 */     if ((this.application.getFeaturesAndProperties() instanceof ReloadListener)) {
/* 224 */       ((ReloadListener)this.application.getFeaturesAndProperties()).onReload();
/*     */     }
/* 226 */     oldApplication.destroy();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\container\httpserver\HttpHandlerContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */