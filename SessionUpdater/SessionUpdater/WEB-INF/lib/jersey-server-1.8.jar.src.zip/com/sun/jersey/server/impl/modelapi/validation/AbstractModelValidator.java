/*     */ package com.sun.jersey.server.impl.modelapi.validation;
/*     */ 
/*     */ import com.sun.jersey.api.model.AbstractModelComponent;
/*     */ import com.sun.jersey.api.model.AbstractModelVisitor;
/*     */ import com.sun.jersey.api.model.ResourceModelIssue;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractModelValidator
/*     */   implements AbstractModelVisitor
/*     */ {
/*  69 */   final List<ResourceModelIssue> issueList = new LinkedList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<ResourceModelIssue> getIssueList()
/*     */   {
/*  77 */     return this.issueList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fatalIssuesFound()
/*     */   {
/*  85 */     for (ResourceModelIssue issue : getIssueList()) {
/*  86 */       if (issue.isFatal()) {
/*  87 */         return true;
/*     */       }
/*     */     }
/*  90 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void cleanIssueList()
/*     */   {
/*  98 */     this.issueList.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validate(AbstractModelComponent component)
/*     */   {
/* 109 */     component.accept(this);
/* 110 */     List<AbstractModelComponent> componentList = component.getComponents();
/* 111 */     if (null != componentList) {
/* 112 */       for (AbstractModelComponent subcomponent : componentList) {
/* 113 */         validate(subcomponent);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\modelapi\validation\AbstractModelValidator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */