/*    */ package com.sun.jersey.server.impl.model.parameter.multivalued;
/*    */ 
/*    */ import javax.ws.rs.core.MultivaluedMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StringExtractor
/*    */   implements MultivaluedParameterExtractor
/*    */ {
/*    */   final String parameter;
/*    */   final String defaultValue;
/*    */   
/*    */   public StringExtractor(String parameter)
/*    */   {
/* 55 */     this(parameter, null);
/*    */   }
/*    */   
/*    */   public StringExtractor(String parameter, String defaultValue) {
/* 59 */     this.parameter = parameter;
/* 60 */     this.defaultValue = defaultValue;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 64 */     return this.parameter;
/*    */   }
/*    */   
/*    */   public String getDefaultStringValue() {
/* 68 */     return this.defaultValue;
/*    */   }
/*    */   
/*    */   public Object extract(MultivaluedMap<String, String> parameters) {
/* 72 */     String value = (String)parameters.getFirst(this.parameter);
/* 73 */     return value != null ? value : this.defaultValue;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\parameter\multivalued\StringExtractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */