package com.sun.jersey.spi.uri.rules;

import java.util.Iterator;

public abstract interface UriRules<R>
{
  public abstract Iterator<R> match(CharSequence paramCharSequence, UriMatchResultContext paramUriMatchResultContext);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\spi\uri\rules\UriRules.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */