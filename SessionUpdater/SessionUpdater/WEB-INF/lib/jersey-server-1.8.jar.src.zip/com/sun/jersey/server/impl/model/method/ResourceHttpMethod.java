/*     */ package com.sun.jersey.server.impl.model.method;
/*     */ 
/*     */ import com.sun.jersey.api.model.AbstractResourceMethod;
/*     */ import com.sun.jersey.api.uri.UriTemplate;
/*     */ import com.sun.jersey.impl.ImplMessages;
/*     */ import com.sun.jersey.server.impl.container.filter.FilterFactory;
/*     */ import com.sun.jersey.spi.container.ResourceFilter;
/*     */ import com.sun.jersey.spi.container.ResourceMethodDispatchProvider;
/*     */ import com.sun.jersey.spi.inject.Errors;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResourceHttpMethod
/*     */   extends ResourceMethod
/*     */ {
/*     */   private final AbstractResourceMethod arm;
/*     */   
/*     */   public ResourceHttpMethod(ResourceMethodDispatchProvider dp, FilterFactory ff, AbstractResourceMethod arm)
/*     */   {
/*  64 */     this(dp, ff, UriTemplate.EMPTY, arm);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceHttpMethod(ResourceMethodDispatchProvider dp, FilterFactory ff, UriTemplate template, AbstractResourceMethod arm)
/*     */   {
/*  72 */     this(dp, ff, ff.getResourceFilters(arm), template, arm);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceHttpMethod(ResourceMethodDispatchProvider dp, FilterFactory ff, List<ResourceFilter> resourceFilters, UriTemplate template, AbstractResourceMethod arm)
/*     */   {
/*  81 */     super(arm.getHttpMethod(), template, arm.getSupportedInputTypes(), arm.getSupportedOutputTypes(), arm.areOutputTypesDeclared(), dp.create(arm), FilterFactory.getRequestFilters(resourceFilters), FilterFactory.getResponseFilters(resourceFilters));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */     this.arm = arm;
/*     */     
/*  92 */     if (getDispatcher() == null) {
/*  93 */       Method m = arm.getMethod();
/*     */       
/*  95 */       String msg = ImplMessages.NOT_VALID_HTTPMETHOD(m, arm.getHttpMethod(), m.getDeclaringClass());
/*     */       
/*  97 */       Errors.error(msg);
/*     */     }
/*     */   }
/*     */   
/*     */   public AbstractResourceMethod getAbstractResourceMethod()
/*     */   {
/* 103 */     return this.arm;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 108 */     Method m = this.arm.getMethod();
/* 109 */     return ImplMessages.RESOURCE_METHOD(m.getDeclaringClass(), m.getName());
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\method\ResourceHttpMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */