/*     */ package com.sun.jersey.server.impl.resource;
/*     */ 
/*     */ import com.sun.jersey.api.container.ContainerException;
/*     */ import com.sun.jersey.api.core.HttpContext;
/*     */ import com.sun.jersey.api.model.AbstractResource;
/*     */ import com.sun.jersey.core.spi.component.ComponentScope;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCComponentProvider;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCDestroyable;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCInstantiatedComponentProvider;
/*     */ import com.sun.jersey.core.spi.component.ioc.IoCProxiedComponentProvider;
/*     */ import com.sun.jersey.server.impl.inject.ServerInjectableProviderContext;
/*     */ import com.sun.jersey.server.spi.component.ResourceComponentConstructor;
/*     */ import com.sun.jersey.server.spi.component.ResourceComponentDestructor;
/*     */ import com.sun.jersey.server.spi.component.ResourceComponentInjector;
/*     */ import com.sun.jersey.server.spi.component.ResourceComponentProvider;
/*     */ import com.sun.jersey.server.spi.component.ResourceComponentProviderFactory;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.ws.rs.core.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SingletonFactory
/*     */   implements ResourceComponentProviderFactory
/*     */ {
/*  66 */   private static final Logger LOGGER = Logger.getLogger(SingletonFactory.class.getName());
/*     */   
/*     */   private final ServerInjectableProviderContext sipc;
/*     */   
/*     */   public SingletonFactory(@Context ServerInjectableProviderContext sipc)
/*     */   {
/*  72 */     this.sipc = sipc;
/*     */   }
/*     */   
/*     */   public ComponentScope getScope(Class c) {
/*  76 */     return ComponentScope.Singleton;
/*     */   }
/*     */   
/*     */   public ResourceComponentProvider getComponentProvider(Class c) {
/*  80 */     return new Singleton(null);
/*     */   }
/*     */   
/*     */   public ResourceComponentProvider getComponentProvider(IoCComponentProvider icp, Class c) {
/*  84 */     if ((icp instanceof IoCInstantiatedComponentProvider))
/*  85 */       return new SingletonInstantiated((IoCInstantiatedComponentProvider)icp);
/*  86 */     if ((icp instanceof IoCProxiedComponentProvider)) {
/*  87 */       return new SingletonProxied((IoCProxiedComponentProvider)icp);
/*     */     }
/*  89 */     throw new IllegalStateException();
/*     */   }
/*     */   
/*     */   private abstract class AbstractSingleton implements ResourceComponentProvider {
/*     */     private ResourceComponentDestructor rcd;
/*     */     protected Object resource;
/*     */     
/*     */     private AbstractSingleton() {}
/*     */     
/*  98 */     public void init(AbstractResource abstractResource) { this.rcd = new ResourceComponentDestructor(abstractResource); }
/*     */     
/*     */     public final Object getInstance(HttpContext hc)
/*     */     {
/* 102 */       return this.resource;
/*     */     }
/*     */     
/*     */     public final Object getInstance() {
/* 106 */       return this.resource;
/*     */     }
/*     */     
/*     */     public final ComponentScope getScope() {
/* 110 */       return ComponentScope.Singleton;
/*     */     }
/*     */     
/*     */     public void destroy() {
/*     */       try {
/* 115 */         this.rcd.destroy(this.resource);
/*     */       } catch (IllegalAccessException ex) {
/* 117 */         SingletonFactory.LOGGER.log(Level.SEVERE, "Unable to destroy resource", ex);
/*     */       } catch (IllegalArgumentException ex) {
/* 119 */         SingletonFactory.LOGGER.log(Level.SEVERE, "Unable to destroy resource", ex);
/*     */       } catch (InvocationTargetException ex) {
/* 121 */         SingletonFactory.LOGGER.log(Level.SEVERE, "Unable to destroy resource", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 126 */   private class Singleton extends SingletonFactory.AbstractSingleton { private Singleton() { super(null); }
/*     */     
/*     */     public void init(AbstractResource abstractResource) {
/* 129 */       super.init(abstractResource);
/*     */       
/* 131 */       ResourceComponentConstructor rcc = new ResourceComponentConstructor(SingletonFactory.this.sipc, ComponentScope.Singleton, abstractResource);
/*     */       
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/* 137 */         this.resource = rcc.construct(null);
/*     */       } catch (InvocationTargetException ex) {
/* 139 */         throw new ContainerException("Unable to create resource", ex);
/*     */       } catch (InstantiationException ex) {
/* 141 */         throw new ContainerException("Unable to create resource", ex);
/*     */       } catch (IllegalAccessException ex) {
/* 143 */         throw new ContainerException("Unable to create resource", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private class SingletonInstantiated extends SingletonFactory.AbstractSingleton {
/*     */     private final IoCInstantiatedComponentProvider iicp;
/*     */     private final IoCDestroyable destroyable;
/*     */     
/*     */     SingletonInstantiated(IoCInstantiatedComponentProvider iicp) {
/* 153 */       super(null);
/* 154 */       this.iicp = iicp;
/* 155 */       this.destroyable = ((iicp instanceof IoCDestroyable) ? (IoCDestroyable)iicp : null);
/*     */     }
/*     */     
/*     */ 
/*     */     public void init(AbstractResource abstractResource)
/*     */     {
/* 161 */       super.init(abstractResource);
/*     */       
/* 163 */       this.resource = this.iicp.getInstance();
/*     */       
/* 165 */       if (this.destroyable == null) {
/* 166 */         ResourceComponentInjector rci = new ResourceComponentInjector(SingletonFactory.this.sipc, ComponentScope.Singleton, abstractResource);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 171 */         rci.inject(null, this.iicp.getInjectableInstance(this.resource));
/*     */       }
/*     */     }
/*     */     
/*     */     public void destroy()
/*     */     {
/* 177 */       if (this.destroyable != null) {
/* 178 */         this.destroyable.destroy(this.resource);
/*     */       } else
/* 180 */         super.destroy();
/*     */     }
/*     */   }
/*     */   
/*     */   private class SingletonProxied extends SingletonFactory.AbstractSingleton {
/*     */     private final IoCProxiedComponentProvider ipcp;
/*     */     
/*     */     SingletonProxied(IoCProxiedComponentProvider ipcp) {
/* 188 */       super(null);
/* 189 */       this.ipcp = ipcp;
/*     */     }
/*     */     
/*     */     public void init(AbstractResource abstractResource)
/*     */     {
/* 194 */       super.init(abstractResource);
/*     */       
/* 196 */       ResourceComponentConstructor rcc = new ResourceComponentConstructor(SingletonFactory.this.sipc, ComponentScope.Singleton, abstractResource);
/*     */       
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/* 202 */         Object o = rcc.construct(null);
/* 203 */         this.resource = this.ipcp.proxy(o);
/*     */       } catch (InvocationTargetException ex) {
/* 205 */         throw new ContainerException("Unable to create resource", ex);
/*     */       } catch (InstantiationException ex) {
/* 207 */         throw new ContainerException("Unable to create resource", ex);
/*     */       } catch (IllegalAccessException ex) {
/* 209 */         throw new ContainerException("Unable to create resource", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\resource\SingletonFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */