/*    */ package com.sun.jersey.server.impl.model.parameter.multivalued;
/*    */ 
/*    */ import com.sun.jersey.spi.StringReader;
/*    */ import com.sun.jersey.spi.StringReader.ValidateDefaultValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractStringReaderExtractor
/*    */   implements MultivaluedParameterExtractor
/*    */ {
/*    */   protected final StringReader sr;
/*    */   protected final String parameter;
/*    */   protected final String defaultStringValue;
/*    */   
/*    */   public AbstractStringReaderExtractor(StringReader sr, String parameter, String defaultStringValue)
/*    */   {
/* 59 */     this.sr = sr;
/* 60 */     this.parameter = parameter;
/* 61 */     this.defaultStringValue = defaultStringValue;
/* 62 */     if (defaultStringValue != null) {
/* 63 */       StringReader.ValidateDefaultValue validate = (StringReader.ValidateDefaultValue)sr.getClass().getAnnotation(StringReader.ValidateDefaultValue.class);
/*    */       
/* 65 */       if ((validate == null) || (validate.value())) {
/* 66 */         sr.fromString(defaultStringValue);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public String getName() {
/* 72 */     return this.parameter;
/*    */   }
/*    */   
/*    */   public String getDefaultStringValue() {
/* 76 */     return this.defaultStringValue;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\model\parameter\multivalued\AbstractStringReaderExtractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */