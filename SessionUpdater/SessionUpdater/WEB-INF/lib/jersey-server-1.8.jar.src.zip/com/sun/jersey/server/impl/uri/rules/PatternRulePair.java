/*    */ package com.sun.jersey.server.impl.uri.rules;
/*    */ 
/*    */ import com.sun.jersey.api.uri.UriPattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PatternRulePair<R>
/*    */ {
/*    */   public final UriPattern p;
/*    */   public final R r;
/*    */   
/*    */   public PatternRulePair(UriPattern p, R r)
/*    */   {
/* 56 */     this.p = p;
/* 57 */     this.r = r;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\impl\uri\rules\PatternRulePair.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */