/*     */ package com.sun.jersey.server.wadl.generators.resourcedoc.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlAnyElement;
/*     */ import javax.xml.bind.annotation.XmlElementWrapper;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name="methodDoc", propOrder={})
/*     */ public class MethodDocType
/*     */ {
/*     */   private String methodName;
/*     */   protected String commentText;
/*     */   private String returnDoc;
/*     */   private String returnTypeExample;
/*     */   private RequestDocType requestDoc;
/*     */   private ResponseDocType responseDoc;
/*     */   @XmlElementWrapper(name="paramDocs")
/*     */   protected List<ParamDocType> paramDoc;
/*     */   @XmlAnyElement(lax=true)
/*     */   private List<Object> any;
/*     */   
/*     */   public String getCommentText()
/*     */   {
/*  75 */     return this.commentText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCommentText(String value)
/*     */   {
/*  85 */     this.commentText = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<ParamDocType> getParamDocs()
/*     */   {
/*  98 */     if (this.paramDoc == null) {
/*  99 */       this.paramDoc = new ArrayList();
/*     */     }
/* 101 */     return this.paramDoc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<Object> getAny()
/*     */   {
/* 108 */     if (this.any == null) {
/* 109 */       this.any = new ArrayList();
/*     */     }
/* 111 */     return this.any;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getMethodName()
/*     */   {
/* 118 */     return this.methodName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setMethodName(String methodName)
/*     */   {
/* 125 */     this.methodName = methodName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getReturnDoc()
/*     */   {
/* 132 */     return this.returnDoc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setReturnDoc(String returnDoc)
/*     */   {
/* 139 */     this.returnDoc = returnDoc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getReturnTypeExample()
/*     */   {
/* 146 */     return this.returnTypeExample;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setReturnTypeExample(String returnTypeExample)
/*     */   {
/* 153 */     this.returnTypeExample = returnTypeExample;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public RequestDocType getRequestDoc()
/*     */   {
/* 160 */     return this.requestDoc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setRequestDoc(RequestDocType requestDoc)
/*     */   {
/* 167 */     this.requestDoc = requestDoc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ResponseDocType getResponseDoc()
/*     */   {
/* 174 */     return this.responseDoc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setResponseDoc(ResponseDocType responseDoc)
/*     */   {
/* 181 */     this.responseDoc = responseDoc;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-server-1.8.jar!\com\sun\jersey\server\wadl\generators\resourcedoc\model\MethodDocType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */