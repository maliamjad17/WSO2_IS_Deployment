package javax.ws.rs.core;

import java.net.URI;
import java.util.List;

public abstract interface UriInfo
{
  public abstract String getPath();
  
  public abstract String getPath(boolean paramBoolean);
  
  public abstract List<PathSegment> getPathSegments();
  
  public abstract List<PathSegment> getPathSegments(boolean paramBoolean);
  
  public abstract URI getRequestUri();
  
  public abstract UriBuilder getRequestUriBuilder();
  
  public abstract URI getAbsolutePath();
  
  public abstract UriBuilder getAbsolutePathBuilder();
  
  public abstract URI getBaseUri();
  
  public abstract UriBuilder getBaseUriBuilder();
  
  public abstract MultivaluedMap<String, String> getPathParameters();
  
  public abstract MultivaluedMap<String, String> getPathParameters(boolean paramBoolean);
  
  public abstract MultivaluedMap<String, String> getQueryParameters();
  
  public abstract MultivaluedMap<String, String> getQueryParameters(boolean paramBoolean);
  
  public abstract List<String> getMatchedURIs();
  
  public abstract List<String> getMatchedURIs(boolean paramBoolean);
  
  public abstract List<Object> getMatchedResources();
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\javax\ws\rs\core\UriInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */