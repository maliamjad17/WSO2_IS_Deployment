/*     */ package javax.ws.rs.core;
/*     */ 
/*     */ import java.io.StringWriter;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import javax.ws.rs.ext.RuntimeDelegate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Variant
/*     */ {
/*     */   private Locale language;
/*     */   private MediaType mediaType;
/*     */   private String encoding;
/*     */   
/*     */   public Variant(MediaType mediaType, Locale language, String encoding)
/*     */   {
/*  45 */     if ((mediaType == null) && (language == null) && (encoding == null))
/*  46 */       throw new IllegalArgumentException("mediaType, language, encoding all null");
/*  47 */     this.encoding = encoding;
/*  48 */     this.language = language;
/*  49 */     this.mediaType = mediaType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Locale getLanguage()
/*     */   {
/*  57 */     return this.language;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MediaType getMediaType()
/*     */   {
/*  65 */     return this.mediaType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getEncoding()
/*     */   {
/*  73 */     return this.encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static VariantListBuilder mediaTypes(MediaType... mediaTypes)
/*     */   {
/*  87 */     VariantListBuilder b = VariantListBuilder.newInstance();
/*  88 */     b.mediaTypes(mediaTypes);
/*  89 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static VariantListBuilder languages(Locale... languages)
/*     */   {
/* 101 */     VariantListBuilder b = VariantListBuilder.newInstance();
/* 102 */     b.languages(languages);
/* 103 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static VariantListBuilder encodings(String... encodings)
/*     */   {
/* 115 */     VariantListBuilder b = VariantListBuilder.newInstance();
/* 116 */     b.encodings(encodings);
/* 117 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 126 */     int hash = 7;
/* 127 */     hash = 29 * hash + (this.language != null ? this.language.hashCode() : 0);
/* 128 */     hash = 29 * hash + (this.mediaType != null ? this.mediaType.hashCode() : 0);
/* 129 */     hash = 29 * hash + (this.encoding != null ? this.encoding.hashCode() : 0);
/* 130 */     return hash;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 141 */     if (obj == null) {
/* 142 */       return false;
/*     */     }
/* 144 */     if (getClass() != obj.getClass()) {
/* 145 */       return false;
/*     */     }
/* 147 */     Variant other = (Variant)obj;
/* 148 */     if ((this.language != other.language) && ((this.language == null) || (!this.language.equals(other.language)))) {
/* 149 */       return false;
/*     */     }
/* 151 */     if ((this.mediaType != other.mediaType) && ((this.mediaType == null) || (!this.mediaType.equals(other.mediaType)))) {
/* 152 */       return false;
/*     */     }
/* 154 */     if ((this.encoding != other.encoding) && ((this.encoding == null) || (!this.encoding.equals(other.encoding)))) {
/* 155 */       return false;
/*     */     }
/* 157 */     return true;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 162 */     StringWriter w = new StringWriter();
/* 163 */     w.append("Variant[mediaType=");
/* 164 */     w.append(this.mediaType == null ? "null" : this.mediaType.toString());
/* 165 */     w.append(", language=");
/* 166 */     w.append(this.language == null ? "null" : this.language.toString());
/* 167 */     w.append(", encoding=");
/* 168 */     w.append(this.encoding == null ? "null" : this.encoding);
/* 169 */     w.append("]");
/* 170 */     return w.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static abstract class VariantListBuilder
/*     */   {
/*     */     public static VariantListBuilder newInstance()
/*     */     {
/* 189 */       VariantListBuilder b = RuntimeDelegate.getInstance().createVariantListBuilder();
/* 190 */       return b;
/*     */     }
/*     */     
/*     */     public abstract List<Variant> build();
/*     */     
/*     */     public abstract VariantListBuilder add();
/*     */     
/*     */     public abstract VariantListBuilder languages(Locale... paramVarArgs);
/*     */     
/*     */     public abstract VariantListBuilder encodings(String... paramVarArgs);
/*     */     
/*     */     public abstract VariantListBuilder mediaTypes(MediaType... paramVarArgs);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\javax\ws\rs\core\Variant.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */