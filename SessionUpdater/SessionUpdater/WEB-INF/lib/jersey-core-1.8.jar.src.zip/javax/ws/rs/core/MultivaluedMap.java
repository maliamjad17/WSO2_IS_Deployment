package javax.ws.rs.core;

import java.util.List;
import java.util.Map;

public abstract interface MultivaluedMap<K, V>
  extends Map<K, List<V>>
{
  public abstract void putSingle(K paramK, V paramV);
  
  public abstract void add(K paramK, V paramV);
  
  public abstract V getFirst(K paramK);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\javax\ws\rs\core\MultivaluedMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */