/*     */ package javax.ws.rs.core;
/*     */ 
/*     */ import javax.ws.rs.ext.RuntimeDelegate;
/*     */ import javax.ws.rs.ext.RuntimeDelegate.HeaderDelegate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityTag
/*     */ {
/*     */   private String value;
/*     */   private boolean weak;
/*  35 */   private static final RuntimeDelegate.HeaderDelegate<EntityTag> delegate = RuntimeDelegate.getInstance().createHeaderDelegate(EntityTag.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EntityTag(String value)
/*     */   {
/*  44 */     this(value, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EntityTag(String value, boolean weak)
/*     */   {
/*  54 */     if (value == null)
/*  55 */       throw new IllegalArgumentException("value==null");
/*  56 */     this.value = value;
/*  57 */     this.weak = weak;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static EntityTag valueOf(String value)
/*     */     throws IllegalArgumentException
/*     */   {
/*  68 */     return (EntityTag)delegate.fromString(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isWeak()
/*     */   {
/*  76 */     return this.weak;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getValue()
/*     */   {
/*  84 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  95 */     if (obj == null)
/*  96 */       return false;
/*  97 */     if (!(obj instanceof EntityTag))
/*  98 */       return super.equals(obj);
/*  99 */     EntityTag other = (EntityTag)obj;
/* 100 */     if ((this.value.equals(other.getValue())) && (this.weak == other.isWeak()))
/* 101 */       return true;
/* 102 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 111 */     int hash = 3;
/* 112 */     hash = 17 * hash + (this.value != null ? this.value.hashCode() : 0);
/* 113 */     hash = 17 * hash + (this.weak ? 1 : 0);
/* 114 */     return hash;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 124 */     return delegate.toString(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\javax\ws\rs\core\EntityTag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */