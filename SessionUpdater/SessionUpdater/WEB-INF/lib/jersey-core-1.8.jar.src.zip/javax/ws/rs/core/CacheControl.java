/*     */ package javax.ws.rs.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.ws.rs.ext.RuntimeDelegate;
/*     */ import javax.ws.rs.ext.RuntimeDelegate.HeaderDelegate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CacheControl
/*     */ {
/*     */   private boolean _private;
/*     */   private List<String> privateFields;
/*     */   private boolean noCache;
/*     */   private List<String> noCacheFields;
/*     */   private boolean noStore;
/*     */   private boolean noTransform;
/*     */   private boolean mustRevalidate;
/*     */   private boolean proxyRevalidate;
/*  41 */   private int maxAge = -1;
/*  42 */   private int sMaxAge = -1;
/*     */   
/*     */   private Map<String, String> cacheExtension;
/*  45 */   private static final RuntimeDelegate.HeaderDelegate<CacheControl> delegate = RuntimeDelegate.getInstance().createHeaderDelegate(CacheControl.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CacheControl()
/*     */   {
/*  66 */     this._private = false;
/*  67 */     this.noCache = false;
/*  68 */     this.noStore = false;
/*  69 */     this.noTransform = true;
/*  70 */     this.mustRevalidate = false;
/*  71 */     this.proxyRevalidate = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CacheControl valueOf(String value)
/*     */     throws IllegalArgumentException
/*     */   {
/*  82 */     return (CacheControl)delegate.fromString(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isMustRevalidate()
/*     */   {
/*  92 */     return this.mustRevalidate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMustRevalidate(boolean mustRevalidate)
/*     */   {
/* 102 */     this.mustRevalidate = mustRevalidate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isProxyRevalidate()
/*     */   {
/* 112 */     return this.proxyRevalidate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProxyRevalidate(boolean proxyRevalidate)
/*     */   {
/* 122 */     this.proxyRevalidate = proxyRevalidate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaxAge()
/*     */   {
/* 131 */     return this.maxAge;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaxAge(int maxAge)
/*     */   {
/* 140 */     this.maxAge = maxAge;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSMaxAge()
/*     */   {
/* 149 */     return this.sMaxAge;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSMaxAge(int sMaxAge)
/*     */   {
/* 158 */     this.sMaxAge = sMaxAge;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getNoCacheFields()
/*     */   {
/* 170 */     if (this.noCacheFields == null)
/* 171 */       this.noCacheFields = new ArrayList();
/* 172 */     return this.noCacheFields;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNoCache(boolean noCache)
/*     */   {
/* 183 */     this.noCache = noCache;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isNoCache()
/*     */   {
/* 194 */     return this.noCache;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPrivate()
/*     */   {
/* 205 */     return this._private;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getPrivateFields()
/*     */   {
/* 217 */     if (this.privateFields == null)
/* 218 */       this.privateFields = new ArrayList();
/* 219 */     return this.privateFields;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPrivate(boolean _private)
/*     */   {
/* 230 */     this._private = _private;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isNoTransform()
/*     */   {
/* 240 */     return this.noTransform;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNoTransform(boolean noTransform)
/*     */   {
/* 250 */     this.noTransform = noTransform;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isNoStore()
/*     */   {
/* 260 */     return this.noStore;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNoStore(boolean noStore)
/*     */   {
/* 270 */     this.noStore = noStore;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, String> getCacheExtension()
/*     */   {
/* 283 */     if (this.cacheExtension == null)
/* 284 */       this.cacheExtension = new HashMap();
/* 285 */     return this.cacheExtension;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 295 */     return delegate.toString(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 304 */     int hash = 7;
/* 305 */     hash = 41 * hash + (this._private ? 1 : 0);
/* 306 */     hash = 41 * hash + (this.privateFields != null ? this.privateFields.hashCode() : 0);
/* 307 */     hash = 41 * hash + (this.noCache ? 1 : 0);
/* 308 */     hash = 41 * hash + (this.noCacheFields != null ? this.noCacheFields.hashCode() : 0);
/* 309 */     hash = 41 * hash + (this.noStore ? 1 : 0);
/* 310 */     hash = 41 * hash + (this.noTransform ? 1 : 0);
/* 311 */     hash = 41 * hash + (this.mustRevalidate ? 1 : 0);
/* 312 */     hash = 41 * hash + (this.proxyRevalidate ? 1 : 0);
/* 313 */     hash = 41 * hash + this.maxAge;
/* 314 */     hash = 41 * hash + this.sMaxAge;
/* 315 */     hash = 41 * hash + (this.cacheExtension != null ? this.cacheExtension.hashCode() : 0);
/* 316 */     return hash;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 327 */     if (obj == null) {
/* 328 */       return false;
/*     */     }
/* 330 */     if (getClass() != obj.getClass()) {
/* 331 */       return false;
/*     */     }
/* 333 */     CacheControl other = (CacheControl)obj;
/* 334 */     if (this._private != other._private) {
/* 335 */       return false;
/*     */     }
/* 337 */     if ((this.privateFields != other.privateFields) && ((this.privateFields == null) || (!this.privateFields.equals(other.privateFields)))) {
/* 338 */       return false;
/*     */     }
/* 340 */     if (this.noCache != other.noCache) {
/* 341 */       return false;
/*     */     }
/* 343 */     if ((this.noCacheFields != other.noCacheFields) && ((this.noCacheFields == null) || (!this.noCacheFields.equals(other.noCacheFields)))) {
/* 344 */       return false;
/*     */     }
/* 346 */     if (this.noStore != other.noStore) {
/* 347 */       return false;
/*     */     }
/* 349 */     if (this.noTransform != other.noTransform) {
/* 350 */       return false;
/*     */     }
/* 352 */     if (this.mustRevalidate != other.mustRevalidate) {
/* 353 */       return false;
/*     */     }
/* 355 */     if (this.proxyRevalidate != other.proxyRevalidate) {
/* 356 */       return false;
/*     */     }
/* 358 */     if (this.maxAge != other.maxAge) {
/* 359 */       return false;
/*     */     }
/* 361 */     if (this.sMaxAge != other.sMaxAge) {
/* 362 */       return false;
/*     */     }
/* 364 */     if ((this.cacheExtension != other.cacheExtension) && ((this.cacheExtension == null) || (!this.cacheExtension.equals(other.cacheExtension)))) {
/* 365 */       return false;
/*     */     }
/* 367 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\javax\ws\rs\core\CacheControl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */