package javax.ws.rs.ext;

import javax.ws.rs.core.Response;

public abstract interface ExceptionMapper<E extends Throwable>
{
  public abstract Response toResponse(E paramE);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\javax\ws\rs\ext\ExceptionMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */