/*     */ package javax.ws.rs.core;
/*     */ 
/*     */ import javax.ws.rs.ext.RuntimeDelegate;
/*     */ import javax.ws.rs.ext.RuntimeDelegate.HeaderDelegate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Cookie
/*     */ {
/*     */   public static final int DEFAULT_VERSION = 1;
/*  38 */   private static final RuntimeDelegate.HeaderDelegate<Cookie> delegate = RuntimeDelegate.getInstance().createHeaderDelegate(Cookie.class);
/*     */   
/*     */ 
/*     */   private String name;
/*     */   
/*     */ 
/*     */   private String value;
/*     */   
/*     */ 
/*     */   private int version;
/*     */   
/*     */ 
/*     */   private String path;
/*     */   
/*     */   private String domain;
/*     */   
/*     */ 
/*     */   public Cookie(String name, String value, String path, String domain, int version)
/*     */   {
/*  57 */     if (name == null)
/*  58 */       throw new IllegalArgumentException("name==null");
/*  59 */     this.name = name;
/*  60 */     this.value = value;
/*  61 */     this.version = version;
/*  62 */     this.domain = domain;
/*  63 */     this.path = path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cookie(String name, String value, String path, String domain)
/*     */   {
/*  75 */     this(name, value, path, domain, 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cookie(String name, String value)
/*     */   {
/*  85 */     this(name, value, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Cookie valueOf(String value)
/*     */     throws IllegalArgumentException
/*     */   {
/*  96 */     return (Cookie)delegate.fromString(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 104 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getValue()
/*     */   {
/* 112 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getVersion()
/*     */   {
/* 120 */     return this.version;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDomain()
/*     */   {
/* 128 */     return this.domain;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPath()
/*     */   {
/* 136 */     return this.path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 146 */     return delegate.toString(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 155 */     int hash = 7;
/* 156 */     hash = 97 * hash + (this.name != null ? this.name.hashCode() : 0);
/* 157 */     hash = 97 * hash + (this.value != null ? this.value.hashCode() : 0);
/* 158 */     hash = 97 * hash + this.version;
/* 159 */     hash = 97 * hash + (this.path != null ? this.path.hashCode() : 0);
/* 160 */     hash = 97 * hash + (this.domain != null ? this.domain.hashCode() : 0);
/* 161 */     return hash;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 172 */     if (obj == null) {
/* 173 */       return false;
/*     */     }
/* 175 */     if (getClass() != obj.getClass()) {
/* 176 */       return false;
/*     */     }
/* 178 */     Cookie other = (Cookie)obj;
/* 179 */     if ((this.name != other.name) && ((this.name == null) || (!this.name.equals(other.name)))) {
/* 180 */       return false;
/*     */     }
/* 182 */     if ((this.value != other.value) && ((this.value == null) || (!this.value.equals(other.value)))) {
/* 183 */       return false;
/*     */     }
/* 185 */     if (this.version != other.version) {
/* 186 */       return false;
/*     */     }
/* 188 */     if ((this.path != other.path) && ((this.path == null) || (!this.path.equals(other.path)))) {
/* 189 */       return false;
/*     */     }
/* 191 */     if ((this.domain != other.domain) && ((this.domain == null) || (!this.domain.equals(other.domain)))) {
/* 192 */       return false;
/*     */     }
/* 194 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\javax\ws\rs\core\Cookie.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */