/*     */ package javax.ws.rs.core;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import javax.ws.rs.ext.RuntimeDelegate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Response
/*     */ {
/*     */   public abstract Object getEntity();
/*     */   
/*     */   public abstract int getStatus();
/*     */   
/*     */   public abstract MultivaluedMap<String, Object> getMetadata();
/*     */   
/*     */   public static ResponseBuilder fromResponse(Response response)
/*     */   {
/*  86 */     ResponseBuilder b = status(response.getStatus());
/*  87 */     b.entity(response.getEntity());
/*  88 */     for (Iterator i$ = response.getMetadata().keySet().iterator(); i$.hasNext();) { headerName = (String)i$.next();
/*  89 */       List<Object> headerValues = (List)response.getMetadata().get(headerName);
/*  90 */       for (Object headerValue : headerValues)
/*  91 */         b.header(headerName, headerValue);
/*     */     }
/*     */     String headerName;
/*  94 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ResponseBuilder status(StatusType status)
/*     */   {
/* 104 */     ResponseBuilder b = ResponseBuilder.newInstance();
/* 105 */     b.status(status);
/* 106 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ResponseBuilder status(Status status)
/*     */   {
/* 116 */     return status(status);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ResponseBuilder status(int status)
/*     */   {
/* 127 */     ResponseBuilder b = ResponseBuilder.newInstance();
/* 128 */     b.status(status);
/* 129 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ResponseBuilder ok()
/*     */   {
/* 138 */     ResponseBuilder b = status(Status.OK);
/* 139 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ResponseBuilder ok(Object entity)
/*     */   {
/* 151 */     ResponseBuilder b = ok();
/* 152 */     b.entity(entity);
/* 153 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ResponseBuilder ok(Object entity, MediaType type)
/*     */   {
/* 166 */     ResponseBuilder b = ok();
/* 167 */     b.entity(entity);
/* 168 */     b.type(type);
/* 169 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ResponseBuilder ok(Object entity, String type)
/*     */   {
/* 182 */     ResponseBuilder b = ok();
/* 183 */     b.entity(entity);
/* 184 */     b.type(type);
/* 185 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ResponseBuilder ok(Object entity, Variant variant)
/*     */   {
/* 198 */     ResponseBuilder b = ok();
/* 199 */     b.entity(entity);
/* 200 */     b.variant(variant);
/* 201 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ResponseBuilder serverError()
/*     */   {
/* 210 */     ResponseBuilder b = status(Status.INTERNAL_SERVER_ERROR);
/* 211 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ResponseBuilder created(URI location)
/*     */   {
/* 225 */     ResponseBuilder b = status(Status.CREATED).location(location);
/* 226 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ResponseBuilder noContent()
/*     */   {
/* 235 */     ResponseBuilder b = status(Status.NO_CONTENT);
/* 236 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ResponseBuilder notModified()
/*     */   {
/* 245 */     ResponseBuilder b = status(Status.NOT_MODIFIED);
/* 246 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ResponseBuilder notModified(EntityTag tag)
/*     */   {
/* 257 */     ResponseBuilder b = notModified();
/* 258 */     b.tag(tag);
/* 259 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ResponseBuilder notModified(String tag)
/*     */   {
/* 273 */     ResponseBuilder b = notModified();
/* 274 */     b.tag(tag);
/* 275 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ResponseBuilder seeOther(URI location)
/*     */   {
/* 290 */     ResponseBuilder b = status(Status.SEE_OTHER).location(location);
/* 291 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ResponseBuilder temporaryRedirect(URI location)
/*     */   {
/* 305 */     ResponseBuilder b = status(Status.TEMPORARY_REDIRECT).location(location);
/* 306 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ResponseBuilder notAcceptable(List<Variant> variants)
/*     */   {
/* 317 */     ResponseBuilder b = status(Status.NOT_ACCEPTABLE).variants(variants);
/* 318 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static abstract class ResponseBuilder
/*     */   {
/*     */     protected static ResponseBuilder newInstance()
/*     */     {
/* 356 */       ResponseBuilder b = RuntimeDelegate.getInstance().createResponseBuilder();
/* 357 */       return b;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract Response build();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract ResponseBuilder clone();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract ResponseBuilder status(int paramInt);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ResponseBuilder status(Response.StatusType status)
/*     */     {
/* 393 */       if (status == null)
/* 394 */         throw new IllegalArgumentException();
/* 395 */       return status(status.getStatusCode());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ResponseBuilder status(Response.Status status)
/*     */     {
/* 406 */       return status(status);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract ResponseBuilder entity(Object paramObject);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract ResponseBuilder type(MediaType paramMediaType);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract ResponseBuilder type(String paramString);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract ResponseBuilder variant(Variant paramVariant);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract ResponseBuilder variants(List<Variant> paramList);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract ResponseBuilder language(String paramString);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract ResponseBuilder language(Locale paramLocale);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract ResponseBuilder location(URI paramURI);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract ResponseBuilder contentLocation(URI paramURI);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract ResponseBuilder tag(EntityTag paramEntityTag);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract ResponseBuilder tag(String paramString);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract ResponseBuilder lastModified(Date paramDate);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract ResponseBuilder cacheControl(CacheControl paramCacheControl);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract ResponseBuilder expires(Date paramDate);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract ResponseBuilder header(String paramString, Object paramObject);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract ResponseBuilder cookie(NewCookie... paramVarArgs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static abstract interface StatusType
/*     */   {
/*     */     public abstract int getStatusCode();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract Response.Status.Family getFamily();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract String getReasonPhrase();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static enum Status
/*     */     implements Response.StatusType
/*     */   {
/* 605 */     OK(200, "OK"), 
/*     */     
/*     */ 
/*     */ 
/* 609 */     CREATED(201, "Created"), 
/*     */     
/*     */ 
/*     */ 
/* 613 */     ACCEPTED(202, "Accepted"), 
/*     */     
/*     */ 
/*     */ 
/* 617 */     NO_CONTENT(204, "No Content"), 
/*     */     
/*     */ 
/*     */ 
/* 621 */     MOVED_PERMANENTLY(301, "Moved Permanently"), 
/*     */     
/*     */ 
/*     */ 
/* 625 */     SEE_OTHER(303, "See Other"), 
/*     */     
/*     */ 
/*     */ 
/* 629 */     NOT_MODIFIED(304, "Not Modified"), 
/*     */     
/*     */ 
/*     */ 
/* 633 */     TEMPORARY_REDIRECT(307, "Temporary Redirect"), 
/*     */     
/*     */ 
/*     */ 
/* 637 */     BAD_REQUEST(400, "Bad Request"), 
/*     */     
/*     */ 
/*     */ 
/* 641 */     UNAUTHORIZED(401, "Unauthorized"), 
/*     */     
/*     */ 
/*     */ 
/* 645 */     FORBIDDEN(403, "Forbidden"), 
/*     */     
/*     */ 
/*     */ 
/* 649 */     NOT_FOUND(404, "Not Found"), 
/*     */     
/*     */ 
/*     */ 
/* 653 */     NOT_ACCEPTABLE(406, "Not Acceptable"), 
/*     */     
/*     */ 
/*     */ 
/* 657 */     CONFLICT(409, "Conflict"), 
/*     */     
/*     */ 
/*     */ 
/* 661 */     GONE(410, "Gone"), 
/*     */     
/*     */ 
/*     */ 
/* 665 */     PRECONDITION_FAILED(412, "Precondition Failed"), 
/*     */     
/*     */ 
/*     */ 
/* 669 */     UNSUPPORTED_MEDIA_TYPE(415, "Unsupported Media Type"), 
/*     */     
/*     */ 
/*     */ 
/* 673 */     INTERNAL_SERVER_ERROR(500, "Internal Server Error"), 
/*     */     
/*     */ 
/*     */ 
/* 677 */     SERVICE_UNAVAILABLE(503, "Service Unavailable");
/*     */     
/*     */ 
/*     */     private final int code;
/*     */     
/*     */     private final String reason;
/*     */     private Family family;
/*     */     
/*     */     public static enum Family
/*     */     {
/* 687 */       INFORMATIONAL,  SUCCESSFUL,  REDIRECTION,  CLIENT_ERROR,  SERVER_ERROR,  OTHER;
/*     */       
/*     */       private Family() {} }
/* 690 */     private Status(int statusCode, String reasonPhrase) { this.code = statusCode;
/* 691 */       this.reason = reasonPhrase;
/* 692 */       switch (this.code / 100) {
/* 693 */       case 1:  this.family = Family.INFORMATIONAL; break;
/* 694 */       case 2:  this.family = Family.SUCCESSFUL; break;
/* 695 */       case 3:  this.family = Family.REDIRECTION; break;
/* 696 */       case 4:  this.family = Family.CLIENT_ERROR; break;
/* 697 */       case 5:  this.family = Family.SERVER_ERROR; break;
/* 698 */       default:  this.family = Family.OTHER;
/*     */       }
/*     */       
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Family getFamily()
/*     */     {
/* 707 */       return this.family;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getStatusCode()
/*     */     {
/* 715 */       return this.code;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getReasonPhrase()
/*     */     {
/* 723 */       return toString();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/* 732 */       return this.reason;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static Status fromStatusCode(int statusCode)
/*     */     {
/* 741 */       for (Status s : ) {
/* 742 */         if (s.code == statusCode) {
/* 743 */           return s;
/*     */         }
/*     */       }
/* 746 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\javax\ws\rs\core\Response.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */