package javax.ws.rs.ext;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import javax.ws.rs.core.MediaType;

public abstract interface Providers
{
  public abstract <T> MessageBodyReader<T> getMessageBodyReader(Class<T> paramClass, Type paramType, Annotation[] paramArrayOfAnnotation, MediaType paramMediaType);
  
  public abstract <T> MessageBodyWriter<T> getMessageBodyWriter(Class<T> paramClass, Type paramType, Annotation[] paramArrayOfAnnotation, MediaType paramMediaType);
  
  public abstract <T extends Throwable> ExceptionMapper<T> getExceptionMapper(Class<T> paramClass);
  
  public abstract <T> ContextResolver<T> getContextResolver(Class<T> paramClass, MediaType paramMediaType);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\javax\ws\rs\ext\Providers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */