/*     */ package javax.ws.rs;
/*     */ 
/*     */ import javax.ws.rs.core.Response;
/*     */ import javax.ws.rs.core.Response.ResponseBuilder;
/*     */ import javax.ws.rs.core.Response.Status;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebApplicationException
/*     */   extends RuntimeException
/*     */ {
/*     */   private static final long serialVersionUID = 11660101L;
/*     */   private Response response;
/*     */   
/*     */   public WebApplicationException()
/*     */   {
/*  37 */     this(null, Response.Status.INTERNAL_SERVER_ERROR);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WebApplicationException(Response response)
/*     */   {
/*  47 */     this(null, response);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public WebApplicationException(int status)
/*     */   {
/*  55 */     this(null, status);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WebApplicationException(Response.Status status)
/*     */   {
/*  64 */     this(null, status);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public WebApplicationException(Throwable cause)
/*     */   {
/*  72 */     this(cause, Response.Status.INTERNAL_SERVER_ERROR);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WebApplicationException(Throwable cause, Response response)
/*     */   {
/*  83 */     super(cause);
/*  84 */     if (response == null) {
/*  85 */       this.response = Response.serverError().build();
/*     */     } else {
/*  87 */       this.response = response;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public WebApplicationException(Throwable cause, int status)
/*     */   {
/*  96 */     this(cause, Response.status(status).build());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WebApplicationException(Throwable cause, Response.Status status)
/*     */   {
/* 106 */     this(cause, Response.status(status).build());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Response getResponse()
/*     */   {
/* 115 */     return this.response;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\javax\ws\rs\WebApplicationException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */