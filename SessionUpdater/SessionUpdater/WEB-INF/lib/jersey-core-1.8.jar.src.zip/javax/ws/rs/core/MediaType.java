/*     */ package javax.ws.rs.core;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.TreeMap;
/*     */ import javax.ws.rs.ext.RuntimeDelegate;
/*     */ import javax.ws.rs.ext.RuntimeDelegate.HeaderDelegate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MediaType
/*     */ {
/*     */   private String type;
/*     */   private String subtype;
/*     */   private Map<String, String> parameters;
/*  42 */   private static final Map<String, String> emptyMap = ;
/*     */   
/*  44 */   private static final RuntimeDelegate.HeaderDelegate<MediaType> delegate = RuntimeDelegate.getInstance().createHeaderDelegate(MediaType.class);
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String MEDIA_TYPE_WILDCARD = "*";
/*     */   
/*     */ 
/*     */   public static final String WILDCARD = "*/*";
/*     */   
/*     */ 
/*  54 */   public static final MediaType WILDCARD_TYPE = new MediaType();
/*     */   
/*     */ 
/*     */   public static final String APPLICATION_XML = "application/xml";
/*     */   
/*  59 */   public static final MediaType APPLICATION_XML_TYPE = new MediaType("application", "xml");
/*     */   
/*     */ 
/*     */   public static final String APPLICATION_ATOM_XML = "application/atom+xml";
/*     */   
/*  64 */   public static final MediaType APPLICATION_ATOM_XML_TYPE = new MediaType("application", "atom+xml");
/*     */   
/*     */ 
/*     */   public static final String APPLICATION_XHTML_XML = "application/xhtml+xml";
/*     */   
/*  69 */   public static final MediaType APPLICATION_XHTML_XML_TYPE = new MediaType("application", "xhtml+xml");
/*     */   
/*     */ 
/*     */   public static final String APPLICATION_SVG_XML = "application/svg+xml";
/*     */   
/*  74 */   public static final MediaType APPLICATION_SVG_XML_TYPE = new MediaType("application", "svg+xml");
/*     */   
/*     */ 
/*     */   public static final String APPLICATION_JSON = "application/json";
/*     */   
/*  79 */   public static final MediaType APPLICATION_JSON_TYPE = new MediaType("application", "json");
/*     */   
/*     */ 
/*     */   public static final String APPLICATION_FORM_URLENCODED = "application/x-www-form-urlencoded";
/*     */   
/*  84 */   public static final MediaType APPLICATION_FORM_URLENCODED_TYPE = new MediaType("application", "x-www-form-urlencoded");
/*     */   
/*     */ 
/*     */   public static final String MULTIPART_FORM_DATA = "multipart/form-data";
/*     */   
/*  89 */   public static final MediaType MULTIPART_FORM_DATA_TYPE = new MediaType("multipart", "form-data");
/*     */   
/*     */ 
/*     */   public static final String APPLICATION_OCTET_STREAM = "application/octet-stream";
/*     */   
/*  94 */   public static final MediaType APPLICATION_OCTET_STREAM_TYPE = new MediaType("application", "octet-stream");
/*     */   
/*     */ 
/*     */   public static final String TEXT_PLAIN = "text/plain";
/*     */   
/*  99 */   public static final MediaType TEXT_PLAIN_TYPE = new MediaType("text", "plain");
/*     */   
/*     */ 
/*     */   public static final String TEXT_XML = "text/xml";
/*     */   
/* 104 */   public static final MediaType TEXT_XML_TYPE = new MediaType("text", "xml");
/*     */   
/*     */ 
/*     */   public static final String TEXT_HTML = "text/html";
/*     */   
/* 109 */   public static final MediaType TEXT_HTML_TYPE = new MediaType("text", "html");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MediaType valueOf(String type)
/*     */     throws IllegalArgumentException
/*     */   {
/* 119 */     return (MediaType)delegate.fromString(type);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MediaType(String type, String subtype, Map<String, String> parameters)
/*     */   {
/* 133 */     this.type = (type == null ? "*" : type);
/* 134 */     this.subtype = (subtype == null ? "*" : subtype);
/* 135 */     if (parameters == null) {
/* 136 */       this.parameters = emptyMap;
/*     */     } else {
/* 138 */       Map<String, String> map = new TreeMap(new Comparator() {
/*     */         public int compare(String o1, String o2) {
/* 140 */           return o1.compareToIgnoreCase(o2);
/*     */         }
/*     */       });
/* 143 */       for (Map.Entry<String, String> e : parameters.entrySet()) {
/* 144 */         map.put(((String)e.getKey()).toLowerCase(), e.getValue());
/*     */       }
/* 146 */       this.parameters = Collections.unmodifiableMap(map);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MediaType(String type, String subtype)
/*     */   {
/* 158 */     this(type, subtype, emptyMap);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MediaType()
/*     */   {
/* 166 */     this("*", "*");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getType()
/*     */   {
/* 174 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isWildcardType()
/*     */   {
/* 182 */     return getType().equals("*");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSubtype()
/*     */   {
/* 190 */     return this.subtype;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isWildcardSubtype()
/*     */   {
/* 198 */     return getSubtype().equals("*");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, String> getParameters()
/*     */   {
/* 206 */     return this.parameters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCompatible(MediaType other)
/*     */   {
/* 217 */     if (other == null)
/* 218 */       return false;
/* 219 */     if ((this.type.equals("*")) || (other.type.equals("*")))
/* 220 */       return true;
/* 221 */     if ((this.type.equalsIgnoreCase(other.type)) && ((this.subtype.equals("*")) || (other.subtype.equals("*")))) {
/* 222 */       return true;
/*     */     }
/* 224 */     return (this.type.equalsIgnoreCase(other.type)) && (this.subtype.equalsIgnoreCase(other.subtype));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 239 */     if (obj == null)
/* 240 */       return false;
/* 241 */     if (!(obj instanceof MediaType))
/* 242 */       return false;
/* 243 */     MediaType other = (MediaType)obj;
/* 244 */     return (this.type.equalsIgnoreCase(other.type)) && (this.subtype.equalsIgnoreCase(other.subtype)) && (this.parameters.equals(other.parameters));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 255 */     return (this.type.toLowerCase() + this.subtype.toLowerCase()).hashCode() + this.parameters.hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 265 */     return delegate.toString(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\javax\ws\rs\core\MediaType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */