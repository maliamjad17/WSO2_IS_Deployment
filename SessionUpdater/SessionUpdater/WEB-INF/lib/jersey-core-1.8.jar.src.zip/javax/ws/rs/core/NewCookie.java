/*     */ package javax.ws.rs.core;
/*     */ 
/*     */ import javax.ws.rs.ext.RuntimeDelegate;
/*     */ import javax.ws.rs.ext.RuntimeDelegate.HeaderDelegate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NewCookie
/*     */   extends Cookie
/*     */ {
/*     */   public static final int DEFAULT_MAX_AGE = -1;
/*  36 */   private static final RuntimeDelegate.HeaderDelegate<NewCookie> delegate = RuntimeDelegate.getInstance().createHeaderDelegate(NewCookie.class);
/*     */   
/*     */ 
/*  39 */   private String comment = null;
/*  40 */   private int maxAge = -1;
/*  41 */   private boolean secure = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NewCookie(String name, String value)
/*     */   {
/*  50 */     super(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NewCookie(String name, String value, String path, String domain, String comment, int maxAge, boolean secure)
/*     */   {
/*  65 */     super(name, value, path, domain);
/*  66 */     this.comment = comment;
/*  67 */     this.maxAge = maxAge;
/*  68 */     this.secure = secure;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NewCookie(String name, String value, String path, String domain, int version, String comment, int maxAge, boolean secure)
/*     */   {
/*  84 */     super(name, value, path, domain, version);
/*  85 */     this.comment = comment;
/*  86 */     this.maxAge = maxAge;
/*  87 */     this.secure = secure;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NewCookie(Cookie cookie)
/*     */   {
/*  96 */     super(cookie == null ? null : cookie.getName(), cookie == null ? null : cookie.getValue(), cookie == null ? null : cookie.getPath(), cookie == null ? null : cookie.getDomain(), cookie == null ? 1 : cookie.getVersion());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NewCookie(Cookie cookie, String comment, int maxAge, boolean secure)
/*     */   {
/* 112 */     this(cookie);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NewCookie valueOf(String value)
/*     */     throws IllegalArgumentException
/*     */   {
/* 126 */     return (NewCookie)delegate.fromString(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getComment()
/*     */   {
/* 134 */     return this.comment;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaxAge()
/*     */   {
/* 146 */     return this.maxAge;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSecure()
/*     */   {
/* 156 */     return this.secure;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cookie toCookie()
/*     */   {
/* 167 */     return new Cookie(getName(), getValue(), getPath(), getDomain(), getVersion());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 178 */     return delegate.toString(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 187 */     int hash = super.hashCode();
/* 188 */     hash = 59 * hash + (this.comment != null ? this.comment.hashCode() : 0);
/* 189 */     hash = 59 * hash + this.maxAge;
/* 190 */     hash = 59 * hash + (this.secure ? 1 : 0);
/* 191 */     return hash;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 204 */     if (obj == null) {
/* 205 */       return false;
/*     */     }
/* 207 */     if (getClass() != obj.getClass()) {
/* 208 */       return false;
/*     */     }
/* 210 */     NewCookie other = (NewCookie)obj;
/* 211 */     if ((getName() != other.getName()) && ((getName() == null) || (!getName().equals(other.getName())))) {
/* 212 */       return false;
/*     */     }
/* 214 */     if ((getValue() != other.getValue()) && ((getValue() == null) || (!getValue().equals(other.getValue())))) {
/* 215 */       return false;
/*     */     }
/* 217 */     if (getVersion() != other.getVersion()) {
/* 218 */       return false;
/*     */     }
/* 220 */     if ((getPath() != other.getPath()) && ((getPath() == null) || (!getPath().equals(other.getPath())))) {
/* 221 */       return false;
/*     */     }
/* 223 */     if ((getDomain() != other.getDomain()) && ((getDomain() == null) || (!getDomain().equals(other.getDomain())))) {
/* 224 */       return false;
/*     */     }
/* 226 */     if ((this.comment != other.comment) && ((this.comment == null) || (!this.comment.equals(other.comment)))) {
/* 227 */       return false;
/*     */     }
/* 229 */     if (this.maxAge != other.maxAge) {
/* 230 */       return false;
/*     */     }
/* 232 */     if (this.secure != other.secure) {
/* 233 */       return false;
/*     */     }
/* 235 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\javax\ws\rs\core\NewCookie.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */