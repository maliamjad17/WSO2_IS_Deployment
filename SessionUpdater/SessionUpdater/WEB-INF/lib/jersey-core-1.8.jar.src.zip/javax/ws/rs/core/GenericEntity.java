/*     */ package javax.ws.rs.core;
/*     */ 
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericEntity<T>
/*     */ {
/*     */   final Class<?> rawType;
/*     */   final Type type;
/*     */   final T entity;
/*     */   
/*     */   protected GenericEntity(T entity)
/*     */   {
/*  88 */     if (entity == null) {
/*  89 */       throw new IllegalArgumentException("The entity must not be null");
/*     */     }
/*  91 */     this.entity = entity;
/*  92 */     this.type = getSuperclassTypeParameter(getClass());
/*  93 */     this.rawType = entity.getClass();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GenericEntity(T entity, Type genericType)
/*     */   {
/* 110 */     if ((entity == null) || (genericType == null)) {
/* 111 */       throw new IllegalArgumentException("Arguments must not be null");
/*     */     }
/* 113 */     this.entity = entity;
/* 114 */     this.rawType = entity.getClass();
/* 115 */     checkTypeCompatibility(this.rawType, genericType);
/* 116 */     this.type = genericType;
/*     */   }
/*     */   
/*     */   private void checkTypeCompatibility(Class<?> c, Type t) {
/* 120 */     if ((t instanceof Class)) {
/* 121 */       Class<?> ct = (Class)t;
/* 122 */       if (ct.isAssignableFrom(c))
/* 123 */         return;
/* 124 */     } else { if ((t instanceof ParameterizedType)) {
/* 125 */         ParameterizedType pt = (ParameterizedType)t;
/* 126 */         Type rt = pt.getRawType();
/* 127 */         checkTypeCompatibility(c, rt);
/* 128 */         return; }
/* 129 */       if ((c.isArray()) && ((t instanceof GenericArrayType))) {
/* 130 */         GenericArrayType at = (GenericArrayType)t;
/* 131 */         Type rt = at.getGenericComponentType();
/* 132 */         checkTypeCompatibility(c.getComponentType(), rt);
/* 133 */         return;
/*     */       } }
/* 135 */     throw new IllegalArgumentException("The type is incompatible with the class of the entity");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static Type getSuperclassTypeParameter(Class<?> subclass)
/*     */   {
/* 142 */     Type superclass = subclass.getGenericSuperclass();
/* 143 */     if (!(superclass instanceof ParameterizedType)) {
/* 144 */       throw new RuntimeException("Missing type parameter.");
/*     */     }
/* 146 */     ParameterizedType parameterized = (ParameterizedType)superclass;
/* 147 */     return parameterized.getActualTypeArguments()[0];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Class<?> getRawType()
/*     */   {
/* 157 */     return this.rawType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Type getType()
/*     */   {
/* 168 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final T getEntity()
/*     */   {
/* 176 */     return (T)this.entity;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\javax\ws\rs\core\GenericEntity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */