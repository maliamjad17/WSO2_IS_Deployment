package javax.ws.rs.core;

public abstract interface PathSegment
{
  public abstract String getPath();
  
  public abstract MultivaluedMap<String, String> getMatrixParameters();
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\javax\ws\rs\core\PathSegment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */