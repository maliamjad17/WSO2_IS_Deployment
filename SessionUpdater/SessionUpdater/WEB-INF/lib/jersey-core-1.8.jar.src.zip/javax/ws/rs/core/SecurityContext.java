package javax.ws.rs.core;

import java.security.Principal;

public abstract interface SecurityContext
{
  public static final String BASIC_AUTH = "BASIC";
  public static final String CLIENT_CERT_AUTH = "CLIENT_CERT";
  public static final String DIGEST_AUTH = "DIGEST";
  public static final String FORM_AUTH = "FORM";
  
  public abstract Principal getUserPrincipal();
  
  public abstract boolean isUserInRole(String paramString);
  
  public abstract boolean isSecure();
  
  public abstract String getAuthenticationScheme();
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\javax\ws\rs\core\SecurityContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */