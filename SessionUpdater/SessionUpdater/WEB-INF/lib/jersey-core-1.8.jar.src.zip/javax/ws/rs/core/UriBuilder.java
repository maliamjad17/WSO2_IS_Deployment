/*     */ package javax.ws.rs.core;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URI;
/*     */ import java.util.Map;
/*     */ import javax.ws.rs.ext.RuntimeDelegate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class UriBuilder
/*     */ {
/*     */   protected static UriBuilder newInstance()
/*     */   {
/*  69 */     UriBuilder b = RuntimeDelegate.getInstance().createUriBuilder();
/*  70 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UriBuilder fromUri(URI uri)
/*     */     throws IllegalArgumentException
/*     */   {
/*  80 */     UriBuilder b = newInstance();
/*  81 */     b.uri(uri);
/*  82 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static UriBuilder fromUri(String uri)
/*     */     throws IllegalArgumentException
/*     */   {
/*     */     URI u;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  95 */       u = URI.create(uri);
/*     */     } catch (NullPointerException ex) {
/*  97 */       throw new IllegalArgumentException(ex.getMessage(), ex);
/*     */     }
/*  99 */     return fromUri(u);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UriBuilder fromPath(String path)
/*     */     throws IllegalArgumentException
/*     */   {
/* 111 */     UriBuilder b = newInstance();
/* 112 */     b.path(path);
/* 113 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UriBuilder fromResource(Class<?> resource)
/*     */     throws IllegalArgumentException
/*     */   {
/* 127 */     UriBuilder b = newInstance();
/* 128 */     b.path(resource);
/* 129 */     return b;
/*     */   }
/*     */   
/*     */   public abstract UriBuilder clone();
/*     */   
/*     */   public abstract UriBuilder uri(URI paramURI)
/*     */     throws IllegalArgumentException;
/*     */   
/*     */   public abstract UriBuilder scheme(String paramString)
/*     */     throws IllegalArgumentException;
/*     */   
/*     */   public abstract UriBuilder schemeSpecificPart(String paramString)
/*     */     throws IllegalArgumentException;
/*     */   
/*     */   public abstract UriBuilder userInfo(String paramString);
/*     */   
/*     */   public abstract UriBuilder host(String paramString)
/*     */     throws IllegalArgumentException;
/*     */   
/*     */   public abstract UriBuilder port(int paramInt)
/*     */     throws IllegalArgumentException;
/*     */   
/*     */   public abstract UriBuilder replacePath(String paramString);
/*     */   
/*     */   public abstract UriBuilder path(String paramString)
/*     */     throws IllegalArgumentException;
/*     */   
/*     */   public abstract UriBuilder path(Class paramClass)
/*     */     throws IllegalArgumentException;
/*     */   
/*     */   public abstract UriBuilder path(Class paramClass, String paramString)
/*     */     throws IllegalArgumentException;
/*     */   
/*     */   public abstract UriBuilder path(Method paramMethod)
/*     */     throws IllegalArgumentException;
/*     */   
/*     */   public abstract UriBuilder segment(String... paramVarArgs)
/*     */     throws IllegalArgumentException;
/*     */   
/*     */   public abstract UriBuilder replaceMatrix(String paramString)
/*     */     throws IllegalArgumentException;
/*     */   
/*     */   public abstract UriBuilder matrixParam(String paramString, Object... paramVarArgs)
/*     */     throws IllegalArgumentException;
/*     */   
/*     */   public abstract UriBuilder replaceMatrixParam(String paramString, Object... paramVarArgs)
/*     */     throws IllegalArgumentException;
/*     */   
/*     */   public abstract UriBuilder replaceQuery(String paramString)
/*     */     throws IllegalArgumentException;
/*     */   
/*     */   public abstract UriBuilder queryParam(String paramString, Object... paramVarArgs)
/*     */     throws IllegalArgumentException;
/*     */   
/*     */   public abstract UriBuilder replaceQueryParam(String paramString, Object... paramVarArgs)
/*     */     throws IllegalArgumentException;
/*     */   
/*     */   public abstract UriBuilder fragment(String paramString);
/*     */   
/*     */   public abstract URI buildFromMap(Map<String, ? extends Object> paramMap)
/*     */     throws IllegalArgumentException, UriBuilderException;
/*     */   
/*     */   public abstract URI buildFromEncodedMap(Map<String, ? extends Object> paramMap)
/*     */     throws IllegalArgumentException, UriBuilderException;
/*     */   
/*     */   public abstract URI build(Object... paramVarArgs)
/*     */     throws IllegalArgumentException, UriBuilderException;
/*     */   
/*     */   public abstract URI buildFromEncoded(Object... paramVarArgs)
/*     */     throws IllegalArgumentException, UriBuilderException;
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\javax\ws\rs\core\UriBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */