/*     */ package com.sun.jersey.core.util;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnmodifiableMultivaluedMap<K, V>
/*     */   implements MultivaluedMap<K, V>
/*     */ {
/*     */   private final MultivaluedMap<K, V> delegate;
/*     */   
/*     */   public UnmodifiableMultivaluedMap(MultivaluedMap<K, V> delegate)
/*     */   {
/*  69 */     this.delegate = delegate;
/*     */   }
/*     */   
/*     */   public void putSingle(K key, V value)
/*     */   {
/*  74 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void add(K key, V value)
/*     */   {
/*  79 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public V getFirst(K key)
/*     */   {
/*  84 */     return (V)this.delegate.getFirst(key);
/*     */   }
/*     */   
/*     */   public int size()
/*     */   {
/*  89 */     return this.delegate.size();
/*     */   }
/*     */   
/*     */   public boolean isEmpty()
/*     */   {
/*  94 */     return this.delegate.isEmpty();
/*     */   }
/*     */   
/*     */   public boolean containsKey(Object key)
/*     */   {
/*  99 */     return this.delegate.containsKey(key);
/*     */   }
/*     */   
/*     */   public boolean containsValue(Object value)
/*     */   {
/* 104 */     return this.delegate.containsValue(value);
/*     */   }
/*     */   
/*     */   public List<V> get(Object key)
/*     */   {
/* 109 */     return (List)this.delegate.get(key);
/*     */   }
/*     */   
/*     */   public List<V> put(K key, List<V> value)
/*     */   {
/* 114 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public List<V> remove(Object key)
/*     */   {
/* 119 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void putAll(Map<? extends K, ? extends List<V>> m)
/*     */   {
/* 124 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void clear()
/*     */   {
/* 129 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Set<K> keySet()
/*     */   {
/* 134 */     return Collections.unmodifiableSet(this.delegate.keySet());
/*     */   }
/*     */   
/*     */   public Collection<List<V>> values()
/*     */   {
/* 139 */     return Collections.unmodifiableCollection(this.delegate.values());
/*     */   }
/*     */   
/*     */   public Set<Map.Entry<K, List<V>>> entrySet()
/*     */   {
/* 144 */     return Collections.unmodifiableSet(this.delegate.entrySet());
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\util\UnmodifiableMultivaluedMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */