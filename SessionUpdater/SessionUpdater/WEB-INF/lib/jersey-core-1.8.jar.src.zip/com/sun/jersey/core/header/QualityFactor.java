package com.sun.jersey.core.header;

public abstract interface QualityFactor
{
  public static final String QUALITY_FACTOR = "q";
  public static final int MINUMUM_QUALITY = 0;
  public static final int MAXIMUM_QUALITY = 1000;
  public static final int DEFAULT_QUALITY_FACTOR = 1000;
  
  public abstract int getQuality();
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\header\QualityFactor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */