/*    */ package com.sun.jersey.core.spi.component;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.AccessibleObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnotatedContext
/*    */   implements ComponentContext
/*    */ {
/*    */   private Annotation[] annotations;
/*    */   private AccessibleObject ao;
/*    */   
/*    */   public AnnotatedContext() {}
/*    */   
/*    */   public AnnotatedContext(Annotation[] annotations)
/*    */   {
/* 60 */     this(null, annotations);
/*    */   }
/*    */   
/*    */   public AnnotatedContext(AccessibleObject ao) {
/* 64 */     this(ao, null);
/*    */   }
/*    */   
/*    */   public AnnotatedContext(AccessibleObject ao, Annotation[] annotations) {
/* 68 */     this.ao = ao;
/* 69 */     this.annotations = annotations;
/*    */   }
/*    */   
/*    */   public void setAnnotations(Annotation[] annotations) {
/* 73 */     this.annotations = annotations;
/*    */   }
/*    */   
/*    */   public void setAccessibleObject(AccessibleObject ao) {
/* 77 */     this.ao = ao;
/*    */   }
/*    */   
/*    */ 
/*    */   public AccessibleObject getAccesibleObject()
/*    */   {
/* 83 */     return this.ao;
/*    */   }
/*    */   
/*    */   public Annotation[] getAnnotations() {
/* 87 */     return this.annotations;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\component\AnnotatedContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */