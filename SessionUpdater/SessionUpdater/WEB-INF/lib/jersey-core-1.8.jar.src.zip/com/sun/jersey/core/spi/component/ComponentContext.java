package com.sun.jersey.core.spi.component;

import java.lang.annotation.Annotation;
import java.lang.reflect.AccessibleObject;

public abstract interface ComponentContext
{
  public abstract AccessibleObject getAccesibleObject();
  
  public abstract Annotation[] getAnnotations();
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\component\ComponentContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */