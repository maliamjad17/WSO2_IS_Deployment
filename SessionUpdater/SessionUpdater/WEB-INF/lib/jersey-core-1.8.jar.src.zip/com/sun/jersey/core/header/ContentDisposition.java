/*     */ package com.sun.jersey.core.header;
/*     */ 
/*     */ import com.sun.jersey.core.header.reader.HttpHeaderReader;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContentDisposition
/*     */ {
/*     */   private String type;
/*     */   private Map<String, String> parameters;
/*     */   private String fileName;
/*     */   private Date creationDate;
/*     */   private Date modificationDate;
/*     */   private Date readDate;
/*     */   private long size;
/*     */   
/*     */   protected ContentDisposition(String type, String fileName, Date creationDate, Date modificationDate, Date readDate, long size)
/*     */   {
/*  73 */     this.type = type;
/*  74 */     this.fileName = fileName;
/*  75 */     this.creationDate = creationDate;
/*  76 */     this.modificationDate = modificationDate;
/*  77 */     this.readDate = readDate;
/*  78 */     this.size = size;
/*     */   }
/*     */   
/*     */   public ContentDisposition(String header) throws ParseException {
/*  82 */     this(HttpHeaderReader.newInstance(header));
/*     */   }
/*     */   
/*     */   public ContentDisposition(HttpHeaderReader reader) throws ParseException {
/*  86 */     reader.hasNext();
/*     */     
/*  88 */     this.type = reader.nextToken();
/*     */     
/*  90 */     if (reader.hasNext())
/*  91 */       this.parameters = HttpHeaderReader.readParameters(reader);
/*  92 */     if (this.parameters == null) {
/*  93 */       this.parameters = Collections.emptyMap();
/*     */     } else {
/*  95 */       this.parameters = Collections.unmodifiableMap(this.parameters);
/*     */     }
/*  97 */     createParameters();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getType()
/*     */   {
/* 106 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, String> getParameters()
/*     */   {
/* 115 */     return this.parameters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFileName()
/*     */   {
/* 124 */     return this.fileName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getCreationDate()
/*     */   {
/* 133 */     return this.creationDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getModificationDate()
/*     */   {
/* 142 */     return this.modificationDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getReadDate()
/*     */   {
/* 151 */     return this.readDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getSize()
/*     */   {
/* 160 */     return this.size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 170 */     return toStringBuffer().toString();
/*     */   }
/*     */   
/*     */   protected StringBuilder toStringBuffer() {
/* 174 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 176 */     sb.append(this.type);
/* 177 */     addStringParameter(sb, "filename", this.fileName);
/* 178 */     addDateParameter(sb, "creation-date", this.creationDate);
/* 179 */     addDateParameter(sb, "modification-date", this.modificationDate);
/* 180 */     addDateParameter(sb, "read-date", this.readDate);
/* 181 */     addLongParameter(sb, "size", Long.valueOf(this.size));
/*     */     
/* 183 */     return sb;
/*     */   }
/*     */   
/*     */   protected void addStringParameter(StringBuilder sb, String name, String p) {
/* 187 */     if (p != null)
/* 188 */       sb.append("; ").append(name).append("=\"").append(p).append("\"");
/*     */   }
/*     */   
/*     */   protected void addDateParameter(StringBuilder sb, String name, Date p) {
/* 192 */     if (p != null)
/* 193 */       sb.append("; ").append(name).append("=\"").append(HttpDateFormat.getPreferedDateFormat().format(p)).append("\"");
/*     */   }
/*     */   
/*     */   protected void addLongParameter(StringBuilder sb, String name, Long p) {
/* 197 */     if (p.longValue() != -1L) {
/* 198 */       sb.append("; ").append(name).append('=').append(Long.toString(p.longValue()));
/*     */     }
/*     */   }
/*     */   
/*     */   private void createParameters() throws ParseException {
/* 203 */     this.fileName = ((String)this.parameters.get("filename"));
/*     */     
/* 205 */     this.creationDate = createDate("creation-date");
/*     */     
/* 207 */     this.modificationDate = createDate("modification-date");
/*     */     
/* 209 */     this.readDate = createDate("read-date");
/*     */     
/* 211 */     this.size = createLong("size");
/*     */   }
/*     */   
/*     */   private Date createDate(String name) throws ParseException {
/* 215 */     String value = (String)this.parameters.get(name);
/* 216 */     if (value == null)
/* 217 */       return null;
/* 218 */     return HttpDateFormat.getPreferedDateFormat().parse(value);
/*     */   }
/*     */   
/*     */   private long createLong(String name) throws ParseException {
/* 222 */     String value = (String)this.parameters.get(name);
/* 223 */     if (value == null)
/* 224 */       return -1L;
/*     */     try {
/* 226 */       return Long.valueOf(value).longValue();
/*     */     } catch (NumberFormatException e) {
/* 228 */       throw new ParseException("Error parsing size parameter of value, " + value, 0);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ContentDispositionBuilder type(String type)
/*     */   {
/* 239 */     return new ContentDispositionBuilder(type);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class ContentDispositionBuilder<T extends ContentDispositionBuilder, V extends ContentDisposition>
/*     */   {
/*     */     protected String type;
/*     */     
/*     */ 
/*     */     protected String fileName;
/*     */     
/*     */ 
/*     */     protected Date creationDate;
/*     */     
/*     */ 
/*     */     protected Date modificationDate;
/*     */     
/*     */     protected Date readDate;
/*     */     
/* 259 */     protected long size = -1L;
/*     */     
/*     */     ContentDispositionBuilder(String type) {
/* 262 */       this.type = type;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public T fileName(String fileName)
/*     */     {
/* 273 */       this.fileName = fileName;
/* 274 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public T creationDate(Date creationDate)
/*     */     {
/* 285 */       this.creationDate = creationDate;
/* 286 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public T modificationDate(Date modificationDate)
/*     */     {
/* 297 */       this.modificationDate = modificationDate;
/* 298 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public T readDate(Date readDate)
/*     */     {
/* 309 */       this.readDate = readDate;
/* 310 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public T size(long size)
/*     */     {
/* 320 */       this.size = size;
/* 321 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public V build()
/*     */     {
/* 330 */       ContentDisposition cd = new ContentDisposition(this.type, this.fileName, this.creationDate, this.modificationDate, this.readDate, this.size);
/* 331 */       return cd;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\header\ContentDisposition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */