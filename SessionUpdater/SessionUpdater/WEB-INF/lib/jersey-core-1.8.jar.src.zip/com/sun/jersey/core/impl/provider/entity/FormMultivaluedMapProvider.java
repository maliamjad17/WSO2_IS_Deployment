/*    */ package com.sun.jersey.core.impl.provider.entity;
/*    */ 
/*    */ import com.sun.jersey.core.util.MultivaluedMapImpl;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.ParameterizedType;
/*    */ import java.lang.reflect.Type;
/*    */ import javax.ws.rs.Consumes;
/*    */ import javax.ws.rs.Produces;
/*    */ import javax.ws.rs.core.MediaType;
/*    */ import javax.ws.rs.core.MultivaluedMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Produces({"application/x-www-form-urlencoded"})
/*    */ @Consumes({"application/x-www-form-urlencoded"})
/*    */ public final class FormMultivaluedMapProvider
/*    */   extends BaseFormProvider<MultivaluedMap<String, String>>
/*    */ {
/*    */   private final Type mapType;
/*    */   
/*    */   public FormMultivaluedMapProvider()
/*    */   {
/* 67 */     ParameterizedType iface = (ParameterizedType)getClass().getGenericSuperclass();
/* 68 */     this.mapType = iface.getActualTypeArguments()[0];
/*    */   }
/*    */   
/*    */   public boolean isReadable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType)
/*    */   {
/* 73 */     return (type == MultivaluedMap.class) && ((type == genericType) || (this.mapType.equals(genericType)));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public MultivaluedMap<String, String> readFrom(Class<MultivaluedMap<String, String>> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, String> httpHeaders, InputStream entityStream)
/*    */     throws IOException
/*    */   {
/* 84 */     return readFrom(new MultivaluedMapImpl(), mediaType, entityStream);
/*    */   }
/*    */   
/*    */   public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
/* 88 */     return MultivaluedMap.class.isAssignableFrom(type);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void writeTo(MultivaluedMap<String, String> t, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, OutputStream entityStream)
/*    */     throws IOException
/*    */   {
/* 99 */     writeTo(t, mediaType, entityStream);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\entity\FormMultivaluedMapProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */