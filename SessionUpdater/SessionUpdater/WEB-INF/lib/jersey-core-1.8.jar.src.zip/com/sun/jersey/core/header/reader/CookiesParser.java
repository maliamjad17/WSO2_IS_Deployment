/*     */ package com.sun.jersey.core.header.reader;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.ws.rs.core.Cookie;
/*     */ import javax.ws.rs.core.NewCookie;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CookiesParser
/*     */ {
/*     */   private static class MutableCookie
/*     */   {
/*     */     String name;
/*     */     String value;
/*  57 */     int version = 1;
/*  58 */     String path = null;
/*  59 */     String domain = null;
/*     */     
/*     */     public MutableCookie(String name, String value) {
/*  62 */       this.name = name;
/*  63 */       this.value = value;
/*     */     }
/*     */     
/*     */     public Cookie getImmutableCookie() {
/*  67 */       return new Cookie(this.name, this.value, this.path, this.domain, this.version);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Map<String, Cookie> parseCookies(String header) {
/*  72 */     String[] bites = header.split("[;,]");
/*  73 */     Map<String, Cookie> cookies = new LinkedHashMap();
/*  74 */     int version = 0;
/*  75 */     MutableCookie cookie = null;
/*  76 */     for (String bite : bites) {
/*  77 */       String[] crumbs = bite.split("=", 2);
/*  78 */       String name = crumbs.length > 0 ? crumbs[0].trim() : "";
/*  79 */       String value = crumbs.length > 1 ? crumbs[1].trim() : "";
/*  80 */       if ((value.startsWith("\"")) && (value.endsWith("\"")) && (value.length() > 1))
/*  81 */         value = value.substring(1, value.length() - 1);
/*  82 */       if (!name.startsWith("$")) {
/*  83 */         if (cookie != null) {
/*  84 */           cookies.put(cookie.name, cookie.getImmutableCookie());
/*     */         }
/*  86 */         cookie = new MutableCookie(name, value);
/*  87 */         cookie.version = version;
/*     */       }
/*  89 */       else if (name.startsWith("$Version")) {
/*  90 */         version = Integer.parseInt(value);
/*  91 */       } else if ((name.startsWith("$Path")) && (cookie != null)) {
/*  92 */         cookie.path = value;
/*  93 */       } else if ((name.startsWith("$Domain")) && (cookie != null)) {
/*  94 */         cookie.domain = value;
/*     */       } }
/*  96 */     if (cookie != null)
/*  97 */       cookies.put(cookie.name, cookie.getImmutableCookie());
/*  98 */     return cookies;
/*     */   }
/*     */   
/*     */   public static Cookie parseCookie(String header) {
/* 102 */     Map<String, Cookie> cookies = parseCookies(header);
/* 103 */     return (Cookie)((Map.Entry)cookies.entrySet().iterator().next()).getValue();
/*     */   }
/*     */   
/*     */   private static class MutableNewCookie {
/* 107 */     String name = null;
/* 108 */     String value = null;
/* 109 */     String path = null;
/* 110 */     String domain = null;
/* 111 */     int version = 1;
/* 112 */     String comment = null;
/* 113 */     int maxAge = -1;
/* 114 */     boolean secure = false;
/*     */     
/*     */     public MutableNewCookie(String name, String value) {
/* 117 */       this.name = name;
/* 118 */       this.value = value;
/*     */     }
/*     */     
/*     */     public NewCookie getImmutableNewCookie() {
/* 122 */       return new NewCookie(this.name, this.value, this.path, this.domain, this.version, this.comment, this.maxAge, this.secure);
/*     */     }
/*     */   }
/*     */   
/*     */   public static NewCookie parseNewCookie(String header) {
/* 127 */     String[] bites = header.split("[;,]");
/*     */     
/* 129 */     MutableNewCookie cookie = null;
/* 130 */     for (String bite : bites) {
/* 131 */       String[] crumbs = bite.split("=", 2);
/* 132 */       String name = crumbs.length > 0 ? crumbs[0].trim() : "";
/* 133 */       String value = crumbs.length > 1 ? crumbs[1].trim() : "";
/* 134 */       if ((value.startsWith("\"")) && (value.endsWith("\"")) && (value.length() > 1)) {
/* 135 */         value = value.substring(1, value.length() - 1);
/*     */       }
/* 137 */       if (cookie == null) {
/* 138 */         cookie = new MutableNewCookie(name, value);
/* 139 */       } else if (name.startsWith("Comment")) {
/* 140 */         cookie.comment = value;
/* 141 */       } else if (name.startsWith("Domain")) {
/* 142 */         cookie.domain = value;
/* 143 */       } else if (name.startsWith("Max-Age")) {
/* 144 */         cookie.maxAge = Integer.parseInt(value);
/* 145 */       } else if (name.startsWith("Path")) {
/* 146 */         cookie.path = value;
/* 147 */       } else if (name.startsWith("Secure")) {
/* 148 */         cookie.secure = true;
/* 149 */       } else if (name.startsWith("Version")) {
/* 150 */         cookie.version = Integer.parseInt(value);
/* 151 */       } else if (name.startsWith("Domain")) {
/* 152 */         cookie.domain = value;
/*     */       }
/*     */     }
/* 155 */     return cookie.getImmutableNewCookie();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\header\reader\CookiesParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */