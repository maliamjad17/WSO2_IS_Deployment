/*     */ package com.sun.jersey.core.osgi;
/*     */ 
/*     */ import com.sun.jersey.core.spi.scanning.PackageNamesScanner;
/*     */ import com.sun.jersey.core.spi.scanning.PackageNamesScanner.ResourcesProvider;
/*     */ import com.sun.jersey.core.spi.scanning.uri.BundleSchemeScanner;
/*     */ import com.sun.jersey.core.spi.scanning.uri.UriSchemeScanner;
/*     */ import com.sun.jersey.impl.SpiMessages;
/*     */ import com.sun.jersey.spi.service.ServiceConfigurationError;
/*     */ import com.sun.jersey.spi.service.ServiceFinder;
/*     */ import com.sun.jersey.spi.service.ServiceFinder.DefaultServiceIteratorProvider;
/*     */ import com.sun.jersey.spi.service.ServiceFinder.ServiceIteratorProvider;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleActivator;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleEvent;
/*     */ import org.osgi.framework.SynchronousBundleListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Activator
/*     */   implements BundleActivator, SynchronousBundleListener
/*     */ {
/*  51 */   private static final Logger LOGGER = Logger.getLogger(Activator.class.getName());
/*     */   private BundleContext bundleContext;
/*     */   private ConcurrentMap<Long, Map<String, Callable<List<Class>>>> factories;
/*     */   
/*  55 */   public Activator() { this.factories = new ConcurrentHashMap(); }
/*     */   
/*     */   private static final class OsgiServiceFinder<T> extends ServiceFinder.ServiceIteratorProvider<T>
/*     */   {
/*  59 */     static final ServiceFinder.ServiceIteratorProvider defaultIterator = new ServiceFinder.DefaultServiceIteratorProvider();
/*     */     
/*     */     public Iterator<T> createIterator(final Class<T> serviceClass, final String serviceName, ClassLoader loader, boolean ignoreOnClassNotFound)
/*     */     {
/*  63 */       final List<Class> providerClasses = OsgiLocator.locateAll(serviceName);
/*  64 */       if (!providerClasses.isEmpty()) {
/*  65 */         new Iterator()
/*     */         {
/*  67 */           Iterator<Class> it = providerClasses.iterator();
/*     */           
/*     */           public boolean hasNext()
/*     */           {
/*  71 */             return this.it.hasNext();
/*     */           }
/*     */           
/*     */           public T next()
/*     */           {
/*  76 */             Class<T> nextClass = (Class)this.it.next();
/*     */             try {
/*  78 */               return (T)serviceClass.cast(nextClass.newInstance());
/*     */             } catch (Exception ex) {
/*  80 */               ServiceConfigurationError sce = new ServiceConfigurationError(serviceName + ": " + SpiMessages.PROVIDER_COULD_NOT_BE_CREATED(nextClass.getName(), serviceClass, ex.getLocalizedMessage()));
/*     */               
/*  82 */               sce.initCause(ex);
/*  83 */               throw sce;
/*     */             }
/*     */           }
/*     */           
/*     */           public void remove()
/*     */           {
/*  89 */             throw new UnsupportedOperationException();
/*     */           }
/*     */         };
/*     */       }
/*  93 */       return defaultIterator.createIterator(serviceClass, serviceName, loader, ignoreOnClassNotFound);
/*     */     }
/*     */     
/*     */     public Iterator<Class<T>> createClassIterator(Class<T> service, String serviceName, ClassLoader loader, boolean ignoreOnClassNotFound)
/*     */     {
/*  98 */       final List<Class> providerClasses = OsgiLocator.locateAll(serviceName);
/*  99 */       if (!providerClasses.isEmpty()) {
/* 100 */         new Iterator()
/*     */         {
/* 102 */           Iterator<Class> it = providerClasses.iterator();
/*     */           
/*     */           public boolean hasNext()
/*     */           {
/* 106 */             return this.it.hasNext();
/*     */           }
/*     */           
/*     */ 
/*     */           public Class<T> next()
/*     */           {
/* 112 */             return (Class)this.it.next();
/*     */           }
/*     */           
/*     */           public void remove()
/*     */           {
/* 117 */             throw new UnsupportedOperationException();
/*     */           }
/*     */         };
/*     */       }
/* 121 */       return defaultIterator.createClassIterator(service, serviceName, loader, ignoreOnClassNotFound);
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void start(BundleContext bundleContext)
/*     */     throws Exception
/*     */   {
/* 128 */     LOGGER.log(Level.FINE, "Activating Jersey core bundle...");
/*     */     
/* 130 */     this.bundleContext = bundleContext;
/*     */     
/* 132 */     setOSGiPackageScannerResourceProvider();
/* 133 */     registerBundleSchemeScanner();
/* 134 */     setOSGiServiceFinderIteratorProvider();
/*     */     
/* 136 */     bundleContext.addBundleListener(this);
/* 137 */     registerExistingBundles();
/*     */     
/* 139 */     LOGGER.log(Level.FINE, "Jersey core bundle activated");
/*     */   }
/*     */   
/*     */   private void registerExistingBundles()
/*     */   {
/* 144 */     for (Bundle bundle : this.bundleContext.getBundles()) {
/* 145 */       if ((bundle.getState() == 4) || (bundle.getState() == 8) || (bundle.getState() == 32) || (bundle.getState() == 16))
/*     */       {
/* 147 */         register(bundle);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void setOSGiPackageScannerResourceProvider() {
/* 153 */     PackageNamesScanner.setResourcesProvider(new PackageNamesScanner.ResourcesProvider()
/*     */     {
/*     */       public Enumeration<URL> getResources(String name, ClassLoader cl) throws IOException
/*     */       {
/* 157 */         List<URL> result = new LinkedList();
/* 158 */         for (Bundle b : Activator.this.bundleContext.getBundles()) {
/* 159 */           Enumeration<URL> e = b.findEntries(name, "*", false);
/* 160 */           if (e != null) {
/* 161 */             result.addAll(Collections.list(e));
/*     */           }
/*     */         }
/* 164 */         return Collections.enumeration(result);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private void setOSGiServiceFinderIteratorProvider() {
/* 170 */     ServiceFinder.setIteratorProvider(new OsgiServiceFinder(null));
/*     */   }
/*     */   
/*     */   private void registerBundleSchemeScanner() {
/* 174 */     OsgiLocator.register(UriSchemeScanner.class.getName(), new Callable()
/*     */     {
/*     */       public List<Class> call() throws Exception {
/* 177 */         List<Class> result = new LinkedList();
/* 178 */         result.add(BundleSchemeScanner.class);
/* 179 */         return result;
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public synchronized void stop(BundleContext bundleContext) throws Exception
/*     */   {
/* 186 */     LOGGER.log(Level.FINE, "Deactivating Jersey core bundle...");
/*     */     
/* 188 */     bundleContext.removeBundleListener(this);
/* 189 */     while (!this.factories.isEmpty()) {
/* 190 */       unregister(((Long)this.factories.keySet().iterator().next()).longValue());
/*     */     }
/* 192 */     LOGGER.log(Level.FINE, "Jersey core bundle deactivated");
/* 193 */     this.bundleContext = null;
/*     */   }
/*     */   
/*     */   public void bundleChanged(BundleEvent event)
/*     */   {
/* 198 */     if (event.getType() == 32) {
/* 199 */       register(event.getBundle());
/* 200 */     } else if ((event.getType() == 64) || (event.getType() == 16)) {
/* 201 */       unregister(event.getBundle().getBundleId());
/*     */     }
/*     */   }
/*     */   
/*     */   protected void register(Bundle bundle) {
/* 206 */     if (LOGGER.isLoggable(Level.FINEST)) {
/* 207 */       LOGGER.log(Level.FINEST, "checking bundle " + bundle.getBundleId());
/*     */     }
/* 209 */     Map<String, Callable<List<Class>>> map = (Map)this.factories.get(Long.valueOf(bundle.getBundleId()));
/* 210 */     Enumeration e = bundle.findEntries("META-INF/services/", "*", false);
/* 211 */     if (e != null)
/* 212 */       while (e.hasMoreElements()) {
/* 213 */         URL u = (URL)e.nextElement();
/* 214 */         String url = u.toString();
/* 215 */         if (!url.endsWith("/"))
/*     */         {
/*     */ 
/* 218 */           String factoryId = url.substring(url.lastIndexOf("/") + 1);
/* 219 */           if (map == null) {
/* 220 */             map = new HashMap();
/* 221 */             this.factories.put(Long.valueOf(bundle.getBundleId()), map);
/*     */           }
/* 223 */           map.put(factoryId, new BundleFactoryLoader(factoryId, u, bundle));
/*     */         }
/*     */       }
/* 226 */     if (map != null) {
/* 227 */       for (Map.Entry<String, Callable<List<Class>>> entry : map.entrySet()) {
/* 228 */         if (LOGGER.isLoggable(Level.FINEST)) {
/* 229 */           LOGGER.log(Level.FINEST, "registering service for key " + (String)entry.getKey() + "with value " + entry.getValue());
/*     */         }
/* 231 */         OsgiLocator.register((String)entry.getKey(), (Callable)entry.getValue());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void unregister(long bundleId) {
/* 237 */     Map<String, Callable<List<Class>>> map = (Map)this.factories.remove(Long.valueOf(bundleId));
/* 238 */     if (map != null) {
/* 239 */       for (Map.Entry<String, Callable<List<Class>>> entry : map.entrySet()) {
/* 240 */         if (LOGGER.isLoggable(Level.FINEST)) {
/* 241 */           LOGGER.log(Level.FINEST, "unregistering service for key " + (String)entry.getKey() + "with value " + entry.getValue());
/*     */         }
/* 243 */         OsgiLocator.unregister((String)entry.getKey(), (Callable)entry.getValue());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private class BundleFactoryLoader implements Callable<List<Class>>
/*     */   {
/*     */     private final String factoryId;
/*     */     private final URL u;
/*     */     private final Bundle bundle;
/*     */     
/*     */     public BundleFactoryLoader(String factoryId, URL u, Bundle bundle) {
/* 255 */       this.factoryId = factoryId;
/* 256 */       this.u = u;
/* 257 */       this.bundle = bundle;
/*     */     }
/*     */     
/*     */     public List<Class> call() throws Exception
/*     */     {
/*     */       try {
/* 263 */         if (Activator.LOGGER.isLoggable(Level.FINEST)) {
/* 264 */           Activator.LOGGER.log(Level.FINEST, "creating factories for key: " + this.factoryId);
/*     */         }
/* 266 */         BufferedReader br = new BufferedReader(new InputStreamReader(this.u.openStream(), "UTF-8"));
/*     */         
/* 268 */         List<Class> factoryClasses = new ArrayList();
/* 269 */         String factoryClassName; while ((factoryClassName = br.readLine()) != null)
/* 270 */           if (factoryClassName.trim().length() != 0)
/*     */           {
/*     */ 
/* 273 */             if (Activator.LOGGER.isLoggable(Level.FINEST)) {
/* 274 */               Activator.LOGGER.log(Level.FINEST, "factory implementation: " + factoryClassName);
/*     */             }
/* 276 */             factoryClasses.add(this.bundle.loadClass(factoryClassName));
/*     */           }
/* 278 */         br.close();
/* 279 */         return factoryClasses;
/*     */       } catch (Exception e) {
/* 281 */         Activator.LOGGER.log(Level.WARNING, "exception caught while creating factories: " + e);
/* 282 */         throw e;
/*     */       } catch (Error e) {
/* 284 */         Activator.LOGGER.log(Level.WARNING, "error caught while creating factories: " + e);
/* 285 */         throw e;
/*     */       }
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 291 */       return this.u.toString();
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 296 */       return this.u.hashCode();
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj)
/*     */     {
/* 301 */       if ((obj instanceof BundleFactoryLoader)) {
/* 302 */         return this.u.equals(((BundleFactoryLoader)obj).u);
/*     */       }
/* 304 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\osgi\Activator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */