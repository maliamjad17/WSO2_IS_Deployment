/*    */ package com.sun.jersey.core.header;
/*    */ 
/*    */ import com.sun.jersey.core.header.reader.HttpHeaderReader;
/*    */ import java.text.ParseException;
/*    */ import java.util.Map;
/*    */ import javax.ws.rs.core.MediaType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AcceptableMediaType
/*    */   extends MediaType
/*    */   implements QualityFactor
/*    */ {
/*    */   private final int q;
/*    */   
/*    */   public AcceptableMediaType(String p, String s)
/*    */   {
/* 57 */     super(p, s);
/* 58 */     this.q = 1000;
/*    */   }
/*    */   
/*    */   public AcceptableMediaType(String p, String s, int q, Map<String, String> parameters) {
/* 62 */     super(p, s, parameters);
/* 63 */     this.q = q;
/*    */   }
/*    */   
/*    */   public int getQuality() {
/* 67 */     return this.q;
/*    */   }
/*    */   
/*    */   public static AcceptableMediaType valueOf(HttpHeaderReader reader) throws ParseException
/*    */   {
/* 72 */     reader.hasNext();
/*    */     
/*    */ 
/* 75 */     String type = reader.nextToken();
/* 76 */     String subType = "*";
/*    */     
/* 78 */     if (reader.hasNextSeparator('/', false)) {
/* 79 */       reader.next(false);
/*    */       
/* 81 */       subType = reader.nextToken();
/*    */     }
/*    */     
/* 84 */     Map<String, String> parameters = null;
/* 85 */     int quality = 1000;
/* 86 */     if (reader.hasNext()) {
/* 87 */       parameters = HttpHeaderReader.readParameters(reader);
/* 88 */       if (parameters != null) {
/* 89 */         String v = (String)parameters.get("q");
/* 90 */         if (v != null) {
/* 91 */           quality = HttpHeaderReader.readQualityFactor(v);
/*    */         }
/*    */       }
/*    */     }
/* 95 */     return new AcceptableMediaType(type, subType, quality, parameters);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\header\AcceptableMediaType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */