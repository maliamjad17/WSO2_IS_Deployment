/*    */ package com.sun.jersey.core.impl.provider.header;
/*    */ 
/*    */ import com.sun.jersey.core.header.reader.HttpHeaderReader;
/*    */ import com.sun.jersey.core.header.reader.HttpHeaderReader.Event;
/*    */ import com.sun.jersey.spi.HeaderDelegateProvider;
/*    */ import java.text.ParseException;
/*    */ import javax.ws.rs.core.EntityTag;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityTagProvider
/*    */   implements HeaderDelegateProvider<EntityTag>
/*    */ {
/*    */   public boolean supports(Class<?> type)
/*    */   {
/* 56 */     return type == EntityTag.class;
/*    */   }
/*    */   
/*    */   public String toString(EntityTag header) {
/* 60 */     StringBuilder b = new StringBuilder();
/* 61 */     if (header.isWeak())
/* 62 */       b.append("W/");
/* 63 */     WriterUtil.appendQuoted(b, header.getValue());
/* 64 */     return b.toString();
/*    */   }
/*    */   
/*    */   public EntityTag fromString(String header) {
/* 68 */     if (header == null) {
/* 69 */       throw new IllegalArgumentException("Entity tag is null");
/*    */     }
/*    */     try {
/* 72 */       HttpHeaderReader reader = HttpHeaderReader.newInstance(header);
/* 73 */       HttpHeaderReader.Event e = reader.next(false);
/* 74 */       if (e == HttpHeaderReader.Event.QuotedString)
/* 75 */         return new EntityTag(reader.getEventValue());
/* 76 */       if ((e == HttpHeaderReader.Event.Token) && 
/* 77 */         (reader.getEventValue().equals("W"))) {
/* 78 */         reader.nextSeparator('/');
/* 79 */         return new EntityTag(reader.nextQuotedString(), true);
/*    */       }
/*    */     }
/*    */     catch (ParseException ex) {
/* 83 */       throw new IllegalArgumentException("Error parsing entity tag '" + header + "'", ex);
/*    */     }
/*    */     
/*    */ 
/* 87 */     throw new IllegalArgumentException("Error parsing entity tag '" + header + "'");
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\header\EntityTagProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */