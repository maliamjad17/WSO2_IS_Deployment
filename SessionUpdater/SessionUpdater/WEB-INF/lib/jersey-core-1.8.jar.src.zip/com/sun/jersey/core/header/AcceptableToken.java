/*    */ package com.sun.jersey.core.header;
/*    */ 
/*    */ import com.sun.jersey.core.header.reader.HttpHeaderReader;
/*    */ import java.text.ParseException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AcceptableToken
/*    */   extends Token
/*    */   implements QualityFactor
/*    */ {
/* 52 */   protected int quality = 1000;
/*    */   
/*    */   public AcceptableToken(String header) throws ParseException {
/* 55 */     this(HttpHeaderReader.newInstance(header));
/*    */   }
/*    */   
/*    */   public AcceptableToken(HttpHeaderReader reader) throws ParseException
/*    */   {
/* 60 */     reader.hasNext();
/*    */     
/* 62 */     this.token = reader.nextToken();
/*    */     
/* 64 */     if (reader.hasNext()) {
/* 65 */       this.quality = HttpHeaderReader.readQualityFactorParameter(reader);
/*    */     }
/*    */   }
/*    */   
/*    */   public int getQuality() {
/* 70 */     return this.quality;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\header\AcceptableToken.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */