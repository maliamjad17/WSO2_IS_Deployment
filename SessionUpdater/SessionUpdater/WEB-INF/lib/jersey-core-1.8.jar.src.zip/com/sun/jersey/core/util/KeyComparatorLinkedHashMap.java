/*     */ package com.sun.jersey.core.util;
/*     */ 
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyComparatorLinkedHashMap<K, V>
/*     */   extends KeyComparatorHashMap<K, V>
/*     */   implements Map<K, V>
/*     */ {
/*     */   private static final long serialVersionUID = 3801124242820219131L;
/*     */   private transient Entry<K, V> header;
/*     */   private final boolean accessOrder;
/*     */   
/*     */   public KeyComparatorLinkedHashMap(int initialCapacity, float loadFactor, KeyComparator<K> keyComparator)
/*     */   {
/*  81 */     super(initialCapacity, loadFactor, keyComparator);
/*  82 */     this.accessOrder = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyComparatorLinkedHashMap(int initialCapacity, KeyComparator<K> keyComparator)
/*     */   {
/*  94 */     super(initialCapacity, keyComparator);
/*  95 */     this.accessOrder = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyComparatorLinkedHashMap(KeyComparator<K> keyComparator)
/*     */   {
/* 103 */     super(keyComparator);
/* 104 */     this.accessOrder = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyComparatorLinkedHashMap(Map<? extends K, ? extends V> m, KeyComparator<K> keyComparator)
/*     */   {
/* 118 */     super(m, keyComparator);
/* 119 */     this.accessOrder = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyComparatorLinkedHashMap(int initialCapacity, float loadFactor, boolean accessOrder, KeyComparator<K> keyComparator)
/*     */   {
/* 136 */     super(initialCapacity, loadFactor, keyComparator);
/* 137 */     this.accessOrder = accessOrder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void init()
/*     */   {
/* 147 */     this.header = new Entry(-1, null, null, null);
/* 148 */     this.header.before = (this.header.after = this.header);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void transfer(KeyComparatorHashMap.Entry[] newTable)
/*     */   {
/* 158 */     int newCapacity = newTable.length;
/* 159 */     for (Entry<K, V> e = this.header.after; e != this.header; e = e.after) {
/* 160 */       int index = indexFor(e.hash, newCapacity);
/* 161 */       e.next = newTable[index];
/* 162 */       newTable[index] = e;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsValue(Object value)
/*     */   {
/* 177 */     if (value == null) {
/* 178 */       for (Entry e = this.header.after; e != this.header; e = e.after) {
/* 179 */         if (e.value == null) {
/* 180 */           return true;
/*     */         }
/*     */       }
/*     */     } else {
/* 184 */       for (Entry e = this.header.after; e != this.header; e = e.after) {
/* 185 */         if (value.equals(e.value)) {
/* 186 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 190 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public V get(Object key)
/*     */   {
/* 210 */     Entry<K, V> e = (Entry)getEntry(key);
/* 211 */     if (e == null) {
/* 212 */       return null;
/*     */     }
/* 214 */     e.recordAccess(this);
/* 215 */     return (V)e.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 224 */     super.clear();
/* 225 */     this.header.before = (this.header.after = this.header);
/*     */   }
/*     */   
/*     */ 
/*     */   private static class Entry<K, V>
/*     */     extends KeyComparatorHashMap.Entry<K, V>
/*     */   {
/*     */     Entry<K, V> before;
/*     */     Entry<K, V> after;
/*     */     
/*     */     Entry(int hash, K key, V value, KeyComparatorHashMap.Entry<K, V> next)
/*     */     {
/* 237 */       super(key, value, next);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private void remove()
/*     */     {
/* 244 */       this.before.after = this.after;
/* 245 */       this.after.before = this.before;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private void addBefore(Entry<K, V> existingEntry)
/*     */     {
/* 252 */       this.after = existingEntry;
/* 253 */       this.before = existingEntry.before;
/* 254 */       this.before.after = this;
/* 255 */       this.after.before = this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     void recordAccess(KeyComparatorHashMap<K, V> m)
/*     */     {
/* 266 */       KeyComparatorLinkedHashMap<K, V> lm = (KeyComparatorLinkedHashMap)m;
/* 267 */       if (lm.accessOrder) {
/* 268 */         lm.modCount += 1;
/* 269 */         remove();
/* 270 */         addBefore(lm.header);
/*     */       }
/*     */     }
/*     */     
/*     */     void recordRemoval(KeyComparatorHashMap<K, V> m)
/*     */     {
/* 276 */       remove();
/*     */     }
/*     */   }
/*     */   
/*     */   private abstract class LinkedHashIterator<T> implements Iterator<T>
/*     */   {
/* 282 */     KeyComparatorLinkedHashMap.Entry<K, V> nextEntry = KeyComparatorLinkedHashMap.this.header.after;
/* 283 */     KeyComparatorLinkedHashMap.Entry<K, V> lastReturned = null;
/*     */     
/*     */ 
/*     */     private LinkedHashIterator() {}
/*     */     
/*     */ 
/* 289 */     int expectedModCount = KeyComparatorLinkedHashMap.this.modCount;
/*     */     
/*     */     public boolean hasNext() {
/* 292 */       return this.nextEntry != KeyComparatorLinkedHashMap.this.header; }
/*     */     
/*     */     public void remove()
/*     */     {
/* 296 */       if (this.lastReturned == null) {
/* 297 */         throw new IllegalStateException();
/*     */       }
/* 299 */       if (KeyComparatorLinkedHashMap.this.modCount != this.expectedModCount) {
/* 300 */         throw new ConcurrentModificationException();
/*     */       }
/*     */       
/* 303 */       KeyComparatorLinkedHashMap.this.remove(this.lastReturned.key);
/* 304 */       this.lastReturned = null;
/* 305 */       this.expectedModCount = KeyComparatorLinkedHashMap.this.modCount;
/*     */     }
/*     */     
/*     */     KeyComparatorLinkedHashMap.Entry<K, V> nextEntry() {
/* 309 */       if (KeyComparatorLinkedHashMap.this.modCount != this.expectedModCount) {
/* 310 */         throw new ConcurrentModificationException();
/*     */       }
/* 312 */       if (this.nextEntry == KeyComparatorLinkedHashMap.this.header) {
/* 313 */         throw new NoSuchElementException();
/*     */       }
/*     */       
/* 316 */       KeyComparatorLinkedHashMap.Entry<K, V> e = this.lastReturned = this.nextEntry;
/* 317 */       this.nextEntry = e.after;
/* 318 */       return e;
/*     */     }
/*     */   }
/*     */   
/* 322 */   private class KeyIterator extends KeyComparatorLinkedHashMap<K, V>.LinkedHashIterator<K> { private KeyIterator() { super(null); }
/*     */     
/*     */ 
/* 325 */     public K next() { return (K)nextEntry().getKey(); }
/*     */   }
/*     */   
/*     */   private class ValueIterator extends KeyComparatorLinkedHashMap<K, V>.LinkedHashIterator<V> {
/* 329 */     private ValueIterator() { super(null); }
/*     */     
/*     */ 
/* 332 */     public V next() { return (V)nextEntry().value; }
/*     */   }
/*     */   
/*     */   private class EntryIterator extends KeyComparatorLinkedHashMap<K, V>.LinkedHashIterator<Map.Entry<K, V>> {
/* 336 */     private EntryIterator() { super(null); }
/*     */     
/*     */     public Map.Entry<K, V> next() {
/* 339 */       return nextEntry();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   Iterator<K> newKeyIterator()
/*     */   {
/* 346 */     return new KeyIterator(null);
/*     */   }
/*     */   
/*     */   Iterator<V> newValueIterator()
/*     */   {
/* 351 */     return new ValueIterator(null);
/*     */   }
/*     */   
/*     */   Iterator<Map.Entry<K, V>> newEntryIterator()
/*     */   {
/* 356 */     return new EntryIterator(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void addEntry(int hash, K key, V value, int bucketIndex)
/*     */   {
/* 366 */     createEntry(hash, key, value, bucketIndex);
/*     */     
/*     */ 
/* 369 */     Entry<K, V> eldest = this.header.after;
/* 370 */     if (removeEldestEntry(eldest)) {
/* 371 */       removeEntryForKey(eldest.key);
/*     */     }
/* 373 */     else if (this.size >= this.threshold) {
/* 374 */       resize(2 * this.table.length);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void createEntry(int hash, K key, V value, int bucketIndex)
/*     */   {
/* 385 */     KeyComparatorHashMap.Entry<K, V> old = this.table[bucketIndex];
/* 386 */     Entry<K, V> e = new Entry(hash, key, value, old);
/* 387 */     this.table[bucketIndex] = e;
/* 388 */     e.addBefore(this.header);
/* 389 */     this.size += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean removeEldestEntry(Map.Entry<K, V> eldest)
/*     */   {
/* 434 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\util\KeyComparatorLinkedHashMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */