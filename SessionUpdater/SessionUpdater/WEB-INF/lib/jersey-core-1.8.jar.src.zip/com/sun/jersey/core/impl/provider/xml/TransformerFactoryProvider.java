/*    */ package com.sun.jersey.core.impl.provider.xml;
/*    */ 
/*    */ import com.sun.jersey.core.util.FeaturesAndProperties;
/*    */ import javax.ws.rs.core.Context;
/*    */ import javax.xml.transform.TransformerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransformerFactoryProvider
/*    */   extends ThreadLocalSingletonContextProvider<TransformerFactory>
/*    */ {
/*    */   private final boolean disableXmlSecurity;
/*    */   
/*    */   public TransformerFactoryProvider(@Context FeaturesAndProperties fps)
/*    */   {
/* 55 */     super(TransformerFactory.class);
/*    */     
/* 57 */     this.disableXmlSecurity = fps.getFeature("com.sun.jersey.config.feature.DisableXmlSecurity");
/*    */   }
/*    */   
/*    */   protected TransformerFactory getInstance()
/*    */   {
/* 62 */     TransformerFactory f = TransformerFactory.newInstance();
/*    */     
/* 64 */     if (!this.disableXmlSecurity) {}
/*    */     
/*    */ 
/*    */ 
/* 68 */     return f;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\xml\TransformerFactoryProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */