/*     */ package com.sun.jersey.core.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringKeyIgnoreCaseMultivaluedMap<V>
/*     */   extends KeyComparatorLinkedHashMap<String, List<V>>
/*     */   implements MultivaluedMap<String, V>
/*     */ {
/*     */   public StringKeyIgnoreCaseMultivaluedMap()
/*     */   {
/*  61 */     super(StringIgnoreCaseKeyComparator.SINGLETON);
/*     */   }
/*     */   
/*     */   public StringKeyIgnoreCaseMultivaluedMap(StringKeyIgnoreCaseMultivaluedMap<V> that) {
/*  65 */     super(StringIgnoreCaseKeyComparator.SINGLETON);
/*  66 */     for (Map.Entry<String, List<V>> e : that.entrySet()) {
/*  67 */       put(e.getKey(), new ArrayList((Collection)e.getValue()));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void putSingle(String key, V value)
/*     */   {
/*  74 */     if (value == null) {
/*  75 */       return;
/*     */     }
/*  77 */     List<V> l = getList(key);
/*  78 */     l.clear();
/*  79 */     l.add(value);
/*     */   }
/*     */   
/*     */   public void add(String key, V value) {
/*  83 */     if (value == null) {
/*  84 */       return;
/*     */     }
/*  86 */     List<V> l = getList(key);
/*  87 */     l.add(value);
/*     */   }
/*     */   
/*     */   public V getFirst(String key) {
/*  91 */     List<V> values = (List)get(key);
/*  92 */     if ((values != null) && (values.size() > 0)) {
/*  93 */       return (V)values.get(0);
/*     */     }
/*  95 */     return null;
/*     */   }
/*     */   
/*     */   protected List<V> getList(String key) {
/*  99 */     List<V> l = (List)get(key);
/* 100 */     if (l == null) {
/* 101 */       l = new LinkedList();
/* 102 */       put(key, l);
/*     */     }
/* 104 */     return l;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\util\StringKeyIgnoreCaseMultivaluedMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */