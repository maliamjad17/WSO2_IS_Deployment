/*     */ package com.sun.jersey.core.impl.provider.entity;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Inflector
/*     */ {
/*     */   private Inflector()
/*     */   {
/*  82 */     addPlural("$", "s", false);
/*  83 */     addPlural("(.*)$", "\\1s");
/*  84 */     addPlural("(.*)(ax|test)is$", "\\1\\2es");
/*  85 */     addPlural("(.*)(octop|vir)us$", "\\1\\2i");
/*  86 */     addPlural("(.*)(alias|status)$", "\\1\\2es");
/*  87 */     addPlural("(.*)(bu)s$", "\\1\\2ses");
/*  88 */     addPlural("(.*)(buffal|tomat)o$", "\\1\\2oes");
/*  89 */     addPlural("(.*)([ti])um$", "\\1\\2a");
/*  90 */     addPlural("(.*)sis$", "\\1ses");
/*  91 */     addPlural("(.*)(?:([^f])fe|([lr])f)$", "\\1\\3ves");
/*  92 */     addPlural("(.*)(hive)$", "\\1\\2s");
/*  93 */     addPlural("(.*)(tive)$", "\\1\\2s");
/*  94 */     addPlural("(.*)([^aeiouy]|qu)y$", "\\1\\2ies");
/*  95 */     addPlural("(.*)(series)$", "\\1\\2");
/*  96 */     addPlural("(.*)(movie)$", "\\1\\2s");
/*  97 */     addPlural("(.*)(x|ch|ss|sh)$", "\\1\\2es");
/*  98 */     addPlural("(.*)(matr|vert|ind)ix|ex$", "\\1\\2ices");
/*  99 */     addPlural("(.*)(o)$", "\\1\\2es");
/* 100 */     addPlural("(.*)(shoe)$", "\\1\\2s");
/* 101 */     addPlural("(.*)([m|l])ouse$", "\\1\\2ice");
/* 102 */     addPlural("^(ox)$", "\\1en");
/* 103 */     addPlural("(.*)(vert|ind)ex$", "\\1\\2ices");
/* 104 */     addPlural("(.*)(matr)ix$", "\\1\\2ices");
/* 105 */     addPlural("(.*)(quiz)$", "\\1\\2zes");
/*     */     
/* 107 */     addSingular("(.*)s$", "\\1");
/* 108 */     addSingular("(.*)(n)ews$", "\\1\\2ews");
/* 109 */     addSingular("(.*)([ti])a$", "\\1\\2um");
/* 110 */     addSingular("(.*)((a)naly|(b)a|(d)iagno|(p)arenthe|(p)rogno|(s)ynop|(t)he)ses$", "\\1\\2sis");
/* 111 */     addSingular("(.*)(^analy)ses$", "\\1\\2sis");
/* 112 */     addSingular("(.*)([^f])ves$", "\\1\\2fe");
/* 113 */     addSingular("(.*)(hive)s$", "\\1\\2");
/* 114 */     addSingular("(.*)(tive)s$", "\\1\\2");
/* 115 */     addSingular("(.*)([lr])ves$", "\\1\\2f");
/* 116 */     addSingular("(.*)([^aeiouy]|qu)ies$", "\\1\\2y");
/* 117 */     addSingular("(.*)(s)eries$", "\\1\\2eries");
/* 118 */     addSingular("(.*)(m)ovies$", "\\1\\2ovie");
/* 119 */     addSingular("(.*)(x|ch|ss|sh)es$", "\\1\\2");
/* 120 */     addSingular("(.*)([m|l])ice$", "\\1\\2ouse");
/* 121 */     addSingular("(.*)(bus)es$", "\\1\\2");
/* 122 */     addSingular("(.*)(o)es$", "\\1\\2");
/* 123 */     addSingular("(.*)(shoe)s$", "\\1\\2");
/* 124 */     addSingular("(.*)(cris|ax|test)es$", "\\1\\2is");
/* 125 */     addSingular("(.*)(octop|vir)i$", "\\1\\2us");
/* 126 */     addSingular("(.*)(alias|status)es$", "\\1\\2");
/* 127 */     addSingular("^(ox)en", "\\1");
/* 128 */     addSingular("(.*)(vert|ind)ices$", "\\1\\2ex");
/* 129 */     addSingular("(.*)(matr)ices$", "\\1\\2ix");
/* 130 */     addSingular("(.*)(quiz)zes$", "\\1\\2");
/*     */     
/* 132 */     addIrregular("child", "children");
/* 133 */     addIrregular("man", "men");
/* 134 */     addIrregular("move", "moves");
/* 135 */     addIrregular("person", "people");
/* 136 */     addIrregular("sex", "sexes");
/*     */     
/* 138 */     addUncountable("equipment");
/* 139 */     addUncountable("fish");
/* 140 */     addUncountable("information");
/* 141 */     addUncountable("money");
/* 142 */     addUncountable("rice");
/* 143 */     addUncountable("series");
/* 144 */     addUncountable("sheep");
/* 145 */     addUncountable("species");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 153 */   private static transient Inflector instance = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 158 */   private List<Replacer> plurals = new LinkedList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 163 */   private List<Replacer> singulars = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 168 */   private List uncountables = new LinkedList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Inflector getInstance()
/*     */   {
/* 179 */     if (instance == null) {
/* 180 */       instance = new Inflector();
/*     */     }
/* 182 */     return instance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String camelize(String word)
/*     */   {
/* 196 */     return camelize(word, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String camelize(String word, boolean flag)
/*     */   {
/* 240 */     if (word.length() == 0) {
/* 241 */       return word;
/*     */     }
/*     */     
/* 244 */     StringBuffer sb = new StringBuffer(word.length());
/* 245 */     if (flag) {
/* 246 */       sb.append(Character.toLowerCase(word.charAt(0)));
/*     */     } else {
/* 248 */       sb.append(Character.toUpperCase(word.charAt(0)));
/*     */     }
/* 250 */     boolean capitalize = false;
/* 251 */     for (int i = 1; i < word.length(); i++) {
/* 252 */       char ch = word.charAt(i);
/* 253 */       if (capitalize) {
/* 254 */         sb.append(Character.toUpperCase(ch));
/* 255 */         capitalize = false;
/* 256 */       } else if (ch == '_') {
/* 257 */         capitalize = true;
/* 258 */       } else if (ch == '/') {
/* 259 */         capitalize = true;
/* 260 */         sb.append('.');
/*     */       } else {
/* 262 */         sb.append(ch);
/*     */       }
/*     */     }
/* 265 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String classify(String tableName)
/*     */   {
/* 292 */     int period = tableName.lastIndexOf('.');
/* 293 */     if (period >= 0) {
/* 294 */       tableName = tableName.substring(period + 1);
/*     */     }
/* 296 */     return camelize(singularize(tableName));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String dasherize(String word)
/*     */   {
/* 322 */     return word.replace('_', '-');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String demodulize(String className)
/*     */   {
/* 349 */     int period = className.lastIndexOf('.');
/* 350 */     if (period >= 0) {
/* 351 */       return className.substring(period + 1);
/*     */     }
/* 353 */     return className;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String foreignKey(String className)
/*     */   {
/* 364 */     return foreignKey(className, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String foreignKey(String className, boolean underscore)
/*     */   {
/* 401 */     return underscore(demodulize(className) + (underscore ? "_id" : "id"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String humanize(String words)
/*     */   {
/* 430 */     if (words.endsWith("_id")) {
/* 431 */       words = words.substring(0, words.length() - 3);
/*     */     }
/* 433 */     StringBuffer sb = new StringBuffer(words.length());
/* 434 */     sb.append(Character.toUpperCase(words.charAt(0)));
/* 435 */     for (int i = 1; i < words.length(); i++) {
/* 436 */       char ch = words.charAt(i);
/* 437 */       if (ch == '_') {
/* 438 */         sb.append(' ');
/*     */       } else {
/* 440 */         sb.append(ch);
/*     */       }
/*     */     }
/* 443 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String ordinalize(int number)
/*     */   {
/* 486 */     int modulo = number % 100;
/* 487 */     if ((modulo >= 11) && (modulo <= 13)) {
/* 488 */       return "" + number + "th";
/*     */     }
/* 490 */     switch (number % 10) {
/*     */     case 1: 
/* 492 */       return "" + number + "st";
/*     */     case 2: 
/* 494 */       return "" + number + "nd";
/*     */     case 3: 
/* 496 */       return "" + number + "rd";
/*     */     }
/* 498 */     return "" + number + "th";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String pluralize(String word)
/*     */   {
/* 512 */     for (int i = 0; i < this.uncountables.size(); i++) {
/* 513 */       if (this.uncountables.get(i).equals(word)) {
/* 514 */         return word;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 519 */     for (int i = 0; i < this.plurals.size(); i++) {
/* 520 */       String replacement = ((Replacer)this.plurals.get(i)).replacement(word);
/* 521 */       if (replacement != null) {
/* 522 */         return replacement;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 527 */     return word;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String singularize(String word)
/*     */   {
/* 540 */     for (int i = 0; i < this.uncountables.size(); i++) {
/* 541 */       if (this.uncountables.get(i).equals(word)) {
/* 542 */         return word;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 547 */     for (int i = 0; i < this.singulars.size(); i++) {
/* 548 */       String replacement = ((Replacer)this.singulars.get(i)).replacement(word);
/* 549 */       if (replacement != null) {
/* 550 */         return replacement;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 555 */     return word;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String tableize(String className)
/*     */   {
/* 583 */     return pluralize(underscore(className));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String titleize(String words)
/*     */   {
/* 611 */     StringBuffer sb = new StringBuffer(words.length());
/* 612 */     boolean capitalize = true;
/* 613 */     for (int i = 0; i < words.length(); i++) {
/* 614 */       char ch = words.charAt(i);
/* 615 */       if (Character.isWhitespace(ch)) {
/* 616 */         sb.append(' ');
/* 617 */         capitalize = true;
/* 618 */       } else if (ch == '-') {
/* 619 */         sb.append(' ');
/* 620 */         capitalize = true;
/* 621 */       } else if (capitalize) {
/* 622 */         sb.append(Character.toUpperCase(ch));
/* 623 */         capitalize = false;
/*     */       } else {
/* 625 */         sb.append(ch);
/*     */       }
/*     */     }
/* 628 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   public String decapitalize(String word)
/*     */   {
/* 634 */     if ((word == null) || (word.length() < 1)) {
/* 635 */       return word;
/*     */     }
/*     */     
/* 638 */     char first = word.charAt(0);
/* 639 */     if (Character.isLowerCase(first)) {
/* 640 */       return word;
/*     */     }
/*     */     
/* 643 */     StringBuilder sb = new StringBuilder(word.length());
/* 644 */     sb.append(Character.toLowerCase(first));
/* 645 */     sb.append(word.substring(1));
/* 646 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String underscore(String word)
/*     */   {
/* 681 */     StringBuffer sb = new StringBuffer(word.length() + 5);
/* 682 */     boolean uncapitalize = false;
/* 683 */     for (int i = 0; i < word.length(); i++) {
/* 684 */       char ch = word.charAt(i);
/* 685 */       if (uncapitalize) {
/* 686 */         sb.append(Character.toLowerCase(ch));
/* 687 */         uncapitalize = false;
/* 688 */       } else if (ch == '.') {
/* 689 */         sb.append('/');
/* 690 */         uncapitalize = true;
/* 691 */       } else if (Character.isUpperCase(ch)) {
/* 692 */         if (i > 0) {
/* 693 */           sb.append('_');
/*     */         }
/* 695 */         sb.append(Character.toLowerCase(ch));
/*     */       } else {
/* 697 */         sb.append(ch);
/*     */       }
/*     */     }
/* 700 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addIrregular(String singular, String plural)
/*     */   {
/* 716 */     addPlural("(.*)(" + singular.substring(0, 1) + ")" + singular.substring(1) + "$", "\\1\\2" + plural.substring(1));
/*     */     
/* 718 */     addSingular("(.*)(" + plural.substring(0, 1) + ")" + plural.substring(1) + "$", "\\1\\2" + singular.substring(1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addPlural(String match, String rule)
/*     */   {
/* 734 */     addPlural(match, rule, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addPlural(String match, String rule, boolean insensitive)
/*     */   {
/* 749 */     this.plurals.add(0, new Replacer(match, rule, insensitive));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSingular(String match, String rule)
/*     */   {
/* 763 */     addSingular(match, rule, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSingular(String match, String rule, boolean insensitive)
/*     */   {
/* 778 */     this.singulars.add(0, new Replacer(match, rule, insensitive));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addUncountable(String word)
/*     */   {
/* 790 */     this.uncountables.add(0, word.toLowerCase());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private class Replacer
/*     */   {
/*     */     public Replacer(String match, String rule, boolean insensitive)
/*     */     {
/* 806 */       this.pattern = Pattern.compile(match, insensitive ? 2 : 0);
/*     */       
/* 808 */       this.rule = rule;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 813 */     private Pattern pattern = null;
/* 814 */     private String rule = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String replacement(String input)
/*     */     {
/* 826 */       Matcher matcher = this.pattern.matcher(input);
/* 827 */       if (matcher.matches()) {
/* 828 */         StringBuffer sb = new StringBuffer();
/* 829 */         boolean group = false;
/* 830 */         for (int i = 0; i < this.rule.length(); i++) {
/* 831 */           char ch = this.rule.charAt(i);
/* 832 */           if (group) {
/* 833 */             sb.append(matcher.group(Character.digit(ch, 10)));
/* 834 */             group = false;
/* 835 */           } else if (ch == '\\') {
/* 836 */             group = true;
/*     */           } else {
/* 838 */             sb.append(ch);
/*     */           }
/*     */         }
/* 841 */         return sb.toString();
/*     */       }
/* 843 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\entity\Inflector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */