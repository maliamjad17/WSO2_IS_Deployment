/*     */ package com.sun.jersey.core.util;
/*     */ 
/*     */ import com.sun.jersey.impl.ImplMessages;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyComparatorHashMap<K, V>
/*     */   extends AbstractMap<K, V>
/*     */   implements Map<K, V>, Cloneable, Serializable
/*     */ {
/*     */   static final int DEFAULT_INITIAL_CAPACITY = 16;
/*     */   static final int MAXIMUM_CAPACITY = 1073741824;
/*     */   static final float DEFAULT_LOAD_FACTOR = 0.75F;
/*     */   transient Entry<K, V>[] table;
/*     */   transient int size;
/*     */   int threshold;
/*     */   final float loadFactor;
/*     */   volatile transient int modCount;
/*     */   final KeyComparator<K> keyComparator;
/*     */   
/*     */   public int getDEFAULT_INITIAL_CAPACITY()
/*     */   {
/* 116 */     return 16;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyComparatorHashMap(int initialCapacity, float loadFactor, KeyComparator<K> keyComparator)
/*     */   {
/* 131 */     if (initialCapacity < 0)
/* 132 */       throw new IllegalArgumentException(ImplMessages.ILLEGAL_INITIAL_CAPACITY(Integer.valueOf(initialCapacity)));
/* 133 */     if (initialCapacity > 1073741824)
/* 134 */       initialCapacity = 1073741824;
/* 135 */     if ((loadFactor <= 0.0F) || (Float.isNaN(loadFactor))) {
/* 136 */       throw new IllegalArgumentException(ImplMessages.ILLEGAL_LOAD_FACTOR(Float.valueOf(loadFactor)));
/*     */     }
/*     */     
/* 139 */     int capacity = 1;
/* 140 */     while (capacity < initialCapacity) {
/* 141 */       capacity <<= 1;
/*     */     }
/* 143 */     this.loadFactor = loadFactor;
/* 144 */     this.threshold = ((int)(capacity * loadFactor));
/* 145 */     this.table = new Entry[capacity];
/* 146 */     init();
/*     */     
/* 148 */     this.keyComparator = keyComparator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyComparatorHashMap(int initialCapacity, KeyComparator<K> keyComparator)
/*     */   {
/* 159 */     this(initialCapacity, 0.75F, keyComparator);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyComparatorHashMap(KeyComparator<K> keyComparator)
/*     */   {
/* 167 */     this.loadFactor = 0.75F;
/* 168 */     this.threshold = 12;
/* 169 */     this.table = new Entry[16];
/* 170 */     init();
/*     */     
/* 172 */     this.keyComparator = keyComparator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyComparatorHashMap(Map<? extends K, ? extends V> m, KeyComparator<K> keyComparator)
/*     */   {
/* 186 */     this(Math.max((int)(m.size() / 0.75F) + 1, 16), 0.75F, keyComparator);
/*     */     
/* 188 */     putAllForCreate(m);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getModCount()
/*     */   {
/* 202 */     return this.modCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 220 */   static final Object NULL_KEY = new Object();
/*     */   
/*     */   void init() {}
/*     */   
/*     */   static <T> T maskNull(T key)
/*     */   {
/* 226 */     return (T)(key == null ? NULL_KEY : key);
/*     */   }
/*     */   
/*     */   static <T> boolean isNull(T key) {
/* 230 */     return key == NULL_KEY;
/*     */   }
/*     */   
/*     */ 
/*     */   static <T> T unmaskNull(T key)
/*     */   {
/* 236 */     return key == NULL_KEY ? null : key;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int hash(Object x)
/*     */   {
/* 250 */     int h = x.hashCode();
/*     */     
/* 252 */     h += (h << 9 ^ 0xFFFFFFFF);
/* 253 */     h ^= h >>> 14;
/* 254 */     h += (h << 4);
/* 255 */     h ^= h >>> 10;
/* 256 */     return h;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static boolean eq(Object x, Object y)
/*     */   {
/* 263 */     return (x == y) || (x.equals(y));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static int indexFor(int h, int length)
/*     */   {
/* 270 */     return h & length - 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int size()
/*     */   {
/* 280 */     return this.size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 290 */     return this.size == 0;
/*     */   }
/*     */   
/*     */   int keyComparatorHash(K k) {
/* 294 */     return isNull(k) ? hash(k.hashCode()) : hash(this.keyComparator.hash(k));
/*     */   }
/*     */   
/*     */ 
/*     */   int hash(int h)
/*     */   {
/* 300 */     h += (h << 9 ^ 0xFFFFFFFF);
/* 301 */     h ^= h >>> 14;
/* 302 */     h += (h << 4);
/* 303 */     h ^= h >>> 10;
/* 304 */     return h;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   boolean keyComparatorEq(K x, K y)
/*     */   {
/* 311 */     if (isNull(x))
/* 312 */       return x == y;
/* 313 */     if (isNull(y)) {
/* 314 */       return x == y;
/*     */     }
/* 316 */     return (x == y) || (this.keyComparator.equals(x, y));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public V get(Object key)
/*     */   {
/* 335 */     K k = maskNull(key);
/* 336 */     int hash = keyComparatorHash(k);
/* 337 */     int i = indexFor(hash, this.table.length);
/* 338 */     Entry<K, V> e = this.table[i];
/*     */     for (;;) {
/* 340 */       if (e == null)
/* 341 */         return null;
/* 342 */       if ((e.hash == hash) && (keyComparatorEq(k, e.key)))
/* 343 */         return (V)e.value;
/* 344 */       e = e.next;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsKey(Object key)
/*     */   {
/* 358 */     K k = maskNull(key);
/* 359 */     int hash = keyComparatorHash(k);
/* 360 */     int i = indexFor(hash, this.table.length);
/* 361 */     Entry<K, V> e = this.table[i];
/* 362 */     while (e != null) {
/* 363 */       if ((e.hash == hash) && (keyComparatorEq(k, e.key)))
/* 364 */         return true;
/* 365 */       e = e.next;
/*     */     }
/* 367 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Entry<K, V> getEntry(K key)
/*     */   {
/* 376 */     K k = maskNull(key);
/* 377 */     int hash = keyComparatorHash(k);
/* 378 */     int i = indexFor(hash, this.table.length);
/* 379 */     Entry<K, V> e = this.table[i];
/* 380 */     while ((e != null) && ((e.hash != hash) || (!keyComparatorEq(k, e.key))))
/* 381 */       e = e.next;
/* 382 */     return e;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public V put(K key, V value)
/*     */   {
/* 399 */     K k = maskNull(key);
/* 400 */     int hash = keyComparatorHash(k);
/* 401 */     int i = indexFor(hash, this.table.length);
/*     */     
/* 403 */     for (Entry<K, V> e = this.table[i]; e != null; e = e.next) {
/* 404 */       if ((e.hash == hash) && (keyComparatorEq(k, e.key))) {
/* 405 */         V oldValue = e.value;
/* 406 */         e.value = value;
/* 407 */         e.recordAccess(this);
/* 408 */         return oldValue;
/*     */       }
/*     */     }
/*     */     
/* 412 */     this.modCount += 1;
/* 413 */     addEntry(hash, k, value, i);
/* 414 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void putForCreate(K key, V value)
/*     */   {
/* 424 */     K k = maskNull(key);
/* 425 */     int hash = keyComparatorHash(k);
/* 426 */     int i = indexFor(hash, this.table.length);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 433 */     for (Entry<K, V> e = this.table[i]; e != null; e = e.next) {
/* 434 */       if ((e.hash == hash) && (keyComparatorEq(k, e.key))) {
/* 435 */         e.value = value;
/* 436 */         return;
/*     */       }
/*     */     }
/*     */     
/* 440 */     createEntry(hash, k, value, i);
/*     */   }
/*     */   
/*     */   void putAllForCreate(Map<? extends K, ? extends V> m) {
/* 444 */     for (Iterator<? extends Map.Entry<? extends K, ? extends V>> i = m.entrySet().iterator(); i.hasNext();) {
/* 445 */       Map.Entry<? extends K, ? extends V> e = (Map.Entry)i.next();
/* 446 */       putForCreate(e.getKey(), e.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void resize(int newCapacity)
/*     */   {
/* 465 */     Entry<K, V>[] oldTable = this.table;
/* 466 */     int oldCapacity = oldTable.length;
/* 467 */     if (oldCapacity == 1073741824) {
/* 468 */       this.threshold = Integer.MAX_VALUE;
/* 469 */       return;
/*     */     }
/*     */     
/* 472 */     Entry<K, V>[] newTable = new Entry[newCapacity];
/* 473 */     transfer(newTable);
/* 474 */     this.table = newTable;
/* 475 */     this.threshold = ((int)(newCapacity * this.loadFactor));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void transfer(Entry<K, V>[] newTable)
/*     */   {
/* 482 */     Entry<K, V>[] src = this.table;
/* 483 */     int newCapacity = newTable.length;
/* 484 */     for (int j = 0; j < src.length; j++) {
/* 485 */       Entry<K, V> e = src[j];
/* 486 */       if (e != null) {
/* 487 */         src[j] = null;
/*     */         do {
/* 489 */           Entry<K, V> next = e.next;
/* 490 */           int i = indexFor(e.hash, newCapacity);
/* 491 */           e.next = newTable[i];
/* 492 */           newTable[i] = e;
/* 493 */           e = next;
/* 494 */         } while (e != null);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void putAll(Map<? extends K, ? extends V> m)
/*     */   {
/* 509 */     int numKeysToBeAdded = m.size();
/* 510 */     if (numKeysToBeAdded == 0) {
/* 511 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 522 */     if (numKeysToBeAdded > this.threshold) {
/* 523 */       int targetCapacity = (int)(numKeysToBeAdded / this.loadFactor + 1.0F);
/* 524 */       if (targetCapacity > 1073741824)
/* 525 */         targetCapacity = 1073741824;
/* 526 */       int newCapacity = this.table.length;
/* 527 */       while (newCapacity < targetCapacity)
/* 528 */         newCapacity <<= 1;
/* 529 */       if (newCapacity > this.table.length) {
/* 530 */         resize(newCapacity);
/*     */       }
/*     */     }
/* 533 */     for (Iterator<? extends Map.Entry<? extends K, ? extends V>> i = m.entrySet().iterator(); i.hasNext();) {
/* 534 */       Map.Entry<? extends K, ? extends V> e = (Map.Entry)i.next();
/* 535 */       put(e.getKey(), e.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public V remove(Object key)
/*     */   {
/* 550 */     Entry<K, V> e = removeEntryForKey(key);
/* 551 */     return e == null ? null : e.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Entry<K, V> removeEntryForKey(Object key)
/*     */   {
/* 560 */     K k = maskNull(key);
/* 561 */     int hash = keyComparatorHash(k);
/* 562 */     int i = indexFor(hash, this.table.length);
/* 563 */     Entry<K, V> prev = this.table[i];
/* 564 */     Entry<K, V> e = prev;
/*     */     
/* 566 */     while (e != null) {
/* 567 */       Entry<K, V> next = e.next;
/* 568 */       if ((e.hash == hash) && (keyComparatorEq(k, e.key))) {
/* 569 */         this.modCount += 1;
/* 570 */         this.size -= 1;
/* 571 */         if (prev == e) {
/* 572 */           this.table[i] = next;
/*     */         } else
/* 574 */           prev.next = next;
/* 575 */         e.recordRemoval(this);
/* 576 */         return e;
/*     */       }
/* 578 */       prev = e;
/* 579 */       e = next;
/*     */     }
/*     */     
/* 582 */     return e;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   Entry<K, V> removeMapping(Object o)
/*     */   {
/* 589 */     if (!(o instanceof Map.Entry)) {
/* 590 */       return null;
/*     */     }
/* 592 */     Map.Entry<K, V> entry = (Map.Entry)o;
/* 593 */     K k = maskNull(entry.getKey());
/* 594 */     int hash = keyComparatorHash(k);
/* 595 */     int i = indexFor(hash, this.table.length);
/* 596 */     Entry<K, V> prev = this.table[i];
/* 597 */     Entry<K, V> e = prev;
/*     */     
/* 599 */     while (e != null) {
/* 600 */       Entry<K, V> next = e.next;
/* 601 */       if ((e.hash == hash) && (e.equals(entry))) {
/* 602 */         this.modCount += 1;
/* 603 */         this.size -= 1;
/* 604 */         if (prev == e) {
/* 605 */           this.table[i] = next;
/*     */         } else
/* 607 */           prev.next = next;
/* 608 */         e.recordRemoval(this);
/* 609 */         return e;
/*     */       }
/* 611 */       prev = e;
/* 612 */       e = next;
/*     */     }
/*     */     
/* 615 */     return e;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 623 */     this.modCount += 1;
/* 624 */     Entry[] tab = this.table;
/* 625 */     for (int i = 0; i < tab.length; i++)
/* 626 */       tab[i] = null;
/* 627 */     this.size = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsValue(Object value)
/*     */   {
/* 640 */     if (value == null) {
/* 641 */       return containsNullValue();
/*     */     }
/* 643 */     Entry[] tab = this.table;
/* 644 */     for (int i = 0; i < tab.length; i++)
/* 645 */       for (Entry e = tab[i]; e != null; e = e.next)
/* 646 */         if (value.equals(e.value))
/* 647 */           return true;
/* 648 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean containsNullValue()
/*     */   {
/* 655 */     Entry[] tab = this.table;
/* 656 */     for (int i = 0; i < tab.length; i++)
/* 657 */       for (Entry e = tab[i]; e != null; e = e.next)
/* 658 */         if (e.value == null)
/* 659 */           return true;
/* 660 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 671 */     KeyComparatorHashMap<K, V> result = null;
/*     */     try {
/* 673 */       result = (KeyComparatorHashMap)super.clone();
/*     */     }
/*     */     catch (CloneNotSupportedException e) {}
/*     */     
/* 677 */     result.table = new Entry[this.table.length];
/* 678 */     result.entrySet = null;
/* 679 */     result.modCount = 0;
/* 680 */     result.size = 0;
/* 681 */     result.init();
/* 682 */     result.putAllForCreate(this);
/*     */     
/* 684 */     return result;
/*     */   }
/*     */   
/*     */   static class Entry<K, V>
/*     */     implements Map.Entry<K, V>
/*     */   {
/*     */     final K key;
/*     */     V value;
/*     */     final int hash;
/*     */     Entry<K, V> next;
/*     */     
/*     */     Entry(int h, K k, V v, Entry<K, V> n)
/*     */     {
/* 697 */       this.value = v;
/* 698 */       this.next = n;
/* 699 */       this.key = k;
/* 700 */       this.hash = h;
/*     */     }
/*     */     
/*     */     public K getKey() {
/* 704 */       return (K)KeyComparatorHashMap.unmaskNull(this.key);
/*     */     }
/*     */     
/*     */     public V getValue() {
/* 708 */       return (V)this.value;
/*     */     }
/*     */     
/*     */     public V setValue(V newValue) {
/* 712 */       V oldValue = this.value;
/* 713 */       this.value = newValue;
/* 714 */       return oldValue;
/*     */     }
/*     */     
/*     */     public boolean equals(Object o)
/*     */     {
/* 719 */       if (!(o instanceof Map.Entry))
/* 720 */         return false;
/* 721 */       Map.Entry e = (Map.Entry)o;
/* 722 */       Object k1 = getKey();
/* 723 */       Object k2 = e.getKey();
/* 724 */       if ((k1 == k2) || ((k1 != null) && (k1.equals(k2)))) {
/* 725 */         Object v1 = getValue();
/* 726 */         Object v2 = e.getValue();
/* 727 */         if ((v1 == v2) || ((v1 != null) && (v1.equals(v2))))
/* 728 */           return true;
/*     */       }
/* 730 */       return false;
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 735 */       return (this.key == KeyComparatorHashMap.NULL_KEY ? 0 : this.key.hashCode()) ^ (this.value == null ? 0 : this.value.hashCode());
/*     */     }
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/* 741 */       return getKey() + "=" + getValue();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     void recordAccess(KeyComparatorHashMap<K, V> m) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     void recordRemoval(KeyComparatorHashMap<K, V> m) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void addEntry(int hash, K key, V value, int bucketIndex)
/*     */   {
/* 768 */     Entry<K, V> e = this.table[bucketIndex];
/* 769 */     this.table[bucketIndex] = new Entry(hash, key, value, e);
/* 770 */     if (this.size++ >= this.threshold) {
/* 771 */       resize(2 * this.table.length);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void createEntry(int hash, K key, V value, int bucketIndex)
/*     */   {
/* 783 */     Entry<K, V> e = this.table[bucketIndex];
/* 784 */     this.table[bucketIndex] = new Entry(hash, key, value, e);
/* 785 */     this.size += 1;
/*     */   }
/*     */   
/*     */   private abstract class HashIterator<E> implements Iterator<E> {
/*     */     KeyComparatorHashMap.Entry<K, V> next;
/*     */     int expectedModCount;
/*     */     int index;
/*     */     KeyComparatorHashMap.Entry<K, V> current;
/*     */     
/*     */     HashIterator() {
/* 795 */       this.expectedModCount = KeyComparatorHashMap.this.modCount;
/* 796 */       KeyComparatorHashMap.Entry<K, V>[] t = KeyComparatorHashMap.this.table;
/* 797 */       int i = t.length;
/* 798 */       KeyComparatorHashMap.Entry<K, V> n = null;
/* 799 */       while ((KeyComparatorHashMap.this.size != 0) && 
/* 800 */         (i > 0) && ((n = t[(--i)]) == null)) {}
/*     */       
/*     */ 
/* 803 */       this.next = n;
/* 804 */       this.index = i;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 808 */       return this.next != null;
/*     */     }
/*     */     
/*     */     KeyComparatorHashMap.Entry<K, V> nextEntry() {
/* 812 */       if (KeyComparatorHashMap.this.modCount != this.expectedModCount)
/* 813 */         throw new ConcurrentModificationException();
/* 814 */       KeyComparatorHashMap.Entry<K, V> e = this.next;
/* 815 */       if (e == null) {
/* 816 */         throw new NoSuchElementException();
/*     */       }
/* 818 */       KeyComparatorHashMap.Entry<K, V> n = e.next;
/* 819 */       KeyComparatorHashMap.Entry<K, V>[] t = KeyComparatorHashMap.this.table;
/* 820 */       int i = this.index;
/* 821 */       while ((n == null) && (i > 0))
/* 822 */         n = t[(--i)];
/* 823 */       this.index = i;
/* 824 */       this.next = n;
/* 825 */       return this.current = e;
/*     */     }
/*     */     
/*     */     public void remove() {
/* 829 */       if (this.current == null)
/* 830 */         throw new IllegalStateException();
/* 831 */       if (KeyComparatorHashMap.this.modCount != this.expectedModCount)
/* 832 */         throw new ConcurrentModificationException();
/* 833 */       K k = this.current.key;
/* 834 */       this.current = null;
/* 835 */       KeyComparatorHashMap.this.removeEntryForKey(k);
/* 836 */       this.expectedModCount = KeyComparatorHashMap.this.modCount;
/*     */     }
/*     */   }
/*     */   
/*     */   private class ValueIterator extends KeyComparatorHashMap<K, V>.HashIterator<V> {
/* 841 */     private ValueIterator() { super(); }
/*     */     
/* 843 */     public V next() { return (V)nextEntry().value; }
/*     */   }
/*     */   
/*     */   private class KeyIterator extends KeyComparatorHashMap<K, V>.HashIterator<K> {
/* 847 */     private KeyIterator() { super(); }
/*     */     
/* 849 */     public K next() { return (K)nextEntry().getKey(); }
/*     */   }
/*     */   
/*     */   private class EntryIterator extends KeyComparatorHashMap<K, V>.HashIterator<Map.Entry<K, V>> {
/* 853 */     private EntryIterator() { super(); }
/*     */     
/* 855 */     public Map.Entry<K, V> next() { return nextEntry(); }
/*     */   }
/*     */   
/*     */ 
/*     */   Iterator<K> newKeyIterator()
/*     */   {
/* 861 */     return new KeyIterator(null);
/*     */   }
/*     */   
/* 864 */   Iterator<V> newValueIterator() { return new ValueIterator(null); }
/*     */   
/*     */   Iterator<Map.Entry<K, V>> newEntryIterator() {
/* 867 */     return new EntryIterator(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 873 */   private transient Set<Map.Entry<K, V>> entrySet = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<Map.Entry<K, V>> entrySet()
/*     */   {
/* 889 */     Set<Map.Entry<K, V>> es = this.entrySet;
/* 890 */     return es != null ? es : (this.entrySet = new EntrySet(null));
/*     */   }
/*     */   
/*     */   private class EntrySet extends AbstractSet { private EntrySet() {}
/*     */     
/* 895 */     public Iterator iterator() { return KeyComparatorHashMap.this.newEntryIterator(); }
/*     */     
/*     */     public boolean contains(Object o)
/*     */     {
/* 899 */       if (!(o instanceof Map.Entry))
/* 900 */         return false;
/* 901 */       Map.Entry<K, V> e = (Map.Entry)o;
/* 902 */       KeyComparatorHashMap.Entry<K, V> candidate = KeyComparatorHashMap.this.getEntry(e.getKey());
/* 903 */       return (candidate != null) && (candidate.equals(e));
/*     */     }
/*     */     
/*     */     public boolean remove(Object o) {
/* 907 */       return KeyComparatorHashMap.this.removeMapping(o) != null;
/*     */     }
/*     */     
/* 910 */     public int size() { return KeyComparatorHashMap.this.size; }
/*     */     
/*     */     public void clear()
/*     */     {
/* 914 */       KeyComparatorHashMap.this.clear();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeObject(ObjectOutputStream s)
/*     */     throws IOException
/*     */   {
/* 934 */     Iterator<Map.Entry<K, V>> i = entrySet().iterator();
/*     */     
/*     */ 
/* 937 */     s.defaultWriteObject();
/*     */     
/*     */ 
/* 940 */     s.writeInt(this.table.length);
/*     */     
/*     */ 
/* 943 */     s.writeInt(this.size);
/*     */     
/*     */ 
/* 946 */     while (i.hasNext()) {
/* 947 */       Map.Entry<K, V> e = (Map.Entry)i.next();
/* 948 */       s.writeObject(e.getKey());
/* 949 */       s.writeObject(e.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readObject(ObjectInputStream s)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 961 */     s.defaultReadObject();
/*     */     
/*     */ 
/* 964 */     int numBuckets = s.readInt();
/* 965 */     this.table = new Entry[numBuckets];
/*     */     
/* 967 */     init();
/*     */     
/*     */ 
/* 970 */     int size = s.readInt();
/*     */     
/*     */ 
/* 973 */     for (int i = 0; i < size; i++) {
/* 974 */       K key = s.readObject();
/* 975 */       V value = s.readObject();
/* 976 */       putForCreate(key, value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/* 981 */   int capacity() { return this.table.length; }
/* 982 */   float loadFactor() { return this.loadFactor; }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\util\KeyComparatorHashMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */