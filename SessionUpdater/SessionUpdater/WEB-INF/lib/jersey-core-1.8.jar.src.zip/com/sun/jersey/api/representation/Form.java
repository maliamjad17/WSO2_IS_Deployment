package com.sun.jersey.api.representation;

import com.sun.jersey.core.util.MultivaluedMapImpl;

public class Form
  extends MultivaluedMapImpl
{
  static final long serialVersionUID = 2572713614319991270L;
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\api\representation\Form.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */