package com.sun.jersey.core.spi.scanning.uri;

import com.sun.jersey.core.spi.scanning.ScannerException;
import com.sun.jersey.core.spi.scanning.ScannerListener;
import java.net.URI;
import java.util.Set;

public abstract interface UriSchemeScanner
{
  public abstract Set<String> getSchemes();
  
  public abstract void scan(URI paramURI, ScannerListener paramScannerListener)
    throws ScannerException;
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\scanning\uri\UriSchemeScanner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */