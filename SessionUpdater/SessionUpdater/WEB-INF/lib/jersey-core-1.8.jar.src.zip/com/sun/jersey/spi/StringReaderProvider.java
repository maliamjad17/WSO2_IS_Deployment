package com.sun.jersey.spi;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

public abstract interface StringReaderProvider<T>
{
  public abstract StringReader<T> getStringReader(Class<?> paramClass, Type paramType, Annotation[] paramArrayOfAnnotation);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\spi\StringReaderProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */