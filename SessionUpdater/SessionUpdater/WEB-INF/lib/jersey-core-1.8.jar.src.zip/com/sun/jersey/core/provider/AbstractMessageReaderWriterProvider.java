/*     */ package com.sun.jersey.core.provider;
/*     */ 
/*     */ import com.sun.jersey.core.util.ReaderWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.charset.Charset;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.ext.MessageBodyReader;
/*     */ import javax.ws.rs.ext.MessageBodyWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractMessageReaderWriterProvider<T>
/*     */   implements MessageBodyReader<T>, MessageBodyWriter<T>
/*     */ {
/*  66 */   public static final Charset UTF8 = ReaderWriter.UTF8;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void writeTo(InputStream in, OutputStream out)
/*     */     throws IOException
/*     */   {
/*  76 */     ReaderWriter.writeTo(in, out);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void writeTo(Reader in, Writer out)
/*     */     throws IOException
/*     */   {
/*  87 */     ReaderWriter.writeTo(in, out);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final Charset getCharset(MediaType m)
/*     */   {
/* 100 */     return ReaderWriter.getCharset(m);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String readFromAsString(InputStream in, MediaType type)
/*     */     throws IOException
/*     */   {
/* 114 */     return ReaderWriter.readFromAsString(in, type);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void writeToAsString(String s, OutputStream out, MediaType type)
/*     */     throws IOException
/*     */   {
/* 128 */     ReaderWriter.writeToAsString(s, out, type);
/*     */   }
/*     */   
/*     */ 
/*     */   public long getSize(T t, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType)
/*     */   {
/* 134 */     return -1L;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\provider\AbstractMessageReaderWriterProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */