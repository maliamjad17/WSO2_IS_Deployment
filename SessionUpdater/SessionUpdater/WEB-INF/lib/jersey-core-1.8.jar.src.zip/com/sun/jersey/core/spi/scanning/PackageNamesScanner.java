/*     */ package com.sun.jersey.core.spi.scanning;
/*     */ 
/*     */ import com.sun.jersey.api.uri.UriComponent;
/*     */ import com.sun.jersey.api.uri.UriComponent.Type;
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*     */ import com.sun.jersey.core.spi.scanning.uri.FileSchemeScanner;
/*     */ import com.sun.jersey.core.spi.scanning.uri.JarZipSchemeScanner;
/*     */ import com.sun.jersey.core.spi.scanning.uri.UriSchemeScanner;
/*     */ import com.sun.jersey.core.spi.scanning.uri.VfsSchemeScanner;
/*     */ import com.sun.jersey.spi.service.ServiceFinder;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.ReflectPermission;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PackageNamesScanner
/*     */   implements Scanner
/*     */ {
/*     */   private final String[] packages;
/*     */   private final ClassLoader classloader;
/*     */   private final Map<String, UriSchemeScanner> scanners;
/*     */   
/*     */   public PackageNamesScanner(String[] packages)
/*     */   {
/* 102 */     this(ReflectionHelper.getContextClassLoader(), packages);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PackageNamesScanner(ClassLoader classloader, String[] packages)
/*     */   {
/* 112 */     this.packages = packages;
/* 113 */     this.classloader = classloader;
/*     */     
/* 115 */     this.scanners = new HashMap();
/* 116 */     add(new JarZipSchemeScanner());
/* 117 */     add(new FileSchemeScanner());
/* 118 */     add(new VfsSchemeScanner());
/*     */     
/* 120 */     for (UriSchemeScanner s : ServiceFinder.find(UriSchemeScanner.class)) {
/* 121 */       add(s);
/*     */     }
/*     */   }
/*     */   
/*     */   private void add(UriSchemeScanner ss) {
/* 126 */     for (String s : ss.getSchemes()) {
/* 127 */       this.scanners.put(s.toLowerCase(), ss);
/*     */     }
/*     */   }
/*     */   
/*     */   public void scan(ScannerListener cfl)
/*     */   {
/* 133 */     for (String p : this.packages) {
/*     */       try {
/* 135 */         Enumeration<URL> urls = ResourcesProvider.access$000().getResources(p.replace('.', '/'), this.classloader);
/*     */         
/* 137 */         while (urls.hasMoreElements()) {
/*     */           try {
/* 139 */             scan(toURI((URL)urls.nextElement()), cfl);
/*     */           } catch (URISyntaxException ex) {
/* 141 */             throw new ScannerException("Error when converting a URL to a URI", ex);
/*     */           }
/*     */         }
/*     */       } catch (IOException ex) {
/* 145 */         throw new ScannerException("IO error when package scanning jar", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static abstract class ResourcesProvider
/*     */   {
/*     */     private static volatile ResourcesProvider provider;
/*     */     
/*     */ 
/*     */     private static ResourcesProvider getInstance()
/*     */     {
/* 159 */       ResourcesProvider result = provider;
/*     */       
/* 161 */       if (result == null) {
/* 162 */         synchronized (ResourcesProvider.class) {
/* 163 */           result = provider;
/* 164 */           if (result == null) {
/* 165 */             provider =  = new ResourcesProvider()
/*     */             {
/*     */               public Enumeration<URL> getResources(String name, ClassLoader cl)
/*     */                 throws IOException
/*     */               {
/* 170 */                 return cl.getResources(name);
/*     */               }
/*     */             };
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 178 */       return result;
/*     */     }
/*     */     
/*     */     private static void setInstance(ResourcesProvider provider) throws SecurityException {
/* 182 */       SecurityManager security = System.getSecurityManager();
/* 183 */       if (security != null) {
/* 184 */         ReflectPermission rp = new ReflectPermission("suppressAccessChecks");
/* 185 */         security.checkPermission(rp);
/*     */       }
/* 187 */       synchronized (ResourcesProvider.class) {
/* 188 */         provider = provider;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract Enumeration<URL> getResources(String paramString, ClassLoader paramClassLoader)
/*     */       throws IOException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setResourcesProvider(ResourcesProvider provider)
/*     */     throws SecurityException
/*     */   {
/* 216 */     ResourcesProvider.setInstance(provider);
/*     */   }
/*     */   
/*     */   private void scan(URI u, ScannerListener cfl)
/*     */   {
/* 221 */     UriSchemeScanner ss = (UriSchemeScanner)this.scanners.get(u.getScheme().toLowerCase());
/* 222 */     if (ss != null) {
/* 223 */       ss.scan(u, cfl);
/*     */     } else {
/* 225 */       throw new ScannerException("The URI scheme " + u.getScheme() + " of the URI " + u + " is not supported. Package scanning deployment is not" + " supported for such URIs." + "\nTry using a different deployment mechanism such as" + " explicitly declaring root resource and provider classes" + " using an extension of javax.ws.rs.core.Application");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private URI toURI(URL url)
/*     */     throws URISyntaxException
/*     */   {
/*     */     try
/*     */     {
/* 237 */       return url.toURI();
/*     */     }
/*     */     catch (URISyntaxException e) {}
/*     */     
/*     */ 
/* 242 */     return URI.create(toExternalForm(url));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private String toExternalForm(URL u)
/*     */   {
/* 249 */     int len = u.getProtocol().length() + 1;
/* 250 */     if ((u.getAuthority() != null) && (u.getAuthority().length() > 0)) {
/* 251 */       len += 2 + u.getAuthority().length();
/*     */     }
/* 253 */     if (u.getPath() != null) {
/* 254 */       len += u.getPath().length();
/*     */     }
/* 256 */     if (u.getQuery() != null) {
/* 257 */       len += 1 + u.getQuery().length();
/*     */     }
/* 259 */     if (u.getRef() != null) {
/* 260 */       len += 1 + u.getRef().length();
/*     */     }
/*     */     
/* 263 */     StringBuffer result = new StringBuffer(len);
/* 264 */     result.append(u.getProtocol());
/* 265 */     result.append(":");
/* 266 */     if ((u.getAuthority() != null) && (u.getAuthority().length() > 0)) {
/* 267 */       result.append("//");
/* 268 */       result.append(u.getAuthority());
/*     */     }
/* 270 */     if (u.getPath() != null) {
/* 271 */       result.append(UriComponent.contextualEncode(u.getPath(), UriComponent.Type.PATH));
/*     */     }
/* 273 */     if (u.getQuery() != null) {
/* 274 */       result.append('?');
/* 275 */       result.append(UriComponent.contextualEncode(u.getQuery(), UriComponent.Type.QUERY));
/*     */     }
/* 277 */     if (u.getRef() != null) {
/* 278 */       result.append("#");
/* 279 */       result.append(u.getRef());
/*     */     }
/* 281 */     return result.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\scanning\PackageNamesScanner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */