/*     */ package com.sun.jersey.impl;
/*     */ 
/*     */ import com.sun.jersey.localization.Localizable;
/*     */ import com.sun.jersey.localization.LocalizableMessageFactory;
/*     */ import com.sun.jersey.localization.Localizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpiMessages
/*     */ {
/*  15 */   private static final LocalizableMessageFactory messageFactory = new LocalizableMessageFactory("com.sun.jersey.impl.spi");
/*  16 */   private static final Localizer localizer = new Localizer();
/*     */   
/*     */   public static Localizable localizableILLEGAL_CONFIG_SYNTAX() {
/*  19 */     return messageFactory.getMessage("illegal.config.syntax", new Object[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String ILLEGAL_CONFIG_SYNTAX()
/*     */   {
/*  27 */     return localizer.localize(localizableILLEGAL_CONFIG_SYNTAX());
/*     */   }
/*     */   
/*     */   public static Localizable localizablePROVIDER_COULD_NOT_BE_CREATED(Object arg0, Object arg1, Object arg2) {
/*  31 */     return messageFactory.getMessage("provider.could.not.be.created", new Object[] { arg0, arg1, arg2 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String PROVIDER_COULD_NOT_BE_CREATED(Object arg0, Object arg1, Object arg2)
/*     */   {
/*  39 */     return localizer.localize(localizablePROVIDER_COULD_NOT_BE_CREATED(arg0, arg1, arg2));
/*     */   }
/*     */   
/*     */   public static Localizable localizableTEMPLATE_NAME_TO_VALUE_NOT_NULL() {
/*  43 */     return messageFactory.getMessage("template.name.to.value.not.null", new Object[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String TEMPLATE_NAME_TO_VALUE_NOT_NULL()
/*     */   {
/*  51 */     return localizer.localize(localizableTEMPLATE_NAME_TO_VALUE_NOT_NULL());
/*     */   }
/*     */   
/*     */   public static Localizable localizableILLEGAL_PROVIDER_CLASS_NAME(Object arg0) {
/*  55 */     return messageFactory.getMessage("illegal.provider.class.name", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String ILLEGAL_PROVIDER_CLASS_NAME(Object arg0)
/*     */   {
/*  63 */     return localizer.localize(localizableILLEGAL_PROVIDER_CLASS_NAME(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableDEPENDENT_CLASS_OF_PROVIDER_FORMAT_ERROR(Object arg0, Object arg1, Object arg2) {
/*  67 */     return messageFactory.getMessage("dependent.class.of.provider.format.error", new Object[] { arg0, arg1, arg2 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String DEPENDENT_CLASS_OF_PROVIDER_FORMAT_ERROR(Object arg0, Object arg1, Object arg2)
/*     */   {
/*  75 */     return localizer.localize(localizableDEPENDENT_CLASS_OF_PROVIDER_FORMAT_ERROR(arg0, arg1, arg2));
/*     */   }
/*     */   
/*     */   public static Localizable localizableDEPENDENT_CLASS_OF_PROVIDER_NOT_FOUND(Object arg0, Object arg1, Object arg2) {
/*  79 */     return messageFactory.getMessage("dependent.class.of.provider.not.found", new Object[] { arg0, arg1, arg2 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String DEPENDENT_CLASS_OF_PROVIDER_NOT_FOUND(Object arg0, Object arg1, Object arg2)
/*     */   {
/*  87 */     return localizer.localize(localizableDEPENDENT_CLASS_OF_PROVIDER_NOT_FOUND(arg0, arg1, arg2));
/*     */   }
/*     */   
/*     */   public static Localizable localizableURITEMPLATE_CANNOT_BE_NULL() {
/*  91 */     return messageFactory.getMessage("uritemplate.cannot.be.null", new Object[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String URITEMPLATE_CANNOT_BE_NULL()
/*     */   {
/*  99 */     return localizer.localize(localizableURITEMPLATE_CANNOT_BE_NULL());
/*     */   }
/*     */   
/*     */   public static Localizable localizablePROVIDER_NOT_FOUND(Object arg0, Object arg1) {
/* 103 */     return messageFactory.getMessage("provider.not.found", new Object[] { arg0, arg1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String PROVIDER_NOT_FOUND(Object arg0, Object arg1)
/*     */   {
/* 111 */     return localizer.localize(localizablePROVIDER_NOT_FOUND(arg0, arg1));
/*     */   }
/*     */   
/*     */   public static Localizable localizablePROVIDER_CLASS_COULD_NOT_BE_LOADED(Object arg0, Object arg1, Object arg2) {
/* 115 */     return messageFactory.getMessage("provider.class.could.not.be.loaded", new Object[] { arg0, arg1, arg2 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String PROVIDER_CLASS_COULD_NOT_BE_LOADED(Object arg0, Object arg1, Object arg2)
/*     */   {
/* 123 */     return localizer.localize(localizablePROVIDER_CLASS_COULD_NOT_BE_LOADED(arg0, arg1, arg2));
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\impl\SpiMessages.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */