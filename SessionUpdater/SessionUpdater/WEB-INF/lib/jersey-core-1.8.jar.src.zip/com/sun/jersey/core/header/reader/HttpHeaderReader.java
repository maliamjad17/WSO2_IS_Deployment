/*     */ package com.sun.jersey.core.header.reader;
/*     */ 
/*     */ import com.sun.jersey.core.header.AcceptableLanguageTag;
/*     */ import com.sun.jersey.core.header.AcceptableMediaType;
/*     */ import com.sun.jersey.core.header.AcceptableToken;
/*     */ import com.sun.jersey.core.header.HttpDateFormat;
/*     */ import com.sun.jersey.core.header.MatchingEntityTag;
/*     */ import com.sun.jersey.core.header.MediaTypes;
/*     */ import com.sun.jersey.core.header.QualityFactor;
/*     */ import com.sun.jersey.core.header.QualitySourceMediaType;
/*     */ import com.sun.jersey.core.impl.provider.header.MediaTypeProvider;
/*     */ import java.text.ParseException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.ws.rs.core.Cookie;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.NewCookie;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HttpHeaderReader
/*     */ {
/*     */   public abstract boolean hasNext();
/*     */   
/*     */   public abstract boolean hasNextSeparator(char paramChar, boolean paramBoolean);
/*     */   
/*     */   public abstract Event next()
/*     */     throws ParseException;
/*     */   
/*     */   public abstract Event next(boolean paramBoolean)
/*     */     throws ParseException;
/*     */   
/*     */   public abstract String nextSeparatedString(char paramChar1, char paramChar2)
/*     */     throws ParseException;
/*     */   
/*     */   public abstract Event getEvent();
/*     */   
/*     */   public abstract String getEventValue();
/*     */   
/*     */   public abstract String getRemainder();
/*     */   
/*     */   public abstract int getIndex();
/*     */   
/*     */   public static abstract interface ListElementCreator<T>
/*     */   {
/*     */     public abstract T create(HttpHeaderReader paramHttpHeaderReader)
/*     */       throws ParseException;
/*     */   }
/*     */   
/*     */   public static enum Event
/*     */   {
/*  74 */     Token,  QuotedString,  Comment,  Separator,  Control;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private Event() {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String nextToken()
/*     */     throws ParseException
/*     */   {
/*  96 */     Event e = next(false);
/*  97 */     if (e != Event.Token) {
/*  98 */       throw new ParseException("Next event is not a Token", getIndex());
/*     */     }
/* 100 */     return getEventValue();
/*     */   }
/*     */   
/*     */   public char nextSeparator() throws ParseException {
/* 104 */     Event e = next(false);
/* 105 */     if (e != Event.Separator) {
/* 106 */       throw new ParseException("Next event is not a Separator", getIndex());
/*     */     }
/* 108 */     return getEventValue().charAt(0);
/*     */   }
/*     */   
/*     */   public void nextSeparator(char c) throws ParseException {
/* 112 */     Event e = next(false);
/* 113 */     if (e != Event.Separator) {
/* 114 */       throw new ParseException("Next event is not a Separator", getIndex());
/*     */     }
/* 116 */     if (c != getEventValue().charAt(0)) {
/* 117 */       throw new ParseException("Expected separator '" + c + "' instead of '" + getEventValue().charAt(0) + "'", getIndex());
/*     */     }
/*     */   }
/*     */   
/*     */   public String nextQuotedString() throws ParseException
/*     */   {
/* 123 */     Event e = next(false);
/* 124 */     if (e != Event.QuotedString) {
/* 125 */       throw new ParseException("Next event is not a Quoted String", getIndex());
/*     */     }
/* 127 */     return getEventValue();
/*     */   }
/*     */   
/*     */   public String nextTokenOrQuotedString() throws ParseException {
/* 131 */     Event e = next(false);
/* 132 */     if ((e != Event.Token) && (e != Event.QuotedString)) {
/* 133 */       throw new ParseException("Next event is not a Token or a Quoted String, " + getEventValue(), getIndex());
/*     */     }
/*     */     
/* 136 */     return getEventValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static HttpHeaderReader newInstance(String header)
/*     */   {
/* 143 */     return new HttpHeaderReaderImpl(header);
/*     */   }
/*     */   
/*     */   public static HttpHeaderReader newInstance(String header, boolean processComments) {
/* 147 */     return new HttpHeaderReaderImpl(header, processComments);
/*     */   }
/*     */   
/*     */   public static Date readDate(String date) throws ParseException
/*     */   {
/* 152 */     return HttpDateFormat.readDate(date);
/*     */   }
/*     */   
/*     */   public static int readQualityFactor(String q) throws ParseException
/*     */   {
/* 157 */     if ((q == null) || (q.length() == 0)) {
/* 158 */       throw new ParseException("Quality value cannot be null or an empty String", 0);
/*     */     }
/* 160 */     int index = 0;
/* 161 */     int length = q.length();
/* 162 */     if (length > 5) {
/* 163 */       throw new ParseException("Quality value is greater than the maximum length, 5", 0);
/*     */     }
/*     */     
/*     */     char wholeNumber;
/*     */     
/* 168 */     char c = wholeNumber = q.charAt(index++);
/* 169 */     if ((c == '0') || (c == '1')) {
/* 170 */       if (index == length)
/* 171 */         return (c - '0') * 1000;
/* 172 */       c = q.charAt(index++);
/* 173 */       if (c != '.') {
/* 174 */         throw new ParseException("Error parsing Quality value: a decimal place is expected rather than '" + c + "'", index);
/*     */       }
/*     */       
/* 177 */       if (index == length)
/* 178 */         return (c - '0') * 1000;
/* 179 */     } else if (c == '.')
/*     */     {
/*     */ 
/* 182 */       if (index == length) {
/* 183 */         throw new ParseException("Error parsing Quality value: a decimal numeral is expected after the decimal point", index);
/*     */       }
/*     */     } else {
/* 186 */       throw new ParseException("Error parsing Quality value: a decimal numeral '0' or '1' is expected rather than '" + c + "'", index);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 191 */     int value = 0;
/* 192 */     int exponent = 100;
/* 193 */     while (index < length) {
/* 194 */       c = q.charAt(index++);
/* 195 */       if ((c >= '0') && (c <= '9')) {
/* 196 */         value += (c - '0') * exponent;
/* 197 */         exponent /= 10;
/*     */       } else {
/* 199 */         throw new ParseException("Error parsing Quality value: a decimal numeral is expected rather than '" + c + "'", index);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 204 */     if (wholeNumber == '1') {
/* 205 */       if (value > 0)
/* 206 */         throw new ParseException("The Quality value, " + q + ", is greater than 1", index);
/* 207 */       return 1000;
/*     */     }
/* 209 */     return value;
/*     */   }
/*     */   
/*     */   public static int readQualityFactorParameter(HttpHeaderReader reader) throws ParseException {
/* 213 */     int q = -1;
/* 214 */     while (reader.hasNext()) {
/* 215 */       reader.nextSeparator(';');
/*     */       
/*     */ 
/* 218 */       if (!reader.hasNext()) {
/* 219 */         return 1000;
/*     */       }
/*     */       
/* 222 */       String name = reader.nextToken();
/* 223 */       reader.nextSeparator('=');
/*     */       
/* 225 */       String value = reader.nextTokenOrQuotedString();
/*     */       
/* 227 */       if ((q == -1) && (name.equalsIgnoreCase("q"))) {
/* 228 */         q = readQualityFactor(value);
/*     */       }
/*     */     }
/*     */     
/* 232 */     return q == -1 ? 1000 : q;
/*     */   }
/*     */   
/*     */   public static Map<String, String> readParameters(HttpHeaderReader reader) throws ParseException {
/* 236 */     Map<String, String> m = null;
/*     */     
/* 238 */     while (reader.hasNext()) {
/* 239 */       reader.nextSeparator(';');
/* 240 */       while (reader.hasNextSeparator(';', true)) {
/* 241 */         reader.next();
/*     */       }
/*     */       
/* 244 */       if (!reader.hasNext()) {
/*     */         break;
/*     */       }
/*     */       
/* 248 */       String name = reader.nextToken();
/* 249 */       reader.nextSeparator('=');
/*     */       
/* 251 */       String value = reader.nextTokenOrQuotedString();
/*     */       
/* 253 */       if (m == null) {
/* 254 */         m = new LinkedHashMap();
/*     */       }
/*     */       
/* 257 */       m.put(name.toLowerCase(), value);
/*     */     }
/*     */     
/* 260 */     return m;
/*     */   }
/*     */   
/*     */   public static Map<String, Cookie> readCookies(String header) {
/* 264 */     return CookiesParser.parseCookies(header);
/*     */   }
/*     */   
/*     */   public static Cookie readCookie(String header) {
/* 268 */     return CookiesParser.parseCookie(header);
/*     */   }
/*     */   
/*     */   public static NewCookie readNewCookie(String header) {
/* 272 */     return CookiesParser.parseNewCookie(header);
/*     */   }
/*     */   
/*     */ 
/* 276 */   private static final ListElementCreator<MatchingEntityTag> MATCHING_ENTITY_TAG_CREATOR = new ListElementCreator()
/*     */   {
/*     */     public MatchingEntityTag create(HttpHeaderReader reader) throws ParseException {
/* 279 */       return MatchingEntityTag.valueOf(reader);
/*     */     }
/*     */   };
/*     */   
/*     */   public static Set<MatchingEntityTag> readMatchingEntityTag(String header) throws ParseException {
/* 284 */     if (header.equals("*")) {
/* 285 */       return MatchingEntityTag.ANY_MATCH;
/*     */     }
/* 287 */     HttpHeaderReader reader = new HttpHeaderReaderImpl(header);
/* 288 */     Set<MatchingEntityTag> l = new HashSet(1);
/* 289 */     HttpHeaderListAdapter adapter = new HttpHeaderListAdapter(reader);
/* 290 */     while (reader.hasNext()) {
/* 291 */       l.add(MATCHING_ENTITY_TAG_CREATOR.create(adapter));
/* 292 */       adapter.reset();
/* 293 */       if (reader.hasNext()) {
/* 294 */         reader.next();
/*     */       }
/*     */     }
/* 297 */     return l;
/*     */   }
/*     */   
/*     */ 
/* 301 */   private static final ListElementCreator<MediaType> MEDIA_TYPE_CREATOR = new ListElementCreator()
/*     */   {
/*     */     public MediaType create(HttpHeaderReader reader) throws ParseException {
/* 304 */       return MediaTypeProvider.valueOf(reader);
/*     */     }
/*     */   };
/*     */   
/*     */   public static List<MediaType> readMediaTypes(List<MediaType> l, String header) throws ParseException {
/* 309 */     return readList(l, MEDIA_TYPE_CREATOR, header);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 315 */   private static final ListElementCreator<AcceptableMediaType> ACCEPTABLE_MEDIA_TYPE_CREATOR = new ListElementCreator()
/*     */   {
/*     */     public AcceptableMediaType create(HttpHeaderReader reader) throws ParseException {
/* 318 */       return AcceptableMediaType.valueOf(reader);
/*     */     }
/*     */   };
/*     */   
/* 322 */   private static final Comparator<AcceptableMediaType> ACCEPTABLE_MEDIA_TYPE_COMPARATOR = new Comparator()
/*     */   {
/*     */     public int compare(AcceptableMediaType o1, AcceptableMediaType o2) {
/* 325 */       int i = o2.getQuality() - o1.getQuality();
/* 326 */       if (i != 0) {
/* 327 */         return i;
/*     */       }
/* 329 */       return MediaTypes.MEDIA_TYPE_COMPARATOR.compare(o1, o2);
/*     */     }
/*     */   };
/*     */   
/*     */   public static List<AcceptableMediaType> readAcceptMediaType(String header) throws ParseException {
/* 334 */     return readAcceptableList(ACCEPTABLE_MEDIA_TYPE_COMPARATOR, ACCEPTABLE_MEDIA_TYPE_CREATOR, header);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 341 */   private static final ListElementCreator<QualitySourceMediaType> QUALITY_SOURCE_MEDIA_TYPE_CREATOR = new ListElementCreator()
/*     */   {
/*     */     public QualitySourceMediaType create(HttpHeaderReader reader) throws ParseException {
/* 344 */       return QualitySourceMediaType.valueOf(reader);
/*     */     }
/*     */   };
/*     */   
/*     */   public static List<QualitySourceMediaType> readQualitySourceMediaType(String header) throws ParseException {
/* 349 */     return readAcceptableList(MediaTypes.QUALITY_SOURCE_MEDIA_TYPE_COMPARATOR, QUALITY_SOURCE_MEDIA_TYPE_CREATOR, header);
/*     */   }
/*     */   
/*     */ 
/*     */   public static List<QualitySourceMediaType> readQualitySourceMediaType(String[] header)
/*     */     throws ParseException
/*     */   {
/* 356 */     if (header.length < 2) {
/* 357 */       return readQualitySourceMediaType(header[0]);
/*     */     }
/* 359 */     StringBuffer sb = new StringBuffer();
/* 360 */     for (String h : header) {
/* 361 */       if (sb.length() > 0) {
/* 362 */         sb.append(",");
/*     */       }
/* 364 */       sb.append(h);
/*     */     }
/*     */     
/* 367 */     return readQualitySourceMediaType(sb.toString());
/*     */   }
/*     */   
/*     */   public static List<AcceptableMediaType> readAcceptMediaType(String header, List<QualitySourceMediaType> priorityMediaTypes) throws ParseException
/*     */   {
/* 372 */     readAcceptableList(new Comparator()
/*     */     {
/*     */       public int compare(AcceptableMediaType o1, AcceptableMediaType o2) {
/* 375 */         boolean q_o1_set = false;
/* 376 */         int q_o1 = 1000000;
/* 377 */         boolean q_o2_set = false;
/* 378 */         int q_o2 = 1000000;
/* 379 */         for (QualitySourceMediaType m : this.val$priorityMediaTypes) {
/* 380 */           if ((!q_o1_set) && (MediaTypes.typeEquals(o1, m))) {
/* 381 */             q_o1 = o1.getQuality() * m.getQualitySource();
/* 382 */             q_o1_set = true;
/* 383 */           } else if ((!q_o2_set) && (MediaTypes.typeEquals(o2, m))) {
/* 384 */             q_o2 = o2.getQuality() * m.getQualitySource();
/* 385 */             q_o2_set = true;
/*     */           }
/*     */         }
/* 388 */         int i = q_o2 - q_o1;
/* 389 */         if (i != 0) {
/* 390 */           return i;
/*     */         }
/* 392 */         i = o2.getQuality() - o1.getQuality();
/* 393 */         if (i != 0) {
/* 394 */           return i;
/*     */         }
/* 396 */         return MediaTypes.MEDIA_TYPE_COMPARATOR.compare(o1, o2); } }, ACCEPTABLE_MEDIA_TYPE_CREATOR, header);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 403 */   private static final ListElementCreator<AcceptableToken> ACCEPTABLE_TOKEN_CREATOR = new ListElementCreator()
/*     */   {
/*     */     public AcceptableToken create(HttpHeaderReader reader) throws ParseException {
/* 406 */       return new AcceptableToken(reader);
/*     */     }
/*     */   };
/*     */   
/*     */   public static List<AcceptableToken> readAcceptToken(String header) throws ParseException {
/* 411 */     return readAcceptableList(ACCEPTABLE_TOKEN_CREATOR, header);
/*     */   }
/*     */   
/*     */ 
/* 415 */   private static final ListElementCreator<AcceptableLanguageTag> LANGUAGE_CREATOR = new ListElementCreator()
/*     */   {
/*     */     public AcceptableLanguageTag create(HttpHeaderReader reader) throws ParseException {
/* 418 */       return new AcceptableLanguageTag(reader);
/*     */     }
/*     */   };
/*     */   
/*     */   public static List<AcceptableLanguageTag> readAcceptLanguage(String header) throws ParseException {
/* 423 */     return readAcceptableList(LANGUAGE_CREATOR, header);
/*     */   }
/*     */   
/*     */ 
/* 427 */   private static final Comparator<QualityFactor> QUALITY_COMPARATOR = new Comparator() {
/*     */     public int compare(QualityFactor o1, QualityFactor o2) {
/* 429 */       return o2.getQuality() - o1.getQuality();
/*     */     }
/*     */   };
/*     */   
/*     */   public static <T extends QualityFactor> List<T> readAcceptableList(ListElementCreator<T> c, String header)
/*     */     throws ParseException
/*     */   {
/* 436 */     List<T> l = readList(c, header);
/* 437 */     Collections.sort(l, QUALITY_COMPARATOR);
/* 438 */     return l;
/*     */   }
/*     */   
/*     */ 
/*     */   public static <T> List<T> readAcceptableList(Comparator<T> comparator, ListElementCreator<T> c, String header)
/*     */     throws ParseException
/*     */   {
/* 445 */     List<T> l = readList(c, header);
/* 446 */     Collections.sort(l, comparator);
/* 447 */     return l;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <T> List<T> readList(ListElementCreator<T> c, String header)
/*     */     throws ParseException
/*     */   {
/* 457 */     return readList(new ArrayList(), c, header);
/*     */   }
/*     */   
/*     */   public static <T> List<T> readList(List<T> l, ListElementCreator<T> c, String header) throws ParseException
/*     */   {
/* 462 */     HttpHeaderReader reader = new HttpHeaderReaderImpl(header);
/* 463 */     HttpHeaderListAdapter adapter = new HttpHeaderListAdapter(reader);
/* 464 */     while (reader.hasNext()) {
/* 465 */       l.add(c.create(adapter));
/* 466 */       adapter.reset();
/* 467 */       if (reader.hasNext()) {
/* 468 */         reader.next();
/*     */       }
/*     */     }
/* 471 */     return l;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\header\reader\HttpHeaderReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */