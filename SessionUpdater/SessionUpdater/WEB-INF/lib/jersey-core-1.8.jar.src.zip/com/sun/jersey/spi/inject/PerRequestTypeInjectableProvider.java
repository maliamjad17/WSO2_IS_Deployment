/*    */ package com.sun.jersey.spi.inject;
/*    */ 
/*    */ import com.sun.jersey.core.spi.component.ComponentContext;
/*    */ import com.sun.jersey.core.spi.component.ComponentScope;
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PerRequestTypeInjectableProvider<A extends Annotation, T>
/*    */   implements InjectableProvider<A, Type>
/*    */ {
/*    */   private final Type t;
/*    */   
/*    */   public PerRequestTypeInjectableProvider(Type t)
/*    */   {
/* 32 */     this.t = t;
/*    */   }
/*    */   
/*    */   public final ComponentScope getScope() {
/* 36 */     return ComponentScope.PerRequest;
/*    */   }
/*    */   
/*    */   public final Injectable getInjectable(ComponentContext ic, A a, Type c) {
/* 40 */     if (c.equals(this.t)) {
/* 41 */       return getInjectable(ic, a);
/*    */     }
/* 43 */     return null;
/*    */   }
/*    */   
/*    */   public abstract Injectable<T> getInjectable(ComponentContext paramComponentContext, A paramA);
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\spi\inject\PerRequestTypeInjectableProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */