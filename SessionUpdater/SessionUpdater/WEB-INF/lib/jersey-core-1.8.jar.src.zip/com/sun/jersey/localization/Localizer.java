/*     */ package com.sun.jersey.localization;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Localizer
/*     */ {
/*     */   private final Locale _locale;
/*     */   private final HashMap _resourceBundles;
/*     */   
/*     */   public Localizer()
/*     */   {
/*  61 */     this(Locale.getDefault());
/*     */   }
/*     */   
/*     */   public Localizer(Locale l) {
/*  65 */     this._locale = l;
/*  66 */     this._resourceBundles = new HashMap();
/*     */   }
/*     */   
/*     */   public Locale getLocale() {
/*  70 */     return this._locale;
/*     */   }
/*     */   
/*     */   public String localize(Localizable l) {
/*  74 */     String key = l.getKey();
/*  75 */     if (key == Localizable.NOT_LOCALIZABLE)
/*     */     {
/*  77 */       return (String)l.getArguments()[0];
/*     */     }
/*  79 */     String bundlename = l.getResourceBundleName();
/*     */     try
/*     */     {
/*  82 */       ResourceBundle bundle = (ResourceBundle)this._resourceBundles.get(bundlename);
/*     */       
/*     */ 
/*  85 */       if (bundle == null) {
/*     */         try {
/*  87 */           bundle = ResourceBundle.getBundle(bundlename, this._locale);
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         catch (MissingResourceException e)
/*     */         {
/*     */ 
/*     */ 
/*  96 */           int i = bundlename.lastIndexOf('.');
/*  97 */           if (i != -1) {
/*  98 */             String alternateBundleName = bundlename.substring(i + 1);
/*     */             try
/*     */             {
/* 101 */               bundle = ResourceBundle.getBundle(alternateBundleName, this._locale);
/*     */ 
/*     */             }
/*     */             catch (MissingResourceException e2)
/*     */             {
/*     */ 
/* 107 */               return getDefaultMessage(l);
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 112 */         this._resourceBundles.put(bundlename, bundle);
/*     */       }
/*     */       
/* 115 */       if (bundle == null) {
/* 116 */         return getDefaultMessage(l);
/*     */       }
/*     */       
/* 119 */       if (key == null) {
/* 120 */         key = "undefined";
/*     */       }
/*     */       String msg;
/*     */       try {
/* 124 */         msg = bundle.getString(key);
/*     */       }
/*     */       catch (MissingResourceException e) {
/* 127 */         msg = bundle.getString("undefined");
/*     */       }
/*     */       
/*     */ 
/* 131 */       Object[] args = l.getArguments();
/* 132 */       for (int i = 0; i < args.length; i++) {
/* 133 */         if ((args[i] instanceof Localizable)) {
/* 134 */           args[i] = localize((Localizable)args[i]);
/*     */         }
/*     */       }
/* 137 */       return MessageFormat.format(msg, args);
/*     */     }
/*     */     catch (MissingResourceException e) {}
/*     */     
/* 141 */     return getDefaultMessage(l);
/*     */   }
/*     */   
/*     */ 
/*     */   private String getDefaultMessage(Localizable l)
/*     */   {
/* 147 */     String key = l.getKey();
/* 148 */     Object[] args = l.getArguments();
/* 149 */     StringBuilder sb = new StringBuilder();
/* 150 */     sb.append("[failed to localize] ");
/* 151 */     sb.append(key);
/* 152 */     if (args != null) {
/* 153 */       sb.append('(');
/* 154 */       for (int i = 0; i < args.length; i++) {
/* 155 */         if (i != 0)
/* 156 */           sb.append(", ");
/* 157 */         sb.append(String.valueOf(args[i]));
/*     */       }
/* 159 */       sb.append(')');
/*     */     }
/* 161 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\localization\Localizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */