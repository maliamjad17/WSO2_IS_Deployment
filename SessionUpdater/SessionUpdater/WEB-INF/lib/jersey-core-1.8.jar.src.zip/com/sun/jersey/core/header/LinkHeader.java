/*     */ package com.sun.jersey.core.header;
/*     */ 
/*     */ import com.sun.jersey.core.header.reader.HttpHeaderReader;
/*     */ import com.sun.jersey.core.header.reader.HttpHeaderReader.Event;
/*     */ import com.sun.jersey.core.impl.provider.header.WriterUtil;
/*     */ import com.sun.jersey.core.util.MultivaluedMapImpl;
/*     */ import java.net.URI;
/*     */ import java.text.ParseException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LinkHeader
/*     */ {
/*     */   private URI uri;
/*     */   private Set<String> rels;
/*     */   private MediaType type;
/*     */   private MultivaluedMap<String, String> parameters;
/*     */   
/*     */   public LinkHeader(String header)
/*     */     throws ParseException, IllegalArgumentException
/*     */   {
/*  74 */     this(HttpHeaderReader.newInstance(header));
/*     */   }
/*     */   
/*     */   public LinkHeader(HttpHeaderReader reader) throws ParseException, IllegalArgumentException {
/*  78 */     this.uri = URI.create(reader.nextSeparatedString('<', '>'));
/*     */     
/*  80 */     if (reader.hasNext())
/*  81 */       parseParameters(reader);
/*     */   }
/*     */   
/*     */   protected LinkHeader(LinkHeaderBuilder builder) {
/*  85 */     this.uri = builder.uri;
/*     */     
/*  87 */     if (builder.rels != null) {
/*  88 */       if (builder.rels.size() == 1) {
/*  89 */         this.rels = builder.rels;
/*     */       } else {
/*  91 */         this.rels = Collections.unmodifiableSet(new HashSet(builder.rels));
/*     */       }
/*     */     }
/*     */     
/*  95 */     this.type = builder.type;
/*     */     
/*  97 */     if (builder.parameters != null) {
/*  98 */       this.parameters = new MultivaluedMapImpl(builder.parameters);
/*     */     }
/*     */   }
/*     */   
/*     */   public static LinkHeader valueOf(String header) throws IllegalArgumentException {
/*     */     try {
/* 104 */       return new LinkHeader(HttpHeaderReader.newInstance(header));
/*     */     } catch (ParseException ex) {
/* 106 */       throw new IllegalArgumentException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 112 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 114 */     sb.append('<').append(this.uri.toASCIIString()).append('>');
/*     */     
/* 116 */     if (this.rels != null) {
/* 117 */       sb.append(';').append("rel=");
/* 118 */       if (this.rels.size() == 1) {
/* 119 */         sb.append((String)this.rels.iterator().next());
/*     */       } else {
/* 121 */         sb.append('"');
/* 122 */         boolean first = true;
/* 123 */         for (String rel : this.rels) {
/* 124 */           if (!first)
/* 125 */             sb.append(' ');
/* 126 */           sb.append(rel);
/* 127 */           first = false;
/*     */         }
/* 129 */         sb.append('"');
/*     */       }
/*     */     }
/*     */     
/* 133 */     if (this.type != null) {
/* 134 */       sb.append(';').append("type=").append(this.type.getType()).append('/').append(this.type.getSubtype());
/*     */     }
/*     */     
/*     */     Iterator i$;
/* 138 */     if (this.parameters != null) {
/* 139 */       for (i$ = this.parameters.entrySet().iterator(); i$.hasNext();) { e = (Map.Entry)i$.next();
/* 140 */         String key = (String)e.getKey();
/* 141 */         List<String> values = (List)e.getValue();
/*     */         
/* 143 */         if ((key.equals("anchor")) || (key.equals("title"))) {
/* 144 */           sb.append(";").append(key).append("=");
/* 145 */           WriterUtil.appendQuoted(sb, (String)values.get(0));
/* 146 */         } else if (key.equals("hreflang")) {
/* 147 */           for (String value : (List)e.getValue()) {
/* 148 */             sb.append(";").append((String)e.getKey()).append("=").append(value);
/*     */           }
/*     */         }
/*     */         else {
/* 152 */           for (String value : (List)e.getValue()) {
/* 153 */             sb.append(";").append((String)e.getKey()).append("=");
/* 154 */             WriterUtil.appendQuoted(sb, value);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     Map.Entry<String, List<String>> e;
/* 160 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public MultivaluedMap<String, String> getParams() {
/* 164 */     checkNull();
/* 165 */     return this.parameters;
/*     */   }
/*     */   
/*     */   public URI getUri() {
/* 169 */     return this.uri;
/*     */   }
/*     */   
/*     */   public Set<String> getRel() {
/* 173 */     if (this.rels == null) {
/* 174 */       this.rels = Collections.emptySet();
/*     */     }
/* 176 */     return this.rels;
/*     */   }
/*     */   
/*     */   public MediaType getType() {
/* 180 */     return this.type;
/*     */   }
/*     */   
/*     */   public String getOp() {
/* 184 */     if (this.parameters != null) {
/* 185 */       return (String)this.parameters.getFirst("op");
/*     */     }
/* 187 */     return null;
/*     */   }
/*     */   
/*     */   private void parseParameters(HttpHeaderReader reader) throws ParseException
/*     */   {
/* 192 */     while (reader.hasNext()) {
/* 193 */       reader.nextSeparator(';');
/* 194 */       while (reader.hasNextSeparator(';', true)) {
/* 195 */         reader.next();
/*     */       }
/*     */       
/* 198 */       if (!reader.hasNext()) {
/*     */         break;
/*     */       }
/*     */       
/* 202 */       String name = reader.nextToken().toLowerCase();
/* 203 */       reader.nextSeparator('=');
/*     */       
/* 205 */       if (name.equals("rel")) {
/* 206 */         String value = reader.nextTokenOrQuotedString();
/* 207 */         if (reader.getEvent() == HttpHeaderReader.Event.Token) {
/* 208 */           this.rels = Collections.singleton(value);
/*     */         } else {
/* 210 */           String[] values = value.split(" ");
/* 211 */           this.rels = Collections.unmodifiableSet(new HashSet(Arrays.asList(values)));
/*     */         }
/* 213 */       } else if (name.equals("hreflang")) {
/* 214 */         add(name, reader.nextTokenOrQuotedString());
/* 215 */       } else if (name.equals("media")) {
/* 216 */         if (!containsKey("media")) {
/* 217 */           add(name, reader.nextTokenOrQuotedString());
/*     */         }
/* 219 */       } else if (name.equals("title")) {
/* 220 */         if (!containsKey("title")) {
/* 221 */           add(name, reader.nextQuotedString());
/*     */         }
/* 223 */       } else if (name.equals("title*")) {
/* 224 */         add(name, reader.nextQuotedString());
/* 225 */       } else if (name.equals("type")) {
/* 226 */         String typeName = reader.nextToken();
/* 227 */         reader.nextSeparator('/');
/* 228 */         String subTypeName = reader.nextToken();
/* 229 */         this.type = new MediaType(typeName, subTypeName);
/*     */       } else {
/* 231 */         add(name, reader.nextTokenOrQuotedString());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void checkNull()
/*     */   {
/* 239 */     if (this.parameters == null)
/* 240 */       this.parameters = new MultivaluedMapImpl();
/*     */   }
/*     */   
/*     */   private boolean containsKey(String key) {
/* 244 */     checkNull();
/* 245 */     return this.parameters.containsKey(key);
/*     */   }
/*     */   
/*     */   private void add(String key, String value) {
/* 249 */     checkNull();
/* 250 */     this.parameters.add(key, value);
/*     */   }
/*     */   
/*     */   public static LinkHeaderBuilder uri(URI uri) {
/* 254 */     return new LinkHeaderBuilder(uri);
/*     */   }
/*     */   
/*     */ 
/*     */   public static class LinkHeaderBuilder<T extends LinkHeaderBuilder, V extends LinkHeader>
/*     */   {
/*     */     protected URI uri;
/*     */     
/*     */     protected Set<String> rels;
/*     */     
/*     */     protected MediaType type;
/*     */     
/*     */     protected MultivaluedMap<String, String> parameters;
/*     */     
/*     */ 
/*     */     LinkHeaderBuilder(URI uri)
/*     */     {
/* 271 */       this.uri = uri;
/*     */     }
/*     */     
/*     */     public T rel(String rel) {
/* 275 */       if (rel == null) {
/* 276 */         throw new IllegalArgumentException("rel parameter cannot be null");
/*     */       }
/* 278 */       rel = rel.trim();
/* 279 */       if (rel.length() == 0) {
/* 280 */         throw new IllegalArgumentException("rel parameter cannot an empty string or just white space");
/*     */       }
/* 282 */       if (this.rels == null) {
/* 283 */         this.rels = Collections.singleton(rel);
/* 284 */       } else if ((this.rels.size() == 1) && (!this.rels.contains(rel))) {
/* 285 */         this.rels = new HashSet(this.rels);
/* 286 */         this.rels.add(rel);
/*     */       } else {
/* 288 */         this.rels.add(rel);
/*     */       }
/*     */       
/* 291 */       return this;
/*     */     }
/*     */     
/*     */     public T type(MediaType type) {
/* 295 */       this.type = type;
/* 296 */       return this;
/*     */     }
/*     */     
/*     */     public T op(String op) {
/* 300 */       parameter("op", op);
/* 301 */       return this;
/*     */     }
/*     */     
/*     */     public T parameter(String key, String value) {
/* 305 */       if (key.equals("rel"))
/* 306 */         return rel(value);
/* 307 */       if (key.equals("type")) {
/* 308 */         return type(MediaType.valueOf(value));
/*     */       }
/*     */       
/* 311 */       if (this.parameters == null)
/* 312 */         this.parameters = new MultivaluedMapImpl();
/* 313 */       this.parameters.add(key, value);
/* 314 */       return this;
/*     */     }
/*     */     
/*     */     public V build() {
/* 318 */       LinkHeader lh = new LinkHeader(this);
/* 319 */       return lh;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\header\LinkHeader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */