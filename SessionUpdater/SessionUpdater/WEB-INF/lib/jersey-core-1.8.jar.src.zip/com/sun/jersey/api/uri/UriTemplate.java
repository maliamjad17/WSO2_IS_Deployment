/*     */ package com.sun.jersey.api.uri;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.regex.PatternSyntaxException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UriTemplate
/*     */ {
/*  68 */   public static final Comparator<UriTemplate> COMPARATOR = new Comparator() {
/*     */     public int compare(UriTemplate o1, UriTemplate o2) {
/*  70 */       if ((o1 == null) && (o2 == null))
/*  71 */         return 0;
/*  72 */       if (o1 == null)
/*  73 */         return 1;
/*  74 */       if (o2 == null) {
/*  75 */         return -1;
/*     */       }
/*  77 */       if ((o1 == UriTemplate.EMPTY) && (o2 == UriTemplate.EMPTY))
/*  78 */         return 0;
/*  79 */       if (o1 == UriTemplate.EMPTY)
/*  80 */         return 1;
/*  81 */       if (o2 == UriTemplate.EMPTY) {
/*  82 */         return -1;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  88 */       int i = o2.getNumberOfExplicitCharacters() - o1.getNumberOfExplicitCharacters();
/*  89 */       if (i != 0) { return i;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */       i = o2.getNumberOfTemplateVariables() - o1.getNumberOfTemplateVariables();
/*  97 */       if (i != 0) { return i;
/*     */       }
/*     */       
/*     */ 
/* 101 */       i = o2.getNumberOfExplicitRegexes() - o1.getNumberOfExplicitRegexes();
/* 102 */       if (i != 0) { return i;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 108 */       return o2.pattern.getRegex().compareTo(o1.pattern.getRegex());
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 115 */   private static final Pattern TEMPLATE_NAMES_PATTERN = Pattern.compile("\\{(\\w[-\\w\\.]*)\\}");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 120 */   public static final UriTemplate EMPTY = new UriTemplate();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String template;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String normalizedTemplate;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final UriPattern pattern;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final boolean endsWithSlash;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final List<String> templateVariables;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int numOfExplicitRegexes;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int numOfCharacters;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private UriTemplate()
/*     */   {
/* 164 */     this.template = (this.normalizedTemplate = "");
/* 165 */     this.pattern = UriPattern.EMPTY;
/* 166 */     this.endsWithSlash = false;
/* 167 */     this.templateVariables = Collections.emptyList();
/* 168 */     this.numOfExplicitRegexes = (this.numOfCharacters = 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriTemplate(String template)
/*     */     throws PatternSyntaxException, IllegalArgumentException
/*     */   {
/* 188 */     this(new UriTemplateParser(template));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected UriTemplate(UriTemplateParser templateParser)
/*     */     throws PatternSyntaxException, IllegalArgumentException
/*     */   {
/* 208 */     this.template = templateParser.getTemplate();
/*     */     
/* 210 */     this.normalizedTemplate = templateParser.getNormalizedTemplate();
/*     */     
/* 212 */     this.pattern = createUriPattern(templateParser);
/*     */     
/* 214 */     this.numOfExplicitRegexes = templateParser.getNumberOfExplicitRegexes();
/*     */     
/* 216 */     this.numOfCharacters = templateParser.getNumberOfLiteralCharacters();
/*     */     
/* 218 */     this.endsWithSlash = (this.template.charAt(this.template.length() - 1) == '/');
/*     */     
/* 220 */     this.templateVariables = Collections.unmodifiableList(templateParser.getNames());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected UriPattern createUriPattern(UriTemplateParser templateParser)
/*     */   {
/* 230 */     return new UriPattern(templateParser.getPattern(), templateParser.getGroupIndexes());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getTemplate()
/*     */   {
/* 238 */     return this.template;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final UriPattern getPattern()
/*     */   {
/* 247 */     return this.pattern;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final boolean endsWithSlash()
/*     */   {
/* 254 */     return this.endsWithSlash;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final List<String> getTemplateVariables()
/*     */   {
/* 262 */     return this.templateVariables;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isTemplateVariablePresent(String name)
/*     */   {
/* 273 */     for (String s : this.templateVariables) {
/* 274 */       if (s.equals(name)) {
/* 275 */         return true;
/*     */       }
/*     */     }
/* 278 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getNumberOfExplicitRegexes()
/*     */   {
/* 287 */     return this.numOfExplicitRegexes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getNumberOfExplicitCharacters()
/*     */   {
/* 297 */     return this.numOfCharacters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getNumberOfTemplateVariables()
/*     */   {
/* 305 */     return this.templateVariables.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean match(CharSequence uri, Map<String, String> templateVariableToValue)
/*     */     throws IllegalArgumentException
/*     */   {
/* 326 */     if (templateVariableToValue == null) {
/* 327 */       throw new IllegalArgumentException();
/*     */     }
/* 329 */     return this.pattern.match(uri, this.templateVariables, templateVariableToValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean match(CharSequence uri, List<String> groupValues)
/*     */     throws IllegalArgumentException
/*     */   {
/* 350 */     if (groupValues == null) {
/* 351 */       throw new IllegalArgumentException();
/*     */     }
/* 353 */     return this.pattern.match(uri, groupValues);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String createURI(Map<String, String> values)
/*     */   {
/* 367 */     StringBuilder b = new StringBuilder();
/*     */     
/* 369 */     Matcher m = TEMPLATE_NAMES_PATTERN.matcher(this.normalizedTemplate);
/* 370 */     int i = 0;
/* 371 */     while (m.find()) {
/* 372 */       b.append(this.normalizedTemplate, i, m.start());
/* 373 */       String tValue = (String)values.get(m.group(1));
/* 374 */       if (tValue != null) b.append(tValue);
/* 375 */       i = m.end();
/*     */     }
/* 377 */     b.append(this.normalizedTemplate, i, this.normalizedTemplate.length());
/* 378 */     return b.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String createURI(String... values)
/*     */   {
/* 393 */     return createURI(values, 0, values.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String createURI(String[] values, int offset, int length)
/*     */   {
/* 410 */     Map<String, String> mapValues = new HashMap();
/* 411 */     StringBuilder b = new StringBuilder();
/*     */     
/* 413 */     Matcher m = TEMPLATE_NAMES_PATTERN.matcher(this.normalizedTemplate);
/* 414 */     int v = offset;
/* 415 */     length += offset;
/* 416 */     int i = 0;
/* 417 */     while (m.find()) {
/* 418 */       b.append(this.normalizedTemplate, i, m.start());
/* 419 */       String tVariable = m.group(1);
/*     */       
/*     */ 
/*     */ 
/* 423 */       String tValue = (String)mapValues.get(tVariable);
/* 424 */       if (tValue != null) {
/* 425 */         b.append(tValue);
/*     */       }
/* 427 */       else if (v < length) {
/* 428 */         tValue = values[(v++)];
/* 429 */         if (tValue != null) {
/* 430 */           mapValues.put(tVariable, tValue);
/* 431 */           b.append(tValue);
/*     */         }
/*     */       }
/*     */       
/* 435 */       i = m.end();
/*     */     }
/* 437 */     b.append(this.normalizedTemplate, i, this.normalizedTemplate.length());
/* 438 */     return b.toString();
/*     */   }
/*     */   
/*     */   public final String toString()
/*     */   {
/* 443 */     return this.pattern.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int hashCode()
/*     */   {
/* 453 */     return this.pattern.hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean equals(Object o)
/*     */   {
/* 464 */     if ((o instanceof UriTemplate)) {
/* 465 */       UriTemplate that = (UriTemplate)o;
/* 466 */       return this.pattern.equals(that.pattern);
/*     */     }
/* 468 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String createURI(String scheme, String userInfo, String host, String port, String path, String query, String fragment, Map<String, ? extends Object> values, boolean encode)
/*     */   {
/* 496 */     return createURI(scheme, null, userInfo, host, port, path, query, fragment, values, encode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String createURI(String scheme, String authority, String userInfo, String host, String port, String path, String query, String fragment, Map<String, ? extends Object> values, boolean encode)
/*     */   {
/* 526 */     Map<String, String> stringValues = new HashMap();
/* 527 */     for (Map.Entry<String, ? extends Object> e : values.entrySet()) {
/* 528 */       if (e.getValue() != null) {
/* 529 */         stringValues.put(e.getKey(), e.getValue().toString());
/*     */       }
/*     */     }
/* 532 */     return createURIWithStringValues(scheme, authority, userInfo, host, port, path, query, fragment, stringValues, encode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String createURIWithStringValues(String scheme, String userInfo, String host, String port, String path, String query, String fragment, Map<String, ? extends Object> values, boolean encode)
/*     */   {
/* 561 */     return createURIWithStringValues(scheme, null, userInfo, host, port, path, query, fragment, values, encode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String createURIWithStringValues(String scheme, String authority, String userInfo, String host, String port, String path, String query, String fragment, Map<String, ? extends Object> values, boolean encode)
/*     */   {
/* 593 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 595 */     if (scheme != null) {
/* 596 */       createURIComponent(UriComponent.Type.SCHEME, scheme, values, false, sb).append(':');
/*     */     }
/*     */     
/* 599 */     if ((userInfo != null) || (host != null) || (port != null)) {
/* 600 */       sb.append("//");
/*     */       
/* 602 */       if ((userInfo != null) && (userInfo.length() > 0)) {
/* 603 */         createURIComponent(UriComponent.Type.USER_INFO, userInfo, values, encode, sb).append('@');
/*     */       }
/*     */       
/* 606 */       if (host != null)
/*     */       {
/* 608 */         createURIComponent(UriComponent.Type.HOST, host, values, encode, sb);
/*     */       }
/*     */       
/* 611 */       if ((port != null) && (port.length() > 0)) {
/* 612 */         sb.append(':');
/* 613 */         createURIComponent(UriComponent.Type.PORT, port, values, false, sb);
/*     */       }
/* 615 */     } else if (authority != null) {
/* 616 */       sb.append("//");
/*     */       
/* 618 */       createURIComponent(UriComponent.Type.AUTHORITY, authority, values, encode, sb);
/*     */     }
/*     */     
/* 621 */     if (path != null) {
/* 622 */       createURIComponent(UriComponent.Type.PATH, path, values, encode, sb);
/*     */     }
/* 624 */     if ((query != null) && (query.length() > 0)) {
/* 625 */       sb.append('?');
/* 626 */       createURIComponent(UriComponent.Type.QUERY_PARAM, query, values, encode, sb);
/*     */     }
/*     */     
/* 629 */     if ((fragment != null) && (fragment.length() > 0)) {
/* 630 */       sb.append('#');
/* 631 */       createURIComponent(UriComponent.Type.FRAGMENT, fragment, values, encode, sb);
/*     */     }
/* 633 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static StringBuilder createURIComponent(UriComponent.Type t, String template, Map<String, ? extends Object> values, boolean encode, StringBuilder b)
/*     */   {
/* 641 */     if (template.indexOf('{') == -1) {
/* 642 */       b.append(template);
/* 643 */       return b;
/*     */     }
/*     */     
/*     */ 
/* 647 */     template = new UriTemplateParser(template).getNormalizedTemplate();
/* 648 */     Matcher m = TEMPLATE_NAMES_PATTERN.matcher(template);
/*     */     
/* 650 */     int i = 0;
/* 651 */     while (m.find()) {
/* 652 */       b.append(template, i, m.start());
/* 653 */       Object tValue = values.get(m.group(1));
/* 654 */       if (tValue != null) {
/* 655 */         if (encode) {
/* 656 */           tValue = UriComponent.encode(tValue.toString(), t);
/*     */         } else
/* 658 */           tValue = UriComponent.contextualEncode(tValue.toString(), t);
/* 659 */         b.append(tValue);
/*     */       } else {
/* 661 */         throw templateVariableHasNoValue(m.group(1));
/*     */       }
/* 663 */       i = m.end();
/*     */     }
/* 665 */     b.append(template, i, template.length());
/* 666 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String createURI(String scheme, String userInfo, String host, String port, String path, String query, String fragment, Object[] values, boolean encode)
/*     */   {
/* 694 */     return createURI(scheme, null, userInfo, host, port, path, query, fragment, values, encode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String createURI(String scheme, String authority, String userInfo, String host, String port, String path, String query, String fragment, Object[] values, boolean encode)
/*     */   {
/* 727 */     String[] stringValues = new String[values.length];
/* 728 */     for (int i = 0; i < values.length; i++) {
/* 729 */       if (values[i] != null) {
/* 730 */         stringValues[i] = values[i].toString();
/*     */       }
/*     */     }
/* 733 */     return createURIWithStringValues(scheme, authority, userInfo, host, port, path, query, fragment, stringValues, encode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String createURIWithStringValues(String scheme, String userInfo, String host, String port, String path, String query, String fragment, String[] values, boolean encode)
/*     */   {
/* 760 */     return createURIWithStringValues(scheme, null, userInfo, host, port, path, query, fragment, values, encode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String createURIWithStringValues(String scheme, String authority, String userInfo, String host, String port, String path, String query, String fragment, String[] values, boolean encode)
/*     */   {
/* 790 */     Map<String, String> mapValues = new HashMap();
/* 791 */     StringBuilder sb = new StringBuilder();
/* 792 */     int offset = 0;
/*     */     
/* 794 */     if (scheme != null) {
/* 795 */       offset = createURIComponent(UriComponent.Type.SCHEME, scheme, values, offset, false, mapValues, sb);
/*     */       
/* 797 */       sb.append(':');
/*     */     }
/*     */     
/* 800 */     if ((userInfo != null) || (host != null) || (port != null)) {
/* 801 */       sb.append("//");
/*     */       
/* 803 */       if ((userInfo != null) && (userInfo.length() > 0)) {
/* 804 */         offset = createURIComponent(UriComponent.Type.USER_INFO, userInfo, values, offset, encode, mapValues, sb);
/*     */         
/* 806 */         sb.append('@');
/*     */       }
/*     */       
/* 809 */       if (host != null)
/*     */       {
/* 811 */         offset = createURIComponent(UriComponent.Type.HOST, host, values, offset, encode, mapValues, sb);
/*     */       }
/*     */       
/*     */ 
/* 815 */       if ((port != null) && (port.length() > 0)) {
/* 816 */         sb.append(':');
/* 817 */         offset = createURIComponent(UriComponent.Type.PORT, port, values, offset, false, mapValues, sb);
/*     */       }
/*     */     }
/* 820 */     else if (authority != null) {
/* 821 */       sb.append("//");
/*     */       
/* 823 */       offset = createURIComponent(UriComponent.Type.AUTHORITY, authority, values, offset, encode, mapValues, sb);
/*     */     }
/*     */     
/*     */ 
/* 827 */     if (path != null) {
/* 828 */       offset = createURIComponent(UriComponent.Type.PATH, path, values, offset, encode, mapValues, sb);
/*     */     }
/*     */     
/* 831 */     if ((query != null) && (query.length() > 0)) {
/* 832 */       sb.append('?');
/* 833 */       offset = createURIComponent(UriComponent.Type.QUERY_PARAM, query, values, offset, encode, mapValues, sb);
/*     */     }
/*     */     
/*     */ 
/* 837 */     if ((fragment != null) && (fragment.length() > 0)) {
/* 838 */       sb.append('#');
/* 839 */       offset = createURIComponent(UriComponent.Type.FRAGMENT, fragment, values, offset, encode, mapValues, sb);
/*     */     }
/*     */     
/* 842 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int createURIComponent(UriComponent.Type t, String template, String[] values, int offset, boolean encode, Map<String, String> mapValues, StringBuilder b)
/*     */   {
/* 851 */     if (template.indexOf('{') == -1) {
/* 852 */       b.append(template);
/* 853 */       return offset;
/*     */     }
/*     */     
/*     */ 
/* 857 */     template = new UriTemplateParser(template).getNormalizedTemplate();
/* 858 */     Matcher m = TEMPLATE_NAMES_PATTERN.matcher(template);
/* 859 */     int v = offset;
/* 860 */     int i = 0;
/* 861 */     while (m.find()) {
/* 862 */       b.append(template, i, m.start());
/* 863 */       String tVariable = m.group(1);
/*     */       
/*     */ 
/*     */ 
/* 867 */       String tValue = (String)mapValues.get(tVariable);
/* 868 */       if (tValue != null) {
/* 869 */         b.append(tValue);
/* 870 */       } else if (v < values.length) {
/* 871 */         tValue = values[(v++)];
/* 872 */         if (tValue != null) {
/* 873 */           if (encode) {
/* 874 */             tValue = UriComponent.encode(tValue, t);
/*     */           } else
/* 876 */             tValue = UriComponent.contextualEncode(tValue, t);
/* 877 */           mapValues.put(tVariable, tValue);
/* 878 */           b.append(tValue);
/*     */         } else {
/* 880 */           throw templateVariableHasNoValue(tVariable);
/*     */         }
/*     */       } else {
/* 883 */         throw templateVariableHasNoValue(tVariable);
/*     */       }
/* 885 */       i = m.end();
/*     */     }
/* 887 */     b.append(template, i, template.length());
/* 888 */     return v;
/*     */   }
/*     */   
/*     */   private static IllegalArgumentException templateVariableHasNoValue(String tVariable) {
/* 892 */     return new IllegalArgumentException("The template variable, " + tVariable + ", has no value");
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\api\uri\UriTemplate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */