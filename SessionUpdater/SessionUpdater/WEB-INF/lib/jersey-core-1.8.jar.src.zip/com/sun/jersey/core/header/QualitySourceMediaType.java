/*     */ package com.sun.jersey.core.header;
/*     */ 
/*     */ import com.sun.jersey.core.header.reader.HttpHeaderReader;
/*     */ import java.text.ParseException;
/*     */ import java.util.Map;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QualitySourceMediaType
/*     */   extends MediaType
/*     */ {
/*     */   public static final String QUALITY_SOURCE_FACTOR = "qs";
/*     */   public static final int DEFAULT_QUALITY_SOURCE_FACTOR = 1000;
/*     */   private final int qs;
/*     */   
/*     */   public QualitySourceMediaType(String p, String s)
/*     */   {
/*  62 */     super(p, s);
/*  63 */     this.qs = 1000;
/*     */   }
/*     */   
/*     */   public QualitySourceMediaType(String p, String s, int qs, Map<String, String> parameters) {
/*  67 */     super(p, s, parameters);
/*  68 */     this.qs = qs;
/*     */   }
/*     */   
/*     */   public QualitySourceMediaType(MediaType mt) {
/*  72 */     this(mt.getType(), mt.getSubtype(), getQs(mt), mt.getParameters());
/*     */   }
/*     */   
/*     */   public int getQualitySource() {
/*  76 */     return this.qs;
/*     */   }
/*     */   
/*     */   public static QualitySourceMediaType valueOf(HttpHeaderReader reader) throws ParseException
/*     */   {
/*  81 */     reader.hasNext();
/*     */     
/*     */ 
/*  84 */     String type = reader.nextToken();
/*  85 */     reader.nextSeparator('/');
/*     */     
/*  87 */     String subType = reader.nextToken();
/*     */     
/*  89 */     int qs = 1000;
/*  90 */     Map<String, String> parameters = null;
/*  91 */     if (reader.hasNext()) {
/*  92 */       parameters = HttpHeaderReader.readParameters(reader);
/*  93 */       if (parameters != null) {
/*  94 */         qs = getQs((String)parameters.get("qs"));
/*     */       }
/*     */     }
/*     */     
/*  98 */     return new QualitySourceMediaType(type, subType, qs, parameters);
/*     */   }
/*     */   
/*     */   public static int getQualitySource(MediaType mt) {
/* 102 */     if ((mt instanceof QualitySourceMediaType)) {
/* 103 */       QualitySourceMediaType qsmt = (QualitySourceMediaType)mt;
/* 104 */       return qsmt.getQualitySource();
/*     */     }
/* 106 */     return getQs(mt);
/*     */   }
/*     */   
/*     */   private static int getQs(MediaType mt)
/*     */   {
/*     */     try {
/* 112 */       return getQs((String)mt.getParameters().get("qs"));
/*     */     } catch (ParseException ex) {
/* 114 */       throw new IllegalArgumentException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private static int getQs(String v) throws ParseException {
/* 119 */     if (v == null) {
/* 120 */       return 1000;
/*     */     }
/*     */     try {
/* 123 */       int qs = (int)(Float.valueOf(v).floatValue() * 1000.0D);
/* 124 */       if (qs < 0)
/* 125 */         throw new ParseException("The quality source (qs) value, " + v + ", must be non-negative number", 0);
/* 126 */       return qs;
/*     */     } catch (NumberFormatException ex) {
/* 128 */       ParseException pe = new ParseException("The quality source (qs) value, " + v + ", is not a valid value", 0);
/* 129 */       pe.initCause(ex);
/* 130 */       throw pe;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\header\QualitySourceMediaType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */