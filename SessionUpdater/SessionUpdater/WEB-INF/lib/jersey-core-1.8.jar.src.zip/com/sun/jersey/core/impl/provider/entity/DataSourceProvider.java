/*     */ package com.sun.jersey.core.impl.provider.entity;
/*     */ 
/*     */ import com.sun.jersey.core.provider.AbstractMessageReaderWriterProvider;
/*     */ import com.sun.jersey.core.util.ReaderWriter;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import javax.activation.DataSource;
/*     */ import javax.ws.rs.Consumes;
/*     */ import javax.ws.rs.Produces;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Produces({"application/octet-stream", "*/*"})
/*     */ @Consumes({"application/octet-stream", "*/*"})
/*     */ public class DataSourceProvider
/*     */   extends AbstractMessageReaderWriterProvider<DataSource>
/*     */ {
/*     */   public static class ByteArrayDataSource
/*     */     implements DataSource
/*     */   {
/*     */     private byte[] data;
/*  80 */     private int len = -1;
/*     */     private String type;
/*  82 */     private String name = "";
/*     */     
/*     */     static class DSByteArrayOutputStream extends ByteArrayOutputStream {
/*     */       public byte[] getBuf() {
/*  86 */         return this.buf;
/*     */       }
/*     */       
/*     */       public int getCount() {
/*  90 */         return this.count;
/*     */       }
/*     */     }
/*     */     
/*     */     public ByteArrayDataSource(InputStream is, String type) throws IOException {
/*  95 */       DSByteArrayOutputStream os = new DSByteArrayOutputStream();
/*  96 */       ReaderWriter.writeTo(is, os);
/*  97 */       this.data = os.getBuf();
/*  98 */       this.len = os.getCount();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */       if (this.data.length - this.len > 262144) {
/* 108 */         this.data = os.toByteArray();
/* 109 */         this.len = this.data.length;
/*     */       }
/* 111 */       this.type = type;
/*     */     }
/*     */     
/*     */     public InputStream getInputStream() throws IOException {
/* 115 */       if (this.data == null)
/* 116 */         throw new IOException("no data");
/* 117 */       if (this.len < 0)
/* 118 */         this.len = this.data.length;
/* 119 */       return new ByteArrayInputStream(this.data, 0, this.len);
/*     */     }
/*     */     
/*     */     public OutputStream getOutputStream() throws IOException {
/* 123 */       throw new IOException("cannot do this");
/*     */     }
/*     */     
/*     */     public String getContentType() {
/* 127 */       return this.type;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 131 */       return this.name;
/*     */     }
/*     */     
/*     */     public void setName(String name) {
/* 135 */       this.name = name;
/*     */     }
/*     */   }
/*     */   
/*     */   public DataSourceProvider() {
/* 140 */     Class<?> c = DataSource.class;
/*     */   }
/*     */   
/*     */   public boolean isReadable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
/* 144 */     return DataSource.class == type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataSource readFrom(Class<DataSource> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, String> httpHeaders, InputStream entityStream)
/*     */     throws IOException
/*     */   {
/* 154 */     ByteArrayDataSource ds = new ByteArrayDataSource(entityStream, mediaType == null ? null : mediaType.toString());
/*     */     
/* 156 */     return ds;
/*     */   }
/*     */   
/*     */   public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
/* 160 */     return DataSource.class.isAssignableFrom(type);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeTo(DataSource t, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, OutputStream entityStream)
/*     */     throws IOException
/*     */   {
/* 171 */     InputStream in = t.getInputStream();
/*     */     try {
/* 173 */       writeTo(in, entityStream);
/*     */     } finally {
/* 175 */       in.close();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\entity\DataSourceProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */