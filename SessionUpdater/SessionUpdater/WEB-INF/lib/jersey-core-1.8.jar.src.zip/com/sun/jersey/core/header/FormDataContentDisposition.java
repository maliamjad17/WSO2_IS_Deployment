/*     */ package com.sun.jersey.core.header;
/*     */ 
/*     */ import com.sun.jersey.core.header.reader.HttpHeaderReader;
/*     */ import java.text.ParseException;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormDataContentDisposition
/*     */   extends ContentDisposition
/*     */ {
/*     */   private String name;
/*     */   
/*     */   protected FormDataContentDisposition(String type, String name, String fileName, Date creationDate, Date modificationDate, Date readDate, long size)
/*     */   {
/*  72 */     super(type, fileName, creationDate, modificationDate, readDate, size);
/*  73 */     this.name = name;
/*     */     
/*  75 */     if (!getType().equalsIgnoreCase("form-data")) {
/*  76 */       throw new IllegalArgumentException("The content dispostion type is not equal to form-data");
/*     */     }
/*     */     
/*  79 */     if (name == null) {
/*  80 */       throw new IllegalArgumentException("The name parameter is not present");
/*     */     }
/*     */   }
/*     */   
/*     */   public FormDataContentDisposition(String header) throws ParseException {
/*  85 */     this(HttpHeaderReader.newInstance(header));
/*     */   }
/*     */   
/*     */   public FormDataContentDisposition(HttpHeaderReader reader) throws ParseException {
/*  89 */     super(reader);
/*  90 */     if (!getType().equalsIgnoreCase("form-data")) {
/*  91 */       throw new IllegalArgumentException("The content dispostion type is not equal to form-data");
/*     */     }
/*     */     
/*  94 */     this.name = ((String)getParameters().get("name"));
/*  95 */     if (this.name == null) {
/*  96 */       throw new IllegalArgumentException("The name parameter is not present");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 106 */     return this.name;
/*     */   }
/*     */   
/*     */   protected StringBuilder toStringBuffer()
/*     */   {
/* 111 */     StringBuilder sb = super.toStringBuffer();
/*     */     
/* 113 */     addStringParameter(sb, "name", this.name);
/*     */     
/* 115 */     return sb;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static FormDataContentDispositionBuilder name(String name)
/*     */   {
/* 125 */     return new FormDataContentDispositionBuilder(name);
/*     */   }
/*     */   
/*     */ 
/*     */   public static class FormDataContentDispositionBuilder
/*     */     extends ContentDisposition.ContentDispositionBuilder<FormDataContentDispositionBuilder, FormDataContentDisposition>
/*     */   {
/*     */     private String name;
/*     */     
/*     */     FormDataContentDispositionBuilder(String name)
/*     */     {
/* 136 */       super();
/* 137 */       this.name = name;
/*     */     }
/*     */     
/*     */     public FormDataContentDisposition build()
/*     */     {
/* 142 */       FormDataContentDisposition cd = new FormDataContentDisposition(this.type, this.name, this.fileName, this.creationDate, this.modificationDate, this.readDate, this.size);
/* 143 */       return cd;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\header\FormDataContentDisposition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */