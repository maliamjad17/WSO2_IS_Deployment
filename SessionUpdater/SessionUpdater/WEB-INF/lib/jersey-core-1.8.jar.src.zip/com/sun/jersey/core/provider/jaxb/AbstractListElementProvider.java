/*     */ package com.sun.jersey.core.provider.jaxb;
/*     */ 
/*     */ import com.sun.jersey.core.impl.provider.entity.Inflector;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import javax.ws.rs.WebApplicationException;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.core.Response.Status;
/*     */ import javax.ws.rs.ext.Providers;
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.Marshaller;
/*     */ import javax.xml.bind.UnmarshalException;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractListElementProvider
/*     */   extends AbstractJAXBProvider<Object>
/*     */ {
/*     */   public AbstractListElementProvider(Providers ps)
/*     */   {
/* 100 */     super(ps);
/*     */   }
/*     */   
/*     */   public AbstractListElementProvider(Providers ps, MediaType mt) {
/* 104 */     super(ps, mt);
/*     */   }
/*     */   
/*     */   public boolean isReadable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType)
/*     */   {
/* 109 */     if ((type == List.class) || (type == Collection.class))
/* 110 */       return (verifyGenericType(genericType)) && (isSupported(mediaType));
/* 111 */     if (type.isArray()) {
/* 112 */       return (verifyArrayType(type)) && (isSupported(mediaType));
/*     */     }
/* 114 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType)
/*     */   {
/* 119 */     if (List.class.isAssignableFrom(type))
/* 120 */       return (verifyGenericType(genericType)) && (isSupported(mediaType));
/* 121 */     if (type.isArray()) {
/* 122 */       return (verifyArrayType(type)) && (isSupported(mediaType));
/*     */     }
/* 124 */     return false;
/*     */   }
/*     */   
/*     */   private boolean verifyArrayType(Class type) {
/* 128 */     type = type.getComponentType();
/*     */     
/* 130 */     return (type.isAnnotationPresent(XmlRootElement.class)) || (type.isAnnotationPresent(XmlType.class)) || (JAXBElement.class.isAssignableFrom(type));
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean verifyGenericType(Type genericType)
/*     */   {
/* 136 */     if (!(genericType instanceof ParameterizedType)) { return false;
/*     */     }
/* 138 */     ParameterizedType pt = (ParameterizedType)genericType;
/*     */     
/* 140 */     if (pt.getActualTypeArguments().length > 1) { return false;
/*     */     }
/* 142 */     Type ta = pt.getActualTypeArguments()[0];
/*     */     
/* 144 */     if ((ta instanceof ParameterizedType)) {
/* 145 */       ParameterizedType lpt = (ParameterizedType)ta;
/* 146 */       return ((lpt.getRawType() instanceof Class)) && (JAXBElement.class.isAssignableFrom((Class)lpt.getRawType()));
/*     */     }
/*     */     
/*     */ 
/* 150 */     if (!(pt.getActualTypeArguments()[0] instanceof Class)) { return false;
/*     */     }
/* 152 */     Class listClass = (Class)pt.getActualTypeArguments()[0];
/*     */     
/* 154 */     return (listClass.isAnnotationPresent(XmlRootElement.class)) || (listClass.isAnnotationPresent(XmlType.class));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void writeTo(Object t, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, OutputStream entityStream)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 168 */       Collection c = type.isArray() ? Arrays.asList((Object[])t) : (Collection)t;
/*     */       
/*     */ 
/* 171 */       Class elementType = getElementClass(type, genericType);
/* 172 */       Charset charset = getCharset(mediaType);
/* 173 */       String charsetName = charset.name();
/*     */       
/* 175 */       Marshaller m = getMarshaller(elementType, mediaType);
/* 176 */       m.setProperty("jaxb.fragment", Boolean.valueOf(true));
/* 177 */       if (charset != UTF8) {
/* 178 */         m.setProperty("jaxb.encoding", charsetName);
/*     */       }
/* 180 */       setHeader(m, annotations);
/* 181 */       writeList(elementType, c, mediaType, charset, m, entityStream);
/*     */     } catch (JAXBException ex) {
/* 183 */       throw new WebApplicationException(ex, Response.Status.INTERNAL_SERVER_ERROR);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writeList(Class<?> paramClass, Collection<?> paramCollection, MediaType paramMediaType, Charset paramCharset, Marshaller paramMarshaller, OutputStream paramOutputStream)
/*     */     throws JAXBException, IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Object readFrom(Class<Object> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, String> httpHeaders, InputStream entityStream)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 213 */       Class elementType = getElementClass(type, genericType);
/* 214 */       Unmarshaller u = getUnmarshaller(elementType, mediaType);
/* 215 */       XMLStreamReader r = getXMLStreamReader(elementType, mediaType, u, entityStream);
/* 216 */       List l = new ArrayList();
/* 217 */       boolean jaxbElement = false;
/*     */       
/*     */ 
/* 220 */       int event = r.next();
/* 221 */       while (event != 1) {
/* 222 */         event = r.next();
/*     */       }
/*     */       
/* 225 */       event = r.next();
/*     */       
/* 227 */       while ((event != 1) && (event != 8)) {
/* 228 */         event = r.next();
/*     */       }
/* 230 */       for (; event != 8; 
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 244 */           goto 210)
/*     */       {
/* 231 */         if (elementType.isAnnotationPresent(XmlRootElement.class)) {
/* 232 */           l.add(u.unmarshal(r));
/* 233 */         } else if (elementType.isAnnotationPresent(XmlType.class)) {
/* 234 */           l.add(u.unmarshal(r, elementType).getValue());
/*     */         } else {
/* 236 */           l.add(u.unmarshal(r, elementType));
/* 237 */           jaxbElement = true;
/*     */         }
/*     */         
/*     */ 
/* 241 */         event = r.getEventType();
/*     */         
/* 243 */         if ((event != 1) && (event != 8)) {
/* 244 */           event = r.next();
/*     */         }
/*     */       }
/* 247 */       return type.isArray() ? createArray(l, jaxbElement ? JAXBElement.class : elementType) : l;
/*     */     }
/*     */     catch (UnmarshalException ex)
/*     */     {
/* 251 */       throw new WebApplicationException(ex, Response.Status.BAD_REQUEST);
/*     */     } catch (XMLStreamException ex) {
/* 253 */       throw new WebApplicationException(ex, Response.Status.BAD_REQUEST);
/*     */     } catch (JAXBException ex) {
/* 255 */       throw new WebApplicationException(ex, Response.Status.INTERNAL_SERVER_ERROR);
/*     */     }
/*     */   }
/*     */   
/*     */   private Object createArray(List l, Class componentType) {
/* 260 */     Object array = Array.newInstance(componentType, l.size());
/* 261 */     for (int i = 0; i < l.size(); i++)
/* 262 */       Array.set(array, i, l.get(i));
/* 263 */     return array;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract XMLStreamReader getXMLStreamReader(Class<?> paramClass, MediaType paramMediaType, Unmarshaller paramUnmarshaller, InputStream paramInputStream)
/*     */     throws XMLStreamException;
/*     */   
/*     */ 
/*     */ 
/*     */   protected Class getElementClass(Class<?> type, Type genericType)
/*     */   {
/*     */     Type ta;
/*     */     
/*     */ 
/*     */     Type ta;
/*     */     
/*     */ 
/* 282 */     if ((genericType instanceof ParameterizedType))
/*     */     {
/* 284 */       ta = ((ParameterizedType)genericType).getActualTypeArguments()[0]; } else { Type ta;
/* 285 */       if ((genericType instanceof GenericArrayType))
/*     */       {
/* 287 */         ta = ((GenericArrayType)genericType).getGenericComponentType();
/*     */       }
/*     */       else
/* 290 */         ta = type.getComponentType();
/*     */     }
/* 292 */     if ((ta instanceof ParameterizedType))
/*     */     {
/* 294 */       ta = ((ParameterizedType)ta).getActualTypeArguments()[0];
/*     */     }
/* 296 */     return (Class)ta;
/*     */   }
/*     */   
/* 299 */   private final Inflector inflector = Inflector.getInstance();
/*     */   
/*     */   private String convertToXmlName(String name) {
/* 302 */     return name.replace("$", "_");
/*     */   }
/*     */   
/*     */   protected final String getRootElementName(Class<?> elementType) {
/* 306 */     if (isXmlRootElementProcessing()) {
/* 307 */       return convertToXmlName(this.inflector.pluralize(this.inflector.demodulize(getElementName(elementType))));
/*     */     }
/* 309 */     return convertToXmlName(this.inflector.decapitalize(this.inflector.pluralize(this.inflector.demodulize(elementType.getName()))));
/*     */   }
/*     */   
/*     */   protected final String getElementName(Class<?> elementType)
/*     */   {
/* 314 */     String name = elementType.getName();
/* 315 */     XmlRootElement xre = (XmlRootElement)elementType.getAnnotation(XmlRootElement.class);
/* 316 */     if ((xre != null) && (!xre.name().equals("##default"))) {
/* 317 */       name = xre.name();
/*     */     }
/* 319 */     return name;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\provider\jaxb\AbstractListElementProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */