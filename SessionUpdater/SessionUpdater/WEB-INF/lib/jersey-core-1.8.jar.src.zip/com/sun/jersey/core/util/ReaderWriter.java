/*     */ package com.sun.jersey.core.util;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Map;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReaderWriter
/*     */ {
/*  67 */   public static final Charset UTF8 = Charset.forName("UTF-8");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String BUFFER_SIZE_SYSTEM_PROPERTY = "com.sun.jersey.core.util.ReaderWriter.BufferSize";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int DEFAULT_BUFFER_SIZE = 8192;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  87 */   public static final int BUFFER_SIZE = getBufferSize();
/*     */   
/*     */   private static int getBufferSize()
/*     */   {
/*  91 */     String v = System.getProperty("com.sun.jersey.core.util.ReaderWriter.BufferSize", Integer.toString(8192));
/*     */     
/*     */     try
/*     */     {
/*  95 */       int i = Integer.valueOf(v).intValue();
/*  96 */       if (i <= 0)
/*  97 */         throw new NumberFormatException();
/*  98 */       return i;
/*     */     } catch (NumberFormatException ex) {}
/* 100 */     return 8192;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void writeTo(InputStream in, OutputStream out)
/*     */     throws IOException
/*     */   {
/* 113 */     byte[] data = new byte[BUFFER_SIZE];
/* 114 */     int read; while ((read = in.read(data)) != -1) {
/* 115 */       out.write(data, 0, read);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void writeTo(Reader in, Writer out)
/*     */     throws IOException
/*     */   {
/* 127 */     char[] data = new char[BUFFER_SIZE];
/* 128 */     int read; while ((read = in.read(data)) != -1) {
/* 129 */       out.write(data, 0, read);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final Charset getCharset(MediaType m)
/*     */   {
/* 142 */     String name = m == null ? null : (String)m.getParameters().get("charset");
/* 143 */     return name == null ? UTF8 : Charset.forName(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String readFromAsString(InputStream in, MediaType type)
/*     */     throws IOException
/*     */   {
/* 157 */     return readFromAsString(new InputStreamReader(in, getCharset(type)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String readFromAsString(Reader reader)
/*     */     throws IOException
/*     */   {
/* 168 */     StringBuilder sb = new StringBuilder();
/* 169 */     char[] c = new char[BUFFER_SIZE];
/*     */     int l;
/* 171 */     while ((l = reader.read(c)) != -1) {
/* 172 */       sb.append(c, 0, l);
/*     */     }
/* 174 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void writeToAsString(String s, OutputStream out, MediaType type)
/*     */     throws IOException
/*     */   {
/* 188 */     Writer osw = new BufferedWriter(new OutputStreamWriter(out, getCharset(type)));
/*     */     
/* 190 */     osw.write(s);
/* 191 */     osw.flush();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\util\ReaderWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */