/*    */ package com.sun.jersey.core.header;
/*    */ 
/*    */ import com.sun.jersey.core.header.reader.HttpHeaderReader;
/*    */ import com.sun.jersey.core.header.reader.HttpHeaderReader.Event;
/*    */ import java.text.ParseException;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import javax.ws.rs.core.EntityTag;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MatchingEntityTag
/*    */   extends EntityTag
/*    */ {
/* 66 */   public static final Set<MatchingEntityTag> ANY_MATCH = ;
/*    */   
/*    */   public MatchingEntityTag(String value) {
/* 69 */     super(value, false);
/*    */   }
/*    */   
/*    */   public MatchingEntityTag(String value, boolean weak) {
/* 73 */     super(value, weak);
/*    */   }
/*    */   
/*    */   public static MatchingEntityTag valueOf(HttpHeaderReader reader) throws ParseException {
/* 77 */     HttpHeaderReader.Event e = reader.next(false);
/* 78 */     if (e == HttpHeaderReader.Event.QuotedString)
/* 79 */       return new MatchingEntityTag(reader.getEventValue());
/* 80 */     if (e == HttpHeaderReader.Event.Token) {
/* 81 */       String v = reader.getEventValue();
/* 82 */       if (v.equals("W")) {
/* 83 */         reader.nextSeparator('/');
/* 84 */         return new MatchingEntityTag(reader.nextQuotedString(), true);
/*    */       }
/*    */     }
/*    */     
/* 88 */     throw new ParseException("Error parsing entity tag", reader.getIndex());
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\header\MatchingEntityTag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */