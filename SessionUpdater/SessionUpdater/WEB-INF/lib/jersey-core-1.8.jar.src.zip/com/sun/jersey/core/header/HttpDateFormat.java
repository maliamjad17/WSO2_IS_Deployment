/*     */ package com.sun.jersey.core.header;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpDateFormat
/*     */ {
/*     */   private static final String RFC1123_DATE_FORMAT_PATTERN = "EEE, dd MMM yyyy HH:mm:ss zzz";
/*     */   private static final String RFC1036_DATE_FORMAT_PATTERN = "EEEE, dd-MMM-yy HH:mm:ss zzz";
/*     */   private static final String ANSI_C_ASCTIME_DATE_FORMAT_PATTERN = "EEE MMM d HH:mm:ss yyyy";
/*  77 */   private static ThreadLocal<List<SimpleDateFormat>> dateFormats = new ThreadLocal()
/*     */   {
/*     */     protected synchronized List<SimpleDateFormat> initialValue() {
/*  80 */       return HttpDateFormat.access$000();
/*     */     }
/*     */   };
/*     */   
/*     */   private static List<SimpleDateFormat> createDateFormats() {
/*  85 */     SimpleDateFormat[] dateFormats = { new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US), new SimpleDateFormat("EEEE, dd-MMM-yy HH:mm:ss zzz", Locale.US), new SimpleDateFormat("EEE MMM d HH:mm:ss yyyy", Locale.US) };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  91 */     TimeZone tz = TimeZone.getTimeZone("GMT");
/*  92 */     dateFormats[0].setTimeZone(tz);
/*  93 */     dateFormats[1].setTimeZone(tz);
/*  94 */     dateFormats[2].setTimeZone(tz);
/*     */     
/*  96 */     return Collections.unmodifiableList(Arrays.asList(dateFormats));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<SimpleDateFormat> getDateFormats()
/*     */   {
/* 110 */     return (List)dateFormats.get();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SimpleDateFormat getPreferedDateFormat()
/*     */   {
/* 123 */     return (SimpleDateFormat)((List)dateFormats.get()).get(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Date readDate(String date)
/*     */     throws ParseException
/*     */   {
/* 135 */     ParseException pe = null;
/* 136 */     for (SimpleDateFormat f : getDateFormats()) {
/*     */       try {
/* 138 */         return f.parse(date);
/*     */       } catch (ParseException e) {
/* 140 */         pe = pe == null ? e : pe;
/*     */       }
/*     */     }
/*     */     
/* 144 */     throw pe;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\header\HttpDateFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */