/*     */ package com.sun.jersey.core.header.reader;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class HttpHeaderReaderImpl
/*     */   extends HttpHeaderReader
/*     */ {
/*     */   private static final int TOKEN = 0;
/*     */   private static final int QUOTED_STRING = 1;
/*     */   private static final int COMMENT = 2;
/*     */   private static final int SEPARATOR = 3;
/*     */   private static final int CONTROL = 4;
/*  55 */   private static final char[] WHITE_SPACE = { '\t', '\r', '\n', ' ' };
/*  56 */   private static final char[] SEPARATORS = { '(', ')', '<', '>', '@', ',', ';', ':', '\\', '"', '/', '[', ']', '?', '=', '{', '}', ' ', '\t' };
/*  57 */   private static final int[] EVENT_TABLE = createEventTable();
/*     */   
/*     */   private static int[] createEventTable() {
/*  60 */     int[] table = new int[''];
/*     */     
/*     */ 
/*  63 */     for (int i = 0; i < 127; i++) {
/*  64 */       table[i] = 0;
/*     */     }
/*     */     
/*     */ 
/*  68 */     for (char c : SEPARATORS) {
/*  69 */       table[c] = 3;
/*     */     }
/*     */     
/*     */ 
/*  73 */     table[40] = 2;
/*     */     
/*     */ 
/*  76 */     table[34] = 1;
/*     */     
/*     */ 
/*  79 */     for (int i = 0; i < 32; i++) {
/*  80 */       table[i] = 4;
/*     */     }
/*  82 */     table[127] = 4;
/*     */     
/*     */ 
/*  85 */     for (char c : WHITE_SPACE) {
/*  86 */       table[c] = -1;
/*     */     }
/*     */     
/*  89 */     return table;
/*     */   }
/*     */   
/*  92 */   private static final boolean[] IS_WHITE_SPACE = createWhiteSpaceTable();
/*     */   
/*     */   private static boolean[] createWhiteSpaceTable() {
/*  95 */     boolean[] table = new boolean[''];
/*     */     
/*  97 */     for (char c : WHITE_SPACE) {
/*  98 */       table[c] = true;
/*     */     }
/*     */     
/* 101 */     return table;
/*     */   }
/*     */   
/* 104 */   private static final boolean[] IS_TOKEN = createTokenTable();
/*     */   private String header;
/*     */   
/* 107 */   private static boolean[] createTokenTable() { boolean[] table = new boolean[''];
/*     */     
/* 109 */     for (int i = 0; i < 128; i++) {
/* 110 */       table[i] = (EVENT_TABLE[i] == 0 ? 1 : false);
/*     */     }
/*     */     
/* 113 */     return table;
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean processComments;
/*     */   
/*     */   private int index;
/*     */   
/*     */   private int length;
/*     */   
/*     */   private HttpHeaderReader.Event event;
/*     */   
/*     */   private String value;
/*     */   
/*     */   public HttpHeaderReaderImpl(String header, boolean processComments)
/*     */   {
/* 129 */     this.header = (header == null ? "" : header);
/* 130 */     this.processComments = processComments;
/* 131 */     this.index = 0;
/* 132 */     this.length = this.header.length();
/*     */   }
/*     */   
/*     */   public HttpHeaderReaderImpl(String header) {
/* 136 */     this(header, false);
/*     */   }
/*     */   
/*     */   public boolean hasNext() {
/* 140 */     return skipWhiteSpace();
/*     */   }
/*     */   
/*     */   public boolean hasNextSeparator(char separator, boolean skipWhiteSpace) {
/* 144 */     if (skipWhiteSpace) {
/* 145 */       skipWhiteSpace();
/*     */     }
/*     */     
/* 148 */     if (this.index >= this.length) {
/* 149 */       return false;
/*     */     }
/*     */     
/* 152 */     char c = this.header.charAt(this.index);
/* 153 */     return c == separator;
/*     */   }
/*     */   
/*     */   public String nextSeparatedString(char startSeparator, char endSeparator) throws ParseException
/*     */   {
/* 158 */     nextSeparator(startSeparator);
/* 159 */     int start = this.index;
/* 160 */     while ((this.index < this.length) && 
/* 161 */       (this.header.charAt(this.index) != endSeparator)) {
/* 160 */       this.index += 1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 166 */     if (start == this.index)
/*     */     {
/* 168 */       throw new ParseException("No characters between the separators '" + startSeparator + "' and '" + endSeparator + "'", this.index);
/*     */     }
/* 170 */     if (this.index == this.length)
/*     */     {
/* 172 */       throw new ParseException("No end separator '" + endSeparator + "'", this.index);
/*     */     }
/*     */     
/* 175 */     this.event = HttpHeaderReader.Event.Token;
/* 176 */     return this.value = this.header.substring(start, this.index++);
/*     */   }
/*     */   
/*     */   public HttpHeaderReader.Event next() throws ParseException {
/* 180 */     return this.event = process(getNextCharacter(true));
/*     */   }
/*     */   
/*     */   public HttpHeaderReader.Event next(boolean skipWhiteSpace) throws ParseException {
/* 184 */     return this.event = process(getNextCharacter(skipWhiteSpace));
/*     */   }
/*     */   
/*     */   public HttpHeaderReader.Event getEvent() {
/* 188 */     return this.event;
/*     */   }
/*     */   
/*     */   public String getEventValue() {
/* 192 */     return this.value;
/*     */   }
/*     */   
/*     */   public String getRemainder() {
/* 196 */     return this.index < this.length ? this.header.substring(this.index) : null;
/*     */   }
/*     */   
/*     */   public int getIndex() {
/* 200 */     return this.index;
/*     */   }
/*     */   
/*     */   private boolean skipWhiteSpace() {
/* 204 */     for (; this.index < this.length; this.index += 1) {
/* 205 */       if (!isWhiteSpace(this.header.charAt(this.index))) {
/* 206 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 210 */     return false;
/*     */   }
/*     */   
/*     */   private char getNextCharacter(boolean skipWhiteSpace) throws ParseException {
/* 214 */     if (skipWhiteSpace) {
/* 215 */       skipWhiteSpace();
/*     */     }
/*     */     
/* 218 */     if (this.index >= this.length) {
/* 219 */       throw new ParseException("End of header", this.index);
/*     */     }
/*     */     
/* 222 */     return this.header.charAt(this.index);
/*     */   }
/*     */   
/*     */   private HttpHeaderReader.Event process(char c) throws ParseException {
/* 226 */     if (c > '') {
/* 227 */       this.index += 1;
/* 228 */       return HttpHeaderReader.Event.Control;
/*     */     }
/*     */     
/* 231 */     switch (EVENT_TABLE[c]) {
/*     */     case 0: 
/* 233 */       int start = this.index;
/* 234 */       for (this.index += 1; (this.index < this.length) && 
/* 235 */             (isToken(this.header.charAt(this.index))); this.index += 1) {}
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 239 */       this.value = this.header.substring(start, this.index);
/* 240 */       return HttpHeaderReader.Event.Token;
/*     */     
/*     */     case 1: 
/* 243 */       processQuotedString();
/* 244 */       return HttpHeaderReader.Event.QuotedString;
/*     */     case 2: 
/* 246 */       if (!this.processComments) {
/* 247 */         throw new ParseException("Comments are not allowed", this.index);
/*     */       }
/*     */       
/* 250 */       processComment();
/* 251 */       return HttpHeaderReader.Event.Comment;
/*     */     case 3: 
/* 253 */       this.index += 1;
/* 254 */       this.value = String.valueOf(c);
/* 255 */       return HttpHeaderReader.Event.Separator;
/*     */     case 4: 
/* 257 */       this.index += 1;
/* 258 */       this.value = String.valueOf(c);
/* 259 */       return HttpHeaderReader.Event.Control;
/*     */     }
/*     */     
/* 262 */     throw new ParseException("White space not allowed", this.index);
/*     */   }
/*     */   
/*     */   private void processComment() throws ParseException
/*     */   {
/* 267 */     boolean filter = false;
/*     */     
/*     */ 
/* 270 */     int start = ++this.index;int nesting = 1;
/* 271 */     for (; (nesting > 0) && (this.index < this.length); 
/* 272 */         this.index += 1) {
/* 273 */       char c = this.header.charAt(this.index);
/* 274 */       if (c == '\\') {
/* 275 */         this.index += 1;
/* 276 */         filter = true;
/* 277 */       } else if (c == '\r') {
/* 278 */         filter = true;
/* 279 */       } else if (c == '(') {
/* 280 */         nesting++;
/* 281 */       } else if (c == ')') {
/* 282 */         nesting--;
/*     */       }
/*     */     }
/* 285 */     if (nesting != 0) {
/* 286 */       throw new ParseException("Unbalanced comments", this.index);
/*     */     }
/*     */     
/* 289 */     this.value = (filter ? filterToken(this.header, start, this.index - 1) : this.header.substring(start, this.index - 1));
/*     */   }
/*     */   
/*     */   private void processQuotedString()
/*     */     throws ParseException
/*     */   {
/* 295 */     boolean filter = false;
/* 296 */     for (int start = ++this.index; this.index < this.length; this.index += 1) {
/* 297 */       char c = this.header.charAt(this.index);
/* 298 */       if (c == '\\') {
/* 299 */         this.index += 1;
/* 300 */         filter = true;
/* 301 */       } else if (c == '\r') {
/* 302 */         filter = true;
/* 303 */       } else if (c == '"') {
/* 304 */         this.value = (filter ? filterToken(this.header, start, this.index) : this.header.substring(start, this.index));
/*     */         
/*     */ 
/*     */ 
/* 308 */         this.index += 1;
/* 309 */         return;
/*     */       }
/*     */     }
/*     */     
/* 313 */     throw new ParseException("Unbalanced quoted string", this.index);
/*     */   }
/*     */   
/*     */   private boolean isWhiteSpace(char c) {
/* 317 */     return (c < '') && (IS_WHITE_SPACE[c] != 0);
/*     */   }
/*     */   
/*     */   private boolean isToken(char c) {
/* 321 */     return (c < '') && (IS_TOKEN[c] != 0);
/*     */   }
/*     */   
/*     */   private static String filterToken(String s, int start, int end) {
/* 325 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 327 */     boolean gotEscape = false;
/* 328 */     boolean gotCR = false;
/*     */     
/* 330 */     for (int i = start; i < end; i++) {
/* 331 */       char c = s.charAt(i);
/* 332 */       if ((c == '\n') && (gotCR))
/*     */       {
/*     */ 
/* 335 */         gotCR = false;
/*     */       }
/*     */       else
/*     */       {
/* 339 */         gotCR = false;
/* 340 */         if (!gotEscape)
/*     */         {
/* 342 */           if (c == '\\') {
/* 343 */             gotEscape = true;
/* 344 */           } else if (c == '\r') {
/* 345 */             gotCR = true;
/*     */           } else {
/* 347 */             sb.append(c);
/*     */           }
/*     */           
/*     */         }
/*     */         else
/*     */         {
/* 353 */           sb.append(c);
/* 354 */           gotEscape = false;
/*     */         }
/*     */       } }
/* 357 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\header\reader\HttpHeaderReaderImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */