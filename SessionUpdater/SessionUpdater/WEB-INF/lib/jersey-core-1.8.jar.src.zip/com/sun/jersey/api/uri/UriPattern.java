/*     */ package com.sun.jersey.api.uri;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.MatchResult;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UriPattern
/*     */ {
/*  61 */   public static final UriPattern EMPTY = new UriPattern();
/*     */   
/*     */ 
/*     */ 
/*     */   private final String regex;
/*     */   
/*     */ 
/*     */ 
/*     */   private final Pattern regexPattern;
/*     */   
/*     */ 
/*     */ 
/*     */   private final int[] groupIndexes;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected UriPattern()
/*     */   {
/*  80 */     this.regex = "";
/*  81 */     this.regexPattern = null;
/*  82 */     this.groupIndexes = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriPattern(String regex)
/*     */   {
/*  95 */     this(regex, UriTemplateParser.EMPTY_INT_ARRAY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriPattern(String regex, int[] groupIndexes)
/*     */   {
/* 109 */     this(compile(regex), groupIndexes);
/*     */   }
/*     */   
/*     */   private static Pattern compile(String regex) {
/* 113 */     return (regex == null) || (regex.length() == 0) ? null : Pattern.compile(regex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriPattern(Pattern regexPattern)
/*     */   {
/* 123 */     this(regexPattern, UriTemplateParser.EMPTY_INT_ARRAY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UriPattern(Pattern regexPattern, int[] groupIndexes)
/*     */   {
/* 134 */     if (regexPattern == null) {
/* 135 */       throw new IllegalArgumentException();
/*     */     }
/* 137 */     this.regex = regexPattern.toString();
/* 138 */     this.regexPattern = regexPattern;
/* 139 */     this.groupIndexes = groupIndexes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getRegex()
/*     */   {
/* 148 */     return this.regex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int[] getGroupIndexes()
/*     */   {
/* 157 */     return this.groupIndexes;
/*     */   }
/*     */   
/*     */   private static final class EmptyStringMatchResult implements MatchResult {
/*     */     public int start() {
/* 162 */       return 0;
/*     */     }
/*     */     
/*     */     public int start(int group) {
/* 166 */       if (group != 0)
/* 167 */         throw new IndexOutOfBoundsException();
/* 168 */       return start();
/*     */     }
/*     */     
/*     */     public int end() {
/* 172 */       return 0;
/*     */     }
/*     */     
/*     */     public int end(int group) {
/* 176 */       if (group != 0)
/* 177 */         throw new IndexOutOfBoundsException();
/* 178 */       return end();
/*     */     }
/*     */     
/*     */     public String group() {
/* 182 */       return "";
/*     */     }
/*     */     
/*     */     public String group(int group) {
/* 186 */       if (group != 0)
/* 187 */         throw new IndexOutOfBoundsException();
/* 188 */       return group();
/*     */     }
/*     */     
/*     */     public int groupCount() {
/* 192 */       return 0;
/*     */     }
/*     */   }
/*     */   
/* 196 */   private static final EmptyStringMatchResult EMPTY_STRING_MATCH_RESULT = new EmptyStringMatchResult(null);
/*     */   
/*     */   private final class GroupIndexMatchResult implements MatchResult {
/*     */     private final MatchResult r;
/*     */     
/*     */     GroupIndexMatchResult(MatchResult r) {
/* 202 */       this.r = r;
/*     */     }
/*     */     
/*     */     public int start() {
/* 206 */       return this.r.start();
/*     */     }
/*     */     
/*     */     public int start(int group) {
/* 210 */       if (group > groupCount()) {
/* 211 */         throw new IndexOutOfBoundsException();
/*     */       }
/* 213 */       return group > 0 ? this.r.start(UriPattern.this.groupIndexes[(group - 1)]) : this.r.start();
/*     */     }
/*     */     
/*     */     public int end() {
/* 217 */       return this.r.end();
/*     */     }
/*     */     
/*     */     public int end(int group) {
/* 221 */       if (group > groupCount()) {
/* 222 */         throw new IndexOutOfBoundsException();
/*     */       }
/* 224 */       return group > 0 ? this.r.end(UriPattern.this.groupIndexes[(group - 1)]) : this.r.end();
/*     */     }
/*     */     
/*     */     public String group() {
/* 228 */       return this.r.group();
/*     */     }
/*     */     
/*     */     public String group(int group) {
/* 232 */       if (group > groupCount()) {
/* 233 */         throw new IndexOutOfBoundsException();
/*     */       }
/* 235 */       return group > 0 ? this.r.group(UriPattern.this.groupIndexes[(group - 1)]) : this.r.group();
/*     */     }
/*     */     
/*     */     public int groupCount() {
/* 239 */       return UriPattern.this.groupIndexes.length - 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final MatchResult match(CharSequence uri)
/*     */   {
/* 251 */     if ((uri == null) || (uri.length() == 0))
/* 252 */       return this.regexPattern == null ? EMPTY_STRING_MATCH_RESULT : null;
/* 253 */     if (this.regexPattern == null) {
/* 254 */       return null;
/*     */     }
/*     */     
/* 257 */     Matcher m = this.regexPattern.matcher(uri);
/* 258 */     if (!m.matches()) {
/* 259 */       return null;
/*     */     }
/* 261 */     return this.groupIndexes.length > 0 ? new GroupIndexMatchResult(m) : m;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean match(CharSequence uri, List<String> groupValues)
/*     */   {
/* 280 */     if (groupValues == null) {
/* 281 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 284 */     if ((uri == null) || (uri.length() == 0))
/* 285 */       return this.regexPattern == null;
/* 286 */     if (this.regexPattern == null) {
/* 287 */       return false;
/*     */     }
/*     */     
/* 290 */     Matcher m = this.regexPattern.matcher(uri);
/* 291 */     if (!m.matches()) {
/* 292 */       return false;
/*     */     }
/* 294 */     groupValues.clear();
/* 295 */     if (this.groupIndexes.length > 0) {
/* 296 */       for (int i = 0; i < this.groupIndexes.length - 1; i++) {
/* 297 */         groupValues.add(m.group(this.groupIndexes[i]));
/*     */       }
/*     */     } else {
/* 300 */       for (int i = 1; i <= m.groupCount(); i++) {
/* 301 */         groupValues.add(m.group(i));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 308 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean match(CharSequence uri, List<String> groupNames, Map<String, String> groupValues)
/*     */   {
/* 332 */     if (groupValues == null) {
/* 333 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 336 */     if ((uri == null) || (uri.length() == 0))
/* 337 */       return this.regexPattern == null;
/* 338 */     if (this.regexPattern == null) {
/* 339 */       return false;
/*     */     }
/*     */     
/* 342 */     Matcher m = this.regexPattern.matcher(uri);
/* 343 */     if (!m.matches()) {
/* 344 */       return false;
/*     */     }
/*     */     
/* 347 */     groupValues.clear();
/* 348 */     for (int i = 0; i < groupNames.size(); i++) {
/* 349 */       String name = (String)groupNames.get(i);
/* 350 */       String currentValue = m.group(this.groupIndexes.length > 0 ? this.groupIndexes[i] : i + 1);
/*     */       
/*     */ 
/*     */ 
/* 354 */       String previousValue = (String)groupValues.get(name);
/* 355 */       if ((previousValue != null) && (!previousValue.equals(currentValue))) {
/* 356 */         return false;
/*     */       }
/* 358 */       groupValues.put(name, currentValue);
/*     */     }
/*     */     
/* 361 */     return true;
/*     */   }
/*     */   
/*     */   public final int hashCode()
/*     */   {
/* 366 */     return this.regex.hashCode();
/*     */   }
/*     */   
/*     */   public final boolean equals(Object obj)
/*     */   {
/* 371 */     if (obj == null) {
/* 372 */       return false;
/*     */     }
/* 374 */     if (getClass() != obj.getClass()) {
/* 375 */       return false;
/*     */     }
/* 377 */     UriPattern that = (UriPattern)obj;
/* 378 */     if ((this.regex != that.regex) && ((this.regex == null) || (!this.regex.equals(that.regex))))
/*     */     {
/* 380 */       return false;
/*     */     }
/* 382 */     return true;
/*     */   }
/*     */   
/*     */   public final String toString()
/*     */   {
/* 387 */     return this.regex;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\api\uri\UriPattern.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */