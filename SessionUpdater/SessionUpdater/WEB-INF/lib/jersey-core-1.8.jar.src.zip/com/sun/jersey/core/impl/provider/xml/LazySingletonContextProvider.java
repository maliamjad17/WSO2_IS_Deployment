/*    */ package com.sun.jersey.core.impl.provider.xml;
/*    */ 
/*    */ import com.sun.jersey.core.spi.component.ComponentContext;
/*    */ import com.sun.jersey.core.spi.component.ComponentScope;
/*    */ import com.sun.jersey.spi.inject.Injectable;
/*    */ import com.sun.jersey.spi.inject.InjectableProvider;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.concurrent.atomic.AtomicReference;
/*    */ import javax.ws.rs.core.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class LazySingletonContextProvider<T>
/*    */   implements InjectableProvider<Context, Type>
/*    */ {
/*    */   private final Class<T> t;
/* 58 */   private final AtomicReference<T> rf = new AtomicReference();
/*    */   
/*    */   protected LazySingletonContextProvider(Class<T> t) {
/* 61 */     this.t = t;
/*    */   }
/*    */   
/*    */   public ComponentScope getScope() {
/* 65 */     return ComponentScope.Singleton;
/*    */   }
/*    */   
/*    */   public Injectable<T> getInjectable(ComponentContext ic, Context a, Type c) {
/* 69 */     if (c == this.t) {
/* 70 */       new Injectable() {
/*    */         public T getValue() {
/* 72 */           return (T)LazySingletonContextProvider.this.get();
/*    */         }
/*    */       };
/*    */     }
/* 76 */     return null;
/*    */   }
/*    */   
/*    */   private T get()
/*    */   {
/* 81 */     T f = this.rf.get();
/* 82 */     if (f == null) {
/* 83 */       T nf = getInstance();
/*    */       
/* 85 */       this.rf.compareAndSet(null, nf);
/* 86 */       f = this.rf.get();
/*    */     }
/* 88 */     return f;
/*    */   }
/*    */   
/*    */   protected abstract T getInstance();
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\xml\LazySingletonContextProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */