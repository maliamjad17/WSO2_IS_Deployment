package com.sun.jersey.core.util;

import java.util.Map;

public abstract interface FeaturesAndProperties
{
  public static final String FEATURE_DISABLE_XML_SECURITY = "com.sun.jersey.config.feature.DisableXmlSecurity";
  public static final String FEATURE_FORMATTED = "com.sun.jersey.config.feature.Formatted";
  public static final String FEATURE_XMLROOTELEMENT_PROCESSING = "com.sun.jersey.config.feature.XmlRootElementProcessing";
  public static final String FEATURE_PRE_1_4_PROVIDER_PRECEDENCE = "com.sun.jersey.config.feature.Pre14ProviderPrecedence";
  
  public abstract Map<String, Boolean> getFeatures();
  
  public abstract boolean getFeature(String paramString);
  
  public abstract Map<String, Object> getProperties();
  
  public abstract Object getProperty(String paramString);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\util\FeaturesAndProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */