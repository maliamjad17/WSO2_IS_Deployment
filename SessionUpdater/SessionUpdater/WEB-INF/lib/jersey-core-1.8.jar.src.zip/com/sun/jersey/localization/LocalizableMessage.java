/*    */ package com.sun.jersey.localization;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LocalizableMessage
/*    */   implements Localizable
/*    */ {
/*    */   private final String _bundlename;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final String _key;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final Object[] _args;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public LocalizableMessage(String bundlename, String key, Object... args)
/*    */   {
/* 53 */     this._bundlename = bundlename;
/* 54 */     this._key = key;
/* 55 */     if (args == null)
/* 56 */       args = new Object[0];
/* 57 */     this._args = args;
/*    */   }
/*    */   
/*    */   public String getKey() {
/* 61 */     return this._key;
/*    */   }
/*    */   
/*    */   public Object[] getArguments() {
/* 65 */     return this._args;
/*    */   }
/*    */   
/*    */   public String getResourceBundleName() {
/* 69 */     return this._bundlename;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\localization\LocalizableMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */