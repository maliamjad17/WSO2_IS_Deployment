/*    */ package com.sun.jersey.core.impl.provider.header;
/*    */ 
/*    */ import com.sun.jersey.core.header.reader.HttpHeaderReader;
/*    */ import com.sun.jersey.spi.HeaderDelegateProvider;
/*    */ import javax.ws.rs.core.NewCookie;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NewCookieProvider
/*    */   implements HeaderDelegateProvider<NewCookie>
/*    */ {
/*    */   public boolean supports(Class<?> type)
/*    */   {
/* 50 */     return type == NewCookie.class;
/*    */   }
/*    */   
/*    */   public String toString(NewCookie cookie) {
/* 54 */     StringBuilder b = new StringBuilder();
/*    */     
/* 56 */     b.append(cookie.getName()).append('=');
/* 57 */     WriterUtil.appendQuotedIfWhitespace(b, cookie.getValue());
/*    */     
/* 59 */     b.append(";").append("Version=").append(cookie.getVersion());
/*    */     
/* 61 */     if (cookie.getComment() != null) {
/* 62 */       b.append(";Comment=");
/* 63 */       WriterUtil.appendQuotedIfWhitespace(b, cookie.getComment());
/*    */     }
/* 65 */     if (cookie.getDomain() != null) {
/* 66 */       b.append(";Domain=");
/* 67 */       WriterUtil.appendQuotedIfWhitespace(b, cookie.getDomain());
/*    */     }
/* 69 */     if (cookie.getPath() != null) {
/* 70 */       b.append(";Path=");
/* 71 */       WriterUtil.appendQuotedIfWhitespace(b, cookie.getPath());
/*    */     }
/* 73 */     if (cookie.getMaxAge() != -1) {
/* 74 */       b.append(";Max-Age=");
/* 75 */       b.append(cookie.getMaxAge());
/*    */     }
/* 77 */     if (cookie.isSecure())
/* 78 */       b.append(";Secure");
/* 79 */     return b.toString();
/*    */   }
/*    */   
/*    */   public NewCookie fromString(String header) {
/* 83 */     if (header == null) {
/* 84 */       throw new IllegalArgumentException("NewCookie is null");
/*    */     }
/* 86 */     return HttpHeaderReader.readNewCookie(header);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\header\NewCookieProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */