/*    */ package com.sun.jersey.core.impl.provider.entity;
/*    */ 
/*    */ import com.sun.jersey.api.representation.Form;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Type;
/*    */ import javax.ws.rs.Consumes;
/*    */ import javax.ws.rs.Produces;
/*    */ import javax.ws.rs.core.MediaType;
/*    */ import javax.ws.rs.core.MultivaluedMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Produces({"application/x-www-form-urlencoded", "*/*"})
/*    */ @Consumes({"application/x-www-form-urlencoded", "*/*"})
/*    */ public final class FormProvider
/*    */   extends BaseFormProvider<Form>
/*    */ {
/*    */   public boolean isReadable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType)
/*    */   {
/* 63 */     return type == Form.class;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Form readFrom(Class<Form> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, String> httpHeaders, InputStream entityStream)
/*    */     throws IOException
/*    */   {
/* 73 */     return (Form)readFrom(new Form(), mediaType, entityStream);
/*    */   }
/*    */   
/*    */   public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
/* 77 */     return type == Form.class;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void writeTo(Form t, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, OutputStream entityStream)
/*    */     throws IOException
/*    */   {
/* 88 */     writeTo(t, mediaType, entityStream);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\entity\FormProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */