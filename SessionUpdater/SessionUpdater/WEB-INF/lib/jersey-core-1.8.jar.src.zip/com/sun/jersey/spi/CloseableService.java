package com.sun.jersey.spi;

import java.io.Closeable;

public abstract interface CloseableService
{
  public abstract void add(Closeable paramCloseable);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\spi\CloseableService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */