/*    */ package com.sun.jersey.core.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class LazyVal<T>
/*    */ {
/*    */   private volatile T val;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public T get()
/*    */   {
/* 52 */     T result = this.val;
/* 53 */     if (result == null) {
/* 54 */       synchronized (this) {
/* 55 */         result = this.val;
/* 56 */         if (result == null) {
/* 57 */           this.val = (result = instance());
/*    */         }
/*    */       }
/*    */     }
/* 61 */     return result;
/*    */   }
/*    */   
/*    */   public void set(T t) {
/* 65 */     this.val = t;
/*    */   }
/*    */   
/*    */   protected abstract T instance();
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\util\LazyVal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */