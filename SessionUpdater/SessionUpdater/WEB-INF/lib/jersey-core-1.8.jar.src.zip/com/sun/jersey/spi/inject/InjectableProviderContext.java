/*     */ package com.sun.jersey.spi.inject;
/*     */ 
/*     */ import com.sun.jersey.core.spi.component.ComponentContext;
/*     */ import com.sun.jersey.core.spi.component.ComponentScope;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface InjectableProviderContext
/*     */ {
/*     */   public abstract boolean isAnnotationRegistered(Class<? extends Annotation> paramClass, Class<?> paramClass1);
/*     */   
/*     */   public abstract boolean isInjectableProviderRegistered(Class<? extends Annotation> paramClass, Class<?> paramClass1, ComponentScope paramComponentScope);
/*     */   
/*     */   public abstract <A extends Annotation, C> Injectable getInjectable(Class<? extends Annotation> paramClass, ComponentContext paramComponentContext, A paramA, C paramC, ComponentScope paramComponentScope);
/*     */   
/*     */   public abstract <A extends Annotation, C> Injectable getInjectable(Class<? extends Annotation> paramClass, ComponentContext paramComponentContext, A paramA, C paramC, List<ComponentScope> paramList);
/*     */   
/*     */   public abstract <A extends Annotation, C> InjectableScopePair getInjectableWithScope(Class<? extends Annotation> paramClass, ComponentContext paramComponentContext, A paramA, C paramC, List<ComponentScope> paramList);
/*     */   
/*     */   public static final class InjectableScopePair
/*     */   {
/*     */     public final Injectable i;
/*     */     public final ComponentScope cs;
/*     */     
/*     */     public InjectableScopePair(Injectable i, ComponentScope cs)
/*     */     {
/* 128 */       this.i = i;
/* 129 */       this.cs = cs;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\spi\inject\InjectableProviderContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */