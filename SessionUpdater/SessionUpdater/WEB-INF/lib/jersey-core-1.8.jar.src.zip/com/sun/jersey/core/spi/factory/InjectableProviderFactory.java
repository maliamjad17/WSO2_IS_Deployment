/*     */ package com.sun.jersey.core.spi.factory;
/*     */ 
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper.ClassTypePair;
/*     */ import com.sun.jersey.core.spi.component.ComponentContext;
/*     */ import com.sun.jersey.core.spi.component.ComponentScope;
/*     */ import com.sun.jersey.core.spi.component.ProviderServices;
/*     */ import com.sun.jersey.core.spi.component.ProviderServices.ProviderListener;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import com.sun.jersey.spi.inject.InjectableProvider;
/*     */ import com.sun.jersey.spi.inject.InjectableProviderContext;
/*     */ import com.sun.jersey.spi.inject.InjectableProviderContext.InjectableScopePair;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InjectableProviderFactory
/*     */   implements InjectableProviderContext
/*     */ {
/*     */   private static final class MetaInjectableProvider
/*     */   {
/*     */     final InjectableProvider ip;
/*     */     final Class<? extends Annotation> ac;
/*     */     final Class<?> cc;
/*     */     
/*     */     MetaInjectableProvider(InjectableProvider ip, Class<? extends Annotation> ac, Class<?> cc)
/*     */     {
/*  76 */       this.ip = ip;
/*  77 */       this.ac = ac;
/*  78 */       this.cc = cc;
/*     */     }
/*     */   }
/*     */   
/*  82 */   private final Map<Class<? extends Annotation>, LinkedList<MetaInjectableProvider>> ipm = new HashMap();
/*     */   
/*     */   public final void update(InjectableProviderFactory ipf)
/*     */   {
/*  86 */     for (Map.Entry<Class<? extends Annotation>, LinkedList<MetaInjectableProvider>> e : ipf.ipm.entrySet()) {
/*  87 */       getList((Class)e.getKey()).addAll((Collection)e.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */   public final void add(InjectableProvider ip)
/*     */   {
/*  93 */     Type[] args = getMetaArguments(ip.getClass());
/*  94 */     if (args != null) {
/*  95 */       MetaInjectableProvider mip = new MetaInjectableProvider(ip, (Class)args[0], (Class)args[1]);
/*     */       
/*     */ 
/*     */ 
/*  99 */       getList(mip.ac).add(mip);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public final void configure(ProviderServices providerServices)
/*     */   {
/* 106 */     providerServices.getProvidersAndServices(InjectableProvider.class, new ProviderServices.ProviderListener()
/*     */     {
/*     */       public void onAdd(InjectableProvider ip) {
/* 109 */         InjectableProviderFactory.this.add(ip);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public final void configureProviders(ProviderServices providerServices) {
/* 115 */     providerServices.getProviders(InjectableProvider.class, new ProviderServices.ProviderListener()
/*     */     {
/*     */       public void onAdd(InjectableProvider ip) {
/* 118 */         InjectableProviderFactory.this.add(ip);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private LinkedList<MetaInjectableProvider> getList(Class<? extends Annotation> c) {
/* 124 */     LinkedList<MetaInjectableProvider> l = (LinkedList)this.ipm.get(c);
/* 125 */     if (l == null) {
/* 126 */       l = new LinkedList();
/* 127 */       this.ipm.put(c, l);
/*     */     }
/* 129 */     return l;
/*     */   }
/*     */   
/*     */   private Type[] getMetaArguments(Class<? extends InjectableProvider> c) {
/* 133 */     Class _c = c;
/* 134 */     while (_c != Object.class) {
/* 135 */       Type[] ts = _c.getGenericInterfaces();
/* 136 */       for (Type t : ts) {
/* 137 */         if ((t instanceof ParameterizedType)) {
/* 138 */           ParameterizedType pt = (ParameterizedType)t;
/* 139 */           if (pt.getRawType() == InjectableProvider.class) {
/* 140 */             Type[] args = pt.getActualTypeArguments();
/* 141 */             for (int i = 0; i < args.length; i++)
/* 142 */               args[i] = getResolvedType(args[i], c, _c);
/* 143 */             if (((args[0] instanceof Class)) && ((args[1] instanceof Class)))
/*     */             {
/* 145 */               return args;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 150 */       _c = _c.getSuperclass();
/*     */     }
/*     */     
/* 153 */     return null;
/*     */   }
/*     */   
/*     */   private Type getResolvedType(Type t, Class c, Class dc) {
/* 157 */     if ((t instanceof Class))
/* 158 */       return t;
/* 159 */     if ((t instanceof TypeVariable)) {
/* 160 */       ReflectionHelper.ClassTypePair ct = ReflectionHelper.resolveTypeVariable(c, dc, (TypeVariable)t);
/*     */       
/* 162 */       if (ct != null) {
/* 163 */         return ct.c;
/*     */       }
/* 165 */       return t; }
/* 166 */     if ((t instanceof ParameterizedType)) {
/* 167 */       ParameterizedType pt = (ParameterizedType)t;
/* 168 */       return pt.getRawType();
/*     */     }
/* 170 */     return t;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private List<MetaInjectableProvider> findInjectableProviders(Class<? extends Annotation> ac, Class<?> cc, ComponentScope s)
/*     */   {
/* 177 */     List<MetaInjectableProvider> subips = new ArrayList();
/* 178 */     for (MetaInjectableProvider i : getList(ac)) {
/* 179 */       if ((s == i.ip.getScope()) && 
/* 180 */         (i.cc.isAssignableFrom(cc))) {
/* 181 */         subips.add(i);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 186 */     return subips;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isAnnotationRegistered(Class<? extends Annotation> ac, Class<?> cc)
/*     */   {
/* 193 */     for (MetaInjectableProvider i : getList(ac)) {
/* 194 */       if (i.cc.isAssignableFrom(cc)) {
/* 195 */         return true;
/*     */       }
/*     */     }
/* 198 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isInjectableProviderRegistered(Class<? extends Annotation> ac, Class<?> cc, ComponentScope s)
/*     */   {
/* 204 */     return !findInjectableProviders(ac, cc, s).isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final <A extends Annotation, C> Injectable getInjectable(Class<? extends Annotation> ac, ComponentContext ic, A a, C c, ComponentScope s)
/*     */   {
/* 213 */     for (MetaInjectableProvider mip : findInjectableProviders(ac, c.getClass(), s)) {
/* 214 */       Injectable i = mip.ip.getInjectable(ic, a, c);
/* 215 */       if (i != null)
/* 216 */         return i;
/*     */     }
/* 218 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final <A extends Annotation, C> Injectable getInjectable(Class<? extends Annotation> ac, ComponentContext ic, A a, C c, List<ComponentScope> ls)
/*     */   {
/* 227 */     for (ComponentScope s : ls) {
/* 228 */       Injectable i = getInjectable(ac, ic, a, c, s);
/* 229 */       if (i != null) {
/* 230 */         return i;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 235 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <A extends Annotation, C> InjectableProviderContext.InjectableScopePair getInjectableWithScope(Class<? extends Annotation> ac, ComponentContext ic, A a, C c, List<ComponentScope> ls)
/*     */   {
/* 244 */     for (ComponentScope s : ls) {
/* 245 */       Injectable i = getInjectable(ac, ic, a, c, s);
/* 246 */       if (i != null)
/* 247 */         return new InjectableProviderContext.InjectableScopePair(i, s);
/*     */     }
/* 249 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\factory\InjectableProviderFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */