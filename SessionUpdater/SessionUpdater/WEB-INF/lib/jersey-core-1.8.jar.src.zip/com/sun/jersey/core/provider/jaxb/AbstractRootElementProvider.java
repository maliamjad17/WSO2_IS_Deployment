/*     */ package com.sun.jersey.core.provider.jaxb;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.charset.Charset;
/*     */ import javax.ws.rs.WebApplicationException;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.core.Response.Status;
/*     */ import javax.ws.rs.ext.Providers;
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.Marshaller;
/*     */ import javax.xml.bind.UnmarshalException;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractRootElementProvider
/*     */   extends AbstractJAXBProvider<Object>
/*     */ {
/*     */   public AbstractRootElementProvider(Providers ps)
/*     */   {
/*  83 */     super(ps);
/*     */   }
/*     */   
/*     */   public AbstractRootElementProvider(Providers ps, MediaType mt) {
/*  87 */     super(ps, mt);
/*     */   }
/*     */   
/*     */   public boolean isReadable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType)
/*     */   {
/*  92 */     return ((type.getAnnotation(XmlRootElement.class) != null) || (type.getAnnotation(XmlType.class) != null)) && (isSupported(mediaType));
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType)
/*     */   {
/*  98 */     return (type.getAnnotation(XmlRootElement.class) != null) && (isSupported(mediaType));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Object readFrom(Class<Object> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, String> httpHeaders, InputStream entityStream)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 111 */       return readFrom(type, mediaType, getUnmarshaller(type, mediaType), entityStream);
/*     */     } catch (UnmarshalException ex) {
/* 113 */       throw new WebApplicationException(ex, Response.Status.BAD_REQUEST);
/*     */     } catch (JAXBException ex) {
/* 115 */       throw new WebApplicationException(ex, Response.Status.INTERNAL_SERVER_ERROR);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object readFrom(Class<Object> type, MediaType mediaType, Unmarshaller u, InputStream entityStream)
/*     */     throws JAXBException
/*     */   {
/* 135 */     if (type.isAnnotationPresent(XmlRootElement.class)) {
/* 136 */       return u.unmarshal(entityStream);
/*     */     }
/* 138 */     return u.unmarshal(new StreamSource(entityStream), type).getValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void writeTo(Object t, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, OutputStream entityStream)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 151 */       Marshaller m = getMarshaller(type, mediaType);
/* 152 */       Charset c = getCharset(mediaType);
/* 153 */       if (c != UTF8) {
/* 154 */         m.setProperty("jaxb.encoding", c.name());
/*     */       }
/* 156 */       setHeader(m, annotations);
/* 157 */       writeTo(t, mediaType, c, m, entityStream);
/*     */     } catch (JAXBException ex) {
/* 159 */       throw new WebApplicationException(ex, Response.Status.INTERNAL_SERVER_ERROR);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeTo(Object t, MediaType mediaType, Charset c, Marshaller m, OutputStream entityStream)
/*     */     throws JAXBException
/*     */   {
/* 179 */     m.marshal(t, entityStream);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\provider\jaxb\AbstractRootElementProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */