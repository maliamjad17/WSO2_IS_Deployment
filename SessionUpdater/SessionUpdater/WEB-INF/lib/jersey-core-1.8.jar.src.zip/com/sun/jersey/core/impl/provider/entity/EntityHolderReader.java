/*     */ package com.sun.jersey.core.impl.provider.entity;
/*     */ 
/*     */ import com.sun.jersey.core.provider.EntityHolder;
/*     */ import com.sun.jersey.core.util.ReaderWriter;
/*     */ import com.sun.jersey.spi.MessageBodyWorkers;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.logging.Logger;
/*     */ import javax.ws.rs.WebApplicationException;
/*     */ import javax.ws.rs.core.Context;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.ext.MessageBodyReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EntityHolderReader
/*     */   implements MessageBodyReader<Object>
/*     */ {
/*  65 */   private static final Logger LOGGER = Logger.getLogger(EntityHolderReader.class.getName());
/*     */   private final MessageBodyWorkers bodyWorker;
/*     */   
/*     */   public EntityHolderReader(@Context MessageBodyWorkers bodyWorker)
/*     */   {
/*  70 */     this.bodyWorker = bodyWorker;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isReadable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType)
/*     */   {
/*  78 */     if (type != EntityHolder.class) { return false;
/*     */     }
/*  80 */     if (!(genericType instanceof ParameterizedType)) { return false;
/*     */     }
/*  82 */     ParameterizedType pt = (ParameterizedType)genericType;
/*     */     
/*  84 */     Type t = pt.getActualTypeArguments()[0];
/*     */     
/*  86 */     if (((t instanceof Class)) || ((t instanceof ParameterizedType))) {
/*  87 */       return true;
/*     */     }
/*  89 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object readFrom(Class<Object> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, String> httpHeaders, InputStream entityStream)
/*     */     throws IOException
/*     */   {
/* 100 */     if (!entityStream.markSupported()) {
/* 101 */       entityStream = new BufferedInputStream(entityStream, ReaderWriter.BUFFER_SIZE);
/*     */     }
/* 103 */     entityStream.mark(1);
/* 104 */     if (entityStream.read() == -1) {
/* 105 */       return new EntityHolder();
/*     */     }
/*     */     
/* 108 */     entityStream.reset();
/*     */     
/* 110 */     ParameterizedType pt = (ParameterizedType)genericType;
/* 111 */     Type t = pt.getActualTypeArguments()[0];
/* 112 */     Class entityClass = (t instanceof Class) ? (Class)t : (Class)((ParameterizedType)t).getRawType();
/* 113 */     Type entityGenericType = (t instanceof Class) ? entityClass : t;
/*     */     
/* 115 */     MessageBodyReader br = this.bodyWorker.getMessageBodyReader(entityClass, entityGenericType, annotations, mediaType);
/* 116 */     if (br == null) {
/* 117 */       LOGGER.severe("A message body reader for the type, " + type + ", could not be found");
/* 118 */       throw new WebApplicationException();
/*     */     }
/* 120 */     Object o = br.readFrom(entityClass, entityGenericType, annotations, mediaType, httpHeaders, entityStream);
/* 121 */     return new EntityHolder(o);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\entity\EntityHolderReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */