/*     */ package com.sun.jersey.core.impl.provider.entity;
/*     */ 
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import javax.ws.rs.Consumes;
/*     */ import javax.ws.rs.Produces;
/*     */ import javax.ws.rs.WebApplicationException;
/*     */ import javax.ws.rs.core.Context;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.core.Response.Status;
/*     */ import javax.ws.rs.ext.MessageBodyReader;
/*     */ import javax.ws.rs.ext.MessageBodyWriter;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.w3c.dom.Document;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SourceProvider
/*     */ {
/*     */   @Produces({"application/xml", "text/xml", "*/*"})
/*     */   @Consumes({"application/xml", "text/xml", "*/*"})
/*     */   public static final class StreamSourceReader
/*     */     implements MessageBodyReader<StreamSource>
/*     */   {
/*     */     public boolean isReadable(Class<?> t, Type gt, Annotation[] as, MediaType mediaType)
/*     */     {
/*  84 */       return StreamSource.class == t;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public StreamSource readFrom(Class<StreamSource> t, Type gt, Annotation[] as, MediaType mediaType, MultivaluedMap<String, String> httpHeaders, InputStream entityStream)
/*     */       throws IOException
/*     */     {
/*  94 */       return new StreamSource(entityStream);
/*     */     }
/*     */   }
/*     */   
/*     */   @Produces({"application/xml", "text/xml", "*/*"})
/*     */   @Consumes({"application/xml", "text/xml", "*/*"})
/*     */   public static final class SAXSourceReader implements MessageBodyReader<SAXSource>
/*     */   {
/*     */     private final Injectable<SAXParserFactory> spf;
/*     */     
/*     */     public SAXSourceReader(@Context Injectable<SAXParserFactory> spf)
/*     */     {
/* 106 */       this.spf = spf;
/*     */     }
/*     */     
/*     */     public boolean isReadable(Class<?> t, Type gt, Annotation[] as, MediaType mediaType) {
/* 110 */       return SAXSource.class == t;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public SAXSource readFrom(Class<SAXSource> t, Type gt, Annotation[] as, MediaType mediaType, MultivaluedMap<String, String> httpHeaders, InputStream entityStream)
/*     */       throws IOException
/*     */     {
/*     */       try
/*     */       {
/* 121 */         return new SAXSource(((SAXParserFactory)this.spf.getValue()).newSAXParser().getXMLReader(), new InputSource(entityStream));
/*     */       }
/*     */       catch (SAXParseException ex) {
/* 124 */         throw new WebApplicationException(ex, Response.Status.BAD_REQUEST);
/*     */       } catch (SAXException ex) {
/* 126 */         throw new WebApplicationException(ex, Response.Status.INTERNAL_SERVER_ERROR);
/*     */       } catch (ParserConfigurationException ex) {
/* 128 */         throw new WebApplicationException(ex, Response.Status.INTERNAL_SERVER_ERROR);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @Produces({"application/xml", "text/xml", "*/*"})
/*     */   @Consumes({"application/xml", "text/xml", "*/*"})
/*     */   public static final class DOMSourceReader implements MessageBodyReader<DOMSource>
/*     */   {
/*     */     private final Injectable<DocumentBuilderFactory> dbf;
/*     */     
/*     */     public DOMSourceReader(@Context Injectable<DocumentBuilderFactory> dbf)
/*     */     {
/* 141 */       this.dbf = dbf;
/*     */     }
/*     */     
/*     */     public boolean isReadable(Class<?> t, Type gt, Annotation[] as, MediaType mediaType) {
/* 145 */       return DOMSource.class == t;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public DOMSource readFrom(Class<DOMSource> t, Type gt, Annotation[] as, MediaType mediaType, MultivaluedMap<String, String> httpHeaders, InputStream entityStream)
/*     */       throws IOException
/*     */     {
/*     */       try
/*     */       {
/* 156 */         Document d = ((DocumentBuilderFactory)this.dbf.getValue()).newDocumentBuilder().parse(entityStream);
/* 157 */         return new DOMSource(d);
/*     */       } catch (SAXParseException ex) {
/* 159 */         throw new WebApplicationException(ex, Response.Status.BAD_REQUEST);
/*     */       } catch (SAXException ex) {
/* 161 */         throw new WebApplicationException(ex, Response.Status.INTERNAL_SERVER_ERROR);
/*     */       } catch (ParserConfigurationException ex) {
/* 163 */         throw new WebApplicationException(ex, Response.Status.INTERNAL_SERVER_ERROR);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   @Produces({"application/xml", "text/xml", "*/*"})
/*     */   @Consumes({"application/xml", "text/xml", "*/*"})
/*     */   public static final class SourceWriter
/*     */     implements MessageBodyWriter<Source>
/*     */   {
/*     */     private final Injectable<SAXParserFactory> spf;
/*     */     
/*     */     private final Injectable<TransformerFactory> tf;
/*     */     
/*     */ 
/*     */     public SourceWriter(@Context Injectable<SAXParserFactory> spf, @Context Injectable<TransformerFactory> tf)
/*     */     {
/* 181 */       this.spf = spf;
/* 182 */       this.tf = tf;
/*     */     }
/*     */     
/*     */     public boolean isWriteable(Class<?> t, Type gt, Annotation[] as, MediaType mediaType) {
/* 186 */       return Source.class.isAssignableFrom(t);
/*     */     }
/*     */     
/*     */     public long getSize(Source o, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
/* 190 */       return -1L;
/*     */     }
/*     */     
/*     */     public void writeTo(Source o, Class<?> t, Type gt, Annotation[] as, MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, OutputStream entityStream)
/*     */       throws IOException
/*     */     {
/*     */       try
/*     */       {
/* 198 */         if ((o instanceof StreamSource)) {
/* 199 */           StreamSource s = (StreamSource)o;
/* 200 */           InputSource is = new InputSource(s.getInputStream());
/* 201 */           o = new SAXSource(((SAXParserFactory)this.spf.getValue()).newSAXParser().getXMLReader(), is);
/*     */         }
/* 203 */         StreamResult sr = new StreamResult(entityStream);
/* 204 */         ((TransformerFactory)this.tf.getValue()).newTransformer().transform(o, sr);
/*     */       } catch (SAXException ex) {
/* 206 */         throw new WebApplicationException(ex, Response.Status.INTERNAL_SERVER_ERROR);
/*     */       } catch (ParserConfigurationException ex) {
/* 208 */         throw new WebApplicationException(ex, Response.Status.INTERNAL_SERVER_ERROR);
/*     */       } catch (TransformerException ex) {
/* 210 */         throw new WebApplicationException(ex, Response.Status.INTERNAL_SERVER_ERROR);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\entity\SourceProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */