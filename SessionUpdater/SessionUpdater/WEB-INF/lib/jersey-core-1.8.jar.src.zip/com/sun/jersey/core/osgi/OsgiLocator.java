/*    */ package com.sun.jersey.core.osgi;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.concurrent.locks.Lock;
/*    */ import java.util.concurrent.locks.ReadWriteLock;
/*    */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OsgiLocator
/*    */ {
/* 29 */   private static Map<String, List<Callable<List<Class>>>> factories = new HashMap();
/* 30 */   private static ReadWriteLock lock = new ReentrantReadWriteLock();
/*    */   
/*    */ 
/*    */ 
/*    */   public static void unregister(String id, Callable<List<Class>> factory)
/*    */   {
/* 36 */     lock.writeLock().lock();
/*    */     try {
/* 38 */       List<Callable<List<Class>>> l = (List)factories.get(id);
/* 39 */       if (l != null) {
/* 40 */         l.remove(factory);
/*    */       }
/*    */     } finally {
/* 43 */       lock.writeLock().unlock();
/*    */     }
/*    */   }
/*    */   
/*    */   public static void register(String id, Callable<List<Class>> factory) {
/* 48 */     lock.writeLock().lock();
/*    */     try {
/* 50 */       List<Callable<List<Class>>> l = (List)factories.get(id);
/* 51 */       if (l == null) {
/* 52 */         l = new ArrayList();
/* 53 */         factories.put(id, l);
/*    */       }
/* 55 */       l.add(factory);
/*    */     } finally {
/* 57 */       lock.writeLock().unlock();
/*    */     }
/*    */   }
/*    */   
/*    */   public static synchronized Class locate(String factoryId) {
/* 62 */     lock.readLock().lock();
/*    */     try {
/* 64 */       List<Callable<List<Class>>> l = (List)factories.get(factoryId);
/* 65 */       if ((l == null) || (l.isEmpty())) {
/* 66 */         return null;
/*    */       }
/*    */       
/* 69 */       Object c = (Callable)l.get(l.size() - 1);
/*    */       List<Class> classes;
/*    */       try {
/* 72 */         classes = (List)((Callable)c).call();
/*    */       } catch (Exception e) {
/* 74 */         return null;
/*    */       }
/*    */       
/* 77 */       return (Class)classes.get(0);
/*    */     } finally {
/* 79 */       lock.readLock().unlock();
/*    */     }
/*    */   }
/*    */   
/*    */   public static synchronized List<Class> locateAll(String factoryId) {
/* 84 */     List<Class> classes = new ArrayList();
/* 85 */     List<Callable<List<Class>>> l = (List)factories.get(factoryId);
/* 86 */     if (l == null) {
/* 87 */       return classes;
/*    */     }
/*    */     
/* 90 */     for (Callable<List<Class>> c : l) {
/*    */       try {
/* 92 */         classes.addAll((Collection)c.call());
/*    */       }
/*    */       catch (Exception e) {}
/*    */     }
/* 96 */     return classes;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\osgi\OsgiLocator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */