/*     */ package com.sun.jersey.api.uri;
/*     */ 
/*     */ import com.sun.jersey.core.util.MultivaluedMapImpl;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URI;
/*     */ import java.net.URLDecoder;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.core.PathSegment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UriComponent
/*     */ {
/*     */   public static enum Type
/*     */   {
/*  73 */     UNRESERVED, 
/*     */     
/*     */ 
/*     */ 
/*  77 */     SCHEME, 
/*     */     
/*     */ 
/*     */ 
/*  81 */     AUTHORITY, 
/*     */     
/*     */ 
/*     */ 
/*  85 */     USER_INFO, 
/*     */     
/*     */ 
/*     */ 
/*  89 */     HOST, 
/*     */     
/*     */ 
/*     */ 
/*  93 */     PORT, 
/*     */     
/*     */ 
/*     */ 
/*  97 */     PATH, 
/*     */     
/*     */ 
/*     */ 
/* 101 */     PATH_SEGMENT, 
/*     */     
/*     */ 
/*     */ 
/* 105 */     MATRIX_PARAM, 
/*     */     
/*     */ 
/*     */ 
/* 109 */     QUERY, 
/*     */     
/*     */ 
/*     */ 
/* 113 */     QUERY_PARAM, 
/*     */     
/*     */ 
/*     */ 
/* 117 */     FRAGMENT;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private Type() {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void validate(String s, Type t)
/*     */   {
/* 133 */     validate(s, t, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void validate(String s, Type t, boolean template)
/*     */   {
/* 147 */     int i = _valid(s, t, template);
/* 148 */     if (i > -1)
/*     */     {
/* 150 */       throw new IllegalArgumentException("The string '" + s + "' for the URI component " + t + " contains an invalid character, '" + s.charAt(i) + "', at index " + i);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean valid(String s, Type t)
/*     */   {
/* 165 */     return valid(s, t, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean valid(String s, Type t, boolean template)
/*     */   {
/* 178 */     return _valid(s, t, template) == -1;
/*     */   }
/*     */   
/*     */   private static int _valid(String s, Type t, boolean template) {
/* 182 */     boolean[] table = ENCODING_TABLES[t.ordinal()];
/*     */     
/* 184 */     for (int i = 0; i < s.length(); i++) {
/* 185 */       char c = s.charAt(i);
/* 186 */       if (((c < '') && (c != '%') && (table[c] == 0)) || ((c >= '') && (
/* 187 */         (!template) || ((c != '{') && (c != '}'))))) {
/* 188 */         return i;
/*     */       }
/*     */     }
/*     */     
/* 192 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String contextualEncode(String s, Type t)
/*     */   {
/* 207 */     return _encode(s, t, false, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String contextualEncode(String s, Type t, boolean template)
/*     */   {
/* 223 */     return _encode(s, t, template, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encode(String s, Type t)
/*     */   {
/* 237 */     return _encode(s, t, false, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encode(String s, Type t, boolean template)
/*     */   {
/* 252 */     return _encode(s, t, template, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encodeTemplateNames(String s)
/*     */   {
/* 263 */     int i = s.indexOf('{');
/* 264 */     if (i != -1)
/* 265 */       s = s.replace("{", "%7B");
/* 266 */     i = s.indexOf('}');
/* 267 */     if (i != -1) {
/* 268 */       s = s.replace("}", "%7D");
/*     */     }
/* 270 */     return s;
/*     */   }
/*     */   
/*     */   private static String _encode(String s, Type t, boolean template, boolean contextualEncode) {
/* 274 */     boolean[] table = ENCODING_TABLES[t.ordinal()];
/*     */     
/* 276 */     StringBuilder sb = null;
/* 277 */     for (int i = 0; i < s.length(); i++) {
/* 278 */       char c = s.charAt(i);
/* 279 */       if ((c < '') && (table[c] != 0)) {
/* 280 */         if (sb != null) sb.append(c);
/*     */       }
/* 282 */       else if ((template) && ((c == '{') || (c == '}'))) {
/* 283 */         if (sb != null) sb.append(c);
/*     */       }
/* 285 */       else if ((contextualEncode) && 
/* 286 */         (c == '%') && (i + 2 < s.length()) && 
/* 287 */         (isHexCharacter(s.charAt(i + 1))) && (isHexCharacter(s.charAt(i + 2))))
/*     */       {
/* 289 */         if (sb != null)
/* 290 */           sb.append('%').append(s.charAt(i + 1)).append(s.charAt(i + 2));
/* 291 */         i += 2;
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 297 */         if (sb == null) {
/* 298 */           sb = new StringBuilder();
/* 299 */           sb.append(s.substring(0, i));
/*     */         }
/*     */         
/* 302 */         if (c < '') {
/* 303 */           if ((c == ' ') && (t == Type.QUERY_PARAM)) {
/* 304 */             sb.append('+');
/*     */           } else {
/* 306 */             appendPercentEncodedOctet(sb, c);
/*     */           }
/*     */         } else {
/* 309 */           appendUTF8EncodedCharacter(sb, c);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 314 */     return sb == null ? s : sb.toString(); }
/*     */   
/* 316 */   private static final char[] HEX_DIGITS = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*     */   
/*     */ 
/*     */ 
/*     */   private static void appendPercentEncodedOctet(StringBuilder sb, int b)
/*     */   {
/* 322 */     sb.append('%');
/* 323 */     sb.append(HEX_DIGITS[(b >> 4)]);
/* 324 */     sb.append(HEX_DIGITS[(b & 0xF)]);
/*     */   }
/*     */   
/*     */   private static void appendUTF8EncodedCharacter(StringBuilder sb, char c) {
/* 328 */     ByteBuffer bb = UTF_8_CHARSET.encode("" + c);
/*     */     
/* 330 */     while (bb.hasRemaining())
/* 331 */       appendPercentEncodedOctet(sb, bb.get() & 0xFF);
/*     */   }
/*     */   
/* 334 */   private static final String[] SCHEME = { "0-9", "A-Z", "a-z", "+", "-", "." };
/* 335 */   private static final String[] UNRESERVED = { "0-9", "A-Z", "a-z", "-", ".", "_", "~" };
/* 336 */   private static final String[] SUB_DELIMS = { "!", "$", "&", "'", "(", ")", "*", "+", ",", ";", "=" };
/* 337 */   private static final boolean[][] ENCODING_TABLES = initEncodingTables();
/*     */   
/*     */   private static boolean[][] initEncodingTables() {
/* 340 */     boolean[][] tables = new boolean[Type.values().length][];
/*     */     
/* 342 */     List<String> l = new ArrayList();
/* 343 */     l.addAll(Arrays.asList(SCHEME));
/* 344 */     tables[Type.SCHEME.ordinal()] = initEncodingTable(l);
/*     */     
/* 346 */     l.clear();
/*     */     
/* 348 */     l.addAll(Arrays.asList(UNRESERVED));
/* 349 */     tables[Type.UNRESERVED.ordinal()] = initEncodingTable(l);
/*     */     
/* 351 */     l.addAll(Arrays.asList(SUB_DELIMS));
/*     */     
/* 353 */     tables[Type.HOST.ordinal()] = initEncodingTable(l);
/*     */     
/* 355 */     tables[Type.PORT.ordinal()] = initEncodingTable(Arrays.asList(new String[] { "0-9" }));
/*     */     
/* 357 */     l.add(":");
/*     */     
/* 359 */     tables[Type.USER_INFO.ordinal()] = initEncodingTable(l);
/*     */     
/* 361 */     l.add("@");
/*     */     
/* 363 */     tables[Type.AUTHORITY.ordinal()] = initEncodingTable(l);
/*     */     
/* 365 */     tables[Type.PATH_SEGMENT.ordinal()] = initEncodingTable(l);
/* 366 */     tables[Type.PATH_SEGMENT.ordinal()][59] = 0;
/*     */     
/* 368 */     tables[Type.MATRIX_PARAM.ordinal()] = ((boolean[])tables[Type.PATH_SEGMENT.ordinal()].clone());
/* 369 */     tables[Type.MATRIX_PARAM.ordinal()][61] = 0;
/*     */     
/* 371 */     l.add("/");
/*     */     
/* 373 */     tables[Type.PATH.ordinal()] = initEncodingTable(l);
/*     */     
/* 375 */     l.add("?");
/*     */     
/* 377 */     tables[Type.QUERY.ordinal()] = initEncodingTable(l);
/*     */     
/* 379 */     tables[Type.FRAGMENT.ordinal()] = tables[Type.QUERY.ordinal()];
/*     */     
/* 381 */     tables[Type.QUERY_PARAM.ordinal()] = initEncodingTable(l);
/* 382 */     tables[Type.QUERY_PARAM.ordinal()][61] = 0;
/* 383 */     tables[Type.QUERY_PARAM.ordinal()][43] = 0;
/* 384 */     tables[Type.QUERY_PARAM.ordinal()][38] = 0;
/*     */     
/* 386 */     return tables;
/*     */   }
/*     */   
/*     */   private static boolean[] initEncodingTable(List<String> allowed) {
/* 390 */     boolean[] table = new boolean[''];
/* 391 */     for (String range : allowed) {
/* 392 */       if (range.length() == 1) {
/* 393 */         table[range.charAt(0)] = true;
/* 394 */       } else if ((range.length() == 3) && (range.charAt(1) == '-')) {
/* 395 */         for (int i = range.charAt(0); i <= range.charAt(2); i++) {
/* 396 */           table[i] = true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 401 */     return table; }
/*     */   
/* 403 */   private static final Charset UTF_8_CHARSET = Charset.forName("UTF-8");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String decode(String s, Type t)
/*     */   {
/* 426 */     if (s == null) {
/* 427 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 430 */     int n = s.length();
/* 431 */     if (n == 0) {
/* 432 */       return s;
/*     */     }
/*     */     
/*     */ 
/* 436 */     if (s.indexOf('%') < 0)
/*     */     {
/* 438 */       if (t == Type.QUERY_PARAM) {
/* 439 */         if (s.indexOf('+') < 0) {
/* 440 */           return s;
/*     */         }
/*     */       } else {
/* 443 */         return s;
/*     */       }
/*     */     }
/*     */     else {
/* 447 */       if (n < 2)
/*     */       {
/* 449 */         throw new IllegalArgumentException("Malformed percent-encoded octet at index 1");
/*     */       }
/*     */       
/*     */ 
/* 453 */       if (s.charAt(n - 2) == '%')
/*     */       {
/* 455 */         throw new IllegalArgumentException("Malformed percent-encoded octet at index " + (n - 2));
/*     */       }
/*     */     }
/*     */     
/* 459 */     if (t == null) {
/* 460 */       return decode(s, n);
/*     */     }
/* 462 */     switch (t) {
/*     */     case HOST: 
/* 464 */       return decodeHost(s, n);
/*     */     case QUERY_PARAM: 
/* 466 */       return decodeQueryParam(s, n);
/*     */     }
/* 468 */     return decode(s, n);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MultivaluedMap<String, String> decodeQuery(URI u, boolean decode)
/*     */   {
/* 481 */     return decodeQuery(u.getRawQuery(), decode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MultivaluedMap<String, String> decodeQuery(String q, boolean decode)
/*     */   {
/* 493 */     MultivaluedMap<String, String> queryParameters = new MultivaluedMapImpl();
/*     */     
/* 495 */     if ((q == null) || (q.length() == 0)) {
/* 496 */       return queryParameters;
/*     */     }
/*     */     
/* 499 */     int s = 0;int e = 0;
/*     */     do {
/* 501 */       e = q.indexOf('&', s);
/*     */       
/* 503 */       if (e == -1) {
/* 504 */         decodeQueryParam(queryParameters, q.substring(s), decode);
/* 505 */       } else if (e > s) {
/* 506 */         decodeQueryParam(queryParameters, q.substring(s, e), decode);
/*     */       }
/* 508 */       s = e + 1;
/* 509 */     } while ((s > 0) && (s < q.length()));
/*     */     
/* 511 */     return queryParameters;
/*     */   }
/*     */   
/*     */   private static void decodeQueryParam(MultivaluedMap<String, String> params, String param, boolean decode)
/*     */   {
/*     */     try {
/* 517 */       int equals = param.indexOf('=');
/* 518 */       if (equals > 0) {
/* 519 */         params.add(URLDecoder.decode(param.substring(0, equals), "UTF-8"), decode ? URLDecoder.decode(param.substring(equals + 1), "UTF-8") : param.substring(equals + 1));
/*     */ 
/*     */       }
/* 522 */       else if (equals != 0)
/*     */       {
/* 524 */         if (param.length() > 0) {
/* 525 */           params.add(URLDecoder.decode(param, "UTF-8"), "");
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (UnsupportedEncodingException ex)
/*     */     {
/* 531 */       throw new IllegalArgumentException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class PathSegmentImpl implements PathSegment
/*     */   {
/* 537 */     private static final PathSegment EMPTY_PATH_SEGMENT = new PathSegmentImpl("", false);
/*     */     private final String path;
/*     */     private final MultivaluedMap<String, String> matrixParameters;
/*     */     
/*     */     PathSegmentImpl(String path, boolean decode) {
/* 542 */       this(path, decode, new MultivaluedMapImpl());
/*     */     }
/*     */     
/*     */     PathSegmentImpl(String path, boolean decode, MultivaluedMap<String, String> matrixParameters) {
/* 546 */       this.path = (decode ? UriComponent.decode(path, UriComponent.Type.PATH_SEGMENT) : path);
/* 547 */       this.matrixParameters = matrixParameters;
/*     */     }
/*     */     
/*     */     public String getPath()
/*     */     {
/* 552 */       return this.path;
/*     */     }
/*     */     
/*     */     public MultivaluedMap<String, String> getMatrixParameters()
/*     */     {
/* 557 */       return this.matrixParameters;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<PathSegment> decodePath(URI u, boolean decode)
/*     */   {
/* 572 */     String rawPath = u.getRawPath();
/* 573 */     if ((rawPath != null) && (rawPath.length() > 0) && (rawPath.charAt(0) == '/')) {
/* 574 */       rawPath = rawPath.substring(1);
/*     */     }
/* 576 */     return decodePath(rawPath, decode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<PathSegment> decodePath(String path, boolean decode)
/*     */   {
/* 595 */     List<PathSegment> segments = new LinkedList();
/*     */     
/* 597 */     if (path == null) {
/* 598 */       return segments;
/*     */     }
/*     */     
/* 601 */     int s = 0;
/* 602 */     int e = -1;
/*     */     do {
/* 604 */       s = e + 1;
/* 605 */       e = path.indexOf('/', s);
/*     */       
/* 607 */       if (e > s) {
/* 608 */         decodePathSegment(segments, path.substring(s, e), decode);
/* 609 */       } else if (e == s) {
/* 610 */         segments.add(PathSegmentImpl.EMPTY_PATH_SEGMENT);
/*     */       }
/* 612 */     } while (e != -1);
/* 613 */     if (s < path.length()) {
/* 614 */       decodePathSegment(segments, path.substring(s), decode);
/*     */     } else {
/* 616 */       segments.add(PathSegmentImpl.EMPTY_PATH_SEGMENT);
/*     */     }
/* 618 */     return segments;
/*     */   }
/*     */   
/*     */   public static void decodePathSegment(List<PathSegment> segments, String segment, boolean decode) {
/* 622 */     int colon = segment.indexOf(';');
/* 623 */     if (colon != -1) {
/* 624 */       segments.add(new PathSegmentImpl(colon == 0 ? "" : segment.substring(0, colon), decode, decodeMatrix(segment, decode)));
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 629 */       segments.add(new PathSegmentImpl(segment, decode));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MultivaluedMap<String, String> decodeMatrix(String pathSegment, boolean decode)
/*     */   {
/* 644 */     MultivaluedMap<String, String> matrixMap = new MultivaluedMapImpl();
/*     */     
/*     */ 
/* 647 */     int s = pathSegment.indexOf(';') + 1;
/* 648 */     if ((s == 0) || (s == pathSegment.length())) {
/* 649 */       return matrixMap;
/*     */     }
/*     */     
/* 652 */     int e = 0;
/*     */     do {
/* 654 */       e = pathSegment.indexOf(';', s);
/*     */       
/* 656 */       if (e == -1) {
/* 657 */         decodeMatrixParam(matrixMap, pathSegment.substring(s), decode);
/* 658 */       } else if (e > s) {
/* 659 */         decodeMatrixParam(matrixMap, pathSegment.substring(s, e), decode);
/*     */       }
/* 661 */       s = e + 1;
/* 662 */     } while ((s > 0) && (s < pathSegment.length()));
/*     */     
/* 664 */     return matrixMap;
/*     */   }
/*     */   
/*     */   private static void decodeMatrixParam(MultivaluedMap<String, String> params, String param, boolean decode)
/*     */   {
/* 669 */     int equals = param.indexOf('=');
/* 670 */     if (equals > 0) {
/* 671 */       params.add(decode(param.substring(0, equals), Type.MATRIX_PARAM), decode ? decode(param.substring(equals + 1), Type.MATRIX_PARAM) : param.substring(equals + 1));
/*     */ 
/*     */     }
/* 674 */     else if (equals != 0)
/*     */     {
/* 676 */       if (param.length() > 0) {
/* 677 */         params.add(decode(param, Type.MATRIX_PARAM), "");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static String decode(String s, int n)
/*     */   {
/* 684 */     StringBuilder sb = new StringBuilder(n);
/* 685 */     ByteBuffer bb = null;
/*     */     
/* 687 */     for (int i = 0; i < n;) {
/* 688 */       char c = s.charAt(i++);
/* 689 */       if (c != '%') {
/* 690 */         sb.append(c);
/*     */       } else {
/* 692 */         bb = decodePercentEncodedOctets(s, i, bb);
/* 693 */         i = decodeOctets(i, bb, sb);
/*     */       }
/*     */     }
/*     */     
/* 697 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private static String decodeQueryParam(String s, int n) {
/* 701 */     StringBuilder sb = new StringBuilder(n);
/* 702 */     ByteBuffer bb = null;
/*     */     
/* 704 */     for (int i = 0; i < n;) {
/* 705 */       char c = s.charAt(i++);
/* 706 */       if (c != '%') {
/* 707 */         if (c != '+') {
/* 708 */           sb.append(c);
/*     */         } else
/* 710 */           sb.append(' ');
/*     */       } else {
/* 712 */         bb = decodePercentEncodedOctets(s, i, bb);
/* 713 */         i = decodeOctets(i, bb, sb);
/*     */       }
/*     */     }
/*     */     
/* 717 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private static String decodeHost(String s, int n) {
/* 721 */     StringBuilder sb = new StringBuilder(n);
/* 722 */     ByteBuffer bb = null;
/*     */     
/* 724 */     boolean betweenBrackets = false;
/* 725 */     for (int i = 0; i < n;) {
/* 726 */       char c = s.charAt(i++);
/* 727 */       if (c == '[') {
/* 728 */         betweenBrackets = true;
/* 729 */       } else if ((betweenBrackets) && (c == ']')) {
/* 730 */         betweenBrackets = false;
/*     */       }
/*     */       
/* 733 */       if ((c != '%') || (betweenBrackets)) {
/* 734 */         sb.append(c);
/*     */       } else {
/* 736 */         bb = decodePercentEncodedOctets(s, i, bb);
/* 737 */         i = decodeOctets(i, bb, sb);
/*     */       }
/*     */     }
/*     */     
/* 741 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ByteBuffer decodePercentEncodedOctets(String s, int i, ByteBuffer bb)
/*     */   {
/* 751 */     if (bb == null) {
/* 752 */       bb = ByteBuffer.allocate(1);
/*     */     } else {
/* 754 */       bb.clear();
/*     */     }
/*     */     for (;;)
/*     */     {
/* 758 */       bb.put((byte)(decodeHex(s, i++) << 4 | decodeHex(s, i++)));
/*     */       
/*     */ 
/* 761 */       if (i == s.length()) {
/*     */         break;
/*     */       }
/*     */       
/*     */ 
/* 766 */       if (s.charAt(i++) != '%') {
/*     */         break;
/*     */       }
/*     */       
/*     */ 
/* 771 */       if (bb.position() == bb.capacity()) {
/* 772 */         bb.flip();
/*     */         
/*     */ 
/* 775 */         ByteBuffer bb_new = ByteBuffer.allocate(s.length() / 3);
/* 776 */         bb_new.put(bb);
/* 777 */         bb = bb_new;
/*     */       }
/*     */     }
/*     */     
/* 781 */     bb.flip();
/* 782 */     return bb;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int decodeOctets(int i, ByteBuffer bb, StringBuilder sb)
/*     */   {
/* 792 */     if ((bb.limit() == 1) && ((bb.get(0) & 0xFF) < 128))
/*     */     {
/* 794 */       sb.append((char)bb.get(0));
/* 795 */       return i + 2;
/*     */     }
/*     */     
/* 798 */     CharBuffer cb = UTF_8_CHARSET.decode(bb);
/* 799 */     sb.append(cb.toString());
/* 800 */     return i + bb.limit() * 3 - 1;
/*     */   }
/*     */   
/*     */   private static int decodeHex(String s, int i)
/*     */   {
/* 805 */     int v = decodeHex(s.charAt(i));
/* 806 */     if (v == -1)
/*     */     {
/* 808 */       throw new IllegalArgumentException("Malformed percent-encoded octet at index " + i + ", invalid hexadecimal digit '" + s.charAt(i) + "'");
/*     */     }
/*     */     
/* 811 */     return v; }
/*     */   
/* 813 */   private static final int[] HEX_TABLE = initHexTable();
/*     */   
/*     */   private static int[] initHexTable() {
/* 816 */     int[] table = new int[''];
/* 817 */     Arrays.fill(table, -1);
/*     */     
/* 819 */     for (char c = '0'; c <= '9'; c = (char)(c + '\001')) {
/* 820 */       table[c] = (c - '0');
/*     */     }
/* 822 */     for (char c = 'A'; c <= 'F'; c = (char)(c + '\001')) {
/* 823 */       table[c] = (c - 'A' + 10);
/*     */     }
/* 825 */     for (char c = 'a'; c <= 'f'; c = (char)(c + '\001')) {
/* 826 */       table[c] = (c - 'a' + 10);
/*     */     }
/* 828 */     return table;
/*     */   }
/*     */   
/*     */   private static int decodeHex(char c) {
/* 832 */     return c < '' ? HEX_TABLE[c] : -1;
/*     */   }
/*     */   
/*     */   private static boolean isHexCharacter(char c) {
/* 836 */     return (c < '') && (HEX_TABLE[c] != -1);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\api\uri\UriComponent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */