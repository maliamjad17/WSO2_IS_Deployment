/*    */ package com.sun.jersey.core.spi.scanning.uri;
/*    */ 
/*    */ import com.sun.jersey.core.spi.scanning.ScannerException;
/*    */ import com.sun.jersey.core.spi.scanning.ScannerListener;
/*    */ import com.sun.jersey.core.util.Closing;
/*    */ import com.sun.jersey.core.util.Closing.Closure;
/*    */ import java.io.BufferedInputStream;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.URI;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileSchemeScanner
/*    */   implements UriSchemeScanner
/*    */ {
/*    */   public Set<String> getSchemes()
/*    */   {
/* 63 */     return Collections.singleton("file");
/*    */   }
/*    */   
/*    */ 
/*    */   public void scan(URI u, ScannerListener cfl)
/*    */   {
/* 69 */     File f = new File(u.getPath());
/* 70 */     if (f.isDirectory()) {
/* 71 */       scanDirectory(f, cfl);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   private void scanDirectory(File root, final ScannerListener cfl)
/*    */   {
/* 78 */     for (final File child : root.listFiles()) {
/* 79 */       if (child.isDirectory()) {
/* 80 */         scanDirectory(child, cfl);
/* 81 */       } else if (cfl.onAccept(child.getName())) {
/*    */         try {
/* 83 */           new Closing(new BufferedInputStream(new FileInputStream(child))).f(new Closing.Closure()
/*    */           {
/*    */             public void f(InputStream in) throws IOException {
/* 86 */               cfl.onProcess(child.getName(), in);
/*    */             }
/*    */           });
/*    */         } catch (IOException ex) {
/* 90 */           throw new ScannerException("IO error when scanning jar file " + child, ex);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\scanning\uri\FileSchemeScanner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */