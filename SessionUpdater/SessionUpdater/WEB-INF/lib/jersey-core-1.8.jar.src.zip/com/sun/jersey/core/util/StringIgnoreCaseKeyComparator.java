/*    */ package com.sun.jersey.core.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringIgnoreCaseKeyComparator
/*    */   implements KeyComparator<String>
/*    */ {
/* 49 */   public static final StringIgnoreCaseKeyComparator SINGLETON = new StringIgnoreCaseKeyComparator();
/*    */   
/*    */   public int hash(String k)
/*    */   {
/* 53 */     return k.toLowerCase().hashCode();
/*    */   }
/*    */   
/*    */   public boolean equals(String x, String y) {
/* 57 */     return x.equalsIgnoreCase(y);
/*    */   }
/*    */   
/*    */   public int compare(String o1, String o2) {
/* 61 */     return o1.compareToIgnoreCase(o2);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\util\StringIgnoreCaseKeyComparator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */