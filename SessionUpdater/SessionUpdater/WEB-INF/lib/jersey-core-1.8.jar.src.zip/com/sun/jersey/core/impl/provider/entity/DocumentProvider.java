/*     */ package com.sun.jersey.core.impl.provider.entity;
/*     */ 
/*     */ import com.sun.jersey.core.provider.AbstractMessageReaderWriterProvider;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import javax.ws.rs.Consumes;
/*     */ import javax.ws.rs.Produces;
/*     */ import javax.ws.rs.WebApplicationException;
/*     */ import javax.ws.rs.core.Context;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.core.Response.Status;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import org.w3c.dom.Document;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Produces({"application/xml", "text/xml", "*/*"})
/*     */ @Consumes({"application/xml", "text/xml", "*/*"})
/*     */ public final class DocumentProvider
/*     */   extends AbstractMessageReaderWriterProvider<Document>
/*     */ {
/*     */   private final Injectable<DocumentBuilderFactory> dbf;
/*     */   private final Injectable<TransformerFactory> tf;
/*     */   
/*     */   public DocumentProvider(@Context Injectable<DocumentBuilderFactory> dbf, @Context Injectable<TransformerFactory> tf)
/*     */   {
/*  82 */     this.dbf = dbf;
/*  83 */     this.tf = tf;
/*     */   }
/*     */   
/*     */   public boolean isReadable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
/*  87 */     return Document.class == type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Document readFrom(Class<Document> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, String> httpHeaders, InputStream entityStream)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/*  98 */       return ((DocumentBuilderFactory)this.dbf.getValue()).newDocumentBuilder().parse(entityStream);
/*     */     } catch (SAXException ex) {
/* 100 */       throw new WebApplicationException(ex, Response.Status.BAD_REQUEST);
/*     */     } catch (ParserConfigurationException ex) {
/* 102 */       throw new WebApplicationException(ex, Response.Status.INTERNAL_SERVER_ERROR);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
/* 107 */     return Document.class.isAssignableFrom(type);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeTo(Document t, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, OutputStream entityStream)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 119 */       StreamResult sr = new StreamResult(entityStream);
/* 120 */       ((TransformerFactory)this.tf.getValue()).newTransformer().transform(new DOMSource(t), sr);
/*     */     } catch (TransformerException ex) {
/* 122 */       throw new WebApplicationException(ex, Response.Status.INTERNAL_SERVER_ERROR);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\entity\DocumentProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */