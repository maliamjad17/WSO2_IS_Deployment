/*     */ package com.sun.jersey.api.uri;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.regex.PatternSyntaxException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UriTemplateParser
/*     */ {
/*  59 */   static final int[] EMPTY_INT_ARRAY = new int[0];
/*  60 */   private static final Set<Character> RESERVED_REGEX_CHARACTERS = initReserved();
/*     */   
/*     */   private static Set<Character> initReserved()
/*     */   {
/*  64 */     char[] reserved = { '.', '?', '(', ')' };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  70 */     Set<Character> s = new HashSet(reserved.length);
/*  71 */     for (char c : reserved) {
/*  72 */       s.add(Character.valueOf(c));
/*     */     }
/*  74 */     return s; }
/*     */   
/*  76 */   private static final Pattern TEMPLATE_VALUE_PATTERN = Pattern.compile("[^/]+?");
/*     */   
/*     */ 
/*     */   private final String template;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final class StringCharacterIterator
/*     */     implements UriTemplateParser.CharacterIterator
/*     */   {
/*     */     private int pos;
/*     */     
/*     */ 
/*     */     private String s;
/*     */     
/*     */ 
/*     */ 
/*     */     public StringCharacterIterator(String s)
/*     */     {
/*  95 */       this.s = s;
/*  96 */       this.pos = 0;
/*     */     }
/*     */     
/*     */     public boolean hasNext()
/*     */     {
/* 101 */       return this.pos < this.s.length();
/*     */     }
/*     */     
/*     */     public char next()
/*     */     {
/* 106 */       if (!hasNext()) {
/* 107 */         throw new NoSuchElementException();
/*     */       }
/* 109 */       return this.s.charAt(this.pos++);
/*     */     }
/*     */     
/*     */     public char peek()
/*     */     {
/* 114 */       if (!hasNext()) {
/* 115 */         throw new NoSuchElementException();
/*     */       }
/*     */       
/* 118 */       return this.s.charAt(this.pos);
/*     */     }
/*     */     
/*     */     public int pos()
/*     */     {
/* 123 */       if (this.pos == 0) {
/* 124 */         throw new IllegalStateException("Iterator not used yet.");
/*     */       }
/*     */       
/* 127 */       return this.pos - 1;
/*     */     }
/*     */   }
/*     */   
/* 131 */   private final StringBuffer regex = new StringBuffer();
/* 132 */   private final StringBuffer normalizedTemplate = new StringBuffer();
/* 133 */   private final StringBuffer literalCharactersBuffer = new StringBuffer();
/*     */   private final Pattern pattern;
/* 135 */   private final List<String> names = new ArrayList();
/* 136 */   private final List<Integer> groupCounts = new ArrayList();
/* 137 */   private final Map<String, Pattern> nameToPattern = new HashMap();
/*     */   
/*     */ 
/*     */   private int numOfExplicitRegexes;
/*     */   
/*     */ 
/*     */   private int literalCharacters;
/*     */   
/*     */ 
/*     */   public UriTemplateParser(String template)
/*     */     throws IllegalArgumentException
/*     */   {
/* 149 */     if ((template == null) || (template.length() == 0)) {
/* 150 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 153 */     this.template = template;
/* 154 */     parse(new StringCharacterIterator(template));
/*     */     try {
/* 156 */       this.pattern = Pattern.compile(this.regex.toString());
/*     */     } catch (PatternSyntaxException ex) {
/* 158 */       throw new IllegalArgumentException("Invalid syntax for the template expression '" + this.regex + "'", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getTemplate()
/*     */   {
/* 170 */     return this.template;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Pattern getPattern()
/*     */   {
/* 179 */     return this.pattern;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getNormalizedTemplate()
/*     */   {
/* 191 */     return this.normalizedTemplate.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Map<String, Pattern> getNameToPattern()
/*     */   {
/* 200 */     return this.nameToPattern;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final List<String> getNames()
/*     */   {
/* 209 */     return this.names;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final List<Integer> getGroupCounts()
/*     */   {
/* 218 */     return this.groupCounts;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int[] getGroupIndexes()
/*     */   {
/* 231 */     if (this.names.isEmpty()) {
/* 232 */       return EMPTY_INT_ARRAY;
/*     */     }
/*     */     
/* 235 */     int[] indexes = new int[this.names.size() + 1];
/* 236 */     indexes[0] = 1;
/* 237 */     for (int i = 1; i < indexes.length; i++) {
/* 238 */       indexes[i] = (indexes[(i - 1)] + ((Integer)this.groupCounts.get(i - 1)).intValue());
/*     */     }
/* 240 */     for (int i = 0; i < indexes.length; i++) {
/* 241 */       if (indexes[i] != i + 1) {
/* 242 */         return indexes;
/*     */       }
/*     */     }
/* 245 */     return EMPTY_INT_ARRAY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getNumberOfExplicitRegexes()
/*     */   {
/* 254 */     return this.numOfExplicitRegexes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getNumberOfLiteralCharacters()
/*     */   {
/* 263 */     return this.literalCharacters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String encodeLiteralCharacters(String characters)
/*     */   {
/* 273 */     return characters;
/*     */   }
/*     */   
/*     */   private void parse(CharacterIterator ci) {
/*     */     try {
/* 278 */       while (ci.hasNext()) {
/* 279 */         char c = ci.next();
/* 280 */         if (c == '{') {
/* 281 */           processLiteralCharacters();
/* 282 */           parseName(ci);
/*     */         } else {
/* 284 */           this.literalCharactersBuffer.append(c);
/*     */         }
/*     */       }
/* 287 */       processLiteralCharacters();
/*     */     } catch (NoSuchElementException ex) {
/* 289 */       throw new IllegalArgumentException("Invalid syntax for the template, \"" + this.template + "\". Check if a path parameter is terminated with a '}'.", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void processLiteralCharacters()
/*     */   {
/* 297 */     if (this.literalCharactersBuffer.length() > 0) {
/* 298 */       this.literalCharacters += this.literalCharactersBuffer.length();
/*     */       
/* 300 */       String s = encodeLiteralCharacters(this.literalCharactersBuffer.toString());
/*     */       
/* 302 */       this.normalizedTemplate.append(s);
/*     */       
/*     */ 
/* 305 */       for (int i = 0; i < s.length(); i++) {
/* 306 */         char c = s.charAt(i);
/* 307 */         if (RESERVED_REGEX_CHARACTERS.contains(Character.valueOf(c))) {
/* 308 */           this.regex.append("\\");
/*     */         }
/* 310 */         this.regex.append(c);
/*     */       }
/*     */       
/* 313 */       this.literalCharactersBuffer.setLength(0);
/*     */     }
/*     */   }
/*     */   
/*     */   private void parseName(CharacterIterator ci) {
/* 318 */     char c = consumeWhiteSpace(ci);
/*     */     
/* 320 */     StringBuilder nameBuffer = new StringBuilder();
/* 321 */     if ((Character.isLetterOrDigit(c)) || (c == '_'))
/*     */     {
/* 323 */       nameBuffer.append(c);
/*     */     } else {
/* 325 */       throw new IllegalArgumentException("Illegal character '" + c + "' at position " + ci.pos() + " is not as the start of a name");
/*     */     }
/*     */     
/*     */ 
/* 329 */     String nameRegexString = "";
/*     */     for (;;) {
/* 331 */       c = ci.next();
/*     */       
/* 333 */       if ((!Character.isLetterOrDigit(c)) && (c != '_') && (c != '-') && (c != '.'))
/*     */         break;
/* 335 */       nameBuffer.append(c); }
/* 336 */     if (c == ':') {
/* 337 */       nameRegexString = parseRegex(ci);
/*     */     }
/* 339 */     else if (c != '}')
/*     */     {
/* 341 */       if (c == ' ') {
/* 342 */         c = consumeWhiteSpace(ci);
/*     */         
/* 344 */         if (c == ':') {
/* 345 */           nameRegexString = parseRegex(ci);
/*     */         }
/* 347 */         else if (c != '}')
/*     */         {
/*     */ 
/*     */ 
/* 351 */           throw new IllegalArgumentException("Illegal character '" + c + "' at position " + ci.pos() + " is not allowed after a name");
/*     */         }
/*     */       }
/*     */       else {
/* 355 */         throw new IllegalArgumentException("Illegal character '" + c + "' at position " + ci.pos() + " is not allowed as part of a name");
/*     */       }
/*     */     }
/*     */     
/* 359 */     String name = nameBuffer.toString();
/* 360 */     this.names.add(name);
/*     */     try
/*     */     {
/* 363 */       if (nameRegexString.length() > 0) {
/* 364 */         this.numOfExplicitRegexes += 1;
/*     */       }
/* 366 */       Pattern namePattern = nameRegexString.length() == 0 ? TEMPLATE_VALUE_PATTERN : Pattern.compile(nameRegexString);
/*     */       
/* 368 */       if (this.nameToPattern.containsKey(name)) {
/* 369 */         if (!((Pattern)this.nameToPattern.get(name)).equals(namePattern)) {
/* 370 */           throw new IllegalArgumentException("The name '" + name + "' is declared " + "more than once with different regular expressions");
/*     */         }
/*     */         
/*     */       }
/*     */       else {
/* 375 */         this.nameToPattern.put(name, namePattern);
/*     */       }
/*     */       
/*     */ 
/* 379 */       Matcher m = namePattern.matcher("");
/* 380 */       int g = m.groupCount();
/* 381 */       this.groupCounts.add(Integer.valueOf(g + 1));
/*     */       
/* 383 */       this.regex.append('(').append(namePattern).append(')');
/*     */       
/*     */ 
/* 386 */       this.normalizedTemplate.append('{').append(name).append('}');
/*     */     }
/*     */     catch (PatternSyntaxException ex)
/*     */     {
/* 390 */       throw new IllegalArgumentException("Invalid syntax for the expression '" + nameRegexString + "' associated with the name '" + name + "'", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private String parseRegex(CharacterIterator ci)
/*     */   {
/* 397 */     StringBuilder regexBuffer = new StringBuilder();
/*     */     
/* 399 */     int braceCount = 1;
/*     */     for (;;) {
/* 401 */       char c = ci.next();
/* 402 */       if (c == '{') {
/* 403 */         braceCount++;
/* 404 */       } else if (c == '}') {
/* 405 */         braceCount--;
/* 406 */         if (braceCount == 0) {
/*     */           break;
/*     */         }
/*     */       }
/* 410 */       regexBuffer.append(c);
/*     */     }
/*     */     
/* 413 */     return regexBuffer.toString().trim();
/*     */   }
/*     */   
/*     */   private char consumeWhiteSpace(CharacterIterator ci) {
/*     */     char c;
/*     */     do {
/* 419 */       c = ci.next();
/* 420 */     } while (Character.isWhitespace(c));
/*     */     
/* 422 */     return c;
/*     */   }
/*     */   
/*     */   private static abstract interface CharacterIterator
/*     */   {
/*     */     public abstract boolean hasNext();
/*     */     
/*     */     public abstract char next();
/*     */     
/*     */     public abstract char peek();
/*     */     
/*     */     public abstract int pos();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\api\uri\UriTemplateParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */