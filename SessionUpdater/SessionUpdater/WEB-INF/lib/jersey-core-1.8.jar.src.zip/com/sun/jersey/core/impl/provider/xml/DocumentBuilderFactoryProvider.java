/*    */ package com.sun.jersey.core.impl.provider.xml;
/*    */ 
/*    */ import com.sun.jersey.core.util.FeaturesAndProperties;
/*    */ import java.util.logging.Logger;
/*    */ import javax.ws.rs.core.Context;
/*    */ import javax.xml.parsers.DocumentBuilderFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DocumentBuilderFactoryProvider
/*    */   extends ThreadLocalSingletonContextProvider<DocumentBuilderFactory>
/*    */ {
/* 53 */   private static final Logger LOGGER = Logger.getLogger(DocumentBuilderFactoryProvider.class.getName());
/*    */   
/*    */   private final boolean disableXmlSecurity;
/*    */   
/*    */   public DocumentBuilderFactoryProvider(@Context FeaturesAndProperties fps)
/*    */   {
/* 59 */     super(DocumentBuilderFactory.class);
/*    */     
/* 61 */     this.disableXmlSecurity = fps.getFeature("com.sun.jersey.config.feature.DisableXmlSecurity");
/*    */   }
/*    */   
/*    */   protected DocumentBuilderFactory getInstance()
/*    */   {
/* 66 */     DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
/*    */     
/* 68 */     f.setNamespaceAware(true);
/*    */     
/* 70 */     if (!this.disableXmlSecurity) {
/* 71 */       f.setExpandEntityReferences(false);
/*    */     }
/*    */     
/* 74 */     return f;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\xml\DocumentBuilderFactoryProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */