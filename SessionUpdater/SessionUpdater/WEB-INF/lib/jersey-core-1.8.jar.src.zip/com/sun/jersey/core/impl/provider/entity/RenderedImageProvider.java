/*     */ package com.sun.jersey.core.impl.provider.entity;
/*     */ 
/*     */ import com.sun.jersey.core.provider.AbstractMessageReaderWriterProvider;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.RenderedImage;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Iterator;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.imageio.ImageReader;
/*     */ import javax.imageio.ImageWriter;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ import javax.ws.rs.Consumes;
/*     */ import javax.ws.rs.Produces;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Produces({"image/*"})
/*     */ @Consumes({"image/*", "application/octet-stream"})
/*     */ public final class RenderedImageProvider
/*     */   extends AbstractMessageReaderWriterProvider<RenderedImage>
/*     */ {
/*  69 */   private static final MediaType IMAGE_MEDIA_TYPE = new MediaType("image", "*");
/*     */   
/*     */   public boolean isReadable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
/*  72 */     return (RenderedImage.class == type) || (BufferedImage.class == type);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RenderedImage readFrom(Class<RenderedImage> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, String> httpHeaders, InputStream entityStream)
/*     */     throws IOException
/*     */   {
/*  82 */     if (IMAGE_MEDIA_TYPE.isCompatible(mediaType)) {
/*  83 */       Iterator<ImageReader> readers = ImageIO.getImageReadersByMIMEType(mediaType.toString());
/*  84 */       if (!readers.hasNext())
/*  85 */         throw new IOException("The image-based media type " + mediaType + "is not supported for reading");
/*  86 */       ImageReader reader = (ImageReader)readers.next();
/*     */       
/*  88 */       ImageInputStream in = ImageIO.createImageInputStream(entityStream);
/*  89 */       reader.setInput(in, true, true);
/*  90 */       BufferedImage bi = reader.read(0, reader.getDefaultReadParam());
/*  91 */       in.close();
/*  92 */       reader.dispose();
/*  93 */       return bi;
/*     */     }
/*  95 */     return ImageIO.read(entityStream);
/*     */   }
/*     */   
/*     */   public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType)
/*     */   {
/* 100 */     return RenderedImage.class.isAssignableFrom(type);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeTo(RenderedImage t, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, OutputStream entityStream)
/*     */     throws IOException
/*     */   {
/* 111 */     String formatName = getWriterFormatName(mediaType);
/* 112 */     if (formatName == null)
/* 113 */       throw new IOException("The image-based media type " + mediaType + " is not supported for writing");
/* 114 */     ImageIO.write(t, formatName, entityStream);
/*     */   }
/*     */   
/*     */   private String getWriterFormatName(MediaType t) {
/* 118 */     return getWriterFormatName(t.toString());
/*     */   }
/*     */   
/*     */   private String getWriterFormatName(String t) {
/* 122 */     Iterator<ImageWriter> i = ImageIO.getImageWritersByMIMEType(t);
/* 123 */     if (!i.hasNext()) { return null;
/*     */     }
/* 125 */     return ((ImageWriter)i.next()).getOriginatingProvider().getFormatNames()[0];
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\entity\RenderedImageProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */