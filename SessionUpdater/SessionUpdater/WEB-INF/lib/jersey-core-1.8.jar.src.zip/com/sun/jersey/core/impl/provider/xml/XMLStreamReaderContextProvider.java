/*    */ package com.sun.jersey.core.impl.provider.xml;
/*    */ 
/*    */ import com.sun.jersey.core.util.FeaturesAndProperties;
/*    */ import javax.ws.rs.core.Context;
/*    */ import javax.xml.stream.XMLInputFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLStreamReaderContextProvider
/*    */   extends ThreadLocalSingletonContextProvider<XMLInputFactory>
/*    */ {
/*    */   private final boolean disableXmlSecurity;
/*    */   
/*    */   public XMLStreamReaderContextProvider(@Context FeaturesAndProperties fps)
/*    */   {
/* 56 */     super(XMLInputFactory.class);
/*    */     
/* 58 */     this.disableXmlSecurity = fps.getFeature("com.sun.jersey.config.feature.DisableXmlSecurity");
/*    */   }
/*    */   
/*    */   protected XMLInputFactory getInstance()
/*    */   {
/* 63 */     XMLInputFactory f = XMLInputFactory.newInstance();
/*    */     
/* 65 */     if (!this.disableXmlSecurity) {
/* 66 */       f.setProperty("javax.xml.stream.isReplacingEntityReferences", Boolean.FALSE);
/*    */     }
/*    */     
/*    */ 
/* 70 */     return f;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\xml\XMLStreamReaderContextProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */