/*     */ package com.sun.jersey.api.uri;
/*     */ 
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javax.ws.rs.Path;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.core.UriBuilder;
/*     */ import javax.ws.rs.core.UriBuilderException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UriBuilderImpl
/*     */   extends UriBuilder
/*     */ {
/*     */   private String scheme;
/*     */   private String ssp;
/*     */   private String authority;
/*     */   private String userInfo;
/*     */   private String host;
/*  73 */   private int port = -1;
/*     */   
/*     */   private final StringBuilder path;
/*     */   
/*     */   private MultivaluedMap<String, String> matrixParams;
/*     */   
/*     */   private final StringBuilder query;
/*     */   
/*     */   private MultivaluedMap<String, String> queryParams;
/*     */   private String fragment;
/*     */   
/*     */   public UriBuilderImpl()
/*     */   {
/*  86 */     this.path = new StringBuilder();
/*  87 */     this.query = new StringBuilder();
/*     */   }
/*     */   
/*     */   private UriBuilderImpl(UriBuilderImpl that) {
/*  91 */     this.scheme = that.scheme;
/*  92 */     this.ssp = that.ssp;
/*  93 */     this.userInfo = that.userInfo;
/*  94 */     this.host = that.host;
/*  95 */     this.port = that.port;
/*  96 */     this.path = new StringBuilder(that.path);
/*  97 */     this.query = new StringBuilder(that.query);
/*  98 */     this.fragment = that.fragment;
/*     */   }
/*     */   
/*     */   public UriBuilder clone()
/*     */   {
/* 103 */     return new UriBuilderImpl(this);
/*     */   }
/*     */   
/*     */   public UriBuilder uri(URI uri)
/*     */   {
/* 108 */     if (uri == null) {
/* 109 */       throw new IllegalArgumentException("URI parameter is null");
/*     */     }
/* 111 */     if (uri.getRawFragment() != null) { this.fragment = uri.getRawFragment();
/*     */     }
/* 113 */     if (uri.isOpaque()) {
/* 114 */       this.scheme = uri.getScheme();
/* 115 */       this.ssp = uri.getRawSchemeSpecificPart();
/* 116 */       return this;
/*     */     }
/*     */     
/* 119 */     if (uri.getScheme() == null) {
/* 120 */       if ((this.ssp != null) && 
/* 121 */         (uri.getRawSchemeSpecificPart() != null)) {
/* 122 */         this.ssp = uri.getRawSchemeSpecificPart();
/* 123 */         return this;
/*     */       }
/*     */     }
/*     */     else {
/* 127 */       this.scheme = uri.getScheme();
/*     */     }
/*     */     
/* 130 */     this.ssp = null;
/* 131 */     if (uri.getRawAuthority() != null) {
/* 132 */       if ((uri.getRawUserInfo() == null) && (uri.getHost() == null) && (uri.getPort() == -1)) {
/* 133 */         this.authority = uri.getRawAuthority();
/* 134 */         this.userInfo = null;
/* 135 */         this.host = null;
/* 136 */         this.port = -1;
/*     */       } else {
/* 138 */         this.authority = null;
/* 139 */         if (uri.getRawUserInfo() != null) this.userInfo = uri.getRawUserInfo();
/* 140 */         if (uri.getHost() != null) this.host = uri.getHost();
/* 141 */         if (uri.getPort() != -1) { this.port = uri.getPort();
/*     */         }
/*     */       }
/*     */     }
/* 145 */     if ((uri.getRawPath() != null) && (uri.getRawPath().length() > 0)) {
/* 146 */       this.path.setLength(0);
/* 147 */       this.path.append(uri.getRawPath());
/*     */     }
/* 149 */     if ((uri.getRawQuery() != null) && (uri.getRawQuery().length() > 0)) {
/* 150 */       this.query.setLength(0);
/* 151 */       this.query.append(uri.getRawQuery());
/*     */     }
/*     */     
/*     */ 
/* 155 */     return this;
/*     */   }
/*     */   
/*     */   public UriBuilder scheme(String scheme)
/*     */   {
/* 160 */     if (scheme != null) {
/* 161 */       this.scheme = scheme;
/* 162 */       UriComponent.validate(scheme, UriComponent.Type.SCHEME, true);
/*     */     } else {
/* 164 */       this.scheme = null;
/*     */     }
/* 166 */     return this;
/*     */   }
/*     */   
/*     */   public UriBuilder schemeSpecificPart(String ssp)
/*     */   {
/* 171 */     if (ssp == null) {
/* 172 */       throw new IllegalArgumentException("Scheme specific part parameter is null");
/*     */     }
/*     */     
/*     */ 
/* 176 */     StringBuilder sb = new StringBuilder();
/* 177 */     if (this.scheme != null) sb.append(this.scheme).append(':');
/* 178 */     if (ssp != null)
/* 179 */       sb.append(ssp);
/* 180 */     if ((this.fragment != null) && (this.fragment.length() > 0)) sb.append('#').append(this.fragment);
/* 181 */     URI uri = createURI(sb.toString());
/*     */     
/* 183 */     if ((uri.getRawSchemeSpecificPart() != null) && (uri.getRawPath() == null)) {
/* 184 */       this.ssp = uri.getRawSchemeSpecificPart();
/*     */     } else {
/* 186 */       this.ssp = null;
/*     */       
/* 188 */       if (uri.getRawAuthority() != null) {
/* 189 */         if ((uri.getRawUserInfo() == null) && (uri.getHost() == null) && (uri.getPort() == -1)) {
/* 190 */           this.authority = uri.getRawAuthority();
/* 191 */           this.userInfo = null;
/* 192 */           this.host = null;
/* 193 */           this.port = -1;
/*     */         } else {
/* 195 */           this.authority = null;
/* 196 */           this.userInfo = uri.getRawUserInfo();
/* 197 */           this.host = uri.getHost();
/* 198 */           this.port = uri.getPort();
/*     */         }
/*     */       }
/*     */       
/* 202 */       this.path.setLength(0);
/* 203 */       this.path.append(replaceNull(uri.getRawPath()));
/*     */       
/* 205 */       this.query.setLength(0);
/* 206 */       this.query.append(replaceNull(uri.getRawQuery()));
/*     */     }
/* 208 */     return this;
/*     */   }
/*     */   
/*     */   public UriBuilder userInfo(String ui)
/*     */   {
/* 213 */     checkSsp();
/* 214 */     this.userInfo = (ui != null ? encode(ui, UriComponent.Type.USER_INFO) : null);
/*     */     
/* 216 */     return this;
/*     */   }
/*     */   
/*     */   public UriBuilder host(String host)
/*     */   {
/* 221 */     checkSsp();
/* 222 */     if (host != null) {
/* 223 */       if (host.length() == 0)
/* 224 */         throw new IllegalArgumentException("Invalid host name");
/* 225 */       this.host = encode(host, UriComponent.Type.HOST);
/*     */     } else {
/* 227 */       this.host = null;
/*     */     }
/* 229 */     return this;
/*     */   }
/*     */   
/*     */   public UriBuilder port(int port)
/*     */   {
/* 234 */     checkSsp();
/* 235 */     if (port < -1)
/*     */     {
/* 237 */       throw new IllegalArgumentException("Invalid port value"); }
/* 238 */     this.port = port;
/* 239 */     return this;
/*     */   }
/*     */   
/*     */   public UriBuilder replacePath(String path)
/*     */   {
/* 244 */     checkSsp();
/* 245 */     this.path.setLength(0);
/* 246 */     if (path != null)
/* 247 */       appendPath(path);
/* 248 */     return this;
/*     */   }
/*     */   
/*     */   public UriBuilder path(String path)
/*     */   {
/* 253 */     checkSsp();
/* 254 */     appendPath(path);
/* 255 */     return this;
/*     */   }
/*     */   
/*     */   public UriBuilder path(Class resource)
/*     */   {
/* 260 */     checkSsp();
/* 261 */     if (resource == null) {
/* 262 */       throw new IllegalArgumentException("Resource parameter is null");
/*     */     }
/* 264 */     Class<?> c = resource;
/* 265 */     Path p = (Path)c.getAnnotation(Path.class);
/* 266 */     if (p == null)
/* 267 */       throw new IllegalArgumentException("The class, " + resource + " is not annotated with @Path");
/* 268 */     appendPath(p);
/* 269 */     return this;
/*     */   }
/*     */   
/*     */   public UriBuilder path(Class resource, String methodName)
/*     */   {
/* 274 */     checkSsp();
/* 275 */     if (resource == null)
/* 276 */       throw new IllegalArgumentException("Resource parameter is null");
/* 277 */     if (methodName == null) {
/* 278 */       throw new IllegalArgumentException("MethodName parameter is null");
/*     */     }
/* 280 */     Method[] methods = resource.getMethods();
/* 281 */     Method found = null;
/* 282 */     for (Method m : methods) {
/* 283 */       if (methodName.equals(m.getName())) {
/* 284 */         if (found == null) { found = m;
/*     */         } else {
/* 286 */           throw new IllegalArgumentException();
/*     */         }
/*     */       }
/*     */     }
/* 290 */     if (found == null) {
/* 291 */       throw new IllegalArgumentException("The method named, " + methodName + ", is not specified by " + resource);
/*     */     }
/*     */     
/* 294 */     appendPath(getPath(found));
/*     */     
/* 296 */     return this;
/*     */   }
/*     */   
/*     */   public UriBuilder path(Method method)
/*     */   {
/* 301 */     checkSsp();
/* 302 */     if (method == null)
/* 303 */       throw new IllegalArgumentException("Method is null");
/* 304 */     appendPath(getPath(method));
/* 305 */     return this;
/*     */   }
/*     */   
/*     */   private Path getPath(AnnotatedElement ae) {
/* 309 */     Path p = (Path)ae.getAnnotation(Path.class);
/* 310 */     if (p == null) {
/* 311 */       throw new IllegalArgumentException("The annotated element, " + ae + " is not annotated with @Path");
/*     */     }
/* 313 */     return p;
/*     */   }
/*     */   
/*     */   public UriBuilder segment(String... segments)
/*     */     throws IllegalArgumentException
/*     */   {
/* 319 */     checkSsp();
/* 320 */     if (segments == null) {
/* 321 */       throw new IllegalArgumentException("Segments parameter is null");
/*     */     }
/* 323 */     for (String segment : segments)
/* 324 */       appendPath(segment, true);
/* 325 */     return this;
/*     */   }
/*     */   
/*     */   public UriBuilder replaceMatrix(String matrix)
/*     */   {
/* 330 */     checkSsp();
/* 331 */     int i = this.path.lastIndexOf("/");
/* 332 */     if (i != -1) i = 0;
/* 333 */     i = this.path.indexOf(";", i);
/* 334 */     if (i != -1) {
/* 335 */       this.path.setLength(i + 1);
/*     */     } else {
/* 337 */       this.path.append(';');
/*     */     }
/*     */     
/* 340 */     if (matrix != null)
/* 341 */       this.path.append(encode(matrix, UriComponent.Type.PATH));
/* 342 */     return this;
/*     */   }
/*     */   
/*     */   public UriBuilder matrixParam(String name, Object... values)
/*     */   {
/* 347 */     checkSsp();
/* 348 */     if (name == null)
/* 349 */       throw new IllegalArgumentException("Name parameter is null");
/* 350 */     if (values == null)
/* 351 */       throw new IllegalArgumentException("Value parameter is null");
/* 352 */     if (values.length == 0) {
/* 353 */       return this;
/*     */     }
/* 355 */     name = encode(name, UriComponent.Type.MATRIX_PARAM);
/* 356 */     if (this.matrixParams == null) {
/* 357 */       for (Object value : values) {
/* 358 */         this.path.append(';').append(name);
/*     */         
/* 360 */         if (value == null) {
/* 361 */           throw new IllegalArgumentException("One or more of matrix value parameters are null");
/*     */         }
/* 363 */         String stringValue = value.toString();
/* 364 */         if (stringValue.length() > 0)
/* 365 */           this.path.append('=').append(encode(stringValue, UriComponent.Type.MATRIX_PARAM));
/*     */       }
/*     */     } else {
/* 368 */       for (Object value : values) {
/* 369 */         if (value == null) {
/* 370 */           throw new IllegalArgumentException("One or more of matrix value parameters are null");
/*     */         }
/* 372 */         this.matrixParams.add(name, encode(value.toString(), UriComponent.Type.MATRIX_PARAM));
/*     */       }
/*     */     }
/* 375 */     return this;
/*     */   }
/*     */   
/*     */   public UriBuilder replaceMatrixParam(String name, Object... values)
/*     */   {
/* 380 */     checkSsp();
/*     */     
/* 382 */     if (name == null) {
/* 383 */       throw new IllegalArgumentException("Name parameter is null");
/*     */     }
/*     */     
/* 386 */     if (this.matrixParams == null) {
/* 387 */       int i = this.path.lastIndexOf("/");
/* 388 */       if (i != -1) i = 0;
/* 389 */       this.matrixParams = UriComponent.decodeMatrix(i != -1 ? this.path.substring(i) : "", false);
/* 390 */       i = this.path.indexOf(";", i);
/* 391 */       if (i != -1) { this.path.setLength(i);
/*     */       }
/*     */     }
/* 394 */     name = encode(name, UriComponent.Type.MATRIX_PARAM);
/* 395 */     this.matrixParams.remove(name);
/* 396 */     if (values != null) {
/* 397 */       for (Object value : values) {
/* 398 */         if (value == null) {
/* 399 */           throw new IllegalArgumentException("One or more of matrix value parameters are null");
/*     */         }
/* 401 */         this.matrixParams.add(name, encode(value.toString(), UriComponent.Type.MATRIX_PARAM));
/*     */       }
/*     */     }
/* 404 */     return this;
/*     */   }
/*     */   
/*     */   public UriBuilder replaceQuery(String query)
/*     */   {
/* 409 */     checkSsp();
/* 410 */     this.query.setLength(0);
/* 411 */     if (query != null)
/* 412 */       this.query.append(encode(query, UriComponent.Type.QUERY));
/* 413 */     return this;
/*     */   }
/*     */   
/*     */   public UriBuilder queryParam(String name, Object... values)
/*     */   {
/* 418 */     checkSsp();
/* 419 */     if (name == null)
/* 420 */       throw new IllegalArgumentException("Name parameter is null");
/* 421 */     if (values == null)
/* 422 */       throw new IllegalArgumentException("Value parameter is null");
/* 423 */     if (values.length == 0) {
/* 424 */       return this;
/*     */     }
/* 426 */     name = encode(name, UriComponent.Type.QUERY_PARAM);
/* 427 */     if (this.queryParams == null) {
/* 428 */       for (Object value : values) {
/* 429 */         if (this.query.length() > 0) this.query.append('&');
/* 430 */         this.query.append(name);
/*     */         
/* 432 */         if (value == null) {
/* 433 */           throw new IllegalArgumentException("One or more of query value parameters are null");
/*     */         }
/* 435 */         String stringValue = value.toString();
/* 436 */         if (stringValue.length() > 0)
/* 437 */           this.query.append('=').append(encode(stringValue, UriComponent.Type.QUERY_PARAM));
/*     */       }
/*     */     } else {
/* 440 */       for (Object value : values) {
/* 441 */         if (value == null) {
/* 442 */           throw new IllegalArgumentException("One or more of query value parameters are null");
/*     */         }
/* 444 */         this.queryParams.add(name, encode(value.toString(), UriComponent.Type.QUERY_PARAM));
/*     */       }
/*     */     }
/* 447 */     return this;
/*     */   }
/*     */   
/*     */   public UriBuilder replaceQueryParam(String name, Object... values)
/*     */   {
/* 452 */     checkSsp();
/*     */     
/* 454 */     if (this.queryParams == null) {
/* 455 */       this.queryParams = UriComponent.decodeQuery(this.query.toString(), false);
/* 456 */       this.query.setLength(0);
/*     */     }
/*     */     
/* 459 */     name = encode(name, UriComponent.Type.QUERY_PARAM);
/* 460 */     this.queryParams.remove(name);
/*     */     
/* 462 */     if (values == null) { return this;
/*     */     }
/* 464 */     for (Object value : values) {
/* 465 */       if (value == null) {
/* 466 */         throw new IllegalArgumentException("One or more of query value parameters are null");
/*     */       }
/* 468 */       this.queryParams.add(name, encode(value.toString(), UriComponent.Type.QUERY_PARAM));
/*     */     }
/* 470 */     return this;
/*     */   }
/*     */   
/*     */   public UriBuilder fragment(String fragment)
/*     */   {
/* 475 */     this.fragment = (fragment != null ? encode(fragment, UriComponent.Type.FRAGMENT) : null);
/*     */     
/*     */ 
/* 478 */     return this;
/*     */   }
/*     */   
/*     */   private void checkSsp() {
/* 482 */     if (this.ssp != null)
/* 483 */       throw new IllegalArgumentException("Schema specific part is opaque");
/*     */   }
/*     */   
/*     */   private void appendPath(Path t) {
/* 487 */     if (t == null) {
/* 488 */       throw new IllegalArgumentException("Path is null");
/*     */     }
/* 490 */     appendPath(t.value());
/*     */   }
/*     */   
/*     */   private void appendPath(String path) {
/* 494 */     appendPath(path, false);
/*     */   }
/*     */   
/*     */   private void appendPath(String segments, boolean isSegment) {
/* 498 */     if (segments == null)
/* 499 */       throw new IllegalArgumentException("Path segment is null");
/* 500 */     if (segments.length() == 0) {
/* 501 */       return;
/*     */     }
/*     */     
/* 504 */     encodeMatrix();
/*     */     
/* 506 */     segments = encode(segments, isSegment ? UriComponent.Type.PATH_SEGMENT : UriComponent.Type.PATH);
/*     */     
/*     */ 
/* 509 */     boolean pathEndsInSlash = (this.path.length() > 0) && (this.path.charAt(this.path.length() - 1) == '/');
/* 510 */     boolean segmentStartsWithSlash = segments.charAt(0) == '/';
/*     */     
/* 512 */     if ((this.path.length() > 0) && (!pathEndsInSlash) && (!segmentStartsWithSlash)) {
/* 513 */       this.path.append('/');
/* 514 */     } else if ((pathEndsInSlash) && (segmentStartsWithSlash)) {
/* 515 */       segments = segments.substring(1);
/* 516 */       if (segments.length() == 0) {
/* 517 */         return;
/*     */       }
/*     */     }
/* 520 */     this.path.append(segments);
/*     */   }
/*     */   
/*     */   private void encodeMatrix() {
/* 524 */     if ((this.matrixParams == null) || (this.matrixParams.isEmpty())) {
/* 525 */       return;
/*     */     }
/* 527 */     for (Map.Entry<String, List<String>> e : this.matrixParams.entrySet()) {
/* 528 */       name = (String)e.getKey();
/*     */       
/* 530 */       for (String value : (List)e.getValue()) {
/* 531 */         this.path.append(';').append(name);
/* 532 */         if (value.length() > 0)
/* 533 */           this.path.append('=').append(value);
/*     */       } }
/*     */     String name;
/* 536 */     this.matrixParams = null;
/*     */   }
/*     */   
/*     */   private void encodeQuery() {
/* 540 */     if ((this.queryParams == null) || (this.queryParams.isEmpty())) {
/* 541 */       return;
/*     */     }
/* 543 */     for (Map.Entry<String, List<String>> e : this.queryParams.entrySet()) {
/* 544 */       name = (String)e.getKey();
/*     */       
/* 546 */       for (String value : (List)e.getValue()) {
/* 547 */         if (this.query.length() > 0) this.query.append('&');
/* 548 */         this.query.append(name);
/*     */         
/* 550 */         if (value.length() > 0)
/* 551 */           this.query.append('=').append(value);
/*     */       } }
/*     */     String name;
/* 554 */     this.queryParams = null;
/*     */   }
/*     */   
/*     */   private String encode(String s, UriComponent.Type type) {
/* 558 */     return UriComponent.contextualEncode(s, type, true);
/*     */   }
/*     */   
/*     */   public URI buildFromMap(Map<String, ? extends Object> values) {
/* 562 */     return _buildFromMap(true, values);
/*     */   }
/*     */   
/*     */   public URI buildFromEncodedMap(Map<String, ? extends Object> values) throws IllegalArgumentException, UriBuilderException
/*     */   {
/* 567 */     return _buildFromMap(false, values);
/*     */   }
/*     */   
/*     */   private URI _buildFromMap(boolean encode, Map<String, ? extends Object> values) {
/* 571 */     if (this.ssp != null) {
/* 572 */       throw new IllegalArgumentException("Schema specific part is opaque");
/*     */     }
/* 574 */     encodeMatrix();
/* 575 */     encodeQuery();
/*     */     
/* 577 */     String uri = UriTemplate.createURI(this.scheme, this.authority, this.userInfo, this.host, this.port != -1 ? String.valueOf(this.port) : null, this.path.toString(), this.query.toString(), this.fragment, values, encode);
/*     */     
/*     */ 
/*     */ 
/* 581 */     return createURI(uri);
/*     */   }
/*     */   
/*     */   public URI build(Object... values)
/*     */   {
/* 586 */     return _build(true, values);
/*     */   }
/*     */   
/*     */   public URI buildFromEncoded(Object... values)
/*     */   {
/* 591 */     return _build(false, values);
/*     */   }
/*     */   
/*     */   private URI _build(boolean encode, Object... values) {
/* 595 */     if ((values == null) || (values.length == 0)) {
/* 596 */       return createURI(create());
/*     */     }
/* 598 */     if (this.ssp != null) {
/* 599 */       throw new IllegalArgumentException("Schema specific part is opaque");
/*     */     }
/* 601 */     encodeMatrix();
/* 602 */     encodeQuery();
/*     */     
/* 604 */     String uri = UriTemplate.createURI(this.scheme, this.authority, this.userInfo, this.host, this.port != -1 ? String.valueOf(this.port) : null, this.path.toString(), this.query.toString(), this.fragment, values, encode);
/*     */     
/*     */ 
/*     */ 
/* 608 */     return createURI(uri);
/*     */   }
/*     */   
/*     */   private String create() {
/* 612 */     encodeMatrix();
/* 613 */     encodeQuery();
/*     */     
/* 615 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 617 */     if (this.scheme != null) { sb.append(this.scheme).append(':');
/*     */     }
/* 619 */     if (this.ssp != null) {
/* 620 */       sb.append(this.ssp);
/*     */     } else {
/* 622 */       if ((this.userInfo != null) || (this.host != null) || (this.port != -1)) {
/* 623 */         sb.append("//");
/*     */         
/* 625 */         if ((this.userInfo != null) && (this.userInfo.length() > 0)) {
/* 626 */           sb.append(this.userInfo).append('@');
/*     */         }
/* 628 */         if (this.host != null)
/*     */         {
/* 630 */           sb.append(this.host);
/*     */         }
/*     */         
/* 633 */         if (this.port != -1) sb.append(':').append(this.port);
/* 634 */       } else if (this.authority != null) {
/* 635 */         sb.append("//").append(this.authority);
/*     */       }
/*     */       
/* 638 */       if (this.path.length() > 0) {
/* 639 */         if ((sb.length() > 0) && (this.path.charAt(0) != '/')) sb.append("/");
/* 640 */         sb.append(this.path);
/*     */       }
/*     */       
/* 643 */       if (this.query.length() > 0) { sb.append('?').append(this.query);
/*     */       }
/*     */     }
/* 646 */     if ((this.fragment != null) && (this.fragment.length() > 0)) { sb.append('#').append(this.fragment);
/*     */     }
/* 648 */     return UriComponent.encodeTemplateNames(sb.toString());
/*     */   }
/*     */   
/*     */   private URI createURI(String uri) {
/*     */     try {
/* 653 */       return new URI(uri);
/*     */     } catch (URISyntaxException ex) {
/* 655 */       throw new UriBuilderException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private String replaceNull(String s) {
/* 660 */     return s != null ? s : "";
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\api\uri\UriBuilderImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */