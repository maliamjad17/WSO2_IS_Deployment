/*     */ package com.sun.jersey.core.spi.component;
/*     */ 
/*     */ import com.sun.jersey.core.reflection.AnnotatedMethod;
/*     */ import com.sun.jersey.core.reflection.MethodList;
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*     */ import com.sun.jersey.spi.inject.Errors;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import com.sun.jersey.spi.inject.InjectableProviderContext;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComponentConstructor<T>
/*     */ {
/*     */   private final InjectableProviderContext ipc;
/*     */   private final Class<T> c;
/*     */   private final List<Method> postConstructs;
/*     */   private final ComponentInjector<T> ci;
/*     */   
/*     */   private static class ConstructorInjectablePair<T>
/*     */   {
/*     */     private final Constructor<T> con;
/*     */     private final List<Injectable> is;
/*     */     
/*     */     private ConstructorInjectablePair(Constructor<T> con, List<Injectable> is)
/*     */     {
/*  95 */       this.con = con;
/*  96 */       this.is = is;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ConstructorComparator<T> implements Comparator<ComponentConstructor.ConstructorInjectablePair<T>>
/*     */   {
/*     */     public int compare(ComponentConstructor.ConstructorInjectablePair<T> o1, ComponentConstructor.ConstructorInjectablePair<T> o2) {
/* 103 */       int p = Collections.frequency(ComponentConstructor.ConstructorInjectablePair.access$000(o1), null) - Collections.frequency(ComponentConstructor.ConstructorInjectablePair.access$000(o2), null);
/* 104 */       if (p != 0) {
/* 105 */         return p;
/*     */       }
/* 107 */       return ComponentConstructor.ConstructorInjectablePair.access$100(o2).getParameterTypes().length - ComponentConstructor.ConstructorInjectablePair.access$100(o1).getParameterTypes().length;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ComponentConstructor(InjectableProviderContext ipc, Class<T> c, ComponentInjector<T> ci)
/*     */   {
/* 120 */     this.ipc = ipc;
/* 121 */     this.c = c;
/* 122 */     this.ci = ci;
/* 123 */     this.postConstructs = getPostConstructMethods(c);
/*     */   }
/*     */   
/*     */   private static List<Method> getPostConstructMethods(Class c) {
/* 127 */     Class postConstructClass = ReflectionHelper.classForName("javax.annotation.PostConstruct");
/* 128 */     LinkedList<Method> list = new LinkedList();
/* 129 */     HashSet<String> names = new HashSet();
/* 130 */     if (postConstructClass != null) {
/* 131 */       MethodList methodList = new MethodList(c, true);
/* 132 */       for (AnnotatedMethod m : methodList.hasAnnotation(postConstructClass).hasNumParams(0).hasReturnType(Void.TYPE))
/*     */       {
/*     */ 
/*     */ 
/* 136 */         Method method = m.getMethod();
/*     */         
/* 138 */         if (names.add(method.getName())) {
/* 139 */           ReflectionHelper.setAccessibleMethod(method);
/*     */           
/* 141 */           list.addFirst(method);
/*     */         }
/*     */       }
/*     */     }
/* 145 */     return list;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public T getInstance()
/*     */     throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
/*     */   {
/* 156 */     int modifiers = this.c.getModifiers();
/* 157 */     if (!Modifier.isPublic(modifiers)) {
/* 158 */       Errors.nonPublicClass(this.c);
/*     */     }
/*     */     
/* 161 */     if (Modifier.isAbstract(modifiers)) {
/* 162 */       if (Modifier.isInterface(modifiers)) {
/* 163 */         Errors.interfaceClass(this.c);
/*     */       } else {
/* 165 */         Errors.abstractClass(this.c);
/*     */       }
/*     */     }
/*     */     
/* 169 */     if ((this.c.getEnclosingClass() != null) && (!Modifier.isStatic(modifiers))) {
/* 170 */       Errors.innerClass(this.c);
/*     */     }
/*     */     
/* 173 */     if ((Modifier.isPublic(modifiers)) && (!Modifier.isAbstract(modifiers)) && 
/* 174 */       (this.c.getConstructors().length == 0)) {
/* 175 */       Errors.nonPublicConstructor(this.c);
/*     */     }
/*     */     
/*     */ 
/* 179 */     T t = _getInstance();
/* 180 */     this.ci.inject(t);
/* 181 */     for (Method postConstruct : this.postConstructs) {
/* 182 */       postConstruct.invoke(t, new Object[0]);
/*     */     }
/* 184 */     return t;
/*     */   }
/*     */   
/*     */   private T _getInstance()
/*     */     throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
/*     */   {
/* 190 */     ConstructorInjectablePair<T> cip = getConstructor();
/* 191 */     if ((cip == null) || (cip.is.isEmpty())) {
/* 192 */       return (T)this.c.newInstance();
/*     */     }
/* 194 */     if (cip.is.contains(null))
/*     */     {
/* 196 */       for (int i = 0; i < cip.is.size(); i++) {
/* 197 */         if (cip.is.get(i) == null) {
/* 198 */           Errors.missingDependency(cip.con, i);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 203 */     Object[] params = new Object[cip.is.size()];
/* 204 */     int i = 0;
/* 205 */     for (Injectable injectable : cip.is) {
/* 206 */       if (injectable != null)
/* 207 */         params[(i++)] = injectable.getValue();
/*     */     }
/* 209 */     return (T)cip.con.newInstance(params);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ConstructorInjectablePair<T> getConstructor()
/*     */   {
/* 224 */     if (this.c.getConstructors().length == 0) {
/* 225 */       return null;
/*     */     }
/* 227 */     SortedSet<ConstructorInjectablePair<T>> cs = new TreeSet(new ConstructorComparator(null));
/*     */     
/*     */ 
/* 230 */     AnnotatedContext aoc = new AnnotatedContext();
/* 231 */     for (Constructor con : this.c.getConstructors()) {
/* 232 */       List<Injectable> is = new ArrayList();
/* 233 */       int ps = con.getParameterTypes().length;
/* 234 */       aoc.setAccessibleObject(con);
/* 235 */       for (int p = 0; p < ps; p++) {
/* 236 */         Type pgtype = con.getGenericParameterTypes()[p];
/* 237 */         Annotation[] as = con.getParameterAnnotations()[p];
/* 238 */         aoc.setAnnotations(as);
/* 239 */         Injectable i = null;
/* 240 */         for (Annotation a : as) {
/* 241 */           i = this.ipc.getInjectable(a.annotationType(), aoc, a, pgtype, ComponentScope.UNDEFINED_SINGLETON);
/*     */         }
/*     */         
/*     */ 
/* 245 */         is.add(i);
/*     */       }
/* 247 */       cs.add(new ConstructorInjectablePair(con, is, null));
/*     */     }
/*     */     
/* 250 */     return (ConstructorInjectablePair)cs.first();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\component\ComponentConstructor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */