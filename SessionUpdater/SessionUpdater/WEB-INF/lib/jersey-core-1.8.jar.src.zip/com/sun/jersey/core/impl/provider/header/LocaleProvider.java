/*    */ package com.sun.jersey.core.impl.provider.header;
/*    */ 
/*    */ import com.sun.jersey.core.header.LanguageTag;
/*    */ import com.sun.jersey.spi.HeaderDelegateProvider;
/*    */ import java.text.ParseException;
/*    */ import java.util.Locale;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocaleProvider
/*    */   implements HeaderDelegateProvider<Locale>
/*    */ {
/*    */   public boolean supports(Class<?> type)
/*    */   {
/* 55 */     return Locale.class.isAssignableFrom(type);
/*    */   }
/*    */   
/*    */   public String toString(Locale header) {
/* 59 */     if (header.getCountry().length() == 0) {
/* 60 */       return header.getLanguage();
/*    */     }
/* 62 */     StringBuilder sb = new StringBuilder(header.getLanguage());
/* 63 */     return '-' + header.getCountry();
/*    */   }
/*    */   
/*    */   public Locale fromString(String header)
/*    */   {
/*    */     try {
/* 69 */       LanguageTag lt = new LanguageTag(header);
/* 70 */       return lt.getAsLocale();
/*    */     } catch (ParseException ex) {
/* 72 */       throw new IllegalArgumentException("Error parsing date '" + header + "'", ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\header\LocaleProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */