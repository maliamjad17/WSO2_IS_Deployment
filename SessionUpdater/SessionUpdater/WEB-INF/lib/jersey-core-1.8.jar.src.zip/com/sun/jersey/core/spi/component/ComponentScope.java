/*    */ package com.sun.jersey.core.spi.component;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ComponentScope
/*    */ {
/* 16 */   Singleton, 
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 22 */   PerRequest, 
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 27 */   Undefined;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 33 */   public static final List<ComponentScope> UNDEFINED_SINGLETON = Collections.unmodifiableList(Arrays.asList(new ComponentScope[] { Undefined, Singleton }));
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 40 */   public static final List<ComponentScope> PERREQUEST_UNDEFINED_SINGLETON = Collections.unmodifiableList(Arrays.asList(new ComponentScope[] { PerRequest, Undefined, Singleton }));
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 47 */   public static final List<ComponentScope> PERREQUEST_UNDEFINED = Collections.unmodifiableList(Arrays.asList(new ComponentScope[] { PerRequest, Undefined }));
/*    */   
/*    */   private ComponentScope() {}
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\component\ComponentScope.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */