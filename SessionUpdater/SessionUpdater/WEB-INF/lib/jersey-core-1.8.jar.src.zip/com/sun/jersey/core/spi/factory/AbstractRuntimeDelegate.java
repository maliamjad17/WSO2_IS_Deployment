/*     */ package com.sun.jersey.core.spi.factory;
/*     */ 
/*     */ import com.sun.jersey.api.uri.UriBuilderImpl;
/*     */ import com.sun.jersey.spi.HeaderDelegateProvider;
/*     */ import com.sun.jersey.spi.service.ServiceFinder;
/*     */ import java.net.URI;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ import javax.ws.rs.core.CacheControl;
/*     */ import javax.ws.rs.core.Cookie;
/*     */ import javax.ws.rs.core.EntityTag;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.NewCookie;
/*     */ import javax.ws.rs.core.Response.ResponseBuilder;
/*     */ import javax.ws.rs.core.UriBuilder;
/*     */ import javax.ws.rs.core.Variant.VariantListBuilder;
/*     */ import javax.ws.rs.ext.RuntimeDelegate;
/*     */ import javax.ws.rs.ext.RuntimeDelegate.HeaderDelegate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractRuntimeDelegate
/*     */   extends RuntimeDelegate
/*     */ {
/*  69 */   private final Set<HeaderDelegateProvider> hps = new HashSet();
/*     */   
/*     */ 
/*  72 */   private final Map<Class<?>, RuntimeDelegate.HeaderDelegate> map = new WeakHashMap();
/*     */   
/*     */   public AbstractRuntimeDelegate()
/*     */   {
/*  76 */     for (HeaderDelegateProvider p : ServiceFinder.find(HeaderDelegateProvider.class, true)) {
/*  77 */       this.hps.add(p);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  82 */     this.map.put(EntityTag.class, _createHeaderDelegate(EntityTag.class));
/*  83 */     this.map.put(MediaType.class, _createHeaderDelegate(MediaType.class));
/*  84 */     this.map.put(CacheControl.class, _createHeaderDelegate(CacheControl.class));
/*  85 */     this.map.put(NewCookie.class, _createHeaderDelegate(NewCookie.class));
/*  86 */     this.map.put(Cookie.class, _createHeaderDelegate(Cookie.class));
/*  87 */     this.map.put(URI.class, _createHeaderDelegate(URI.class));
/*  88 */     this.map.put(Date.class, _createHeaderDelegate(Date.class));
/*  89 */     this.map.put(String.class, _createHeaderDelegate(String.class));
/*     */   }
/*     */   
/*     */   public Variant.VariantListBuilder createVariantListBuilder()
/*     */   {
/*  94 */     return new VariantListBuilderImpl();
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder createResponseBuilder()
/*     */   {
/*  99 */     return new ResponseBuilderImpl();
/*     */   }
/*     */   
/*     */   public UriBuilder createUriBuilder()
/*     */   {
/* 104 */     return new UriBuilderImpl();
/*     */   }
/*     */   
/*     */   public <T> RuntimeDelegate.HeaderDelegate<T> createHeaderDelegate(Class<T> type)
/*     */   {
/* 109 */     if (type == null) {
/* 110 */       throw new IllegalArgumentException("type parameter cannot be null");
/*     */     }
/* 112 */     RuntimeDelegate.HeaderDelegate h = (RuntimeDelegate.HeaderDelegate)this.map.get(type);
/* 113 */     if (h != null) { return h;
/*     */     }
/* 115 */     return _createHeaderDelegate(type);
/*     */   }
/*     */   
/*     */   private <T> RuntimeDelegate.HeaderDelegate<T> _createHeaderDelegate(Class<T> type) {
/* 119 */     for (HeaderDelegateProvider hp : this.hps) {
/* 120 */       if (hp.supports(type))
/* 121 */         return hp;
/*     */     }
/* 123 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\factory\AbstractRuntimeDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */