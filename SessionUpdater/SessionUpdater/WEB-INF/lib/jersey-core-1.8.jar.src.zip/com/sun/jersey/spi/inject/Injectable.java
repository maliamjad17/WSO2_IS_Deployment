package com.sun.jersey.spi.inject;

public abstract interface Injectable<T>
{
  public abstract T getValue();
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\spi\inject\Injectable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */