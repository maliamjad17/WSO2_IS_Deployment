/*    */ package com.sun.jersey.core.impl.provider.header;
/*    */ 
/*    */ import com.sun.jersey.core.header.LinkHeader;
/*    */ import com.sun.jersey.spi.HeaderDelegateProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LinkHeaderProvider
/*    */   implements HeaderDelegateProvider<LinkHeader>
/*    */ {
/*    */   public boolean supports(Class<?> type)
/*    */   {
/* 54 */     return LinkHeader.class.isAssignableFrom(type);
/*    */   }
/*    */   
/*    */   public LinkHeader fromString(String value) throws IllegalArgumentException {
/* 58 */     return LinkHeader.valueOf(value);
/*    */   }
/*    */   
/*    */   public String toString(LinkHeader value) {
/* 62 */     return value.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\header\LinkHeaderProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */