/*    */ package com.sun.jersey.spi.inject;
/*    */ 
/*    */ import com.sun.jersey.core.spi.component.ComponentContext;
/*    */ import com.sun.jersey.core.spi.component.ComponentScope;
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SingletonTypeInjectableProvider<A extends Annotation, T>
/*    */   implements InjectableProvider<A, Type>, Injectable<T>
/*    */ {
/*    */   private final Type t;
/*    */   private final T instance;
/*    */   
/*    */   public SingletonTypeInjectableProvider(Type t, T instance)
/*    */   {
/* 70 */     this.t = t;
/* 71 */     this.instance = instance;
/*    */   }
/*    */   
/*    */   public final ComponentScope getScope() {
/* 75 */     return ComponentScope.Singleton;
/*    */   }
/*    */   
/*    */   public final Injectable<T> getInjectable(ComponentContext ic, A a, Type c) {
/* 79 */     if (c.equals(this.t)) {
/* 80 */       return this;
/*    */     }
/* 82 */     return null;
/*    */   }
/*    */   
/*    */   public final T getValue() {
/* 86 */     return (T)this.instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\spi\inject\SingletonTypeInjectableProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */