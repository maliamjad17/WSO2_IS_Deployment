/*     */ package com.sun.jersey.core.spi.component.ioc;
/*     */ 
/*     */ import com.sun.jersey.core.spi.component.ComponentDestructor;
/*     */ import com.sun.jersey.core.spi.component.ComponentInjector;
/*     */ import com.sun.jersey.core.spi.component.ComponentProvider;
/*     */ import com.sun.jersey.core.spi.component.ComponentScope;
/*     */ import com.sun.jersey.core.spi.component.ProviderFactory;
/*     */ import com.sun.jersey.core.spi.component.ProviderFactory.Destroyable;
/*     */ import com.sun.jersey.spi.inject.InjectableProviderContext;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IoCProviderFactory
/*     */   extends ProviderFactory
/*     */ {
/*     */   private final List<IoCComponentProviderFactory> factories;
/*     */   
/*     */   public IoCProviderFactory(InjectableProviderContext ipc, IoCComponentProviderFactory icpf)
/*     */   {
/*  70 */     this(ipc, Collections.singletonList(icpf));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IoCProviderFactory(InjectableProviderContext ipc, List<IoCComponentProviderFactory> factories)
/*     */   {
/*  81 */     super(ipc);
/*  82 */     this.factories = factories;
/*     */   }
/*     */   
/*     */   public ComponentProvider _getComponentProvider(Class c)
/*     */   {
/*  87 */     IoCComponentProvider icp = null;
/*  88 */     for (IoCComponentProviderFactory f : this.factories) {
/*  89 */       icp = f.getComponentProvider(c);
/*  90 */       if (icp != null)
/*     */         break;
/*     */     }
/*  93 */     return icp == null ? super._getComponentProvider(c) : wrap(c, icp);
/*     */   }
/*     */   
/*     */   private ComponentProvider wrap(Class c, IoCComponentProvider icp) {
/*  97 */     if ((icp instanceof IoCManagedComponentProvider)) {
/*  98 */       IoCManagedComponentProvider imcp = (IoCManagedComponentProvider)icp;
/*  99 */       if (imcp.getScope() == ComponentScope.Singleton) {
/* 100 */         return new ManagedSingleton(getInjectableProviderContext(), imcp, c);
/*     */       }
/* 102 */       throw new RuntimeException("The scope of the component " + c + " must be a singleton");
/*     */     }
/* 104 */     if ((icp instanceof IoCFullyManagedComponentProvider)) {
/* 105 */       IoCFullyManagedComponentProvider ifmcp = (IoCFullyManagedComponentProvider)icp;
/* 106 */       return new FullyManagedSingleton(ifmcp.getInstance()); }
/* 107 */     if ((icp instanceof IoCInstantiatedComponentProvider)) {
/* 108 */       IoCInstantiatedComponentProvider iicp = (IoCInstantiatedComponentProvider)icp;
/* 109 */       return new InstantiatedSingleton(getInjectableProviderContext(), iicp, c); }
/* 110 */     if ((icp instanceof IoCProxiedComponentProvider)) {
/* 111 */       IoCProxiedComponentProvider ipcp = (IoCProxiedComponentProvider)icp;
/* 112 */       ComponentProvider cp = super._getComponentProvider(c);
/*     */       
/* 114 */       if (cp == null) {
/* 115 */         return null;
/*     */       }
/* 117 */       return new ProxiedSingletonWrapper(ipcp, cp, c);
/*     */     }
/* 119 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */   private static class InstantiatedSingleton
/*     */     implements ComponentProvider, ProviderFactory.Destroyable
/*     */   {
/*     */     private final Object o;
/*     */     private final IoCDestroyable destroyable;
/*     */     private final ComponentDestructor cd;
/*     */     
/*     */     InstantiatedSingleton(InjectableProviderContext ipc, IoCInstantiatedComponentProvider iicp, Class c)
/*     */     {
/* 132 */       this.destroyable = ((iicp instanceof IoCDestroyable) ? (IoCDestroyable)iicp : null);
/*     */       
/*     */ 
/* 135 */       this.o = iicp.getInstance();
/*     */       
/* 137 */       this.cd = (this.destroyable == null ? new ComponentDestructor(c) : null);
/*     */       
/* 139 */       if (this.destroyable == null) {
/* 140 */         ComponentInjector ci = new ComponentInjector(ipc, c);
/*     */         
/*     */ 
/* 143 */         ci.inject(iicp.getInjectableInstance(this.o));
/*     */       }
/*     */     }
/*     */     
/*     */     public Object getInstance()
/*     */     {
/* 149 */       return this.o;
/*     */     }
/*     */     
/*     */     public void destroy()
/*     */     {
/* 154 */       if (this.destroyable != null) {
/* 155 */         this.destroyable.destroy(this.o);
/*     */       } else {
/*     */         try {
/* 158 */           this.cd.destroy(this.o);
/*     */         } catch (IllegalAccessException ex) {
/* 160 */           IoCProviderFactory.LOGGER.log(Level.SEVERE, "Unable to destroy resource", ex);
/*     */         } catch (IllegalArgumentException ex) {
/* 162 */           IoCProviderFactory.LOGGER.log(Level.SEVERE, "Unable to destroy resource", ex);
/*     */         } catch (InvocationTargetException ex) {
/* 164 */           IoCProviderFactory.LOGGER.log(Level.SEVERE, "Unable to destroy resource", ex);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ManagedSingleton implements ComponentProvider
/*     */   {
/*     */     private final Object o;
/*     */     
/*     */     ManagedSingleton(InjectableProviderContext ipc, IoCInstantiatedComponentProvider iicp, Class c)
/*     */     {
/* 176 */       ComponentInjector rci = new ComponentInjector(ipc, c);
/*     */       
/*     */ 
/* 179 */       this.o = iicp.getInstance();
/* 180 */       rci.inject(iicp.getInjectableInstance(this.o));
/*     */     }
/*     */     
/*     */     public Object getInstance()
/*     */     {
/* 185 */       return this.o;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class FullyManagedSingleton implements ComponentProvider {
/*     */     private final Object o;
/*     */     
/*     */     FullyManagedSingleton(Object o) {
/* 193 */       this.o = o;
/*     */     }
/*     */     
/*     */     public Object getInstance()
/*     */     {
/* 198 */       return this.o;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class ProxiedSingletonWrapper
/*     */     implements ComponentProvider, ProviderFactory.Destroyable
/*     */   {
/*     */     private final ProviderFactory.Destroyable destroyable;
/*     */     private final Object proxy;
/*     */     
/*     */     ProxiedSingletonWrapper(IoCProxiedComponentProvider ipcp, ComponentProvider cp, Class c)
/*     */     {
/* 211 */       this.destroyable = ((cp instanceof ProviderFactory.Destroyable) ? (ProviderFactory.Destroyable)cp : null);
/*     */       
/*     */ 
/* 214 */       Object o = cp.getInstance();
/* 215 */       this.proxy = ipcp.proxy(o);
/* 216 */       if (!this.proxy.getClass().isAssignableFrom(o.getClass())) {
/* 217 */         throw new IllegalStateException("Proxied object class " + this.proxy.getClass() + " is not assignable from object class " + o.getClass());
/*     */       }
/*     */     }
/*     */     
/*     */     public Object getInstance()
/*     */     {
/* 223 */       return this.proxy;
/*     */     }
/*     */     
/*     */     public void destroy()
/*     */     {
/* 228 */       if (this.destroyable != null) {
/* 229 */         this.destroyable.destroy();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\component\ioc\IoCProviderFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */