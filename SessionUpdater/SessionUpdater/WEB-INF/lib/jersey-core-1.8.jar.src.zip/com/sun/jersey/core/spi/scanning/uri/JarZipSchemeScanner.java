/*     */ package com.sun.jersey.core.spi.scanning.uri;
/*     */ 
/*     */ import com.sun.jersey.api.uri.UriComponent;
/*     */ import com.sun.jersey.api.uri.UriComponent.Type;
/*     */ import com.sun.jersey.core.spi.scanning.JarFileScanner;
/*     */ import com.sun.jersey.core.spi.scanning.ScannerException;
/*     */ import com.sun.jersey.core.spi.scanning.ScannerListener;
/*     */ import com.sun.jersey.core.util.Closing;
/*     */ import com.sun.jersey.core.util.Closing.Closure;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JarZipSchemeScanner
/*     */   implements UriSchemeScanner
/*     */ {
/*     */   public Set<String> getSchemes()
/*     */   {
/*  67 */     return new HashSet(Arrays.asList(new String[] { "jar", "zip" }));
/*     */   }
/*     */   
/*     */   public void scan(URI u, final ScannerListener cfl) {
/*  71 */     String ssp = u.getRawSchemeSpecificPart();
/*  72 */     String jarUrlString = ssp.substring(0, ssp.lastIndexOf('!'));
/*  73 */     final String parent = ssp.substring(ssp.lastIndexOf('!') + 2);
/*     */     try {
/*  75 */       closing(jarUrlString).f(new Closing.Closure()
/*     */       {
/*     */         public void f(InputStream in) throws IOException {
/*  78 */           JarFileScanner.scan(in, parent, cfl);
/*     */         }
/*     */       });
/*     */     } catch (IOException ex) {
/*  82 */       throw new ScannerException("IO error when scanning jar " + u, ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Closing closing(String jarUrlString)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 123 */       return new Closing(new URL(jarUrlString).openStream());
/*     */     } catch (MalformedURLException ex) {}
/* 125 */     return new Closing(new FileInputStream(UriComponent.decode(jarUrlString, UriComponent.Type.PATH)));
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\scanning\uri\JarZipSchemeScanner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */