/*     */ package com.sun.jersey.core.util;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringKeyStringValueIgnoreCaseMultivaluedMap
/*     */   extends StringKeyIgnoreCaseMultivaluedMap<String>
/*     */ {
/*     */   public StringKeyStringValueIgnoreCaseMultivaluedMap() {}
/*     */   
/*     */   public StringKeyStringValueIgnoreCaseMultivaluedMap(StringKeyStringValueIgnoreCaseMultivaluedMap that)
/*     */   {
/*  62 */     super(that);
/*     */   }
/*     */   
/*     */   public void putSingleObject(String key, Object value) {
/*  66 */     List<String> l = getList(key);
/*     */     
/*  68 */     l.clear();
/*  69 */     if (value != null) {
/*  70 */       l.add(value.toString());
/*     */     } else
/*  72 */       l.add("");
/*     */   }
/*     */   
/*     */   public void addObject(String key, Object value) {
/*  76 */     List<String> l = getList(key);
/*     */     
/*  78 */     if (value != null) {
/*  79 */       l.add(value.toString());
/*     */     } else
/*  81 */       l.add("");
/*     */   }
/*     */   
/*     */   public <A> List<A> get(String key, Class<A> type) {
/*  85 */     Constructor<A> c = null;
/*     */     try {
/*  87 */       c = type.getConstructor(new Class[] { String.class });
/*     */     } catch (Exception ex) {
/*  89 */       throw new IllegalArgumentException(type.getName() + " has no String constructor", ex);
/*     */     }
/*     */     
/*  92 */     ArrayList<A> l = null;
/*  93 */     List<String> values = (List)get(key);
/*  94 */     if (values != null) {
/*  95 */       l = new ArrayList();
/*  96 */       for (String value : values) {
/*     */         try {
/*  98 */           l.add(c.newInstance(new Object[] { value }));
/*     */         } catch (Exception ex) {
/* 100 */           l.add(null);
/*     */         }
/*     */       }
/*     */     }
/* 104 */     return l;
/*     */   }
/*     */   
/*     */   public <A> A getFirst(String key, Class<A> type) {
/* 108 */     String value = (String)getFirst(key);
/* 109 */     if (value == null)
/* 110 */       return null;
/* 111 */     Constructor<A> c = null;
/*     */     try {
/* 113 */       c = type.getConstructor(new Class[] { String.class });
/*     */     } catch (Exception ex) {
/* 115 */       throw new IllegalArgumentException(type.getName() + " has no String constructor", ex);
/*     */     }
/* 117 */     A retVal = null;
/*     */     try {
/* 119 */       retVal = c.newInstance(new Object[] { value });
/*     */     }
/*     */     catch (Exception ex) {}
/* 122 */     return retVal;
/*     */   }
/*     */   
/*     */   public <A> A getFirst(String key, A defaultValue)
/*     */   {
/* 127 */     String value = (String)getFirst(key);
/* 128 */     if (value == null) {
/* 129 */       return defaultValue;
/*     */     }
/* 131 */     Class<A> type = defaultValue.getClass();
/*     */     
/* 133 */     Constructor<A> c = null;
/*     */     try {
/* 135 */       c = type.getConstructor(new Class[] { String.class });
/*     */     } catch (Exception ex) {
/* 137 */       throw new IllegalArgumentException(type.getName() + " has no String constructor", ex);
/*     */     }
/* 139 */     A retVal = defaultValue;
/*     */     try {
/* 141 */       retVal = c.newInstance(new Object[] { value });
/*     */     }
/*     */     catch (Exception ex) {}
/* 144 */     return retVal;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\util\StringKeyStringValueIgnoreCaseMultivaluedMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */