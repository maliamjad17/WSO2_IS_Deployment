/*     */ package com.sun.jersey.core.impl.provider.entity;
/*     */ 
/*     */ import com.sun.jersey.core.provider.jaxb.AbstractJAXBElementProvider;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import javax.ws.rs.Consumes;
/*     */ import javax.ws.rs.Produces;
/*     */ import javax.ws.rs.core.Context;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.ext.Providers;
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.Marshaller;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLJAXBElementProvider
/*     */   extends AbstractJAXBElementProvider
/*     */ {
/*     */   private final Injectable<SAXParserFactory> spf;
/*     */   
/*     */   public XMLJAXBElementProvider(Injectable<SAXParserFactory> spf, Providers ps)
/*     */   {
/*  69 */     super(ps);
/*     */     
/*  71 */     this.spf = spf;
/*     */   }
/*     */   
/*     */   public XMLJAXBElementProvider(Injectable<SAXParserFactory> spf, Providers ps, MediaType mt) {
/*  75 */     super(ps, mt);
/*     */     
/*  77 */     this.spf = spf;
/*     */   }
/*     */   
/*     */   @Produces({"application/xml"})
/*     */   @Consumes({"application/xml"})
/*     */   public static final class App extends XMLJAXBElementProvider {
/*     */     public App(@Context Injectable<SAXParserFactory> spf, @Context Providers ps) {
/*  84 */       super(ps, MediaType.APPLICATION_XML_TYPE);
/*     */     }
/*     */   }
/*     */   
/*     */   @Produces({"text/xml"})
/*     */   @Consumes({"text/xml"})
/*     */   public static final class Text extends XMLJAXBElementProvider {
/*     */     public Text(@Context Injectable<SAXParserFactory> spf, @Context Providers ps) {
/*  92 */       super(ps, MediaType.TEXT_XML_TYPE);
/*     */     }
/*     */   }
/*     */   
/*     */   @Produces({"*/*"})
/*     */   @Consumes({"*/*"})
/*     */   public static final class General extends XMLJAXBElementProvider {
/*     */     public General(@Context Injectable<SAXParserFactory> spf, @Context Providers ps) {
/* 100 */       super(ps);
/*     */     }
/*     */     
/*     */     protected boolean isSupported(MediaType m)
/*     */     {
/* 105 */       return m.getSubtype().endsWith("+xml");
/*     */     }
/*     */   }
/*     */   
/*     */   protected final JAXBElement<?> readFrom(Class<?> type, MediaType mediaType, Unmarshaller u, InputStream entityStream)
/*     */     throws JAXBException
/*     */   {
/* 112 */     return u.unmarshal(getSAXSource((SAXParserFactory)this.spf.getValue(), entityStream), type);
/*     */   }
/*     */   
/*     */   protected final void writeTo(JAXBElement<?> t, MediaType mediaType, Charset c, Marshaller m, OutputStream entityStream)
/*     */     throws JAXBException
/*     */   {
/* 118 */     m.marshal(t, entityStream);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\entity\XMLJAXBElementProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */