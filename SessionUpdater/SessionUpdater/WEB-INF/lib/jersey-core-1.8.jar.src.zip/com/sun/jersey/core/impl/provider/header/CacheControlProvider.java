/*     */ package com.sun.jersey.core.impl.provider.header;
/*     */ 
/*     */ import com.sun.jersey.core.header.reader.HttpHeaderReader;
/*     */ import com.sun.jersey.spi.HeaderDelegateProvider;
/*     */ import java.text.ParseException;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.ws.rs.core.CacheControl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CacheControlProvider
/*     */   implements HeaderDelegateProvider<CacheControl>
/*     */ {
/*  59 */   private static final Pattern WHITESPACE = Pattern.compile("\\s");
/*     */   
/*  61 */   private static final Pattern COMMA_SEPARATED_LIST = Pattern.compile("[\\s]*,[\\s]*");
/*     */   
/*     */   public boolean supports(Class<?> type) {
/*  64 */     return type == CacheControl.class;
/*     */   }
/*     */   
/*     */   public String toString(CacheControl header) {
/*  68 */     StringBuffer b = new StringBuffer();
/*  69 */     if (header.isPrivate())
/*  70 */       appendQuotedWithSeparator(b, "private", buildListValue(header.getPrivateFields()));
/*  71 */     if (header.isNoCache())
/*  72 */       appendQuotedWithSeparator(b, "no-cache", buildListValue(header.getNoCacheFields()));
/*  73 */     if (header.isNoStore())
/*  74 */       appendWithSeparator(b, "no-store");
/*  75 */     if (header.isNoTransform())
/*  76 */       appendWithSeparator(b, "no-transform");
/*  77 */     if (header.isMustRevalidate())
/*  78 */       appendWithSeparator(b, "must-revalidate");
/*  79 */     if (header.isProxyRevalidate())
/*  80 */       appendWithSeparator(b, "proxy-revalidate");
/*  81 */     if (header.getMaxAge() != -1)
/*  82 */       appendWithSeparator(b, "max-age", header.getMaxAge());
/*  83 */     if (header.getSMaxAge() != -1) {
/*  84 */       appendWithSeparator(b, "s-maxage", header.getSMaxAge());
/*     */     }
/*  86 */     for (Map.Entry<String, String> e : header.getCacheExtension().entrySet()) {
/*  87 */       appendWithSeparator(b, (String)e.getKey(), quoteIfWhitespace((String)e.getValue()));
/*     */     }
/*     */     
/*  90 */     return b.toString();
/*     */   }
/*     */   
/*     */   private void readFieldNames(List<String> fieldNames, HttpHeaderReader reader, String directiveName) throws ParseException
/*     */   {
/*  95 */     if (!reader.hasNextSeparator('=', false))
/*  96 */       return;
/*  97 */     reader.nextSeparator('=');
/*  98 */     fieldNames.addAll(Arrays.asList(COMMA_SEPARATED_LIST.split(reader.nextQuotedString())));
/*     */   }
/*     */   
/*     */   private int readIntValue(HttpHeaderReader reader, String directiveName)
/*     */     throws ParseException
/*     */   {
/* 104 */     reader.nextSeparator('=');
/* 105 */     int index = reader.getIndex();
/*     */     try {
/* 107 */       return Integer.parseInt(reader.nextToken());
/*     */     } catch (NumberFormatException nfe) {
/* 109 */       ParseException pe = new ParseException("Error parsing integer value for " + directiveName + " directive", index);
/*     */       
/* 111 */       pe.initCause(nfe);
/* 112 */       throw pe;
/*     */     }
/*     */   }
/*     */   
/*     */   private void readDirective(CacheControl cacheControl, HttpHeaderReader reader) throws ParseException
/*     */   {
/* 118 */     String directiveName = reader.nextToken();
/* 119 */     if (directiveName.equalsIgnoreCase("private")) {
/* 120 */       cacheControl.setPrivate(true);
/* 121 */       readFieldNames(cacheControl.getPrivateFields(), reader, directiveName);
/* 122 */     } else if (directiveName.equalsIgnoreCase("public"))
/*     */     {
/* 124 */       cacheControl.getCacheExtension().put(directiveName, null);
/* 125 */     } else if (directiveName.equalsIgnoreCase("no-cache")) {
/* 126 */       cacheControl.setNoCache(true);
/* 127 */       readFieldNames(cacheControl.getNoCacheFields(), reader, directiveName);
/* 128 */     } else if (directiveName.equalsIgnoreCase("no-store")) {
/* 129 */       cacheControl.setNoStore(true);
/* 130 */     } else if (directiveName.equalsIgnoreCase("no-transform")) {
/* 131 */       cacheControl.setNoTransform(true);
/* 132 */     } else if (directiveName.equalsIgnoreCase("must-revalidate")) {
/* 133 */       cacheControl.setMustRevalidate(true);
/* 134 */     } else if (directiveName.equalsIgnoreCase("proxy-revalidate")) {
/* 135 */       cacheControl.setProxyRevalidate(true);
/* 136 */     } else if (directiveName.equalsIgnoreCase("max-age")) {
/* 137 */       cacheControl.setMaxAge(readIntValue(reader, directiveName));
/* 138 */     } else if (directiveName.equalsIgnoreCase("s-maxage")) {
/* 139 */       cacheControl.setSMaxAge(readIntValue(reader, directiveName));
/*     */     } else {
/* 141 */       String value = null;
/* 142 */       if (reader.hasNextSeparator('=', false)) {
/* 143 */         reader.nextSeparator('=');
/* 144 */         value = reader.nextTokenOrQuotedString();
/*     */       }
/* 146 */       cacheControl.getCacheExtension().put(directiveName, value);
/*     */     }
/*     */   }
/*     */   
/*     */   public CacheControl fromString(String header)
/*     */   {
/* 152 */     if (header == null)
/* 153 */       throw new IllegalArgumentException("Cache control is null");
/*     */     try {
/* 155 */       HttpHeaderReader reader = HttpHeaderReader.newInstance(header);
/* 156 */       CacheControl cacheControl = new CacheControl();
/* 157 */       cacheControl.setNoTransform(false);
/* 158 */       while (reader.hasNext()) {
/* 159 */         readDirective(cacheControl, reader);
/* 160 */         if (reader.hasNextSeparator(',', true))
/* 161 */           reader.nextSeparator(',');
/*     */       }
/* 163 */       return cacheControl;
/*     */     } catch (ParseException pe) {
/* 165 */       throw new IllegalArgumentException("Error parsing cache control '" + header + "'", pe);
/*     */     }
/*     */   }
/*     */   
/*     */   private void appendWithSeparator(StringBuffer b, String field)
/*     */   {
/* 171 */     if (b.length() > 0)
/* 172 */       b.append(", ");
/* 173 */     b.append(field);
/*     */   }
/*     */   
/*     */   private void appendQuotedWithSeparator(StringBuffer b, String field, String value) {
/* 177 */     appendWithSeparator(b, field);
/* 178 */     if ((value != null) && (value.length() > 0)) {
/* 179 */       b.append("=\"");
/* 180 */       b.append(value);
/* 181 */       b.append("\"");
/*     */     }
/*     */   }
/*     */   
/*     */   private void appendWithSeparator(StringBuffer b, String field, String value) {
/* 186 */     appendWithSeparator(b, field);
/* 187 */     if ((value != null) && (value.length() > 0)) {
/* 188 */       b.append("=");
/* 189 */       b.append(value);
/*     */     }
/*     */   }
/*     */   
/*     */   private void appendWithSeparator(StringBuffer b, String field, int value) {
/* 194 */     appendWithSeparator(b, field);
/* 195 */     b.append("=");
/* 196 */     b.append(value);
/*     */   }
/*     */   
/*     */   private String buildListValue(List<String> values) {
/* 200 */     StringBuffer b = new StringBuffer();
/* 201 */     for (String value : values)
/* 202 */       appendWithSeparator(b, value);
/* 203 */     return b.toString();
/*     */   }
/*     */   
/*     */   private String quoteIfWhitespace(String value) {
/* 207 */     if (value == null)
/* 208 */       return null;
/* 209 */     Matcher m = WHITESPACE.matcher(value);
/* 210 */     if (m.find()) {
/* 211 */       return "\"" + value + "\"";
/*     */     }
/* 213 */     return value;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\header\CacheControlProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */