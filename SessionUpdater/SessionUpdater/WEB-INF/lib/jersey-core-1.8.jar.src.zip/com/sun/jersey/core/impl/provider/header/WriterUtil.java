/*    */ package com.sun.jersey.core.impl.provider.header;
/*    */ 
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WriterUtil
/*    */ {
/* 52 */   private static Pattern whitespace = Pattern.compile("\\s");
/*    */   
/* 54 */   private static Pattern whitespaceOrQuote = Pattern.compile("[\\s\"]");
/*    */   
/*    */   public static void appendQuotedIfWhiteSpaceOrQuote(StringBuilder b, String value) {
/* 57 */     if (value == null)
/* 58 */       return;
/* 59 */     Matcher m = whitespaceOrQuote.matcher(value);
/* 60 */     boolean quote = m.find();
/* 61 */     if (quote)
/* 62 */       b.append('"');
/* 63 */     appendEscapingQuotes(b, value);
/* 64 */     if (quote)
/* 65 */       b.append('"');
/*    */   }
/*    */   
/*    */   public static void appendQuotedIfWhitespace(StringBuilder b, String value) {
/* 69 */     if (value == null)
/* 70 */       return;
/* 71 */     Matcher m = whitespace.matcher(value);
/* 72 */     boolean quote = m.find();
/* 73 */     if (quote)
/* 74 */       b.append('"');
/* 75 */     appendEscapingQuotes(b, value);
/* 76 */     if (quote)
/* 77 */       b.append('"');
/*    */   }
/*    */   
/*    */   public static void appendQuoted(StringBuilder b, String value) {
/* 81 */     b.append('"');
/* 82 */     appendEscapingQuotes(b, value);
/* 83 */     b.append('"');
/*    */   }
/*    */   
/*    */   public static void appendEscapingQuotes(StringBuilder b, String value) {
/* 87 */     for (int i = 0; i < value.length(); i++) {
/* 88 */       char c = value.charAt(i);
/* 89 */       if (c == '"')
/* 90 */         b.append('\\');
/* 91 */       b.append(c);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\header\WriterUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */