/*     */ package com.sun.jersey.spi.inject;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Errors
/*     */ {
/*     */   private final ArrayList<ErrorMessage> messages;
/*     */   private int mark;
/*     */   private int stack;
/*     */   private boolean fieldReporting;
/*     */   
/*     */   public static class ErrorMessagesException
/*     */     extends RuntimeException
/*     */   {
/*     */     public final List<Errors.ErrorMessage> messages;
/*     */     
/*     */     private ErrorMessagesException(List<Errors.ErrorMessage> messages)
/*     */     {
/*  60 */       this.messages = messages;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ErrorMessage
/*     */   {
/*     */     final String message;
/*     */     final boolean isFatal;
/*     */     
/*     */     private ErrorMessage(String message, boolean isFatal)
/*     */     {
/*  71 */       this.message = message;
/*  72 */       this.isFatal = isFatal;
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/*  77 */       int hash = 3;
/*  78 */       hash = 37 * hash + (this.message != null ? this.message.hashCode() : 0);
/*  79 */       hash = 37 * hash + (this.isFatal ? 1 : 0);
/*  80 */       return hash;
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj)
/*     */     {
/*  85 */       if (obj == null) {
/*  86 */         return false;
/*     */       }
/*  88 */       if (getClass() != obj.getClass()) {
/*  89 */         return false;
/*     */       }
/*  91 */       ErrorMessage other = (ErrorMessage)obj;
/*  92 */       if (this.message == null ? other.message != null : !this.message.equals(other.message)) {
/*  93 */         return false;
/*     */       }
/*  95 */       if (this.isFatal != other.isFatal) {
/*  96 */         return false;
/*     */       }
/*  98 */       return true;
/*     */     }
/*     */   }
/*     */   
/* 102 */   public Errors() { this.messages = new ArrayList(0);
/*     */     
/* 104 */     this.mark = -1;
/*     */     
/* 106 */     this.stack = 0;
/*     */     
/* 108 */     this.fieldReporting = true;
/*     */   }
/*     */   
/* 111 */   private void _mark() { this.mark = this.messages.size(); }
/*     */   
/*     */   private void _unmark()
/*     */   {
/* 115 */     this.mark = -1;
/*     */   }
/*     */   
/*     */   private void _reset() {
/* 119 */     if ((this.mark >= 0) && (this.mark < this.messages.size())) {
/* 120 */       this.messages.subList(this.mark, this.messages.size()).clear();
/* 121 */       _unmark();
/*     */     }
/*     */   }
/*     */   
/*     */   private void preProcess() {
/* 126 */     this.stack += 1;
/*     */   }
/*     */   
/*     */   private void postProcess(boolean throwException) {
/* 130 */     this.stack -= 1;
/* 131 */     this.fieldReporting = true;
/*     */     
/* 133 */     if (this.stack == 0) {
/*     */       try {
/* 135 */         if (!this.messages.isEmpty()) {
/* 136 */           processErrorMessages(throwException, this.messages);
/*     */         }
/*     */       } finally {
/* 139 */         errors.remove();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 144 */   private static final Logger LOGGER = Logger.getLogger(Errors.class.getName());
/*     */   
/*     */   private static void processErrorMessages(boolean throwException, List<ErrorMessage> messages) {
/* 147 */     StringBuilder sb = new StringBuilder();
/* 148 */     boolean isFatal = false;
/* 149 */     for (ErrorMessage em : messages) {
/* 150 */       if (sb.length() > 0) {
/* 151 */         sb.append("\n");
/*     */       }
/*     */       
/* 154 */       sb.append("  ");
/*     */       
/* 156 */       if (em.isFatal) {
/* 157 */         sb.append("SEVERE: ");
/*     */       } else {
/* 159 */         sb.append("WARNING: ");
/*     */       }
/* 161 */       isFatal |= em.isFatal;
/*     */       
/* 163 */       sb.append(em.message);
/*     */     }
/*     */     
/* 166 */     String message = sb.toString();
/* 167 */     if (isFatal) {
/* 168 */       LOGGER.severe("The following errors and warnings have been detected with resource and/or provider classes:\n" + message);
/* 169 */       if (throwException) {
/* 170 */         throw new ErrorMessagesException(new ArrayList(messages), null);
/*     */       }
/*     */     } else {
/* 173 */       LOGGER.warning("The following warnings have been detected with resource and/or provider classes:\n" + message);
/*     */     }
/*     */   }
/*     */   
/* 177 */   private static ThreadLocal<Errors> errors = new ThreadLocal();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <T> T processWithErrors(Closure<T> c)
/*     */   {
/* 184 */     Errors e = (Errors)errors.get();
/* 185 */     if (e == null) {
/* 186 */       e = new Errors();
/* 187 */       errors.set(e);
/*     */     }
/* 189 */     e.preProcess();
/*     */     
/* 191 */     RuntimeException caught = null;
/*     */     try {
/* 193 */       return (T)c.f();
/*     */     }
/*     */     catch (RuntimeException re)
/*     */     {
/* 197 */       caught = re;
/*     */     } finally {
/* 199 */       e.postProcess(caught == null);
/*     */     }
/*     */     
/* 202 */     throw caught;
/*     */   }
/*     */   
/*     */   private static Errors getInstance() {
/* 206 */     Errors e = (Errors)errors.get();
/*     */     
/* 208 */     if (e == null) {
/* 209 */       throw new IllegalStateException("There is no error processing in scope");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 214 */     if (e.stack == 0) {
/* 215 */       errors.remove();
/* 216 */       throw new IllegalStateException("There is no error processing in scope");
/*     */     }
/* 218 */     return e;
/*     */   }
/*     */   
/*     */   public static void mark() {
/* 222 */     getInstance()._mark();
/*     */   }
/*     */   
/*     */   public static void unmark() {
/* 226 */     getInstance()._unmark();
/*     */   }
/*     */   
/*     */   public static void reset() {
/* 230 */     getInstance()._reset();
/*     */   }
/*     */   
/*     */   public static void error(String message) {
/* 234 */     error(message, true);
/*     */   }
/*     */   
/*     */   public static void error(String message, boolean isFatal) {
/* 238 */     ErrorMessage em = new ErrorMessage(message, isFatal, null);
/* 239 */     getInstance().messages.add(em);
/*     */   }
/*     */   
/*     */   public int numberOfErrors() {
/* 243 */     return getInstance().messages.size();
/*     */   }
/*     */   
/*     */   public static void innerClass(Class c) {
/* 247 */     error("The inner class " + c.getName() + " is not a static inner class and cannot be instantiated.");
/*     */   }
/*     */   
/*     */   public static void nonPublicClass(Class c) {
/* 251 */     error("The class " + c.getName() + " is a not a public class and cannot be instantiated.");
/*     */   }
/*     */   
/*     */   public static void nonPublicConstructor(Class c) {
/* 255 */     error("The class " + c.getName() + " does not have a public constructor and cannot be instantiated.");
/*     */   }
/*     */   
/*     */   public static void abstractClass(Class c) {
/* 259 */     error("The class " + c.getName() + " is an abstract class and cannot be instantiated.");
/*     */   }
/*     */   
/*     */   public static void interfaceClass(Class c) {
/* 263 */     error("The class " + c.getName() + " is an interface and cannot be instantiated.");
/*     */   }
/*     */   
/*     */   public static void missingDependency(Constructor ctor, int i) {
/* 267 */     error("Missing dependency for constructor " + ctor + " at parameter index " + i);
/*     */   }
/*     */   
/*     */   public static void setReportMissingDependentFieldOrMethod(boolean fieldReporting) {
/* 271 */     getInstance().fieldReporting = fieldReporting;
/*     */   }
/*     */   
/*     */   public static boolean getReportMissingDependentFieldOrMethod() {
/* 275 */     return getInstance().fieldReporting;
/*     */   }
/*     */   
/*     */   public static void missingDependency(Field f) {
/* 279 */     if (getReportMissingDependentFieldOrMethod()) {
/* 280 */       error("Missing dependency for field: " + f.toGenericString());
/*     */     }
/*     */   }
/*     */   
/*     */   public static void missingDependency(Method m, int i) {
/* 285 */     if (getReportMissingDependentFieldOrMethod()) {
/* 286 */       error("Missing dependency for method " + m + " at parameter at index " + i);
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract interface Closure<T>
/*     */   {
/*     */     public abstract T f();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\spi\inject\Errors.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */