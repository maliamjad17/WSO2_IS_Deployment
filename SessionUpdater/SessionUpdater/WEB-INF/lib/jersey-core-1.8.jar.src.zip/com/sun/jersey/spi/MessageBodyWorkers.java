package com.sun.jersey.spi;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.ext.MessageBodyReader;
import javax.ws.rs.ext.MessageBodyWriter;

public abstract interface MessageBodyWorkers
{
  public abstract Map<MediaType, List<MessageBodyReader>> getReaders(MediaType paramMediaType);
  
  public abstract Map<MediaType, List<MessageBodyWriter>> getWriters(MediaType paramMediaType);
  
  public abstract String readersToString(Map<MediaType, List<MessageBodyReader>> paramMap);
  
  public abstract String writersToString(Map<MediaType, List<MessageBodyWriter>> paramMap);
  
  public abstract <T> MessageBodyReader<T> getMessageBodyReader(Class<T> paramClass, Type paramType, Annotation[] paramArrayOfAnnotation, MediaType paramMediaType);
  
  public abstract <T> MessageBodyWriter<T> getMessageBodyWriter(Class<T> paramClass, Type paramType, Annotation[] paramArrayOfAnnotation, MediaType paramMediaType);
  
  public abstract <T> List<MediaType> getMessageBodyWriterMediaTypes(Class<T> paramClass, Type paramType, Annotation[] paramArrayOfAnnotation);
  
  public abstract <T> MediaType getMessageBodyWriterMediaType(Class<T> paramClass, Type paramType, Annotation[] paramArrayOfAnnotation, List<MediaType> paramList);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\spi\MessageBodyWorkers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */