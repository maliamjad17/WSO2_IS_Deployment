/*     */ package com.sun.jersey.core.impl.provider.entity;
/*     */ 
/*     */ import com.sun.jersey.core.provider.jaxb.AbstractRootElementProvider;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import java.io.InputStream;
/*     */ import javax.ws.rs.Consumes;
/*     */ import javax.ws.rs.Produces;
/*     */ import javax.ws.rs.core.Context;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.ext.Providers;
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLRootElementProvider
/*     */   extends AbstractRootElementProvider
/*     */ {
/*     */   private final Injectable<SAXParserFactory> spf;
/*     */   
/*     */   XMLRootElementProvider(Injectable<SAXParserFactory> spf, Providers ps)
/*     */   {
/*  66 */     super(ps);
/*     */     
/*  68 */     this.spf = spf;
/*     */   }
/*     */   
/*     */   XMLRootElementProvider(Injectable<SAXParserFactory> spf, Providers ps, MediaType mt) {
/*  72 */     super(ps, mt);
/*     */     
/*  74 */     this.spf = spf;
/*     */   }
/*     */   
/*     */   @Produces({"application/xml"})
/*     */   @Consumes({"application/xml"})
/*     */   public static final class App extends XMLRootElementProvider
/*     */   {
/*     */     public App(@Context Injectable<SAXParserFactory> spf, @Context Providers ps) {
/*  82 */       super(ps, MediaType.APPLICATION_XML_TYPE);
/*     */     }
/*     */   }
/*     */   
/*     */   @Produces({"text/xml"})
/*     */   @Consumes({"text/xml"})
/*     */   public static final class Text extends XMLRootElementProvider
/*     */   {
/*     */     public Text(@Context Injectable<SAXParserFactory> spf, @Context Providers ps) {
/*  91 */       super(ps, MediaType.TEXT_XML_TYPE);
/*     */     }
/*     */   }
/*     */   
/*     */   @Produces({"*/*"})
/*     */   @Consumes({"*/*"})
/*     */   public static final class General extends XMLRootElementProvider
/*     */   {
/*     */     public General(@Context Injectable<SAXParserFactory> spf, @Context Providers ps) {
/* 100 */       super(ps);
/*     */     }
/*     */     
/*     */     protected boolean isSupported(MediaType m)
/*     */     {
/* 105 */       return m.getSubtype().endsWith("+xml");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected Object readFrom(Class<Object> type, MediaType mediaType, Unmarshaller u, InputStream entityStream)
/*     */     throws JAXBException
/*     */   {
/* 113 */     SAXSource s = getSAXSource((SAXParserFactory)this.spf.getValue(), entityStream);
/* 114 */     if (type.isAnnotationPresent(XmlRootElement.class)) {
/* 115 */       return u.unmarshal(s);
/*     */     }
/* 117 */     return u.unmarshal(s, type).getValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\entity\XMLRootElementProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */