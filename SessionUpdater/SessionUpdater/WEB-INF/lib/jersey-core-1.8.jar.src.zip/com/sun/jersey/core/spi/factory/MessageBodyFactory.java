/*     */ package com.sun.jersey.core.spi.factory;
/*     */ 
/*     */ import com.sun.jersey.core.header.MediaTypes;
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper.DeclaringClassInterfacePair;
/*     */ import com.sun.jersey.core.spi.component.ProviderServices;
/*     */ import com.sun.jersey.core.util.KeyComparator;
/*     */ import com.sun.jersey.core.util.KeyComparatorHashMap;
/*     */ import com.sun.jersey.core.util.KeyComparatorLinkedHashMap;
/*     */ import com.sun.jersey.spi.MessageBodyWorkers;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.ws.rs.Consumes;
/*     */ import javax.ws.rs.Produces;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.ext.MessageBodyReader;
/*     */ import javax.ws.rs.ext.MessageBodyWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageBodyFactory
/*     */   implements MessageBodyWorkers
/*     */ {
/*  76 */   static final KeyComparator<MediaType> MEDIA_TYPE_COMPARATOR = new KeyComparator()
/*     */   {
/*     */     public boolean equals(MediaType x, MediaType y) {
/*  79 */       return (x.getType().equalsIgnoreCase(y.getType())) && (x.getSubtype().equalsIgnoreCase(y.getSubtype()));
/*     */     }
/*     */     
/*     */     public int hash(MediaType k)
/*     */     {
/*  84 */       return k.getType().toLowerCase().hashCode() + k.getSubtype().toLowerCase().hashCode();
/*     */     }
/*     */     
/*     */     public int compare(MediaType o1, MediaType o2)
/*     */     {
/*  89 */       throw new UnsupportedOperationException("Not supported yet.");
/*     */     }
/*     */   };
/*     */   
/*     */   private final ProviderServices providerServices;
/*     */   
/*     */   private final boolean deprecatedProviderPrecedence;
/*     */   
/*     */   private Map<MediaType, List<MessageBodyReader>> readerProviders;
/*     */   
/*     */   private Map<MediaType, List<MessageBodyWriter>> writerProviders;
/*     */   
/*     */   private List<MessageBodyWriterPair> writerListProviders;
/*     */   
/*     */   private Map<MediaType, List<MessageBodyReader>> customReaderProviders;
/*     */   
/*     */   private Map<MediaType, List<MessageBodyWriter>> customWriterProviders;
/*     */   private List<MessageBodyWriterPair> customWriterListProviders;
/*     */   
/*     */   private static class MessageBodyWriterPair
/*     */   {
/*     */     final MessageBodyWriter mbw;
/*     */     final List<MediaType> types;
/*     */     
/*     */     MessageBodyWriterPair(MessageBodyWriter mbw, List<MediaType> types)
/*     */     {
/* 115 */       this.mbw = mbw;
/* 116 */       this.types = types;
/*     */     }
/*     */   }
/*     */   
/*     */   public MessageBodyFactory(ProviderServices providerServices, boolean deprecatedProviderPrecedence) {
/* 121 */     this.providerServices = providerServices;
/* 122 */     this.deprecatedProviderPrecedence = deprecatedProviderPrecedence;
/*     */   }
/*     */   
/*     */   private static class DistanceComparator<T> implements Comparator<T>
/*     */   {
/*     */     private final Class<T> c;
/* 128 */     private final Map<Class, Integer> distanceMap = new HashMap();
/*     */     
/*     */     DistanceComparator(Class c) {
/* 131 */       this.c = c;
/*     */     }
/*     */     
/*     */     public int compare(T o1, T o2) {
/* 135 */       int d1 = getDistance(o1);
/* 136 */       int d2 = getDistance(o2);
/* 137 */       return d2 - d1;
/*     */     }
/*     */     
/*     */     int getDistance(T t) {
/* 141 */       Integer d = (Integer)this.distanceMap.get(t.getClass());
/* 142 */       if (d != null) {
/* 143 */         return d.intValue();
/*     */       }
/* 145 */       ReflectionHelper.DeclaringClassInterfacePair p = ReflectionHelper.getClass(t.getClass(), this.c);
/*     */       
/*     */ 
/* 148 */       Class[] as = ReflectionHelper.getParameterizedClassArguments(p);
/* 149 */       Class a = as != null ? as[0] : null;
/* 150 */       d = Integer.valueOf(0);
/* 151 */       while ((a != null) && (a != Object.class)) {
/* 152 */         Integer localInteger1 = d;Integer localInteger2 = d = Integer.valueOf(d.intValue() + 1);
/* 153 */         a = a.getSuperclass();
/*     */       }
/*     */       
/* 156 */       this.distanceMap.put(t.getClass(), d);
/* 157 */       return d.intValue();
/*     */     }
/*     */   }
/*     */   
/*     */   public void init() {
/* 162 */     initReaders();
/* 163 */     initWriters();
/*     */   }
/*     */   
/*     */   private void initReaders() {
/* 167 */     this.customReaderProviders = new KeyComparatorHashMap(MEDIA_TYPE_COMPARATOR);
/*     */     
/* 169 */     this.readerProviders = new KeyComparatorHashMap(MEDIA_TYPE_COMPARATOR);
/*     */     
/*     */ 
/* 172 */     if (this.deprecatedProviderPrecedence) {
/* 173 */       initReaders(this.readerProviders, this.providerServices.getProvidersAndServices(MessageBodyReader.class));
/*     */     } else {
/* 175 */       initReaders(this.customReaderProviders, this.providerServices.getProviders(MessageBodyReader.class));
/* 176 */       initReaders(this.readerProviders, this.providerServices.getServices(MessageBodyReader.class));
/*     */     }
/*     */   }
/*     */   
/*     */   private void initReaders(Map<MediaType, List<MessageBodyReader>> providersMap, Set<MessageBodyReader> providersSet) {
/* 181 */     for (Iterator i$ = providersSet.iterator(); i$.hasNext();) { provider = (MessageBodyReader)i$.next();
/* 182 */       List<MediaType> values = MediaTypes.createMediaTypes((Consumes)provider.getClass().getAnnotation(Consumes.class));
/*     */       
/* 184 */       for (MediaType type : values)
/* 185 */         getClassCapability(providersMap, provider, type);
/*     */     }
/*     */     MessageBodyReader provider;
/* 188 */     DistanceComparator<MessageBodyReader> dc = new DistanceComparator(MessageBodyReader.class);
/* 189 */     for (Map.Entry<MediaType, List<MessageBodyReader>> e : providersMap.entrySet()) {
/* 190 */       Collections.sort((List)e.getValue(), dc);
/*     */     }
/*     */   }
/*     */   
/*     */   private void initWriters() {
/* 195 */     this.customWriterProviders = new KeyComparatorHashMap(MEDIA_TYPE_COMPARATOR);
/*     */     
/* 197 */     this.customWriterListProviders = new ArrayList();
/*     */     
/* 199 */     this.writerProviders = new KeyComparatorHashMap(MEDIA_TYPE_COMPARATOR);
/*     */     
/* 201 */     this.writerListProviders = new ArrayList();
/*     */     
/* 203 */     if (this.deprecatedProviderPrecedence) {
/* 204 */       initWriters(this.writerProviders, this.writerListProviders, this.providerServices.getProvidersAndServices(MessageBodyWriter.class));
/*     */     } else {
/* 206 */       initWriters(this.customWriterProviders, this.customWriterListProviders, this.providerServices.getProviders(MessageBodyWriter.class));
/* 207 */       initWriters(this.writerProviders, this.writerListProviders, this.providerServices.getServices(MessageBodyWriter.class));
/*     */     }
/*     */   }
/*     */   
/*     */   private void initWriters(Map<MediaType, List<MessageBodyWriter>> providersMap, List<MessageBodyWriterPair> listProviders, Set<MessageBodyWriter> providersSet) {
/* 212 */     for (MessageBodyWriter provider : providersSet) {
/* 213 */       List<MediaType> values = MediaTypes.createMediaTypes((Produces)provider.getClass().getAnnotation(Produces.class));
/*     */       
/* 215 */       for (MediaType type : values) {
/* 216 */         getClassCapability(providersMap, provider, type);
/*     */       }
/* 218 */       listProviders.add(new MessageBodyWriterPair(provider, values));
/*     */     }
/*     */     
/* 221 */     final DistanceComparator<MessageBodyWriter> dc = new DistanceComparator(MessageBodyWriter.class);
/* 222 */     for (Map.Entry<MediaType, List<MessageBodyWriter>> e : providersMap.entrySet()) {
/* 223 */       Collections.sort((List)e.getValue(), dc);
/*     */     }
/*     */     
/* 226 */     Collections.sort(listProviders, new Comparator() {
/*     */       public int compare(MessageBodyFactory.MessageBodyWriterPair p1, MessageBodyFactory.MessageBodyWriterPair p2) {
/* 228 */         return dc.compare(p1.mbw, p2.mbw);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private <T> void getClassCapability(Map<MediaType, List<T>> capabilities, T provider, MediaType mediaType)
/*     */   {
/* 235 */     if (!capabilities.containsKey(mediaType)) {
/* 236 */       capabilities.put(mediaType, new ArrayList());
/*     */     }
/* 238 */     List<T> providers = (List)capabilities.get(mediaType);
/* 239 */     providers.add(provider);
/*     */   }
/*     */   
/*     */ 
/*     */   public Map<MediaType, List<MessageBodyReader>> getReaders(MediaType mediaType)
/*     */   {
/* 245 */     Map<MediaType, List<MessageBodyReader>> subSet = new KeyComparatorLinkedHashMap(MEDIA_TYPE_COMPARATOR);
/*     */     
/*     */ 
/*     */ 
/* 249 */     if (!this.customReaderProviders.isEmpty())
/* 250 */       getCompatibleReadersWritersMap(mediaType, this.customReaderProviders, subSet);
/* 251 */     getCompatibleReadersWritersMap(mediaType, this.readerProviders, subSet);
/* 252 */     return subSet;
/*     */   }
/*     */   
/*     */   public Map<MediaType, List<MessageBodyWriter>> getWriters(MediaType mediaType) {
/* 256 */     Map<MediaType, List<MessageBodyWriter>> subSet = new KeyComparatorLinkedHashMap(MEDIA_TYPE_COMPARATOR);
/*     */     
/*     */ 
/*     */ 
/* 260 */     if (!this.customWriterProviders.isEmpty())
/* 261 */       getCompatibleReadersWritersMap(mediaType, this.customWriterProviders, subSet);
/* 262 */     getCompatibleReadersWritersMap(mediaType, this.writerProviders, subSet);
/* 263 */     return subSet;
/*     */   }
/*     */   
/*     */   public String readersToString(Map<MediaType, List<MessageBodyReader>> readers) {
/* 267 */     return toString(readers);
/*     */   }
/*     */   
/*     */   public String writersToString(Map<MediaType, List<MessageBodyWriter>> writers) {
/* 271 */     return toString(writers);
/*     */   }
/*     */   
/*     */   private <T> String toString(Map<MediaType, List<T>> set) {
/* 275 */     StringWriter sw = new StringWriter();
/* 276 */     PrintWriter pw = new PrintWriter(sw);
/* 277 */     for (Map.Entry<MediaType, List<T>> e : set.entrySet()) {
/* 278 */       pw.append(((MediaType)e.getKey()).toString()).println(" ->");
/* 279 */       for (T t : (List)e.getValue()) {
/* 280 */         pw.append("  ").println(t.getClass().getName());
/*     */       }
/*     */     }
/* 283 */     pw.flush();
/* 284 */     return sw.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> MessageBodyReader<T> getMessageBodyReader(Class<T> c, Type t, Annotation[] as, MediaType mediaType)
/*     */   {
/* 293 */     if (!this.customReaderProviders.isEmpty()) {
/* 294 */       MessageBodyReader reader = _getMessageBodyReader(c, t, as, mediaType, this.customReaderProviders);
/* 295 */       if (reader != null)
/* 296 */         return reader;
/*     */     }
/* 298 */     MessageBodyReader reader = _getMessageBodyReader(c, t, as, mediaType, this.readerProviders);
/*     */     
/* 300 */     return reader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private <T> MessageBodyReader<T> _getMessageBodyReader(Class<T> c, Type t, Annotation[] as, MediaType mediaType, Map<MediaType, List<MessageBodyReader>> providers)
/*     */   {
/* 307 */     MessageBodyReader p = null;
/* 308 */     if (mediaType != null) {
/* 309 */       p = _getMessageBodyReader(c, t, as, mediaType, mediaType, providers);
/* 310 */       if (p == null) {
/* 311 */         p = _getMessageBodyReader(c, t, as, mediaType, MediaTypes.getTypeWildCart(mediaType), providers);
/*     */       }
/*     */     }
/* 314 */     if (p == null) {
/* 315 */       p = _getMessageBodyReader(c, t, as, mediaType, MediaTypes.GENERAL_MEDIA_TYPE, providers);
/*     */     }
/* 317 */     return p;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private <T> MessageBodyReader<T> _getMessageBodyReader(Class<T> c, Type t, Annotation[] as, MediaType mediaType, MediaType lookup)
/*     */   {
/* 326 */     if (!this.customReaderProviders.isEmpty()) {
/* 327 */       MessageBodyReader reader = _getMessageBodyReader(c, t, as, mediaType, lookup, this.customReaderProviders);
/* 328 */       if (reader != null)
/* 329 */         return reader;
/*     */     }
/* 331 */     MessageBodyReader reader = _getMessageBodyReader(c, t, as, mediaType, lookup, this.readerProviders);
/*     */     
/* 333 */     return reader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private <T> MessageBodyReader<T> _getMessageBodyReader(Class<T> c, Type t, Annotation[] as, MediaType mediaType, MediaType lookup, Map<MediaType, List<MessageBodyReader>> providers)
/*     */   {
/* 341 */     List<MessageBodyReader> readers = (List)providers.get(lookup);
/* 342 */     if (readers == null)
/* 343 */       return null;
/* 344 */     for (MessageBodyReader p : readers) {
/* 345 */       if (p.isReadable(c, t, as, mediaType)) {
/* 346 */         return p;
/*     */       }
/*     */     }
/* 349 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> MessageBodyWriter<T> getMessageBodyWriter(Class<T> c, Type t, Annotation[] as, MediaType mediaType)
/*     */   {
/* 358 */     if (!this.customWriterProviders.isEmpty()) {
/* 359 */       MessageBodyWriter p = _getMessageBodyWriter(c, t, as, mediaType, this.customWriterProviders);
/* 360 */       if (p != null)
/* 361 */         return p;
/*     */     }
/* 363 */     MessageBodyWriter p = _getMessageBodyWriter(c, t, as, mediaType, this.writerProviders);
/*     */     
/* 365 */     return p;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private <T> MessageBodyWriter<T> _getMessageBodyWriter(Class<T> c, Type t, Annotation[] as, MediaType mediaType, Map<MediaType, List<MessageBodyWriter>> providers)
/*     */   {
/* 373 */     MessageBodyWriter p = null;
/*     */     
/* 375 */     if (mediaType != null) {
/* 376 */       p = _getMessageBodyWriter(c, t, as, mediaType, mediaType, providers);
/* 377 */       if (p == null) {
/* 378 */         p = _getMessageBodyWriter(c, t, as, mediaType, MediaTypes.getTypeWildCart(mediaType), providers);
/*     */       }
/*     */     }
/* 381 */     if (p == null) {
/* 382 */       p = _getMessageBodyWriter(c, t, as, mediaType, MediaTypes.GENERAL_MEDIA_TYPE, providers);
/*     */     }
/* 384 */     return p;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private <T> MessageBodyWriter<T> _getMessageBodyWriter(Class<T> c, Type t, Annotation[] as, MediaType mediaType, MediaType lookup, Map<MediaType, List<MessageBodyWriter>> providers)
/*     */   {
/* 391 */     List<MessageBodyWriter> writers = (List)providers.get(lookup);
/* 392 */     if (writers == null)
/* 393 */       return null;
/* 394 */     for (MessageBodyWriter p : writers) {
/* 395 */       if (p.isWriteable(c, t, as, mediaType)) {
/* 396 */         return p;
/*     */       }
/*     */     }
/*     */     
/* 400 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   private <T> void getCompatibleReadersWritersMap(MediaType mediaType, Map<MediaType, List<T>> set, Map<MediaType, List<T>> subSet)
/*     */   {
/* 406 */     if (mediaType.isWildcardType()) {
/* 407 */       getCompatibleReadersWritersList(mediaType, set, subSet);
/* 408 */     } else if (mediaType.isWildcardSubtype()) {
/* 409 */       getCompatibleReadersWritersList(mediaType, set, subSet);
/* 410 */       getCompatibleReadersWritersList(MediaTypes.GENERAL_MEDIA_TYPE, set, subSet);
/*     */     } else {
/* 412 */       getCompatibleReadersWritersList(mediaType, set, subSet);
/* 413 */       getCompatibleReadersWritersList(MediaTypes.getTypeWildCart(mediaType), set, subSet);
/*     */       
/*     */ 
/* 416 */       getCompatibleReadersWritersList(MediaTypes.GENERAL_MEDIA_TYPE, set, subSet);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private <T> void getCompatibleReadersWritersList(MediaType mediaType, Map<MediaType, List<T>> set, Map<MediaType, List<T>> subSet)
/*     */   {
/* 424 */     List<T> readers = (List)set.get(mediaType);
/* 425 */     if (readers != null) {
/* 426 */       subSet.put(mediaType, Collections.unmodifiableList(readers));
/*     */     }
/*     */   }
/*     */   
/*     */   public <T> List<MediaType> getMessageBodyWriterMediaTypes(Class<T> c, Type t, Annotation[] as)
/*     */   {
/* 432 */     List<MediaType> mtl = new ArrayList();
/* 433 */     for (MessageBodyWriterPair mbwp : this.customWriterListProviders) {
/* 434 */       if (mbwp.mbw.isWriteable(c, t, as, MediaType.APPLICATION_OCTET_STREAM_TYPE)) {
/* 435 */         mtl.addAll(mbwp.types);
/*     */       }
/*     */     }
/* 438 */     for (MessageBodyWriterPair mbwp : this.writerListProviders) {
/* 439 */       if (mbwp.mbw.isWriteable(c, t, as, MediaType.APPLICATION_OCTET_STREAM_TYPE)) {
/* 440 */         mtl.addAll(mbwp.types);
/*     */       }
/*     */     }
/*     */     
/* 444 */     Collections.sort(mtl, MediaTypes.MEDIA_TYPE_COMPARATOR);
/* 445 */     return mtl;
/*     */   }
/*     */   
/*     */   public <T> MediaType getMessageBodyWriterMediaType(Class<T> c, Type t, Annotation[] as, List<MediaType> acceptableMediaTypes)
/*     */   {
/* 450 */     for (Iterator i$ = acceptableMediaTypes.iterator(); i$.hasNext();) { acceptable = (MediaType)i$.next();
/* 451 */       for (Iterator i$ = this.customWriterListProviders.iterator(); i$.hasNext();) { mbwp = (MessageBodyWriterPair)i$.next();
/* 452 */         for (MediaType mt : mbwp.types) {
/* 453 */           if ((mt.isCompatible(acceptable)) && (mbwp.mbw.isWriteable(c, t, as, acceptable)))
/*     */           {
/* 455 */             return MediaTypes.mostSpecific(mt, acceptable); }
/*     */         }
/*     */       }
/*     */       MessageBodyWriterPair mbwp;
/* 459 */       for (i$ = this.writerListProviders.iterator(); i$.hasNext();) { mbwp = (MessageBodyWriterPair)i$.next();
/* 460 */         for (MediaType mt : mbwp.types)
/* 461 */           if ((mt.isCompatible(acceptable)) && (mbwp.mbw.isWriteable(c, t, as, acceptable)))
/*     */           {
/* 463 */             return MediaTypes.mostSpecific(mt, acceptable); }
/*     */       }
/*     */     }
/*     */     MediaType acceptable;
/*     */     Iterator i$;
/*     */     MessageBodyWriterPair mbwp;
/* 469 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\factory\MessageBodyFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */