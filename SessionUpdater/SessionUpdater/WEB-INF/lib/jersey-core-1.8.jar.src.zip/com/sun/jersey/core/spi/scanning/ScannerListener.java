package com.sun.jersey.core.spi.scanning;

import java.io.IOException;
import java.io.InputStream;

public abstract interface ScannerListener
{
  public abstract boolean onAccept(String paramString);
  
  public abstract void onProcess(String paramString, InputStream paramInputStream)
    throws IOException;
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\scanning\ScannerListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */