/*     */ package com.sun.jersey.core.spi.factory;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.Variant;
/*     */ import javax.ws.rs.core.Variant.VariantListBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VariantListBuilderImpl
/*     */   extends Variant.VariantListBuilder
/*     */ {
/*     */   private List<Variant> variants;
/*  59 */   private final List<MediaType> mediaTypes = new ArrayList();
/*     */   
/*  61 */   private final List<Locale> languages = new ArrayList();
/*     */   
/*  63 */   private final List<String> charsets = new ArrayList();
/*     */   
/*  65 */   private final List<String> encodings = new ArrayList();
/*     */   
/*     */   public List<Variant> build()
/*     */   {
/*  69 */     if (this.variants == null) {
/*  70 */       this.variants = new ArrayList();
/*     */     }
/*  72 */     return this.variants;
/*     */   }
/*     */   
/*     */   public Variant.VariantListBuilder add()
/*     */   {
/*  77 */     if (this.variants == null) {
/*  78 */       this.variants = new ArrayList();
/*     */     }
/*  80 */     addMediaTypes();
/*     */     
/*  82 */     this.charsets.clear();
/*  83 */     this.languages.clear();
/*  84 */     this.encodings.clear();
/*  85 */     this.mediaTypes.clear();
/*     */     
/*  87 */     return this;
/*     */   }
/*     */   
/*     */   private void addMediaTypes() {
/*  91 */     if (this.mediaTypes.isEmpty()) { addLanguages(null); } else { MediaType mediaType;
/*  92 */       for (Iterator i$ = this.mediaTypes.iterator(); i$.hasNext(); addLanguages(mediaType)) mediaType = (MediaType)i$.next();
/*     */     }
/*     */   }
/*     */   
/*  96 */   private void addLanguages(MediaType mediaType) { if (this.languages.isEmpty()) { addEncodings(mediaType, null); } else { Locale language;
/*  97 */       for (Iterator i$ = this.languages.iterator(); i$.hasNext(); addEncodings(mediaType, language)) language = (Locale)i$.next();
/*     */     }
/*     */   }
/*     */   
/* 101 */   private void addEncodings(MediaType mediaType, Locale language) { if (this.encodings.isEmpty()) { addVariant(mediaType, language, null); } else { String encoding;
/* 102 */       for (Iterator i$ = this.encodings.iterator(); i$.hasNext(); addVariant(mediaType, language, encoding)) encoding = (String)i$.next();
/*     */     }
/*     */   }
/*     */   
/* 106 */   private void addVariant(MediaType mediaType, Locale language, String encoding) { this.variants.add(new Variant(mediaType, language, encoding)); }
/*     */   
/*     */ 
/*     */   public Variant.VariantListBuilder languages(Locale... languages)
/*     */   {
/* 111 */     for (Locale language : languages) this.languages.add(language);
/* 112 */     return this;
/*     */   }
/*     */   
/*     */   public Variant.VariantListBuilder encodings(String... encodings)
/*     */   {
/* 117 */     for (String encoding : encodings) this.encodings.add(encoding);
/* 118 */     return this;
/*     */   }
/*     */   
/*     */   public Variant.VariantListBuilder mediaTypes(MediaType... mediaTypes)
/*     */   {
/* 123 */     for (MediaType mediaType : mediaTypes) this.mediaTypes.add(mediaType);
/* 124 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\factory\VariantListBuilderImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */