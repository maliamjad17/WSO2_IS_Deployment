/*     */ package com.sun.jersey.core.provider.jaxb;
/*     */ 
/*     */ import com.sun.jersey.api.provider.jaxb.XmlHeader;
/*     */ import com.sun.jersey.core.provider.AbstractMessageReaderWriterProvider;
/*     */ import com.sun.jersey.core.util.FeaturesAndProperties;
/*     */ import java.io.InputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import javax.ws.rs.core.Context;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.ext.ContextResolver;
/*     */ import javax.ws.rs.ext.Providers;
/*     */ import javax.xml.bind.JAXBContext;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.Marshaller;
/*     */ import javax.xml.bind.PropertyException;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractJAXBProvider<T>
/*     */   extends AbstractMessageReaderWriterProvider<T>
/*     */ {
/*  69 */   private static final Map<Class, JAXBContext> jaxbContexts = new WeakHashMap();
/*     */   
/*     */ 
/*     */   private final Providers ps;
/*     */   
/*     */   private final boolean fixedMediaType;
/*     */   
/*     */   private final ContextResolver<JAXBContext> mtContext;
/*     */   
/*     */   private final ContextResolver<Unmarshaller> mtUnmarshaller;
/*     */   
/*     */   private final ContextResolver<Marshaller> mtMarshaller;
/*     */   
/*  82 */   private boolean formattedOutput = false;
/*     */   
/*  84 */   private boolean xmlRootElementProcessing = false;
/*     */   
/*     */   public AbstractJAXBProvider(Providers ps) {
/*  87 */     this(ps, null);
/*     */   }
/*     */   
/*     */   public AbstractJAXBProvider(Providers ps, MediaType mt) {
/*  91 */     this.ps = ps;
/*     */     
/*  93 */     this.fixedMediaType = (mt != null);
/*  94 */     if (this.fixedMediaType) {
/*  95 */       this.mtContext = ps.getContextResolver(JAXBContext.class, mt);
/*  96 */       this.mtUnmarshaller = ps.getContextResolver(Unmarshaller.class, mt);
/*  97 */       this.mtMarshaller = ps.getContextResolver(Marshaller.class, mt);
/*     */     } else {
/*  99 */       this.mtContext = null;
/* 100 */       this.mtUnmarshaller = null;
/* 101 */       this.mtMarshaller = null;
/*     */     }
/*     */   }
/*     */   
/*     */   @Context
/*     */   public void setConfiguration(FeaturesAndProperties fp) {
/* 107 */     this.formattedOutput = fp.getFeature("com.sun.jersey.config.feature.Formatted");
/* 108 */     this.xmlRootElementProcessing = fp.getFeature("com.sun.jersey.config.feature.XmlRootElementProcessing");
/*     */   }
/*     */   
/*     */   protected boolean isSupported(MediaType m) {
/* 112 */     return true;
/*     */   }
/*     */   
/*     */   protected final Unmarshaller getUnmarshaller(Class type, MediaType mt) throws JAXBException {
/* 116 */     if (this.fixedMediaType) {
/* 117 */       return getUnmarshaller(type);
/*     */     }
/* 119 */     ContextResolver<Unmarshaller> uncr = this.ps.getContextResolver(Unmarshaller.class, mt);
/* 120 */     if (uncr != null) {
/* 121 */       Unmarshaller u = (Unmarshaller)uncr.getContext(type);
/* 122 */       if (u != null) { return u;
/*     */       }
/*     */     }
/* 125 */     return getJAXBContext(type, mt).createUnmarshaller();
/*     */   }
/*     */   
/*     */   private Unmarshaller getUnmarshaller(Class type) throws JAXBException {
/* 129 */     if (this.mtUnmarshaller != null) {
/* 130 */       Unmarshaller u = (Unmarshaller)this.mtUnmarshaller.getContext(type);
/* 131 */       if (u != null) { return u;
/*     */       }
/*     */     }
/* 134 */     return getJAXBContext(type).createUnmarshaller();
/*     */   }
/*     */   
/*     */   protected final Marshaller getMarshaller(Class type, MediaType mt) throws JAXBException {
/* 138 */     if (this.fixedMediaType) {
/* 139 */       return getMarshaller(type);
/*     */     }
/* 141 */     ContextResolver<Marshaller> mcr = this.ps.getContextResolver(Marshaller.class, mt);
/* 142 */     if (mcr != null) {
/* 143 */       Marshaller m = (Marshaller)mcr.getContext(type);
/* 144 */       if (m != null) { return m;
/*     */       }
/*     */     }
/* 147 */     Marshaller m = getJAXBContext(type, mt).createMarshaller();
/* 148 */     if (this.formattedOutput)
/* 149 */       m.setProperty("jaxb.formatted.output", Boolean.valueOf(this.formattedOutput));
/* 150 */     return m;
/*     */   }
/*     */   
/*     */   private Marshaller getMarshaller(Class type) throws JAXBException
/*     */   {
/* 155 */     if (this.mtMarshaller != null) {
/* 156 */       Marshaller u = (Marshaller)this.mtMarshaller.getContext(type);
/* 157 */       if (u != null) { return u;
/*     */       }
/*     */     }
/* 160 */     Marshaller m = getJAXBContext(type).createMarshaller();
/* 161 */     if (this.formattedOutput)
/* 162 */       m.setProperty("jaxb.formatted.output", Boolean.valueOf(this.formattedOutput));
/* 163 */     return m;
/*     */   }
/*     */   
/*     */   private JAXBContext getJAXBContext(Class type, MediaType mt) throws JAXBException {
/* 167 */     ContextResolver<JAXBContext> cr = this.ps.getContextResolver(JAXBContext.class, mt);
/* 168 */     if (cr != null) {
/* 169 */       JAXBContext c = (JAXBContext)cr.getContext(type);
/* 170 */       if (c != null) { return c;
/*     */       }
/*     */     }
/* 173 */     return getStoredJAXBContext(type);
/*     */   }
/*     */   
/*     */   private JAXBContext getJAXBContext(Class type) throws JAXBException {
/* 177 */     if (this.mtContext != null) {
/* 178 */       JAXBContext c = (JAXBContext)this.mtContext.getContext(type);
/* 179 */       if (c != null) { return c;
/*     */       }
/*     */     }
/* 182 */     return getStoredJAXBContext(type);
/*     */   }
/*     */   
/*     */   protected JAXBContext getStoredJAXBContext(Class type) throws JAXBException {
/* 186 */     synchronized (jaxbContexts) {
/* 187 */       JAXBContext c = (JAXBContext)jaxbContexts.get(type);
/* 188 */       if (c == null) {
/* 189 */         c = JAXBContext.newInstance(new Class[] { type });
/* 190 */         jaxbContexts.put(type, c);
/*     */       }
/* 192 */       return c;
/*     */     }
/*     */   }
/*     */   
/*     */   protected static SAXSource getSAXSource(SAXParserFactory spf, InputStream entityStream) throws JAXBException
/*     */   {
/*     */     try {
/* 199 */       return new SAXSource(spf.newSAXParser().getXMLReader(), new InputSource(entityStream));
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 203 */       throw new JAXBException("Error creating SAXSource", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean isFormattedOutput() {
/* 208 */     return this.formattedOutput;
/*     */   }
/*     */   
/*     */   protected boolean isXmlRootElementProcessing() {
/* 212 */     return this.xmlRootElementProcessing;
/*     */   }
/*     */   
/*     */   protected void setHeader(Marshaller m, Annotation[] annotations) throws PropertyException {
/* 216 */     for (Annotation a : annotations) {
/* 217 */       if ((a instanceof XmlHeader)) {
/*     */         try {
/* 219 */           m.setProperty("com.sun.xml.bind.xmlHeaders", ((XmlHeader)a).value());
/*     */         } catch (PropertyException e) {
/* 221 */           m.setProperty("com.sun.xml.internal.bind.xmlHeaders", ((XmlHeader)a).value());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\provider\jaxb\AbstractJAXBProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */