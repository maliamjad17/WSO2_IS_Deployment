/*     */ package com.sun.jersey.core.reflection;
/*     */ 
/*     */ import com.sun.jersey.impl.ImplMessages;
/*     */ import java.lang.reflect.AccessibleObject;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectionHelper
/*     */ {
/*     */   public static Class getDeclaringClass(AccessibleObject ao)
/*     */   {
/*  70 */     if ((ao instanceof Method))
/*  71 */       return ((Method)ao).getDeclaringClass();
/*  72 */     if ((ao instanceof Field))
/*  73 */       return ((Field)ao).getDeclaringClass();
/*  74 */     if ((ao instanceof Constructor)) {
/*  75 */       return ((Constructor)ao).getDeclaringClass();
/*     */     }
/*  77 */     throw new RuntimeException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String objectToString(Object o)
/*     */   {
/*  98 */     if (o == null)
/*  99 */       return "null";
/* 100 */     StringBuffer sb = new StringBuffer();
/* 101 */     sb.append(o.getClass().getName()).append('@').append(Integer.toHexString(o.hashCode()));
/*     */     
/* 103 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String methodInstanceToString(Object o, Method m)
/*     */   {
/* 128 */     StringBuffer sb = new StringBuffer();
/* 129 */     sb.append(o.getClass().getName()).append('@').append(Integer.toHexString(o.hashCode())).append('.').append(m.getName()).append('(');
/*     */     
/*     */ 
/*     */ 
/* 133 */     Class[] params = m.getParameterTypes();
/* 134 */     for (int i = 0; i < params.length; i++) {
/* 135 */       sb.append(getTypeName(params[i]));
/* 136 */       if (i < params.length - 1) {
/* 137 */         sb.append(",");
/*     */       }
/*     */     }
/* 140 */     sb.append(')');
/*     */     
/* 142 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String getTypeName(Class type)
/*     */   {
/* 151 */     if (type.isArray()) {
/*     */       try {
/* 153 */         Class cl = type;
/* 154 */         int dimensions = 0;
/* 155 */         while (cl.isArray()) {
/* 156 */           dimensions++;
/* 157 */           cl = cl.getComponentType();
/*     */         }
/* 159 */         StringBuffer sb = new StringBuffer();
/* 160 */         sb.append(cl.getName());
/* 161 */         for (int i = 0; i < dimensions; i++) {
/* 162 */           sb.append("[]");
/*     */         }
/* 164 */         return sb.toString();
/*     */       } catch (Throwable e) {}
/*     */     }
/* 167 */     return type.getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class classForName(String name)
/*     */   {
/* 181 */     return classForName(name, getContextClassLoader());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class classForName(String name, ClassLoader cl)
/*     */   {
/* 193 */     if (cl != null) {
/*     */       try {
/* 195 */         return Class.forName(name, false, cl);
/*     */       }
/*     */       catch (ClassNotFoundException ex) {}
/*     */     }
/*     */     try {
/* 200 */       return Class.forName(name);
/*     */     }
/*     */     catch (ClassNotFoundException ex) {}
/*     */     
/* 204 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class classForNameWithException(String name)
/*     */     throws ClassNotFoundException
/*     */   {
/* 220 */     return classForNameWithException(name, getContextClassLoader());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class classForNameWithException(String name, ClassLoader cl)
/*     */     throws ClassNotFoundException
/*     */   {
/* 234 */     if (cl != null) {
/*     */       try {
/* 236 */         return Class.forName(name, false, cl);
/*     */       }
/*     */       catch (ClassNotFoundException ex) {}
/*     */     }
/* 240 */     return Class.forName(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ClassLoader getContextClassLoader()
/*     */   {
/* 250 */     (ClassLoader)AccessController.doPrivileged(new PrivilegedAction()
/*     */     {
/*     */       public ClassLoader run() {
/* 253 */         ClassLoader cl = null;
/*     */         try {
/* 255 */           cl = Thread.currentThread().getContextClassLoader();
/*     */         }
/*     */         catch (SecurityException ex) {}
/* 258 */         return cl;
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setAccessibleMethod(Method m)
/*     */   {
/* 269 */     if (Modifier.isPublic(m.getModifiers())) {
/* 270 */       return;
/*     */     }
/* 272 */     AccessController.doPrivileged(new PrivilegedAction() {
/*     */       public Object run() {
/* 274 */         if (!this.val$m.isAccessible()) {
/* 275 */           this.val$m.setAccessible(true);
/*     */         }
/* 277 */         return this.val$m;
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class getGenericClass(Type parameterizedType)
/*     */     throws IllegalArgumentException
/*     */   {
/* 301 */     Type t = getTypeArgumentOfParameterizedType(parameterizedType);
/* 302 */     if (t == null) {
/* 303 */       return null;
/*     */     }
/* 305 */     Class c = getClassOfType(t);
/* 306 */     if (c == null) {
/* 307 */       throw new IllegalArgumentException(ImplMessages.GENERIC_TYPE_NOT_SUPPORTED(t, parameterizedType));
/*     */     }
/*     */     
/* 310 */     return c;
/*     */   }
/*     */   
/*     */   public static final class TypeClassPair {
/*     */     public final Type t;
/*     */     public final Class c;
/*     */     
/*     */     public TypeClassPair(Type t, Class c) {
/* 318 */       this.t = t;
/* 319 */       this.c = c;
/*     */     }
/*     */   }
/*     */   
/*     */   public static TypeClassPair getTypeArgumentAndClass(Type parameterizedType) throws IllegalArgumentException {
/* 324 */     Type t = getTypeArgumentOfParameterizedType(parameterizedType);
/* 325 */     if (t == null) {
/* 326 */       return null;
/*     */     }
/* 328 */     Class c = getClassOfType(t);
/* 329 */     if (c == null) {
/* 330 */       throw new IllegalArgumentException(ImplMessages.GENERIC_TYPE_NOT_SUPPORTED(t, parameterizedType));
/*     */     }
/*     */     
/*     */ 
/* 334 */     return new TypeClassPair(t, c);
/*     */   }
/*     */   
/*     */   private static Type getTypeArgumentOfParameterizedType(Type parameterizedType) {
/* 338 */     if (!(parameterizedType instanceof ParameterizedType)) { return null;
/*     */     }
/* 340 */     ParameterizedType type = (ParameterizedType)parameterizedType;
/* 341 */     Type[] genericTypes = type.getActualTypeArguments();
/* 342 */     if (genericTypes.length != 1) { return null;
/*     */     }
/* 344 */     return genericTypes[0];
/*     */   }
/*     */   
/*     */   private static Class getClassOfType(Type type) {
/* 348 */     if ((type instanceof Class))
/* 349 */       return (Class)type;
/* 350 */     if ((type instanceof GenericArrayType)) {
/* 351 */       GenericArrayType arrayType = (GenericArrayType)type;
/* 352 */       Type t = arrayType.getGenericComponentType();
/* 353 */       if ((t instanceof Class)) {
/* 354 */         return getArrayClass((Class)t);
/*     */       }
/* 356 */     } else if ((type instanceof ParameterizedType)) {
/* 357 */       ParameterizedType subType = (ParameterizedType)type;
/* 358 */       Type t = subType.getRawType();
/* 359 */       if ((t instanceof Class)) {
/* 360 */         return (Class)t;
/*     */       }
/*     */     }
/* 363 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class getArrayClass(Class c)
/*     */   {
/*     */     try
/*     */     {
/* 374 */       Object o = Array.newInstance(c, 0);
/* 375 */       return o.getClass();
/*     */     } catch (Exception e) {
/* 377 */       throw new IllegalArgumentException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Method getValueOfStringMethod(Class c)
/*     */   {
/*     */     try
/*     */     {
/* 390 */       Method m = c.getDeclaredMethod("valueOf", new Class[] { String.class });
/* 391 */       if ((!Modifier.isStatic(m.getModifiers())) && (m.getReturnType() == c)) {
/* 392 */         return null;
/*     */       }
/* 394 */       return m;
/*     */     } catch (Exception e) {}
/* 396 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Method getFromStringStringMethod(Class c)
/*     */   {
/*     */     try
/*     */     {
/* 409 */       Method m = c.getDeclaredMethod("fromString", new Class[] { String.class });
/* 410 */       if ((!Modifier.isStatic(m.getModifiers())) && (m.getReturnType() == c)) {
/* 411 */         return null;
/*     */       }
/* 413 */       return m;
/*     */     } catch (Exception e) {}
/* 415 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Constructor getStringConstructor(Class c)
/*     */   {
/*     */     try
/*     */     {
/* 428 */       return c.getConstructor(new Class[] { String.class });
/*     */     } catch (Exception e) {}
/* 430 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class DeclaringClassInterfacePair
/*     */   {
/*     */     public final Class concreteClass;
/*     */     
/*     */ 
/*     */     public final Class declaringClass;
/*     */     
/*     */     public final Type genericInterface;
/*     */     
/*     */ 
/*     */     private DeclaringClassInterfacePair(Class concreteClass, Class declaringClass, Type genericInteface)
/*     */     {
/* 447 */       this.concreteClass = concreteClass;
/* 448 */       this.declaringClass = declaringClass;
/* 449 */       this.genericInterface = genericInteface;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class[] getParameterizedClassArguments(DeclaringClassInterfacePair p)
/*     */   {
/* 462 */     if ((p.genericInterface instanceof ParameterizedType)) {
/* 463 */       ParameterizedType pt = (ParameterizedType)p.genericInterface;
/* 464 */       Type[] as = pt.getActualTypeArguments();
/* 465 */       Class[] cas = new Class[as.length];
/*     */       
/* 467 */       for (int i = 0; i < as.length; i++) {
/* 468 */         Type a = as[i];
/* 469 */         if ((a instanceof Class)) {
/* 470 */           cas[i] = ((Class)a);
/* 471 */         } else if ((a instanceof ParameterizedType)) {
/* 472 */           pt = (ParameterizedType)a;
/* 473 */           cas[i] = ((Class)pt.getRawType());
/* 474 */         } else if ((a instanceof TypeVariable)) {
/* 475 */           ClassTypePair ctp = resolveTypeVariable(p.concreteClass, p.declaringClass, (TypeVariable)a);
/* 476 */           cas[i] = (ctp != null ? ctp.c : Object.class);
/*     */         }
/*     */       }
/* 479 */       return cas;
/*     */     }
/* 481 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type[] getParameterizedTypeArguments(DeclaringClassInterfacePair p)
/*     */   {
/* 494 */     if ((p.genericInterface instanceof ParameterizedType)) {
/* 495 */       ParameterizedType pt = (ParameterizedType)p.genericInterface;
/* 496 */       Type[] as = pt.getActualTypeArguments();
/* 497 */       Type[] ras = new Type[as.length];
/*     */       
/* 499 */       for (int i = 0; i < as.length; i++) {
/* 500 */         Type a = as[i];
/* 501 */         if ((a instanceof Class)) {
/* 502 */           ras[i] = a;
/* 503 */         } else if ((a instanceof ParameterizedType)) {
/* 504 */           pt = (ParameterizedType)a;
/* 505 */           ras[i] = a;
/* 506 */         } else if ((a instanceof TypeVariable)) {
/* 507 */           ClassTypePair ctp = resolveTypeVariable(p.concreteClass, p.declaringClass, (TypeVariable)a);
/* 508 */           ras[i] = ctp.t;
/*     */         }
/*     */       }
/* 511 */       return ras;
/*     */     }
/* 513 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static DeclaringClassInterfacePair getClass(Class concrete, Class iface)
/*     */   {
/* 527 */     return getClass(concrete, iface, concrete);
/*     */   }
/*     */   
/*     */   private static DeclaringClassInterfacePair getClass(Class concrete, Class iface, Class c) {
/* 531 */     Type[] gis = c.getGenericInterfaces();
/* 532 */     DeclaringClassInterfacePair p = getType(concrete, iface, c, gis);
/* 533 */     if (p != null) {
/* 534 */       return p;
/*     */     }
/* 536 */     c = c.getSuperclass();
/* 537 */     if ((c == null) || (c == Object.class)) {
/* 538 */       return null;
/*     */     }
/* 540 */     return getClass(concrete, iface, c);
/*     */   }
/*     */   
/*     */   private static DeclaringClassInterfacePair getType(Class concrete, Class iface, Class c, Type[] ts) {
/* 544 */     for (Type t : ts) {
/* 545 */       DeclaringClassInterfacePair p = getType(concrete, iface, c, t);
/* 546 */       if (p != null)
/* 547 */         return p;
/*     */     }
/* 549 */     return null;
/*     */   }
/*     */   
/*     */   private static DeclaringClassInterfacePair getType(Class concrete, Class iface, Class c, Type t) {
/* 553 */     if ((t instanceof Class)) {
/* 554 */       if (t == iface) {
/* 555 */         return new DeclaringClassInterfacePair(concrete, c, t, null);
/*     */       }
/* 557 */       return getClass(concrete, iface, (Class)t);
/*     */     }
/* 559 */     if ((t instanceof ParameterizedType)) {
/* 560 */       ParameterizedType pt = (ParameterizedType)t;
/* 561 */       if (pt.getRawType() == iface) {
/* 562 */         return new DeclaringClassInterfacePair(concrete, c, t, null);
/*     */       }
/* 564 */       return getClass(concrete, iface, (Class)pt.getRawType());
/*     */     }
/*     */     
/* 567 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class ClassTypePair
/*     */   {
/*     */     public final Class c;
/*     */     
/*     */ 
/*     */ 
/*     */     public final Type t;
/*     */     
/*     */ 
/*     */ 
/*     */     public ClassTypePair(Class c)
/*     */     {
/* 585 */       this(c, c);
/*     */     }
/*     */     
/*     */     public ClassTypePair(Class c, Type t) {
/* 589 */       this.c = c;
/* 590 */       this.t = t;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ClassTypePair resolveTypeVariable(Class c, Class dc, TypeVariable tv)
/*     */   {
/* 604 */     return resolveTypeVariable(c, dc, tv, new HashMap());
/*     */   }
/*     */   
/*     */   private static ClassTypePair resolveTypeVariable(Class c, Class dc, TypeVariable tv, Map<TypeVariable, Type> map)
/*     */   {
/* 609 */     Type[] gis = c.getGenericInterfaces();
/* 610 */     for (Type gi : gis) {
/* 611 */       if ((gi instanceof ParameterizedType))
/*     */       {
/* 613 */         ParameterizedType pt = (ParameterizedType)gi;
/* 614 */         ClassTypePair ctp = resolveTypeVariable(pt, (Class)pt.getRawType(), dc, tv, map);
/* 615 */         if (ctp != null) {
/* 616 */           return ctp;
/*     */         }
/*     */       }
/*     */     }
/* 620 */     Type gsc = c.getGenericSuperclass();
/* 621 */     if ((gsc instanceof ParameterizedType))
/*     */     {
/* 623 */       ParameterizedType pt = (ParameterizedType)gsc;
/* 624 */       return resolveTypeVariable(pt, c.getSuperclass(), dc, tv, map); }
/* 625 */     if ((gsc instanceof Class)) {
/* 626 */       return resolveTypeVariable(c.getSuperclass(), dc, tv, map);
/*     */     }
/* 628 */     return null;
/*     */   }
/*     */   
/*     */   private static ClassTypePair resolveTypeVariable(ParameterizedType pt, Class c, Class dc, TypeVariable tv, Map<TypeVariable, Type> map)
/*     */   {
/* 633 */     Type[] typeArguments = pt.getActualTypeArguments();
/*     */     
/* 635 */     TypeVariable[] typeParameters = c.getTypeParameters();
/*     */     
/* 637 */     Map<TypeVariable, Type> submap = new HashMap();
/* 638 */     for (int i = 0; i < typeArguments.length; i++)
/*     */     {
/* 640 */       if ((typeArguments[i] instanceof TypeVariable)) {
/* 641 */         Type t = (Type)map.get(typeArguments[i]);
/* 642 */         submap.put(typeParameters[i], t);
/*     */       } else {
/* 644 */         submap.put(typeParameters[i], typeArguments[i]);
/*     */       }
/*     */     }
/*     */     
/* 648 */     if (c == dc) {
/* 649 */       Type t = (Type)submap.get(tv);
/* 650 */       if ((t instanceof Class))
/* 651 */         return new ClassTypePair((Class)t);
/* 652 */       if ((t instanceof GenericArrayType)) {
/* 653 */         t = ((GenericArrayType)t).getGenericComponentType();
/* 654 */         if ((t instanceof Class)) {
/* 655 */           c = (Class)t;
/*     */           try {
/* 657 */             return new ClassTypePair(getArrayClass(c));
/*     */           }
/*     */           catch (Exception e) {
/* 660 */             return null; } }
/* 661 */         if ((t instanceof ParameterizedType)) {
/* 662 */           Type rt = ((ParameterizedType)t).getRawType();
/* 663 */           if ((rt instanceof Class)) {
/* 664 */             c = (Class)rt;
/*     */           } else {
/* 666 */             return null;
/*     */           }
/*     */           try {
/* 669 */             return new ClassTypePair(getArrayClass(c), t);
/*     */           } catch (Exception e) {
/* 671 */             return null;
/*     */           }
/*     */         }
/* 674 */         return null;
/*     */       }
/* 676 */       if ((t instanceof ParameterizedType)) {
/* 677 */         pt = (ParameterizedType)t;
/* 678 */         if ((pt.getRawType() instanceof Class)) {
/* 679 */           return new ClassTypePair((Class)pt.getRawType(), pt);
/*     */         }
/* 681 */         return null;
/*     */       }
/* 683 */       return null;
/*     */     }
/*     */     
/* 686 */     return resolveTypeVariable(c, dc, tv, submap);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Method findMethodOnClass(Class c, Method m)
/*     */   {
/*     */     try
/*     */     {
/* 710 */       return c.getMethod(m.getName(), m.getParameterTypes());
/*     */     } catch (NoSuchMethodException ex) {
/* 712 */       for (Method _m : c.getMethods()) {
/* 713 */         if ((_m.getName().equals(m.getName())) && (_m.getParameterTypes().length == m.getParameterTypes().length))
/*     */         {
/* 715 */           if (compareParameterTypes(m.getGenericParameterTypes(), _m.getGenericParameterTypes()))
/*     */           {
/* 717 */             return _m;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 722 */     return null;
/*     */   }
/*     */   
/*     */   private static boolean compareParameterTypes(Type[] ts, Type[] _ts) {
/* 726 */     for (int i = 0; i < ts.length; i++) {
/* 727 */       if ((!ts[i].equals(_ts[i])) && 
/* 728 */         (!(_ts[i] instanceof TypeVariable))) {
/* 729 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 733 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\reflection\ReflectionHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */