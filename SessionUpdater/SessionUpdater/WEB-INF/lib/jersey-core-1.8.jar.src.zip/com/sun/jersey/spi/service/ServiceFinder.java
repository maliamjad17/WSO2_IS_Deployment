/*      */ package com.sun.jersey.spi.service;
/*      */ 
/*      */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*      */ import com.sun.jersey.impl.SpiMessages;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.ReflectPermission;
/*      */ import java.net.URL;
/*      */ import java.net.URLConnection;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.ListIterator;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Set;
/*      */ import java.util.TreeSet;
/*      */ import java.util.jar.Attributes;
/*      */ import java.util.jar.Manifest;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ServiceFinder<T>
/*      */   implements Iterable<T>
/*      */ {
/*  160 */   private static final Logger LOGGER = Logger.getLogger(ServiceFinder.class.getName());
/*      */   
/*      */   private static final String MANIFEST = "META-INF/MANIFEST.MF";
/*      */   
/*      */   private static final String MODULE_VERSION = "META-INF/jersey-module-version";
/*      */   
/*      */   private static final String PREFIX = "META-INF/services/";
/*      */   
/*      */   private static final String BUNDLE_VERSION_ATTRIBUTE = "Bundle-Version";
/*      */   
/*      */   private static final String BUNDLE_SYMBOLIC_NAME_ATTRIBUTE = "Bundle-SymbolicName";
/*      */   
/*  172 */   private static final String BUNDLE_VERSION = getBundleAttribute("Bundle-Version");
/*      */   
/*  174 */   private static final String BUNDLE_SYMBOLIC_NAME = getBundleAttribute("Bundle-SymbolicName");
/*      */   
/*  176 */   private static final String MODULE_VERSION_VALUE = getModuleVersion();
/*      */   private final Class<T> serviceClass;
/*      */   private final String serviceName;
/*      */   private final ClassLoader classLoader;
/*      */   private final boolean ignoreOnClassNotFound;
/*      */   
/*      */   private static String getBundleAttribute(String attributeName)
/*      */   {
/*      */     try {
/*  185 */       String version = getManifest(ServiceFinder.class).getMainAttributes().getValue(attributeName);
/*      */       
/*      */ 
/*  188 */       if (LOGGER.isLoggable(Level.FINE)) {
/*  189 */         LOGGER.fine("ServiceFinder " + attributeName + ": " + version);
/*      */       }
/*  191 */       return version;
/*      */     } catch (IOException ex) {
/*  193 */       LOGGER.log(Level.FINE, "Error loading META-INF/MANIFEST.MF associated with " + ServiceFinder.class.getName(), ex); }
/*  194 */     return null;
/*      */   }
/*      */   
/*      */   private static String getModuleVersion()
/*      */   {
/*      */     try {
/*  200 */       String resource = ServiceFinder.class.getName().replace(".", "/") + ".class";
/*  201 */       URL url = getResource(ServiceFinder.class.getClassLoader(), resource);
/*  202 */       if (url == null) {
/*  203 */         LOGGER.log(Level.FINE, "Error getting " + ServiceFinder.class.getName() + " class as a resource");
/*  204 */         return null;
/*      */       }
/*      */       
/*  207 */       return getJerseyModuleVersion(getManifestURL(resource, url));
/*      */     } catch (IOException ioe) {
/*  209 */       LOGGER.log(Level.FINE, "Error loading META-INF/jersey-module-version associated with " + ServiceFinder.class.getName(), ioe); }
/*  210 */     return null;
/*      */   }
/*      */   
/*      */ 
/*  214 */   private static final Map<URL, Boolean> manifestURLs = new HashMap();
/*      */   
/*      */   private static Enumeration<URL> filterServiceURLsWithVersion(String serviceName, Enumeration<URL> serviceUrls) {
/*  217 */     if ((BUNDLE_VERSION == null) || (!serviceUrls.hasMoreElements())) {
/*  218 */       return serviceUrls;
/*      */     }
/*  220 */     List<URL> urls = Collections.list(serviceUrls);
/*  221 */     ListIterator<URL> li = urls.listIterator();
/*  222 */     while (li.hasNext()) {
/*  223 */       URL url = (URL)li.next();
/*      */       try {
/*  225 */         URL manifestURL = getManifestURL(serviceName, url);
/*      */         
/*  227 */         synchronized (manifestURLs) {
/*  228 */           Boolean keep = (Boolean)manifestURLs.get(manifestURL);
/*  229 */           if (keep != null) {
/*  230 */             if (!keep.booleanValue()) {
/*  231 */               if (LOGGER.isLoggable(Level.CONFIG)) {
/*  232 */                 LOGGER.config("Ignoring service URL: " + url);
/*      */               }
/*  234 */               li.remove();
/*      */             }
/*  236 */             else if (LOGGER.isLoggable(Level.FINE)) {
/*  237 */               LOGGER.fine("Including service URL: " + url);
/*      */             }
/*      */             
/*      */           }
/*  241 */           else if (!compatibleManifest(manifestURL)) {
/*  242 */             if (LOGGER.isLoggable(Level.CONFIG)) {
/*  243 */               LOGGER.config("Ignoring service URL: " + url);
/*      */             }
/*  245 */             li.remove();
/*  246 */             manifestURLs.put(manifestURL, Boolean.valueOf(false));
/*      */           } else {
/*  248 */             if (LOGGER.isLoggable(Level.FINE)) {
/*  249 */               LOGGER.fine("Including service URL: " + url);
/*      */             }
/*  251 */             manifestURLs.put(manifestURL, Boolean.valueOf(true));
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (IOException ex) {
/*  256 */         LOGGER.log(Level.FINE, "Error loading META-INF/MANIFEST.MF associated with " + url, ex);
/*      */       }
/*      */     }
/*  259 */     return Collections.enumeration(urls);
/*      */   }
/*      */   
/*      */   private static boolean compatibleManifest(URL manifestURL) throws IOException {
/*  263 */     Attributes as = getManifest(manifestURL).getMainAttributes();
/*  264 */     String symbolicName = as.getValue("Bundle-SymbolicName");
/*  265 */     String version = as.getValue("Bundle-Version");
/*      */     
/*  267 */     if (LOGGER.isLoggable(Level.FINE)) {
/*  268 */       LOGGER.fine("Checking META-INF/MANIFEST.MF URL: " + manifestURL + "\n  " + "Bundle-SymbolicName" + ": " + symbolicName + "\n  " + "Bundle-Version" + ": " + version);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  273 */     if ((symbolicName != null) && (symbolicName.startsWith("com.sun.jersey")) && (!BUNDLE_VERSION.equals(version)))
/*      */     {
/*      */ 
/*  276 */       return false;
/*      */     }
/*  278 */     String moduleVersion = getJerseyModuleVersion(manifestURL);
/*      */     
/*  280 */     if ((moduleVersion != null) && ((!moduleVersion.equals(MODULE_VERSION_VALUE)) || ((symbolicName != null) && ((BUNDLE_SYMBOLIC_NAME.startsWith("com.sun.jersey") ^ symbolicName.startsWith("com.sun.jersey"))))))
/*      */     {
/*      */ 
/*      */ 
/*  284 */       return false;
/*      */     }
/*      */     
/*  287 */     return true;
/*      */   }
/*      */   
/*      */   private static String getJerseyModuleVersion(URL manifestURL)
/*      */   {
/*      */     try {
/*  293 */       URL moduleVersionURL = new URL(manifestURL.toString().replace("META-INF/MANIFEST.MF", "META-INF/jersey-module-version"));
/*      */       
/*  295 */       return new BufferedReader(new InputStreamReader(moduleVersionURL.openStream())).readLine();
/*      */     } catch (IOException ioe) {
/*  297 */       LOGGER.log(Level.FINE, "Error loading META-INF/jersey-module-version associated with " + ServiceFinder.class.getName(), ioe); }
/*  298 */     return null;
/*      */   }
/*      */   
/*      */   private static Manifest getManifest(Class c) throws IOException
/*      */   {
/*  303 */     String resource = c.getName().replace(".", "/") + ".class";
/*  304 */     URL url = getResource(c.getClassLoader(), resource);
/*  305 */     if (url == null) {
/*  306 */       throw new IOException("Resource not found: " + url);
/*      */     }
/*  308 */     return getManifest(resource, url);
/*      */   }
/*      */   
/*      */   private static Manifest getManifest(String name, URL serviceURL) throws IOException {
/*  312 */     return getManifest(getManifestURL(name, serviceURL));
/*      */   }
/*      */   
/*      */   private static URL getManifestURL(String name, URL serviceURL) throws IOException {
/*  316 */     return new URL(serviceURL.toString().replace(name, "META-INF/MANIFEST.MF"));
/*      */   }
/*      */   
/*      */   private static Manifest getManifest(URL url) throws IOException {
/*  320 */     InputStream in = url.openStream();
/*      */     try {
/*  322 */       return new Manifest(in);
/*      */     } finally {
/*  324 */       in.close();
/*      */     }
/*      */   }
/*      */   
/*      */   private static URL getResource(ClassLoader loader, String name) throws IOException {
/*  329 */     if (loader == null) {
/*  330 */       return getResource(name);
/*      */     }
/*  332 */     URL resource = loader.getResource(name);
/*  333 */     if (resource != null) {
/*  334 */       return resource;
/*      */     }
/*  336 */     return getResource(name);
/*      */   }
/*      */   
/*      */   private static URL getResource(String name)
/*      */     throws IOException
/*      */   {
/*  342 */     if (ServiceFinder.class.getClassLoader() != null) {
/*  343 */       return ServiceFinder.class.getClassLoader().getResource(name);
/*      */     }
/*  345 */     return ClassLoader.getSystemResource(name);
/*      */   }
/*      */   
/*      */   private static Enumeration<URL> getResources(ClassLoader loader, String name) throws IOException {
/*  349 */     if (loader == null) {
/*  350 */       return getResources(name);
/*      */     }
/*  352 */     Enumeration<URL> resources = loader.getResources(name);
/*  353 */     if (resources.hasMoreElements()) {
/*  354 */       return resources;
/*      */     }
/*  356 */     return getResources(name);
/*      */   }
/*      */   
/*      */   private static Enumeration<URL> getResources(String name)
/*      */     throws IOException
/*      */   {
/*  362 */     if (ServiceFinder.class.getClassLoader() != null) {
/*  363 */       return ServiceFinder.class.getClassLoader().getResources(name);
/*      */     }
/*  365 */     return ClassLoader.getSystemResources(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <T> ServiceFinder<T> find(Class<T> service, ClassLoader loader)
/*      */     throws ServiceConfigurationError
/*      */   {
/*  396 */     return find(service, loader, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <T> ServiceFinder<T> find(Class<T> service, ClassLoader loader, boolean ignoreOnClassNotFound)
/*      */     throws ServiceConfigurationError
/*      */   {
/*  432 */     return new ServiceFinder(service, loader, ignoreOnClassNotFound);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <T> ServiceFinder<T> find(Class<T> service)
/*      */     throws ServiceConfigurationError
/*      */   {
/*  455 */     return find(service, Thread.currentThread().getContextClassLoader(), false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <T> ServiceFinder<T> find(Class<T> service, boolean ignoreOnClassNotFound)
/*      */     throws ServiceConfigurationError
/*      */   {
/*  481 */     return find(service, Thread.currentThread().getContextClassLoader(), ignoreOnClassNotFound);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ServiceFinder<?> find(String serviceName)
/*      */     throws ServiceConfigurationError
/*      */   {
/*  498 */     return new ServiceFinder(Object.class, serviceName, Thread.currentThread().getContextClassLoader(), false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void setIteratorProvider(ServiceIteratorProvider sip)
/*      */     throws SecurityException
/*      */   {
/*  515 */     ServiceIteratorProvider.setInstance(sip);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ServiceFinder(Class<T> service, ClassLoader loader, boolean ignoreOnClassNotFound)
/*      */   {
/*  523 */     this(service, service.getName(), loader, ignoreOnClassNotFound);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ServiceFinder(Class<T> service, String serviceName, ClassLoader loader, boolean ignoreOnClassNotFound)
/*      */   {
/*  531 */     this.serviceClass = service;
/*  532 */     this.serviceName = serviceName;
/*  533 */     this.classLoader = loader;
/*  534 */     this.ignoreOnClassNotFound = ignoreOnClassNotFound;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Iterator<T> iterator()
/*      */   {
/*  547 */     return ServiceIteratorProvider.access$100().createIterator(this.serviceClass, this.serviceName, this.classLoader, this.ignoreOnClassNotFound);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Iterator<Class<T>> classIterator()
/*      */   {
/*  560 */     return ServiceIteratorProvider.access$100().createClassIterator(this.serviceClass, this.serviceName, this.classLoader, this.ignoreOnClassNotFound);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public T[] toArray()
/*      */     throws ServiceConfigurationError
/*      */   {
/*  574 */     List<T> result = new ArrayList();
/*  575 */     for (T t : this) {
/*  576 */       result.add(t);
/*      */     }
/*  578 */     return result.toArray((Object[])Array.newInstance(this.serviceClass, result.size()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Class<T>[] toClassArray()
/*      */     throws ServiceConfigurationError
/*      */   {
/*  592 */     List<Class<T>> result = new ArrayList();
/*      */     
/*  594 */     Iterator<Class<T>> i = classIterator();
/*  595 */     while (i.hasNext())
/*  596 */       result.add(i.next());
/*  597 */     return (Class[])result.toArray((Class[])Array.newInstance(Class.class, result.size()));
/*      */   }
/*      */   
/*      */   private static void fail(String serviceName, String msg, Throwable cause) throws ServiceConfigurationError
/*      */   {
/*  602 */     ServiceConfigurationError sce = new ServiceConfigurationError(serviceName + ": " + msg);
/*      */     
/*  604 */     sce.initCause(cause);
/*  605 */     throw sce;
/*      */   }
/*      */   
/*      */   private static void fail(String serviceName, String msg) throws ServiceConfigurationError
/*      */   {
/*  610 */     throw new ServiceConfigurationError(serviceName + ": " + msg);
/*      */   }
/*      */   
/*      */   private static void fail(String serviceName, URL u, int line, String msg) throws ServiceConfigurationError
/*      */   {
/*  615 */     fail(serviceName, u + ":" + line + ": " + msg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static int parseLine(String serviceName, URL u, BufferedReader r, int lc, List<String> names, Set<String> returned)
/*      */     throws IOException, ServiceConfigurationError
/*      */   {
/*  626 */     String ln = r.readLine();
/*  627 */     if (ln == null) {
/*  628 */       return -1;
/*      */     }
/*  630 */     int ci = ln.indexOf('#');
/*  631 */     if (ci >= 0) ln = ln.substring(0, ci);
/*  632 */     ln = ln.trim();
/*  633 */     int n = ln.length();
/*  634 */     if (n != 0) {
/*  635 */       if ((ln.indexOf(' ') >= 0) || (ln.indexOf('\t') >= 0))
/*  636 */         fail(serviceName, u, lc, SpiMessages.ILLEGAL_CONFIG_SYNTAX());
/*  637 */       int cp = ln.codePointAt(0);
/*  638 */       if (!Character.isJavaIdentifierStart(cp))
/*  639 */         fail(serviceName, u, lc, SpiMessages.ILLEGAL_PROVIDER_CLASS_NAME(ln));
/*  640 */       for (int i = Character.charCount(cp); i < n; i += Character.charCount(cp)) {
/*  641 */         cp = ln.codePointAt(i);
/*  642 */         if ((!Character.isJavaIdentifierPart(cp)) && (cp != 46))
/*  643 */           fail(serviceName, u, lc, SpiMessages.ILLEGAL_PROVIDER_CLASS_NAME(ln));
/*      */       }
/*  645 */       if (!returned.contains(ln)) {
/*  646 */         names.add(ln);
/*  647 */         returned.add(ln);
/*      */       }
/*      */     }
/*  650 */     return lc + 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static Iterator<String> parse(String serviceName, URL u, Set<String> returned)
/*      */     throws ServiceConfigurationError
/*      */   {
/*  671 */     InputStream in = null;
/*  672 */     BufferedReader r = null;
/*  673 */     names = new ArrayList();
/*      */     try {
/*  675 */       URLConnection uConn = u.openConnection();
/*  676 */       uConn.setUseCaches(false);
/*  677 */       in = uConn.getInputStream();
/*  678 */       r = new BufferedReader(new InputStreamReader(in, "utf-8"));
/*  679 */       int lc = 1;
/*  680 */       while ((lc = parseLine(serviceName, u, r, lc, names, returned)) >= 0) {}
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  691 */       return names.iterator();
/*      */     }
/*      */     catch (IOException x)
/*      */     {
/*  682 */       fail(serviceName, ": " + x);
/*      */     } finally {
/*      */       try {
/*  685 */         if (r != null) r.close();
/*  686 */         if (in != null) in.close();
/*      */       } catch (IOException y) {
/*  688 */         fail(serviceName, ": " + y);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static class AbstractLazyIterator<T>
/*      */   {
/*      */     final Class<T> service;
/*      */     final String serviceName;
/*      */     final ClassLoader loader;
/*      */     final boolean ignoreOnClassNotFound;
/*  700 */     Enumeration<URL> configs = null;
/*  701 */     Iterator<String> pending = null;
/*  702 */     Set<String> returned = new TreeSet();
/*  703 */     String nextName = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private AbstractLazyIterator(Class<T> service, String serviceName, ClassLoader loader, boolean ignoreOnClassNotFound)
/*      */     {
/*  710 */       this.service = service;
/*  711 */       this.serviceName = serviceName;
/*  712 */       this.loader = loader;
/*  713 */       this.ignoreOnClassNotFound = ignoreOnClassNotFound;
/*      */     }
/*      */     
/*      */     protected final void setConfigs() {
/*  717 */       if (this.configs == null) {
/*      */         try {
/*  719 */           String fullName = "META-INF/services/" + this.serviceName;
/*  720 */           this.configs = ServiceFinder.filterServiceURLsWithVersion(fullName, ServiceFinder.access$200(this.loader, fullName));
/*      */         }
/*      */         catch (IOException x) {
/*  723 */           ServiceFinder.fail(this.serviceName, ": " + x);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean hasNext() throws ServiceConfigurationError {
/*  729 */       if (this.nextName != null) {
/*  730 */         return true;
/*      */       }
/*  732 */       setConfigs();
/*      */       
/*  734 */       while (this.nextName == null) {
/*  735 */         while ((this.pending == null) || (!this.pending.hasNext())) {
/*  736 */           if (!this.configs.hasMoreElements()) {
/*  737 */             return false;
/*      */           }
/*  739 */           this.pending = ServiceFinder.parse(this.serviceName, (URL)this.configs.nextElement(), this.returned);
/*      */         }
/*  741 */         this.nextName = ((String)this.pending.next());
/*  742 */         if (this.ignoreOnClassNotFound) {
/*      */           try {
/*  744 */             ReflectionHelper.classForNameWithException(this.nextName, this.loader);
/*      */           }
/*      */           catch (ClassNotFoundException ex) {
/*  747 */             if (ServiceFinder.LOGGER.isLoggable(Level.CONFIG)) {
/*  748 */               ServiceFinder.LOGGER.log(Level.CONFIG, SpiMessages.PROVIDER_NOT_FOUND(this.nextName, this.service));
/*      */             }
/*      */             
/*  751 */             this.nextName = null;
/*      */           }
/*      */           catch (NoClassDefFoundError ex) {
/*  754 */             if (ServiceFinder.LOGGER.isLoggable(Level.CONFIG))
/*      */             {
/*      */ 
/*  757 */               ServiceFinder.LOGGER.log(Level.CONFIG, SpiMessages.DEPENDENT_CLASS_OF_PROVIDER_NOT_FOUND(ex.getLocalizedMessage(), this.nextName, this.service));
/*      */             }
/*      */             
/*      */ 
/*  761 */             this.nextName = null;
/*      */           }
/*      */           catch (ClassFormatError ex) {
/*  764 */             if (ServiceFinder.LOGGER.isLoggable(Level.CONFIG)) {
/*  765 */               ServiceFinder.LOGGER.log(Level.CONFIG, SpiMessages.DEPENDENT_CLASS_OF_PROVIDER_FORMAT_ERROR(ex.getLocalizedMessage(), this.nextName, this.service));
/*      */             }
/*      */             
/*      */ 
/*  769 */             this.nextName = null;
/*      */           }
/*      */         }
/*      */       }
/*  773 */       return true;
/*      */     }
/*      */     
/*      */     public void remove() {
/*  777 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static final class LazyClassIterator<T>
/*      */     extends ServiceFinder.AbstractLazyIterator<T>
/*      */     implements Iterator<Class<T>>
/*      */   {
/*      */     private LazyClassIterator(Class<T> service, String serviceName, ClassLoader loader, boolean ignoreOnClassNotFound)
/*      */     {
/*  789 */       super(serviceName, loader, ignoreOnClassNotFound, null);
/*      */     }
/*      */     
/*      */     public Class<T> next()
/*      */     {
/*  794 */       if (!hasNext()) {
/*  795 */         throw new NoSuchElementException();
/*      */       }
/*  797 */       String cn = this.nextName;
/*  798 */       this.nextName = null;
/*      */       try {
/*  800 */         return ReflectionHelper.classForNameWithException(cn, this.loader);
/*      */       } catch (ClassNotFoundException ex) {
/*  802 */         ServiceFinder.fail(this.serviceName, SpiMessages.PROVIDER_NOT_FOUND(cn, this.service));
/*      */       }
/*      */       catch (NoClassDefFoundError ex) {
/*  805 */         ServiceFinder.fail(this.serviceName, SpiMessages.DEPENDENT_CLASS_OF_PROVIDER_NOT_FOUND(ex.getLocalizedMessage(), cn, this.service));
/*      */       }
/*      */       catch (ClassFormatError ex)
/*      */       {
/*  809 */         ServiceFinder.fail(this.serviceName, SpiMessages.DEPENDENT_CLASS_OF_PROVIDER_FORMAT_ERROR(ex.getLocalizedMessage(), cn, this.service));
/*      */       }
/*      */       catch (Exception x)
/*      */       {
/*  813 */         ServiceFinder.fail(this.serviceName, SpiMessages.PROVIDER_CLASS_COULD_NOT_BE_LOADED(cn, this.service, x.getLocalizedMessage()), x);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  818 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static final class LazyObjectIterator<T>
/*      */     extends ServiceFinder.AbstractLazyIterator<T>
/*      */     implements Iterator<T>
/*      */   {
/*      */     private T t;
/*      */     
/*      */ 
/*      */     private LazyObjectIterator(Class<T> service, String serviceName, ClassLoader loader, boolean ignoreOnClassNotFound)
/*      */     {
/*  832 */       super(serviceName, loader, ignoreOnClassNotFound, null);
/*      */     }
/*      */     
/*      */     public boolean hasNext() throws ServiceConfigurationError
/*      */     {
/*  837 */       if (this.nextName != null) {
/*  838 */         return true;
/*      */       }
/*  840 */       setConfigs();
/*      */       
/*  842 */       while (this.nextName == null) {
/*  843 */         while ((this.pending == null) || (!this.pending.hasNext())) {
/*  844 */           if (!this.configs.hasMoreElements()) {
/*  845 */             return false;
/*      */           }
/*  847 */           this.pending = ServiceFinder.parse(this.serviceName, (URL)this.configs.nextElement(), this.returned);
/*      */         }
/*  849 */         this.nextName = ((String)this.pending.next());
/*      */         try {
/*  851 */           this.t = this.service.cast(ReflectionHelper.classForNameWithException(this.nextName, this.loader).newInstance());
/*      */         } catch (ClassNotFoundException ex) {
/*  853 */           if (this.ignoreOnClassNotFound)
/*      */           {
/*  855 */             if (ServiceFinder.LOGGER.isLoggable(Level.WARNING)) {
/*  856 */               ServiceFinder.LOGGER.log(Level.WARNING, SpiMessages.PROVIDER_NOT_FOUND(this.nextName, this.service));
/*      */             }
/*      */             
/*  859 */             this.nextName = null;
/*      */           } else {
/*  861 */             ServiceFinder.fail(this.serviceName, SpiMessages.PROVIDER_NOT_FOUND(this.nextName, this.service));
/*      */           }
/*      */         }
/*      */         catch (NoClassDefFoundError ex) {
/*  865 */           if (this.ignoreOnClassNotFound) {
/*  866 */             if (ServiceFinder.LOGGER.isLoggable(Level.CONFIG))
/*      */             {
/*      */ 
/*  869 */               ServiceFinder.LOGGER.log(Level.CONFIG, SpiMessages.DEPENDENT_CLASS_OF_PROVIDER_NOT_FOUND(ex.getLocalizedMessage(), this.nextName, this.service));
/*      */             }
/*      */             
/*      */ 
/*  873 */             this.nextName = null;
/*      */           } else {
/*  875 */             ServiceFinder.fail(this.serviceName, SpiMessages.DEPENDENT_CLASS_OF_PROVIDER_NOT_FOUND(ex.getLocalizedMessage(), this.nextName, this.service), ex);
/*      */           }
/*      */         }
/*      */         catch (ClassFormatError ex)
/*      */         {
/*  880 */           if (this.ignoreOnClassNotFound) {
/*  881 */             if (ServiceFinder.LOGGER.isLoggable(Level.CONFIG)) {
/*  882 */               ServiceFinder.LOGGER.log(Level.CONFIG, SpiMessages.DEPENDENT_CLASS_OF_PROVIDER_FORMAT_ERROR(ex.getLocalizedMessage(), this.nextName, this.service));
/*      */             }
/*      */             
/*      */ 
/*  886 */             this.nextName = null;
/*      */           } else {
/*  888 */             ServiceFinder.fail(this.serviceName, SpiMessages.DEPENDENT_CLASS_OF_PROVIDER_FORMAT_ERROR(ex.getLocalizedMessage(), this.nextName, this.service), ex);
/*      */           }
/*      */         }
/*      */         catch (Exception ex) {
/*  892 */           ServiceFinder.fail(this.serviceName, SpiMessages.PROVIDER_COULD_NOT_BE_CREATED(this.nextName, this.service, ex.getLocalizedMessage()), ex);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  897 */       return true;
/*      */     }
/*      */     
/*      */     public T next() {
/*  901 */       if (!hasNext()) {
/*  902 */         throw new NoSuchElementException();
/*      */       }
/*  904 */       String cn = this.nextName;
/*  905 */       this.nextName = null;
/*  906 */       return (T)this.t;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static abstract class ServiceIteratorProvider<T>
/*      */   {
/*      */     private static volatile ServiceIteratorProvider sip;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private static ServiceIteratorProvider getInstance()
/*      */     {
/*  926 */       ServiceIteratorProvider result = sip;
/*  927 */       if (result == null) {
/*  928 */         synchronized (ServiceIteratorProvider.class) {
/*  929 */           result = sip;
/*  930 */           if (result == null) {
/*  931 */             sip = result = new ServiceFinder.DefaultServiceIteratorProvider();
/*      */           }
/*      */         }
/*      */       }
/*  935 */       return result;
/*      */     }
/*      */     
/*      */     private static void setInstance(ServiceIteratorProvider sip) throws SecurityException {
/*  939 */       SecurityManager security = System.getSecurityManager();
/*  940 */       if (security != null) {
/*  941 */         ReflectPermission rp = new ReflectPermission("suppressAccessChecks");
/*  942 */         security.checkPermission(rp);
/*      */       }
/*  944 */       synchronized (ServiceIteratorProvider.class) {
/*  945 */         sip = sip;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public abstract Iterator<T> createIterator(Class<T> paramClass, String paramString, ClassLoader paramClassLoader, boolean paramBoolean);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public abstract Iterator<Class<T>> createClassIterator(Class<T> paramClass, String paramString, ClassLoader paramClassLoader, boolean paramBoolean);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final class DefaultServiceIteratorProvider<T>
/*      */     extends ServiceFinder.ServiceIteratorProvider<T>
/*      */   {
/*      */     public Iterator<T> createIterator(Class<T> service, String serviceName, ClassLoader loader, boolean ignoreOnClassNotFound)
/*      */     {
/*  995 */       return new ServiceFinder.LazyObjectIterator(service, serviceName, loader, ignoreOnClassNotFound, null);
/*      */     }
/*      */     
/*      */ 
/*      */     public Iterator<Class<T>> createClassIterator(Class<T> service, String serviceName, ClassLoader loader, boolean ignoreOnClassNotFound)
/*      */     {
/* 1001 */       return new ServiceFinder.LazyClassIterator(service, serviceName, loader, ignoreOnClassNotFound, null);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\spi\service\ServiceFinder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */