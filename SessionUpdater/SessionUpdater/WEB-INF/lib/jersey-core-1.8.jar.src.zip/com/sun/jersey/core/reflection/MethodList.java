/*     */ package com.sun.jersey.core.reflection;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodList
/*     */   implements Iterable<AnnotatedMethod>
/*     */ {
/*     */   private AnnotatedMethod[] methods;
/*     */   
/*     */   public MethodList(Class c)
/*     */   {
/*  60 */     this(c, false);
/*     */   }
/*     */   
/*     */   public MethodList(Class c, boolean declaredMethods) {
/*  64 */     this(declaredMethods ? getAllDeclaredMethods(c) : getMethods(c));
/*     */   }
/*     */   
/*     */   private static List<Method> getAllDeclaredMethods(Class c) {
/*  68 */     List<Method> l = new ArrayList();
/*  69 */     while ((c != null) && (c != Object.class)) {
/*  70 */       l.addAll(Arrays.asList(c.getDeclaredMethods()));
/*  71 */       c = c.getSuperclass();
/*     */     }
/*  73 */     return l;
/*     */   }
/*     */   
/*     */   private static List<Method> getMethods(Class c) {
/*  77 */     return Arrays.asList(c.getMethods());
/*     */   }
/*     */   
/*     */   public MethodList(List<Method> methods) {
/*  81 */     List<AnnotatedMethod> l = new ArrayList();
/*  82 */     for (Method m : methods) {
/*  83 */       if ((!m.isBridge()) && (m.getDeclaringClass() != Object.class)) {
/*  84 */         l.add(new AnnotatedMethod(m));
/*     */       }
/*     */     }
/*  87 */     this.methods = new AnnotatedMethod[l.size()];
/*  88 */     this.methods = ((AnnotatedMethod[])l.toArray(this.methods));
/*     */   }
/*     */   
/*     */   public MethodList(Method... methods) {
/*  92 */     List<AnnotatedMethod> l = new ArrayList();
/*  93 */     for (Method m : methods) {
/*  94 */       if ((!m.isBridge()) && (m.getDeclaringClass() != Object.class)) {
/*  95 */         l.add(new AnnotatedMethod(m));
/*     */       }
/*     */     }
/*  98 */     this.methods = new AnnotatedMethod[l.size()];
/*  99 */     this.methods = ((AnnotatedMethod[])l.toArray(this.methods));
/*     */   }
/*     */   
/*     */   public MethodList(AnnotatedMethod... methods) {
/* 103 */     this.methods = methods;
/*     */   }
/*     */   
/*     */   public Iterator<AnnotatedMethod> iterator() {
/* 107 */     return Arrays.asList(this.methods).iterator();
/*     */   }
/*     */   
/*     */   public <T extends Annotation> MethodList isNotPublic() {
/* 111 */     filter(new Filter() {
/*     */       public boolean keep(AnnotatedMethod m) {
/* 113 */         return !Modifier.isPublic(m.getMethod().getModifiers());
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public <T extends Annotation> MethodList hasNumParams(final int i) {
/* 119 */     filter(new Filter() {
/*     */       public boolean keep(AnnotatedMethod m) {
/* 121 */         return m.getParameterTypes().length == i;
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public <T extends Annotation> MethodList hasReturnType(final Class<?> r) {
/* 127 */     filter(new Filter() {
/*     */       public boolean keep(AnnotatedMethod m) {
/* 129 */         return m.getMethod().getReturnType() == r;
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public <T extends Annotation> MethodList nameStartsWith(final String s) {
/* 135 */     filter(new Filter() {
/*     */       public boolean keep(AnnotatedMethod m) {
/* 137 */         return m.getMethod().getName().startsWith(s);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public <T extends Annotation> MethodList hasAnnotation(final Class<T> annotation) {
/* 143 */     filter(new Filter() {
/*     */       public boolean keep(AnnotatedMethod m) {
/* 145 */         return m.getAnnotation(annotation) != null;
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public <T extends Annotation> MethodList hasMetaAnnotation(final Class<T> annotation) {
/* 151 */     filter(new Filter() {
/*     */       public boolean keep(AnnotatedMethod m) {
/* 153 */         for (Annotation a : m.getAnnotations()) {
/* 154 */           if (a.annotationType().getAnnotation(annotation) != null)
/* 155 */             return true;
/*     */         }
/* 157 */         return false;
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public <T extends Annotation> MethodList hasNotAnnotation(final Class<T> annotation) {
/* 163 */     filter(new Filter() {
/*     */       public boolean keep(AnnotatedMethod m) {
/* 165 */         return m.getAnnotation(annotation) == null;
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public <T extends Annotation> MethodList hasNotMetaAnnotation(final Class<T> annotation) {
/* 171 */     filter(new Filter() {
/*     */       public boolean keep(AnnotatedMethod m) {
/* 173 */         for (Annotation a : m.getAnnotations()) {
/* 174 */           if (a.annotationType().getAnnotation(annotation) != null)
/* 175 */             return false;
/*     */         }
/* 177 */         return true;
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MethodList filter(Filter f)
/*     */   {
/* 187 */     List<AnnotatedMethod> r = new ArrayList();
/* 188 */     for (AnnotatedMethod m : this.methods)
/* 189 */       if (f.keep(m))
/* 190 */         r.add(m);
/* 191 */     return new MethodList((AnnotatedMethod[])r.toArray(new AnnotatedMethod[0]));
/*     */   }
/*     */   
/*     */   public static abstract interface Filter
/*     */   {
/*     */     public abstract boolean keep(AnnotatedMethod paramAnnotatedMethod);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\reflection\MethodList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */