/*     */ package com.sun.jersey.core.impl.provider.entity;
/*     */ 
/*     */ import com.sun.jersey.core.provider.jaxb.AbstractJAXBProvider;
/*     */ import com.sun.jersey.impl.ImplMessages;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import javax.ws.rs.Consumes;
/*     */ import javax.ws.rs.Produces;
/*     */ import javax.ws.rs.WebApplicationException;
/*     */ import javax.ws.rs.core.Context;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.core.Response.Status;
/*     */ import javax.ws.rs.ext.Providers;
/*     */ import javax.xml.bind.JAXBContext;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.UnmarshalException;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLRootObjectProvider
/*     */   extends AbstractJAXBProvider<Object>
/*     */ {
/*     */   private final Injectable<SAXParserFactory> spf;
/*     */   
/*     */   XMLRootObjectProvider(Injectable<SAXParserFactory> spf, Providers ps)
/*     */   {
/*  74 */     super(ps);
/*     */     
/*  76 */     this.spf = spf;
/*     */   }
/*     */   
/*     */   XMLRootObjectProvider(Injectable<SAXParserFactory> spf, Providers ps, MediaType mt) {
/*  80 */     super(ps, mt);
/*     */     
/*  82 */     this.spf = spf;
/*     */   }
/*     */   
/*     */   protected JAXBContext getStoredJAXBContext(Class type) throws JAXBException
/*     */   {
/*  87 */     return null;
/*     */   }
/*     */   
/*     */   @Produces({"application/xml"})
/*     */   @Consumes({"application/xml"})
/*     */   public static final class App extends XMLRootObjectProvider {
/*     */     public App(@Context Injectable<SAXParserFactory> spf, @Context Providers ps) {
/*  94 */       super(ps, MediaType.APPLICATION_XML_TYPE);
/*     */     }
/*     */   }
/*     */   
/*     */   @Produces({"text/xml"})
/*     */   @Consumes({"text/xml"})
/*     */   public static final class Text extends XMLRootObjectProvider {
/*     */     public Text(@Context Injectable<SAXParserFactory> spf, @Context Providers ps) {
/* 102 */       super(ps, MediaType.TEXT_XML_TYPE);
/*     */     }
/*     */   }
/*     */   
/*     */   @Produces({"*/*"})
/*     */   @Consumes({"*/*"})
/*     */   public static final class General extends XMLRootObjectProvider {
/*     */     public General(@Context Injectable<SAXParserFactory> spf, @Context Providers ps) {
/* 110 */       super(ps);
/*     */     }
/*     */     
/*     */     protected boolean isSupported(MediaType m)
/*     */     {
/* 115 */       return m.getSubtype().endsWith("+xml");
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isReadable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
/*     */     try {
/* 121 */       return (Object.class == type) && (isSupported(mediaType)) && (getUnmarshaller(type, mediaType) != null);
/*     */     } catch (JAXBException cause) {
/* 123 */       throw new RuntimeException(ImplMessages.ERROR_UNMARSHALLING_JAXB(type), cause);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object readFrom(Class<Object> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, String> httpHeaders, InputStream entityStream)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 135 */       return getUnmarshaller(type, mediaType).unmarshal(getSAXSource((SAXParserFactory)this.spf.getValue(), entityStream));
/*     */     }
/*     */     catch (UnmarshalException ex) {
/* 138 */       throw new WebApplicationException(ex, Response.Status.BAD_REQUEST);
/*     */     } catch (JAXBException ex) {
/* 140 */       throw new WebApplicationException(ex, Response.Status.INTERNAL_SERVER_ERROR);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isWriteable(Class<?> arg0, Type arg1, Annotation[] arg2, MediaType mediaType) {
/* 145 */     return false;
/*     */   }
/*     */   
/*     */   public void writeTo(Object arg0, Class<?> arg1, Type arg2, Annotation[] arg3, MediaType arg4, MultivaluedMap<String, Object> arg5, OutputStream arg6)
/*     */     throws IOException, WebApplicationException
/*     */   {
/* 151 */     throw new IllegalArgumentException();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\entity\XMLRootObjectProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */