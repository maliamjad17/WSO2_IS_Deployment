/*     */ package com.sun.jersey.core.reflection;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.ws.rs.Consumes;
/*     */ import javax.ws.rs.CookieParam;
/*     */ import javax.ws.rs.DefaultValue;
/*     */ import javax.ws.rs.Encoded;
/*     */ import javax.ws.rs.FormParam;
/*     */ import javax.ws.rs.HeaderParam;
/*     */ import javax.ws.rs.HttpMethod;
/*     */ import javax.ws.rs.MatrixParam;
/*     */ import javax.ws.rs.Path;
/*     */ import javax.ws.rs.PathParam;
/*     */ import javax.ws.rs.Produces;
/*     */ import javax.ws.rs.QueryParam;
/*     */ import javax.ws.rs.core.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AnnotatedMethod
/*     */   implements AnnotatedElement
/*     */ {
/*  73 */   private static final Set<Class<? extends Annotation>> METHOD_META_ANNOTATIONS = getSet(new Class[] { HttpMethod.class });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  78 */   private static final Set<Class<? extends Annotation>> METHOD_ANNOTATIONS = getSet(new Class[] { Path.class, Produces.class, Consumes.class });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */   private static final Set<Class<? extends Annotation>> PARAMETER_ANNOTATIONS = getSet(new Class[] { Context.class, Encoded.class, DefaultValue.class, MatrixParam.class, QueryParam.class, CookieParam.class, HeaderParam.class, PathParam.class, FormParam.class });
/*     */   
/*     */   private final Method m;
/*     */   
/*     */   private final Method am;
/*     */   
/*     */   private final Annotation[] methodAnnotations;
/*     */   
/*     */   private final Annotation[][] parameterAnnotations;
/*     */   
/*     */   private static Set<Class<? extends Annotation>> getSet(Class<? extends Annotation>... cs)
/*     */   {
/*  97 */     Set<Class<? extends Annotation>> s = new HashSet();
/*  98 */     for (Class<? extends Annotation> c : cs) s.add(c);
/*  99 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotatedMethod(Method m)
/*     */   {
/* 111 */     this.m = m;
/* 112 */     this.am = findAnnotatedMethod(m);
/*     */     
/* 114 */     if (m.equals(this.am)) {
/* 115 */       this.methodAnnotations = m.getAnnotations();
/* 116 */       this.parameterAnnotations = m.getParameterAnnotations();
/*     */     } else {
/* 118 */       this.methodAnnotations = mergeMethodAnnotations(m, this.am);
/* 119 */       this.parameterAnnotations = mergeParameterAnnotations(m, this.am);
/*     */     }
/*     */   }
/*     */   
/*     */   public Method getMethod() {
/* 124 */     return this.am;
/*     */   }
/*     */   
/*     */   public Annotation[][] getParameterAnnotations() {
/* 128 */     return (Annotation[][])this.parameterAnnotations.clone();
/*     */   }
/*     */   
/*     */   public Class<?>[] getParameterTypes() {
/* 132 */     return this.am.getParameterTypes();
/*     */   }
/*     */   
/*     */   public TypeVariable<Method>[] getTypeParameters() {
/* 136 */     return this.am.getTypeParameters();
/*     */   }
/*     */   
/*     */   public Type[] getGenericParameterTypes() {
/* 140 */     return this.am.getGenericParameterTypes();
/*     */   }
/*     */   
/*     */   public <T extends Annotation> List<T> getMetaMethodAnnotations(Class<T> annotation)
/*     */   {
/* 145 */     List<T> ma = new ArrayList();
/* 146 */     for (Annotation a : this.methodAnnotations) {
/* 147 */       if (a.annotationType().getAnnotation(annotation) != null) {
/* 148 */         ma.add(a.annotationType().getAnnotation(annotation));
/*     */       }
/*     */     }
/*     */     
/* 152 */     return ma;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 157 */     return this.m.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isAnnotationPresent(Class<? extends Annotation> annotationType)
/*     */   {
/* 163 */     for (Annotation ma : this.methodAnnotations) {
/* 164 */       if (ma.annotationType() == annotationType)
/* 165 */         return true;
/*     */     }
/* 167 */     return false;
/*     */   }
/*     */   
/*     */   public <T extends Annotation> T getAnnotation(Class<T> annotationType) {
/* 171 */     for (Annotation ma : this.methodAnnotations) {
/* 172 */       if (ma.annotationType() == annotationType)
/* 173 */         return (Annotation)annotationType.cast(ma);
/*     */     }
/* 175 */     return this.am.getAnnotation(annotationType);
/*     */   }
/*     */   
/*     */   public Annotation[] getAnnotations() {
/* 179 */     return (Annotation[])this.methodAnnotations.clone();
/*     */   }
/*     */   
/*     */   public Annotation[] getDeclaredAnnotations() {
/* 183 */     return getAnnotations();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static Annotation[] mergeMethodAnnotations(Method m, Method am)
/*     */   {
/* 190 */     List<Annotation> al = asList(m.getAnnotations());
/* 191 */     for (Annotation a : am.getAnnotations()) {
/* 192 */       if (!m.isAnnotationPresent(a.getClass())) {
/* 193 */         al.add(a);
/*     */       }
/*     */     }
/* 196 */     return (Annotation[])al.toArray(new Annotation[0]);
/*     */   }
/*     */   
/*     */   private static Annotation[][] mergeParameterAnnotations(Method m, Method am) {
/* 200 */     Annotation[][] mp = m.getParameterAnnotations();
/* 201 */     Annotation[][] amp = am.getParameterAnnotations();
/*     */     
/* 203 */     List<List<Annotation>> ala = new ArrayList();
/* 204 */     for (int i = 0; i < mp.length; i++) {
/* 205 */       List<Annotation> al = asList(mp[i]);
/* 206 */       for (Annotation a : amp[i])
/* 207 */         if (!isAnnotatonPresent(a.getClass(), al))
/* 208 */           al.add(a);
/* 209 */       ala.add(al);
/*     */     }
/*     */     
/* 212 */     Annotation[][] paa = new Annotation[mp.length][];
/* 213 */     for (int i = 0; i < mp.length; i++) {
/* 214 */       paa[i] = ((Annotation[])((List)ala.get(i)).toArray(new Annotation[0]));
/*     */     }
/*     */     
/* 217 */     return paa;
/*     */   }
/*     */   
/*     */   private static boolean isAnnotatonPresent(Class<? extends Annotation> ca, List<Annotation> la) {
/* 221 */     for (Annotation a : la) {
/* 222 */       if (ca == a.getClass())
/* 223 */         return true;
/*     */     }
/* 225 */     return false;
/*     */   }
/*     */   
/*     */   private static Method findAnnotatedMethod(Method m) {
/* 229 */     Method am = findAnnotatedMethod(m.getDeclaringClass(), m);
/* 230 */     return am != null ? am : m;
/*     */   }
/*     */   
/*     */   private static Method findAnnotatedMethod(Class<?> c, Method m) {
/* 234 */     if (c == Object.class) {
/* 235 */       return null;
/*     */     }
/* 237 */     m = ReflectionHelper.findMethodOnClass(c, m);
/* 238 */     if (m == null) {
/* 239 */       return null;
/*     */     }
/* 241 */     if (hasAnnotations(m)) { return m;
/*     */     }
/*     */     
/* 244 */     Class<?> sc = c.getSuperclass();
/* 245 */     if ((sc != null) && (sc != Object.class)) {
/* 246 */       Method sm = findAnnotatedMethod(sc, m);
/* 247 */       if (sm != null) { return sm;
/*     */       }
/*     */     }
/* 250 */     for (Class<?> ic : c.getInterfaces()) {
/* 251 */       Method im = findAnnotatedMethod(ic, m);
/* 252 */       if (im != null) { return im;
/*     */       }
/*     */     }
/* 255 */     return null;
/*     */   }
/*     */   
/*     */   private static boolean hasAnnotations(Method m) {
/* 259 */     return (hasMetaMethodAnnotations(m)) || (hasMethodAnnotations(m)) || (hasParameterAnnotations(m));
/*     */   }
/*     */   
/*     */ 
/*     */   private static boolean hasMetaMethodAnnotations(Method m)
/*     */   {
/* 265 */     for (Class<? extends Annotation> ac : METHOD_META_ANNOTATIONS) {
/* 266 */       for (Annotation a : m.getAnnotations())
/* 267 */         if (a.annotationType().getAnnotation(ac) != null) return true;
/*     */     }
/* 269 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean hasMethodAnnotations(Method m) {
/* 273 */     for (Class<? extends Annotation> ac : METHOD_ANNOTATIONS) {
/* 274 */       if (m.isAnnotationPresent(ac)) return true;
/*     */     }
/* 276 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean hasParameterAnnotations(Method m) {
/* 280 */     for (Annotation[] as : m.getParameterAnnotations()) {
/* 281 */       for (Annotation a : as)
/* 282 */         if (PARAMETER_ANNOTATIONS.contains(a.annotationType())) return true;
/*     */     }
/* 284 */     return false;
/*     */   }
/*     */   
/*     */   private static <T> List<T> asList(T... ts) {
/* 288 */     List<T> l = new ArrayList();
/* 289 */     for (T t : ts) l.add(t);
/* 290 */     return l;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\reflection\AnnotatedMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */