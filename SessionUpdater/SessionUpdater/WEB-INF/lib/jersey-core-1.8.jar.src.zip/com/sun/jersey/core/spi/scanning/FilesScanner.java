/*     */ package com.sun.jersey.core.spi.scanning;
/*     */ 
/*     */ import com.sun.jersey.core.util.Closing;
/*     */ import com.sun.jersey.core.util.Closing.Closure;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilesScanner
/*     */   implements Scanner
/*     */ {
/*     */   private final File[] files;
/*     */   
/*     */   public FilesScanner(File[] files)
/*     */   {
/*  67 */     this.files = files;
/*     */   }
/*     */   
/*     */ 
/*     */   public void scan(ScannerListener cfl)
/*     */   {
/*  73 */     for (File f : this.files) {
/*  74 */       scan(f, cfl);
/*     */     }
/*     */   }
/*     */   
/*     */   private void scan(File f, ScannerListener cfl) {
/*  79 */     if (f.isDirectory()) {
/*  80 */       scanDir(f, cfl);
/*  81 */     } else if ((f.getName().endsWith(".jar")) || (f.getName().endsWith(".zip"))) {
/*     */       try {
/*  83 */         JarFileScanner.scan(f, "", cfl);
/*     */       } catch (IOException ex) {
/*  85 */         throw new ScannerException("IO error when scanning jar file " + f, ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void scanDir(File root, final ScannerListener cfl)
/*     */   {
/*  93 */     for (final File child : root.listFiles()) {
/*  94 */       if (child.isDirectory()) {
/*  95 */         scanDir(child, cfl);
/*  96 */       } else if (child.getName().endsWith(".jar")) {
/*     */         try {
/*  98 */           JarFileScanner.scan(child, "", cfl);
/*     */         } catch (IOException ex) {
/* 100 */           throw new ScannerException("IO error when scanning jar file " + child, ex);
/*     */         }
/* 102 */       } else if (cfl.onAccept(child.getName())) {
/*     */         try {
/* 104 */           new Closing(new BufferedInputStream(new FileInputStream(child))).f(new Closing.Closure()
/*     */           {
/*     */             public void f(InputStream in) throws IOException {
/* 107 */               cfl.onProcess(child.getName(), in);
/*     */             }
/*     */           });
/*     */         } catch (IOException ex) {
/* 111 */           throw new ScannerException("IO error when scanning file " + child, ex);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\scanning\FilesScanner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */