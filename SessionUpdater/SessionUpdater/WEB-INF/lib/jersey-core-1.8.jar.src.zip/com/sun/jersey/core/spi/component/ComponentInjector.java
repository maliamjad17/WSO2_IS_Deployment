/*     */ package com.sun.jersey.core.spi.component;
/*     */ 
/*     */ import com.sun.jersey.core.reflection.AnnotatedMethod;
/*     */ import com.sun.jersey.core.reflection.MethodList;
/*     */ import com.sun.jersey.spi.inject.Errors;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import com.sun.jersey.spi.inject.InjectableProviderContext;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import javax.ws.rs.HttpMethod;
/*     */ import javax.ws.rs.Path;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComponentInjector<T>
/*     */ {
/*     */   protected final InjectableProviderContext ipc;
/*     */   protected final Class<T> c;
/*     */   
/*     */   public ComponentInjector(InjectableProviderContext ipc, Class<T> c)
/*     */   {
/*  73 */     this.ipc = ipc;
/*  74 */     this.c = c;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void inject(T t)
/*     */   {
/*  83 */     AnnotatedContext aoc = new AnnotatedContext();
/*     */     
/*  85 */     Class oClass = this.c;
/*  86 */     while (oClass != Object.class) {
/*  87 */       for (Field f : oClass.getDeclaredFields()) {
/*  88 */         aoc.setAccessibleObject(f);
/*  89 */         Annotation[] as = f.getAnnotations();
/*  90 */         aoc.setAnnotations(as);
/*  91 */         boolean missingDependency = false;
/*  92 */         for (Annotation a : as) {
/*  93 */           Injectable i = this.ipc.getInjectable(a.annotationType(), aoc, a, f.getGenericType(), ComponentScope.UNDEFINED_SINGLETON);
/*     */           
/*     */ 
/*  96 */           if (i != null) {
/*  97 */             missingDependency = false;
/*  98 */             setFieldValue(t, f, i.getValue());
/*  99 */             break; }
/* 100 */           if (this.ipc.isAnnotationRegistered(a.annotationType(), f.getGenericType().getClass())) {
/* 101 */             missingDependency = true;
/*     */           }
/*     */         }
/*     */         
/* 105 */         if (missingDependency) {
/* 106 */           Errors.missingDependency(f);
/*     */         }
/*     */       }
/*     */       
/* 110 */       oClass = oClass.getSuperclass();
/*     */     }
/*     */     
/* 113 */     MethodList ml = new MethodList(this.c.getMethods());
/* 114 */     int methodIndex = 0;
/* 115 */     for (AnnotatedMethod m : ml.hasNotMetaAnnotation(HttpMethod.class).hasNotAnnotation(Path.class).hasNumParams(1).hasReturnType(Void.TYPE).nameStartsWith("set"))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 121 */       Annotation[] as = m.getAnnotations();
/* 122 */       aoc.setAccessibleObject(m.getMethod());
/* 123 */       aoc.setAnnotations(as);
/* 124 */       Type gpt = m.getGenericParameterTypes()[0];
/*     */       
/* 126 */       boolean missingDependency = false;
/* 127 */       for (Annotation a : as) {
/* 128 */         Injectable i = this.ipc.getInjectable(a.annotationType(), aoc, a, gpt, ComponentScope.UNDEFINED_SINGLETON);
/*     */         
/*     */ 
/* 131 */         if (i != null) {
/* 132 */           missingDependency = false;
/* 133 */           setMethodValue(t, m, i.getValue());
/* 134 */           break; }
/* 135 */         if (this.ipc.isAnnotationRegistered(a.annotationType(), gpt.getClass())) {
/* 136 */           missingDependency = true;
/*     */         }
/*     */       }
/*     */       
/* 140 */       if (missingDependency) {
/* 141 */         Errors.missingDependency(m.getMethod(), methodIndex);
/*     */       }
/*     */       
/* 144 */       methodIndex++;
/*     */     }
/*     */   }
/*     */   
/*     */   private void setFieldValue(final Object resource, final Field f, final Object value) {
/* 149 */     AccessController.doPrivileged(new PrivilegedAction() {
/*     */       public Object run() {
/*     */         try {
/* 152 */           if (!f.isAccessible()) {
/* 153 */             f.setAccessible(true);
/*     */           }
/* 155 */           f.set(resource, value);
/* 156 */           return null;
/*     */         } catch (IllegalAccessException ex) {
/* 158 */           throw new RuntimeException(ex);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private void setMethodValue(Object o, AnnotatedMethod m, Object value) {
/*     */     try {
/* 166 */       m.getMethod().invoke(o, new Object[] { value });
/*     */     } catch (Exception ex) {
/* 168 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\component\ComponentInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */