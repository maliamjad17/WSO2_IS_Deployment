/*     */ package com.sun.jersey.core.impl.provider.entity;
/*     */ 
/*     */ import com.sun.jersey.core.provider.AbstractMessageReaderWriterProvider;
/*     */ import com.sun.jersey.core.util.ReaderWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URLDecoder;
/*     */ import java.net.URLEncoder;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.ws.rs.WebApplicationException;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.core.Response.Status;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseFormProvider<T extends MultivaluedMap<String, String>>
/*     */   extends AbstractMessageReaderWriterProvider<T>
/*     */ {
/*     */   public T readFrom(T map, MediaType mediaType, InputStream entityStream)
/*     */     throws IOException
/*     */   {
/*  67 */     String encoded = readFromAsString(entityStream, mediaType);
/*     */     
/*  69 */     String charsetName = ReaderWriter.getCharset(mediaType).name();
/*     */     
/*  71 */     StringTokenizer tokenizer = new StringTokenizer(encoded, "&");
/*     */     try
/*     */     {
/*  74 */       while (tokenizer.hasMoreTokens()) {
/*  75 */         String token = tokenizer.nextToken();
/*  76 */         int idx = token.indexOf('=');
/*  77 */         if (idx < 0) {
/*  78 */           map.add(URLDecoder.decode(token, charsetName), null);
/*  79 */         } else if (idx > 0) {
/*  80 */           map.add(URLDecoder.decode(token.substring(0, idx), charsetName), URLDecoder.decode(token.substring(idx + 1), charsetName));
/*     */         }
/*     */       }
/*     */       
/*  84 */       return map;
/*     */     } catch (IllegalArgumentException ex) {
/*  86 */       throw new WebApplicationException(ex, Response.Status.BAD_REQUEST);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeTo(T t, MediaType mediaType, OutputStream entityStream)
/*     */     throws IOException
/*     */   {
/*  94 */     String charsetName = ReaderWriter.getCharset(mediaType).name();
/*     */     
/*  96 */     StringBuilder sb = new StringBuilder();
/*  97 */     for (Iterator i$ = t.entrySet().iterator(); i$.hasNext();) { e = (Map.Entry)i$.next();
/*  98 */       for (String value : (List)e.getValue()) {
/*  99 */         if (sb.length() > 0)
/* 100 */           sb.append('&');
/* 101 */         sb.append(URLEncoder.encode((String)e.getKey(), charsetName));
/* 102 */         if (value != null) {
/* 103 */           sb.append('=');
/* 104 */           sb.append(URLEncoder.encode(value, charsetName));
/*     */         }
/*     */       }
/*     */     }
/*     */     Map.Entry<String, List<String>> e;
/* 109 */     writeToAsString(sb.toString(), entityStream, mediaType);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\entity\BaseFormProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */