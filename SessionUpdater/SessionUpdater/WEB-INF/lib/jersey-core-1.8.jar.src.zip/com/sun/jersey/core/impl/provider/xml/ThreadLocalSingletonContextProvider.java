/*    */ package com.sun.jersey.core.impl.provider.xml;
/*    */ 
/*    */ import com.sun.jersey.core.spi.component.ComponentContext;
/*    */ import com.sun.jersey.core.spi.component.ComponentScope;
/*    */ import com.sun.jersey.spi.inject.Injectable;
/*    */ import com.sun.jersey.spi.inject.InjectableProvider;
/*    */ import java.lang.reflect.Type;
/*    */ import javax.ws.rs.core.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ThreadLocalSingletonContextProvider<T>
/*    */   implements InjectableProvider<Context, Type>
/*    */ {
/*    */   private final Class<T> t;
/*    */   private final ThreadLocal<T> rf;
/*    */   
/*    */   protected ThreadLocalSingletonContextProvider(Class<T> t)
/*    */   {
/* 60 */     this.t = t;
/* 61 */     this.rf = new ThreadLocal()
/*    */     {
/*    */       protected synchronized T initialValue() {
/* 64 */         return (T)ThreadLocalSingletonContextProvider.this.getInstance();
/*    */       }
/*    */     };
/*    */   }
/*    */   
/*    */   public ComponentScope getScope() {
/* 70 */     return ComponentScope.Singleton;
/*    */   }
/*    */   
/*    */   public Injectable<T> getInjectable(ComponentContext ic, Context a, Type c) {
/* 74 */     if (c == this.t) {
/* 75 */       new Injectable() {
/*    */         public T getValue() {
/* 77 */           return (T)ThreadLocalSingletonContextProvider.this.rf.get();
/*    */         }
/*    */       };
/*    */     }
/* 81 */     return null;
/*    */   }
/*    */   
/*    */   protected abstract T getInstance();
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\xml\ThreadLocalSingletonContextProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */