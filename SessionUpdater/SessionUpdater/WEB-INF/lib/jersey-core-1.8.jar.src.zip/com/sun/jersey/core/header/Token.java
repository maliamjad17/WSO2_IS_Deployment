/*    */ package com.sun.jersey.core.header;
/*    */ 
/*    */ import com.sun.jersey.core.header.reader.HttpHeaderReader;
/*    */ import java.text.ParseException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Token
/*    */ {
/*    */   protected String token;
/*    */   
/*    */   protected Token() {}
/*    */   
/*    */   public Token(String header)
/*    */     throws ParseException
/*    */   {
/* 58 */     this(HttpHeaderReader.newInstance(header));
/*    */   }
/*    */   
/*    */   public Token(HttpHeaderReader reader) throws ParseException
/*    */   {
/* 63 */     reader.hasNext();
/*    */     
/* 65 */     this.token = reader.nextToken();
/*    */     
/* 67 */     if (reader.hasNext())
/* 68 */       throw new ParseException("Invalid token", reader.getIndex());
/*    */   }
/*    */   
/*    */   public String getToken() {
/* 72 */     return this.token;
/*    */   }
/*    */   
/*    */   public final boolean isCompatible(String token) {
/* 76 */     if (this.token.equals("*")) {
/* 77 */       return true;
/*    */     }
/* 79 */     return this.token.equals(token);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\header\Token.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */