/*    */ package com.sun.jersey.core.impl.provider.header;
/*    */ 
/*    */ import com.sun.jersey.core.header.reader.HttpHeaderReader;
/*    */ import com.sun.jersey.spi.HeaderDelegateProvider;
/*    */ import javax.ws.rs.core.Cookie;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CookieProvider
/*    */   implements HeaderDelegateProvider<Cookie>
/*    */ {
/*    */   public boolean supports(Class<?> type)
/*    */   {
/* 50 */     return type == Cookie.class;
/*    */   }
/*    */   
/*    */   public String toString(Cookie cookie) {
/* 54 */     StringBuilder b = new StringBuilder();
/*    */     
/* 56 */     b.append("$Version=").append(cookie.getVersion()).append(';');
/*    */     
/* 58 */     b.append(cookie.getName()).append('=');
/* 59 */     WriterUtil.appendQuotedIfWhitespace(b, cookie.getValue());
/*    */     
/* 61 */     if (cookie.getDomain() != null) {
/* 62 */       b.append(";$Domain=");
/* 63 */       WriterUtil.appendQuotedIfWhitespace(b, cookie.getDomain());
/*    */     }
/* 65 */     if (cookie.getPath() != null) {
/* 66 */       b.append(";$Path=");
/* 67 */       WriterUtil.appendQuotedIfWhitespace(b, cookie.getPath());
/*    */     }
/* 69 */     return b.toString();
/*    */   }
/*    */   
/*    */   public Cookie fromString(String header) {
/* 73 */     if (header == null) {
/* 74 */       throw new IllegalArgumentException();
/*    */     }
/* 76 */     return HttpHeaderReader.readCookie(header);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\header\CookieProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */