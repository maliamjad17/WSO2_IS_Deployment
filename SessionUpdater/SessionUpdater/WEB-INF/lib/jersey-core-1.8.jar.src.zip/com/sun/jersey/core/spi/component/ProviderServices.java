/*     */ package com.sun.jersey.core.spi.component;
/*     */ 
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*     */ import com.sun.jersey.core.spi.factory.InjectableProviderFactory;
/*     */ import com.sun.jersey.spi.inject.ConstrainedTo;
/*     */ import com.sun.jersey.spi.inject.ConstrainedToType;
/*     */ import com.sun.jersey.spi.service.ServiceFinder;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProviderServices
/*     */ {
/*  63 */   private static final Logger LOGGER = Logger.getLogger(ProviderServices.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */   private final Class<? extends ConstrainedToType> constraintToType;
/*     */   
/*     */ 
/*     */ 
/*     */   private final ProviderFactory componentProviderFactory;
/*     */   
/*     */ 
/*     */ 
/*     */   private final Set<Class<?>> providers;
/*     */   
/*     */ 
/*     */   private final Set providerInstances;
/*     */   
/*     */ 
/*     */ 
/*     */   public ProviderServices(ProviderFactory componentProviderFactory, Set<Class<?>> providers, Set<?> providerInstances)
/*     */   {
/*  84 */     this(ConstrainedToType.class, componentProviderFactory, providers, providerInstances);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ProviderServices(Class<? extends ConstrainedToType> constraintToType, ProviderFactory componentProviderFactory, Set<Class<?>> providers, Set<?> providerInstances)
/*     */   {
/* 100 */     this.constraintToType = constraintToType;
/* 101 */     this.componentProviderFactory = componentProviderFactory;
/* 102 */     this.providers = providers;
/* 103 */     this.providerInstances = providerInstances;
/*     */   }
/*     */   
/*     */   public void update(Set<Class<?>> providers, Set<?> providerInstances, InjectableProviderFactory ipf) {
/* 107 */     Set<Class<?>> addedProviders = diff(this.providers, providers);
/* 108 */     Set<?> addedProviderInstances = diff(this.providerInstances, providerInstances);
/*     */     
/* 110 */     this.providers.clear();
/* 111 */     this.providers.addAll(providers);
/*     */     
/* 113 */     this.providerInstances.clear();
/* 114 */     this.providerInstances.addAll(providerInstances);
/*     */     
/* 116 */     ProviderServices _ps = new ProviderServices(this.componentProviderFactory, addedProviders, addedProviderInstances);
/* 117 */     InjectableProviderFactory _ipf = new InjectableProviderFactory();
/* 118 */     _ipf.configureProviders(_ps);
/* 119 */     ipf.update(_ipf);
/*     */   }
/*     */   
/*     */   private <T> Set<T> diff(Set<T> s1, Set<T> s2) {
/* 123 */     Set<T> diff = new LinkedHashSet();
/*     */     
/* 125 */     for (T t : s1) {
/* 126 */       if (!s2.contains(t)) {
/* 127 */         diff.add(t);
/*     */       }
/*     */     }
/*     */     
/* 131 */     for (T t : s2) {
/* 132 */       if (!s1.contains(t)) {
/* 133 */         diff.add(t);
/*     */       }
/*     */     }
/*     */     
/* 137 */     return diff;
/*     */   }
/*     */   
/*     */   public ProviderFactory getComponentProviderFactory() {
/* 141 */     return this.componentProviderFactory;
/*     */   }
/*     */   
/*     */   public <T> Set<T> getProviders(Class<T> provider) {
/* 145 */     Set<T> ps = new LinkedHashSet();
/* 146 */     ps.addAll(getProviderInstances(provider));
/* 147 */     for (Class pc : getProviderClasses(provider)) {
/* 148 */       Object o = getComponent(pc);
/* 149 */       if (o != null) {
/* 150 */         ps.add(provider.cast(o));
/*     */       }
/*     */     }
/*     */     
/* 154 */     return ps;
/*     */   }
/*     */   
/*     */   public <T> Set<T> getServices(Class<T> provider) {
/* 158 */     Set<T> ps = new LinkedHashSet();
/* 159 */     for (ProviderClass pc : getServiceClasses(provider)) {
/* 160 */       Object o = getComponent(pc);
/* 161 */       if (o != null) {
/* 162 */         ps.add(provider.cast(o));
/*     */       }
/*     */     }
/*     */     
/* 166 */     return ps;
/*     */   }
/*     */   
/*     */   public <T> Set<T> getProvidersAndServices(Class<T> provider) {
/* 170 */     Set<T> ps = new LinkedHashSet();
/* 171 */     ps.addAll(getProviderInstances(provider));
/* 172 */     for (ProviderClass pc : getProviderAndServiceClasses(provider)) {
/* 173 */       Object o = getComponent(pc);
/* 174 */       if (o != null) {
/* 175 */         ps.add(provider.cast(o));
/*     */       }
/*     */     }
/*     */     
/* 179 */     return ps;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> void getProviders(Class<T> provider, ProviderListener listener)
/*     */   {
/* 187 */     for (T t : getProviderInstances(provider)) {
/* 188 */       listener.onAdd(t);
/*     */     }
/*     */     
/* 191 */     for (ProviderClass pc : getProviderOnlyClasses(provider)) {
/* 192 */       Object o = getComponent(pc);
/* 193 */       if (o != null) {
/* 194 */         listener.onAdd(provider.cast(o));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public <T> void getProvidersAndServices(Class<T> provider, ProviderListener listener) {
/* 200 */     for (T t : getProviderInstances(provider)) {
/* 201 */       listener.onAdd(t);
/*     */     }
/*     */     
/* 204 */     for (ProviderClass pc : getProviderAndServiceClasses(provider)) {
/* 205 */       Object o = getComponent(pc);
/* 206 */       if (o != null) {
/* 207 */         listener.onAdd(provider.cast(o));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public <T> List<T> getInstances(Class<T> provider, String[] classNames) {
/* 213 */     List<T> ps = new LinkedList();
/* 214 */     for (String className : classNames) {
/*     */       try {
/* 216 */         Class<?> c = ReflectionHelper.classForNameWithException(className);
/* 217 */         if (provider.isAssignableFrom(c)) {
/* 218 */           Object o = getComponent(c);
/* 219 */           if (o != null)
/* 220 */             ps.add(provider.cast(o));
/*     */         } else {
/* 222 */           LOGGER.severe("The class " + className + " is not assignable to the class " + provider.getName() + ". This class is ignored.");
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       catch (ClassNotFoundException e)
/*     */       {
/* 229 */         LOGGER.severe("The class " + className + " could not be found" + ". This class is ignored.");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 236 */     return ps;
/*     */   }
/*     */   
/*     */   public <T> List<T> getInstances(Class<T> provider, Class<? extends T>[] classes) {
/* 240 */     List<T> ps = new LinkedList();
/* 241 */     for (Class<? extends T> c : classes) {
/* 242 */       Object o = getComponent(c);
/* 243 */       if (o != null) {
/* 244 */         ps.add(provider.cast(o));
/*     */       }
/*     */     }
/* 247 */     return ps;
/*     */   }
/*     */   
/*     */   private Object getComponent(Class provider) {
/* 251 */     ComponentProvider cp = this.componentProviderFactory.getComponentProvider(provider);
/* 252 */     return cp != null ? cp.getInstance() : null;
/*     */   }
/*     */   
/*     */   private Object getComponent(ProviderClass provider) {
/* 256 */     ComponentProvider cp = this.componentProviderFactory.getComponentProvider(provider);
/* 257 */     return cp != null ? cp.getInstance() : null;
/*     */   }
/*     */   
/*     */   private <T> Set<T> getProviderInstances(Class<T> service) {
/* 261 */     Set<T> sp = new LinkedHashSet();
/* 262 */     for (Object p : this.providerInstances) {
/* 263 */       if ((service.isInstance(p)) && (constrainedTo(p.getClass()))) {
/* 264 */         sp.add(service.cast(p));
/*     */       }
/*     */     }
/* 267 */     return sp;
/*     */   }
/*     */   
/*     */   private Set<Class> getProviderClasses(Class<?> service) {
/* 271 */     Set<Class> sp = new LinkedHashSet();
/* 272 */     for (Class p : this.providers) {
/* 273 */       if ((service.isAssignableFrom(p)) && (constrainedTo(p))) {
/* 274 */         sp.add(p);
/*     */       }
/*     */     }
/* 277 */     return sp;
/*     */   }
/*     */   
/*     */   public class ProviderClass {
/*     */     final boolean isServiceClass;
/*     */     final Class c;
/*     */     
/*     */     ProviderClass(Class c) {
/* 285 */       this.c = c;
/* 286 */       this.isServiceClass = false;
/*     */     }
/*     */     
/*     */     ProviderClass(Class c, boolean isServiceClass) {
/* 290 */       this.c = c;
/* 291 */       this.isServiceClass = isServiceClass;
/*     */     }
/*     */   }
/*     */   
/*     */   private Set<ProviderClass> getProviderAndServiceClasses(Class<?> service) {
/* 296 */     Set<ProviderClass> sp = getProviderOnlyClasses(service);
/* 297 */     getServiceClasses(service, sp);
/* 298 */     return sp;
/*     */   }
/*     */   
/*     */   private Set<ProviderClass> getProviderOnlyClasses(Class<?> service) {
/* 302 */     Set<ProviderClass> sp = new LinkedHashSet();
/* 303 */     for (Class c : getProviderClasses(service)) {
/* 304 */       sp.add(new ProviderClass(c));
/*     */     }
/* 306 */     return sp;
/*     */   }
/*     */   
/*     */   private Set<ProviderClass> getServiceClasses(Class<?> service) {
/* 310 */     Set<ProviderClass> sp = new LinkedHashSet();
/* 311 */     getServiceClasses(service, sp);
/* 312 */     return sp;
/*     */   }
/*     */   
/*     */   private void getServiceClasses(Class<?> service, Set<ProviderClass> sp)
/*     */   {
/* 317 */     LOGGER.log(Level.CONFIG, "Searching for providers that implement: " + service);
/* 318 */     Class<?>[] pca = ServiceFinder.find(service, true).toClassArray();
/* 319 */     for (Class pc : pca) {
/* 320 */       if (constrainedTo(pc)) {
/* 321 */         LOGGER.log(Level.CONFIG, "    Provider found: " + pc);
/*     */       }
/*     */     }
/*     */     
/* 325 */     for (Class pc : pca) {
/* 326 */       if (constrainedTo(pc)) {
/* 327 */         if (service.isAssignableFrom(pc)) {
/* 328 */           sp.add(new ProviderClass(pc, true));
/*     */         } else {
/* 330 */           LOGGER.log(Level.CONFIG, "Provider " + pc.getName() + " won't be used because its not assignable to " + service.getName() + ". This might be caused by clashing " + "container-provided and application-bundled Jersey classes.");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean constrainedTo(Class<?> p)
/*     */   {
/* 340 */     ConstrainedTo ct = (ConstrainedTo)p.getAnnotation(ConstrainedTo.class);
/* 341 */     return ct != null ? ct.value().isAssignableFrom(this.constraintToType) : true;
/*     */   }
/*     */   
/*     */   public static abstract interface ProviderListener<T>
/*     */   {
/*     */     public abstract void onAdd(T paramT);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\component\ProviderServices.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */