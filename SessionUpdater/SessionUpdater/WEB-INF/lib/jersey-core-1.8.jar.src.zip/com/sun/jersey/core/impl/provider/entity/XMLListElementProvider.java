/*     */ package com.sun.jersey.core.impl.provider.entity;
/*     */ 
/*     */ import com.sun.jersey.core.provider.jaxb.AbstractListElementProvider;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Collection;
/*     */ import javax.ws.rs.Consumes;
/*     */ import javax.ws.rs.Produces;
/*     */ import javax.ws.rs.core.Context;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.ext.Providers;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.Marshaller;
/*     */ import javax.xml.bind.PropertyException;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLListElementProvider
/*     */   extends AbstractListElementProvider
/*     */ {
/*     */   private final Injectable<XMLInputFactory> xif;
/*     */   
/*     */   XMLListElementProvider(Injectable<XMLInputFactory> xif, Providers ps)
/*     */   {
/*  73 */     super(ps);
/*     */     
/*  75 */     this.xif = xif;
/*     */   }
/*     */   
/*     */   XMLListElementProvider(Injectable<XMLInputFactory> xif, Providers ps, MediaType mt) {
/*  79 */     super(ps, mt);
/*     */     
/*  81 */     this.xif = xif;
/*     */   }
/*     */   
/*     */   @Produces({"application/xml"})
/*     */   @Consumes({"application/xml"})
/*     */   public static final class App extends XMLListElementProvider {
/*     */     public App(@Context Injectable<XMLInputFactory> xif, @Context Providers ps) {
/*  88 */       super(ps, MediaType.APPLICATION_XML_TYPE);
/*     */     }
/*     */   }
/*     */   
/*     */   @Produces({"text/xml"})
/*     */   @Consumes({"text/xml"})
/*     */   public static final class Text extends XMLListElementProvider {
/*     */     public Text(@Context Injectable<XMLInputFactory> xif, @Context Providers ps) {
/*  96 */       super(ps, MediaType.TEXT_XML_TYPE);
/*     */     }
/*     */   }
/*     */   
/*     */   @Produces({"*/*"})
/*     */   @Consumes({"*/*"})
/*     */   public static final class General extends XMLListElementProvider {
/*     */     public General(@Context Injectable<XMLInputFactory> xif, @Context Providers ps) {
/* 104 */       super(ps);
/*     */     }
/*     */     
/*     */     protected boolean isSupported(MediaType m)
/*     */     {
/* 109 */       return m.getSubtype().endsWith("+xml");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final XMLStreamReader getXMLStreamReader(Class<?> elementType, MediaType mediaType, Unmarshaller u, InputStream entityStream)
/*     */     throws XMLStreamException
/*     */   {
/* 119 */     return ((XMLInputFactory)this.xif.getValue()).createXMLStreamReader(entityStream);
/*     */   }
/*     */   
/*     */ 
/*     */   public final void writeList(Class<?> elementType, Collection<?> t, MediaType mediaType, Charset c, Marshaller m, OutputStream entityStream)
/*     */     throws JAXBException, IOException
/*     */   {
/* 126 */     String rootElement = getRootElementName(elementType);
/* 127 */     String cName = c.name();
/*     */     
/* 129 */     entityStream.write(String.format("<?xml version=\"1.0\" encoding=\"%s\" standalone=\"yes\"?>", new Object[] { cName }).getBytes(cName));
/*     */     
/* 131 */     String property = "com.sun.xml.bind.xmlHeaders";
/*     */     String header;
/*     */     try {
/* 134 */       header = (String)m.getProperty(property);
/*     */     } catch (PropertyException e) {
/* 136 */       property = "com.sun.xml.internal.bind.xmlHeaders";
/* 137 */       header = (String)m.getProperty(property);
/*     */     }
/* 139 */     if (header != null) {
/* 140 */       m.setProperty(property, "");
/* 141 */       entityStream.write(header.getBytes(cName));
/*     */     }
/* 143 */     entityStream.write(String.format("<%s>", new Object[] { rootElement }).getBytes(cName));
/* 144 */     for (Object o : t) {
/* 145 */       m.marshal(o, entityStream);
/*     */     }
/* 147 */     entityStream.write(String.format("</%s>", new Object[] { rootElement }).getBytes(cName));
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\entity\XMLListElementProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */