/*     */ package com.sun.jersey.core.spi.factory;
/*     */ 
/*     */ import com.sun.jersey.core.header.MediaTypes;
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*     */ import com.sun.jersey.core.reflection.ReflectionHelper.DeclaringClassInterfacePair;
/*     */ import com.sun.jersey.core.spi.component.ComponentContext;
/*     */ import com.sun.jersey.core.spi.component.ComponentScope;
/*     */ import com.sun.jersey.core.spi.component.ProviderServices;
/*     */ import com.sun.jersey.core.util.KeyComparatorHashMap;
/*     */ import com.sun.jersey.spi.inject.Injectable;
/*     */ import com.sun.jersey.spi.inject.InjectableProvider;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.ws.rs.Produces;
/*     */ import javax.ws.rs.core.Context;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.ext.ContextResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextResolverFactory
/*     */ {
/*     */   private final Map<Type, Map<MediaType, ContextResolver>> resolver;
/*     */   private final Map<Type, ConcurrentHashMap<MediaType, ContextResolver>> cache;
/*     */   
/*     */   public ContextResolverFactory()
/*     */   {
/*  72 */     this.resolver = new HashMap(4);
/*     */     
/*     */ 
/*  75 */     this.cache = new HashMap(4);
/*     */   }
/*     */   
/*     */   public void init(ProviderServices providersServices, InjectableProviderFactory ipf)
/*     */   {
/*  80 */     Map<Type, Map<MediaType, List<ContextResolver>>> rs = new HashMap();
/*     */     
/*     */ 
/*  83 */     Set<ContextResolver> providers = providersServices.getProviders(ContextResolver.class);
/*     */     
/*  85 */     for (Iterator i$ = providers.iterator(); i$.hasNext();) { provider = (ContextResolver)i$.next();
/*  86 */       List<MediaType> ms = MediaTypes.createMediaTypes((Produces)provider.getClass().getAnnotation(Produces.class));
/*     */       
/*     */ 
/*  89 */       Type type = getParameterizedType(provider.getClass());
/*     */       
/*  91 */       mr = (Map)rs.get(type);
/*  92 */       if (mr == null) {
/*  93 */         mr = new HashMap();
/*  94 */         rs.put(type, mr);
/*     */       }
/*  96 */       for (MediaType m : ms) {
/*  97 */         List<ContextResolver> crl = (List)mr.get(m);
/*  98 */         if (crl == null) {
/*  99 */           crl = new ArrayList();
/* 100 */           mr.put(m, crl);
/*     */         }
/* 102 */         crl.add(provider);
/*     */       }
/*     */     }
/*     */     
/*     */     ContextResolver provider;
/*     */     
/*     */     Map<MediaType, List<ContextResolver>> mr;
/* 109 */     for (Map.Entry<Type, Map<MediaType, List<ContextResolver>>> e : rs.entrySet()) {
/* 110 */       mr = new KeyComparatorHashMap(4, MessageBodyFactory.MEDIA_TYPE_COMPARATOR);
/*     */       
/* 112 */       this.resolver.put(e.getKey(), mr);
/*     */       
/* 114 */       this.cache.put(e.getKey(), new ConcurrentHashMap(4));
/*     */       
/* 116 */       for (Map.Entry<MediaType, List<ContextResolver>> f : ((Map)e.getValue()).entrySet()) {
/* 117 */         mr.put(f.getKey(), reduce((List)f.getValue()));
/*     */       }
/*     */     }
/*     */     
/*     */     Map<MediaType, ContextResolver> mr;
/*     */     
/* 123 */     ipf.add(new InjectableProvider() {
/*     */       public ComponentScope getScope() {
/* 125 */         return ComponentScope.Singleton;
/*     */       }
/*     */       
/*     */       public Injectable getInjectable(ComponentContext ic, Context ac, Type c) {
/* 129 */         if (!(c instanceof ParameterizedType))
/* 130 */           return null;
/* 131 */         ParameterizedType pType = (ParameterizedType)c;
/* 132 */         if (pType.getRawType() != ContextResolver.class)
/* 133 */           return null;
/* 134 */         Type type = pType.getActualTypeArguments()[0];
/*     */         
/*     */ 
/* 137 */         final ContextResolver cr = getResolver(ic, type);
/* 138 */         if (cr == null) {
/* 139 */           new Injectable() {
/*     */             public Object getValue() {
/* 141 */               return null;
/*     */             }
/*     */           };
/*     */         }
/* 145 */         new Injectable() {
/*     */           public Object getValue() {
/* 147 */             return cr;
/*     */           }
/*     */         };
/*     */       }
/*     */       
/*     */       ContextResolver getResolver(ComponentContext ic, Type type)
/*     */       {
/* 154 */         Map<MediaType, ContextResolver> x = (Map)ContextResolverFactory.this.resolver.get(type);
/* 155 */         if (x == null) {
/* 156 */           return null;
/*     */         }
/* 158 */         List<MediaType> ms = getMediaTypes(ic);
/* 159 */         if (ms.size() == 1) {
/* 160 */           return ContextResolverFactory.this.resolve(type, (MediaType)ms.get(0));
/*     */         }
/* 162 */         Set<MediaType> ml = new TreeSet(MediaTypes.MEDIA_TYPE_COMPARATOR);
/* 163 */         for (MediaType m : ms) {
/* 164 */           if (m.isWildcardType()) {
/* 165 */             ml.add(MediaTypes.GENERAL_MEDIA_TYPE);
/* 166 */           } else if (m.isWildcardSubtype()) {
/* 167 */             ml.add(new MediaType(m.getType(), "*"));
/* 168 */             ml.add(MediaTypes.GENERAL_MEDIA_TYPE);
/*     */           } else {
/* 170 */             ml.add(new MediaType(m.getType(), m.getSubtype()));
/* 171 */             ml.add(new MediaType(m.getType(), "*"));
/* 172 */             ml.add(MediaTypes.GENERAL_MEDIA_TYPE);
/*     */           }
/*     */         }
/* 175 */         List<ContextResolver> crl = new ArrayList(ml.size());
/* 176 */         for (MediaType m : ms) {
/* 177 */           ContextResolver cr = (ContextResolver)x.get(m);
/* 178 */           if (cr != null) crl.add(cr);
/*     */         }
/* 180 */         if (crl.isEmpty()) {
/* 181 */           return null;
/*     */         }
/* 183 */         return new ContextResolverFactory.ContextResolverAdapter(crl);
/*     */       }
/*     */       
/*     */       List<MediaType> getMediaTypes(ComponentContext ic)
/*     */       {
/* 188 */         Produces p = null;
/* 189 */         for (Annotation a : ic.getAnnotations()) {
/* 190 */           if ((a instanceof Produces)) {
/* 191 */             p = (Produces)a;
/* 192 */             break;
/*     */           }
/*     */         }
/*     */         
/* 196 */         return MediaTypes.createMediaTypes(p);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private Type getParameterizedType(Class c) {
/* 202 */     ReflectionHelper.DeclaringClassInterfacePair p = ReflectionHelper.getClass(c, ContextResolver.class);
/*     */     
/*     */ 
/* 205 */     Type[] as = ReflectionHelper.getParameterizedTypeArguments(p);
/*     */     
/* 207 */     return as != null ? as[0] : Object.class;
/*     */   }
/*     */   
/* 210 */   private static final NullContextResolverAdapter NULL_CONTEXT_RESOLVER = new NullContextResolverAdapter(null);
/*     */   
/*     */   private static final class NullContextResolverAdapter implements ContextResolver
/*     */   {
/*     */     public Object getContext(Class type) {
/* 215 */       throw new UnsupportedOperationException("Not supported yet.");
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class ContextResolverAdapter implements ContextResolver
/*     */   {
/*     */     private final ContextResolver[] cra;
/*     */     
/*     */     ContextResolverAdapter(ContextResolver... cra) {
/* 224 */       this(removeNull(cra));
/*     */     }
/*     */     
/*     */     ContextResolverAdapter(List<ContextResolver> crl) {
/* 228 */       this.cra = ((ContextResolver[])crl.toArray(new ContextResolver[crl.size()]));
/*     */     }
/*     */     
/*     */     public Object getContext(Class objectType) {
/* 232 */       for (ContextResolver cr : this.cra) {
/* 233 */         Object c = cr.getContext(objectType);
/* 234 */         if (c != null) return c;
/*     */       }
/* 236 */       return null;
/*     */     }
/*     */     
/*     */     ContextResolver reduce() {
/* 240 */       if (this.cra.length == 0)
/* 241 */         return ContextResolverFactory.NULL_CONTEXT_RESOLVER;
/* 242 */       if (this.cra.length == 1) {
/* 243 */         return this.cra[0];
/*     */       }
/* 245 */       return this;
/*     */     }
/*     */     
/*     */     private static List<ContextResolver> removeNull(ContextResolver... cra)
/*     */     {
/* 250 */       List<ContextResolver> crl = new ArrayList(cra.length);
/* 251 */       for (ContextResolver cr : cra) {
/* 252 */         if (cr != null) {
/* 253 */           crl.add(cr);
/*     */         }
/*     */       }
/* 256 */       return crl;
/*     */     }
/*     */   }
/*     */   
/*     */   private ContextResolver reduce(List<ContextResolver> r) {
/* 261 */     if (r.size() == 1) {
/* 262 */       return (ContextResolver)r.iterator().next();
/*     */     }
/* 264 */     return new ContextResolverAdapter(r);
/*     */   }
/*     */   
/*     */   public <T> ContextResolver<T> resolve(Type t, MediaType m)
/*     */   {
/* 269 */     ConcurrentHashMap<MediaType, ContextResolver> crMapCache = (ConcurrentHashMap)this.cache.get(t);
/* 270 */     if (crMapCache == null) { return null;
/*     */     }
/* 272 */     if (m == null) {
/* 273 */       m = MediaTypes.GENERAL_MEDIA_TYPE;
/*     */     }
/* 275 */     ContextResolver<T> cr = (ContextResolver)crMapCache.get(m);
/* 276 */     if (cr == null) {
/* 277 */       Map<MediaType, ContextResolver> crMap = (Map)this.resolver.get(t);
/*     */       
/* 279 */       if (m.isWildcardType()) {
/* 280 */         cr = (ContextResolver)crMap.get(MediaTypes.GENERAL_MEDIA_TYPE);
/* 281 */         if (cr == null) {
/* 282 */           cr = NULL_CONTEXT_RESOLVER;
/*     */         }
/* 284 */       } else if (m.isWildcardSubtype())
/*     */       {
/* 286 */         ContextResolver<T> subTypeWildCard = (ContextResolver)crMap.get(m);
/* 287 */         ContextResolver<T> wildCard = (ContextResolver)crMap.get(MediaTypes.GENERAL_MEDIA_TYPE);
/*     */         
/* 289 */         cr = new ContextResolverAdapter(new ContextResolver[] { subTypeWildCard, wildCard }).reduce();
/*     */       }
/*     */       else {
/* 292 */         ContextResolver<T> type = (ContextResolver)crMap.get(m);
/* 293 */         ContextResolver<T> subTypeWildCard = (ContextResolver)crMap.get(new MediaType(m.getType(), "*"));
/* 294 */         ContextResolver<T> wildCard = (ContextResolver)crMap.get(MediaType.WILDCARD_TYPE);
/*     */         
/* 296 */         cr = new ContextResolverAdapter(new ContextResolver[] { type, subTypeWildCard, wildCard }).reduce();
/*     */       }
/*     */       
/* 299 */       ContextResolver<T> _cr = (ContextResolver)crMapCache.putIfAbsent(m, cr);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 305 */       if (_cr != null) {
/* 306 */         cr = _cr;
/*     */       }
/*     */     }
/*     */     
/* 310 */     return cr != NULL_CONTEXT_RESOLVER ? cr : null;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\factory\ContextResolverFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */