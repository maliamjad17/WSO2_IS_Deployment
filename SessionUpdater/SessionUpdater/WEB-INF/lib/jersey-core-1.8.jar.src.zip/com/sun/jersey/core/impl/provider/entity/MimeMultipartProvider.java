/*     */ package com.sun.jersey.core.impl.provider.entity;
/*     */ 
/*     */ import com.sun.jersey.core.provider.AbstractMessageReaderWriterProvider;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.internet.MimeMultipart;
/*     */ import javax.mail.internet.ParseException;
/*     */ import javax.mail.util.ByteArrayDataSource;
/*     */ import javax.ws.rs.WebApplicationException;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.core.Response.Status;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MimeMultipartProvider
/*     */   extends AbstractMessageReaderWriterProvider<MimeMultipart>
/*     */ {
/*     */   public MimeMultipartProvider()
/*     */   {
/*  65 */     Class<?> c = MimeMultipart.class;
/*     */   }
/*     */   
/*     */   public boolean isReadable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
/*  69 */     return type == MimeMultipart.class;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MimeMultipart readFrom(Class<MimeMultipart> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, String> httpHeaders, InputStream entityStream)
/*     */     throws IOException
/*     */   {
/*  79 */     if (mediaType == null)
/*  80 */       mediaType = new MediaType("multipart", "form-data");
/*  81 */     ByteArrayDataSource ds = new ByteArrayDataSource(entityStream, mediaType.toString());
/*     */     try {
/*  83 */       return new MimeMultipart(ds);
/*     */     } catch (ParseException ex) {
/*  85 */       throw new WebApplicationException(ex, Response.Status.BAD_REQUEST);
/*     */     } catch (MessagingException ex) {
/*  87 */       throw new WebApplicationException(ex, Response.Status.INTERNAL_SERVER_ERROR);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
/*  92 */     return type == MimeMultipart.class;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeTo(MimeMultipart t, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, OutputStream entityStream)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 106 */       t.writeTo(entityStream);
/*     */     } catch (MessagingException ex) {
/* 108 */       throw new WebApplicationException(ex, Response.Status.INTERNAL_SERVER_ERROR);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\entity\MimeMultipartProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */