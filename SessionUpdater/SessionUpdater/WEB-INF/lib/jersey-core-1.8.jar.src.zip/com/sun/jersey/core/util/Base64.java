/*     */ package com.sun.jersey.core.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Base64
/*     */ {
/*     */   private static final int BASELENGTH = 255;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int LOOKUPLENGTH = 64;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int TWENTYFOURBITGROUP = 24;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int EIGHTBIT = 8;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int SIXTEENBIT = 16;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int SIXBIT = 6;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int FOURBYTE = 4;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int SIGN = -128;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final byte PAD = 61;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  81 */   private static byte[] base64Alphabet = new byte['ÿ'];
/*  82 */   private static byte[] lookUpBase64Alphabet = new byte[64];
/*     */   
/*     */   static
/*     */   {
/*  86 */     for (int i = 0; i < 255; i++)
/*     */     {
/*  88 */       base64Alphabet[i] = -1;
/*     */     }
/*  90 */     for (int i = 90; i >= 65; i--)
/*     */     {
/*  92 */       base64Alphabet[i] = ((byte)(i - 65));
/*     */     }
/*  94 */     for (int i = 122; i >= 97; i--)
/*     */     {
/*  96 */       base64Alphabet[i] = ((byte)(i - 97 + 26));
/*     */     }
/*  98 */     for (int i = 57; i >= 48; i--)
/*     */     {
/* 100 */       base64Alphabet[i] = ((byte)(i - 48 + 52));
/*     */     }
/*     */     
/* 103 */     base64Alphabet[43] = 62;
/* 104 */     base64Alphabet[47] = 63;
/*     */     
/* 106 */     for (int i = 0; i <= 25; i++) {
/* 107 */       lookUpBase64Alphabet[i] = ((byte)(65 + i));
/*     */     }
/* 109 */     int i = 26; for (int j = 0; i <= 51; j++) {
/* 110 */       lookUpBase64Alphabet[i] = ((byte)(97 + j));i++;
/*     */     }
/* 112 */     int i = 52; for (int j = 0; i <= 61; j++) {
/* 113 */       lookUpBase64Alphabet[i] = ((byte)(48 + j));i++;
/*     */     }
/* 115 */     lookUpBase64Alphabet[62] = 43;
/* 116 */     lookUpBase64Alphabet[63] = 47;
/*     */   }
/*     */   
/*     */   public static boolean isBase64(String isValidString)
/*     */   {
/* 121 */     return isArrayByteBase64(isValidString.getBytes());
/*     */   }
/*     */   
/*     */ 
/*     */   public static boolean isBase64(byte octect)
/*     */   {
/* 127 */     return (octect == 61) || (base64Alphabet[octect] != -1);
/*     */   }
/*     */   
/*     */   public static boolean isArrayByteBase64(byte[] arrayOctect)
/*     */   {
/* 132 */     int length = arrayOctect.length;
/* 133 */     if (length == 0)
/*     */     {
/*     */ 
/*     */ 
/* 137 */       return true;
/*     */     }
/* 139 */     for (int i = 0; i < length; i++)
/*     */     {
/* 141 */       if (!isBase64(arrayOctect[i]))
/* 142 */         return false;
/*     */     }
/* 144 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] encode(byte[] binaryData)
/*     */   {
/* 155 */     int lengthDataBits = binaryData.length * 8;
/* 156 */     int fewerThan24bits = lengthDataBits % 24;
/* 157 */     int numberTriplets = lengthDataBits / 24;
/* 158 */     byte[] encodedData = null;
/*     */     
/*     */ 
/* 161 */     if (fewerThan24bits != 0)
/*     */     {
/*     */ 
/* 164 */       encodedData = new byte[(numberTriplets + 1) * 4];
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 169 */       encodedData = new byte[numberTriplets * 4];
/*     */     }
/*     */     
/* 172 */     byte k = 0;byte l = 0;byte b1 = 0;byte b2 = 0;byte b3 = 0;
/*     */     
/* 174 */     int encodedIndex = 0;
/* 175 */     int dataIndex = 0;
/* 176 */     int i = 0;
/* 177 */     for (i = 0; i < numberTriplets; i++)
/*     */     {
/* 179 */       dataIndex = i * 3;
/* 180 */       b1 = binaryData[dataIndex];
/* 181 */       b2 = binaryData[(dataIndex + 1)];
/* 182 */       b3 = binaryData[(dataIndex + 2)];
/*     */       
/* 184 */       l = (byte)(b2 & 0xF);
/* 185 */       k = (byte)(b1 & 0x3);
/*     */       
/* 187 */       encodedIndex = i * 4;
/* 188 */       byte val1 = (b1 & 0xFFFFFF80) == 0 ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/* 189 */       byte val2 = (b2 & 0xFFFFFF80) == 0 ? (byte)(b2 >> 4) : (byte)(b2 >> 4 ^ 0xF0);
/* 190 */       byte val3 = (b3 & 0xFFFFFF80) == 0 ? (byte)(b3 >> 6) : (byte)(b3 >> 6 ^ 0xFC);
/*     */       
/* 192 */       encodedData[encodedIndex] = lookUpBase64Alphabet[val1];
/* 193 */       encodedData[(encodedIndex + 1)] = lookUpBase64Alphabet[(val2 | k << 4)];
/*     */       
/* 195 */       encodedData[(encodedIndex + 2)] = lookUpBase64Alphabet[(l << 2 | val3)];
/*     */       
/* 197 */       encodedData[(encodedIndex + 3)] = lookUpBase64Alphabet[(b3 & 0x3F)];
/*     */     }
/*     */     
/*     */ 
/* 201 */     dataIndex = i * 3;
/* 202 */     encodedIndex = i * 4;
/* 203 */     if (fewerThan24bits == 8)
/*     */     {
/* 205 */       b1 = binaryData[dataIndex];
/* 206 */       k = (byte)(b1 & 0x3);
/* 207 */       byte val1 = (b1 & 0xFFFFFF80) == 0 ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/* 208 */       encodedData[encodedIndex] = lookUpBase64Alphabet[val1];
/* 209 */       encodedData[(encodedIndex + 1)] = lookUpBase64Alphabet[(k << 4)];
/* 210 */       encodedData[(encodedIndex + 2)] = 61;
/* 211 */       encodedData[(encodedIndex + 3)] = 61;
/*     */     }
/* 213 */     else if (fewerThan24bits == 16)
/*     */     {
/*     */ 
/* 216 */       b1 = binaryData[dataIndex];
/* 217 */       b2 = binaryData[(dataIndex + 1)];
/* 218 */       l = (byte)(b2 & 0xF);
/* 219 */       k = (byte)(b1 & 0x3);
/*     */       
/* 221 */       byte val1 = (b1 & 0xFFFFFF80) == 0 ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/* 222 */       byte val2 = (b2 & 0xFFFFFF80) == 0 ? (byte)(b2 >> 4) : (byte)(b2 >> 4 ^ 0xF0);
/*     */       
/* 224 */       encodedData[encodedIndex] = lookUpBase64Alphabet[val1];
/* 225 */       encodedData[(encodedIndex + 1)] = lookUpBase64Alphabet[(val2 | k << 4)];
/*     */       
/* 227 */       encodedData[(encodedIndex + 2)] = lookUpBase64Alphabet[(l << 2)];
/* 228 */       encodedData[(encodedIndex + 3)] = 61;
/*     */     }
/*     */     
/* 231 */     return encodedData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] decode(byte[] base64Data)
/*     */   {
/* 243 */     if (base64Data.length == 0) { return new byte[0];
/*     */     }
/* 245 */     int numberQuadruple = base64Data.length / 4;
/* 246 */     byte[] decodedData = null;
/* 247 */     byte b1 = 0;byte b2 = 0;byte b3 = 0;byte b4 = 0;byte marker0 = 0;byte marker1 = 0;
/*     */     
/*     */ 
/*     */ 
/* 251 */     int encodedIndex = 0;
/* 252 */     int dataIndex = 0;
/*     */     
/*     */ 
/* 255 */     int lastData = base64Data.length;
/*     */     
/* 257 */     while (base64Data[(lastData - 1)] == 61)
/*     */     {
/* 259 */       lastData--; if (lastData == 0)
/*     */       {
/* 261 */         return new byte[0];
/*     */       }
/*     */     }
/* 264 */     decodedData = new byte[lastData - numberQuadruple];
/*     */     
/*     */ 
/* 267 */     for (int i = 0; i < numberQuadruple; i++)
/*     */     {
/* 269 */       dataIndex = i * 4;
/* 270 */       marker0 = base64Data[(dataIndex + 2)];
/* 271 */       marker1 = base64Data[(dataIndex + 3)];
/*     */       
/* 273 */       b1 = base64Alphabet[base64Data[dataIndex]];
/* 274 */       b2 = base64Alphabet[base64Data[(dataIndex + 1)]];
/*     */       
/* 276 */       if ((marker0 != 61) && (marker1 != 61))
/*     */       {
/*     */ 
/* 279 */         b3 = base64Alphabet[marker0];
/* 280 */         b4 = base64Alphabet[marker1];
/*     */         
/* 282 */         decodedData[encodedIndex] = ((byte)(b1 << 2 | b2 >> 4));
/* 283 */         decodedData[(encodedIndex + 1)] = ((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/*     */         
/* 285 */         decodedData[(encodedIndex + 2)] = ((byte)(b3 << 6 | b4));
/*     */       }
/* 287 */       else if (marker0 == 61)
/*     */       {
/*     */ 
/* 290 */         decodedData[encodedIndex] = ((byte)(b1 << 2 | b2 >> 4));
/*     */       }
/* 292 */       else if (marker1 == 61)
/*     */       {
/*     */ 
/* 295 */         b3 = base64Alphabet[marker0];
/*     */         
/* 297 */         decodedData[encodedIndex] = ((byte)(b1 << 2 | b2 >> 4));
/* 298 */         decodedData[(encodedIndex + 1)] = ((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/*     */       }
/*     */       
/* 301 */       encodedIndex += 3;
/*     */     }
/* 303 */     return decodedData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] encode(String data)
/*     */   {
/* 313 */     return encode(data.getBytes());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] decode(String data)
/*     */   {
/* 323 */     return decode(data.getBytes());
/*     */   }
/*     */   
/* 326 */   static final int[] base64 = { 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 62, 64, 64, 64, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 64, 64, 64, 64, 64, 64, 64, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 64, 64, 64, 64, 64, 64, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String base64Decode(String orig)
/*     */   {
/* 346 */     char[] chars = orig.toCharArray();
/* 347 */     StringBuilder sb = new StringBuilder();
/* 348 */     int i = 0;
/*     */     
/* 350 */     int shift = 0;
/* 351 */     int acc = 0;
/*     */     
/* 353 */     for (i = 0; i < chars.length; i++) {
/* 354 */       int v = base64[(chars[i] & 0xFF)];
/*     */       
/* 356 */       if (v < 64)
/*     */       {
/*     */ 
/* 359 */         acc = acc << 6 | v;
/* 360 */         shift += 6;
/* 361 */         if (shift >= 8) {
/* 362 */           shift -= 8;
/* 363 */           sb.append((char)(acc >> shift & 0xFF));
/*     */         }
/*     */       }
/*     */     }
/* 367 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\util\Base64.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */