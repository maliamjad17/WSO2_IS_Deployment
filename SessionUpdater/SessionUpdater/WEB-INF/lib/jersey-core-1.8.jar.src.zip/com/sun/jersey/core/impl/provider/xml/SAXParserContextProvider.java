/*    */ package com.sun.jersey.core.impl.provider.xml;
/*    */ 
/*    */ import com.sun.jersey.core.util.FeaturesAndProperties;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ import javax.ws.rs.core.Context;
/*    */ import javax.xml.parsers.SAXParserFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SAXParserContextProvider
/*    */   extends ThreadLocalSingletonContextProvider<SAXParserFactory>
/*    */ {
/* 55 */   private static final Logger LOGGER = Logger.getLogger(SAXParserContextProvider.class.getName());
/*    */   
/*    */   private final boolean disableXmlSecurity;
/*    */   
/*    */   public SAXParserContextProvider(@Context FeaturesAndProperties fps)
/*    */   {
/* 61 */     super(SAXParserFactory.class);
/*    */     
/* 63 */     this.disableXmlSecurity = fps.getFeature("com.sun.jersey.config.feature.DisableXmlSecurity");
/*    */   }
/*    */   
/*    */   protected SAXParserFactory getInstance()
/*    */   {
/* 68 */     SAXParserFactory f = SAXParserFactory.newInstance();
/*    */     
/* 70 */     f.setNamespaceAware(true);
/*    */     
/* 72 */     if (!this.disableXmlSecurity) {
/*    */       try {
/* 74 */         f.setFeature("http://xml.org/sax/features/external-general-entities", Boolean.FALSE.booleanValue());
/*    */       } catch (Exception ex) {
/* 76 */         throw new RuntimeException("Security features for the SAX parser could not be enabled", ex);
/*    */       }
/*    */       try
/*    */       {
/* 80 */         f.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", Boolean.TRUE.booleanValue());
/*    */       } catch (Exception ex) {
/* 82 */         LOGGER.log(Level.WARNING, "JAXP feature XMLConstants.FEATURE_SECURE_PROCESSING cannot be set on a SAXParserFactory. External general entity processing is disabled but other potential security related features will not be enabled.", ex);
/*    */       }
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 90 */     return f;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\xml\SAXParserContextProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */