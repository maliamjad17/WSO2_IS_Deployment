/*     */ package com.sun.jersey.core.header;
/*     */ 
/*     */ import com.sun.jersey.core.header.reader.HttpHeaderReader;
/*     */ import java.text.ParseException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.ws.rs.Consumes;
/*     */ import javax.ws.rs.Produces;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MediaTypes
/*     */ {
/*  64 */   public static final MediaType WADL = MediaType.valueOf("application/vnd.sun.wadl+xml");
/*     */   
/*     */ 
/*  67 */   public static final MediaType FAST_INFOSET = MediaType.valueOf("application/fastinfoset");
/*     */   
/*     */   public static final boolean typeEquals(MediaType m1, MediaType m2)
/*     */   {
/*  71 */     if ((m1 == null) || (m2 == null)) {
/*  72 */       return false;
/*     */     }
/*  74 */     return (m1.getSubtype().equalsIgnoreCase(m2.getSubtype())) && (m1.getType().equalsIgnoreCase(m2.getType()));
/*     */   }
/*     */   
/*     */   public static final boolean intersects(List<? extends MediaType> ml1, List<? extends MediaType> ml2) {
/*  78 */     for (Iterator i$ = ml1.iterator(); i$.hasNext();) { m1 = (MediaType)i$.next();
/*  79 */       for (MediaType m2 : ml2)
/*  80 */         if (typeEquals(m1, m2))
/*  81 */           return true;
/*     */     }
/*     */     MediaType m1;
/*  84 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  92 */   public static final Comparator<MediaType> MEDIA_TYPE_COMPARATOR = new Comparator() {
/*     */     public int compare(MediaType o1, MediaType o2) {
/*  94 */       if ((o1.getType().equals("*")) && (!o2.getType().equals("*"))) {
/*  95 */         return 1;
/*     */       }
/*     */       
/*  98 */       if ((o2.getType().equals("*")) && (!o1.getType().equals("*"))) {
/*  99 */         return -1;
/*     */       }
/*     */       
/* 102 */       if ((o1.getSubtype().equals("*")) && (!o2.getSubtype().equals("*"))) {
/* 103 */         return 1;
/*     */       }
/*     */       
/* 106 */       if ((o2.getSubtype().equals("*")) && (!o1.getSubtype().equals("*"))) {
/* 107 */         return -1;
/*     */       }
/*     */       
/* 110 */       return 0;
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final MediaType mostSpecific(MediaType m1, MediaType m2)
/*     */   {
/* 125 */     if ((m1.isWildcardSubtype()) && (!m2.isWildcardSubtype()))
/* 126 */       return m2;
/* 127 */     if ((m1.isWildcardType()) && (!m2.isWildcardType()))
/* 128 */       return m2;
/* 129 */     return m1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 141 */   public static final Comparator<List<? extends MediaType>> MEDIA_TYPE_LIST_COMPARATOR = new Comparator()
/*     */   {
/*     */     public int compare(List<? extends MediaType> o1, List<? extends MediaType> o2) {
/* 144 */       return MediaTypes.MEDIA_TYPE_COMPARATOR.compare(getLeastSpecific(o1), getLeastSpecific(o2));
/*     */     }
/*     */     
/*     */     public MediaType getLeastSpecific(List<? extends MediaType> l) {
/* 148 */       return (MediaType)l.get(l.size() - 1);
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 156 */   public static final MediaType GENERAL_MEDIA_TYPE = new MediaType("*", "*");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 161 */   public static final List<MediaType> GENERAL_MEDIA_TYPE_LIST = createMediaTypeList();
/*     */   
/*     */   private static List<MediaType> createMediaTypeList()
/*     */   {
/* 165 */     return Collections.singletonList(GENERAL_MEDIA_TYPE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 173 */   public static final AcceptableMediaType GENERAL_ACCEPT_MEDIA_TYPE = new AcceptableMediaType("*", "*");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 179 */   public static final List<AcceptableMediaType> GENERAL_ACCEPT_MEDIA_TYPE_LIST = createAcceptMediaTypeList();
/*     */   
/*     */   private static List<AcceptableMediaType> createAcceptMediaTypeList()
/*     */   {
/* 183 */     return Collections.singletonList(GENERAL_ACCEPT_MEDIA_TYPE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<MediaType> createMediaTypes(Consumes mime)
/*     */   {
/* 193 */     if (mime == null) {
/* 194 */       return GENERAL_MEDIA_TYPE_LIST;
/*     */     }
/*     */     
/* 197 */     return createMediaTypes(mime.value());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<MediaType> createMediaTypes(Produces mime)
/*     */   {
/* 207 */     if (mime == null) {
/* 208 */       return GENERAL_MEDIA_TYPE_LIST;
/*     */     }
/*     */     
/* 211 */     return createMediaTypes(mime.value());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<MediaType> createMediaTypes(String[] mediaTypes)
/*     */   {
/* 221 */     List<MediaType> l = new ArrayList();
/*     */     try {
/* 223 */       for (String mediaType : mediaTypes) {
/* 224 */         HttpHeaderReader.readMediaTypes(l, mediaType);
/*     */       }
/*     */       
/* 227 */       Collections.sort(l, MEDIA_TYPE_COMPARATOR);
/* 228 */       return l;
/*     */     } catch (ParseException ex) {
/* 230 */       throw new IllegalArgumentException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 237 */   public static final Comparator<QualitySourceMediaType> QUALITY_SOURCE_MEDIA_TYPE_COMPARATOR = new Comparator()
/*     */   {
/*     */     public int compare(QualitySourceMediaType o1, QualitySourceMediaType o2) {
/* 240 */       int i = o2.getQualitySource() - o1.getQualitySource();
/* 241 */       if (i != 0) {
/* 242 */         return i;
/*     */       }
/* 244 */       return MediaTypes.MEDIA_TYPE_COMPARATOR.compare(o1, o2);
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 251 */   public static final List<MediaType> GENERAL_QUALITY_SOURCE_MEDIA_TYPE_LIST = createQualitySourceMediaTypeList();
/*     */   
/*     */   private static List<MediaType> createQualitySourceMediaTypeList()
/*     */   {
/* 255 */     return Collections.singletonList(new QualitySourceMediaType("*", "*"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<MediaType> createQualitySourceMediaTypes(Produces mime)
/*     */   {
/* 266 */     if (mime == null) {
/* 267 */       return GENERAL_QUALITY_SOURCE_MEDIA_TYPE_LIST;
/*     */     }
/*     */     
/* 270 */     return new ArrayList(createQualitySourceMediaTypes(mime.value()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<QualitySourceMediaType> createQualitySourceMediaTypes(String[] mediaTypes)
/*     */   {
/*     */     try
/*     */     {
/* 283 */       return HttpHeaderReader.readQualitySourceMediaType(mediaTypes);
/*     */     } catch (ParseException ex) {
/* 285 */       throw new IllegalArgumentException(ex);
/*     */     }
/*     */   }
/*     */   
/* 289 */   private static Map<String, MediaType> mediaTypeCache = new HashMap() {};
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MediaType getTypeWildCart(MediaType mediaType)
/*     */   {
/* 304 */     MediaType mt = (MediaType)mediaTypeCache.get(mediaType.getType());
/*     */     
/* 306 */     if (mt == null) {
/* 307 */       mt = new MediaType(mediaType.getType(), "*");
/*     */     }
/*     */     
/* 310 */     return mt;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\header\MediaTypes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */