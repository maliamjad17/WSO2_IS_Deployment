/*     */ package com.sun.jersey.impl;
/*     */ 
/*     */ import com.sun.jersey.localization.Localizable;
/*     */ import com.sun.jersey.localization.LocalizableMessageFactory;
/*     */ import com.sun.jersey.localization.Localizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ImplMessages
/*     */ {
/*  15 */   private static final LocalizableMessageFactory messageFactory = new LocalizableMessageFactory("com.sun.jersey.impl.impl");
/*  16 */   private static final Localizer localizer = new Localizer();
/*     */   
/*     */   public static Localizable localizableERROR_NO_SUB_RES_METHOD_LOCATOR_FOUND(Object arg0) {
/*  19 */     return messageFactory.getMessage("error.no.sub.res.method.locator.found", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String ERROR_NO_SUB_RES_METHOD_LOCATOR_FOUND(Object arg0)
/*     */   {
/*  27 */     return localizer.localize(localizableERROR_NO_SUB_RES_METHOD_LOCATOR_FOUND(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableQUALITY_GREATER_THAN_ONE(Object arg0) {
/*  31 */     return messageFactory.getMessage("quality.greater.than.one", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String QUALITY_GREATER_THAN_ONE(Object arg0)
/*     */   {
/*  39 */     return localizer.localize(localizableQUALITY_GREATER_THAN_ONE(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableAMBIGUOUS_SRMS_OUT(Object arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7) {
/*  43 */     return messageFactory.getMessage("ambiguous.srms.out", new Object[] { arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String AMBIGUOUS_SRMS_OUT(Object arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7)
/*     */   {
/*  51 */     return localizer.localize(localizableAMBIGUOUS_SRMS_OUT(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7));
/*     */   }
/*     */   
/*     */   public static Localizable localizableAMBIGUOUS_RMS_OUT(Object arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6) {
/*  55 */     return messageFactory.getMessage("ambiguous.rms.out", new Object[] { arg0, arg1, arg2, arg3, arg4, arg5, arg6 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String AMBIGUOUS_RMS_OUT(Object arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6)
/*     */   {
/*  63 */     return localizer.localize(localizableAMBIGUOUS_RMS_OUT(arg0, arg1, arg2, arg3, arg4, arg5, arg6));
/*     */   }
/*     */   
/*     */   public static Localizable localizableAMBIGUOUS_RMS_IN(Object arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6) {
/*  67 */     return messageFactory.getMessage("ambiguous.rms.in", new Object[] { arg0, arg1, arg2, arg3, arg4, arg5, arg6 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String AMBIGUOUS_RMS_IN(Object arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6)
/*     */   {
/*  75 */     return localizer.localize(localizableAMBIGUOUS_RMS_IN(arg0, arg1, arg2, arg3, arg4, arg5, arg6));
/*     */   }
/*     */   
/*     */   public static Localizable localizableDEFAULT_COULD_NOT_PROCESS_METHOD(Object arg0, Object arg1) {
/*  79 */     return messageFactory.getMessage("default.could.not.process.method", new Object[] { arg0, arg1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String DEFAULT_COULD_NOT_PROCESS_METHOD(Object arg0, Object arg1)
/*     */   {
/*  87 */     return localizer.localize(localizableDEFAULT_COULD_NOT_PROCESS_METHOD(arg0, arg1));
/*     */   }
/*     */   
/*     */   public static Localizable localizableNESTED_ERROR(Object arg0) {
/*  91 */     return messageFactory.getMessage("nested.error", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String NESTED_ERROR(Object arg0)
/*     */   {
/*  99 */     return localizer.localize(localizableNESTED_ERROR(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableAMBIGUOUS_SRMS_IN(Object arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7) {
/* 103 */     return messageFactory.getMessage("ambiguous.srms.in", new Object[] { arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String AMBIGUOUS_SRMS_IN(Object arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7)
/*     */   {
/* 111 */     return localizer.localize(localizableAMBIGUOUS_SRMS_IN(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7));
/*     */   }
/*     */   
/*     */   public static Localizable localizableSUB_RES_METHOD_TREATED_AS_RES_METHOD(Object arg0, Object arg1) {
/* 115 */     return messageFactory.getMessage("sub.res.method.treated.as.res.method", new Object[] { arg0, arg1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String SUB_RES_METHOD_TREATED_AS_RES_METHOD(Object arg0, Object arg1)
/*     */   {
/* 123 */     return localizer.localize(localizableSUB_RES_METHOD_TREATED_AS_RES_METHOD(arg0, arg1));
/*     */   }
/*     */   
/*     */   public static Localizable localizableMULTIPLE_HTTP_METHOD_DESIGNATORS(Object arg0, Object arg1) {
/* 127 */     return messageFactory.getMessage("multiple.http.method.designators", new Object[] { arg0, arg1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String MULTIPLE_HTTP_METHOD_DESIGNATORS(Object arg0, Object arg1)
/*     */   {
/* 135 */     return localizer.localize(localizableMULTIPLE_HTTP_METHOD_DESIGNATORS(arg0, arg1));
/*     */   }
/*     */   
/*     */   public static Localizable localizableAMBIGUOUS_CTORS(Object arg0) {
/* 139 */     return messageFactory.getMessage("ambiguous.ctors", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String AMBIGUOUS_CTORS(Object arg0)
/*     */   {
/* 147 */     return localizer.localize(localizableAMBIGUOUS_CTORS(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableFAILED_TO_CREATE_WEB_RESOURCE(Object arg0) {
/* 151 */     return messageFactory.getMessage("failed.to.create.web.resource", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String FAILED_TO_CREATE_WEB_RESOURCE(Object arg0)
/*     */   {
/* 159 */     return localizer.localize(localizableFAILED_TO_CREATE_WEB_RESOURCE(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableERROR_GET_RETURNS_VOID(Object arg0) {
/* 163 */     return messageFactory.getMessage("error.get.returns.void", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String ERROR_GET_RETURNS_VOID(Object arg0)
/*     */   {
/* 171 */     return localizer.localize(localizableERROR_GET_RETURNS_VOID(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableERROR_RES_URI_PATH_INVALID(Object arg0, Object arg1) {
/* 175 */     return messageFactory.getMessage("error.res.uri.path.invalid", new Object[] { arg0, arg1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String ERROR_RES_URI_PATH_INVALID(Object arg0, Object arg1)
/*     */   {
/* 183 */     return localizer.localize(localizableERROR_RES_URI_PATH_INVALID(arg0, arg1));
/*     */   }
/*     */   
/*     */   public static Localizable localizableILLEGAL_PROVIDER_CLASS_NAME(Object arg0) {
/* 187 */     return messageFactory.getMessage("illegal.provider.class.name", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String ILLEGAL_PROVIDER_CLASS_NAME(Object arg0)
/*     */   {
/* 195 */     return localizer.localize(localizableILLEGAL_PROVIDER_CLASS_NAME(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableERROR_PROCESSING_METHOD(Object arg0, Object arg1) {
/* 199 */     return messageFactory.getMessage("error.processing.method", new Object[] { arg0, arg1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String ERROR_PROCESSING_METHOD(Object arg0, Object arg1)
/*     */   {
/* 207 */     return localizer.localize(localizableERROR_PROCESSING_METHOD(arg0, arg1));
/*     */   }
/*     */   
/*     */   public static Localizable localizableBAD_URITEMPLATE(Object arg0, Object arg1) {
/* 211 */     return messageFactory.getMessage("bad.uritemplate", new Object[] { arg0, arg1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String BAD_URITEMPLATE(Object arg0, Object arg1)
/*     */   {
/* 219 */     return localizer.localize(localizableBAD_URITEMPLATE(arg0, arg1));
/*     */   }
/*     */   
/*     */   public static Localizable localizableRESOURCE_NOT_ACCEPTABLE(Object arg0, Object arg1) {
/* 223 */     return messageFactory.getMessage("resource.not.acceptable", new Object[] { arg0, arg1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String RESOURCE_NOT_ACCEPTABLE(Object arg0, Object arg1)
/*     */   {
/* 231 */     return localizer.localize(localizableRESOURCE_NOT_ACCEPTABLE(arg0, arg1));
/*     */   }
/*     */   
/*     */   public static Localizable localizableGENERIC_TYPE_NOT_SUPPORTED(Object arg0, Object arg1) {
/* 235 */     return messageFactory.getMessage("generic.type.not.supported", new Object[] { arg0, arg1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String GENERIC_TYPE_NOT_SUPPORTED(Object arg0, Object arg1)
/*     */   {
/* 243 */     return localizer.localize(localizableGENERIC_TYPE_NOT_SUPPORTED(arg0, arg1));
/*     */   }
/*     */   
/*     */   public static Localizable localizableBAD_CONTENT_TYPE(Object arg0) {
/* 247 */     return messageFactory.getMessage("bad.content.type", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String BAD_CONTENT_TYPE(Object arg0)
/*     */   {
/* 255 */     return localizer.localize(localizableBAD_CONTENT_TYPE(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableERROR_SUBRES_LOC_URI_PATH_INVALID(Object arg0, Object arg1) {
/* 259 */     return messageFactory.getMessage("error.subres.loc.uri.path.invalid", new Object[] { arg0, arg1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String ERROR_SUBRES_LOC_URI_PATH_INVALID(Object arg0, Object arg1)
/*     */   {
/* 267 */     return localizer.localize(localizableERROR_SUBRES_LOC_URI_PATH_INVALID(arg0, arg1));
/*     */   }
/*     */   
/*     */   public static Localizable localizableNOT_VALID_HTTPMETHOD(Object arg0, Object arg1, Object arg2) {
/* 271 */     return messageFactory.getMessage("not.valid.httpmethod", new Object[] { arg0, arg1, arg2 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String NOT_VALID_HTTPMETHOD(Object arg0, Object arg1, Object arg2)
/*     */   {
/* 279 */     return localizer.localize(localizableNOT_VALID_HTTPMETHOD(arg0, arg1, arg2));
/*     */   }
/*     */   
/*     */   public static Localizable localizableNON_PUB_SUB_RES_LOC(Object arg0) {
/* 283 */     return messageFactory.getMessage("non.pub.sub.res.loc", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String NON_PUB_SUB_RES_LOC(Object arg0)
/*     */   {
/* 291 */     return localizer.localize(localizableNON_PUB_SUB_RES_LOC(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableERROR_GET_CONSUMES_ENTITY(Object arg0) {
/* 295 */     return messageFactory.getMessage("error.get.consumes.entity", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String ERROR_GET_CONSUMES_ENTITY(Object arg0)
/*     */   {
/* 303 */     return localizer.localize(localizableERROR_GET_CONSUMES_ENTITY(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableWEB_APP_ALREADY_INITIATED() {
/* 307 */     return messageFactory.getMessage("web.app.already.initiated", new Object[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String WEB_APP_ALREADY_INITIATED()
/*     */   {
/* 315 */     return localizer.localize(localizableWEB_APP_ALREADY_INITIATED());
/*     */   }
/*     */   
/*     */   public static Localizable localizableAMBIGUOUS_SRLS(Object arg0, Object arg1, Object arg2) {
/* 319 */     return messageFactory.getMessage("ambiguous.srls", new Object[] { arg0, arg1, arg2 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String AMBIGUOUS_SRLS(Object arg0, Object arg1, Object arg2)
/*     */   {
/* 327 */     return localizer.localize(localizableAMBIGUOUS_SRLS(arg0, arg1, arg2));
/*     */   }
/*     */   
/*     */   public static Localizable localizableERROR_UNMARSHALLING_JAXB(Object arg0) {
/* 331 */     return messageFactory.getMessage("error.unmarshalling.jaxb", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String ERROR_UNMARSHALLING_JAXB(Object arg0)
/*     */   {
/* 339 */     return localizer.localize(localizableERROR_UNMARSHALLING_JAXB(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableBAD_CLASS_CONSUMEMIME(Object arg0, Object arg1) {
/* 343 */     return messageFactory.getMessage("bad.class.consumemime", new Object[] { arg0, arg1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String BAD_CLASS_CONSUMEMIME(Object arg0, Object arg1)
/*     */   {
/* 351 */     return localizer.localize(localizableBAD_CLASS_CONSUMEMIME(arg0, arg1));
/*     */   }
/*     */   
/*     */   public static Localizable localizableERROR_SUBRES_METHOD_URI_PATH_INVALID(Object arg0, Object arg1) {
/* 355 */     return messageFactory.getMessage("error.subres.method.uri.path.invalid", new Object[] { arg0, arg1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String ERROR_SUBRES_METHOD_URI_PATH_INVALID(Object arg0, Object arg1)
/*     */   {
/* 363 */     return localizer.localize(localizableERROR_SUBRES_METHOD_URI_PATH_INVALID(arg0, arg1));
/*     */   }
/*     */   
/*     */   public static Localizable localizableBAD_METHOD_CONSUMEMIME(Object arg0, Object arg1, Object arg2) {
/* 367 */     return messageFactory.getMessage("bad.method.consumemime", new Object[] { arg0, arg1, arg2 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String BAD_METHOD_CONSUMEMIME(Object arg0, Object arg1, Object arg2)
/*     */   {
/* 375 */     return localizer.localize(localizableBAD_METHOD_CONSUMEMIME(arg0, arg1, arg2));
/*     */   }
/*     */   
/*     */   public static Localizable localizableILLEGAL_INITIAL_CAPACITY(Object arg0) {
/* 379 */     return messageFactory.getMessage("illegal.initial.capacity", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String ILLEGAL_INITIAL_CAPACITY(Object arg0)
/*     */   {
/* 387 */     return localizer.localize(localizableILLEGAL_INITIAL_CAPACITY(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableNEW_AR_CREATED_BY_INTROSPECTION_MODELER(Object arg0) {
/* 391 */     return messageFactory.getMessage("new.ar.created.by.introspection.modeler", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String NEW_AR_CREATED_BY_INTROSPECTION_MODELER(Object arg0)
/*     */   {
/* 399 */     return localizer.localize(localizableNEW_AR_CREATED_BY_INTROSPECTION_MODELER(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableOBJECT_NOT_A_WEB_RESOURCE(Object arg0) {
/* 403 */     return messageFactory.getMessage("object.not.a.webResource", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String OBJECT_NOT_A_WEB_RESOURCE(Object arg0)
/*     */   {
/* 411 */     return localizer.localize(localizableOBJECT_NOT_A_WEB_RESOURCE(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableAMBIGUOUS_PARAMETER(Object arg0, Object arg1) {
/* 415 */     return messageFactory.getMessage("ambiguous.parameter", new Object[] { arg0, arg1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String AMBIGUOUS_PARAMETER(Object arg0, Object arg1)
/*     */   {
/* 423 */     return localizer.localize(localizableAMBIGUOUS_PARAMETER(arg0, arg1));
/*     */   }
/*     */   
/*     */   public static Localizable localizableERROR_RES_URI_PATH_REQUIRED(Object arg0) {
/* 427 */     return messageFactory.getMessage("error.res.uri.path.required", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String ERROR_RES_URI_PATH_REQUIRED(Object arg0)
/*     */   {
/* 435 */     return localizer.localize(localizableERROR_RES_URI_PATH_REQUIRED(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableQUALITY_MORE_THAN_THREE(Object arg0) {
/* 439 */     return messageFactory.getMessage("quality.more.than.three", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String QUALITY_MORE_THAN_THREE(Object arg0)
/*     */   {
/* 447 */     return localizer.localize(localizableQUALITY_MORE_THAN_THREE(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableBAD_CONSUMEMIME(Object arg0, Object arg1, Object arg2) {
/* 451 */     return messageFactory.getMessage("bad.consumemime", new Object[] { arg0, arg1, arg2 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String BAD_CONSUMEMIME(Object arg0, Object arg1, Object arg2)
/*     */   {
/* 459 */     return localizer.localize(localizableBAD_CONSUMEMIME(arg0, arg1, arg2));
/*     */   }
/*     */   
/*     */   public static Localizable localizableUNABLE_TO_WRITE_MIMEMULTIPART() {
/* 463 */     return messageFactory.getMessage("unable.to.write.mimemultipart", new Object[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String UNABLE_TO_WRITE_MIMEMULTIPART()
/*     */   {
/* 471 */     return localizer.localize(localizableUNABLE_TO_WRITE_MIMEMULTIPART());
/*     */   }
/*     */   
/*     */   public static Localizable localizableNON_PUB_SUB_RES_METHOD(Object arg0) {
/* 475 */     return messageFactory.getMessage("non.pub.sub.res.method", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String NON_PUB_SUB_RES_METHOD(Object arg0)
/*     */   {
/* 483 */     return localizer.localize(localizableNON_PUB_SUB_RES_METHOD(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizablePROVIDER_COULD_NOT_BE_CREATED(Object arg0, Object arg1) {
/* 487 */     return messageFactory.getMessage("provider.could.not.be.created", new Object[] { arg0, arg1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String PROVIDER_COULD_NOT_BE_CREATED(Object arg0, Object arg1)
/*     */   {
/* 495 */     return localizer.localize(localizablePROVIDER_COULD_NOT_BE_CREATED(arg0, arg1));
/*     */   }
/*     */   
/*     */   public static Localizable localizableBAD_MIME_TYPE(Object arg0) {
/* 499 */     return messageFactory.getMessage("bad.mime.type", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String BAD_MIME_TYPE(Object arg0)
/*     */   {
/* 507 */     return localizer.localize(localizableBAD_MIME_TYPE(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableAMBIGUOUS_RR_PATH(Object arg0, Object arg1) {
/* 511 */     return messageFactory.getMessage("ambiguous.rr.path", new Object[] { arg0, arg1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String AMBIGUOUS_RR_PATH(Object arg0, Object arg1)
/*     */   {
/* 519 */     return localizer.localize(localizableAMBIGUOUS_RR_PATH(arg0, arg1));
/*     */   }
/*     */   
/*     */   public static Localizable localizableILLEGAL_LOAD_FACTOR(Object arg0) {
/* 523 */     return messageFactory.getMessage("illegal.load.factor", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String ILLEGAL_LOAD_FACTOR(Object arg0)
/*     */   {
/* 531 */     return localizer.localize(localizableILLEGAL_LOAD_FACTOR(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableERROR_MARSHALLING_JAXB(Object arg0) {
/* 535 */     return messageFactory.getMessage("error.marshalling.jaxb", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String ERROR_MARSHALLING_JAXB(Object arg0)
/*     */   {
/* 543 */     return localizer.localize(localizableERROR_MARSHALLING_JAXB(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableNOT_VALID_DYNAMICRESOLVINGMETHOD(Object arg0, Object arg1, Object arg2) {
/* 547 */     return messageFactory.getMessage("not.valid.dynamicresolvingmethod", new Object[] { arg0, arg1, arg2 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String NOT_VALID_DYNAMICRESOLVINGMETHOD(Object arg0, Object arg1, Object arg2)
/*     */   {
/* 555 */     return localizer.localize(localizableNOT_VALID_DYNAMICRESOLVINGMETHOD(arg0, arg1, arg2));
/*     */   }
/*     */   
/*     */   public static Localizable localizableRESOURCE_METHOD(Object arg0, Object arg1) {
/* 559 */     return messageFactory.getMessage("resource.method", new Object[] { arg0, arg1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String RESOURCE_METHOD(Object arg0, Object arg1)
/*     */   {
/* 567 */     return localizer.localize(localizableRESOURCE_METHOD(arg0, arg1));
/*     */   }
/*     */   
/*     */   public static Localizable localizableNO_WEBRESOURCECLASS_IN_WEBXML() {
/* 571 */     return messageFactory.getMessage("no.webresourceclass.in.webxml", new Object[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String NO_WEBRESOURCECLASS_IN_WEBXML()
/*     */   {
/* 579 */     return localizer.localize(localizableNO_WEBRESOURCECLASS_IN_WEBXML());
/*     */   }
/*     */   
/*     */   public static Localizable localizableILLEGAL_CONFIG_SYNTAX() {
/* 583 */     return messageFactory.getMessage("illegal.config.syntax", new Object[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String ILLEGAL_CONFIG_SYNTAX()
/*     */   {
/* 591 */     return localizer.localize(localizableILLEGAL_CONFIG_SYNTAX());
/*     */   }
/*     */   
/*     */   public static Localizable localizableBAD_ACCEPT_FIELD(Object arg0) {
/* 595 */     return messageFactory.getMessage("bad.accept.field", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String BAD_ACCEPT_FIELD(Object arg0)
/*     */   {
/* 603 */     return localizer.localize(localizableBAD_ACCEPT_FIELD(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableERROR_SUBRES_LOC_HAS_ENTITY_PARAM(Object arg0) {
/* 607 */     return messageFactory.getMessage("error.subres.loc.has.entity.param", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String ERROR_SUBRES_LOC_HAS_ENTITY_PARAM(Object arg0)
/*     */   {
/* 615 */     return localizer.localize(localizableERROR_SUBRES_LOC_HAS_ENTITY_PARAM(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableROOT_RES_NO_PUBLIC_CTOR(Object arg0) {
/* 619 */     return messageFactory.getMessage("root.res.no.public.ctor", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String ROOT_RES_NO_PUBLIC_CTOR(Object arg0)
/*     */   {
/* 627 */     return localizer.localize(localizableROOT_RES_NO_PUBLIC_CTOR(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableRESOURCE_MIMETYPE_NOT_IN_PRODUCE_MIME(Object arg0, Object arg1, Object arg2) {
/* 631 */     return messageFactory.getMessage("resource.mimetype.not.in.produceMime", new Object[] { arg0, arg1, arg2 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String RESOURCE_MIMETYPE_NOT_IN_PRODUCE_MIME(Object arg0, Object arg1, Object arg2)
/*     */   {
/* 639 */     return localizer.localize(localizableRESOURCE_MIMETYPE_NOT_IN_PRODUCE_MIME(arg0, arg1, arg2));
/*     */   }
/*     */   
/*     */   public static Localizable localizableBAD_CLASS_PRODUCEMIME(Object arg0, Object arg1) {
/* 643 */     return messageFactory.getMessage("bad.class.producemime", new Object[] { arg0, arg1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String BAD_CLASS_PRODUCEMIME(Object arg0, Object arg1)
/*     */   {
/* 651 */     return localizer.localize(localizableBAD_CLASS_PRODUCEMIME(arg0, arg1));
/*     */   }
/*     */   
/*     */   public static Localizable localizableNON_PUB_RES_METHOD(Object arg0) {
/* 655 */     return messageFactory.getMessage("non.pub.res.method", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String NON_PUB_RES_METHOD(Object arg0)
/*     */   {
/* 663 */     return localizer.localize(localizableNON_PUB_RES_METHOD(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableBYTE_ARRAY_CANNOT_BE_NULL() {
/* 667 */     return messageFactory.getMessage("byte.array.cannot.be.null", new Object[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String BYTE_ARRAY_CANNOT_BE_NULL()
/*     */   {
/* 675 */     return localizer.localize(localizableBYTE_ARRAY_CANNOT_BE_NULL());
/*     */   }
/*     */   
/*     */   public static Localizable localizableBAD_METHOD_PRODUCEMIME(Object arg0, Object arg1, Object arg2) {
/* 679 */     return messageFactory.getMessage("bad.method.producemime", new Object[] { arg0, arg1, arg2 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String BAD_METHOD_PRODUCEMIME(Object arg0, Object arg1, Object arg2)
/*     */   {
/* 687 */     return localizer.localize(localizableBAD_METHOD_PRODUCEMIME(arg0, arg1, arg2));
/*     */   }
/*     */   
/*     */   public static Localizable localizableNO_ROOT_RES_IN_RES_CFG() {
/* 691 */     return messageFactory.getMessage("no.root.res.in.res.cfg", new Object[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String NO_ROOT_RES_IN_RES_CFG()
/*     */   {
/* 699 */     return localizer.localize(localizableNO_ROOT_RES_IN_RES_CFG());
/*     */   }
/*     */   
/*     */   public static Localizable localizableBAD_METHOD_HTTPMETHOD(Object arg0, Object arg1, Object arg2) {
/* 703 */     return messageFactory.getMessage("bad.method.httpmethod", new Object[] { arg0, arg1, arg2 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String BAD_METHOD_HTTPMETHOD(Object arg0, Object arg1, Object arg2)
/*     */   {
/* 711 */     return localizer.localize(localizableBAD_METHOD_HTTPMETHOD(arg0, arg1, arg2));
/*     */   }
/*     */   
/*     */   public static Localizable localizableDEFAULT_COULD_NOT_PROCESS_CONSTRUCTOR(Object arg0, Object arg1) {
/* 715 */     return messageFactory.getMessage("default.could.not.process.constructor", new Object[] { arg0, arg1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String DEFAULT_COULD_NOT_PROCESS_CONSTRUCTOR(Object arg0, Object arg1)
/*     */   {
/* 723 */     return localizer.localize(localizableDEFAULT_COULD_NOT_PROCESS_CONSTRUCTOR(arg0, arg1));
/*     */   }
/*     */   
/*     */   public static Localizable localizableFATAL_ISSUES_FOUND_AT_RES_CLASS(Object arg0) {
/* 727 */     return messageFactory.getMessage("fatal.issues.found.at.res.class", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String FATAL_ISSUES_FOUND_AT_RES_CLASS(Object arg0)
/*     */   {
/* 735 */     return localizer.localize(localizableFATAL_ISSUES_FOUND_AT_RES_CLASS(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizablePROVIDER_NOT_FOUND(Object arg0) {
/* 739 */     return messageFactory.getMessage("provider.not.found", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String PROVIDER_NOT_FOUND(Object arg0)
/*     */   {
/* 747 */     return localizer.localize(localizablePROVIDER_NOT_FOUND(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableERROR_SUBRES_LOC_RETURNS_VOID(Object arg0) {
/* 751 */     return messageFactory.getMessage("error.subres.loc.returns.void", new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String ERROR_SUBRES_LOC_RETURNS_VOID(Object arg0)
/*     */   {
/* 759 */     return localizer.localize(localizableERROR_SUBRES_LOC_RETURNS_VOID(arg0));
/*     */   }
/*     */   
/*     */   public static Localizable localizableEXCEPTION_INVOKING_RESOURCE_METHOD() {
/* 763 */     return messageFactory.getMessage("exception.invoking.resource.method", new Object[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String EXCEPTION_INVOKING_RESOURCE_METHOD()
/*     */   {
/* 771 */     return localizer.localize(localizableEXCEPTION_INVOKING_RESOURCE_METHOD());
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\impl\ImplMessages.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */