/*     */ package com.sun.jersey.core.header;
/*     */ 
/*     */ import com.sun.jersey.core.header.reader.HttpHeaderReader;
/*     */ import java.text.ParseException;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LanguageTag
/*     */ {
/*     */   protected String tag;
/*     */   protected String primaryTag;
/*     */   protected String subTags;
/*     */   
/*     */   protected LanguageTag() {}
/*     */   
/*     */   public static LanguageTag valueOf(String s)
/*     */     throws IllegalArgumentException
/*     */   {
/*  64 */     LanguageTag lt = new LanguageTag();
/*     */     try
/*     */     {
/*  67 */       lt.parse(s);
/*     */     } catch (ParseException pe) {
/*  69 */       throw new IllegalArgumentException(pe);
/*     */     }
/*     */     
/*  72 */     return lt;
/*     */   }
/*     */   
/*     */   public LanguageTag(String primaryTag, String subTags) {
/*  76 */     if ((subTags != null) && (subTags.length() > 0)) {
/*  77 */       this.tag = (primaryTag + "-" + subTags);
/*     */     } else {
/*  79 */       this.tag = primaryTag;
/*     */     }
/*  81 */     this.primaryTag = primaryTag;
/*     */     
/*  83 */     this.subTags = subTags;
/*     */   }
/*     */   
/*     */   public LanguageTag(String header) throws ParseException {
/*  87 */     this(HttpHeaderReader.newInstance(header));
/*     */   }
/*     */   
/*     */   public LanguageTag(HttpHeaderReader reader) throws ParseException
/*     */   {
/*  92 */     reader.hasNext();
/*     */     
/*  94 */     this.tag = reader.nextToken();
/*     */     
/*  96 */     if (reader.hasNext()) {
/*  97 */       throw new ParseException("Invalid Language tag", reader.getIndex());
/*     */     }
/*  99 */     parse(this.tag);
/*     */   }
/*     */   
/*     */   public final boolean isCompatible(Locale tag) {
/* 103 */     if (this.tag.equals("*")) {
/* 104 */       return true;
/*     */     }
/* 106 */     if (this.subTags == null) {
/* 107 */       return this.primaryTag.equalsIgnoreCase(tag.getLanguage());
/*     */     }
/* 109 */     return (this.primaryTag.equalsIgnoreCase(tag.getLanguage())) && (this.subTags.equalsIgnoreCase(tag.getCountry()));
/*     */   }
/*     */   
/*     */ 
/*     */   public final Locale getAsLocale()
/*     */   {
/* 115 */     return this.subTags == null ? new Locale(this.primaryTag) : new Locale(this.primaryTag, this.subTags);
/*     */   }
/*     */   
/*     */   protected final void parse(String languageTag)
/*     */     throws ParseException
/*     */   {
/* 121 */     if (!isValid(languageTag)) {
/* 122 */       throw new ParseException("String, " + languageTag + ", is not a valid language tag", 0);
/*     */     }
/*     */     
/* 125 */     int index = languageTag.indexOf('-');
/* 126 */     if (index == -1) {
/* 127 */       this.primaryTag = languageTag;
/* 128 */       this.subTags = null;
/*     */     } else {
/* 130 */       this.primaryTag = languageTag.substring(0, index);
/* 131 */       this.subTags = languageTag.substring(index + 1, languageTag.length());
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isValid(String tag) {
/* 136 */     int alphaCount = 0;
/* 137 */     for (int i = 0; i < tag.length(); i++) {
/* 138 */       char c = tag.charAt(i);
/* 139 */       if (c == '-') {
/* 140 */         if (alphaCount == 0)
/* 141 */           return false;
/* 142 */         alphaCount = 0;
/* 143 */       } else if ((('A' <= c) && (c <= 'Z')) || (('a' <= c) && (c <= 'z'))) {
/* 144 */         alphaCount++;
/* 145 */         if (alphaCount > 8)
/* 146 */           return false;
/*     */       } else {
/* 148 */         return false;
/*     */       }
/*     */     }
/* 151 */     return alphaCount != 0;
/*     */   }
/*     */   
/*     */   public final String getTag() {
/* 155 */     return this.tag;
/*     */   }
/*     */   
/*     */   public final String getPrimaryTag() {
/* 159 */     return this.primaryTag;
/*     */   }
/*     */   
/*     */   public final String getSubTags() {
/* 163 */     return this.subTags;
/*     */   }
/*     */   
/*     */   public boolean equals(Object object)
/*     */   {
/* 168 */     if ((object instanceof LanguageTag)) {
/* 169 */       LanguageTag lt = (LanguageTag)object;
/*     */       
/* 171 */       if (this.tag != null) {
/* 172 */         if (!this.tag.equals(lt.getTag())) {
/* 173 */           return false;
/*     */         }
/* 175 */         if (lt.getTag() != null)
/* 176 */           return false;
/*     */       }
/* 178 */       if (this.primaryTag != null) {
/* 179 */         if (!this.primaryTag.equals(lt.getPrimaryTag())) {
/* 180 */           return false;
/*     */         }
/* 182 */         if (lt.getPrimaryTag() != null)
/* 183 */           return false;
/*     */       }
/* 185 */       if (this.subTags != null) {
/* 186 */         if (!this.subTags.equals(lt.getSubTags())) {
/* 187 */           return false;
/*     */         }
/* 189 */         if (lt.getSubTags() != null)
/* 190 */           return false;
/*     */       }
/* 192 */       return true;
/*     */     }
/* 194 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 200 */     return (this.tag == null ? 0 : this.tag.hashCode()) + (this.primaryTag == null ? 0 : this.primaryTag.hashCode()) + (this.subTags == null ? 0 : this.primaryTag.hashCode());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 207 */     return this.primaryTag + (this.subTags == null ? "" : this.subTags);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\header\LanguageTag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */