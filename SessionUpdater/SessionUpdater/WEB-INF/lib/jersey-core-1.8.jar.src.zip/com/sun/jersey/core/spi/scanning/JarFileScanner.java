/*     */ package com.sun.jersey.core.spi.scanning;
/*     */ 
/*     */ import com.sun.jersey.core.util.Closing;
/*     */ import com.sun.jersey.core.util.Closing.Closure;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JarFileScanner
/*     */ {
/*     */   public static void scan(File f, String parent, final ScannerListener sl)
/*     */     throws IOException
/*     */   {
/*  71 */     new Closing(new FileInputStream(f)).f(new Closing.Closure()
/*     */     {
/*     */       public void f(InputStream in) throws IOException {
/*  74 */         JarFileScanner.scan(in, this.val$parent, sl);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void scan(InputStream in, String parent, ScannerListener sl)
/*     */     throws IOException
/*     */   {
/*  91 */     JarInputStream jarIn = null;
/*     */     try {
/*  93 */       jarIn = new JarInputStream(in);
/*  94 */       JarEntry e = jarIn.getNextJarEntry();
/*  95 */       while (e != null) {
/*  96 */         if ((!e.isDirectory()) && (e.getName().startsWith(parent)) && (sl.onAccept(e.getName()))) {
/*  97 */           sl.onProcess(e.getName(), jarIn);
/*     */         }
/*  99 */         jarIn.closeEntry();
/* 100 */         e = jarIn.getNextJarEntry();
/*     */       }
/*     */     } finally {
/* 103 */       if (jarIn != null) {
/* 104 */         jarIn.close();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\scanning\JarFileScanner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */