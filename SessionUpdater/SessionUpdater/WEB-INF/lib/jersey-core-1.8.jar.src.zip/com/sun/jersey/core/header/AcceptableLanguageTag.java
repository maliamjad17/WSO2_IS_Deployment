/*    */ package com.sun.jersey.core.header;
/*    */ 
/*    */ import com.sun.jersey.core.header.reader.HttpHeaderReader;
/*    */ import java.text.ParseException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AcceptableLanguageTag
/*    */   extends LanguageTag
/*    */   implements QualityFactor
/*    */ {
/* 53 */   protected int quality = 1000;
/*    */   
/*    */   public AcceptableLanguageTag(String primaryTag, String subTags) {
/* 56 */     super(primaryTag, subTags);
/*    */   }
/*    */   
/*    */   public AcceptableLanguageTag(String header) throws ParseException {
/* 60 */     this(HttpHeaderReader.newInstance(header));
/*    */   }
/*    */   
/*    */   public AcceptableLanguageTag(HttpHeaderReader reader) throws ParseException
/*    */   {
/* 65 */     reader.hasNext();
/*    */     
/* 67 */     this.tag = reader.nextToken();
/* 68 */     if (!this.tag.equals("*")) {
/* 69 */       parse(this.tag);
/*    */     } else {
/* 71 */       this.primaryTag = this.tag;
/*    */     }
/* 73 */     if (reader.hasNext()) {
/* 74 */       this.quality = HttpHeaderReader.readQualityFactorParameter(reader);
/*    */     }
/*    */   }
/*    */   
/*    */   public int getQuality() {
/* 79 */     return this.quality;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\header\AcceptableLanguageTag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */