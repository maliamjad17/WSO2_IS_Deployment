/*     */ package com.sun.jersey.core.spi.factory;
/*     */ 
/*     */ import com.sun.jersey.core.header.OutBoundHeaders;
/*     */ import java.lang.reflect.Type;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.core.Response;
/*     */ import javax.ws.rs.core.Response.Status;
/*     */ import javax.ws.rs.core.Response.Status.Family;
/*     */ import javax.ws.rs.core.Response.StatusType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResponseImpl
/*     */   extends Response
/*     */ {
/*     */   private final Response.StatusType statusType;
/*     */   private final MultivaluedMap<String, Object> headers;
/*     */   private final Object entity;
/*     */   private final Type entityType;
/*     */   
/*     */   protected ResponseImpl(Response.StatusType statusType, OutBoundHeaders headers, Object entity, Type entityType)
/*     */   {
/*  80 */     this.statusType = statusType;
/*  81 */     this.headers = headers;
/*  82 */     this.entity = entity;
/*  83 */     this.entityType = entityType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseImpl(int status, OutBoundHeaders headers, Object entity, Type entityType)
/*     */   {
/*  97 */     this.statusType = toStatusType(status);
/*  98 */     this.headers = headers;
/*  99 */     this.entity = entity;
/* 100 */     this.entityType = entityType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Response.StatusType getStatusType()
/*     */   {
/* 109 */     return this.statusType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Type getEntityType()
/*     */   {
/* 118 */     return this.entityType;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getStatus()
/*     */   {
/* 124 */     return this.statusType.getStatusCode();
/*     */   }
/*     */   
/*     */   public MultivaluedMap<String, Object> getMetadata() {
/* 128 */     return this.headers;
/*     */   }
/*     */   
/*     */   public Object getEntity() {
/* 132 */     return this.entity;
/*     */   }
/*     */   
/*     */   public static Response.StatusType toStatusType(int statusCode) {
/* 136 */     switch (statusCode) {
/* 137 */     case 200:  return Response.Status.OK;
/* 138 */     case 201:  return Response.Status.CREATED;
/* 139 */     case 202:  return Response.Status.ACCEPTED;
/* 140 */     case 204:  return Response.Status.NO_CONTENT;
/*     */     case 301: 
/* 142 */       return Response.Status.MOVED_PERMANENTLY;
/* 143 */     case 303:  return Response.Status.SEE_OTHER;
/* 144 */     case 304:  return Response.Status.NOT_MODIFIED;
/* 145 */     case 307:  return Response.Status.TEMPORARY_REDIRECT;
/*     */     case 400: 
/* 147 */       return Response.Status.BAD_REQUEST;
/* 148 */     case 401:  return Response.Status.UNAUTHORIZED;
/* 149 */     case 403:  return Response.Status.FORBIDDEN;
/* 150 */     case 404:  return Response.Status.NOT_FOUND;
/* 151 */     case 406:  return Response.Status.NOT_ACCEPTABLE;
/* 152 */     case 409:  return Response.Status.CONFLICT;
/* 153 */     case 410:  return Response.Status.GONE;
/* 154 */     case 412:  return Response.Status.PRECONDITION_FAILED;
/* 155 */     case 415:  return Response.Status.UNSUPPORTED_MEDIA_TYPE;
/*     */     case 500: 
/* 157 */       return Response.Status.INTERNAL_SERVER_ERROR;
/* 158 */     case 503:  return Response.Status.SERVICE_UNAVAILABLE;
/*     */     }
/*     */     
/* 161 */     new Response.StatusType()
/*     */     {
/*     */       public int getStatusCode() {
/* 164 */         return this.val$statusCode;
/*     */       }
/*     */       
/*     */       public Response.Status.Family getFamily()
/*     */       {
/* 169 */         return ResponseImpl.toFamilyCode(this.val$statusCode);
/*     */       }
/*     */       
/*     */       public String getReasonPhrase()
/*     */       {
/* 174 */         return "";
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */   public static Response.Status.Family toFamilyCode(int statusCode)
/*     */   {
/* 182 */     switch (statusCode / 100) {
/* 183 */     case 1:  return Response.Status.Family.INFORMATIONAL;
/* 184 */     case 2:  return Response.Status.Family.SUCCESSFUL;
/* 185 */     case 3:  return Response.Status.Family.REDIRECTION;
/* 186 */     case 4:  return Response.Status.Family.CLIENT_ERROR;
/* 187 */     case 5:  return Response.Status.Family.SERVER_ERROR; }
/* 188 */     return Response.Status.Family.OTHER;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\factory\ResponseImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */