/*     */ package com.sun.jersey.core.provider.jaxb;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.charset.Charset;
/*     */ import javax.ws.rs.WebApplicationException;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.core.Response.Status;
/*     */ import javax.ws.rs.ext.Providers;
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.Marshaller;
/*     */ import javax.xml.bind.UnmarshalException;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractJAXBElementProvider
/*     */   extends AbstractJAXBProvider<JAXBElement<?>>
/*     */ {
/*     */   public AbstractJAXBElementProvider(Providers ps)
/*     */   {
/*  81 */     super(ps);
/*     */   }
/*     */   
/*     */   public AbstractJAXBElementProvider(Providers ps, MediaType mt) {
/*  85 */     super(ps, mt);
/*     */   }
/*     */   
/*     */   public boolean isReadable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType)
/*     */   {
/*  90 */     return (type == JAXBElement.class) && ((genericType instanceof ParameterizedType)) && (isSupported(mediaType));
/*     */   }
/*     */   
/*     */   public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType)
/*     */   {
/*  95 */     return (JAXBElement.class.isAssignableFrom(type)) && (isSupported(mediaType));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final JAXBElement<?> readFrom(Class<JAXBElement<?>> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, String> httpHeaders, InputStream entityStream)
/*     */     throws IOException
/*     */   {
/* 106 */     ParameterizedType pt = (ParameterizedType)genericType;
/* 107 */     Class ta = (Class)pt.getActualTypeArguments()[0];
/*     */     try
/*     */     {
/* 110 */       return readFrom(ta, mediaType, getUnmarshaller(ta, mediaType), entityStream);
/*     */     } catch (UnmarshalException ex) {
/* 112 */       throw new WebApplicationException(ex, Response.Status.BAD_REQUEST);
/*     */     } catch (JAXBException ex) {
/* 114 */       throw new WebApplicationException(ex, Response.Status.INTERNAL_SERVER_ERROR);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract JAXBElement<?> readFrom(Class<?> paramClass, MediaType paramMediaType, Unmarshaller paramUnmarshaller, InputStream paramInputStream)
/*     */     throws JAXBException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void writeTo(JAXBElement<?> t, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, OutputStream entityStream)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 133 */       Marshaller m = getMarshaller(t.getDeclaredType(), mediaType);
/* 134 */       Charset c = getCharset(mediaType);
/* 135 */       if (c != UTF8) {
/* 136 */         m.setProperty("jaxb.encoding", c.name());
/*     */       }
/* 138 */       setHeader(m, annotations);
/* 139 */       writeTo(t, mediaType, c, m, entityStream);
/*     */     } catch (JAXBException ex) {
/* 141 */       throw new WebApplicationException(ex, Response.Status.INTERNAL_SERVER_ERROR);
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract void writeTo(JAXBElement<?> paramJAXBElement, MediaType paramMediaType, Charset paramCharset, Marshaller paramMarshaller, OutputStream paramOutputStream)
/*     */     throws JAXBException;
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\provider\jaxb\AbstractJAXBElementProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */