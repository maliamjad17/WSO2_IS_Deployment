package com.sun.jersey.core.util;

import java.util.Comparator;

public abstract interface KeyComparator<K>
  extends Comparator<K>
{
  public abstract boolean equals(K paramK1, K paramK2);
  
  public abstract int hash(K paramK);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\util\KeyComparator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */