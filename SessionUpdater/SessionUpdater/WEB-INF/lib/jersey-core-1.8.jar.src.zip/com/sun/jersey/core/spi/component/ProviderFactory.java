/*     */ package com.sun.jersey.core.spi.component;
/*     */ 
/*     */ import com.sun.jersey.spi.inject.InjectableProviderContext;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProviderFactory
/*     */   implements ComponentProviderFactory<ComponentProvider>
/*     */ {
/*  60 */   protected static final Logger LOGGER = Logger.getLogger(ProviderFactory.class.getName());
/*     */   
/*     */ 
/*     */   private static final class SingletonComponentProvider
/*     */     implements ComponentProvider, ProviderFactory.Destroyable
/*     */   {
/*     */     private final Object o;
/*     */     
/*     */     private final ComponentDestructor cd;
/*     */     
/*     */     private final ComponentInjector ci;
/*     */     
/*     */     SingletonComponentProvider(ComponentInjector ci, Object o)
/*     */     {
/*  74 */       this.cd = new ComponentDestructor(o.getClass());
/*  75 */       this.ci = ci;
/*  76 */       this.o = o;
/*     */     }
/*     */     
/*     */     public Object getInstance() {
/*  80 */       return this.o;
/*     */     }
/*     */     
/*     */     public void inject() {
/*  84 */       this.ci.inject(this.o);
/*     */     }
/*     */     
/*     */     public void destroy() {
/*     */       try {
/*  89 */         this.cd.destroy(this.o);
/*     */       } catch (IllegalAccessException ex) {
/*  91 */         ProviderFactory.LOGGER.log(Level.SEVERE, "Unable to destroy resource", ex);
/*     */       } catch (IllegalArgumentException ex) {
/*  93 */         ProviderFactory.LOGGER.log(Level.SEVERE, "Unable to destroy resource", ex);
/*     */       } catch (InvocationTargetException ex) {
/*  95 */         ProviderFactory.LOGGER.log(Level.SEVERE, "Unable to destroy resource", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 100 */   private final Map<Class, ComponentProvider> cache = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */   private final InjectableProviderContext ipc;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ProviderFactory(InjectableProviderContext ipc)
/*     */   {
/* 111 */     this.ipc = ipc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InjectableProviderContext getInjectableProviderContext()
/*     */   {
/* 120 */     return this.ipc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final ComponentProvider getComponentProvider(ProviderServices.ProviderClass pc)
/*     */   {
/* 130 */     if (!pc.isServiceClass) {
/* 131 */       return getComponentProvider(pc.c);
/*     */     }
/*     */     
/* 134 */     ComponentProvider cp = (ComponentProvider)this.cache.get(pc.c);
/* 135 */     if (cp != null) { return cp;
/*     */     }
/* 137 */     cp = __getComponentProvider(pc.c);
/*     */     
/* 139 */     if (cp != null) this.cache.put(pc.c, cp);
/* 140 */     return cp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final ComponentProvider getComponentProvider(Class c)
/*     */   {
/* 150 */     ComponentProvider cp = (ComponentProvider)this.cache.get(c);
/* 151 */     if (cp != null) { return cp;
/*     */     }
/* 153 */     cp = _getComponentProvider(c);
/* 154 */     if (cp != null) this.cache.put(c, cp);
/* 155 */     return cp;
/*     */   }
/*     */   
/*     */   protected ComponentProvider _getComponentProvider(Class c) {
/* 159 */     return __getComponentProvider(c);
/*     */   }
/*     */   
/*     */   private ComponentProvider __getComponentProvider(Class c) {
/*     */     try {
/* 164 */       ComponentInjector ci = new ComponentInjector(this.ipc, c);
/* 165 */       ComponentConstructor cc = new ComponentConstructor(this.ipc, c, ci);
/* 166 */       Object o = cc.getInstance();
/*     */       
/* 168 */       return new SingletonComponentProvider(ci, o);
/*     */ 
/*     */     }
/*     */     catch (NoClassDefFoundError ex)
/*     */     {
/* 173 */       LOGGER.log(Level.CONFIG, "A dependent class, " + ex.getLocalizedMessage() + ", of the component " + c + " is not found." + " The component is ignored.");
/*     */       
/*     */ 
/*     */ 
/* 177 */       return null;
/*     */     } catch (InvocationTargetException ex) {
/* 179 */       if ((ex.getCause() instanceof NoClassDefFoundError)) {
/* 180 */         NoClassDefFoundError ncdf = (NoClassDefFoundError)ex.getCause();
/* 181 */         LOGGER.log(Level.CONFIG, "A dependent class, " + ncdf.getLocalizedMessage() + ", of the component " + c + " is not found." + " The component is ignored.");
/*     */         
/*     */ 
/*     */ 
/* 185 */         return null;
/*     */       }
/* 187 */       LOGGER.log(Level.SEVERE, "The provider class, " + c + ", could not be instantiated. Processing will continue but the class will not be utilized", ex.getTargetException());
/*     */       
/*     */ 
/* 190 */       return null;
/*     */     }
/*     */     catch (Exception ex) {
/* 193 */       LOGGER.log(Level.SEVERE, "The provider class, " + c + ", could not be instantiated. Processing will continue but the class will not be utilized", ex);
/*     */     }
/*     */     
/* 196 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void injectOnAllComponents()
/*     */   {
/* 204 */     for (ComponentProvider cp : this.cache.values()) {
/* 205 */       if ((cp instanceof SingletonComponentProvider)) {
/* 206 */         SingletonComponentProvider scp = (SingletonComponentProvider)cp;
/* 207 */         scp.inject();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 216 */     for (ComponentProvider cp : this.cache.values()) {
/* 217 */       if ((cp instanceof Destroyable)) {
/* 218 */         Destroyable d = (Destroyable)cp;
/* 219 */         d.destroy();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void injectOnProviderInstances(Collection<?> providers)
/*     */   {
/* 230 */     for (Object o : providers) {
/* 231 */       injectOnProviderInstance(o);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void injectOnProviderInstance(Object provider)
/*     */   {
/* 241 */     Class c = provider.getClass();
/* 242 */     ComponentInjector ci = new ComponentInjector(this.ipc, c);
/* 243 */     ci.inject(provider);
/*     */   }
/*     */   
/*     */   protected static abstract interface Destroyable
/*     */   {
/*     */     public abstract void destroy();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\component\ProviderFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */