/*    */ package com.sun.jersey.core.header;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import javax.ws.rs.core.MultivaluedMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LinkHeaders
/*    */ {
/*    */   private final Map<String, LinkHeader> map;
/*    */   
/*    */   public LinkHeaders(MultivaluedMap<String, String> headers)
/*    */     throws IllegalArgumentException
/*    */   {
/* 58 */     List<String> ls = (List)headers.get("Link");
/* 59 */     LinkHeader lh; if (ls != null) {
/* 60 */       this.map = new HashMap();
/* 61 */       for (String l : ls) {
/* 62 */         lh = LinkHeader.valueOf(l);
/* 63 */         for (String rel : lh.getRel()) {
/* 64 */           this.map.put(rel, lh);
/*    */         }
/*    */       }
/*    */     } else {
/* 68 */       this.map = Collections.emptyMap();
/*    */     }
/*    */   }
/*    */   
/*    */   public LinkHeader getLink(String rel) throws IllegalArgumentException {
/* 73 */     return (LinkHeader)this.map.get(rel);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\header\LinkHeaders.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */