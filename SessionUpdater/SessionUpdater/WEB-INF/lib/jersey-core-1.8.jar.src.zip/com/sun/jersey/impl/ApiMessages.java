/*    */ package com.sun.jersey.impl;
/*    */ 
/*    */ import com.sun.jersey.localization.LocalizableMessageFactory;
/*    */ import com.sun.jersey.localization.Localizer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ApiMessages
/*    */ {
/* 14 */   private static final LocalizableMessageFactory messageFactory = new LocalizableMessageFactory("com.sun.jersey.impl.api");
/* 15 */   private static final Localizer localizer = new Localizer();
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\impl\ApiMessages.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */