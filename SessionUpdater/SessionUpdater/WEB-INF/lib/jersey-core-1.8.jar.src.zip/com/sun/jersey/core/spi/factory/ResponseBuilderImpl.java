/*     */ package com.sun.jersey.core.spi.factory;
/*     */ 
/*     */ import com.sun.jersey.core.header.OutBoundHeaders;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.URI;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import javax.ws.rs.core.CacheControl;
/*     */ import javax.ws.rs.core.EntityTag;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.NewCookie;
/*     */ import javax.ws.rs.core.Response;
/*     */ import javax.ws.rs.core.Response.ResponseBuilder;
/*     */ import javax.ws.rs.core.Response.Status;
/*     */ import javax.ws.rs.core.Response.StatusType;
/*     */ import javax.ws.rs.core.Variant;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResponseBuilderImpl
/*     */   extends Response.ResponseBuilder
/*     */ {
/*  67 */   private Response.StatusType statusType = Response.Status.NO_CONTENT;
/*     */   
/*     */   private OutBoundHeaders headers;
/*     */   
/*     */   private Object entity;
/*     */   private Type entityType;
/*     */   
/*     */   public ResponseBuilderImpl() {}
/*     */   
/*     */   private ResponseBuilderImpl(ResponseBuilderImpl that)
/*     */   {
/*  78 */     this.statusType = that.statusType;
/*  79 */     this.entity = that.entity;
/*  80 */     if (that.headers != null) {
/*  81 */       this.headers = new OutBoundHeaders(that.headers);
/*     */     } else {
/*  83 */       this.headers = null;
/*     */     }
/*  85 */     this.entityType = that.entityType;
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder entityWithType(Object entity, Type entityType) {
/*  89 */     this.entity = entity;
/*  90 */     this.entityType = entityType;
/*  91 */     return this;
/*     */   }
/*     */   
/*     */   private OutBoundHeaders getHeaders() {
/*  95 */     if (this.headers == null)
/*  96 */       this.headers = new OutBoundHeaders();
/*  97 */     return this.headers;
/*     */   }
/*     */   
/*     */ 
/*     */   public Response build()
/*     */   {
/* 103 */     Response r = new ResponseImpl(this.statusType, getHeaders(), this.entity, this.entityType);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 108 */     reset();
/* 109 */     return r;
/*     */   }
/*     */   
/*     */   private void reset() {
/* 113 */     this.statusType = Response.Status.NO_CONTENT;
/* 114 */     this.headers = null;
/* 115 */     this.entity = null;
/* 116 */     this.entityType = null;
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder clone()
/*     */   {
/* 121 */     return new ResponseBuilderImpl(this);
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder status(Response.StatusType status) {
/* 125 */     if (status == null)
/* 126 */       throw new IllegalArgumentException();
/* 127 */     this.statusType = status;
/* 128 */     return this;
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder status(int status) {
/* 132 */     return status(ResponseImpl.toStatusType(status));
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder entity(Object entity) {
/* 136 */     this.entity = entity;
/* 137 */     this.entityType = (entity != null ? entity.getClass() : null);
/* 138 */     return this;
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder type(MediaType type) {
/* 142 */     headerSingle("Content-Type", type);
/* 143 */     return this;
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder type(String type) {
/* 147 */     return type(type == null ? null : MediaType.valueOf(type));
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder variant(Variant variant) {
/* 151 */     if (variant == null) {
/* 152 */       type((MediaType)null);
/* 153 */       language((String)null);
/* 154 */       encoding(null);
/* 155 */       return this;
/*     */     }
/*     */     
/* 158 */     type(variant.getMediaType());
/*     */     
/* 160 */     language(variant.getLanguage());
/* 161 */     encoding(variant.getEncoding());
/*     */     
/* 163 */     return this;
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder variants(List<Variant> variants) {
/* 167 */     if (variants == null) {
/* 168 */       header("Vary", null);
/* 169 */       return this;
/*     */     }
/*     */     
/* 172 */     if (variants.isEmpty()) {
/* 173 */       return this;
/*     */     }
/* 175 */     MediaType accept = ((Variant)variants.get(0)).getMediaType();
/* 176 */     boolean vAccept = false;
/*     */     
/* 178 */     Locale acceptLanguage = ((Variant)variants.get(0)).getLanguage();
/* 179 */     boolean vAcceptLanguage = false;
/*     */     
/* 181 */     String acceptEncoding = ((Variant)variants.get(0)).getEncoding();
/* 182 */     boolean vAcceptEncoding = false;
/*     */     
/* 184 */     for (Variant v : variants) {
/* 185 */       vAccept |= ((!vAccept) && (vary(v.getMediaType(), accept)));
/* 186 */       vAcceptLanguage |= ((!vAcceptLanguage) && (vary(v.getLanguage(), acceptLanguage)));
/* 187 */       vAcceptEncoding |= ((!vAcceptEncoding) && (vary(v.getEncoding(), acceptEncoding)));
/*     */     }
/*     */     
/* 190 */     StringBuilder vary = new StringBuilder();
/* 191 */     append(vary, vAccept, "Accept");
/* 192 */     append(vary, vAcceptLanguage, "Accept-Language");
/* 193 */     append(vary, vAcceptEncoding, "Accept-Encoding");
/*     */     
/* 195 */     if (vary.length() > 0)
/* 196 */       header("Vary", vary.toString());
/* 197 */     return this;
/*     */   }
/*     */   
/*     */   private boolean vary(MediaType v, MediaType vary) {
/* 201 */     return (v != null) && (!v.equals(vary));
/*     */   }
/*     */   
/*     */   private boolean vary(Locale v, Locale vary) {
/* 205 */     return (v != null) && (!v.equals(vary));
/*     */   }
/*     */   
/*     */   private boolean vary(String v, String vary) {
/* 209 */     return (v != null) && (!v.equalsIgnoreCase(vary));
/*     */   }
/*     */   
/*     */   private void append(StringBuilder sb, boolean v, String s) {
/* 213 */     if (v) {
/* 214 */       if (sb.length() > 0)
/* 215 */         sb.append(',');
/* 216 */       sb.append(s);
/*     */     }
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder language(String language) {
/* 221 */     headerSingle("Content-Language", language);
/* 222 */     return this;
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder language(Locale language) {
/* 226 */     headerSingle("Content-Language", language);
/* 227 */     return this;
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder location(URI location) {
/* 231 */     headerSingle("Location", location);
/* 232 */     return this;
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder contentLocation(URI location) {
/* 236 */     headerSingle("Content-Location", location);
/* 237 */     return this;
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder encoding(String encoding) {
/* 241 */     headerSingle("Content-Encoding", encoding);
/* 242 */     return this;
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder tag(EntityTag tag) {
/* 246 */     headerSingle("ETag", tag);
/* 247 */     return this;
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder tag(String tag) {
/* 251 */     return tag(tag == null ? null : new EntityTag(tag));
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder lastModified(Date lastModified) {
/* 255 */     headerSingle("Last-Modified", lastModified);
/* 256 */     return this;
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder cacheControl(CacheControl cacheControl) {
/* 260 */     headerSingle("Cache-Control", cacheControl);
/* 261 */     return this;
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder expires(Date expires) {
/* 265 */     headerSingle("Expires", expires);
/* 266 */     return this;
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder cookie(NewCookie... cookies) {
/* 270 */     if (cookies != null) {
/* 271 */       for (NewCookie cookie : cookies)
/* 272 */         header("Set-Cookie", cookie);
/*     */     } else {
/* 274 */       header("Set-Cookie", null);
/*     */     }
/* 276 */     return this;
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder header(String name, Object value) {
/* 280 */     return header(name, value, false);
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder headerSingle(String name, Object value) {
/* 284 */     return header(name, value, true);
/*     */   }
/*     */   
/*     */   public Response.ResponseBuilder header(String name, Object value, boolean single) {
/* 288 */     if (value != null) {
/* 289 */       if (single) {
/* 290 */         getHeaders().putSingle(name, value);
/*     */       } else {
/* 292 */         getHeaders().add(name, value);
/*     */       }
/*     */     } else {
/* 295 */       getHeaders().remove(name);
/*     */     }
/* 297 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\factory\ResponseBuilderImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */