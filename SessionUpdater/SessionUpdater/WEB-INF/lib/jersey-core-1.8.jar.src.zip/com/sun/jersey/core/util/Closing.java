/*    */ package com.sun.jersey.core.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Closing
/*    */ {
/*    */   private final InputStream in;
/*    */   
/*    */   public static Closing with(InputStream in)
/*    */   {
/* 57 */     return new Closing(in);
/*    */   }
/*    */   
/*    */ 
/*    */   public Closing(InputStream in)
/*    */   {
/* 63 */     this.in = in;
/*    */   }
/*    */   
/*    */   public void f(Closure c) throws IOException {
/* 67 */     if (this.in == null) {
/* 68 */       return;
/*    */     }
/*    */     try {
/* 71 */       c.f(this.in); return;
/*    */     } finally {
/*    */       try {
/* 74 */         this.in.close();
/*    */       } catch (IOException ex) {
/* 76 */         throw ex;
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public static abstract interface Closure
/*    */   {
/*    */     public abstract void f(InputStream paramInputStream)
/*    */       throws IOException;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\util\Closing.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */