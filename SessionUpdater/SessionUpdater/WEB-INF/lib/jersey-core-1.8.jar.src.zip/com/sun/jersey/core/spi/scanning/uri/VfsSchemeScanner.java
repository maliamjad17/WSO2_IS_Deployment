/*     */ package com.sun.jersey.core.spi.scanning.uri;
/*     */ 
/*     */ import com.sun.jersey.core.spi.scanning.JarFileScanner;
/*     */ import com.sun.jersey.core.spi.scanning.ScannerException;
/*     */ import com.sun.jersey.core.spi.scanning.ScannerListener;
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.ws.rs.core.UriBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VfsSchemeScanner
/*     */   implements UriSchemeScanner
/*     */ {
/*     */   public Set<String> getSchemes()
/*     */   {
/*  63 */     return new HashSet(Arrays.asList(new String[] { "vfsfile", "vfszip" }));
/*     */   }
/*     */   
/*     */ 
/*     */   public void scan(final URI u, final ScannerListener sl)
/*     */   {
/*  69 */     if (u.getScheme().equalsIgnoreCase("vfsfile")) {
/*  70 */       new FileSchemeScanner().scan(UriBuilder.fromUri(u).scheme("file").build(new Object[0]), sl);
/*     */     }
/*     */     else
/*     */     {
/*  74 */       String su = u.toString();
/*  75 */       int webInfIndex = su.indexOf("/WEB-INF/classes");
/*  76 */       if (webInfIndex != -1) {
/*  77 */         String war = su.substring(0, webInfIndex);
/*  78 */         final String path = su.substring(webInfIndex + 1);
/*     */         
/*  80 */         int warParentIndex = war.lastIndexOf('/');
/*  81 */         String warParent = su.substring(0, warParentIndex);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*  86 */         if (warParent.endsWith(".ear")) {
/*  87 */           final String warName = su.substring(warParentIndex + 1, war.length());
/*     */           try {
/*  89 */             JarFileScanner.scan(new URL(warParent.replace("vfszip", "file")).openStream(), "", new ScannerListener()
/*     */             {
/*     */               public boolean onAccept(String name) {
/*  92 */                 return name.equals(warName);
/*     */               }
/*     */               
/*     */               public void onProcess(String name, InputStream in)
/*     */                 throws IOException
/*     */               {
/*  98 */                 in = new FilterInputStream(in) {
/*     */                   public void close() throws IOException
/*     */                   {}
/*     */                 };
/* 102 */                 try { JarFileScanner.scan(in, path, sl);
/*     */                 } catch (IOException ex) {
/* 104 */                   throw new ScannerException("IO error when scanning war " + u, ex);
/*     */                 }
/*     */               }
/*     */             });
/*     */           } catch (IOException ex) {
/* 109 */             throw new ScannerException("IO error when scanning war " + u, ex);
/*     */           }
/*     */         } else {
/*     */           try {
/* 113 */             JarFileScanner.scan(new URL(war.replace("vfszip", "file")).openStream(), path, sl);
/*     */           } catch (IOException ex) {
/* 115 */             throw new ScannerException("IO error when scanning war " + u, ex);
/*     */           }
/*     */         }
/*     */       } else {
/*     */         try {
/* 120 */           JarFileScanner.scan(new URL(su).openStream(), "", sl);
/*     */         } catch (IOException ex) {
/* 122 */           throw new ScannerException("IO error when scanning jar " + u, ex);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\scanning\uri\VfsSchemeScanner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */