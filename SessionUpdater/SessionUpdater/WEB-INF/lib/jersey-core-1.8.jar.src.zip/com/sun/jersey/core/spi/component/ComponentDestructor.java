/*    */ package com.sun.jersey.core.spi.component;
/*    */ 
/*    */ import com.sun.jersey.core.reflection.AnnotatedMethod;
/*    */ import com.sun.jersey.core.reflection.MethodList;
/*    */ import com.sun.jersey.core.reflection.ReflectionHelper;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ComponentDestructor
/*    */ {
/*    */   private final List<Method> preDestroys;
/*    */   
/*    */   public ComponentDestructor(Class c)
/*    */   {
/* 66 */     this.preDestroys = getPreDestroyMethods(c);
/*    */   }
/*    */   
/*    */   private static List<Method> getPreDestroyMethods(Class c) {
/* 70 */     Class preDestroyClass = ReflectionHelper.classForName("javax.annotation.PreDestroy");
/* 71 */     List<Method> list = new ArrayList();
/* 72 */     HashSet<String> names = new HashSet();
/* 73 */     if (preDestroyClass != null) {
/* 74 */       MethodList methodList = new MethodList(c, true);
/* 75 */       for (AnnotatedMethod m : methodList.hasAnnotation(preDestroyClass).hasNumParams(0).hasReturnType(Void.TYPE))
/*    */       {
/*    */ 
/*    */ 
/* 79 */         Method method = m.getMethod();
/*    */         
/* 81 */         if (names.add(method.getName())) {
/* 82 */           ReflectionHelper.setAccessibleMethod(method);
/* 83 */           list.add(method);
/*    */         }
/*    */       }
/*    */     }
/* 87 */     return list;
/*    */   }
/*    */   
/*    */   public void destroy(Object o) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/*    */   {
/* 92 */     for (Method preDestroy : this.preDestroys) {
/* 93 */       preDestroy.invoke(o, new Object[0]);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\component\ComponentDestructor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */