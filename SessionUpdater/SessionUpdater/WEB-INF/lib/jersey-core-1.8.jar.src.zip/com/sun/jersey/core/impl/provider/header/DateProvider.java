/*    */ package com.sun.jersey.core.impl.provider.header;
/*    */ 
/*    */ import com.sun.jersey.core.header.HttpDateFormat;
/*    */ import com.sun.jersey.core.header.reader.HttpHeaderReader;
/*    */ import com.sun.jersey.spi.HeaderDelegateProvider;
/*    */ import java.text.ParseException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateProvider
/*    */   implements HeaderDelegateProvider<Date>
/*    */ {
/*    */   public boolean supports(Class<?> type)
/*    */   {
/* 56 */     return Date.class.isAssignableFrom(type);
/*    */   }
/*    */   
/*    */   public String toString(Date header) {
/* 60 */     return HttpDateFormat.getPreferedDateFormat().format(header);
/*    */   }
/*    */   
/*    */   public Date fromString(String header) {
/*    */     try {
/* 65 */       return HttpHeaderReader.readDate(header);
/*    */     } catch (ParseException ex) {
/* 67 */       throw new IllegalArgumentException("Error parsing date '" + header + "'", ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\header\DateProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */