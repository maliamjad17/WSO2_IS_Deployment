/*     */ package com.sun.jersey.core.impl.provider.entity;
/*     */ 
/*     */ import com.sun.jersey.core.provider.AbstractMessageReaderWriterProvider;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import javax.ws.rs.Consumes;
/*     */ import javax.ws.rs.Produces;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Produces({"application/octet-stream", "*/*"})
/*     */ @Consumes({"application/octet-stream", "*/*"})
/*     */ public final class ByteArrayProvider
/*     */   extends AbstractMessageReaderWriterProvider<byte[]>
/*     */ {
/*     */   public boolean supports(Class type)
/*     */   {
/*  64 */     return type == byte[].class;
/*     */   }
/*     */   
/*     */   public boolean isReadable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
/*  68 */     return type == byte[].class;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] readFrom(Class<byte[]> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, String> httpHeaders, InputStream entityStream)
/*     */     throws IOException
/*     */   {
/*  78 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/*  79 */     writeTo(entityStream, out);
/*  80 */     return out.toByteArray();
/*     */   }
/*     */   
/*     */   public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
/*  84 */     return type == byte[].class;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeTo(byte[] t, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, OutputStream entityStream)
/*     */     throws IOException
/*     */   {
/*  95 */     entityStream.write(t);
/*     */   }
/*     */   
/*     */   public long getSize(byte[] t, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType)
/*     */   {
/* 100 */     return t.length;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\entity\ByteArrayProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */