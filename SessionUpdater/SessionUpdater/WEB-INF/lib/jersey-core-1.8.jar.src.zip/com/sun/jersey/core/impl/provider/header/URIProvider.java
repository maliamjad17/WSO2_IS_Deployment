/*    */ package com.sun.jersey.core.impl.provider.header;
/*    */ 
/*    */ import com.sun.jersey.spi.HeaderDelegateProvider;
/*    */ import java.net.URI;
/*    */ import java.net.URISyntaxException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class URIProvider
/*    */   implements HeaderDelegateProvider<URI>
/*    */ {
/*    */   public boolean supports(Class<?> type)
/*    */   {
/* 54 */     return type == URI.class;
/*    */   }
/*    */   
/*    */   public String toString(URI header) {
/* 58 */     return header.toASCIIString();
/*    */   }
/*    */   
/*    */   public URI fromString(String header) {
/*    */     try {
/* 63 */       return new URI(header);
/*    */     } catch (URISyntaxException e) {
/* 65 */       throw new IllegalArgumentException("Error parsing uri '" + header + "'", e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\header\URIProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */