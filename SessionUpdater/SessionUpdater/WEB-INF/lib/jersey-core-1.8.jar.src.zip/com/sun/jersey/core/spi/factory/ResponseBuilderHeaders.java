/*     */ package com.sun.jersey.core.spi.factory;
/*     */ 
/*     */ import com.sun.jersey.core.util.KeyComparatorHashMap;
/*     */ import com.sun.jersey.core.util.StringIgnoreCaseKeyComparator;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResponseBuilderHeaders
/*     */ {
/*     */   public static final int CACHE_CONTROL = 0;
/*     */   public static final int CONTENT_LANGUAGE = 1;
/*     */   public static final int CONTENT_LOCATION = 2;
/*     */   public static final int CONTENT_TYPE = 3;
/*     */   public static final int ETAG = 4;
/*     */   public static final int LAST_MODIFIED = 5;
/*     */   public static final int LOCATION = 6;
/*  70 */   private static final Map<String, Integer> HEADER_MAP = ;
/*     */   
/*  72 */   private static final String[] HEADER_ARRAY = createHeaderArray();
/*     */   
/*     */   private static Map<String, Integer> createHeaderMap() {
/*  75 */     Map<String, Integer> m = new KeyComparatorHashMap(StringIgnoreCaseKeyComparator.SINGLETON);
/*     */     
/*     */ 
/*  78 */     m.put("Cache-Control", Integer.valueOf(0));
/*  79 */     m.put("Content-Language", Integer.valueOf(1));
/*  80 */     m.put("Content-Location", Integer.valueOf(2));
/*  81 */     m.put("Content-Type", Integer.valueOf(3));
/*  82 */     m.put("ETag", Integer.valueOf(4));
/*  83 */     m.put("Last-Modified", Integer.valueOf(5));
/*  84 */     m.put("Location", Integer.valueOf(6));
/*     */     
/*  86 */     return Collections.unmodifiableMap(m);
/*     */   }
/*     */   
/*     */   private static String[] createHeaderArray() {
/*  90 */     Map<String, Integer> m = createHeaderMap();
/*     */     
/*  92 */     String[] a = new String[m.size()];
/*  93 */     for (Map.Entry<String, Integer> e : m.entrySet()) {
/*  94 */       a[((Integer)e.getValue()).intValue()] = ((String)e.getKey());
/*     */     }
/*     */     
/*  97 */     return a;
/*     */   }
/*     */   
/*     */   public static int getSize()
/*     */   {
/* 102 */     return HEADER_MAP.size();
/*     */   }
/*     */   
/*     */   public static String getNameFromId(int id) {
/* 106 */     return HEADER_ARRAY[id];
/*     */   }
/*     */   
/*     */   public static Integer getIdFromName(String name) {
/* 110 */     return (Integer)HEADER_MAP.get(name);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\spi\factory\ResponseBuilderHeaders.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */