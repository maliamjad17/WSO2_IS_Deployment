/*     */ package com.sun.jersey.core.header.reader;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HttpHeaderListAdapter
/*     */   extends HttpHeaderReader
/*     */ {
/*     */   private HttpHeaderReader reader;
/*     */   boolean isTerminated;
/*     */   
/*     */   public HttpHeaderListAdapter(HttpHeaderReader reader)
/*     */   {
/*  55 */     this.reader = reader;
/*     */   }
/*     */   
/*     */   public void reset() {
/*  59 */     this.isTerminated = false;
/*     */   }
/*     */   
/*     */   public boolean hasNext()
/*     */   {
/*  64 */     if (this.isTerminated) {
/*  65 */       return false;
/*     */     }
/*  67 */     if (this.reader.hasNext()) {
/*  68 */       if (this.reader.hasNextSeparator(',', true)) {
/*  69 */         this.isTerminated = true;
/*  70 */         return false;
/*     */       }
/*  72 */       return true;
/*     */     }
/*     */     
/*  75 */     return false;
/*     */   }
/*     */   
/*     */   public boolean hasNextSeparator(char separator, boolean skipWhiteSpace) {
/*  79 */     if (this.isTerminated) {
/*  80 */       return false;
/*     */     }
/*  82 */     if (this.reader.hasNextSeparator(',', skipWhiteSpace)) {
/*  83 */       this.isTerminated = true;
/*  84 */       return false;
/*     */     }
/*  86 */     return this.reader.hasNextSeparator(separator, skipWhiteSpace);
/*     */   }
/*     */   
/*     */   public HttpHeaderReader.Event next() throws ParseException {
/*  90 */     return next(true);
/*     */   }
/*     */   
/*     */   public HttpHeaderReader.Event next(boolean skipWhiteSpace) throws ParseException {
/*  94 */     if (this.isTerminated) {
/*  95 */       throw new ParseException("End of header", getIndex());
/*     */     }
/*  97 */     if (this.reader.hasNextSeparator(',', skipWhiteSpace)) {
/*  98 */       this.isTerminated = true;
/*  99 */       throw new ParseException("End of header", getIndex());
/*     */     }
/*     */     
/* 102 */     return this.reader.next(skipWhiteSpace);
/*     */   }
/*     */   
/*     */   public String nextSeparatedString(char startSeparator, char endSeparator) throws ParseException {
/* 106 */     if (this.isTerminated) {
/* 107 */       throw new ParseException("End of header", getIndex());
/*     */     }
/* 109 */     if (this.reader.hasNextSeparator(',', true)) {
/* 110 */       this.isTerminated = true;
/* 111 */       throw new ParseException("End of header", getIndex());
/*     */     }
/*     */     
/* 114 */     return this.reader.nextSeparatedString(startSeparator, endSeparator);
/*     */   }
/*     */   
/*     */   public HttpHeaderReader.Event getEvent() {
/* 118 */     return this.reader.getEvent();
/*     */   }
/*     */   
/*     */   public String getEventValue() {
/* 122 */     return this.reader.getEventValue();
/*     */   }
/*     */   
/*     */   public String getRemainder() {
/* 126 */     return this.reader.getRemainder();
/*     */   }
/*     */   
/*     */   public int getIndex() {
/* 130 */     return this.reader.getIndex();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\header\reader\HttpHeaderListAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */