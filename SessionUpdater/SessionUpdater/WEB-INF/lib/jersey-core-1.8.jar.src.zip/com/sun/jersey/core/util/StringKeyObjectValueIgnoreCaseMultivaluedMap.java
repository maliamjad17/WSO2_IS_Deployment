/*     */ package com.sun.jersey.core.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringKeyObjectValueIgnoreCaseMultivaluedMap
/*     */   extends StringKeyIgnoreCaseMultivaluedMap<Object>
/*     */ {
/*     */   public StringKeyObjectValueIgnoreCaseMultivaluedMap() {}
/*     */   
/*     */   public StringKeyObjectValueIgnoreCaseMultivaluedMap(StringKeyObjectValueIgnoreCaseMultivaluedMap that)
/*     */   {
/*  61 */     super(that);
/*     */   }
/*     */   
/*     */   public <A> List<A> get(String key, Class<A> type)
/*     */   {
/*  66 */     ArrayList<A> l = null;
/*  67 */     List<Object> values = (List)get(key);
/*  68 */     if (values != null) {
/*  69 */       l = new ArrayList();
/*  70 */       for (Object value : values) {
/*  71 */         if (type.isInstance(value)) {
/*  72 */           l.add(value);
/*     */         } else {
/*  74 */           throw new IllegalArgumentException(type + " is not an instance of " + value.getClass());
/*     */         }
/*     */       }
/*     */     }
/*  78 */     return l;
/*     */   }
/*     */   
/*     */   public <A> A getFirst(String key, Class<A> type)
/*     */   {
/*  83 */     Object value = getFirst(key);
/*  84 */     if (value == null) {
/*  85 */       return null;
/*     */     }
/*  87 */     if (type.isInstance(value)) {
/*  88 */       return (A)value;
/*     */     }
/*  90 */     throw new IllegalArgumentException(type + " is not an instance of " + value.getClass());
/*     */   }
/*     */   
/*     */ 
/*     */   public <A> A getFirst(String key, A defaultValue)
/*     */   {
/*  96 */     Object value = getFirst(key);
/*  97 */     if (value == null) {
/*  98 */       return defaultValue;
/*     */     }
/* 100 */     if (defaultValue.getClass().isInstance(value)) {
/* 101 */       return (A)value;
/*     */     }
/* 103 */     throw new IllegalArgumentException(defaultValue.getClass() + " is not an instance of " + value.getClass());
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\util\StringKeyObjectValueIgnoreCaseMultivaluedMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */