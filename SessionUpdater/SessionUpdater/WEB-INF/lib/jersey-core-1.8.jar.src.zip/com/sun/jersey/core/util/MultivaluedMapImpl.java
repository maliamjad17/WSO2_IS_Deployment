/*     */ package com.sun.jersey.core.util;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultivaluedMapImpl
/*     */   extends HashMap<String, List<String>>
/*     */   implements MultivaluedMap<String, String>
/*     */ {
/*     */   static final long serialVersionUID = -6052320403766368902L;
/*     */   
/*     */   public MultivaluedMapImpl() {}
/*     */   
/*     */   public MultivaluedMapImpl(MultivaluedMap<String, String> that)
/*     */   {
/*  66 */     for (Map.Entry<String, List<String>> e : that.entrySet()) {
/*  67 */       put(e.getKey(), new ArrayList((Collection)e.getValue()));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void putSingle(String key, String value)
/*     */   {
/*  75 */     List<String> l = getList(key);
/*     */     
/*  77 */     l.clear();
/*  78 */     if (value != null) {
/*  79 */       l.add(value);
/*     */     } else {
/*  81 */       l.add("");
/*     */     }
/*     */   }
/*     */   
/*     */   public final void add(String key, String value) {
/*  86 */     List<String> l = getList(key);
/*     */     
/*  88 */     if (value != null) {
/*  89 */       l.add(value);
/*     */     } else {
/*  91 */       l.add("");
/*     */     }
/*     */   }
/*     */   
/*     */   public final String getFirst(String key) {
/*  96 */     List<String> values = (List)get(key);
/*  97 */     if ((values != null) && (values.size() > 0)) {
/*  98 */       return (String)values.get(0);
/*     */     }
/* 100 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public final void addFirst(String key, String value)
/*     */   {
/* 106 */     List<String> l = getList(key);
/*     */     
/* 108 */     if (value != null) {
/* 109 */       l.add(0, value);
/*     */     } else
/* 111 */       l.add(0, "");
/*     */   }
/*     */   
/*     */   public final <A> List<A> get(String key, Class<A> type) {
/* 115 */     Constructor<A> c = null;
/*     */     try {
/* 117 */       c = type.getConstructor(new Class[] { String.class });
/*     */     } catch (Exception ex) {
/* 119 */       throw new IllegalArgumentException(type.getName() + " has no String constructor", ex);
/*     */     }
/*     */     
/* 122 */     ArrayList<A> l = null;
/* 123 */     List<String> values = (List)get(key);
/* 124 */     if (values != null) {
/* 125 */       l = new ArrayList();
/* 126 */       for (String value : values) {
/*     */         try {
/* 128 */           l.add(c.newInstance(new Object[] { value }));
/*     */         } catch (Exception ex) {
/* 130 */           l.add(null);
/*     */         }
/*     */       }
/*     */     }
/* 134 */     return l;
/*     */   }
/*     */   
/*     */   public final void putSingle(String key, Object value) {
/* 138 */     List<String> l = getList(key);
/*     */     
/* 140 */     l.clear();
/* 141 */     if (value != null) {
/* 142 */       l.add(value.toString());
/*     */     } else
/* 144 */       l.add("");
/*     */   }
/*     */   
/*     */   public final void add(String key, Object value) {
/* 148 */     List<String> l = getList(key);
/*     */     
/* 150 */     if (value != null) {
/* 151 */       l.add(value.toString());
/*     */     } else
/* 153 */       l.add("");
/*     */   }
/*     */   
/*     */   private List<String> getList(String key) {
/* 157 */     List<String> l = (List)get(key);
/* 158 */     if (l == null) {
/* 159 */       l = new LinkedList();
/* 160 */       put(key, l);
/*     */     }
/* 162 */     return l;
/*     */   }
/*     */   
/*     */   public final <A> A getFirst(String key, Class<A> type) {
/* 166 */     String value = getFirst(key);
/* 167 */     if (value == null)
/* 168 */       return null;
/* 169 */     Constructor<A> c = null;
/*     */     try {
/* 171 */       c = type.getConstructor(new Class[] { String.class });
/*     */     } catch (Exception ex) {
/* 173 */       throw new IllegalArgumentException(type.getName() + " has no String constructor", ex);
/*     */     }
/* 175 */     A retVal = null;
/*     */     try {
/* 177 */       retVal = c.newInstance(new Object[] { value });
/*     */     }
/*     */     catch (Exception ex) {}
/* 180 */     return retVal;
/*     */   }
/*     */   
/*     */   public final <A> A getFirst(String key, A defaultValue)
/*     */   {
/* 185 */     String value = getFirst(key);
/* 186 */     if (value == null) {
/* 187 */       return defaultValue;
/*     */     }
/* 189 */     Class<A> type = defaultValue.getClass();
/*     */     
/* 191 */     Constructor<A> c = null;
/*     */     try {
/* 193 */       c = type.getConstructor(new Class[] { String.class });
/*     */     } catch (Exception ex) {
/* 195 */       throw new IllegalArgumentException(type.getName() + " has no String constructor", ex);
/*     */     }
/* 197 */     A retVal = defaultValue;
/*     */     try {
/* 199 */       retVal = c.newInstance(new Object[] { value });
/*     */     }
/*     */     catch (Exception ex) {}
/* 202 */     return retVal;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\util\MultivaluedMapImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */