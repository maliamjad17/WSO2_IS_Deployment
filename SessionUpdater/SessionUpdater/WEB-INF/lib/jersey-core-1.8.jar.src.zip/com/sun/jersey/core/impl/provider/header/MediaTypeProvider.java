/*    */ package com.sun.jersey.core.impl.provider.header;
/*    */ 
/*    */ import com.sun.jersey.core.header.reader.HttpHeaderReader;
/*    */ import com.sun.jersey.spi.HeaderDelegateProvider;
/*    */ import java.text.ParseException;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import javax.ws.rs.core.MediaType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MediaTypeProvider
/*    */   implements HeaderDelegateProvider<MediaType>
/*    */ {
/*    */   public boolean supports(Class<?> type)
/*    */   {
/* 57 */     return MediaType.class.isAssignableFrom(type);
/*    */   }
/*    */   
/*    */   public String toString(MediaType header)
/*    */   {
/* 62 */     StringBuilder b = new StringBuilder();
/* 63 */     b.append(header.getType()).append('/').append(header.getSubtype());
/* 64 */     for (Map.Entry<String, String> e : header.getParameters().entrySet()) {
/* 65 */       b.append("; ").append((String)e.getKey()).append('=');
/* 66 */       WriterUtil.appendQuotedIfWhiteSpaceOrQuote(b, (String)e.getValue());
/*    */     }
/* 68 */     return b.toString();
/*    */   }
/*    */   
/*    */   public MediaType fromString(String header)
/*    */   {
/* 73 */     if (header == null) {
/* 74 */       throw new IllegalArgumentException("Media type is null");
/*    */     }
/*    */     try {
/* 77 */       return valueOf(HttpHeaderReader.newInstance(header));
/*    */     } catch (ParseException ex) {
/* 79 */       throw new IllegalArgumentException("Error parsing media type '" + header + "'", ex);
/*    */     }
/*    */   }
/*    */   
/*    */   public static MediaType valueOf(HttpHeaderReader reader)
/*    */     throws ParseException
/*    */   {
/* 86 */     reader.hasNext();
/*    */     
/*    */ 
/* 89 */     String type = reader.nextToken();
/* 90 */     reader.nextSeparator('/');
/*    */     
/* 92 */     String subType = reader.nextToken();
/*    */     
/* 94 */     Map<String, String> params = null;
/*    */     
/* 96 */     if (reader.hasNext()) {
/* 97 */       params = HttpHeaderReader.readParameters(reader);
/*    */     }
/* 99 */     return new MediaType(type, subType, params);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\impl\provider\header\MediaTypeProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */