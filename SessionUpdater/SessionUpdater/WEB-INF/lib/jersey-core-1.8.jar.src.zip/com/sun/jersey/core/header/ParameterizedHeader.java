/*     */ package com.sun.jersey.core.header;
/*     */ 
/*     */ import com.sun.jersey.core.header.reader.HttpHeaderReader;
/*     */ import java.text.ParseException;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterizedHeader
/*     */ {
/*     */   private String value;
/*     */   private Map<String, String> parameters;
/*     */   
/*     */   public ParameterizedHeader(String header)
/*     */     throws ParseException
/*     */   {
/*  65 */     this(HttpHeaderReader.newInstance(header));
/*     */   }
/*     */   
/*     */   public ParameterizedHeader(HttpHeaderReader reader) throws ParseException {
/*  69 */     reader.hasNext();
/*     */     
/*  71 */     this.value = "";
/*  72 */     while ((reader.hasNext()) && (!reader.hasNextSeparator(';', false))) {
/*  73 */       reader.next();
/*  74 */       this.value += reader.getEventValue();
/*     */     }
/*     */     
/*  77 */     if (reader.hasNext())
/*  78 */       this.parameters = HttpHeaderReader.readParameters(reader);
/*  79 */     if (this.parameters == null) {
/*  80 */       this.parameters = Collections.emptyMap();
/*     */     } else {
/*  82 */       this.parameters = Collections.unmodifiableMap(this.parameters);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getValue()
/*     */   {
/*  91 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, String> getParameters()
/*     */   {
/* 100 */     return this.parameters;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\jersey-core-1.8.jar!\com\sun\jersey\core\header\ParameterizedHeader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */