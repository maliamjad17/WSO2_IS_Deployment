package org.objectweb.asm;

class Edge
{
  int a;
  Label b;
  Edge c;
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\SessionUpdater.war!\WEB-INF\lib\asm-3.1.jar!\org\objectweb\asm\Edge.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */