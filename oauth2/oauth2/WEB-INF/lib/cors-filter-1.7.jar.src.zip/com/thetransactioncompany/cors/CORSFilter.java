/*     */ package com.thetransactioncompany.cors;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CORSFilter
/*     */   implements Filter
/*     */ {
/*     */   private CORSConfiguration config;
/*     */   private CORSRequestHandler handler;
/*     */   
/*     */   public CORSConfiguration getConfiguration()
/*     */   {
/*  64 */     return this.config;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void init(FilterConfig filterConfig)
/*     */     throws ServletException
/*     */   {
/*  81 */     CORSConfigurationLoader configLoader = new CORSConfigurationLoader(filterConfig);
/*     */     try
/*     */     {
/*  84 */       this.config = configLoader.load();
/*     */     }
/*     */     catch (CORSConfigurationException e)
/*     */     {
/*  88 */       throw new ServletException(e.getMessage(), e);
/*     */     }
/*     */     
/*  91 */     this.handler = new CORSRequestHandler(this.config);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void printMessage(HttpServletResponse response, int sc, String msg)
/*     */     throws IOException, ServletException
/*     */   {
/* 114 */     response.setStatus(sc);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 119 */     response.resetBuffer();
/*     */     
/* 121 */     response.setContentType("text/plain");
/*     */     
/* 123 */     PrintWriter out = response.getWriter();
/*     */     
/* 125 */     out.println("Cross-Origin Resource Sharing (CORS) Filter: " + msg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/* 147 */     this.handler.tagRequest(request);
/*     */     
/* 149 */     CORSRequestType type = CORSRequestType.detect(request);
/*     */     try
/*     */     {
/* 152 */       if (type.equals(CORSRequestType.ACTUAL))
/*     */       {
/*     */ 
/* 155 */         this.handler.handleActualRequest(request, response);
/* 156 */         chain.doFilter(request, response);
/*     */       }
/* 158 */       else if (type.equals(CORSRequestType.PREFLIGHT))
/*     */       {
/*     */ 
/*     */ 
/* 162 */         this.handler.handlePreflightRequest(request, response);
/*     */       }
/* 164 */       else if (this.config.allowGenericHttpRequests)
/*     */       {
/*     */ 
/* 167 */         request.setAttribute("cors.isCorsRequest", Boolean.valueOf(false));
/* 168 */         chain.doFilter(request, response);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 173 */         request.setAttribute("cors.isCorsRequest", Boolean.valueOf(false));
/* 174 */         printMessage(response, 403, "Generic HTTP requests not allowed");
/*     */       }
/*     */     }
/*     */     catch (InvalidCORSRequestException e)
/*     */     {
/* 179 */       request.setAttribute("cors.isCorsRequest", Boolean.valueOf(false));
/* 180 */       printMessage(response, 400, e.getMessage());
/*     */     }
/*     */     catch (CORSOriginDeniedException e)
/*     */     {
/* 184 */       String msg = e.getMessage() + ": " + e.getRequestOrigin();
/* 185 */       printMessage(response, 403, msg);
/*     */     }
/*     */     catch (UnsupportedHTTPMethodException e)
/*     */     {
/* 189 */       String msg = e.getMessage();
/*     */       
/* 191 */       HTTPMethod method = e.getRequestedMethod();
/*     */       
/* 193 */       if (method != null) {
/* 194 */         msg = msg + ": " + method.toString();
/*     */       }
/* 196 */       printMessage(response, 405, msg);
/*     */     }
/*     */     catch (UnsupportedHTTPHeaderException e)
/*     */     {
/* 200 */       String msg = e.getMessage();
/*     */       
/* 202 */       HeaderFieldName header = e.getRequestHeader();
/*     */       
/* 204 */       if (header != null) {
/* 205 */         msg = msg + ": " + header.toString();
/*     */       }
/* 207 */       printMessage(response, 403, msg);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/* 230 */     if (((request instanceof HttpServletRequest)) && ((response instanceof HttpServletResponse)))
/*     */     {
/*     */ 
/* 233 */       doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
/*     */     }
/*     */     else
/*     */     {
/* 237 */       throw new ServletException("Cannot filter non-HTTP requests/responses");
/*     */     }
/*     */   }
/*     */   
/*     */   public void destroy() {}
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\cors-filter-1.7.jar!\com\thetransactioncompany\cors\CORSFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */