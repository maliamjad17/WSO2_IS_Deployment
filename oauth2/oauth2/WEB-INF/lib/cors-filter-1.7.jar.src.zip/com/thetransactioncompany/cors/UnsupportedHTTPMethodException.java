/*    */ package com.thetransactioncompany.cors;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsupportedHTTPMethodException
/*    */   extends CORSException
/*    */ {
/*    */   private final HTTPMethod method;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public UnsupportedHTTPMethodException(String message)
/*    */   {
/* 26 */     this(message, null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public UnsupportedHTTPMethodException(String message, HTTPMethod requestedMethod)
/*    */   {
/* 40 */     super(message);
/*    */     
/* 42 */     this.method = requestedMethod;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HTTPMethod getRequestedMethod()
/*    */   {
/* 53 */     return this.method;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\cors-filter-1.7.jar!\com\thetransactioncompany\cors\UnsupportedHTTPMethodException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */