/*    */ package com.thetransactioncompany.cors;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CORSException
/*    */   extends Exception
/*    */ {
/*    */   public CORSException(String message)
/*    */   {
/* 20 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\cors-filter-1.7.jar!\com\thetransactioncompany\cors\CORSException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */