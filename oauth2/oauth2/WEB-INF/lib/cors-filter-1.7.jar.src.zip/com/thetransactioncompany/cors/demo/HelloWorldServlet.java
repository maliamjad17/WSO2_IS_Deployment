/*    */ package com.thetransactioncompany.cors.demo;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HelloWorldServlet
/*    */   extends HttpServlet
/*    */ {
/*    */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*    */     throws IOException, ServletException
/*    */   {
/* 22 */     doHelloWorld(request, response);
/*    */   }
/*    */   
/*    */ 
/*    */   public void doPost(HttpServletRequest request, HttpServletResponse response)
/*    */     throws IOException, ServletException
/*    */   {
/* 29 */     doHelloWorld(request, response);
/*    */   }
/*    */   
/*    */ 
/*    */   private void doHelloWorld(HttpServletRequest request, HttpServletResponse response)
/*    */     throws IOException, ServletException
/*    */   {
/* 36 */     response.setContentType("text/plain");
/*    */     
/* 38 */     response.addHeader("X-Test-1", "Hello world!");
/* 39 */     response.addHeader("X-Test-2", "1, 2, 3");
/*    */     
/* 41 */     PrintWriter out = response.getWriter();
/*    */     
/* 43 */     out.println("[HTTP " + request.getMethod() + "] Hello world!");
/*    */     
/* 45 */     out.println("");
/*    */     
/* 47 */     out.println("Listing CORS Filter request tags: ");
/* 48 */     out.println("\tcors.isCorsRequest: " + request.getAttribute("cors.isCorsRequest"));
/* 49 */     out.println("\tcors.origin: " + request.getAttribute("cors.origin"));
/* 50 */     out.println("\tcors.requestType: " + request.getAttribute("cors.requestType"));
/* 51 */     out.println("\tcors.requestHeaders: " + request.getAttribute("cors.requestHeaders"));
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\cors-filter-1.7.jar!\com\thetransactioncompany\cors\demo\HelloWorldServlet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */