/*    */ package com.thetransactioncompany.cors;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CORSOriginDeniedException
/*    */   extends CORSException
/*    */ {
/*    */   private final Origin requestOrigin;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CORSOriginDeniedException(String message)
/*    */   {
/* 26 */     this(message, null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CORSOriginDeniedException(String message, Origin requestOrigin)
/*    */   {
/* 39 */     super(message);
/*    */     
/* 41 */     this.requestOrigin = requestOrigin;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Origin getRequestOrigin()
/*    */   {
/* 52 */     return this.requestOrigin;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\cors-filter-1.7.jar!\com\thetransactioncompany\cors\CORSOriginDeniedException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */