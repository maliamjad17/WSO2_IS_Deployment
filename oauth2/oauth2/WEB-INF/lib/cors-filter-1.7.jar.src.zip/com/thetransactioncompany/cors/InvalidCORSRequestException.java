/*    */ package com.thetransactioncompany.cors;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidCORSRequestException
/*    */   extends CORSException
/*    */ {
/*    */   public InvalidCORSRequestException(String message)
/*    */   {
/* 21 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\cors-filter-1.7.jar!\com\thetransactioncompany\cors\InvalidCORSRequestException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */