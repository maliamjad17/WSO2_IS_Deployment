/*    */ package com.thetransactioncompany.cors;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CORSRequestType
/*    */ {
/* 19 */   ACTUAL, 
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 25 */   PREFLIGHT, 
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 31 */   OTHER;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private CORSRequestType() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static CORSRequestType detect(HttpServletRequest request)
/*    */   {
/* 44 */     if (request.getHeader("Origin") == null) {
/* 45 */       return OTHER;
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 51 */     String serverOrigin = request.getScheme() + "://" + request.getHeader("Host");
/*    */     
/* 53 */     if ((request.getHeader("Host") != null) && (request.getHeader("Origin").equals(serverOrigin))) {
/* 54 */       return OTHER;
/*    */     }
/*    */     
/* 57 */     if ((request.getHeader("Access-Control-Request-Method") != null) && (request.getMethod() != null) && (request.getMethod().equals("OPTIONS")))
/*    */     {
/*    */ 
/*    */ 
/* 61 */       return PREFLIGHT;
/*    */     }
/*    */     
/* 64 */     return ACTUAL;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\cors-filter-1.7.jar!\com\thetransactioncompany\cors\CORSRequestType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */