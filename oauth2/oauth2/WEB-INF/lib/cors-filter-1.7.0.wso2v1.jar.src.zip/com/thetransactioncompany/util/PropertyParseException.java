/*    */ package com.thetransactioncompany.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyParseException
/*    */   extends Exception
/*    */ {
/*    */   private final String propertyKey;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final String propertyValue;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PropertyParseException(String message)
/*    */   {
/* 37 */     super(message);
/* 38 */     this.propertyKey = null;
/* 39 */     this.propertyValue = null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PropertyParseException(String message, String propertyKey)
/*    */   {
/* 53 */     super(message);
/* 54 */     this.propertyKey = propertyKey;
/* 55 */     this.propertyValue = null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PropertyParseException(String message, String propertyKey, String propertyValue)
/*    */   {
/* 73 */     super(message);
/* 74 */     this.propertyKey = propertyKey;
/* 75 */     this.propertyValue = propertyValue;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getPropertyKey()
/*    */   {
/* 87 */     return this.propertyKey;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getPropertyValue()
/*    */   {
/* 99 */     return this.propertyValue;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\cors-filter-1.7.0.wso2v1.jar!\com\thetransactioncompany\util\PropertyParseException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */