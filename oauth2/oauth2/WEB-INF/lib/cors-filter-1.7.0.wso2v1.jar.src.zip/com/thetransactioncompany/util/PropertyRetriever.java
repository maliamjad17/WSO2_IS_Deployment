/*     */ package com.thetransactioncompany.util;
/*     */ 
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyRetriever
/*     */ {
/*     */   private Properties props;
/*     */   
/*     */   public PropertyRetriever(Properties props)
/*     */   {
/*  32 */     this.props = props;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getBoolean(String key)
/*     */     throws PropertyParseException
/*     */   {
/*  48 */     String value = this.props.getProperty(key);
/*     */     
/*  50 */     if (value == null) {
/*  51 */       throw new PropertyParseException("Missing property", key);
/*     */     }
/*  53 */     if (value.equalsIgnoreCase("true")) {
/*  54 */       return true;
/*     */     }
/*  56 */     if (value.equalsIgnoreCase("false")) {
/*  57 */       return false;
/*     */     }
/*     */     
/*  60 */     throw new PropertyParseException("Invalid boolean property", key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getOptBoolean(String key, boolean def)
/*     */     throws PropertyParseException
/*     */   {
/*  77 */     String value = this.props.getProperty(key);
/*     */     
/*  79 */     if ((value == null) || (value.trim().isEmpty())) {
/*  80 */       return def;
/*     */     }
/*  82 */     if (value.equalsIgnoreCase("true")) {
/*  83 */       return true;
/*     */     }
/*  85 */     if (value.equalsIgnoreCase("false")) {
/*  86 */       return false;
/*     */     }
/*  88 */     throw new PropertyParseException("Invalid boolean property", key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getInt(String key)
/*     */     throws PropertyParseException
/*     */   {
/* 104 */     String value = this.props.getProperty(key);
/*     */     
/* 106 */     if (value == null) {
/* 107 */       throw new PropertyParseException("Missing property", key);
/*     */     }
/*     */     try {
/* 110 */       return Integer.parseInt(value);
/*     */     }
/*     */     catch (NumberFormatException e)
/*     */     {
/* 114 */       throw new PropertyParseException("Invalid int property", key, value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOptInt(String key, int def)
/*     */     throws PropertyParseException
/*     */   {
/* 132 */     String value = this.props.getProperty(key);
/*     */     
/* 134 */     if ((value == null) || (value.trim().isEmpty())) {
/* 135 */       return def;
/*     */     }
/*     */     try {
/* 138 */       return Integer.parseInt(value);
/*     */     }
/*     */     catch (NumberFormatException e)
/*     */     {
/* 142 */       throw new PropertyParseException("Invalid int property", key);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getLong(String key)
/*     */     throws PropertyParseException
/*     */   {
/* 159 */     String value = this.props.getProperty(key);
/*     */     
/* 161 */     if (value == null) {
/* 162 */       throw new PropertyParseException("Missing property", key);
/*     */     }
/*     */     try {
/* 165 */       return Long.parseLong(value);
/*     */     }
/*     */     catch (NumberFormatException e)
/*     */     {
/* 169 */       throw new PropertyParseException("Invalid long property", key, value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getOptLong(String key, long def)
/*     */     throws PropertyParseException
/*     */   {
/* 187 */     String value = this.props.getProperty(key);
/*     */     
/* 189 */     if ((value == null) || (value.trim().isEmpty())) {
/* 190 */       return def;
/*     */     }
/*     */     try {
/* 193 */       return Long.parseLong(value);
/*     */     }
/*     */     catch (NumberFormatException e)
/*     */     {
/* 197 */       throw new PropertyParseException("Invalid long property", key, value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getFloat(String key)
/*     */     throws PropertyParseException
/*     */   {
/* 214 */     String value = this.props.getProperty(key);
/*     */     
/* 216 */     if (value == null) {
/* 217 */       throw new PropertyParseException("Missing property", key);
/*     */     }
/*     */     try {
/* 220 */       return Float.parseFloat(value);
/*     */     }
/*     */     catch (NumberFormatException e)
/*     */     {
/* 224 */       throw new PropertyParseException("Invalid float property", key, value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getOptFloat(String key, float def)
/*     */     throws PropertyParseException
/*     */   {
/* 242 */     String value = this.props.getProperty(key);
/*     */     
/* 244 */     if ((value == null) || (value.trim().isEmpty())) {
/* 245 */       return def;
/*     */     }
/*     */     try {
/* 248 */       return Float.parseFloat(value);
/*     */     }
/*     */     catch (NumberFormatException e)
/*     */     {
/* 252 */       throw new PropertyParseException("Invalid float property", key, value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getDouble(String key)
/*     */     throws PropertyParseException
/*     */   {
/* 269 */     String value = this.props.getProperty(key);
/*     */     
/* 271 */     if (value == null) {
/* 272 */       throw new PropertyParseException("Missing property", key);
/*     */     }
/*     */     try {
/* 275 */       return Double.parseDouble(value);
/*     */     }
/*     */     catch (NumberFormatException e)
/*     */     {
/* 279 */       throw new PropertyParseException("Invalid double property", key, value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getOptDouble(String key, double def)
/*     */     throws PropertyParseException
/*     */   {
/* 297 */     String value = this.props.getProperty(key);
/*     */     
/* 299 */     if ((value == null) || (value.trim().isEmpty())) {
/* 300 */       return def;
/*     */     }
/*     */     try {
/* 303 */       return Double.parseDouble(value);
/*     */     }
/*     */     catch (NumberFormatException e)
/*     */     {
/* 307 */       throw new PropertyParseException("Invalid double property", key, value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getString(String key)
/*     */     throws PropertyParseException
/*     */   {
/* 324 */     String value = this.props.getProperty(key);
/*     */     
/* 326 */     if (value == null) {
/* 327 */       throw new PropertyParseException("Missing property", key);
/*     */     }
/* 329 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getOptString(String key, String def)
/*     */     throws PropertyParseException
/*     */   {
/* 347 */     String value = this.props.getProperty(key);
/*     */     
/* 349 */     if ((value == null) || (value.trim().isEmpty())) {
/* 350 */       return def;
/*     */     }
/* 352 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getEnumString(String key, String[] enums)
/*     */     throws PropertyParseException
/*     */   {
/* 370 */     String value = this.props.getProperty(key);
/*     */     
/* 372 */     if (value == null) {
/* 373 */       throw new PropertyParseException("Missing property", key);
/*     */     }
/* 375 */     for (String en : enums)
/*     */     {
/* 377 */       if (en.equalsIgnoreCase(value)) {
/* 378 */         return value;
/*     */       }
/*     */     }
/* 381 */     throw new PropertyParseException("Invalid enum string property", key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getOptEnumString(String key, String[] enums, String def)
/*     */     throws PropertyParseException
/*     */   {
/* 400 */     String value = this.props.getProperty(key);
/*     */     
/* 402 */     if ((value == null) || (value.trim().isEmpty())) {
/* 403 */       return def;
/*     */     }
/* 405 */     for (String en : enums)
/*     */     {
/* 407 */       if (en.equalsIgnoreCase(value)) {
/* 408 */         return value;
/*     */       }
/*     */     }
/* 411 */     throw new PropertyParseException("Invalid enum string property", key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T extends Enum<T>> T getEnum(String key, Class<T> enumClass)
/*     */     throws PropertyParseException
/*     */   {
/* 430 */     String value = this.props.getProperty(key);
/*     */     
/* 432 */     if (value == null) {
/* 433 */       throw new PropertyParseException("Missing property", key);
/*     */     }
/* 435 */     for (T en : (Enum[])enumClass.getEnumConstants())
/*     */     {
/* 437 */       if (en.toString().equalsIgnoreCase(value)) {
/* 438 */         return en;
/*     */       }
/*     */     }
/*     */     
/* 442 */     throw new PropertyParseException("Invalid enum property", key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T extends Enum<T>> T getOptEnum(String key, Class<T> enumClass, T def)
/*     */     throws PropertyParseException
/*     */   {
/* 463 */     String value = this.props.getProperty(key);
/*     */     
/* 465 */     if ((value == null) || (value.trim().isEmpty())) {
/* 466 */       return def;
/*     */     }
/* 468 */     for (T en : (Enum[])enumClass.getEnumConstants())
/*     */     {
/* 470 */       if (en.toString().equalsIgnoreCase(value)) {
/* 471 */         return en;
/*     */       }
/*     */     }
/*     */     
/* 475 */     throw new PropertyParseException("Invalid enum property", key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public URL getURL(String key)
/*     */     throws PropertyParseException
/*     */   {
/* 491 */     String value = this.props.getProperty(key);
/*     */     
/* 493 */     if (value == null) {
/* 494 */       throw new PropertyParseException("Missing property", key);
/*     */     }
/*     */     try {
/* 497 */       return new URL(value);
/*     */     }
/*     */     catch (MalformedURLException e)
/*     */     {
/* 501 */       throw new PropertyParseException("Invalid URL property: " + e.getMessage(), key, value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public URL getOptURL(String key, URL def)
/*     */     throws PropertyParseException
/*     */   {
/* 519 */     String value = this.props.getProperty(key);
/*     */     
/* 521 */     if ((value == null) || (value.trim().isEmpty())) {
/* 522 */       return def;
/*     */     }
/*     */     try {
/* 525 */       return new URL(value);
/*     */     }
/*     */     catch (MalformedURLException e)
/*     */     {
/* 529 */       throw new PropertyParseException("Invalid URL property: " + e.getMessage(), key, value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\cors-filter-1.7.0.wso2v1.jar!\com\thetransactioncompany\util\PropertyRetriever.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */