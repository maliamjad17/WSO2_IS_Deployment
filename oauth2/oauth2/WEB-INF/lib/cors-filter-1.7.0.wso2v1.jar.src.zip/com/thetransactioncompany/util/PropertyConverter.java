/*    */ package com.thetransactioncompany.util;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.Properties;
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyConverter
/*    */ {
/*    */   public static Properties getServletInitParameters(ServletConfig config)
/*    */   {
/* 35 */     Properties props = new Properties();
/*    */     
/* 37 */     Enumeration en = config.getInitParameterNames();
/*    */     
/* 39 */     while (en.hasMoreElements())
/*    */     {
/* 41 */       String key = (String)en.nextElement();
/* 42 */       String value = config.getInitParameter(key);
/*    */       
/* 44 */       props.setProperty(key, value);
/*    */     }
/*    */     
/* 47 */     return props;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Properties getServletCtxInitParameters(ServletContext ctx)
/*    */   {
/* 66 */     Properties props = new Properties();
/*    */     
/* 68 */     Enumeration en = ctx.getInitParameterNames();
/*    */     
/* 70 */     while (en.hasMoreElements())
/*    */     {
/* 72 */       String key = (String)en.nextElement();
/* 73 */       String value = ctx.getInitParameter(key);
/*    */       
/* 75 */       props.setProperty(key, value);
/*    */     }
/*    */     
/* 78 */     return props;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\cors-filter-1.7.0.wso2v1.jar!\com\thetransactioncompany\util\PropertyConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */