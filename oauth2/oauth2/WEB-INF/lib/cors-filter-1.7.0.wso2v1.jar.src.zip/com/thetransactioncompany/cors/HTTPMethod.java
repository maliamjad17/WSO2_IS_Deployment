package com.thetransactioncompany.cors;

public enum HTTPMethod
{
  GET,  POST,  HEAD,  PUT,  DELETE,  TRACE,  OPTIONS,  CONNECT,  PATCH;
  
  private HTTPMethod() {}
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\cors-filter-1.7.0.wso2v1.jar!\com\thetransactioncompany\cors\HTTPMethod.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */