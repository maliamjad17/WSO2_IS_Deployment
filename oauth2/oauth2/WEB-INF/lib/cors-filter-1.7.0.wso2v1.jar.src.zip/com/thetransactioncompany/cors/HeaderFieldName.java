/*     */ package com.thetransactioncompany.cors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HeaderFieldName
/*     */ {
/*     */   private final String name;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static String formatCanonical(String name)
/*     */   {
/*  41 */     String nameTrimmed = name.trim();
/*     */     
/*  43 */     if (nameTrimmed.isEmpty()) {
/*  44 */       throw new IllegalArgumentException("The header field name must not be an empty string");
/*     */     }
/*     */     
/*  47 */     if (!nameTrimmed.matches("^[a-zA-Z][\\w-]*$")) {
/*  48 */       throw new IllegalArgumentException("Invalid header field name syntax");
/*     */     }
/*     */     
/*  51 */     String[] tokens = nameTrimmed.toLowerCase().split("-");
/*     */     
/*  53 */     String out = "";
/*     */     
/*  55 */     for (int i = 0; i < tokens.length; i++)
/*     */     {
/*  57 */       char[] c = tokens[i].toCharArray();
/*     */       
/*     */ 
/*  60 */       c[0] = Character.toUpperCase(c[0]);
/*     */       
/*  62 */       if (i >= 1) {
/*  63 */         out = out + "-";
/*     */       }
/*  65 */       out = out + new String(c);
/*     */     }
/*     */     
/*  68 */     return out;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HeaderFieldName(String name)
/*     */   {
/*  83 */     this.name = formatCanonical(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  95 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 106 */     return this.name.hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/* 120 */     return ((object instanceof HeaderFieldName)) && (this.name.equals(object.toString()));
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\cors-filter-1.7.0.wso2v1.jar!\com\thetransactioncompany\cors\HeaderFieldName.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */