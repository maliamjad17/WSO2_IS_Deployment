/*     */ package com.thetransactioncompany.cors;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CORSRequestHandler
/*     */ {
/*     */   private final CORSConfiguration config;
/*     */   private final String supportedMethods;
/*     */   private final String supportedHeaders;
/*     */   private final String exposedHeaders;
/*     */   
/*     */   public CORSRequestHandler(CORSConfiguration config)
/*     */   {
/*  57 */     this.config = config;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  62 */     this.supportedMethods = serialize(config.supportedMethods, ", ");
/*     */     
/*     */ 
/*  65 */     if (!config.supportAnyHeader) {
/*  66 */       this.supportedHeaders = serialize(config.supportedHeaders, ", ");
/*     */     } else {
/*  68 */       this.supportedHeaders = null;
/*     */     }
/*     */     
/*  71 */     this.exposedHeaders = serialize(config.exposedHeaders, ", ");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String serialize(Set set, String sep)
/*     */   {
/*  86 */     Iterator it = set.iterator();
/*     */     
/*  88 */     String s = "";
/*     */     
/*  90 */     while (it.hasNext())
/*     */     {
/*  92 */       s = s + it.next().toString();
/*     */       
/*  94 */       if (it.hasNext()) {
/*  95 */         s = s + sep;
/*     */       }
/*     */     }
/*  98 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String[] parseMultipleHeaderValues(String headerValue)
/*     */   {
/* 114 */     if (headerValue == null) {
/* 115 */       return new String[0];
/*     */     }
/* 117 */     String trimmedHeaderValue = headerValue.trim();
/*     */     
/* 119 */     if (trimmedHeaderValue.isEmpty()) {
/* 120 */       return new String[0];
/*     */     }
/* 122 */     return trimmedHeaderValue.split("\\s*,\\s*|\\s+");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void tagRequest(HttpServletRequest request)
/*     */   {
/* 148 */     CORSRequestType type = CORSRequestType.detect(request);
/*     */     
/* 150 */     switch (type)
/*     */     {
/*     */     case ACTUAL: 
/* 153 */       request.setAttribute("cors.isCorsRequest", Boolean.valueOf(true));
/* 154 */       request.setAttribute("cors.origin", request.getHeader("Origin"));
/* 155 */       request.setAttribute("cors.requestType", "actual");
/* 156 */       break;
/*     */     
/*     */     case PREFLIGHT: 
/* 159 */       request.setAttribute("cors.isCorsRequest", Boolean.valueOf(true));
/* 160 */       request.setAttribute("cors.origin", request.getHeader("Origin"));
/* 161 */       request.setAttribute("cors.requestType", "preflight");
/* 162 */       request.setAttribute("cors.requestHeaders", request.getHeader("Access-Control-Request-Headers"));
/* 163 */       break;
/*     */     
/*     */     case OTHER: 
/* 166 */       request.setAttribute("cors.isCorsRequest", Boolean.valueOf(false));
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleActualRequest(HttpServletRequest request, HttpServletResponse response)
/*     */     throws InvalidCORSRequestException, CORSOriginDeniedException, UnsupportedHTTPMethodException
/*     */   {
/* 193 */     if (CORSRequestType.detect(request) != CORSRequestType.ACTUAL) {
/* 194 */       throw new InvalidCORSRequestException("Invalid simple/actual CORS request");
/*     */     }
/*     */     
/*     */ 
/* 198 */     Origin requestOrigin = new Origin(request.getHeader("Origin"));
/*     */     
/* 200 */     if (!this.config.isAllowedOrigin(requestOrigin)) {
/* 201 */       throw new CORSOriginDeniedException("CORS origin denied", requestOrigin);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 206 */     HTTPMethod method = null;
/*     */     try
/*     */     {
/* 209 */       method = HTTPMethod.valueOf(request.getMethod());
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 213 */       throw new UnsupportedHTTPMethodException("Unsupported HTTP method: " + request.getMethod());
/*     */     }
/*     */     
/* 216 */     if (!this.config.isSupportedMethod(method)) {
/* 217 */       throw new UnsupportedHTTPMethodException("Unsupported HTTP method", method);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 222 */     response.addHeader("Access-Control-Allow-Origin", requestOrigin.toString());
/*     */     
/* 224 */     if (this.config.supportsCredentials) {
/* 225 */       response.addHeader("Access-Control-Allow-Credentials", "true");
/*     */     }
/* 227 */     if (!this.exposedHeaders.isEmpty()) {
/* 228 */       response.addHeader("Access-Control-Expose-Headers", this.exposedHeaders);
/*     */     }
/*     */     
/*     */ 
/* 232 */     request.setAttribute("cors.origin", requestOrigin.toString());
/* 233 */     request.setAttribute("cors.requestType", "actual");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handlePreflightRequest(HttpServletRequest request, HttpServletResponse response)
/*     */     throws InvalidCORSRequestException, CORSOriginDeniedException, UnsupportedHTTPMethodException, UnsupportedHTTPHeaderException
/*     */   {
/* 262 */     if (CORSRequestType.detect(request) != CORSRequestType.PREFLIGHT) {
/* 263 */       throw new InvalidCORSRequestException("Invalid preflight CORS request");
/*     */     }
/*     */     
/* 266 */     Origin requestOrigin = new Origin(request.getHeader("Origin"));
/*     */     
/* 268 */     if (!this.config.isAllowedOrigin(requestOrigin)) {
/* 269 */       throw new CORSOriginDeniedException("CORS origin denied", requestOrigin);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 275 */     String requestMethodHeader = request.getHeader("Access-Control-Request-Method");
/*     */     
/* 277 */     if (requestMethodHeader == null) {
/* 278 */       throw new InvalidCORSRequestException("Invalid preflight CORS request: Missing Access-Control-Request-Method header");
/*     */     }
/* 280 */     HTTPMethod requestedMethod = null;
/*     */     try
/*     */     {
/* 283 */       requestedMethod = HTTPMethod.valueOf(requestMethodHeader.toUpperCase());
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 287 */       throw new UnsupportedHTTPMethodException("Unsupported HTTP method: " + requestMethodHeader);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 292 */     String rawRequestHeadersString = request.getHeader("Access-Control-Request-Headers");
/* 293 */     String[] requestHeaderValues = parseMultipleHeaderValues(rawRequestHeadersString);
/*     */     
/* 295 */     HeaderFieldName[] requestHeaders = new HeaderFieldName[requestHeaderValues.length];
/*     */     
/* 297 */     for (int i = 0; i < requestHeaders.length; i++) {
/*     */       try
/*     */       {
/* 300 */         requestHeaders[i] = new HeaderFieldName(requestHeaderValues[i]);
/*     */       }
/*     */       catch (IllegalArgumentException e)
/*     */       {
/* 304 */         throw new InvalidCORSRequestException("Invalid preflight CORS request: Bad request header value");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 310 */     if (!this.config.isSupportedMethod(requestedMethod)) {
/* 311 */       throw new UnsupportedHTTPMethodException("Unsupported HTTP method", requestedMethod);
/*     */     }
/*     */     
/*     */ 
/* 315 */     if (!this.config.supportAnyHeader)
/*     */     {
/* 317 */       for (int i = 0; i < requestHeaders.length; i++)
/*     */       {
/* 319 */         if (!this.config.supportedHeaders.contains(requestHeaders[i])) {
/* 320 */           throw new UnsupportedHTTPHeaderException("Unsupported HTTP request header", requestHeaders[i]);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 326 */     if (this.config.supportsCredentials) {
/* 327 */       response.addHeader("Access-Control-Allow-Origin", requestOrigin.toString());
/* 328 */       response.addHeader("Access-Control-Allow-Credentials", "true");
/*     */     }
/* 330 */     else if (this.config.allowAnyOrigin) {
/* 331 */       response.addHeader("Access-Control-Allow-Origin", "*");
/*     */     } else {
/* 333 */       response.addHeader("Access-Control-Allow-Origin", requestOrigin.toString());
/*     */     }
/*     */     
/* 336 */     if (this.config.maxAge > 0) {
/* 337 */       response.addHeader("Access-Control-Max-Age", Integer.toString(this.config.maxAge));
/*     */     }
/* 339 */     response.addHeader("Access-Control-Allow-Methods", this.supportedMethods);
/*     */     
/*     */ 
/* 342 */     if ((this.config.supportAnyHeader) && (rawRequestHeadersString != null))
/*     */     {
/*     */ 
/* 345 */       response.addHeader("Access-Control-Allow-Headers", rawRequestHeadersString);
/*     */     }
/* 347 */     else if (!this.supportedHeaders.isEmpty())
/*     */     {
/* 349 */       response.addHeader("Access-Control-Allow-Headers", this.supportedHeaders);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\cors-filter-1.7.0.wso2v1.jar!\com\thetransactioncompany\cors\CORSRequestHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */