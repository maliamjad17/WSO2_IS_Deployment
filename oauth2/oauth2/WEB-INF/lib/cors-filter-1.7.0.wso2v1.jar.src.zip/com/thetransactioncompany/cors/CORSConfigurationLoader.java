/*     */ package com.thetransactioncompany.cors;
/*     */ 
/*     */ import com.thetransactioncompany.cors.environment.Environment;
/*     */ import com.thetransactioncompany.cors.environment.SystemVariablesEnvironment;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.FilterConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CORSConfigurationLoader
/*     */ {
/*     */   public static final String CONFIG_FILE_PARAM_NAME = "cors.configurationFile";
/*     */   private final FilterConfig filterConfig;
/*     */   private Environment environment;
/*     */   
/*     */   private static Properties getFilterInitParameters(FilterConfig config)
/*     */   {
/*  54 */     Properties props = new Properties();
/*     */     
/*  56 */     Enumeration en = config.getInitParameterNames();
/*     */     
/*  58 */     while (en.hasMoreElements())
/*     */     {
/*  60 */       String key = (String)en.nextElement();
/*  61 */       String value = config.getInitParameter(key);
/*     */       
/*  63 */       props.setProperty(key, value);
/*     */     }
/*     */     
/*  66 */     return props;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CORSConfigurationLoader(FilterConfig filterConfig)
/*     */   {
/*  78 */     if (filterConfig == null) {
/*  79 */       throw new IllegalArgumentException("The servlet filter configuration must not be null");
/*     */     }
/*  81 */     this.filterConfig = filterConfig;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Properties loadPropertiesFromFile(String filename)
/*     */     throws IOException
/*     */   {
/*  98 */     InputStream is = null;
/*     */     try
/*     */     {
/* 101 */       is = getClass().getResourceAsStream("/" + filename);
/*     */       
/* 103 */       Properties props = new Properties();
/* 104 */       props.load(is);
/* 105 */       return props;
/*     */     }
/*     */     finally
/*     */     {
/*     */       try {
/* 110 */         if (is != null) {
/* 111 */           is.close();
/*     */         }
/*     */       }
/*     */       catch (IOException e) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Environment getEnvironment()
/*     */   {
/* 128 */     if (this.environment == null) {
/* 129 */       this.environment = new SystemVariablesEnvironment();
/*     */     }
/* 131 */     return this.environment;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnvironment(Environment env)
/*     */   {
/* 142 */     this.environment = env;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CORSConfiguration load()
/*     */     throws CORSConfigurationException
/*     */   {
/*     */     Properties props;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 183 */       String configFile = getEnvironment().getProperty("cors.configurationFile");
/*     */       
/* 185 */       if ((configFile == null) || (configFile.trim().isEmpty()))
/*     */       {
/*     */ 
/* 188 */         configFile = this.filterConfig.getInitParameter("cors.configurationFile");
/*     */       }
/*     */       
/*     */       Properties props;
/* 192 */       if (configFile != null)
/*     */       {
/* 194 */         props = loadPropertiesFromFile(configFile);
/*     */       }
/*     */       else
/*     */       {
/* 198 */         props = getFilterInitParameters(this.filterConfig);
/*     */       }
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 203 */       throw new CORSConfigurationException(e.getMessage(), e);
/*     */     }
/*     */     
/* 206 */     return new CORSConfiguration(props);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\cors-filter-1.7.0.wso2v1.jar!\com\thetransactioncompany\cors\CORSConfigurationLoader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */