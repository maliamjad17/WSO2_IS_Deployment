/*     */ package com.thetransactioncompany.cors;
/*     */ 
/*     */ import com.thetransactioncompany.util.PropertyParseException;
/*     */ import com.thetransactioncompany.util.PropertyRetriever;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CORSConfiguration
/*     */ {
/*     */   public final boolean allowGenericHttpRequests;
/*     */   public final boolean allowAnyOrigin;
/*     */   public final Set<ValidatedOrigin> allowedOrigins;
/*     */   public final boolean allowSubdomains;
/*     */   public final Set<HTTPMethod> supportedMethods;
/*     */   public final boolean supportAnyHeader;
/*     */   public final Set<HeaderFieldName> supportedHeaders;
/*     */   public final Set<HeaderFieldName> exposedHeaders;
/*     */   public final boolean supportsCredentials;
/*     */   public final int maxAge;
/*     */   
/*     */   public final boolean isAllowedOrigin(Origin origin)
/*     */   {
/*  85 */     if (this.allowAnyOrigin) {
/*  86 */       return true;
/*     */     }
/*  88 */     if (origin == null) {
/*  89 */       return false;
/*     */     }
/*  91 */     if (this.allowedOrigins.contains(origin)) {
/*  92 */       return true;
/*     */     }
/*  94 */     if (this.allowSubdomains) {
/*  95 */       return isAllowedSubdomainOrigin(origin);
/*     */     }
/*  97 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isAllowedSubdomainOrigin(Origin origin)
/*     */   {
/*     */     try
/*     */     {
/* 121 */       ValidatedOrigin validatedOrigin = origin.validate();
/*     */       
/* 123 */       scheme = validatedOrigin.getScheme();
/* 124 */       suffix = validatedOrigin.getSuffix();
/*     */       
/* 126 */       for (ValidatedOrigin allowedOrigin : this.allowedOrigins)
/*     */       {
/* 128 */         if ((suffix.endsWith("." + allowedOrigin.getSuffix())) && (scheme.equalsIgnoreCase(allowedOrigin.getScheme())))
/*     */         {
/*     */ 
/* 131 */           return true; }
/*     */       }
/*     */     } catch (OriginException e) {
/*     */       String scheme;
/*     */       String suffix;
/* 136 */       return false;
/*     */     }
/*     */     
/* 139 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isSupportedMethod(HTTPMethod method)
/*     */   {
/* 163 */     if (this.supportedMethods.contains(method)) {
/* 164 */       return true;
/*     */     }
/* 166 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isSupportedHeader(HeaderFieldName header)
/*     */   {
/* 199 */     if ((this.supportAnyHeader) || (this.supportedHeaders.contains(header))) {
/* 200 */       return true;
/*     */     }
/* 202 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static String[] parseWords(String s)
/*     */   {
/* 242 */     String s1 = s.trim();
/*     */     
/* 244 */     if (s1.isEmpty()) {
/* 245 */       return new String[0];
/*     */     }
/* 247 */     return s1.split("\\s*,\\s*|\\s+");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CORSConfiguration(Properties props)
/*     */     throws CORSConfigurationException
/*     */   {
/*     */     try
/*     */     {
/* 280 */       PropertyRetriever pr = new PropertyRetriever(props);
/*     */       
/*     */ 
/* 283 */       this.allowGenericHttpRequests = pr.getOptBoolean("cors.allowGenericHttpRequests", true);
/*     */       
/*     */ 
/* 286 */       String originSpec = pr.getOptString("cors.allowOrigin", "*").trim();
/*     */       
/* 288 */       this.allowedOrigins = new HashSet();
/*     */       
/* 290 */       if (originSpec.equals("*"))
/*     */       {
/* 292 */         this.allowAnyOrigin = true;
/*     */       }
/*     */       else
/*     */       {
/* 296 */         this.allowAnyOrigin = false;
/*     */         
/* 298 */         String[] urls = parseWords(originSpec);
/*     */         
/* 300 */         for (String url : urls) {
/*     */           try
/*     */           {
/* 303 */             this.allowedOrigins.add(new Origin(url).validate());
/*     */           }
/*     */           catch (OriginException e)
/*     */           {
/* 307 */             throw new PropertyParseException("Bad origin URL in property cors.allowOrigin: " + url);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 313 */       this.allowSubdomains = pr.getOptBoolean("cors.allowSubdomains", false);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 318 */       String methodSpec = pr.getOptString("cors.supportedMethods", "GET, POST, HEAD, OPTIONS").trim().toUpperCase();
/*     */       
/* 320 */       String[] methodNames = parseWords(methodSpec);
/*     */       
/* 322 */       this.supportedMethods = new HashSet();
/*     */       
/* 324 */       for (String methodName : methodNames) {
/*     */         try
/*     */         {
/* 327 */           this.supportedMethods.add(HTTPMethod.valueOf(methodName));
/*     */         }
/*     */         catch (IllegalArgumentException e) {
/* 330 */           throw new PropertyParseException("Bad HTTP method name in property cors.allowMethods: " + methodName);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */       String headerSpec;
/*     */       
/*     */ 
/*     */       try
/*     */       {
/* 340 */         headerSpec = pr.getString("cors.supportedHeaders");
/*     */       }
/*     */       catch (PropertyParseException e)
/*     */       {
/* 344 */         headerSpec = "*";
/*     */       }
/*     */       
/* 347 */       if (headerSpec.equals("*"))
/*     */       {
/* 349 */         this.supportAnyHeader = true;
/* 350 */         this.supportedHeaders = Collections.unmodifiableSet(new HashSet());
/*     */       }
/*     */       else
/*     */       {
/* 354 */         this.supportAnyHeader = false;
/*     */         
/* 356 */         String[] headers = parseWords(headerSpec);
/*     */         
/* 358 */         this.supportedHeaders = new HashSet();
/*     */         
/* 360 */         for (String header : headers) {
/*     */           try
/*     */           {
/* 363 */             this.supportedHeaders.add(new HeaderFieldName(header));
/*     */           }
/*     */           catch (IllegalArgumentException e)
/*     */           {
/* 367 */             throw new PropertyParseException("Bad header field name in property cors.supportedHeaders: " + header);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 374 */       this.exposedHeaders = new HashSet();
/*     */       
/* 376 */       for (String header : parseWords(pr.getOptString("cors.exposedHeaders", ""))) {
/*     */         try
/*     */         {
/* 379 */           this.exposedHeaders.add(new HeaderFieldName(header));
/*     */         }
/*     */         catch (IllegalArgumentException e) {
/* 382 */           throw new PropertyParseException("Bad header field name in property cors.exposedHeaders: " + header);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 388 */       this.supportsCredentials = pr.getOptBoolean("cors.supportsCredentials", true);
/*     */       
/*     */ 
/*     */ 
/* 392 */       this.maxAge = pr.getOptInt("cors.maxAge", -1);
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (PropertyParseException e)
/*     */     {
/*     */ 
/*     */ 
/* 401 */       throw new CORSConfigurationException(e.getMessage());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\cors-filter-1.7.0.wso2v1.jar!\com\thetransactioncompany\cors\CORSConfiguration.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */