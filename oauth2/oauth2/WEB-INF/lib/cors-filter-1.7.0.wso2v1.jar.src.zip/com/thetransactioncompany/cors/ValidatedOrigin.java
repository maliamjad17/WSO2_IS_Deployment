/*     */ package com.thetransactioncompany.cors;
/*     */ 
/*     */ import java.net.IDN;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidatedOrigin
/*     */   extends Origin
/*     */ {
/*     */   private String scheme;
/*     */   private String host;
/*  36 */   private int port = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ValidatedOrigin(String value)
/*     */     throws OriginException
/*     */   {
/*  51 */     super(value);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  56 */     URI uri = null;
/*     */     try
/*     */     {
/*  59 */       uri = new URI(value);
/*     */     }
/*     */     catch (URISyntaxException e)
/*     */     {
/*  63 */       throw new OriginException("Bad origin URI: " + e.getMessage());
/*     */     }
/*     */     
/*  66 */     this.scheme = uri.getScheme();
/*  67 */     this.host = uri.getHost();
/*  68 */     this.port = uri.getPort();
/*     */     
/*  70 */     if (this.scheme == null) {
/*  71 */       throw new OriginException("Bad origin URI: Missing scheme, such as http or https");
/*     */     }
/*     */     
/*  74 */     this.scheme = this.scheme.toLowerCase();
/*     */     
/*     */ 
/*  77 */     this.host = IDN.toASCII(this.host, 3);
/*     */     
/*     */ 
/*  80 */     this.host = this.host.toLowerCase();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getScheme()
/*     */   {
/*  91 */     return this.scheme;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHost()
/*     */   {
/* 102 */     return this.host;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 113 */     return this.port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSuffix()
/*     */   {
/* 132 */     String s = this.host;
/*     */     
/* 134 */     if (this.port != -1) {
/* 135 */       s = s + ":" + this.port;
/*     */     }
/* 137 */     return s;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\cors-filter-1.7.0.wso2v1.jar!\com\thetransactioncompany\cors\ValidatedOrigin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */