/*    */ package com.thetransactioncompany.cors.environment;
/*    */ 
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SystemVariablesEnvironment
/*    */   implements Environment
/*    */ {
/*    */   public String getProperty(String name)
/*    */   {
/* 18 */     return System.getProperty(name);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Properties getProperties()
/*    */   {
/* 25 */     return System.getProperties();
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\cors-filter-1.7.0.wso2v1.jar!\com\thetransactioncompany\cors\environment\SystemVariablesEnvironment.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */