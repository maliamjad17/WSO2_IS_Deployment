/*    */ package com.thetransactioncompany.cors;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CORSConfigurationException
/*    */   extends Exception
/*    */ {
/*    */   public CORSConfigurationException(String message)
/*    */   {
/* 21 */     super(message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CORSConfigurationException(String message, Throwable cause)
/*    */   {
/* 34 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\cors-filter-1.7.0.wso2v1.jar!\com\thetransactioncompany\cors\CORSConfigurationException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */