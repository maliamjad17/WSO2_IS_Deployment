/*    */ package com.thetransactioncompany.cors;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsupportedHTTPHeaderException
/*    */   extends CORSException
/*    */ {
/*    */   private final HeaderFieldName header;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public UnsupportedHTTPHeaderException(String message)
/*    */   {
/* 27 */     this(message, null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public UnsupportedHTTPHeaderException(String message, HeaderFieldName requestHeader)
/*    */   {
/* 41 */     super(message);
/*    */     
/* 43 */     this.header = requestHeader;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HeaderFieldName getRequestHeader()
/*    */   {
/* 54 */     return this.header;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\cors-filter-1.7.0.wso2v1.jar!\com\thetransactioncompany\cors\UnsupportedHTTPHeaderException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */