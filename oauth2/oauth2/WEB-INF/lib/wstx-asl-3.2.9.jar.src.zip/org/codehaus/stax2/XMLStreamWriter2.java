package org.codehaus.stax2;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import org.codehaus.stax2.validation.Validatable;

public abstract interface XMLStreamWriter2
  extends XMLStreamWriter, Validatable
{
  public abstract boolean isPropertySupported(String paramString);
  
  public abstract boolean setProperty(String paramString, Object paramObject);
  
  public abstract XMLStreamLocation2 getLocation();
  
  public abstract String getEncoding();
  
  public abstract void writeCData(char[] paramArrayOfChar, int paramInt1, int paramInt2)
    throws XMLStreamException;
  
  public abstract void writeDTD(String paramString1, String paramString2, String paramString3, String paramString4)
    throws XMLStreamException;
  
  public abstract void writeFullEndElement()
    throws XMLStreamException;
  
  public abstract void writeStartDocument(String paramString1, String paramString2, boolean paramBoolean)
    throws XMLStreamException;
  
  public abstract void writeRaw(String paramString)
    throws XMLStreamException;
  
  public abstract void writeRaw(String paramString, int paramInt1, int paramInt2)
    throws XMLStreamException;
  
  public abstract void writeRaw(char[] paramArrayOfChar, int paramInt1, int paramInt2)
    throws XMLStreamException;
  
  public abstract void copyEventFromReader(XMLStreamReader2 paramXMLStreamReader2, boolean paramBoolean)
    throws XMLStreamException;
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\XMLStreamWriter2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */