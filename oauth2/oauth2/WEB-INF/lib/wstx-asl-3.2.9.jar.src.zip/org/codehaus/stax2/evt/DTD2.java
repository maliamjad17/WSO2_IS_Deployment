package org.codehaus.stax2.evt;

import javax.xml.stream.events.DTD;

public abstract interface DTD2
  extends DTD
{
  public abstract String getRootName();
  
  public abstract String getSystemId();
  
  public abstract String getPublicId();
  
  public abstract String getInternalSubset();
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\evt\DTD2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */