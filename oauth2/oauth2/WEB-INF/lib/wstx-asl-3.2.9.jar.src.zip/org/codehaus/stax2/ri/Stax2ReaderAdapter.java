/*     */ package org.codehaus.stax2.ri;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.stream.util.StreamReaderDelegate;
/*     */ import org.codehaus.stax2.AttributeInfo;
/*     */ import org.codehaus.stax2.DTDInfo;
/*     */ import org.codehaus.stax2.LocationInfo;
/*     */ import org.codehaus.stax2.XMLStreamLocation2;
/*     */ import org.codehaus.stax2.XMLStreamReader2;
/*     */ import org.codehaus.stax2.validation.DTDValidationSchema;
/*     */ import org.codehaus.stax2.validation.ValidationProblemHandler;
/*     */ import org.codehaus.stax2.validation.XMLValidationSchema;
/*     */ import org.codehaus.stax2.validation.XMLValidator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Stax2ReaderAdapter
/*     */   extends StreamReaderDelegate
/*     */   implements XMLStreamReader2, AttributeInfo, DTDInfo, LocationInfo
/*     */ {
/*  41 */   protected int mDepth = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Stax2ReaderAdapter(XMLStreamReader sr)
/*     */   {
/*  51 */     super(sr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XMLStreamReader2 wrapIfNecessary(XMLStreamReader sr)
/*     */   {
/*  64 */     if ((sr instanceof XMLStreamReader2)) {
/*  65 */       return (XMLStreamReader2)sr;
/*     */     }
/*  67 */     return new Stax2ReaderAdapter(sr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int next()
/*     */     throws XMLStreamException
/*     */   {
/*  79 */     int type = super.next();
/*  80 */     if (type == 1) {
/*  81 */       this.mDepth += 1;
/*  82 */     } else if (type == 2) {
/*  83 */       this.mDepth -= 1;
/*     */     }
/*  85 */     return type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getFeature(String name)
/*     */   {
/*  99 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFeature(String name, Object value) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPropertySupported(String name)
/*     */   {
/* 114 */     return false;
/*     */   }
/*     */   
/*     */   public boolean setProperty(String name, Object value)
/*     */   {
/* 119 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public void skipElement()
/*     */     throws XMLStreamException
/*     */   {
/* 126 */     if (getEventType() != 1) {
/* 127 */       throwNotStartElem();
/*     */     }
/* 129 */     int nesting = 1;
/*     */     for (;;)
/*     */     {
/* 132 */       int type = next();
/* 133 */       if (type == 1) {
/* 134 */         nesting++;
/* 135 */       } else if (type == 2) {
/* 136 */         nesting--; if (nesting == 0) {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public AttributeInfo getAttributeInfo()
/*     */     throws XMLStreamException
/*     */   {
/* 147 */     if (getEventType() != 1) {
/* 148 */       throwNotStartElem();
/*     */     }
/* 150 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */   public DTDInfo getDTDInfo()
/*     */     throws XMLStreamException
/*     */   {
/* 157 */     if (getEventType() != 11) {
/* 158 */       return null;
/*     */     }
/* 160 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final LocationInfo getLocationInfo()
/*     */   {
/* 169 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getText(Writer w, boolean preserveContents)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 177 */     char[] cbuf = getTextCharacters();
/* 178 */     int start = getTextStart();
/* 179 */     int len = getTextLength();
/*     */     
/* 181 */     if (len > 0) {
/* 182 */       w.write(cbuf, start, len);
/*     */     }
/* 184 */     return len;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDepth()
/*     */   {
/* 198 */     if (getEventType() == 2) {
/* 199 */       return this.mDepth + 1;
/*     */     }
/* 201 */     return this.mDepth;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEmptyElement()
/*     */     throws XMLStreamException
/*     */   {
/* 210 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NamespaceContext getNonTransientNamespaceContext()
/*     */   {
/* 219 */     return null;
/*     */   }
/*     */   
/*     */   public String getPrefixedName()
/*     */   {
/* 224 */     switch (getEventType())
/*     */     {
/*     */     case 1: 
/*     */     case 2: 
/* 228 */       String prefix = getPrefix();
/* 229 */       String ln = getLocalName();
/*     */       
/* 231 */       if ((prefix == null) || (prefix.length() == 0)) {
/* 232 */         return ln;
/*     */       }
/* 234 */       StringBuffer sb = new StringBuffer(ln.length() + 1 + prefix.length());
/* 235 */       sb.append(prefix);
/* 236 */       sb.append(':');
/* 237 */       sb.append(ln);
/* 238 */       return sb.toString();
/*     */     
/*     */     case 9: 
/* 241 */       return getLocalName();
/*     */     case 3: 
/* 243 */       return getPITarget();
/*     */     case 11: 
/* 245 */       return getDTDRootName();
/*     */     }
/*     */     
/* 248 */     throw new IllegalStateException("Current state not START_ELEMENT, END_ELEMENT, ENTITY_REFERENCE, PROCESSING_INSTRUCTION or DTD");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void closeCompletely()
/*     */     throws XMLStreamException
/*     */   {
/* 256 */     close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int findAttributeIndex(String nsURI, String localName)
/*     */   {
/* 270 */     if ("".equals(nsURI)) {
/* 271 */       nsURI = null;
/*     */     }
/* 273 */     int i = 0; for (int len = getAttributeCount(); i < len; i++) {
/* 274 */       if (getAttributeLocalName(i).equals(localName)) {
/* 275 */         String otherUri = getAttributeNamespace(i);
/* 276 */         if (nsURI == null) {
/* 277 */           if ((otherUri == null) || (otherUri.length() == 0)) {
/* 278 */             return i;
/*     */           }
/*     */         }
/* 281 */         else if (nsURI.equals(otherUri)) {
/* 282 */           return i;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 287 */     return -1;
/*     */   }
/*     */   
/*     */   public int getIdAttributeIndex()
/*     */   {
/* 292 */     int i = 0; for (int len = getAttributeCount(); i < len; i++) {
/* 293 */       if ("ID".equals(getAttributeType(i))) {
/* 294 */         return i;
/*     */       }
/*     */     }
/* 297 */     return -1;
/*     */   }
/*     */   
/*     */   public int getNotationAttributeIndex()
/*     */   {
/* 302 */     int i = 0; for (int len = getAttributeCount(); i < len; i++) {
/* 303 */       if ("NOTATION".equals(getAttributeType(i))) {
/* 304 */         return i;
/*     */       }
/*     */     }
/* 307 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getProcessedDTD()
/*     */   {
/* 317 */     return null;
/*     */   }
/*     */   
/*     */   public String getDTDRootName() {
/* 321 */     return null;
/*     */   }
/*     */   
/*     */   public String getDTDPublicId() {
/* 325 */     return null;
/*     */   }
/*     */   
/*     */   public String getDTDSystemId() {
/* 329 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDTDInternalSubset()
/*     */   {
/* 342 */     if (getEventType() == 11) {
/* 343 */       return getText();
/*     */     }
/* 345 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public DTDValidationSchema getProcessedDTDSchema()
/*     */   {
/* 351 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getStartingByteOffset()
/*     */   {
/* 363 */     return -1L;
/*     */   }
/*     */   
/*     */   public long getStartingCharOffset() {
/* 367 */     return 0L;
/*     */   }
/*     */   
/*     */   public long getEndingByteOffset() throws XMLStreamException
/*     */   {
/* 372 */     return -1L;
/*     */   }
/*     */   
/*     */   public long getEndingCharOffset() throws XMLStreamException
/*     */   {
/* 377 */     return -1L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLStreamLocation2 getStartLocation()
/*     */   {
/* 388 */     return getCurrentLocation();
/*     */   }
/*     */   
/*     */ 
/*     */   public XMLStreamLocation2 getCurrentLocation()
/*     */   {
/* 394 */     return new Stax2LocationAdapter(getLocation());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final XMLStreamLocation2 getEndLocation()
/*     */     throws XMLStreamException
/*     */   {
/* 404 */     return getCurrentLocation();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLValidator validateAgainst(XMLValidationSchema schema)
/*     */     throws XMLStreamException
/*     */   {
/* 416 */     throwUnsupported();
/* 417 */     return null;
/*     */   }
/*     */   
/*     */   public XMLValidator stopValidatingAgainst(XMLValidationSchema schema)
/*     */     throws XMLStreamException
/*     */   {
/* 423 */     throwUnsupported();
/* 424 */     return null;
/*     */   }
/*     */   
/*     */   public XMLValidator stopValidatingAgainst(XMLValidator validator)
/*     */     throws XMLStreamException
/*     */   {
/* 430 */     throwUnsupported();
/* 431 */     return null;
/*     */   }
/*     */   
/*     */   public ValidationProblemHandler setValidationProblemHandler(ValidationProblemHandler h)
/*     */   {
/* 436 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void throwUnsupported()
/*     */     throws XMLStreamException
/*     */   {
/* 448 */     throw new XMLStreamException("Unsupported method");
/*     */   }
/*     */   
/*     */   protected void throwNotStartElem()
/*     */   {
/* 453 */     throw new IllegalStateException("Current state not START_ELEMENT");
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\ri\Stax2ReaderAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */