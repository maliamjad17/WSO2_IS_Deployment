package org.codehaus.stax2.evt;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.stream.events.XMLEvent;

public abstract interface XMLEvent2
  extends XMLEvent
{
  public abstract void writeUsing(XMLStreamWriter paramXMLStreamWriter)
    throws XMLStreamException;
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\evt\XMLEvent2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */