package org.codehaus.stax2;

import java.io.IOException;
import java.io.Writer;
import javax.xml.namespace.NamespaceContext;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import org.codehaus.stax2.validation.Validatable;

public abstract interface XMLStreamReader2
  extends XMLStreamReader, Validatable
{
  public static final String FEATURE_DTD_OVERRIDE = "org.codehaus.stax2.propDtdOverride";
  
  /**
   * @deprecated
   */
  public abstract Object getFeature(String paramString);
  
  /**
   * @deprecated
   */
  public abstract void setFeature(String paramString, Object paramObject);
  
  public abstract boolean isPropertySupported(String paramString);
  
  public abstract boolean setProperty(String paramString, Object paramObject);
  
  public abstract void skipElement()
    throws XMLStreamException;
  
  public abstract DTDInfo getDTDInfo()
    throws XMLStreamException;
  
  public abstract AttributeInfo getAttributeInfo()
    throws XMLStreamException;
  
  public abstract LocationInfo getLocationInfo();
  
  public abstract int getText(Writer paramWriter, boolean paramBoolean)
    throws IOException, XMLStreamException;
  
  public abstract boolean isEmptyElement()
    throws XMLStreamException;
  
  public abstract int getDepth();
  
  public abstract NamespaceContext getNonTransientNamespaceContext();
  
  public abstract String getPrefixedName();
  
  public abstract void closeCompletely()
    throws XMLStreamException;
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\XMLStreamReader2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */