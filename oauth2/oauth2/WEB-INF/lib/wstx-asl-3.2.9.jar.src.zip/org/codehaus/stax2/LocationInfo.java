package org.codehaus.stax2;

import javax.xml.stream.Location;
import javax.xml.stream.XMLStreamException;

public abstract interface LocationInfo
{
  public abstract long getStartingByteOffset();
  
  public abstract long getStartingCharOffset();
  
  public abstract long getEndingByteOffset()
    throws XMLStreamException;
  
  public abstract long getEndingCharOffset()
    throws XMLStreamException;
  
  public abstract Location getLocation();
  
  public abstract XMLStreamLocation2 getStartLocation();
  
  public abstract XMLStreamLocation2 getCurrentLocation();
  
  public abstract XMLStreamLocation2 getEndLocation()
    throws XMLStreamException;
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\LocationInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */