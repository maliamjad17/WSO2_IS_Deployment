/*    */ package org.codehaus.stax2.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.Reader;
/*    */ import java.net.URL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Stax2BlockSource
/*    */   extends Stax2Source
/*    */ {
/*    */   public URL getReference()
/*    */   {
/* 33 */     return null;
/*    */   }
/*    */   
/*    */   public abstract Reader constructReader()
/*    */     throws IOException;
/*    */   
/*    */   public abstract InputStream constructInputStream()
/*    */     throws IOException;
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\io\Stax2BlockSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */