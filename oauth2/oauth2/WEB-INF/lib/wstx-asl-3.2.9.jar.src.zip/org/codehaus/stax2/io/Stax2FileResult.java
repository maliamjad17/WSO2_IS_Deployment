/*    */ package org.codehaus.stax2.io;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.FileWriter;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.io.Writer;
/*    */ 
/*    */ public class Stax2FileResult extends Stax2ReferentialResult
/*    */ {
/*    */   final File mFile;
/*    */   
/*    */   public Stax2FileResult(File f)
/*    */   {
/* 16 */     this.mFile = f;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Writer constructWriter()
/*    */     throws IOException
/*    */   {
/* 28 */     String enc = getEncoding();
/* 29 */     if ((enc != null) && (enc.length() > 0)) {
/* 30 */       return new OutputStreamWriter(constructOutputStream(), enc);
/*    */     }
/*    */     
/* 33 */     return new FileWriter(this.mFile);
/*    */   }
/*    */   
/*    */   public java.io.OutputStream constructOutputStream()
/*    */     throws IOException
/*    */   {
/* 39 */     return new FileOutputStream(this.mFile);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public File getFile()
/*    */   {
/* 49 */     return this.mFile;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\io\Stax2FileResult.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */