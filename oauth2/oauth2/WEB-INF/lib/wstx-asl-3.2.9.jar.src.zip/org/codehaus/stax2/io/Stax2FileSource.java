/*    */ package org.codehaus.stax2.io;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.MalformedURLException;
/*    */ 
/*    */ public class Stax2FileSource extends Stax2ReferentialSource
/*    */ {
/*    */   final File mFile;
/*    */   
/*    */   public Stax2FileSource(File f)
/*    */   {
/* 16 */     this.mFile = f;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public java.net.URL getReference()
/*    */   {
/*    */     try
/*    */     {
/* 37 */       return this.mFile.toURL();
/*    */ 
/*    */     }
/*    */     catch (MalformedURLException e)
/*    */     {
/*    */ 
/* 43 */       throw new IllegalArgumentException("(was " + e.getClass() + ") Could not convert File '" + this.mFile.getPath() + "' to URL: " + e);
/*    */     }
/*    */   }
/*    */   
/*    */   public java.io.Reader constructReader()
/*    */     throws IOException
/*    */   {
/* 50 */     String enc = getEncoding();
/* 51 */     if ((enc != null) && (enc.length() > 0)) {
/* 52 */       return new java.io.InputStreamReader(constructInputStream(), enc);
/*    */     }
/*    */     
/* 55 */     return new FileReader(this.mFile);
/*    */   }
/*    */   
/*    */   public InputStream constructInputStream()
/*    */     throws IOException
/*    */   {
/* 61 */     return new FileInputStream(this.mFile);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public File getFile()
/*    */   {
/* 71 */     return this.mFile;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\io\Stax2FileSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */