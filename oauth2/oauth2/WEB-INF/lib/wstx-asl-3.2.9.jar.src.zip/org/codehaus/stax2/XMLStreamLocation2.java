package org.codehaus.stax2;

import javax.xml.stream.Location;

public abstract interface XMLStreamLocation2
  extends Location
{
  public abstract XMLStreamLocation2 getContext();
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\XMLStreamLocation2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */