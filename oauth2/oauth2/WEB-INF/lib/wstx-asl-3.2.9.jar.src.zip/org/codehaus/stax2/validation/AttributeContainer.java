package org.codehaus.stax2.validation;

public abstract interface AttributeContainer
{
  public abstract int getAttributeCount();
  
  public abstract int addDefaultAttribute(String paramString1, String paramString2, String paramString3, String paramString4);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\validation\AttributeContainer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */