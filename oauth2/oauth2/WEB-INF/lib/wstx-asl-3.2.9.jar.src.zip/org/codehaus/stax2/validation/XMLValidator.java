/*    */ package org.codehaus.stax2.validation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class XMLValidator
/*    */ {
/*    */   public static final int CONTENT_ALLOW_NONE = 0;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final int CONTENT_ALLOW_WS = 1;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final int CONTENT_ALLOW_VALIDATABLE_TEXT = 2;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final int CONTENT_ALLOW_ANY_TEXT = 3;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final int CONTENT_ALLOW_UNDEFINED = 4;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getSchemaType()
/*    */   {
/* 89 */     XMLValidationSchema sch = getSchema();
/* 90 */     return sch == null ? null : sch.getSchemaType();
/*    */   }
/*    */   
/*    */   public abstract XMLValidationSchema getSchema();
/*    */   
/*    */   public abstract void validateElementStart(String paramString1, String paramString2, String paramString3)
/*    */     throws XMLValidationException;
/*    */   
/*    */   public abstract String validateAttribute(String paramString1, String paramString2, String paramString3, String paramString4)
/*    */     throws XMLValidationException;
/*    */   
/*    */   public abstract String validateAttribute(String paramString1, String paramString2, String paramString3, char[] paramArrayOfChar, int paramInt1, int paramInt2)
/*    */     throws XMLValidationException;
/*    */   
/*    */   public abstract int validateElementAndAttributes()
/*    */     throws XMLValidationException;
/*    */   
/*    */   public abstract int validateElementEnd(String paramString1, String paramString2, String paramString3)
/*    */     throws XMLValidationException;
/*    */   
/*    */   public abstract void validateText(String paramString, boolean paramBoolean)
/*    */     throws XMLValidationException;
/*    */   
/*    */   public abstract void validateText(char[] paramArrayOfChar, int paramInt1, int paramInt2, boolean paramBoolean)
/*    */     throws XMLValidationException;
/*    */   
/*    */   public abstract void validationCompleted(boolean paramBoolean)
/*    */     throws XMLValidationException;
/*    */   
/*    */   public abstract String getAttributeType(int paramInt);
/*    */   
/*    */   public abstract int getIdAttrIndex();
/*    */   
/*    */   public abstract int getNotationAttrIndex();
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\validation\XMLValidator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */