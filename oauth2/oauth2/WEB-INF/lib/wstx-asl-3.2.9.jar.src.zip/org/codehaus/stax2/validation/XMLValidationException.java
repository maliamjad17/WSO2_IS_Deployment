/*    */ package org.codehaus.stax2.validation;
/*    */ 
/*    */ import javax.xml.stream.Location;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLValidationException
/*    */   extends XMLStreamException
/*    */ {
/*    */   protected XMLValidationProblem mCause;
/*    */   
/*    */   protected XMLValidationException(XMLValidationProblem cause)
/*    */   {
/* 29 */     if (cause == null) {
/* 30 */       throwMissing();
/*    */     }
/* 32 */     this.mCause = cause;
/*    */   }
/*    */   
/*    */   protected XMLValidationException(XMLValidationProblem cause, String msg)
/*    */   {
/* 37 */     super(msg);
/* 38 */     if (cause == null) {
/* 39 */       throwMissing();
/*    */     }
/* 41 */     this.mCause = cause;
/*    */   }
/*    */   
/*    */ 
/*    */   protected XMLValidationException(XMLValidationProblem cause, String msg, Location loc)
/*    */   {
/* 47 */     super(msg, loc);
/* 48 */     if (cause == null) {
/* 49 */       throwMissing();
/*    */     }
/* 51 */     this.mCause = cause;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static XMLValidationException createException(XMLValidationProblem cause)
/*    */   {
/* 58 */     String msg = cause.getMessage();
/* 59 */     if (msg == null) {
/* 60 */       return new XMLValidationException(cause);
/*    */     }
/* 62 */     Location loc = cause.getLocation();
/* 63 */     if (loc == null) {
/* 64 */       return new XMLValidationException(cause, msg);
/*    */     }
/* 66 */     return new XMLValidationException(cause, msg, loc);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public XMLValidationProblem getValidationProblem()
/*    */   {
/* 76 */     return this.mCause;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected static void throwMissing()
/*    */     throws RuntimeException
/*    */   {
/* 84 */     throw new IllegalArgumentException("Validation problem argument can not be null");
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\validation\XMLValidationException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */