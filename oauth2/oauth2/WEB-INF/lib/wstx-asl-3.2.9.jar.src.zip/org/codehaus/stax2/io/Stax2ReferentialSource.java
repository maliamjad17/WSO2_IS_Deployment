/*    */ package org.codehaus.stax2.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.Reader;
/*    */ import java.net.URL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Stax2ReferentialSource
/*    */   extends Stax2Source
/*    */ {
/*    */   public abstract URL getReference();
/*    */   
/*    */   public abstract Reader constructReader()
/*    */     throws IOException;
/*    */   
/*    */   public abstract InputStream constructInputStream()
/*    */     throws IOException;
/*    */   
/*    */   public String getSystemId()
/*    */   {
/* 47 */     String sysId = super.getSystemId();
/* 48 */     if (sysId == null) {
/* 49 */       sysId = getReference().toExternalForm();
/*    */     }
/* 51 */     return sysId;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\io\Stax2ReferentialSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */