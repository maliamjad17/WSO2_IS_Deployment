/*     */ package org.codehaus.stax2.validation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidatorPair
/*     */   extends XMLValidator
/*     */ {
/*     */   public static final String ATTR_TYPE_DEFAULT = "CDATA";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XMLValidator mFirst;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XMLValidator mSecond;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ValidatorPair(XMLValidator first, XMLValidator second)
/*     */   {
/*  31 */     this.mFirst = first;
/*  32 */     this.mSecond = second;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLValidationSchema getSchema()
/*     */   {
/*  47 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void validateElementStart(String localName, String uri, String prefix)
/*     */     throws XMLValidationException
/*     */   {
/*  54 */     this.mFirst.validateElementStart(localName, uri, prefix);
/*  55 */     this.mSecond.validateElementStart(localName, uri, prefix);
/*     */   }
/*     */   
/*     */ 
/*     */   public String validateAttribute(String localName, String uri, String prefix, String value)
/*     */     throws XMLValidationException
/*     */   {
/*  62 */     String retVal = this.mFirst.validateAttribute(localName, uri, prefix, value);
/*     */     
/*  64 */     if (retVal != null) {
/*  65 */       value = retVal;
/*     */     }
/*  67 */     return this.mSecond.validateAttribute(localName, uri, prefix, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validateAttribute(String localName, String uri, String prefix, char[] valueChars, int valueStart, int valueEnd)
/*     */     throws XMLValidationException
/*     */   {
/*  76 */     String retVal = this.mFirst.validateAttribute(localName, uri, prefix, valueChars, valueStart, valueEnd);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  81 */     if (retVal != null) {
/*  82 */       return this.mSecond.validateAttribute(localName, uri, prefix, retVal);
/*     */     }
/*     */     
/*  85 */     return this.mSecond.validateAttribute(localName, uri, prefix, valueChars, valueStart, valueEnd);
/*     */   }
/*     */   
/*     */ 
/*     */   public int validateElementAndAttributes()
/*     */     throws XMLValidationException
/*     */   {
/*  92 */     int textType1 = this.mFirst.validateElementAndAttributes();
/*  93 */     int textType2 = this.mSecond.validateElementAndAttributes();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */     return textType1 < textType2 ? textType1 : textType2;
/*     */   }
/*     */   
/*     */   public int validateElementEnd(String localName, String uri, String prefix)
/*     */     throws XMLValidationException
/*     */   {
/* 105 */     int textType1 = this.mFirst.validateElementEnd(localName, uri, prefix);
/* 106 */     int textType2 = this.mSecond.validateElementEnd(localName, uri, prefix);
/*     */     
/*     */ 
/* 109 */     return textType1 < textType2 ? textType1 : textType2;
/*     */   }
/*     */   
/*     */   public void validateText(String text, boolean lastTextSegment)
/*     */     throws XMLValidationException
/*     */   {
/* 115 */     this.mFirst.validateText(text, lastTextSegment);
/* 116 */     this.mSecond.validateText(text, lastTextSegment);
/*     */   }
/*     */   
/*     */ 
/*     */   public void validateText(char[] cbuf, int textStart, int textEnd, boolean lastTextSegment)
/*     */     throws XMLValidationException
/*     */   {
/* 123 */     this.mFirst.validateText(cbuf, textStart, textEnd, lastTextSegment);
/* 124 */     this.mSecond.validateText(cbuf, textStart, textEnd, lastTextSegment);
/*     */   }
/*     */   
/*     */   public void validationCompleted(boolean eod)
/*     */     throws XMLValidationException
/*     */   {
/* 130 */     this.mFirst.validationCompleted(eod);
/* 131 */     this.mSecond.validationCompleted(eod);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAttributeType(int index)
/*     */   {
/* 142 */     String type = this.mFirst.getAttributeType(index);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 147 */     if ((type == null) || (type.length() == 0) || (type.equals("CDATA"))) {
/* 148 */       String type2 = this.mSecond.getAttributeType(index);
/* 149 */       if ((type2 != null) && (type2.length() > 0)) {
/* 150 */         return type2;
/*     */       }
/*     */     }
/*     */     
/* 154 */     return type;
/*     */   }
/*     */   
/*     */   public int getIdAttrIndex()
/*     */   {
/* 159 */     int index = this.mFirst.getIdAttrIndex();
/* 160 */     if (index < 0) {
/* 161 */       return this.mSecond.getIdAttrIndex();
/*     */     }
/* 163 */     return index;
/*     */   }
/*     */   
/*     */   public int getNotationAttrIndex()
/*     */   {
/* 168 */     int index = this.mFirst.getNotationAttrIndex();
/* 169 */     if (index < 0) {
/* 170 */       return this.mSecond.getNotationAttrIndex();
/*     */     }
/* 172 */     return index;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean removeValidator(XMLValidator root, XMLValidationSchema schema, XMLValidator[] results)
/*     */   {
/* 183 */     if ((root instanceof ValidatorPair)) {
/* 184 */       return ((ValidatorPair)root).doRemoveValidator(schema, results);
/*     */     }
/* 186 */     if (root.getSchema() == schema) {
/* 187 */       results[0] = root;
/* 188 */       results[1] = null;
/* 189 */       return true;
/*     */     }
/*     */     
/* 192 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean removeValidator(XMLValidator root, XMLValidator vld, XMLValidator[] results)
/*     */   {
/* 197 */     if (root == vld) {
/* 198 */       results[0] = root;
/* 199 */       results[1] = null;
/* 200 */       return true; }
/* 201 */     if ((root instanceof ValidatorPair)) {
/* 202 */       return ((ValidatorPair)root).doRemoveValidator(vld, results);
/*     */     }
/* 204 */     return false;
/*     */   }
/*     */   
/*     */   private boolean doRemoveValidator(XMLValidationSchema schema, XMLValidator[] results)
/*     */   {
/* 209 */     if (removeValidator(this.mFirst, schema, results)) {
/* 210 */       XMLValidator newFirst = results[1];
/* 211 */       if (newFirst == null) {
/* 212 */         results[1] = this.mSecond;
/*     */       } else {
/* 214 */         this.mFirst = newFirst;
/* 215 */         results[1] = this;
/*     */       }
/* 217 */       return true;
/*     */     }
/* 219 */     if (removeValidator(this.mSecond, schema, results)) {
/* 220 */       XMLValidator newSecond = results[1];
/* 221 */       if (newSecond == null) {
/* 222 */         results[1] = this.mFirst;
/*     */       } else {
/* 224 */         this.mSecond = newSecond;
/* 225 */         results[1] = this;
/*     */       }
/* 227 */       return true;
/*     */     }
/* 229 */     return false;
/*     */   }
/*     */   
/*     */   private boolean doRemoveValidator(XMLValidator vld, XMLValidator[] results)
/*     */   {
/* 234 */     if (removeValidator(this.mFirst, vld, results)) {
/* 235 */       XMLValidator newFirst = results[1];
/* 236 */       if (newFirst == null) {
/* 237 */         results[1] = this.mSecond;
/*     */       } else {
/* 239 */         this.mFirst = newFirst;
/* 240 */         results[1] = this;
/*     */       }
/* 242 */       return true;
/*     */     }
/* 244 */     if (removeValidator(this.mSecond, vld, results)) {
/* 245 */       XMLValidator newSecond = results[1];
/* 246 */       if (newSecond == null) {
/* 247 */         results[1] = this.mFirst;
/*     */       } else {
/* 249 */         this.mSecond = newSecond;
/* 250 */         results[1] = this;
/*     */       }
/* 252 */       return true;
/*     */     }
/* 254 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\validation\ValidatorPair.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */