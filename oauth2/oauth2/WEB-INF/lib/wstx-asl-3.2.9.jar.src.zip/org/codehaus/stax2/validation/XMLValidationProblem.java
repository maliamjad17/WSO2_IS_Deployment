/*    */ package org.codehaus.stax2.validation;
/*    */ 
/*    */ import javax.xml.stream.Location;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLValidationProblem
/*    */ {
/*    */   public static final int SEVERITY_WARNING = 1;
/*    */   public static final int SEVERITY_ERROR = 2;
/*    */   public static final int SEVERITY_FATAL = 3;
/*    */   protected final Location mLocation;
/*    */   protected final String mMessage;
/*    */   protected final int mSeverity;
/*    */   
/*    */   public XMLValidationProblem(Location loc, String msg)
/*    */   {
/* 23 */     this(loc, msg, 2);
/*    */   }
/*    */   
/*    */   public XMLValidationProblem(Location loc, String msg, int severity)
/*    */   {
/* 28 */     this.mLocation = loc;
/* 29 */     this.mMessage = msg;
/* 30 */     this.mSeverity = severity;
/*    */   }
/*    */   
/* 33 */   public Location getLocation() { return this.mLocation; }
/* 34 */   public String getMessage() { return this.mMessage; }
/* 35 */   public int getSeverity() { return this.mSeverity; }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\validation\XMLValidationProblem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */