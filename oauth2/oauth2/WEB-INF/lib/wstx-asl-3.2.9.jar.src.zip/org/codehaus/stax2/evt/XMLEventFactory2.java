package org.codehaus.stax2.evt;

import javax.xml.stream.XMLEventFactory;

public abstract class XMLEventFactory2
  extends XMLEventFactory
{
  public abstract DTD2 createDTD(String paramString1, String paramString2, String paramString3, String paramString4);
  
  public abstract DTD2 createDTD(String paramString1, String paramString2, String paramString3, String paramString4, Object paramObject);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\org\codehaus\stax2\evt\XMLEventFactory2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */