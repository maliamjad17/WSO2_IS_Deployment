/*     */ package com.ctc.wstx.stax;
/*     */ 
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.StreamFilter;
/*     */ import javax.xml.stream.XMLStreamConstants;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilteredStreamReader
/*     */   implements XMLStreamReader, XMLStreamConstants
/*     */ {
/*     */   final XMLStreamReader mReader;
/*     */   final StreamFilter mFilter;
/*     */   
/*     */   public FilteredStreamReader(XMLStreamReader r, StreamFilter f)
/*     */   {
/*  23 */     this.mReader = r;
/*  24 */     this.mFilter = f;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int next()
/*     */     throws XMLStreamException
/*     */   {
/*     */     int type;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     do
/*     */     {
/*  44 */       type = this.mReader.next();
/*  45 */     } while ((!this.mFilter.accept(this)) && 
/*     */     
/*     */ 
/*  48 */       (type != 8));
/*     */     
/*  50 */     return type;
/*     */   }
/*     */   
/*     */ 
/*     */   public int nextTag()
/*     */     throws XMLStreamException
/*     */   {
/*     */     for (;;)
/*     */     {
/*  59 */       int type = this.mReader.nextTag();
/*  60 */       if (this.mFilter.accept(this)) {
/*  61 */         return type;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCharacterEncodingScheme()
/*     */   {
/*  76 */     return this.mReader.getCharacterEncodingScheme();
/*     */   }
/*     */   
/*     */   public String getEncoding() {
/*  80 */     return this.mReader.getEncoding();
/*     */   }
/*     */   
/*     */   public String getVersion() {
/*  84 */     return this.mReader.getVersion();
/*     */   }
/*     */   
/*     */   public boolean isStandalone() {
/*  88 */     return this.mReader.isStandalone();
/*     */   }
/*     */   
/*     */   public boolean standaloneSet() {
/*  92 */     return this.mReader.standaloneSet();
/*     */   }
/*     */   
/*     */   public Object getProperty(String name) {
/*  96 */     return this.mReader.getProperty(name);
/*     */   }
/*     */   
/*     */   public int getAttributeCount() {
/* 100 */     return this.mReader.getAttributeCount();
/*     */   }
/*     */   
/*     */   public String getAttributeLocalName(int index) {
/* 104 */     return this.mReader.getAttributeLocalName(index);
/*     */   }
/*     */   
/*     */   public QName getAttributeName(int index) {
/* 108 */     return this.mReader.getAttributeName(index);
/*     */   }
/*     */   
/*     */   public String getAttributeNamespace(int index) {
/* 112 */     return this.mReader.getAttributeNamespace(index);
/*     */   }
/*     */   
/*     */   public String getAttributePrefix(int index) {
/* 116 */     return this.mReader.getAttributePrefix(index);
/*     */   }
/*     */   
/*     */   public String getAttributeType(int index) {
/* 120 */     return this.mReader.getAttributeType(index);
/*     */   }
/*     */   
/*     */   public String getAttributeValue(int index) {
/* 124 */     return this.mReader.getAttributeValue(index);
/*     */   }
/*     */   
/*     */   public String getAttributeValue(String nsURI, String localName) {
/* 128 */     return this.mReader.getAttributeValue(nsURI, localName);
/*     */   }
/*     */   
/*     */   public String getElementText()
/*     */     throws XMLStreamException
/*     */   {
/* 134 */     return this.mReader.getElementText();
/*     */   }
/*     */   
/*     */   public int getEventType() {
/* 138 */     return this.mReader.getEventType();
/*     */   }
/*     */   
/*     */   public String getLocalName() {
/* 142 */     return this.mReader.getLocalName();
/*     */   }
/*     */   
/*     */   public Location getLocation() {
/* 146 */     return this.mReader.getLocation();
/*     */   }
/*     */   
/*     */   public QName getName() {
/* 150 */     return this.mReader.getName();
/*     */   }
/*     */   
/*     */   public NamespaceContext getNamespaceContext() {
/* 154 */     return this.mReader.getNamespaceContext();
/*     */   }
/*     */   
/*     */   public int getNamespaceCount() {
/* 158 */     return this.mReader.getNamespaceCount();
/*     */   }
/*     */   
/*     */   public String getNamespacePrefix(int index) {
/* 162 */     return this.mReader.getNamespacePrefix(index);
/*     */   }
/*     */   
/*     */   public String getNamespaceURI() {
/* 166 */     return this.mReader.getNamespaceURI();
/*     */   }
/*     */   
/*     */   public String getNamespaceURI(int index) {
/* 170 */     return this.mReader.getNamespaceURI(index);
/*     */   }
/*     */   
/*     */   public String getNamespaceURI(String prefix) {
/* 174 */     return this.mReader.getNamespaceURI(prefix);
/*     */   }
/*     */   
/*     */   public String getPIData() {
/* 178 */     return this.mReader.getPIData();
/*     */   }
/*     */   
/*     */   public String getPITarget() {
/* 182 */     return this.mReader.getPITarget();
/*     */   }
/*     */   
/*     */   public String getPrefix() {
/* 186 */     return this.mReader.getPrefix();
/*     */   }
/*     */   
/*     */   public String getText()
/*     */   {
/* 191 */     return this.mReader.getText();
/*     */   }
/*     */   
/*     */   public char[] getTextCharacters()
/*     */   {
/* 196 */     return this.mReader.getTextCharacters();
/*     */   }
/*     */   
/*     */   public int getTextCharacters(int sourceStart, char[] target, int targetStart, int len)
/*     */     throws XMLStreamException
/*     */   {
/* 202 */     return this.mReader.getTextCharacters(sourceStart, target, targetStart, len);
/*     */   }
/*     */   
/*     */   public int getTextLength() {
/* 206 */     return this.mReader.getTextLength();
/*     */   }
/*     */   
/*     */   public int getTextStart() {
/* 210 */     return this.mReader.getTextStart();
/*     */   }
/*     */   
/*     */   public boolean hasName() {
/* 214 */     return this.mReader.hasName();
/*     */   }
/*     */   
/*     */   public boolean hasNext()
/*     */     throws XMLStreamException
/*     */   {
/* 220 */     return this.mReader.hasNext();
/*     */   }
/*     */   
/*     */   public boolean hasText() {
/* 224 */     return this.mReader.hasText();
/*     */   }
/*     */   
/*     */   public boolean isAttributeSpecified(int index) {
/* 228 */     return this.mReader.isAttributeSpecified(index);
/*     */   }
/*     */   
/*     */   public boolean isCharacters() {
/* 232 */     return this.mReader.isCharacters();
/*     */   }
/*     */   
/*     */   public boolean isEndElement() {
/* 236 */     return this.mReader.isEndElement();
/*     */   }
/*     */   
/*     */   public boolean isStartElement() {
/* 240 */     return this.mReader.isStartElement();
/*     */   }
/*     */   
/*     */   public boolean isWhiteSpace()
/*     */   {
/* 245 */     return this.mReader.isWhiteSpace();
/*     */   }
/*     */   
/*     */   public void require(int type, String nsUri, String localName)
/*     */     throws XMLStreamException
/*     */   {
/* 251 */     this.mReader.require(type, nsUri, localName);
/*     */   }
/*     */   
/*     */   public void close()
/*     */     throws XMLStreamException
/*     */   {
/* 257 */     this.mReader.close();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\stax\FilteredStreamReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */