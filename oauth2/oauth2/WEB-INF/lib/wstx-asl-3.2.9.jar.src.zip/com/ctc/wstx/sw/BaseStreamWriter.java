/*      */ package com.ctc.wstx.sw;
/*      */ 
/*      */ import com.ctc.wstx.api.WriterConfig;
/*      */ import com.ctc.wstx.cfg.ErrorConsts;
/*      */ import com.ctc.wstx.cfg.OutputConfigFlags;
/*      */ import com.ctc.wstx.exc.WstxIOException;
/*      */ import com.ctc.wstx.exc.WstxValidationException;
/*      */ import com.ctc.wstx.io.WstxInputLocation;
/*      */ import com.ctc.wstx.sr.AttributeCollector;
/*      */ import com.ctc.wstx.sr.InputElementStack;
/*      */ import com.ctc.wstx.sr.StreamReaderImpl;
/*      */ import com.ctc.wstx.util.StringUtil;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.io.Writer;
/*      */ import java.text.MessageFormat;
/*      */ import javax.xml.namespace.NamespaceContext;
/*      */ import javax.xml.namespace.QName;
/*      */ import javax.xml.stream.Location;
/*      */ import javax.xml.stream.XMLReporter;
/*      */ import javax.xml.stream.XMLStreamConstants;
/*      */ import javax.xml.stream.XMLStreamException;
/*      */ import javax.xml.stream.events.Characters;
/*      */ import javax.xml.stream.events.StartElement;
/*      */ import org.codehaus.stax2.DTDInfo;
/*      */ import org.codehaus.stax2.XMLStreamLocation2;
/*      */ import org.codehaus.stax2.XMLStreamReader2;
/*      */ import org.codehaus.stax2.XMLStreamWriter2;
/*      */ import org.codehaus.stax2.validation.ValidationContext;
/*      */ import org.codehaus.stax2.validation.ValidationProblemHandler;
/*      */ import org.codehaus.stax2.validation.ValidatorPair;
/*      */ import org.codehaus.stax2.validation.XMLValidationException;
/*      */ import org.codehaus.stax2.validation.XMLValidationProblem;
/*      */ import org.codehaus.stax2.validation.XMLValidationSchema;
/*      */ import org.codehaus.stax2.validation.XMLValidator;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class BaseStreamWriter
/*      */   implements XMLStreamWriter2, ValidationContext, XMLStreamConstants, OutputConfigFlags
/*      */ {
/*      */   protected static final int STATE_PROLOG = 1;
/*      */   protected static final int STATE_TREE = 2;
/*      */   protected static final int STATE_EPILOG = 3;
/*      */   protected static final char CHAR_SPACE = ' ';
/*      */   protected static final String NO_NS_URI = "";
/*   74 */   protected static final String NO_PREFIX = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final int MIN_ARRAYCOPY = 12;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final int ATTR_MIN_ARRAYCOPY = 12;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final int DEFAULT_COPYBUFFER_LEN = 512;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final XmlWriter mWriter;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  109 */   protected char[] mCopyBuffer = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final WriterConfig mConfig;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final boolean mCfgCDataAsText;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final boolean mCfgCopyDefaultAttrs;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final boolean mCfgAutomaticEmptyElems;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean mCheckStructure;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean mCheckAttrs;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String mEncoding;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  151 */   protected XMLValidator mValidator = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  157 */   protected boolean mXml11 = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  162 */   protected ValidationProblemHandler mVldProbHandler = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  170 */   protected int mState = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  177 */   protected boolean mAnyOutput = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  185 */   protected boolean mStartElementOpen = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  195 */   protected boolean mEmptyElement = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  203 */   protected int mVldContent = 3;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  212 */   protected String mDtdRootElem = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  244 */   protected XMLStreamReader2 mLastReader = null;
/*      */   
/*  246 */   protected StreamReaderImpl mLastReaderImpl = null;
/*      */   
/*  248 */   protected AttributeCollector mAttrCollector = null;
/*      */   
/*  250 */   protected InputElementStack mInputElemStack = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected BaseStreamWriter(XmlWriter xw, String enc, WriterConfig cfg)
/*      */   {
/*  260 */     this.mWriter = xw;
/*  261 */     this.mEncoding = enc;
/*  262 */     this.mConfig = cfg;
/*      */     
/*  264 */     int flags = cfg.getConfigFlags();
/*      */     
/*  266 */     this.mCheckStructure = ((flags & 0x100) != 0);
/*  267 */     this.mCheckAttrs = ((flags & 0x800) != 0);
/*      */     
/*  269 */     this.mCfgAutomaticEmptyElems = ((flags & 0x4) != 0);
/*  270 */     this.mCfgCDataAsText = ((flags & 0x8) != 0);
/*  271 */     this.mCfgCopyDefaultAttrs = ((flags & 0x10) != 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws XMLStreamException
/*      */   {
/*  288 */     finishDocument();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void flush()
/*      */     throws XMLStreamException
/*      */   {
/*      */     try
/*      */     {
/*  311 */       this.mWriter.flush();
/*      */     } catch (IOException ie) {
/*  313 */       throw new WstxIOException(ie);
/*      */     }
/*      */   }
/*      */   
/*      */   public abstract NamespaceContext getNamespaceContext();
/*      */   
/*      */   public abstract String getPrefix(String paramString);
/*      */   
/*      */   public Object getProperty(String name) {
/*  322 */     if (name.equals("com.ctc.wstx.outputUnderlyingStream")) {
/*  323 */       return this.mWriter.getOutputStream();
/*      */     }
/*  325 */     if (name.equals("com.ctc.wstx.outputUnderlyingWriter")) {
/*  326 */       return this.mWriter.getWriter();
/*      */     }
/*  328 */     return this.mConfig.getProperty(name);
/*      */   }
/*      */   
/*      */ 
/*      */   public abstract void setDefaultNamespace(String paramString)
/*      */     throws XMLStreamException;
/*      */   
/*      */ 
/*      */   public abstract void setNamespaceContext(NamespaceContext paramNamespaceContext)
/*      */     throws XMLStreamException;
/*      */   
/*      */ 
/*      */   public abstract void setPrefix(String paramString1, String paramString2)
/*      */     throws XMLStreamException;
/*      */   
/*      */ 
/*      */   public abstract void writeAttribute(String paramString1, String paramString2)
/*      */     throws XMLStreamException;
/*      */   
/*      */ 
/*      */   public abstract void writeAttribute(String paramString1, String paramString2, String paramString3)
/*      */     throws XMLStreamException;
/*      */   
/*      */ 
/*      */   public abstract void writeAttribute(String paramString1, String paramString2, String paramString3, String paramString4)
/*      */     throws XMLStreamException;
/*      */   
/*      */   public void writeCData(String data)
/*      */     throws XMLStreamException
/*      */   {
/*  358 */     if (this.mCfgCDataAsText) {
/*  359 */       writeCharacters(data);
/*  360 */       return;
/*      */     }
/*      */     
/*  363 */     this.mAnyOutput = true;
/*      */     
/*  365 */     if (this.mStartElementOpen) {
/*  366 */       closeStartElement(this.mEmptyElement);
/*      */     }
/*  368 */     verifyWriteCData();
/*  369 */     if ((this.mVldContent == 2) && (this.mValidator != null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  374 */       this.mValidator.validateText(data, false);
/*      */     }
/*      */     int ix;
/*      */     try {
/*  378 */       ix = this.mWriter.writeCData(data);
/*      */     } catch (IOException ioe) {
/*  380 */       throw new WstxIOException(ioe);
/*      */     }
/*  382 */     if (ix >= 0) {
/*  383 */       reportNwfContent(ErrorConsts.WERR_CDATA_CONTENT, new Integer(ix));
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeCharacters(char[] text, int start, int len)
/*      */     throws XMLStreamException
/*      */   {
/*  390 */     this.mAnyOutput = true;
/*      */     
/*  392 */     if (this.mStartElementOpen) {
/*  393 */       closeStartElement(this.mEmptyElement);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  399 */     if ((this.mCheckStructure) && 
/*  400 */       (inPrologOrEpilog()) && 
/*  401 */       (!StringUtil.isAllWhitespace(text, start, len))) {
/*  402 */       reportNwfStructure(ErrorConsts.WERR_PROLOG_NONWS_TEXT);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  407 */     if (this.mVldContent <= 1) {
/*  408 */       if (this.mVldContent == 0) {
/*  409 */         reportInvalidContent(4);
/*      */       }
/*  411 */       else if (!StringUtil.isAllWhitespace(text, start, len)) {
/*  412 */         reportInvalidContent(4);
/*      */       }
/*      */     }
/*  415 */     else if ((this.mVldContent == 2) && 
/*  416 */       (this.mValidator != null))
/*      */     {
/*      */ 
/*      */ 
/*  420 */       this.mValidator.validateText(text, start, len, false);
/*      */     }
/*      */     
/*      */ 
/*  424 */     if (len > 0)
/*      */     {
/*      */       try
/*      */       {
/*      */ 
/*  429 */         if (inPrologOrEpilog()) {
/*  430 */           this.mWriter.writeRaw(text, start, len);
/*      */         } else {
/*  432 */           this.mWriter.writeCharacters(text, start, len);
/*      */         }
/*      */       } catch (IOException ioe) {
/*  435 */         throw new WstxIOException(ioe);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeCharacters(String text)
/*      */     throws XMLStreamException
/*      */   {
/*  443 */     this.mAnyOutput = true;
/*      */     
/*  445 */     if (this.mStartElementOpen) {
/*  446 */       closeStartElement(this.mEmptyElement);
/*      */     }
/*      */     
/*      */ 
/*  450 */     if (this.mCheckStructure)
/*      */     {
/*  452 */       if ((inPrologOrEpilog()) && 
/*  453 */         (!StringUtil.isAllWhitespace(text))) {
/*  454 */         reportNwfStructure(ErrorConsts.WERR_PROLOG_NONWS_TEXT);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  464 */     if (this.mVldContent <= 1) {
/*  465 */       if (this.mVldContent == 0) {
/*  466 */         reportInvalidContent(4);
/*      */       }
/*  468 */       else if (!StringUtil.isAllWhitespace(text)) {
/*  469 */         reportInvalidContent(4);
/*      */       }
/*      */     }
/*  472 */     else if ((this.mVldContent == 2) && 
/*  473 */       (this.mValidator != null))
/*      */     {
/*      */ 
/*      */ 
/*  477 */       this.mValidator.validateText(text, false);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  485 */     if (inPrologOrEpilog()) {
/*      */       try {
/*  487 */         this.mWriter.writeRaw(text);
/*      */       } catch (IOException ioe) {
/*  489 */         throw new WstxIOException(ioe);
/*      */       }
/*  491 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  498 */     int len = text.length();
/*  499 */     if (len >= 12) {
/*  500 */       char[] buf = this.mCopyBuffer;
/*  501 */       if (buf == null) {
/*  502 */         this.mCopyBuffer = (buf = this.mConfig.allocMediumCBuffer(512));
/*      */       }
/*  504 */       int offset = 0;
/*  505 */       while (len > 0) {
/*  506 */         int thisLen = len > buf.length ? buf.length : len;
/*  507 */         text.getChars(offset, offset + thisLen, buf, 0);
/*      */         try {
/*  509 */           this.mWriter.writeCharacters(buf, 0, thisLen);
/*      */         } catch (IOException ioe) {
/*  511 */           throw new WstxIOException(ioe);
/*      */         }
/*  513 */         offset += thisLen;
/*  514 */         len -= thisLen;
/*      */       }
/*      */     } else {
/*      */       try {
/*  518 */         this.mWriter.writeCharacters(text);
/*      */       } catch (IOException ioe) {
/*  520 */         throw new WstxIOException(ioe);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeComment(String data)
/*      */     throws XMLStreamException
/*      */   {
/*  528 */     this.mAnyOutput = true;
/*      */     
/*  530 */     if (this.mStartElementOpen) {
/*  531 */       closeStartElement(this.mEmptyElement);
/*      */     }
/*      */     
/*      */ 
/*  535 */     if (this.mVldContent == 0) {
/*  536 */       reportInvalidContent(5);
/*      */     }
/*      */     
/*      */ 
/*      */     int ix;
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  545 */       ix = this.mWriter.writeComment(data);
/*      */     } catch (IOException ioe) {
/*  547 */       throw new WstxIOException(ioe);
/*      */     }
/*      */     
/*  550 */     if (ix >= 0) {
/*  551 */       reportNwfContent(ErrorConsts.WERR_COMMENT_CONTENT, new Integer(ix));
/*      */     }
/*      */   }
/*      */   
/*      */   public abstract void writeDefaultNamespace(String paramString)
/*      */     throws XMLStreamException;
/*      */   
/*      */   public void writeDTD(String dtd)
/*      */     throws XMLStreamException
/*      */   {
/*  561 */     verifyWriteDTD();
/*  562 */     this.mDtdRootElem = "";
/*      */     try {
/*  564 */       this.mWriter.writeDTD(dtd);
/*      */     } catch (IOException ioe) {
/*  566 */       throw new WstxIOException(ioe);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public abstract void writeEmptyElement(String paramString)
/*      */     throws XMLStreamException;
/*      */   
/*      */ 
/*      */   public abstract void writeEmptyElement(String paramString1, String paramString2)
/*      */     throws XMLStreamException;
/*      */   
/*      */ 
/*      */   public abstract void writeEmptyElement(String paramString1, String paramString2, String paramString3)
/*      */     throws XMLStreamException;
/*      */   
/*      */   public void writeEndDocument()
/*      */     throws XMLStreamException
/*      */   {
/*  585 */     finishDocument();
/*      */   }
/*      */   
/*      */   public abstract void writeEndElement()
/*      */     throws XMLStreamException;
/*      */   
/*      */   public void writeEntityRef(String name) throws XMLStreamException
/*      */   {
/*  593 */     this.mAnyOutput = true;
/*      */     
/*  595 */     if (this.mStartElementOpen) {
/*  596 */       closeStartElement(this.mEmptyElement);
/*      */     }
/*      */     
/*      */ 
/*  600 */     if ((this.mCheckStructure) && 
/*  601 */       (inPrologOrEpilog())) {
/*  602 */       reportNwfStructure("Trying to output an entity reference outside main element tree (in prolog or epilog)");
/*      */     }
/*      */     
/*      */ 
/*  606 */     if (this.mVldContent == 0)
/*      */     {
/*      */ 
/*      */ 
/*  610 */       reportInvalidContent(9);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  620 */       this.mWriter.writeEntityReference(name);
/*      */     } catch (IOException ioe) {
/*  622 */       throw new WstxIOException(ioe);
/*      */     }
/*      */   }
/*      */   
/*      */   public abstract void writeNamespace(String paramString1, String paramString2)
/*      */     throws XMLStreamException;
/*      */   
/*      */   public void writeProcessingInstruction(String target)
/*      */     throws XMLStreamException
/*      */   {
/*  632 */     writeProcessingInstruction(target, null);
/*      */   }
/*      */   
/*      */   public void writeProcessingInstruction(String target, String data)
/*      */     throws XMLStreamException
/*      */   {
/*  638 */     this.mAnyOutput = true;
/*      */     
/*  640 */     if (this.mStartElementOpen) {
/*  641 */       closeStartElement(this.mEmptyElement);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  646 */     if (this.mVldContent == 0) {
/*  647 */       reportInvalidContent(3);
/*      */     }
/*      */     int ix;
/*      */     try {
/*  651 */       ix = this.mWriter.writePI(target, data);
/*      */     } catch (IOException ioe) {
/*  653 */       throw new WstxIOException(ioe);
/*      */     }
/*  655 */     if (ix >= 0) {
/*  656 */       throw new XMLStreamException("Illegal input: processing instruction content has embedded '?>' in it (index " + ix + ")");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeStartDocument()
/*      */     throws XMLStreamException
/*      */   {
/*  672 */     if (this.mEncoding == null) {
/*  673 */       this.mEncoding = "UTF-8";
/*      */     }
/*  675 */     writeStartDocument(this.mEncoding, "1.0");
/*      */   }
/*      */   
/*      */   public void writeStartDocument(String version)
/*      */     throws XMLStreamException
/*      */   {
/*  681 */     writeStartDocument(this.mEncoding, version);
/*      */   }
/*      */   
/*      */   public void writeStartDocument(String encoding, String version)
/*      */     throws XMLStreamException
/*      */   {
/*  687 */     doWriteStartDocument(version, encoding, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doWriteStartDocument(String version, String encoding, String standAlone)
/*      */     throws XMLStreamException
/*      */   {
/*  697 */     if ((this.mCheckStructure) && 
/*  698 */       (this.mAnyOutput)) {
/*  699 */       reportNwfStructure("Can not output XML declaration, after other output has already been done.");
/*      */     }
/*      */     
/*      */ 
/*  703 */     this.mAnyOutput = true;
/*      */     
/*  705 */     if (this.mConfig.willValidateContent())
/*      */     {
/*      */ 
/*      */ 
/*  709 */       if ((version != null) && (version.length() > 0) && 
/*  710 */         (!version.equals("1.0")) && (!version.equals("1.1")))
/*      */       {
/*  712 */         reportNwfContent("Illegal version argument ('" + version + "'); should only use '" + "1.0" + "' or '" + "1.1" + "'");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  719 */     if ((version == null) || (version.length() == 0)) {
/*  720 */       version = "1.0";
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  726 */     this.mXml11 = "1.1".equals(version);
/*  727 */     if (this.mXml11) {
/*  728 */       this.mWriter.enableXml11();
/*      */     }
/*      */     
/*  731 */     if ((encoding != null) && (encoding.length() > 0))
/*      */     {
/*      */ 
/*      */ 
/*  735 */       if ((this.mEncoding == null) || (this.mEncoding.length() == 0)) {
/*  736 */         this.mEncoding = encoding;
/*      */       }
/*      */     }
/*      */     try {
/*  740 */       this.mWriter.writeXmlDeclaration(version, encoding, standAlone);
/*      */     } catch (IOException ioe) {
/*  742 */       throw new WstxIOException(ioe);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeStartElement(String paramString)
/*      */     throws XMLStreamException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeStartElement(String paramString1, String paramString2)
/*      */     throws XMLStreamException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeStartElement(String paramString1, String paramString2, String paramString3)
/*      */     throws XMLStreamException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void copyEventFromReader(XMLStreamReader2 sr, boolean preserveEventData)
/*      */     throws XMLStreamException
/*      */   {
/*      */     try
/*      */     {
/*  778 */       switch (sr.getEventType())
/*      */       {
/*      */       case 7: 
/*  781 */         String version = sr.getVersion();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  786 */         if ((version != null) && (version.length() != 0))
/*      */         {
/*      */ 
/*  789 */           if (sr.standaloneSet()) {
/*  790 */             writeStartDocument(sr.getVersion(), sr.getCharacterEncodingScheme(), sr.isStandalone());
/*      */           }
/*      */           else
/*      */           {
/*  794 */             writeStartDocument(sr.getCharacterEncodingScheme(), sr.getVersion());
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*  799 */         return;
/*      */       
/*      */       case 8: 
/*  802 */         writeEndDocument();
/*  803 */         return;
/*      */       
/*      */ 
/*      */ 
/*      */       case 1: 
/*  808 */         if (sr != this.mLastReader) {
/*  809 */           this.mLastReader = sr;
/*      */           
/*      */ 
/*  812 */           if (!(sr instanceof StreamReaderImpl)) {
/*  813 */             throw new XMLStreamException("Can not yet copy START_ELEMENT events from non-Woodstox stream readers (class " + sr.getClass() + ")");
/*      */           }
/*  815 */           this.mLastReaderImpl = ((StreamReaderImpl)sr);
/*  816 */           this.mAttrCollector = this.mLastReaderImpl.getAttributeCollector();
/*  817 */           this.mInputElemStack = this.mLastReaderImpl.getInputElementStack();
/*      */         }
/*  819 */         copyStartElement(this.mInputElemStack, this.mAttrCollector);
/*      */         
/*  821 */         return;
/*      */       
/*      */       case 2: 
/*  824 */         writeEndElement();
/*  825 */         return;
/*      */       
/*      */ 
/*      */       case 6: 
/*  829 */         this.mAnyOutput = true;
/*      */         
/*  831 */         if (this.mStartElementOpen) {
/*  832 */           closeStartElement(this.mEmptyElement);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  838 */         sr.getText(wrapAsRawWriter(), preserveEventData);
/*      */         
/*  840 */         return;
/*      */       
/*      */ 
/*      */ 
/*      */       case 12: 
/*  845 */         if (!this.mCfgCDataAsText) {
/*  846 */           this.mAnyOutput = true;
/*      */           
/*  848 */           if (this.mStartElementOpen) {
/*  849 */             closeStartElement(this.mEmptyElement);
/*      */           }
/*      */           
/*      */ 
/*  853 */           if ((this.mCheckStructure) && 
/*  854 */             (inPrologOrEpilog())) {
/*  855 */             reportNwfStructure(ErrorConsts.WERR_PROLOG_CDATA);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  861 */           this.mWriter.writeCDataStart();
/*  862 */           sr.getText(wrapAsRawWriter(), preserveEventData);
/*  863 */           this.mWriter.writeCDataEnd();
/*  864 */           return;
/*      */         }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       case 4: 
/*  873 */         this.mAnyOutput = true;
/*      */         
/*  875 */         if (this.mStartElementOpen) {
/*  876 */           closeStartElement(this.mEmptyElement);
/*      */         }
/*  878 */         sr.getText(wrapAsTextWriter(), preserveEventData);
/*      */         
/*  880 */         return;
/*      */       
/*      */ 
/*      */       case 5: 
/*  884 */         this.mAnyOutput = true;
/*  885 */         if (this.mStartElementOpen) {
/*  886 */           closeStartElement(this.mEmptyElement);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  891 */         this.mWriter.writeCommentStart();
/*  892 */         sr.getText(wrapAsRawWriter(), preserveEventData);
/*  893 */         this.mWriter.writeCommentEnd();
/*      */         
/*  895 */         return;
/*      */       
/*      */ 
/*      */       case 3: 
/*  899 */         this.mWriter.writePIStart(sr.getPITarget(), true);
/*  900 */         sr.getText(wrapAsRawWriter(), preserveEventData);
/*  901 */         this.mWriter.writePIEnd();
/*      */         
/*  903 */         return;
/*      */       
/*      */ 
/*      */       case 11: 
/*  907 */         DTDInfo info = sr.getDTDInfo();
/*  908 */         if (info == null)
/*      */         {
/*      */ 
/*      */ 
/*  912 */           throwOutputError("Current state DOCTYPE, but not DTDInfo Object returned -- reader doesn't support DTDs?");
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  918 */         writeDTD(info);
/*      */         
/*  920 */         return;
/*      */       
/*      */       case 9: 
/*  923 */         writeEntityRef(sr.getLocalName());
/*  924 */         return;
/*      */       
/*      */ 
/*      */ 
/*      */       }
/*      */       
/*      */     }
/*      */     catch (IOException ioe)
/*      */     {
/*  933 */       throw new WstxIOException(ioe);
/*      */     }
/*      */     
/*  936 */     throw new XMLStreamException("Unrecognized event type (" + sr.getEventType() + "); not sure how to copy");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isPropertySupported(String name)
/*      */   {
/*  950 */     return this.mConfig.isPropertySupported(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setProperty(String name, Object value)
/*      */   {
/*  965 */     return this.mConfig.setProperty(name, value);
/*      */   }
/*      */   
/*      */   public XMLValidator validateAgainst(XMLValidationSchema schema)
/*      */     throws XMLStreamException
/*      */   {
/*  971 */     XMLValidator vld = schema.createValidator(this);
/*      */     
/*  973 */     if (this.mValidator == null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  978 */       this.mCheckStructure = true;
/*  979 */       this.mCheckAttrs = true;
/*  980 */       this.mValidator = vld;
/*      */     } else {
/*  982 */       this.mValidator = new ValidatorPair(this.mValidator, vld);
/*      */     }
/*  984 */     return vld;
/*      */   }
/*      */   
/*      */   public XMLValidator stopValidatingAgainst(XMLValidationSchema schema)
/*      */     throws XMLStreamException
/*      */   {
/*  990 */     XMLValidator[] results = new XMLValidator[2];
/*  991 */     XMLValidator found = null;
/*  992 */     if (ValidatorPair.removeValidator(this.mValidator, schema, results)) {
/*  993 */       found = results[0];
/*  994 */       this.mValidator = results[1];
/*  995 */       found.validationCompleted(false);
/*  996 */       if (this.mValidator == null) {
/*  997 */         resetValidationFlags();
/*      */       }
/*      */     }
/* 1000 */     return found;
/*      */   }
/*      */   
/*      */   public XMLValidator stopValidatingAgainst(XMLValidator validator)
/*      */     throws XMLStreamException
/*      */   {
/* 1006 */     XMLValidator[] results = new XMLValidator[2];
/* 1007 */     XMLValidator found = null;
/* 1008 */     if (ValidatorPair.removeValidator(this.mValidator, validator, results)) {
/* 1009 */       found = results[0];
/* 1010 */       this.mValidator = results[1];
/* 1011 */       found.validationCompleted(false);
/* 1012 */       if (this.mValidator == null) {
/* 1013 */         resetValidationFlags();
/*      */       }
/*      */     }
/* 1016 */     return found;
/*      */   }
/*      */   
/*      */   public ValidationProblemHandler setValidationProblemHandler(ValidationProblemHandler h)
/*      */   {
/* 1021 */     ValidationProblemHandler oldH = this.mVldProbHandler;
/* 1022 */     this.mVldProbHandler = h;
/* 1023 */     return oldH;
/*      */   }
/*      */   
/*      */   private void resetValidationFlags()
/*      */   {
/* 1028 */     int flags = this.mConfig.getConfigFlags();
/* 1029 */     this.mCheckStructure = ((flags & 0x100) != 0);
/* 1030 */     this.mCheckAttrs = ((flags & 0x800) != 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public XMLStreamLocation2 getLocation()
/*      */   {
/* 1041 */     return new WstxInputLocation(null, null, null, this.mWriter.getAbsOffset(), this.mWriter.getRow(), this.mWriter.getColumn());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getEncoding()
/*      */   {
/* 1048 */     return this.mEncoding;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeCData(char[] cbuf, int start, int len)
/*      */     throws XMLStreamException
/*      */   {
/* 1064 */     if (this.mCfgCDataAsText) {
/* 1065 */       writeCharacters(cbuf, start, len);
/* 1066 */       return;
/*      */     }
/*      */     
/* 1069 */     this.mAnyOutput = true;
/*      */     
/* 1071 */     if (this.mStartElementOpen) {
/* 1072 */       closeStartElement(this.mEmptyElement);
/*      */     }
/* 1074 */     verifyWriteCData();
/* 1075 */     if ((this.mVldContent == 2) && (this.mValidator != null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1080 */       this.mValidator.validateText(cbuf, start, len, false);
/*      */     }
/*      */     int ix;
/*      */     try {
/* 1084 */       ix = this.mWriter.writeCData(cbuf, start, len);
/*      */     } catch (IOException ioe) {
/* 1086 */       throw new WstxIOException(ioe);
/*      */     }
/* 1088 */     if (ix >= 0) {
/* 1089 */       throwOutputError(ErrorConsts.WERR_CDATA_CONTENT, new Integer(ix));
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeDTD(DTDInfo info)
/*      */     throws XMLStreamException
/*      */   {
/* 1096 */     writeDTD(info.getDTDRootName(), info.getDTDSystemId(), info.getDTDPublicId(), info.getDTDInternalSubset());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void writeDTD(String rootName, String systemId, String publicId, String internalSubset)
/*      */     throws XMLStreamException
/*      */   {
/* 1104 */     verifyWriteDTD();
/* 1105 */     this.mDtdRootElem = rootName;
/*      */     try {
/* 1107 */       this.mWriter.writeDTD(rootName, systemId, publicId, internalSubset);
/*      */     } catch (IOException ioe) {
/* 1109 */       throw new WstxIOException(ioe);
/*      */     }
/*      */   }
/*      */   
/*      */   public abstract void writeFullEndElement()
/*      */     throws XMLStreamException;
/*      */   
/*      */   public void writeStartDocument(String version, String encoding, boolean standAlone)
/*      */     throws XMLStreamException
/*      */   {
/* 1119 */     doWriteStartDocument(version, encoding, standAlone ? "yes" : "no");
/*      */   }
/*      */   
/*      */   public void writeRaw(String text)
/*      */     throws XMLStreamException
/*      */   {
/* 1125 */     this.mAnyOutput = true;
/* 1126 */     if (this.mStartElementOpen) {
/* 1127 */       closeStartElement(this.mEmptyElement);
/*      */     }
/*      */     try {
/* 1130 */       this.mWriter.writeRaw(text, 0, text.length());
/*      */     } catch (IOException ioe) {
/* 1132 */       throw new WstxIOException(ioe);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeRaw(String text, int start, int offset)
/*      */     throws XMLStreamException
/*      */   {
/* 1139 */     this.mAnyOutput = true;
/* 1140 */     if (this.mStartElementOpen) {
/* 1141 */       closeStartElement(this.mEmptyElement);
/*      */     }
/*      */     try {
/* 1144 */       this.mWriter.writeRaw(text, start, offset);
/*      */     } catch (IOException ioe) {
/* 1146 */       throw new WstxIOException(ioe);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeRaw(char[] text, int offset, int length)
/*      */     throws XMLStreamException
/*      */   {
/* 1153 */     this.mAnyOutput = true;
/* 1154 */     if (this.mStartElementOpen) {
/* 1155 */       closeStartElement(this.mEmptyElement);
/*      */     }
/*      */     try {
/* 1158 */       this.mWriter.writeRaw(text, offset, length);
/*      */     } catch (IOException ioe) {
/* 1160 */       throw new WstxIOException(ioe);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getXmlVersion()
/*      */   {
/* 1171 */     return this.mXml11 ? "1.1" : "1.0";
/*      */   }
/*      */   
/*      */ 
/*      */   public abstract QName getCurrentElementName();
/*      */   
/*      */ 
/*      */   public abstract String getNamespaceURI(String paramString);
/*      */   
/*      */ 
/*      */   public String getBaseUri()
/*      */   {
/* 1183 */     return null;
/*      */   }
/*      */   
/*      */   public Location getValidationLocation() {
/* 1187 */     return getLocation();
/*      */   }
/*      */   
/*      */ 
/*      */   public void reportProblem(XMLValidationProblem prob)
/*      */     throws XMLValidationException
/*      */   {
/* 1194 */     if (this.mVldProbHandler != null) {
/* 1195 */       this.mVldProbHandler.reportProblem(prob);
/* 1196 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1203 */     if ((prob.getSeverity() >= 2) && 
/* 1204 */       (isValidating())) {
/* 1205 */       throw WstxValidationException.create(prob);
/*      */     }
/*      */     
/* 1208 */     XMLReporter rep = this.mConfig.getProblemReporter();
/* 1209 */     if (rep != null) {
/* 1210 */       doReportProblem(rep, ErrorConsts.WT_VALIDATION, prob.getMessage(), prob.getLocation());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int addDefaultAttribute(String localName, String uri, String prefix, String value)
/*      */   {
/* 1223 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 1228 */   public boolean isNotationDeclared(String name) { return false; }
/*      */   
/* 1230 */   public boolean isUnparsedEntityDeclared(String name) { return false; }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1235 */   public int getAttributeCount() { return 0; }
/*      */   
/* 1237 */   public String getAttributeLocalName(int index) { return null; }
/*      */   
/* 1239 */   public String getAttributeNamespace(int index) { return null; }
/*      */   
/* 1241 */   public String getAttributePrefix(int index) { return null; }
/*      */   
/* 1243 */   public String getAttributeValue(int index) { return null; }
/*      */   
/*      */   public String getAttributeValue(String nsURI, String localName) {
/* 1246 */     return null;
/*      */   }
/*      */   
/*      */   public int findAttributeIndex(String nsURI, String localName) {
/* 1250 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Writer wrapAsRawWriter()
/*      */   {
/* 1266 */     return this.mWriter.wrapAsRawWriter();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Writer wrapAsTextWriter()
/*      */   {
/* 1276 */     return this.mWriter.wrapAsTextWriter();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isValidating()
/*      */   {
/* 1288 */     return this.mValidator != null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeStartElement(StartElement paramStartElement)
/*      */     throws XMLStreamException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeEndElement(QName paramQName)
/*      */     throws XMLStreamException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeCharacters(Characters ch)
/*      */     throws XMLStreamException
/*      */   {
/* 1322 */     if (this.mStartElementOpen) {
/* 1323 */       closeStartElement(this.mEmptyElement);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1329 */     if ((this.mCheckStructure) && 
/* 1330 */       (inPrologOrEpilog()) && 
/* 1331 */       (!ch.isIgnorableWhiteSpace()) && (!ch.isWhiteSpace())) {
/* 1332 */       reportNwfStructure(ErrorConsts.WERR_PROLOG_NONWS_TEXT);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1337 */     if (this.mVldContent <= 1) {
/* 1338 */       if (this.mVldContent == 0) {
/* 1339 */         reportInvalidContent(4);
/*      */       }
/* 1341 */       else if ((!ch.isIgnorableWhiteSpace()) && (!ch.isWhiteSpace())) {
/* 1342 */         reportInvalidContent(4);
/*      */       }
/*      */     }
/* 1345 */     else if ((this.mVldContent == 2) && 
/* 1346 */       (this.mValidator != null))
/*      */     {
/*      */ 
/*      */ 
/* 1350 */       this.mValidator.validateText(ch.getData(), false);
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1356 */       this.mWriter.writeCharacters(ch.getData());
/*      */     } catch (IOException ioe) {
/* 1358 */       throw new WstxIOException(ioe);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected abstract void closeStartElement(boolean paramBoolean)
/*      */     throws XMLStreamException;
/*      */   
/*      */ 
/*      */ 
/*      */   protected final boolean inPrologOrEpilog()
/*      */   {
/* 1371 */     return this.mState != 2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void copyStartElement(InputElementStack paramInputElementStack, AttributeCollector paramAttributeCollector)
/*      */     throws IOException, XMLStreamException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void verifyWriteCData()
/*      */     throws XMLStreamException
/*      */   {
/* 1392 */     if ((this.mCheckStructure) && 
/* 1393 */       (inPrologOrEpilog())) {
/* 1394 */       reportNwfStructure(ErrorConsts.WERR_PROLOG_CDATA);
/*      */     }
/*      */     
/*      */ 
/* 1398 */     if (this.mVldContent <= 1)
/*      */     {
/* 1400 */       reportInvalidContent(12);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected final void verifyWriteDTD()
/*      */     throws XMLStreamException
/*      */   {
/* 1408 */     if (this.mCheckStructure) {
/* 1409 */       if (this.mState != 1) {
/* 1410 */         throw new XMLStreamException("Can not write DOCTYPE declaration (DTD) when not in prolog any more (state " + this.mState + "; start element(s) written)");
/*      */       }
/*      */       
/* 1413 */       if (this.mDtdRootElem != null) {
/* 1414 */         throw new XMLStreamException("Trying to write multiple DOCTYPE declarations");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void verifyRootElement(String localName, String prefix)
/*      */     throws XMLValidationException
/*      */   {
/* 1425 */     if (isValidating())
/*      */     {
/*      */ 
/*      */ 
/* 1429 */       if ((this.mDtdRootElem != null) && (this.mDtdRootElem.length() > 0)) {
/* 1430 */         String wrongElem = null;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1436 */         if (!localName.equals(this.mDtdRootElem))
/*      */         {
/*      */ 
/* 1439 */           int lnLen = localName.length();
/* 1440 */           int oldLen = this.mDtdRootElem.length();
/*      */           
/* 1442 */           if ((oldLen <= lnLen) || (!this.mDtdRootElem.endsWith(localName)) || (this.mDtdRootElem.charAt(oldLen - lnLen - 1) != ':'))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 1447 */             if (prefix == null) {
/* 1448 */               wrongElem = localName;
/* 1449 */             } else if (prefix.length() == 0) {
/* 1450 */               wrongElem = "[unknown]:" + localName;
/*      */             } else {
/* 1452 */               wrongElem = prefix + ":" + localName;
/*      */             }
/*      */           }
/*      */         }
/* 1456 */         if (wrongElem != null) {
/* 1457 */           reportValidationProblem(ErrorConsts.ERR_VLD_WRONG_ROOT, wrongElem, this.mDtdRootElem);
/*      */         }
/*      */       }
/*      */     }
/* 1461 */     this.mState = 2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static void throwOutputError(String msg)
/*      */     throws XMLStreamException
/*      */   {
/* 1473 */     throw new XMLStreamException(msg);
/*      */   }
/*      */   
/*      */   protected static void throwOutputError(String format, Object arg)
/*      */     throws XMLStreamException
/*      */   {
/* 1479 */     String msg = MessageFormat.format(format, new Object[] { arg });
/* 1480 */     throwOutputError(msg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static void reportIllegalMethod(String msg)
/*      */     throws XMLStreamException
/*      */   {
/* 1490 */     throwOutputError(msg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static void reportNwfStructure(String msg)
/*      */     throws XMLStreamException
/*      */   {
/* 1502 */     throwOutputError(msg);
/*      */   }
/*      */   
/*      */   protected static void reportNwfStructure(String msg, Object arg)
/*      */     throws XMLStreamException
/*      */   {
/* 1508 */     throwOutputError(msg, arg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static void reportNwfContent(String msg)
/*      */     throws XMLStreamException
/*      */   {
/* 1520 */     throwOutputError(msg);
/*      */   }
/*      */   
/*      */   protected static void reportNwfContent(String msg, Object arg)
/*      */     throws XMLStreamException
/*      */   {
/* 1526 */     throwOutputError(msg, arg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static void reportNwfAttr(String msg)
/*      */     throws XMLStreamException
/*      */   {
/* 1538 */     throwOutputError(msg);
/*      */   }
/*      */   
/*      */   protected static void reportNwfAttr(String msg, Object arg)
/*      */     throws XMLStreamException
/*      */   {
/* 1544 */     throwOutputError(msg, arg);
/*      */   }
/*      */   
/*      */   protected static void throwFromIOE(IOException ioe)
/*      */     throws XMLStreamException
/*      */   {
/* 1550 */     throw new WstxIOException(ioe);
/*      */   }
/*      */   
/*      */   protected static void reportIllegalArg(String msg)
/*      */     throws IllegalArgumentException
/*      */   {
/* 1556 */     throw new IllegalArgumentException(msg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void reportInvalidContent(int evtType)
/*      */     throws XMLStreamException
/*      */   {
/* 1576 */     switch (this.mVldContent) {
/*      */     case 0: 
/* 1578 */       reportValidationProblem(ErrorConsts.ERR_VLD_EMPTY, getTopElementDesc(), ErrorConsts.tokenTypeDesc(evtType));
/*      */       
/*      */ 
/* 1581 */       break;
/*      */     case 1: 
/* 1583 */       reportValidationProblem(ErrorConsts.ERR_VLD_NON_MIXED, getTopElementDesc());
/*      */       
/* 1585 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 2: 
/*      */     case 3: 
/* 1591 */       reportValidationProblem(ErrorConsts.ERR_VLD_ANY, getTopElementDesc(), ErrorConsts.tokenTypeDesc(evtType));
/*      */       
/*      */ 
/* 1594 */       break;
/*      */     default: 
/* 1596 */       reportValidationProblem("Internal error: trying to report invalid content for " + evtType);
/*      */     }
/*      */   }
/*      */   
/*      */   public void reportValidationProblem(String msg, Location loc, int severity)
/*      */     throws XMLValidationException
/*      */   {
/* 1603 */     reportProblem(new XMLValidationProblem(loc, msg, severity));
/*      */   }
/*      */   
/*      */   public void reportValidationProblem(String msg, int severity)
/*      */     throws XMLValidationException
/*      */   {
/* 1609 */     reportProblem(new XMLValidationProblem(getValidationLocation(), msg, severity));
/*      */   }
/*      */   
/*      */ 
/*      */   public void reportValidationProblem(String msg)
/*      */     throws XMLValidationException
/*      */   {
/* 1616 */     reportProblem(new XMLValidationProblem(getValidationLocation(), msg, 2));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void reportValidationProblem(Location loc, String msg)
/*      */     throws XMLValidationException
/*      */   {
/* 1624 */     reportProblem(new XMLValidationProblem(getValidationLocation(), msg));
/*      */   }
/*      */   
/*      */ 
/*      */   public void reportValidationProblem(String format, Object arg)
/*      */     throws XMLValidationException
/*      */   {
/* 1631 */     String msg = MessageFormat.format(format, new Object[] { arg });
/* 1632 */     reportProblem(new XMLValidationProblem(getValidationLocation(), msg));
/*      */   }
/*      */   
/*      */ 
/*      */   public void reportValidationProblem(String format, Object arg, Object arg2)
/*      */     throws XMLValidationException
/*      */   {
/* 1639 */     String msg = MessageFormat.format(format, new Object[] { arg, arg2 });
/* 1640 */     reportProblem(new XMLValidationProblem(getValidationLocation(), msg));
/*      */   }
/*      */   
/*      */ 
/*      */   protected final void doReportProblem(XMLReporter rep, String probType, String msg, Location loc)
/*      */   {
/* 1646 */     if (rep != null) {
/*      */       try {
/* 1648 */         rep.report(msg, probType, null, loc);
/*      */       }
/*      */       catch (XMLStreamException e) {
/* 1651 */         System.err.println("Problem reporting a problem: " + e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected abstract String getTopElementDesc();
/*      */   
/*      */   private final void finishDocument()
/*      */     throws XMLStreamException
/*      */   {
/* 1661 */     if (this.mState != 3) {
/* 1662 */       if ((this.mCheckStructure) && (this.mState == 1)) {
/* 1663 */         reportNwfStructure("Trying to write END_DOCUMENT when document has no root (ie. trying to output empty document).");
/*      */       }
/*      */       
/*      */ 
/* 1667 */       if (this.mStartElementOpen) {
/* 1668 */         closeStartElement(this.mEmptyElement);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1674 */       if ((this.mState != 3) && (this.mConfig.automaticEndElementsEnabled())) {
/*      */         do {
/* 1676 */           writeEndElement();
/* 1677 */         } while (this.mState != 3);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 1685 */       char[] buf = this.mCopyBuffer;
/* 1686 */       if (buf != null) {
/* 1687 */         this.mCopyBuffer = null;
/* 1688 */         this.mConfig.freeMediumCBuffer(buf);
/*      */       }
/* 1690 */       this.mWriter.close();
/*      */     } catch (IOException ie) {
/* 1692 */       throw new WstxIOException(ie);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1716 */     return "[StreamWriter: " + getClass() + ", underlying outputter: " + (this.mWriter == null ? "NULL" : this.mWriter.toString());
/*      */   }
/*      */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sw\BaseStreamWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */