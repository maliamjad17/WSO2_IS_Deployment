/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.BitSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DFAState
/*     */ {
/*     */   final int mIndex;
/*     */   final boolean mAccepting;
/*     */   BitSet mTokenSet;
/*  31 */   HashMap mNext = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DFAState(int index, BitSet tokenSet)
/*     */   {
/*  41 */     this.mIndex = index;
/*     */     
/*  43 */     this.mAccepting = tokenSet.get(0);
/*  44 */     this.mTokenSet = tokenSet;
/*     */   }
/*     */   
/*     */ 
/*     */   public static DFAState constructDFA(ContentSpec rootSpec)
/*     */   {
/*  50 */     ModelNode modelRoot = rootSpec.rewrite();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  55 */     TokenModel eofToken = TokenModel.getNullToken();
/*  56 */     ConcatModel dummyRoot = new ConcatModel(modelRoot, eofToken);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  61 */     ArrayList tokens = new ArrayList();
/*  62 */     tokens.add(eofToken);
/*  63 */     dummyRoot.indexTokens(tokens);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  68 */     int flen = tokens.size();
/*  69 */     BitSet[] followPos = new BitSet[flen];
/*  70 */     NameKey[] tokenNames = new NameKey[flen];
/*  71 */     for (int i = 0; i < flen; i++) {
/*  72 */       followPos[i] = new BitSet(flen);
/*  73 */       tokenNames[i] = ((TokenModel)tokens.get(i)).getName();
/*     */     }
/*  75 */     dummyRoot.calcFollowPos(followPos);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  81 */     BitSet initial = new BitSet(flen);
/*  82 */     dummyRoot.addFirstPos(initial);
/*  83 */     DFAState firstState = new DFAState(0, initial);
/*  84 */     ArrayList stateList = new ArrayList();
/*  85 */     stateList.add(firstState);
/*  86 */     HashMap stateMap = new HashMap();
/*  87 */     stateMap.put(initial, firstState);
/*     */     
/*  89 */     int i = 0;
/*  90 */     while (i < stateList.size()) {
/*  91 */       DFAState curr = (DFAState)stateList.get(i++);
/*  92 */       curr.calcNext(tokenNames, followPos, stateList, stateMap);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 103 */     return firstState;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAcceptingState()
/*     */   {
/* 113 */     return this.mAccepting;
/*     */   }
/*     */   
/*     */   public int getIndex() {
/* 117 */     return this.mIndex;
/*     */   }
/*     */   
/*     */   public DFAState findNext(NameKey elemName) {
/* 121 */     return (DFAState)this.mNext.get(elemName);
/*     */   }
/*     */   
/*     */   public TreeSet getNextNames()
/*     */   {
/* 126 */     TreeSet names = new TreeSet();
/* 127 */     Iterator it = this.mNext.keySet().iterator();
/* 128 */     while (it.hasNext()) {
/* 129 */       Object o = it.next();
/* 130 */       names.add(o);
/*     */     }
/* 132 */     return names;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void calcNext(NameKey[] tokenNames, BitSet[] tokenFPs, List stateList, Map stateMap)
/*     */   {
/* 141 */     int first = -1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 146 */     BitSet tokenSet = (BitSet)this.mTokenSet.clone();
/*     */     
/* 148 */     this.mTokenSet = null;
/*     */     
/* 150 */     while ((first = tokenSet.nextSetBit(first + 1)) >= 0) {
/* 151 */       NameKey tokenName = tokenNames[first];
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 156 */       if (tokenName != null)
/*     */       {
/*     */ 
/*     */ 
/* 160 */         BitSet nextGroup = (BitSet)tokenFPs[first].clone();
/* 161 */         int second = first;
/*     */         
/* 163 */         while ((second = tokenSet.nextSetBit(second + 1)) > 0) {
/* 164 */           if (tokenNames[second] == tokenName)
/*     */           {
/* 166 */             tokenSet.clear(second);
/* 167 */             nextGroup.or(tokenFPs[second]);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 172 */         DFAState next = (DFAState)stateMap.get(nextGroup);
/* 173 */         if (next == null) {
/* 174 */           next = new DFAState(stateList.size(), nextGroup);
/* 175 */           stateList.add(next);
/* 176 */           stateMap.put(nextGroup, next);
/*     */         }
/* 178 */         this.mNext.put(tokenName, next);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 190 */     StringBuffer sb = new StringBuffer();
/* 191 */     sb.append("State #" + this.mIndex + ":\n");
/* 192 */     sb.append("  Accepting: " + this.mAccepting);
/* 193 */     sb.append("\n  Next states:\n");
/* 194 */     Iterator it = this.mNext.entrySet().iterator();
/* 195 */     while (it.hasNext()) {
/* 196 */       Map.Entry en = (Map.Entry)it.next();
/* 197 */       sb.append(en.getKey());
/* 198 */       sb.append(" -> ");
/* 199 */       DFAState next = (DFAState)en.getValue();
/* 200 */       sb.append(next.getIndex());
/* 201 */       sb.append("\n");
/*     */     }
/* 203 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\DFAState.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */