/*     */ package com.ctc.wstx.sr;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ElemAttrs
/*     */ {
/*     */   private static final int OFFSET_LOCAL_NAME = 0;
/*     */   private static final int OFFSET_NS_URI = 1;
/*     */   private static final int OFFSET_NS_PREFIX = 2;
/*     */   private static final int OFFSET_VALUE = 3;
/*     */   private final String[] mRawAttrs;
/*     */   private final int mDefaultOffset;
/*     */   private final int[] mAttrMap;
/*     */   private final int mAttrHashSize;
/*     */   private final int mAttrSpillEnd;
/*     */   
/*     */   public ElemAttrs(String[] rawAttrs, int defOffset)
/*     */   {
/*  71 */     this.mRawAttrs = rawAttrs;
/*  72 */     this.mAttrMap = null;
/*  73 */     this.mAttrHashSize = 0;
/*  74 */     this.mAttrSpillEnd = 0;
/*  75 */     this.mDefaultOffset = (defOffset << 2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ElemAttrs(String[] rawAttrs, int defOffset, int[] attrMap, int hashSize, int spillEnd)
/*     */   {
/*  91 */     this.mRawAttrs = rawAttrs;
/*  92 */     this.mDefaultOffset = (defOffset << 2);
/*     */     
/*  94 */     this.mAttrMap = attrMap;
/*  95 */     this.mAttrHashSize = hashSize;
/*  96 */     this.mAttrSpillEnd = spillEnd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getRawAttrs()
/*     */   {
/* 106 */     return this.mRawAttrs;
/*     */   }
/*     */   
/*     */ 
/*     */   public int findIndex(QName name)
/*     */   {
/* 112 */     if (this.mAttrMap == null) {
/* 113 */       String ln = name.getLocalPart();
/* 114 */       String uri = name.getNamespaceURI();
/* 115 */       boolean defaultNs = (uri == null) || (uri.length() == 0);
/* 116 */       String[] raw = this.mRawAttrs;
/*     */       
/* 118 */       int i = 0; for (int len = raw.length; i < len; i += 4) {
/* 119 */         if (ln.equals(raw[i]))
/*     */         {
/*     */ 
/* 122 */           String thisUri = raw[(i + 1)];
/* 123 */           if (defaultNs) {
/* 124 */             if ((thisUri == null) || (thisUri.length() == 0)) {
/* 125 */               return i;
/*     */             }
/*     */           }
/* 128 */           else if ((thisUri != null) && ((thisUri == uri) || (thisUri.equals(uri))))
/*     */           {
/* 130 */             return i;
/*     */           }
/*     */         }
/*     */       }
/* 134 */       return -1;
/*     */     }
/*     */     
/*     */ 
/* 138 */     return findMapIndex(name.getNamespaceURI(), name.getLocalPart());
/*     */   }
/*     */   
/*     */   public int getFirstDefaultOffset() {
/* 142 */     return this.mDefaultOffset;
/*     */   }
/*     */   
/*     */   public boolean isDefault(int ix) {
/* 146 */     return ix >= this.mDefaultOffset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int findMapIndex(String nsURI, String localName)
/*     */   {
/* 166 */     int hash = localName.hashCode();
/* 167 */     if (nsURI == null) {
/* 168 */       nsURI = "";
/* 169 */     } else if (nsURI.length() > 0) {
/* 170 */       hash ^= nsURI.hashCode();
/*     */     }
/* 172 */     int ix = this.mAttrMap[(hash & this.mAttrHashSize - 1)];
/* 173 */     if (ix == 0) {
/* 174 */       return -1;
/*     */     }
/*     */     
/* 177 */     ix = ix - 1 << 2;
/*     */     
/*     */ 
/* 180 */     String[] raw = this.mRawAttrs;
/* 181 */     String thisName = raw[ix];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 186 */     if ((thisName == localName) || (thisName.equals(localName))) {
/* 187 */       String thisURI = raw[(ix + 1)];
/* 188 */       if (thisURI == nsURI) {
/* 189 */         return ix;
/*     */       }
/* 191 */       if (thisURI == null) {
/* 192 */         if (nsURI.length() == 0) {
/* 193 */           return ix;
/*     */         }
/* 195 */       } else if (thisURI.equals(nsURI)) {
/* 196 */         return ix;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 203 */     int i = this.mAttrHashSize; for (int len = this.mAttrSpillEnd; i < len; i += 2) {
/* 204 */       if (this.mAttrMap[i] == hash)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 210 */         ix = this.mAttrMap[(i + 1)] << 2;
/* 211 */         thisName = raw[ix];
/* 212 */         if ((thisName == localName) || (thisName.equals(localName))) {
/* 213 */           String thisURI = raw[(ix + 1)];
/* 214 */           if (thisURI == nsURI) {
/* 215 */             return ix;
/*     */           }
/* 217 */           if (thisURI == null) {
/* 218 */             if (nsURI.length() == 0) {
/* 219 */               return ix;
/*     */             }
/* 221 */           } else if (thisURI.equals(nsURI)) {
/* 222 */             return ix;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 227 */     return -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sr\ElemAttrs.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */