/*    */ package com.ctc.wstx.compat;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JdkFeatures
/*    */ {
/*    */   private static final JdkImpl sInstance;
/*    */   private static final int sVersion;
/*    */   
/*    */   static
/*    */   {
/* 20 */     int version = JdkInfo.getJDKVersion();
/* 21 */     sVersion = version;
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 27 */     JdkImpl x = null;
/* 28 */     StringBuffer sb = null;
/*    */     
/* 30 */     if ((version >= 104) || (version == 0)) {
/*    */       try {
/* 32 */         x = JdkInfo.constructImpl(14);
/*    */       } catch (Throwable t) {
/* 34 */         sb = new StringBuffer(200);
/* 35 */         sb.append("Failed to load 1.4 features: ");
/* 36 */         sb.append(t.toString());
/*    */       }
/*    */     }
/* 39 */     if ((x == null) && ((version >= 103) || (version == 0))) {
/*    */       try
/*    */       {
/* 42 */         x = JdkInfo.constructImpl(13);
/*    */       } catch (Throwable t) {
/* 44 */         sb.append("Failed to load 1.3 features: ");
/* 45 */         sb.append(t.toString());
/*    */       }
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 52 */     if (x == null) {
/*    */       try {
/* 54 */         x = JdkInfo.constructImpl(12);
/*    */       } catch (Throwable t) {
/* 56 */         sb.append("Failed to load 1.2 features: ");
/* 57 */         sb.append(t.toString());
/*    */       }
/*    */     }
/*    */     
/* 61 */     sInstance = x;
/*    */     
/*    */ 
/* 64 */     if (x == null) {
/* 65 */       System.err.println("Error: Could not load JDK-dependant features (estimated version id " + version + "), problems:\n" + sb + "\n");
/*    */     }
/*    */   }
/*    */   
/*    */   public static JdkImpl getInstance()
/*    */   {
/* 71 */     if (sInstance == null) {
/* 72 */       throw new Error("Internal error: No JDK implementation wrapper class available (version " + sVersion + "; need at least 0102 [== JDK 1.2.x]).");
/*    */     }
/* 74 */     return sInstance;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\compat\JdkFeatures.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */