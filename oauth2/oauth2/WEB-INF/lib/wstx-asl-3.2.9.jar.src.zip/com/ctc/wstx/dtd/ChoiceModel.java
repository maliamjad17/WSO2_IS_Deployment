/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ import java.util.BitSet;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChoiceModel
/*     */   extends ModelNode
/*     */ {
/*     */   final ModelNode[] mSubModels;
/*  16 */   boolean mNullable = false;
/*     */   
/*     */ 
/*     */ 
/*     */   BitSet mFirstPos;
/*     */   
/*     */ 
/*     */   BitSet mLastPos;
/*     */   
/*     */ 
/*     */ 
/*     */   protected ChoiceModel(ModelNode[] subModels)
/*     */   {
/*  29 */     this.mSubModels = subModels;
/*  30 */     boolean nullable = false;
/*  31 */     int i = 0; for (int len = subModels.length; i < len; i++) {
/*  32 */       if (subModels[i].isNullable()) {
/*  33 */         nullable = true;
/*  34 */         break;
/*     */       }
/*     */     }
/*  37 */     this.mNullable = nullable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  48 */     StringBuffer sb = new StringBuffer();
/*  49 */     for (int i = 0; i < this.mSubModels.length; i++) {
/*  50 */       if (i > 0) {
/*  51 */         sb.append(" | ");
/*     */       }
/*  53 */       sb.append(this.mSubModels[i].toString());
/*     */     }
/*  55 */     sb.append(')');
/*  56 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModelNode cloneModel()
/*     */   {
/*  65 */     int len = this.mSubModels.length;
/*  66 */     ModelNode[] newModels = new ModelNode[len];
/*  67 */     for (int i = 0; i < len; i++) {
/*  68 */       newModels[i] = this.mSubModels[i].cloneModel();
/*     */     }
/*  70 */     return new ChoiceModel(newModels);
/*     */   }
/*     */   
/*     */   public boolean isNullable() {
/*  74 */     return this.mNullable;
/*     */   }
/*     */   
/*     */ 
/*     */   public void indexTokens(List tokens)
/*     */   {
/*  80 */     int i = 0; for (int len = this.mSubModels.length; i < len; i++) {
/*  81 */       this.mSubModels[i].indexTokens(tokens);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addFirstPos(BitSet firstPos) {
/*  86 */     if (this.mFirstPos == null) {
/*  87 */       this.mFirstPos = new BitSet();
/*  88 */       int i = 0; for (int len = this.mSubModels.length; i < len; i++) {
/*  89 */         this.mSubModels[i].addFirstPos(this.mFirstPos);
/*     */       }
/*     */     }
/*  92 */     firstPos.or(this.mFirstPos);
/*     */   }
/*     */   
/*     */   public void addLastPos(BitSet lastPos) {
/*  96 */     if (this.mLastPos == null) {
/*  97 */       this.mLastPos = new BitSet();
/*  98 */       int i = 0; for (int len = this.mSubModels.length; i < len; i++) {
/*  99 */         this.mSubModels[i].addLastPos(this.mLastPos);
/*     */       }
/*     */     }
/* 102 */     lastPos.or(this.mLastPos);
/*     */   }
/*     */   
/*     */ 
/*     */   public void calcFollowPos(BitSet[] followPosSets)
/*     */   {
/* 108 */     int i = 0; for (int len = this.mSubModels.length; i < len; i++) {
/* 109 */       this.mSubModels[i].calcFollowPos(followPosSets);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\ChoiceModel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */