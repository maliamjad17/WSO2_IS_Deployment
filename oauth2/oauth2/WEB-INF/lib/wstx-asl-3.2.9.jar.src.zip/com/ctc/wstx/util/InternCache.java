/*    */ package com.ctc.wstx.util;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class InternCache
/*    */   extends HashMap
/*    */ {
/*    */   private static final int DEFAULT_SIZE = 64;
/* 24 */   private static final InternCache sInstance = new InternCache();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private InternCache()
/*    */   {
/* 32 */     super(64, 0.6666F);
/*    */   }
/*    */   
/*    */   public static InternCache getInstance() {
/* 36 */     return sInstance;
/*    */   }
/*    */   
/*    */   public synchronized String intern(String input) {
/* 40 */     String result = (String)get(input);
/* 41 */     if (result == null) {
/* 42 */       result = input.intern();
/* 43 */       put(result, result);
/*    */     }
/* 45 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\util\InternCache.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */