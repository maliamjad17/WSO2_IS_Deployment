/*     */ package com.ctc.wstx.stax;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import com.ctc.wstx.cfg.InputConfigFlags;
/*     */ import com.ctc.wstx.dtd.DTDId;
/*     */ import com.ctc.wstx.dtd.DTDSubset;
/*     */ import com.ctc.wstx.exc.WstxIOException;
/*     */ import com.ctc.wstx.io.BranchingReaderSource;
/*     */ import com.ctc.wstx.io.InputBootstrapper;
/*     */ import com.ctc.wstx.io.InputSourceFactory;
/*     */ import com.ctc.wstx.io.ReaderBootstrapper;
/*     */ import com.ctc.wstx.io.StreamBootstrapper;
/*     */ import com.ctc.wstx.sr.BasicStreamReader;
/*     */ import com.ctc.wstx.sr.ReaderCreator;
/*     */ import com.ctc.wstx.util.DefaultXmlSymbolTable;
/*     */ import com.ctc.wstx.util.SymbolTable;
/*     */ import com.ctc.wstx.util.URLUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URL;
/*     */ import javax.xml.stream.XMLReporter;
/*     */ import javax.xml.stream.XMLResolver;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MinimalInputFactory
/*     */   implements ReaderCreator, InputConfigFlags
/*     */ {
/*     */   protected final boolean mIsMinimal;
/*     */   protected final ReaderConfig mConfig;
/*  97 */   static final SymbolTable mRootSymbols = ;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/* 105 */     mRootSymbols.setInternStrings(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 112 */   SymbolTable mSymbols = mRootSymbols;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MinimalInputFactory()
/*     */   {
/* 121 */     this(true);
/*     */   }
/*     */   
/*     */   protected MinimalInputFactory(boolean minimal) {
/* 125 */     this.mConfig = ReaderConfig.createJ2MEDefaults();
/* 126 */     this.mIsMinimal = minimal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static MinimalInputFactory newMinimalInstance()
/*     */   {
/* 133 */     return new MinimalInputFactory();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DTDSubset findCachedDTD(DTDId id)
/*     */   {
/* 152 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void updateSymbolTable(SymbolTable t)
/*     */   {
/* 168 */     SymbolTable curr = mRootSymbols;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 173 */     if (t.isDirectChildOf(curr)) {
/* 174 */       this.mSymbols = t;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLStreamReader createXMLStreamReader(InputStream in)
/*     */     throws XMLStreamException
/*     */   {
/* 194 */     return createSR(null, StreamBootstrapper.getInstance(in, null, null));
/*     */   }
/*     */   
/*     */   public XMLStreamReader createXMLStreamReader(InputStream in, String enc)
/*     */     throws XMLStreamException
/*     */   {
/* 200 */     if ((enc == null) || (enc.length() == 0)) {
/* 201 */       return createXMLStreamReader(in);
/*     */     }
/*     */     try
/*     */     {
/* 205 */       return createSR(null, ReaderBootstrapper.getInstance(new InputStreamReader(in, enc), null, null, enc));
/*     */     }
/*     */     catch (UnsupportedEncodingException ex) {
/* 208 */       throw new XMLStreamException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public XMLStreamReader createXMLStreamReader(Reader r)
/*     */     throws XMLStreamException
/*     */   {
/* 215 */     return createXMLStreamReader(null, r);
/*     */   }
/*     */   
/*     */   public XMLStreamReader createXMLStreamReader(Source source)
/*     */     throws XMLStreamException
/*     */   {
/* 221 */     return createSR(source);
/*     */   }
/*     */   
/*     */   public XMLStreamReader createXMLStreamReader(String systemId, InputStream in)
/*     */     throws XMLStreamException
/*     */   {
/* 227 */     return createSR(systemId, StreamBootstrapper.getInstance(in, null, systemId));
/*     */   }
/*     */   
/*     */   public XMLStreamReader createXMLStreamReader(String systemId, Reader r)
/*     */     throws XMLStreamException
/*     */   {
/* 233 */     return createSR(systemId, ReaderBootstrapper.getInstance(r, null, systemId, null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getProperty(String name)
/*     */   {
/* 245 */     Object ob = this.mConfig.getProperty(name);
/*     */     
/* 247 */     if ((ob == null) && 
/* 248 */       (name.equals("javax.xml.stream.allocator"))) {
/* 249 */       throw new IllegalArgumentException("Event allocator not usable with J2ME subset.");
/*     */     }
/*     */     
/* 252 */     return ob;
/*     */   }
/*     */   
/*     */   public void setProperty(String propName, Object value)
/*     */   {
/* 257 */     if ((!this.mConfig.setProperty(propName, value)) && 
/* 258 */       ("javax.xml.stream.allocator".equals(propName))) {
/* 259 */       throw new IllegalArgumentException("Event allocator not usable with J2ME subset.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public XMLReporter getXMLReporter()
/*     */   {
/* 267 */     return this.mConfig.getXMLReporter();
/*     */   }
/*     */   
/*     */   public XMLResolver getXMLResolver() {
/* 271 */     return this.mConfig.getXMLResolver();
/*     */   }
/*     */   
/*     */   public boolean isPropertySupported(String name) {
/* 275 */     return this.mConfig.isPropertySupported(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXMLReporter(XMLReporter r)
/*     */   {
/* 285 */     this.mConfig.setXMLReporter(r);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXMLResolver(XMLResolver r)
/*     */   {
/* 295 */     this.mConfig.setXMLResolver(r);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReaderConfig getConfig()
/*     */   {
/* 305 */     return this.mConfig;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XMLStreamReader doCreateSR(BranchingReaderSource input, ReaderConfig cfg, InputBootstrapper bs)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 320 */     return BasicStreamReader.createBasicStreamReader(input, this, cfg, bs, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private XMLStreamReader createSR(String systemId, InputBootstrapper bs)
/*     */     throws XMLStreamException
/*     */   {
/* 334 */     URL src = this.mConfig.getBaseURL();
/*     */     
/*     */ 
/* 337 */     if ((src == null) && (systemId != null) && (systemId.length() > 0)) {
/*     */       try {
/* 339 */         src = URLUtil.urlFromSystemId(systemId);
/*     */       } catch (IOException ie) {
/* 341 */         throw new WstxIOException(ie);
/*     */       }
/*     */     }
/*     */     
/* 345 */     ReaderConfig cfg = this.mConfig.createNonShared(this.mSymbols.makeChild());
/*     */     Reader r;
/*     */     try {
/* 348 */       r = bs.bootstrapInput(cfg, true, 0);
/* 349 */       if (bs.declaredXml11()) {
/* 350 */         cfg.enableXml11(true);
/*     */       }
/*     */     } catch (IOException ie) {
/* 353 */       throw new WstxIOException(ie);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 359 */     BranchingReaderSource input = InputSourceFactory.constructDocumentSource(cfg, bs, null, systemId, src, r, false);
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 365 */       return doCreateSR(input, cfg, bs);
/*     */     } catch (IOException ie) {
/* 367 */       throw new XMLStreamException(ie);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private XMLStreamReader createSR(Source src)
/*     */     throws XMLStreamException
/*     */   {
/* 379 */     if ((src instanceof StreamSource)) {
/* 380 */       StreamSource ss = (StreamSource)src;
/*     */       
/*     */ 
/* 383 */       Reader r = ss.getReader();
/* 384 */       InputBootstrapper bs; InputBootstrapper bs; if (r == null) {
/* 385 */         InputStream in = ss.getInputStream();
/* 386 */         if (in == null) {
/* 387 */           throw new XMLStreamException("Can not create StAX reader for a StreamSource -- neither reader nor input stream was set.");
/*     */         }
/* 389 */         bs = StreamBootstrapper.getInstance(in, ss.getPublicId(), ss.getSystemId());
/*     */       }
/*     */       else {
/* 392 */         bs = ReaderBootstrapper.getInstance(r, ss.getPublicId(), ss.getSystemId(), null);
/*     */       }
/*     */       
/* 395 */       return createSR(src.getSystemId(), bs);
/*     */     }
/*     */     
/* 398 */     if ((src instanceof SAXSource))
/*     */     {
/*     */ 
/* 401 */       throw new XMLStreamException("Can not create a STaX reader for a SAXSource -- not (yet) implemented.");
/*     */     }
/*     */     
/* 404 */     if ((src instanceof DOMSource))
/*     */     {
/*     */ 
/* 407 */       throw new XMLStreamException("Can not create a STaX reader for a DOMSource -- not (yet) implemented.");
/*     */     }
/*     */     
/* 410 */     throw new IllegalArgumentException("Can not instantiate StAX reader for XML source type " + src.getClass() + " (unknown type)");
/*     */   }
/*     */   
/*     */   private void throwUnsupported(String msg) {
/* 414 */     throw new IllegalArgumentException("MinimalInputFactory has no DTD support: can not call " + msg);
/*     */   }
/*     */   
/*     */   public synchronized void addCachedDTD(DTDId id, DTDSubset extSubset) {}
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\stax\MinimalInputFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */