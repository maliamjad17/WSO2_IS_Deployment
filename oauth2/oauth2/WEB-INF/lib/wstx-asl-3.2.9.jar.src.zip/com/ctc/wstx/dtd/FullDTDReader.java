/*      */ package com.ctc.wstx.dtd;
/*      */ 
/*      */ import com.ctc.wstx.api.ReaderConfig;
/*      */ import com.ctc.wstx.cfg.ErrorConsts;
/*      */ import com.ctc.wstx.compat.JdkFeatures;
/*      */ import com.ctc.wstx.compat.JdkImpl;
/*      */ import com.ctc.wstx.ent.EntityDecl;
/*      */ import com.ctc.wstx.ent.IntEntity;
/*      */ import com.ctc.wstx.ent.NotationDecl;
/*      */ import com.ctc.wstx.ent.ParsedExtEntity;
/*      */ import com.ctc.wstx.ent.UnparsedExtEntity;
/*      */ import com.ctc.wstx.io.WstxInputData;
/*      */ import com.ctc.wstx.io.WstxInputSource;
/*      */ import com.ctc.wstx.util.InternCache;
/*      */ import com.ctc.wstx.util.SymbolTable;
/*      */ import com.ctc.wstx.util.TextBuffer;
/*      */ import com.ctc.wstx.util.WordResolver;
/*      */ import java.io.IOException;
/*      */ import java.io.Writer;
/*      */ import java.net.URL;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Set;
/*      */ import java.util.TreeSet;
/*      */ import javax.xml.stream.Location;
/*      */ import javax.xml.stream.XMLReporter;
/*      */ import javax.xml.stream.XMLStreamException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FullDTDReader
/*      */   extends MinimalDTDReader
/*      */ {
/*      */   static final boolean INTERN_SHARED_NAMES = false;
/*      */   static final int EXP_ENTITY_VALUE_LEN = 500;
/*      */   static final int EXP_ATTR_VALUE_LEN = 200;
/*   81 */   static final Boolean ENTITY_EXP_GE = Boolean.FALSE;
/*      */   
/*   83 */   static final Boolean ENTITY_EXP_PE = Boolean.TRUE;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final int mConfigFlags;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final boolean mCfgNormAttrs;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final boolean mCfgSupportDTDPP;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final boolean mCfgFullyValidating;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   HashMap mParamEntities;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final HashMap mPredefdPEs;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Set mRefdPEs;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   HashMap mGeneralEntities;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final HashMap mPredefdGEs;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Set mRefdGEs;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  182 */   boolean mUsesPredefdEntities = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   HashMap mNotations;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final HashMap mPredefdNotations;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  211 */   boolean mUsesPredefdNotations = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  223 */   HashMap mSharedNames = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   HashMap mElements;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  237 */   HashMap mSharedEnumValues = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  251 */   DefaultAttrValue mCurrAttrDefault = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  257 */   boolean mExpandingPE = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  264 */   TextBuffer mValueBuffer = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  270 */   char mSurrogateSecond = '\000';
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  283 */   int mIncludeCount = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  289 */   boolean mCheckForbiddenPEs = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   String mCurrDeclaration;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  307 */   boolean mAnyDTDppFeatures = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  312 */   String mDefaultNsURI = "";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  318 */   HashMap mNamespaces = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  327 */   DTDWriter mFlattenWriter = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   final DTDEventListener mEventListener;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  337 */   transient TextBuffer mTextBuffer = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private FullDTDReader(WstxInputSource input, ReaderConfig cfg, boolean constructFully, int xmlVersion)
/*      */   {
/*  351 */     this(input, cfg, false, null, constructFully, xmlVersion);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private FullDTDReader(WstxInputSource input, ReaderConfig cfg, DTDSubset intSubset, boolean constructFully, int xmlVersion)
/*      */   {
/*  361 */     this(input, cfg, true, intSubset, constructFully, xmlVersion);
/*      */     
/*      */ 
/*  364 */     input.initInputLocation(this, this.mCurrDepth);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private FullDTDReader(WstxInputSource input, ReaderConfig cfg, boolean isExt, DTDSubset intSubset, boolean constructFully, int xmlVersion)
/*      */   {
/*  374 */     super(input, cfg, isExt);
/*      */     
/*      */ 
/*      */ 
/*  378 */     this.mDocXmlVersion = xmlVersion;
/*  379 */     this.mXml11 = cfg.isXml11();
/*  380 */     int cfgFlags = cfg.getConfigFlags();
/*  381 */     this.mConfigFlags = cfgFlags;
/*  382 */     this.mCfgNormAttrs = ((cfgFlags & 0x4000) != 0);
/*  383 */     this.mCfgSupportDTDPP = ((cfgFlags & 0x80000) != 0);
/*  384 */     this.mCfgFullyValidating = constructFully;
/*      */     
/*  386 */     this.mUsesPredefdEntities = false;
/*  387 */     this.mParamEntities = null;
/*  388 */     this.mRefdPEs = null;
/*  389 */     this.mRefdGEs = null;
/*  390 */     this.mGeneralEntities = null;
/*      */     
/*      */ 
/*  393 */     HashMap pes = intSubset == null ? null : intSubset.getParameterEntityMap();
/*      */     
/*  395 */     if ((pes == null) || (pes.isEmpty())) {
/*  396 */       this.mPredefdPEs = null;
/*      */     } else {
/*  398 */       this.mPredefdPEs = pes;
/*      */     }
/*      */     
/*      */ 
/*  402 */     HashMap ges = intSubset == null ? null : intSubset.getGeneralEntityMap();
/*      */     
/*  404 */     if ((ges == null) || (ges.isEmpty())) {
/*  405 */       this.mPredefdGEs = null;
/*      */     } else {
/*  407 */       this.mPredefdGEs = ges;
/*      */     }
/*      */     
/*      */ 
/*  411 */     HashMap not = intSubset == null ? null : intSubset.getNotationMap();
/*      */     
/*  413 */     if ((not == null) || (not.isEmpty())) {
/*  414 */       this.mPredefdNotations = null;
/*      */     } else {
/*  416 */       this.mPredefdNotations = not;
/*      */     }
/*  418 */     this.mEventListener = this.mConfig.getDTDEventListener();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static DTDSubset readInternalSubset(WstxInputData srcData, WstxInputSource input, ReaderConfig cfg, boolean constructFully, int xmlVersion)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  431 */     FullDTDReader r = new FullDTDReader(input, cfg, constructFully, xmlVersion);
/*      */     
/*  433 */     r.copyBufferStateFrom(srcData);
/*      */     DTDSubset ss;
/*      */     try
/*      */     {
/*  437 */       ss = r.parseDTD();
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */ 
/*  443 */       srcData.copyBufferStateFrom(r);
/*      */     }
/*  445 */     return ss;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static DTDSubset readExternalSubset(WstxInputSource src, ReaderConfig cfg, DTDSubset intSubset, boolean constructFully, int xmlVersion)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  456 */     FullDTDReader r = new FullDTDReader(src, cfg, intSubset, constructFully, xmlVersion);
/*  457 */     return r.parseDTD();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static DTDSubset flattenExternalSubset(WstxInputSource src, Writer flattenWriter, boolean inclComments, boolean inclConditionals, boolean inclPEs)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  481 */     int configFlags = -1;
/*  482 */     ReaderConfig cfg = ReaderConfig.createFullDefaults();
/*      */     
/*  484 */     cfg = cfg.createNonShared(new SymbolTable());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  489 */     cfg.clearConfigFlag(8192);
/*  490 */     cfg.clearConfigFlag(16384);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  495 */     FullDTDReader r = new FullDTDReader(src, cfg, null, true, 0);
/*  496 */     r.setFlattenWriter(flattenWriter, inclComments, inclConditionals, inclPEs);
/*      */     
/*  498 */     DTDSubset ss = r.parseDTD();
/*  499 */     r.flushFlattenWriter();
/*  500 */     flattenWriter.flush();
/*  501 */     return ss;
/*      */   }
/*      */   
/*      */   private TextBuffer getTextBuffer()
/*      */   {
/*  506 */     if (this.mTextBuffer == null) {
/*  507 */       this.mTextBuffer = TextBuffer.createTemporaryBuffer(200);
/*  508 */       this.mTextBuffer.resetInitialized();
/*      */     } else {
/*  510 */       this.mTextBuffer.resetWithEmpty();
/*      */     }
/*  512 */     return this.mTextBuffer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFlattenWriter(Writer w, boolean inclComments, boolean inclConditionals, boolean inclPEs)
/*      */   {
/*  530 */     this.mFlattenWriter = new DTDWriter(w, inclComments, inclConditionals, inclPEs);
/*      */   }
/*      */   
/*      */ 
/*      */   private void flushFlattenWriter()
/*      */     throws IOException
/*      */   {
/*  537 */     this.mFlattenWriter.flush(this.mInputBuffer, this.mInputPtr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EntityDecl findEntity(String entName)
/*      */   {
/*  555 */     if (this.mPredefdGEs != null) {
/*  556 */       EntityDecl decl = (EntityDecl)this.mPredefdGEs.get(entName);
/*  557 */       if (decl != null) {
/*  558 */         return decl;
/*      */       }
/*      */     }
/*  561 */     return (EntityDecl)this.mGeneralEntities.get(entName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected DTDSubset parseDTD()
/*      */     throws IOException, XMLStreamException
/*      */   {
/*      */     for (;;)
/*      */     {
/*  574 */       this.mCheckForbiddenPEs = false;
/*  575 */       int i = getNextAfterWS();
/*  576 */       if (i < 0) {
/*  577 */         if (this.mIsExternal) {
/*      */           break;
/*      */         }
/*      */         
/*  581 */         throwUnexpectedEOF(" in internal DTD subset");
/*      */       }
/*  583 */       if (i == 37) {
/*  584 */         expandPE();
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*  591 */         this.mTokenInputTotal = (this.mCurrInputProcessed + this.mInputPtr);
/*  592 */         this.mTokenInputRow = this.mCurrInputRow;
/*  593 */         this.mTokenInputCol = (this.mInputPtr - this.mCurrInputRowStart);
/*      */         
/*  595 */         if (i == 60)
/*      */         {
/*  597 */           this.mCheckForbiddenPEs = ((!this.mIsExternal) && (this.mInput == this.mRootInput));
/*  598 */           if (this.mFlattenWriter == null) {
/*  599 */             parseDirective();
/*      */           } else {
/*  601 */             parseDirectiveFlattened();
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/*  606 */           if (i == 93) {
/*  607 */             if ((this.mIncludeCount == 0) && (!this.mIsExternal)) {
/*      */               break;
/*      */             }
/*  610 */             if (this.mIncludeCount > 0) {
/*  611 */               boolean suppress = (this.mFlattenWriter != null) && (!this.mFlattenWriter.includeConditionals());
/*      */               
/*  613 */               if (suppress) {
/*  614 */                 this.mFlattenWriter.flush(this.mInputBuffer, this.mInputPtr - 1);
/*  615 */                 this.mFlattenWriter.disableOutput();
/*      */               }
/*      */               
/*      */               try
/*      */               {
/*  620 */                 char c = dtdNextFromCurr();
/*  621 */                 if (c == ']') {
/*  622 */                   c = dtdNextFromCurr();
/*  623 */                   if (c == '>')
/*      */                   {
/*  625 */                     this.mIncludeCount -= 1;
/*      */                     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  631 */                     if (!suppress) continue;
/*  632 */                     this.mFlattenWriter.enableOutput(this.mInputPtr); continue;
/*      */                   }
/*      */                 }
/*  629 */                 throwDTDUnexpectedChar(c, "; expected ']]>' to close conditional include section");
/*      */               } finally {
/*  631 */                 if (suppress) {
/*  632 */                   this.mFlattenWriter.enableOutput(this.mInputPtr);
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*  639 */           if (this.mIsExternal) {
/*  640 */             throwDTDUnexpectedChar(i, "; expected a '<' to start a directive");
/*      */           }
/*  642 */           throwDTDUnexpectedChar(i, "; expected a '<' to start a directive, or \"]>\" to end internal subset");
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  648 */     if (this.mIncludeCount > 0) {
/*  649 */       String suffix = "" + this.mIncludeCount + " INCLUDE blocks";
/*  650 */       throwUnexpectedEOF(getErrorMsg() + "; expected closing marker for " + suffix);
/*      */     }
/*      */     
/*      */     DTDSubset ss;
/*      */     
/*      */     DTDSubset ss;
/*      */     
/*  657 */     if (this.mIsExternal)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  667 */       boolean cachable = (!this.mUsesPredefdEntities) && (!this.mUsesPredefdNotations);
/*  668 */       ss = DTDSubsetImpl.constructInstance(cachable, this.mGeneralEntities, this.mRefdGEs, null, this.mRefdPEs, this.mNotations, this.mElements, this.mCfgFullyValidating);
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  678 */       ss = DTDSubsetImpl.constructInstance(false, this.mGeneralEntities, null, this.mParamEntities, null, this.mNotations, this.mElements, this.mCfgFullyValidating);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  684 */     return ss;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parseDirective()
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  694 */     char c = dtdNextFromCurr();
/*  695 */     if (c == '?') {
/*  696 */       readPI();
/*  697 */       return;
/*      */     }
/*  699 */     if (c != '!') {
/*  700 */       throwDTDUnexpectedChar(c, "; expected '!' to start a directive");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  706 */     c = dtdNextFromCurr();
/*  707 */     if (c == '-') {
/*  708 */       c = dtdNextFromCurr();
/*  709 */       if (c != '-') {
/*  710 */         throwDTDUnexpectedChar(c, "; expected '-' for a comment");
/*      */       }
/*  712 */       if ((this.mEventListener != null) && (this.mEventListener.dtdReportComments())) {
/*  713 */         readComment(this.mEventListener);
/*      */       } else {
/*  715 */         skipComment();
/*      */       }
/*  717 */     } else if (c == '[') {
/*  718 */       checkInclusion();
/*  719 */     } else if ((c >= 'A') && (c <= 'Z')) {
/*  720 */       handleDeclaration(c);
/*      */     } else {
/*  722 */       throwDTDUnexpectedChar(c, ErrorConsts.ERR_DTD_MAINLEVEL_KEYWORD);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parseDirectiveFlattened()
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  741 */     this.mFlattenWriter.flush(this.mInputBuffer, this.mInputPtr - 1);
/*  742 */     this.mFlattenWriter.disableOutput();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  747 */     char c = dtdNextFromCurr();
/*  748 */     if (c == '?') {
/*  749 */       this.mFlattenWriter.enableOutput(this.mInputPtr);
/*  750 */       this.mFlattenWriter.output("<?");
/*  751 */       readPI();
/*      */       
/*  753 */       return;
/*      */     }
/*  755 */     if (c != '!') {
/*  756 */       throwDTDUnexpectedChar(c, ErrorConsts.ERR_DTD_MAINLEVEL_KEYWORD);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  761 */     c = dtdNextFromCurr();
/*  762 */     if (c == '-') {
/*  763 */       c = dtdNextFromCurr();
/*  764 */       if (c != '-') {
/*  765 */         throwDTDUnexpectedChar(c, "; expected '-' for a comment");
/*      */       }
/*  767 */       boolean comm = this.mFlattenWriter.includeComments();
/*  768 */       if (comm) {
/*  769 */         this.mFlattenWriter.enableOutput(this.mInputPtr);
/*  770 */         this.mFlattenWriter.output("<!--");
/*      */       }
/*      */       try
/*      */       {
/*  774 */         skipComment();
/*      */       } finally {
/*  776 */         if (!comm) {
/*  777 */           this.mFlattenWriter.enableOutput(this.mInputPtr);
/*      */         }
/*      */       }
/*      */     }
/*  781 */     else if (c == '[') {
/*  782 */       boolean cond = this.mFlattenWriter.includeConditionals();
/*  783 */       if (cond) {
/*  784 */         this.mFlattenWriter.enableOutput(this.mInputPtr);
/*  785 */         this.mFlattenWriter.output("<![");
/*      */       }
/*      */       try {
/*  788 */         checkInclusion();
/*      */       } finally {
/*  790 */         if (!cond) {
/*  791 */           this.mFlattenWriter.enableOutput(this.mInputPtr);
/*      */         }
/*      */         
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  798 */       boolean filterPEs = (c == 'E') && (!this.mFlattenWriter.includeParamEntities());
/*  799 */       if (filterPEs) {
/*  800 */         handleSuppressedDeclaration();
/*  801 */       } else if ((c >= 'A') && (c <= 'Z')) {
/*  802 */         this.mFlattenWriter.enableOutput(this.mInputPtr);
/*  803 */         this.mFlattenWriter.output("<!");
/*  804 */         this.mFlattenWriter.output(c);
/*  805 */         handleDeclaration(c);
/*      */       } else {
/*  807 */         throwDTDUnexpectedChar(c, ErrorConsts.ERR_DTD_MAINLEVEL_KEYWORD);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void initInputSource(WstxInputSource newInput, boolean isExt)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  822 */     if (this.mFlattenWriter != null)
/*      */     {
/*  824 */       this.mFlattenWriter.flush(this.mInputBuffer, this.mInputPtr);
/*  825 */       this.mFlattenWriter.disableOutput();
/*      */       
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/*  831 */         super.initInputSource(newInput, isExt);
/*      */       }
/*      */       finally {
/*  834 */         this.mFlattenWriter.enableOutput(this.mInputPtr);
/*      */       }
/*      */     } else {
/*  837 */       super.initInputSource(newInput, isExt);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean loadMore()
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  850 */     WstxInputSource input = this.mInput;
/*      */     
/*      */ 
/*  853 */     if (this.mFlattenWriter != null)
/*      */     {
/*      */ 
/*      */ 
/*  857 */       this.mFlattenWriter.flush(this.mInputBuffer, this.mInputLen);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     do
/*      */     {
/*  865 */       this.mCurrInputProcessed += this.mInputLen;
/*  866 */       this.mCurrInputRowStart -= this.mInputLen;
/*  867 */       int count = input.readInto(this);
/*  868 */       if (count > 0) {
/*  869 */         if (this.mFlattenWriter != null) {
/*  870 */           this.mFlattenWriter.setFlattenStart(this.mInputPtr);
/*      */         }
/*  872 */         return true;
/*      */       }
/*      */       
/*  875 */       input.close();
/*  876 */       if (input == this.mRootInput) {
/*  877 */         return false;
/*      */       }
/*  879 */       WstxInputSource parent = input.getParent();
/*  880 */       if (parent == null) {
/*  881 */         throwNullParent(input);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  886 */       if (this.mCurrDepth != input.getScopeId()) {
/*  887 */         handleIncompleteEntityProblem(input);
/*      */       }
/*      */       
/*  890 */       this.mInput = (input = parent);
/*  891 */       input.restoreContext(this);
/*  892 */       if (this.mFlattenWriter != null) {
/*  893 */         this.mFlattenWriter.setFlattenStart(this.mInputPtr);
/*      */       }
/*  895 */       this.mInputTopDepth = input.getScopeId();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  900 */       if (this.mCfgNormalizeLFs != this.mConfig.willNormalizeLFs()) {
/*  901 */         this.mCfgNormalizeLFs = (!input.fromInternalEntity());
/*      */       }
/*      */       
/*  904 */     } while (this.mInputPtr >= this.mInputLen);
/*      */     
/*  906 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */   protected boolean loadMoreFromCurrent()
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  913 */     if (this.mFlattenWriter != null) {
/*  914 */       this.mFlattenWriter.flush(this.mInputBuffer, this.mInputLen);
/*      */     }
/*      */     
/*      */ 
/*  918 */     this.mCurrInputProcessed += this.mInputLen;
/*  919 */     this.mCurrInputRowStart -= this.mInputLen;
/*  920 */     int count = this.mInput.readInto(this);
/*  921 */     if (count > 0) {
/*  922 */       if (this.mFlattenWriter != null) {
/*  923 */         this.mFlattenWriter.setFlattenStart(this.mInputPtr);
/*      */       }
/*  925 */       return true;
/*      */     }
/*  927 */     return false;
/*      */   }
/*      */   
/*      */   protected boolean ensureInput(int minAmount)
/*      */     throws IOException
/*      */   {
/*  933 */     int currAmount = this.mInputLen - this.mInputPtr;
/*  934 */     if (currAmount >= minAmount) {
/*  935 */       return true;
/*      */     }
/*      */     
/*  938 */     if (this.mFlattenWriter != null) {
/*  939 */       this.mFlattenWriter.flush(this.mInputBuffer, this.mInputLen);
/*      */     }
/*  941 */     if (this.mInput.readMore(this, minAmount)) {
/*  942 */       if (this.mFlattenWriter != null)
/*      */       {
/*  944 */         this.mFlattenWriter.setFlattenStart(currAmount);
/*      */       }
/*  946 */       return true;
/*      */     }
/*  948 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void loadMoreScoped(WstxInputSource currScope, String entityName, Location loc)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  961 */     boolean check = this.mInput == currScope;
/*  962 */     loadMore(getErrorMsg());
/*      */     
/*  964 */     if ((check) && (this.mInput != currScope)) {
/*  965 */       reportWFCViolation("Unterminated entity value for entity '" + entityName + "' (definition started at " + loc + ")");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private char dtdNextIfAvailable()
/*      */     throws IOException, XMLStreamException
/*      */   {
/*      */     char c;
/*      */     
/*      */ 
/*      */     char c;
/*      */     
/*  979 */     if (this.mInputPtr < this.mInputLen) {
/*  980 */       c = this.mInputBuffer[(this.mInputPtr++)];
/*      */     } else {
/*  982 */       int i = peekNext();
/*  983 */       if (i < 0) {
/*  984 */         return '\000';
/*      */       }
/*  986 */       this.mInputPtr += 1;
/*  987 */       c = (char)i;
/*      */     }
/*  989 */     if (c == 0) {
/*  990 */       throwNullChar();
/*      */     }
/*  992 */     return c;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private char getNextExpanded()
/*      */     throws IOException, XMLStreamException
/*      */   {
/*      */     for (;;)
/*      */     {
/* 1004 */       char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextChar(getErrorMsg());
/*      */       
/* 1006 */       if (c != '%') {
/* 1007 */         return c;
/*      */       }
/* 1009 */       expandPE();
/*      */     }
/*      */   }
/*      */   
/*      */   private char skipDtdWs(boolean handlePEs) throws IOException, XMLStreamException
/*      */   {
/*      */     for (;;)
/*      */     {
/* 1017 */       char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextChar(getErrorMsg());
/*      */       
/* 1019 */       if (c > ' ') {
/* 1020 */         if ((c == '%') && (handlePEs)) {
/* 1021 */           expandPE();
/*      */         }
/*      */         else {
/* 1024 */           return c;
/*      */         }
/* 1026 */       } else if ((c == '\n') || (c == '\r')) {
/* 1027 */         skipCRLF(c);
/* 1028 */       } else if ((c != ' ') && (c != '\t')) {
/* 1029 */         throwInvalidSpace(c);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private char skipObligatoryDtdWs()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1051 */     int i = peekNext();
/*      */     
/*      */     char c;
/* 1054 */     if (i == -1) {
/* 1055 */       char c = getNextChar(getErrorMsg());
/*      */       
/* 1057 */       if ((c > ' ') && (c != '%')) {
/* 1058 */         return c;
/*      */       }
/*      */     } else {
/* 1061 */       c = this.mInputBuffer[(this.mInputPtr++)];
/* 1062 */       if ((c > ' ') && (c != '%')) {
/* 1063 */         throwDTDUnexpectedChar(c, "; expected a separating white space");
/*      */       }
/*      */     }
/*      */     
/*      */     for (;;)
/*      */     {
/* 1069 */       if (c == '%') {
/* 1070 */         expandPE();
/* 1071 */       } else { if (c > ' ') {
/*      */           break;
/*      */         }
/* 1074 */         if ((c == '\n') || (c == '\r')) {
/* 1075 */           skipCRLF(c);
/* 1076 */         } else if ((c != ' ') && (c != '\t')) {
/* 1077 */           throwInvalidSpace(c);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1084 */       c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextChar(getErrorMsg());
/*      */     }
/*      */     
/* 1087 */     return c;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void expandPE()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1101 */     if (this.mCheckForbiddenPEs)
/*      */     {
/*      */ 
/*      */ 
/* 1105 */       throwForbiddenPE();
/*      */     }
/*      */     char c;
/*      */     String id;
/* 1109 */     if (this.mFlattenWriter != null)
/*      */     {
/* 1111 */       this.mFlattenWriter.flush(this.mInputBuffer, this.mInputPtr - 1);
/* 1112 */       this.mFlattenWriter.disableOutput();
/* 1113 */       char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : dtdNextFromCurr();
/*      */       
/* 1115 */       String id = readDTDName(c);
/*      */       try {
/* 1117 */         c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : dtdNextFromCurr();
/*      */       }
/*      */       finally
/*      */       {
/* 1121 */         this.mFlattenWriter.enableOutput(this.mInputPtr);
/*      */       }
/*      */     } else {
/* 1124 */       c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : dtdNextFromCurr();
/*      */       
/* 1126 */       id = readDTDName(c);
/* 1127 */       c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : dtdNextFromCurr();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1132 */     if (c != ';') {
/* 1133 */       throwDTDUnexpectedChar(c, "; expected ';' to end parameter entity name");
/*      */     }
/* 1135 */     this.mExpandingPE = true;
/* 1136 */     expandEntity(id, true, ENTITY_EXP_PE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String checkDTDKeyword(String exp)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1154 */     int i = 0;
/* 1155 */     int len = exp.length();
/* 1156 */     char c = ' ';
/* 1158 */     for (; 
/* 1158 */         i < len; i++) {
/* 1159 */       if (this.mInputPtr < this.mInputLen) {
/* 1160 */         c = this.mInputBuffer[(this.mInputPtr++)];
/*      */       } else {
/* 1162 */         c = dtdNextIfAvailable();
/* 1163 */         if (c == 0) {
/* 1164 */           return exp.substring(0, i);
/*      */         }
/*      */       }
/* 1167 */       if (c != exp.charAt(i)) {
/*      */         break;
/*      */       }
/*      */     }
/*      */     
/* 1172 */     if (i == len)
/*      */     {
/* 1174 */       c = dtdNextIfAvailable();
/* 1175 */       if (c == 0) {
/* 1176 */         return null;
/*      */       }
/* 1178 */       if (!isNameChar(c)) {
/* 1179 */         this.mInputPtr -= 1;
/* 1180 */         return null;
/*      */       }
/*      */     }
/* 1183 */     StringBuffer sb = new StringBuffer(exp.substring(0, i));
/* 1184 */     sb.append(c);
/*      */     for (;;) {
/* 1186 */       c = dtdNextIfAvailable();
/* 1187 */       if (c == 0) {
/*      */         break;
/*      */       }
/* 1190 */       if ((!isNameChar(c)) && (c != ':')) {
/* 1191 */         this.mInputPtr -= 1;
/* 1192 */         break;
/*      */       }
/* 1194 */       sb.append(c);
/*      */     }
/* 1196 */     return sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String readDTDKeyword(String prefix)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1210 */     StringBuffer sb = new StringBuffer(prefix);
/*      */     for (;;) {
/*      */       char c;
/*      */       char c;
/* 1214 */       if (this.mInputPtr < this.mInputLen) {
/* 1215 */         c = this.mInputBuffer[(this.mInputPtr++)];
/*      */       }
/*      */       else {
/* 1218 */         c = dtdNextIfAvailable();
/* 1219 */         if (c == 0) {
/*      */           break;
/*      */         }
/*      */       }
/* 1223 */       if ((!isNameChar(c)) && (c != ':')) {
/* 1224 */         this.mInputPtr -= 1;
/* 1225 */         break;
/*      */       }
/* 1227 */       sb.append(c);
/*      */     }
/* 1229 */     return sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean checkPublicSystemKeyword(char c)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*      */     String errId;
/*      */     
/*      */ 
/* 1241 */     if (c == 'P') {
/* 1242 */       String errId = checkDTDKeyword("UBLIC");
/* 1243 */       if (errId == null) {
/* 1244 */         return true;
/*      */       }
/* 1246 */       errId = "P" + errId;
/* 1247 */     } else if (c == 'S') {
/* 1248 */       String errId = checkDTDKeyword("YSTEM");
/* 1249 */       if (errId == null) {
/* 1250 */         return false;
/*      */       }
/* 1252 */       errId = "S" + errId;
/*      */     } else {
/* 1254 */       if (!isNameStartChar(c)) {
/* 1255 */         throwDTDUnexpectedChar(c, "; expected 'PUBLIC' or 'SYSTEM' keyword");
/*      */       }
/* 1257 */       errId = readDTDKeyword(String.valueOf(c));
/*      */     }
/*      */     
/* 1260 */     reportWFCViolation("Unrecognized keyword '" + errId + "'; expected 'PUBLIC' or 'SYSTEM'");
/* 1261 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   private String readDTDName(char c)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1268 */     if (!isNameStartChar(c)) {
/* 1269 */       throwDTDUnexpectedChar(c, "; expected an identifier");
/*      */     }
/* 1271 */     return parseFullName(c);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String readDTDLocalName(char c, boolean checkChar)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1280 */     if ((checkChar) && (!isNameStartChar(c))) {
/* 1281 */       throwDTDUnexpectedChar(c, "; expected an identifier");
/*      */     }
/* 1283 */     return parseLocalName(c);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String readDTDNmtoken(char c)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1293 */     char[] outBuf = getNameBuffer(64);
/* 1294 */     int outLen = outBuf.length;
/* 1295 */     int outPtr = 0;
/*      */     
/*      */ 
/*      */ 
/*      */     for (;;)
/*      */     {
/* 1301 */       if ((!isNameChar(c)) && (c != ':'))
/*      */       {
/* 1303 */         if (outPtr == 0) {
/* 1304 */           throwDTDUnexpectedChar(c, "; expected a NMTOKEN character to start a NMTOKEN");
/*      */         }
/* 1306 */         this.mInputPtr -= 1;
/*      */       }
/*      */       else {
/* 1309 */         if (outPtr >= outLen) {
/* 1310 */           outBuf = expandBy50Pct(outBuf);
/* 1311 */           outLen = outBuf.length;
/*      */         }
/* 1313 */         outBuf[(outPtr++)] = c;
/* 1314 */         if (this.mInputPtr < this.mInputLen) {
/* 1315 */           c = this.mInputBuffer[(this.mInputPtr++)];
/*      */         } else {
/* 1317 */           c = dtdNextIfAvailable();
/* 1318 */           if (c == 0) {
/*      */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1327 */     return new String(outBuf, 0, outPtr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private NameKey readDTDQName(char firstChar)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*      */     String localName;
/*      */     
/*      */ 
/*      */     String localName;
/*      */     
/*      */ 
/*      */     String prefix;
/*      */     
/*      */ 
/* 1345 */     if (!this.mCfgNsEnabled) {
/* 1346 */       String prefix = null;
/* 1347 */       localName = parseFullName(firstChar);
/*      */     } else {
/* 1349 */       localName = parseLocalName(firstChar);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1354 */       char c = dtdNextIfAvailable();
/* 1355 */       String prefix; if (c == 0)
/*      */       {
/* 1357 */         prefix = null;
/*      */       }
/* 1359 */       else if (c == ':') {
/* 1360 */         String prefix = localName;
/* 1361 */         c = dtdNextFromCurr();
/* 1362 */         localName = parseLocalName(c);
/*      */       } else {
/* 1364 */         prefix = null;
/* 1365 */         this.mInputPtr -= 1;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1370 */     return findSharedName(prefix, localName);
/*      */   }
/*      */   
/*      */   private char readArity()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1376 */     char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextChar(getErrorMsg());
/*      */     
/* 1378 */     if ((c == '?') || (c == '*') || (c == '+')) {
/* 1379 */       return c;
/*      */     }
/*      */     
/* 1382 */     this.mInputPtr -= 1;
/*      */     
/*      */ 
/* 1385 */     return ' ';
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private char[] parseEntityValue(String id, Location loc, char quoteChar)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1401 */     WstxInputSource currScope = this.mInput;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1408 */     boolean allowPEs = (this.mIsExternal) || (this.mInput != this.mRootInput);
/*      */     
/* 1410 */     TextBuffer tb = this.mValueBuffer;
/* 1411 */     if (tb == null) {
/* 1412 */       tb = TextBuffer.createTemporaryBuffer(500);
/*      */     }
/* 1414 */     tb.resetInitialized();
/*      */     
/* 1416 */     char[] outBuf = tb.getCurrentSegment();
/* 1417 */     int outPtr = tb.getCurrentSegmentSize();
/*      */     for (;;)
/*      */     {
/* 1420 */       if (this.mInputPtr >= this.mInputLen) {
/* 1421 */         loadMoreScoped(currScope, id, loc);
/*      */       }
/* 1423 */       char c = this.mInputBuffer[(this.mInputPtr++)];
/*      */       
/*      */ 
/* 1426 */       if (c < '?')
/*      */       {
/* 1428 */         if (c == quoteChar)
/*      */         {
/* 1430 */           if (this.mInput == currScope) {
/*      */             break;
/*      */           }
/* 1433 */         } else if (c == '&')
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1439 */           char d = resolveCharOnlyEntity(false);
/*      */           
/* 1441 */           if (d != 0) {
/* 1442 */             c = d;
/* 1443 */             if (this.mSurrogateSecond != 0)
/*      */             {
/* 1445 */               if (outPtr >= outBuf.length) {
/* 1446 */                 outBuf = tb.finishCurrentSegment();
/* 1447 */                 outPtr = 0;
/*      */               }
/* 1449 */               outBuf[(outPtr++)] = c;
/* 1450 */               c = this.mSurrogateSecond;
/* 1451 */               this.mSurrogateSecond = '\000';
/*      */             }
/*      */             
/*      */           }
/*      */           else
/*      */           {
/* 1457 */             boolean first = true;
/*      */             for (;;) {
/* 1459 */               if (outPtr >= outBuf.length) {
/* 1460 */                 outBuf = tb.finishCurrentSegment();
/* 1461 */                 outPtr = 0;
/*      */               }
/* 1463 */               outBuf[(outPtr++)] = c;
/* 1464 */               if (this.mInputPtr >= this.mInputLen) {
/* 1465 */                 loadMoreScoped(currScope, id, loc);
/*      */               }
/* 1467 */               c = this.mInputBuffer[(this.mInputPtr++)];
/* 1468 */               if (c == ';') {
/*      */                 break;
/*      */               }
/* 1471 */               if (first) {
/* 1472 */                 first = false;
/* 1473 */                 if (!isNameStartChar(c)) {}
/*      */               }
/*      */               else
/*      */               {
/* 1477 */                 if (isNameChar(c)) {
/*      */                   continue;
/*      */                 }
/*      */               }
/* 1481 */               if ((c != ':') || (this.mCfgNsEnabled))
/*      */               {
/*      */ 
/* 1484 */                 if (first) {
/* 1485 */                   throwDTDUnexpectedChar(c, "; expected entity name after '&'");
/*      */                 }
/* 1487 */                 throwDTDUnexpectedChar(c, "; expected semi-colon after entity name");
/*      */               }
/*      */             }
/*      */           }
/*      */         } else {
/* 1492 */           if (c == '%') {
/* 1493 */             expandPE();
/*      */             
/* 1495 */             continue; }
/* 1496 */           if (c < ' ') {
/* 1497 */             if (c == '\n') {
/* 1498 */               markLF();
/* 1499 */             } else if (c == '\r') {
/* 1500 */               if (skipCRLF(c)) {
/* 1501 */                 if (!this.mCfgNormalizeLFs)
/*      */                 {
/* 1503 */                   if (outPtr >= outBuf.length) {
/* 1504 */                     outBuf = tb.finishCurrentSegment();
/* 1505 */                     outPtr = 0;
/*      */                   }
/* 1507 */                   outBuf[(outPtr++)] = c;
/*      */                 }
/* 1509 */                 c = '\n';
/*      */               }
/* 1511 */               else if (this.mCfgNormalizeLFs) {
/* 1512 */                 c = '\n';
/*      */               }
/*      */             }
/* 1515 */             else if (c != '\t') {
/* 1516 */               throwInvalidSpace(c);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1521 */       if (outPtr >= outBuf.length) {
/* 1522 */         outBuf = tb.finishCurrentSegment();
/* 1523 */         outPtr = 0;
/*      */       }
/*      */       
/* 1526 */       outBuf[(outPtr++)] = c;
/*      */     }
/* 1528 */     tb.setCurrentLength(outPtr);
/*      */     
/*      */ 
/* 1531 */     char c = skipDtdWs(true);
/* 1532 */     if (c != '>') {
/* 1533 */       throwDTDUnexpectedChar(c, "; expected closing '>' after ENTITY declaration");
/*      */     }
/* 1535 */     char[] result = tb.contentsAsArray();
/* 1536 */     this.mValueBuffer = tb;
/*      */     
/* 1538 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void parseAttrDefaultValue(DefaultAttrValue defVal, char quoteChar, NameKey attrName, Location loc, boolean gotFixed)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1554 */     if ((quoteChar != '"') && (quoteChar != '\'')) {
/* 1555 */       String msg = "; expected a single or double quote to enclose the default value";
/* 1556 */       if (!gotFixed) {
/* 1557 */         msg = msg + ", or one of keywords (#REQUIRED, #IMPLIED, #FIXED)";
/*      */       }
/* 1559 */       msg = msg + " (for attribute '" + attrName + "')";
/* 1560 */       throwDTDUnexpectedChar(quoteChar, msg);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1568 */     WstxInputSource currScope = this.mInput;
/*      */     
/* 1570 */     TextBuffer tb = this.mValueBuffer;
/* 1571 */     if (tb == null) {
/* 1572 */       tb = TextBuffer.createTemporaryBuffer(500);
/*      */     }
/* 1574 */     tb.resetInitialized();
/*      */     
/* 1576 */     int outPtr = 0;
/* 1577 */     char[] outBuf = tb.getCurrentSegment();
/* 1578 */     int outLen = outBuf.length;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     for (;;)
/*      */     {
/* 1586 */       if (this.mInputPtr >= this.mInputLen) {
/* 1587 */         boolean check = this.mInput == currScope;
/* 1588 */         loadMore(getErrorMsg());
/*      */         
/* 1590 */         if ((check) && (this.mInput != currScope)) {
/* 1591 */           reportWFCViolation("Unterminated attribute default value for attribute '" + attrName + "' (definition started at " + loc + ")");
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1596 */       char c = this.mInputBuffer[(this.mInputPtr++)];
/*      */       
/*      */ 
/* 1599 */       if (c < '?') {
/* 1600 */         if (c <= ' ') {
/* 1601 */           if (c == '\n') {
/* 1602 */             markLF();
/* 1603 */           } else if (c == '\r') {
/* 1604 */             c = getNextChar(" in attribute default value");
/* 1605 */             if (c != '\n') {
/* 1606 */               this.mInputPtr -= 1;
/* 1607 */               c = this.mCfgNormalizeLFs ? '\n' : '\r';
/*      */ 
/*      */             }
/* 1610 */             else if (!this.mCfgNormalizeLFs)
/*      */             {
/* 1612 */               if (!this.mCfgNormAttrs) {
/* 1613 */                 if (outPtr >= outLen) {
/* 1614 */                   outBuf = tb.finishCurrentSegment();
/* 1615 */                   outPtr = 0;
/* 1616 */                   outLen = outBuf.length;
/*      */                 }
/* 1618 */                 outBuf[(outPtr++)] = '\r';
/*      */               }
/*      */             }
/*      */             
/*      */ 
/* 1623 */             markLF();
/* 1624 */           } else if ((c != ' ') && (c != '\t')) {
/* 1625 */             throwInvalidSpace(c);
/*      */           }
/* 1627 */           if (this.mCfgNormAttrs) {
/* 1628 */             c = ' ';
/*      */           }
/* 1630 */         } else if (c == quoteChar)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 1635 */           if (this.mInput == currScope) {
/*      */             break;
/*      */           }
/* 1638 */         } else if (c == '&')
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 1643 */           if (inputInBuffer() >= 3) {
/* 1644 */             c = resolveSimpleEntity(true);
/*      */           } else {
/* 1646 */             c = resolveCharOnlyEntity(true);
/*      */           }
/*      */           
/* 1649 */           if (c == 0) {
/* 1650 */             c = getNextChar(" in entity reference");
/* 1651 */             String id = parseEntityName(c);
/*      */             try {
/* 1653 */               this.mCurrAttrDefault = defVal;
/* 1654 */               this.mExpandingPE = false;
/* 1655 */               expandEntity(id, false, ENTITY_EXP_GE);
/*      */             } finally {
/* 1657 */               this.mCurrAttrDefault = null;
/*      */             }
/*      */             
/* 1660 */             continue;
/*      */           }
/* 1662 */           if (this.mSurrogateSecond != 0) {
/* 1663 */             if (outPtr >= outLen) {
/* 1664 */               outBuf = tb.finishCurrentSegment();
/* 1665 */               outPtr = 0;
/* 1666 */               outLen = outBuf.length;
/*      */             }
/* 1668 */             outBuf[(outPtr++)] = c;
/* 1669 */             c = this.mSurrogateSecond;
/* 1670 */             this.mSurrogateSecond = '\000';
/*      */           }
/* 1672 */         } else if (c == '<') {
/* 1673 */           throwDTDUnexpectedChar(c, " in attribute default value");
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1678 */       if (outPtr >= outLen) {
/* 1679 */         outBuf = tb.finishCurrentSegment();
/* 1680 */         outPtr = 0;
/* 1681 */         outLen = outBuf.length;
/*      */       }
/* 1683 */       outBuf[(outPtr++)] = c;
/*      */     }
/*      */     
/* 1686 */     tb.setCurrentLength(outPtr);
/* 1687 */     defVal.setValue(tb.contentsAsString());
/* 1688 */     this.mValueBuffer = tb;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void readPI()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1698 */     String target = parseFullName();
/* 1699 */     if (target.length() == 0) {
/* 1700 */       reportWFCViolation(ErrorConsts.ERR_WF_PI_MISSING_TARGET);
/*      */     }
/* 1702 */     if (target.equalsIgnoreCase("xml")) {
/* 1703 */       reportWFCViolation(ErrorConsts.ERR_WF_PI_XML_TARGET, target);
/*      */     }
/*      */     
/* 1706 */     char c = dtdNextFromCurr();
/*      */     
/* 1708 */     if (!isSpaceChar(c)) {
/* 1709 */       if ((c != '?') || (dtdNextFromCurr() != '>')) {
/* 1710 */         throwUnexpectedChar(c, ErrorConsts.ERR_WF_PI_XML_MISSING_SPACE);
/*      */       }
/* 1712 */       if (this.mEventListener != null)
/* 1713 */         this.mEventListener.dtdProcessingInstruction(target, "");
/*      */     } else {
/* 1715 */       if (this.mEventListener == null)
/*      */       {
/*      */         for (;;)
/*      */         {
/*      */ 
/* 1720 */           c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : dtdNextFromCurr();
/*      */           
/* 1722 */           if (c == '?') {
/*      */             do {
/* 1724 */               c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : dtdNextFromCurr();
/*      */             }
/* 1726 */             while (c == '?');
/* 1727 */             if (c == '>') {
/*      */               break;
/*      */             }
/*      */           }
/* 1731 */           if (c < ' ') {
/* 1732 */             if ((c == '\n') || (c == '\r')) {
/* 1733 */               skipCRLF(c);
/* 1734 */             } else if (c != '\t') {
/* 1735 */               throwInvalidSpace(c);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1742 */       while (c <= ' ') {
/* 1743 */         if ((c == '\n') || (c == '\r')) {
/* 1744 */           skipCRLF(c);
/* 1745 */         } else if ((c != '\t') && (c != ' ')) {
/* 1746 */           throwInvalidSpace(c);
/*      */         }
/* 1748 */         c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : dtdNextFromCurr();
/*      */       }
/*      */       
/*      */ 
/* 1752 */       TextBuffer tb = getTextBuffer();
/* 1753 */       char[] outBuf = tb.getCurrentSegment();
/* 1754 */       int outPtr = 0;
/*      */       
/*      */       for (;;)
/*      */       {
/* 1758 */         if (c == '?') {
/* 1759 */           int count = 0;
/*      */           for (;;) {
/* 1761 */             c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : dtdNextFromCurr();
/*      */             
/* 1763 */             if (c != '?') {
/*      */               break;
/*      */             }
/* 1766 */             if (outPtr >= outBuf.length) {
/* 1767 */               outBuf = tb.finishCurrentSegment();
/* 1768 */               outPtr = 0;
/*      */             }
/* 1770 */             outBuf[(outPtr++)] = c;
/*      */           }
/* 1772 */           if (c == '>') {
/*      */             break;
/*      */           }
/*      */           
/* 1776 */           this.mInputPtr -= 1;
/* 1777 */           c = '?';
/* 1778 */         } else if (c < ' ') {
/* 1779 */           if ((c == '\n') || (c == '\r')) {
/* 1780 */             skipCRLF(c);
/* 1781 */             c = '\n';
/* 1782 */           } else if (c != '\t') {
/* 1783 */             throwInvalidSpace(c);
/*      */           }
/*      */         }
/*      */         
/* 1787 */         if (outPtr >= outBuf.length) {
/* 1788 */           outBuf = tb.finishCurrentSegment();
/* 1789 */           outPtr = 0;
/*      */         }
/*      */         
/* 1792 */         outBuf[(outPtr++)] = c;
/* 1793 */         c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : dtdNextFromCurr();
/*      */       }
/*      */       
/* 1796 */       tb.setCurrentLength(outPtr);
/* 1797 */       String data = tb.contentsAsString();
/* 1798 */       this.mEventListener.dtdProcessingInstruction(target, data);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void readComment(DTDEventListener l)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1809 */     TextBuffer tb = getTextBuffer();
/* 1810 */     char[] outBuf = tb.getCurrentSegment();
/* 1811 */     int outPtr = 0;
/*      */     
/*      */     for (;;)
/*      */     {
/* 1815 */       char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : dtdNextFromCurr();
/*      */       
/* 1817 */       if (c < ' ') {
/* 1818 */         if ((c == '\n') || (c == '\r')) {
/* 1819 */           skipCRLF(c);
/* 1820 */           c = '\n';
/* 1821 */         } else if (c != '\t') {
/* 1822 */           throwInvalidSpace(c);
/*      */         }
/* 1824 */       } else if (c == '-') {
/* 1825 */         c = dtdNextFromCurr();
/* 1826 */         if (c == '-')
/*      */         {
/* 1828 */           c = dtdNextFromCurr();
/* 1829 */           if (c == '>') break;
/* 1830 */           throwParseError(ErrorConsts.ERR_HYPHENS_IN_COMMENT); break;
/*      */         }
/*      */         
/*      */ 
/* 1834 */         c = '-';
/* 1835 */         this.mInputPtr -= 1;
/*      */       }
/*      */       
/* 1838 */       if (outPtr >= outBuf.length) {
/* 1839 */         outBuf = tb.finishCurrentSegment();
/* 1840 */         outPtr = 0;
/*      */       }
/*      */       
/* 1843 */       outBuf[(outPtr++)] = c;
/*      */     }
/* 1845 */     tb.setCurrentLength(outPtr);
/* 1846 */     tb.fireDtdCommentEvent(l);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkInclusion()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1864 */     if ((!this.mIsExternal) && (this.mInput == this.mRootInput)) {
/* 1865 */       reportWFCViolation("Internal DTD subset can not use (INCLUDE/IGNORE) directives (except via external entities)");
/*      */     }
/*      */     
/* 1868 */     char c = skipDtdWs(true);
/* 1869 */     String keyword; String keyword; if (c != 'I')
/*      */     {
/* 1871 */       keyword = readDTDKeyword(String.valueOf(c));
/*      */     } else {
/* 1873 */       c = dtdNextFromCurr();
/* 1874 */       if (c == 'G') {
/* 1875 */         String keyword = checkDTDKeyword("NORE");
/* 1876 */         if (keyword == null) {
/* 1877 */           handleIgnored();
/* 1878 */           return;
/*      */         }
/* 1880 */         keyword = "IG" + keyword;
/* 1881 */       } else if (c == 'N') {
/* 1882 */         String keyword = checkDTDKeyword("CLUDE");
/* 1883 */         if (keyword == null) {
/* 1884 */           handleIncluded();
/* 1885 */           return;
/*      */         }
/* 1887 */         keyword = "IN" + keyword;
/*      */       } else {
/* 1889 */         this.mInputPtr -= 1;
/* 1890 */         keyword = readDTDKeyword("I");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1895 */     reportWFCViolation("Unrecognized directive '" + keyword + "'; expected either 'IGNORE' or 'INCLUDE'");
/*      */   }
/*      */   
/*      */   private void handleIncluded()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1901 */     char c = skipDtdWs(false);
/* 1902 */     if (c != '[') {
/* 1903 */       throwDTDUnexpectedChar(c, "; expected '[' to follow 'INCLUDE' directive");
/*      */     }
/* 1905 */     this.mIncludeCount += 1;
/*      */   }
/*      */   
/*      */   private void handleIgnored()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1911 */     char c = skipDtdWs(false);
/* 1912 */     int count = 1;
/*      */     
/* 1914 */     if (c != '[') {
/* 1915 */       throwDTDUnexpectedChar(c, "; expected '[' to follow 'IGNORE' directive");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1920 */     String errorMsg = getErrorMsg();
/*      */     for (;;) {
/* 1922 */       c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextChar(errorMsg);
/*      */       
/* 1924 */       if (c < ' ') {
/* 1925 */         if ((c == '\n') || (c == '\r')) {
/* 1926 */           skipCRLF(c);
/* 1927 */         } else if (c != '\t') {
/* 1928 */           throwInvalidSpace(c);
/*      */         }
/* 1930 */       } else if (c == ']') {
/* 1931 */         if ((getNextChar(errorMsg) == ']') && (getNextChar(errorMsg) == '>'))
/*      */         {
/* 1933 */           count--; if (count >= 1) {}
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 1938 */           this.mInputPtr -= 1;
/*      */         }
/* 1940 */       } else if (c == '<') {
/* 1941 */         if ((getNextChar(errorMsg) == '!') && (getNextChar(errorMsg) == '['))
/*      */         {
/*      */ 
/* 1944 */           count++;
/*      */         } else {
/* 1946 */           this.mInputPtr -= 1;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void reportBadDirective(String dir)
/*      */     throws XMLStreamException
/*      */   {
/* 1961 */     String msg = "Unrecognized DTD directive '<!" + dir + " >'; expected ATTLIST, ELEMENT, ENTITY or NOTATION";
/* 1962 */     if (this.mCfgSupportDTDPP) {
/* 1963 */       msg = msg + " (or, for DTD++, TARGETNS)";
/*      */     }
/* 1965 */     reportWFCViolation(msg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void reportVCViolation(String msg)
/*      */     throws XMLStreamException
/*      */   {
/* 1976 */     if (this.mCfgFullyValidating) {
/* 1977 */       reportValidationProblem(msg, 2);
/*      */     } else {
/* 1979 */       reportValidationProblem(msg, 1);
/*      */     }
/*      */   }
/*      */   
/*      */   private void reportWFCViolation(String msg)
/*      */     throws XMLStreamException
/*      */   {
/* 1986 */     throwParseError(msg);
/*      */   }
/*      */   
/*      */   private void reportWFCViolation(String format, Object arg)
/*      */     throws XMLStreamException
/*      */   {
/* 1992 */     throwParseError(format, arg);
/*      */   }
/*      */   
/*      */   private void throwDTDElemError(String msg, Object elem)
/*      */     throws XMLStreamException
/*      */   {
/* 1998 */     reportWFCViolation(elemDesc(elem) + ": " + msg);
/*      */   }
/*      */   
/*      */   private void throwDTDAttrError(String msg, DTDElement elem, NameKey attrName)
/*      */     throws XMLStreamException
/*      */   {
/* 2004 */     reportWFCViolation(attrDesc(elem, attrName) + ": " + msg);
/*      */   }
/*      */   
/*      */   private void throwDTDUnexpectedChar(int i, String extraMsg)
/*      */     throws XMLStreamException
/*      */   {
/* 2010 */     if (extraMsg == null) {
/* 2011 */       throwUnexpectedChar(i, getErrorMsg());
/*      */     }
/* 2013 */     throwUnexpectedChar(i, getErrorMsg() + extraMsg);
/*      */   }
/*      */   
/*      */   private void throwForbiddenPE()
/*      */     throws XMLStreamException
/*      */   {
/* 2019 */     reportWFCViolation("Can not have parameter entities in the internal subset, except for defining complete declarations (XML 1.0, #2.8, WFC 'PEs In Internal Subset')");
/*      */   }
/*      */   
/*      */   private String elemDesc(Object elem) {
/* 2023 */     return "Element <" + elem + ">)";
/*      */   }
/*      */   
/*      */   private String attrDesc(Object elem, NameKey attrName) {
/* 2027 */     return "Attribute '" + attrName + "' (of element <" + elem + ">)";
/*      */   }
/*      */   
/*      */   private String entityDesc(WstxInputSource input) {
/* 2031 */     return "Entity &" + input.getEntityId() + ";";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void handleDeclaration(char c)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2047 */     String keyw = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2057 */     this.mCurrDepth = 1;
/*      */     
/*      */     try
/*      */     {
/* 2061 */       if (c == 'A') {
/* 2062 */         keyw = checkDTDKeyword("TTLIST");
/* 2063 */         if (keyw == null) {
/* 2064 */           this.mCurrDeclaration = "ATTLIST";
/* 2065 */           handleAttlistDecl();
/*      */           break label329;
/*      */         }
/* 2068 */         keyw = "A" + keyw;
/* 2069 */       } else if (c == 'E') {
/* 2070 */         c = dtdNextFromCurr();
/* 2071 */         if (c == 'N') {
/* 2072 */           keyw = checkDTDKeyword("TITY");
/* 2073 */           if (keyw == null) {
/* 2074 */             this.mCurrDeclaration = "ENTITY";
/* 2075 */             handleEntityDecl(false);
/*      */             break label329;
/*      */           }
/* 2078 */           keyw = "EN" + keyw;
/* 2079 */         } else if (c == 'L') {
/* 2080 */           keyw = checkDTDKeyword("EMENT");
/* 2081 */           if (keyw == null) {
/* 2082 */             this.mCurrDeclaration = "ELEMENT";
/* 2083 */             handleElementDecl();
/*      */             break label329;
/*      */           }
/* 2086 */           keyw = "EL" + keyw;
/*      */         } else {
/* 2088 */           keyw = readDTDKeyword("E");
/*      */         }
/* 2090 */       } else if (c == 'N') {
/* 2091 */         keyw = checkDTDKeyword("OTATION");
/* 2092 */         if (keyw == null) {
/* 2093 */           this.mCurrDeclaration = "NOTATION";
/* 2094 */           handleNotationDecl();
/*      */           break label329;
/*      */         }
/* 2097 */         keyw = "N" + keyw;
/* 2098 */       } else if ((c == 'T') && (this.mCfgSupportDTDPP)) {
/* 2099 */         keyw = checkDTDKeyword("ARGETNS");
/* 2100 */         if (keyw == null) {
/* 2101 */           this.mCurrDeclaration = "TARGETNS";
/* 2102 */           handleTargetNsDecl();
/*      */           break label329;
/*      */         }
/* 2105 */         keyw = "T" + keyw;
/*      */       } else {
/* 2107 */         keyw = readDTDKeyword(String.valueOf(c));
/*      */       }
/*      */       
/*      */ 
/* 2111 */       reportBadDirective(keyw);
/*      */       
/*      */ 
/*      */       label329:
/*      */       
/* 2116 */       if (this.mInput.getScopeId() > 0) {
/* 2117 */         handleGreedyEntityProblem(this.mInput);
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 2122 */       this.mCurrDepth = 0;
/* 2123 */       this.mCurrDeclaration = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void handleSuppressedDeclaration()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2139 */     char c = dtdNextFromCurr();
/*      */     String keyw;
/* 2141 */     if (c == 'N') {
/* 2142 */       String keyw = checkDTDKeyword("TITY");
/* 2143 */       if (keyw == null) {
/* 2144 */         handleEntityDecl(true);
/* 2145 */         return;
/*      */       }
/* 2147 */       keyw = "EN" + keyw;
/* 2148 */       this.mFlattenWriter.enableOutput(this.mInputPtr);
/*      */     } else {
/* 2150 */       this.mFlattenWriter.enableOutput(this.mInputPtr);
/* 2151 */       this.mFlattenWriter.output("<!E");
/* 2152 */       this.mFlattenWriter.output(c);
/*      */       
/* 2154 */       if (c == 'L') {
/* 2155 */         String keyw = checkDTDKeyword("EMENT");
/* 2156 */         if (keyw == null) {
/* 2157 */           handleElementDecl();
/* 2158 */           return;
/*      */         }
/* 2160 */         keyw = "EL" + keyw;
/*      */       } else {
/* 2162 */         keyw = readDTDKeyword("E");
/*      */       }
/*      */     }
/* 2165 */     reportBadDirective(keyw);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void handleAttlistDecl()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2179 */     char c = skipObligatoryDtdWs();
/* 2180 */     NameKey elemName = readDTDQName(c);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2186 */     Location loc = getStartLocation();
/*      */     
/*      */ 
/* 2189 */     HashMap m = getElementMap();
/* 2190 */     DTDElement elem = (DTDElement)m.get(elemName);
/*      */     
/* 2192 */     if (elem == null)
/*      */     {
/* 2194 */       elem = DTDElement.createPlaceholder(this.mConfig, loc, elemName);
/* 2195 */       m.put(elemName, elem);
/*      */     }
/*      */     
/*      */ 
/* 2199 */     int index = 0;
/*      */     
/*      */ 
/*      */ 
/*      */     for (;;)
/*      */     {
/* 2205 */       c = getNextExpanded();
/* 2206 */       if (isSpaceChar(c))
/*      */       {
/* 2208 */         this.mInputPtr -= 1;
/* 2209 */         c = skipDtdWs(true);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2222 */       if (c == '>') {
/*      */         break;
/*      */       }
/* 2225 */       handleAttrDecl(elem, c, index, loc);
/* 2226 */       index++;
/*      */     }
/*      */   }
/*      */   
/*      */   private void handleElementDecl()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2233 */     char c = skipObligatoryDtdWs();
/* 2234 */     NameKey elemName = readDTDQName(c);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2240 */     Location loc = getStartLocation();
/*      */     
/*      */ 
/* 2243 */     c = skipObligatoryDtdWs();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2248 */     StructValidator val = null;
/* 2249 */     int vldContent = 3;
/*      */     
/* 2251 */     if (c == '(') {
/* 2252 */       c = skipDtdWs(true);
/* 2253 */       if (c == '#') {
/* 2254 */         val = readMixedSpec(elemName, this.mCfgFullyValidating);
/* 2255 */         vldContent = 3;
/*      */       } else {
/* 2257 */         this.mInputPtr -= 1;
/* 2258 */         ContentSpec spec = readContentSpec(elemName, true, this.mCfgFullyValidating);
/* 2259 */         val = spec.getSimpleValidator();
/* 2260 */         if (val == null) {
/* 2261 */           val = new DFAValidator(DFAState.constructDFA(spec));
/*      */         }
/* 2263 */         vldContent = 1;
/*      */       }
/* 2265 */     } else if (isNameStartChar(c))
/*      */     {
/* 2267 */       String keyw = null;
/* 2268 */       if (c == 'A') {
/* 2269 */         keyw = checkDTDKeyword("NY");
/* 2270 */         if (keyw == null) {
/* 2271 */           val = null;
/* 2272 */           vldContent = 3;
/*      */           break label334;
/*      */         }
/* 2275 */         keyw = "A" + keyw;
/* 2276 */       } else if (c == 'E') {
/* 2277 */         keyw = checkDTDKeyword("MPTY");
/* 2278 */         if (keyw == null) {
/* 2279 */           val = EmptyValidator.getPcdataInstance();
/* 2280 */           vldContent = 0;
/*      */           break label334;
/*      */         }
/* 2283 */         keyw = "E" + keyw;
/*      */       } else {
/* 2285 */         this.mInputPtr -= 1;
/* 2286 */         keyw = readDTDKeyword(String.valueOf(c));
/*      */       }
/* 2288 */       reportWFCViolation("Unrecognized DTD content spec keyword '" + keyw + "' (for element <" + elemName + ">); expected ANY or EMPTY");
/*      */     }
/*      */     else
/*      */     {
/* 2292 */       throwDTDUnexpectedChar(c, ": excepted '(' to start content specification for element <" + elemName + ">");
/*      */     }
/*      */     
/*      */     label334:
/* 2296 */     c = skipDtdWs(true);
/* 2297 */     if (c != '>') {
/* 2298 */       throwDTDUnexpectedChar(c, "; expected '>' to finish the element declaration for <" + elemName + ">");
/*      */     }
/*      */     
/* 2301 */     HashMap m = getElementMap();
/* 2302 */     DTDElement oldElem = (DTDElement)m.get(elemName);
/*      */     
/*      */ 
/* 2305 */     if (oldElem != null) {
/* 2306 */       if (oldElem.isDefined())
/*      */       {
/*      */ 
/*      */ 
/* 2310 */         if (this.mCfgFullyValidating) {
/* 2311 */           DTDSubsetImpl.throwElementException(oldElem, loc);
/*      */         }
/*      */         else {
/* 2314 */           return;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2321 */       oldElem = oldElem.define(loc, val, vldContent);
/*      */     }
/*      */     else {
/* 2324 */       oldElem = DTDElement.createDefined(this.mConfig, loc, elemName, val, vldContent);
/*      */     }
/* 2326 */     m.put(elemName, oldElem);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void handleEntityDecl(boolean suppressPEDecl)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2343 */     char c = dtdNextFromCurr();
/* 2344 */     boolean gotSeparator = false;
/* 2345 */     boolean isParam = false;
/*      */     for (;;)
/*      */     {
/* 2348 */       if (c == '%')
/*      */       {
/* 2350 */         char d = dtdNextIfAvailable();
/* 2351 */         if ((d == 0) || (isSpaceChar(d))) {
/* 2352 */           isParam = true;
/* 2353 */           if ((d != '\n') && (c != '\r')) break;
/* 2354 */           skipCRLF(d); break;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 2359 */         if (!isNameStartChar(d)) {
/* 2360 */           throwDTDUnexpectedChar(d, "; expected a space (for PE declaration) or PE reference name");
/*      */         }
/* 2362 */         this.mInputPtr -= 1;
/* 2363 */         gotSeparator = true;
/* 2364 */         expandPE();
/*      */         
/* 2366 */         c = dtdNextChar();
/* 2367 */       } else { if (!isSpaceChar(c)) {
/*      */           break;
/*      */         }
/* 2370 */         gotSeparator = true;
/* 2371 */         c = dtdNextFromCurr();
/*      */       }
/*      */     }
/*      */     
/* 2375 */     if (!gotSeparator) {
/* 2376 */       throwDTDUnexpectedChar(c, "; expected a space separating ENTITY keyword and entity name");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2382 */     if (isParam)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2388 */       c = skipDtdWs(true);
/*      */     }
/*      */     
/* 2391 */     if ((suppressPEDecl) && 
/* 2392 */       (!isParam)) {
/* 2393 */       this.mFlattenWriter.enableOutput(this.mInputPtr);
/* 2394 */       this.mFlattenWriter.output("<!ENTITY ");
/* 2395 */       this.mFlattenWriter.output(c);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2400 */     String id = readDTDName(c);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2406 */     Location evtLoc = getStartLocation();
/*      */     EntityDecl ent;
/*      */     try
/*      */     {
/* 2410 */       c = skipObligatoryDtdWs();
/* 2411 */       EntityDecl ent; if ((c == '\'') || (c == '"'))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 2416 */         char foo = dtdNextFromCurr();
/* 2417 */         Location contentLoc = getLastCharLocation();
/* 2418 */         this.mInputPtr -= 1;
/* 2419 */         char[] contents = parseEntityValue(id, contentLoc, c);
/* 2420 */         ent = new IntEntity(evtLoc, id, getSource(), contents, contentLoc);
/*      */       }
/*      */       else {
/* 2423 */         if (!isNameStartChar(c)) {
/* 2424 */           throwDTDUnexpectedChar(c, "; expected either quoted value, or keyword 'PUBLIC' or 'SYSTEM'");
/*      */         }
/* 2426 */         ent = handleExternalEntityDecl(this.mInput, isParam, id, c, evtLoc);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2433 */       if (this.mIsExternal) {
/* 2434 */         ent.markAsExternallyDeclared();
/*      */       }
/*      */       
/*      */     }
/*      */     finally
/*      */     {
/* 2440 */       if ((suppressPEDecl) && (isParam)) {
/* 2441 */         this.mFlattenWriter.enableOutput(this.mInputPtr);
/*      */       }
/*      */     }
/*      */     
/*      */     HashMap m;
/*      */     
/* 2447 */     if (isParam) {
/* 2448 */       HashMap m = this.mParamEntities;
/* 2449 */       if (m == null) {
/* 2450 */         this.mParamEntities = (m = new HashMap());
/*      */       }
/*      */     } else {
/* 2453 */       m = this.mGeneralEntities;
/* 2454 */       if (m == null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 2459 */         this.mGeneralEntities = (m = JdkFeatures.getInstance().getInsertOrderedMap());
/*      */       }
/*      */     }
/*      */     
/*      */     Object old;
/*      */     
/* 2465 */     if ((m.size() > 0) && ((old = m.get(id)) != null))
/*      */     {
/* 2467 */       XMLReporter rep = this.mConfig.getXMLReporter();
/* 2468 */       if (rep != null) {
/* 2469 */         EntityDecl oldED = (EntityDecl)old;
/* 2470 */         String str = " entity '" + id + "' defined more than once: first declaration at " + oldED.getLocation();
/*      */         
/* 2472 */         if (isParam) {
/* 2473 */           str = "Parameter" + str;
/*      */         } else {
/* 2475 */           str = "General" + str;
/*      */         }
/* 2477 */         reportWarning(rep, ErrorConsts.WT_ENT_DECL, str, evtLoc, oldED);
/*      */       }
/*      */     } else {
/* 2480 */       m.put(id, ent);
/*      */     }
/*      */     
/*      */ 
/* 2484 */     if ((this.mEventListener != null) && 
/* 2485 */       (!ent.isParsed()))
/*      */     {
/* 2487 */       this.mEventListener.dtdUnparsedEntityDecl(id, ent.getPublicId(), ent.getSystemId(), ent.getNotationName(), this.mInput.getSource());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void handleNotationDecl()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2498 */     char c = skipObligatoryDtdWs();
/* 2499 */     String id = readDTDName(c);
/*      */     
/* 2501 */     c = skipObligatoryDtdWs();
/* 2502 */     boolean isPublic = checkPublicSystemKeyword(c);
/*      */     
/*      */ 
/*      */ 
/* 2506 */     c = skipObligatoryDtdWs();
/*      */     
/*      */     String pubId;
/* 2509 */     if (isPublic) {
/* 2510 */       if ((c != '"') && (c != '\'')) {
/* 2511 */         throwDTDUnexpectedChar(c, "; expected a quote to start the public identifier");
/*      */       }
/* 2513 */       String pubId = parsePublicId(c, this.mCfgNormAttrs, getErrorMsg());
/* 2514 */       c = skipDtdWs(true);
/*      */     } else {
/* 2516 */       pubId = null;
/*      */     }
/*      */     
/*      */ 
/*      */     String sysId;
/*      */     
/* 2522 */     if ((c == '"') || (c == '\'')) {
/* 2523 */       String sysId = parseSystemId(c, this.mCfgNormalizeLFs, getErrorMsg());
/* 2524 */       c = skipDtdWs(true);
/*      */     } else {
/* 2526 */       if (!isPublic) {
/* 2527 */         throwDTDUnexpectedChar(c, "; expected a quote to start the system identifier");
/*      */       }
/* 2529 */       sysId = null;
/*      */     }
/*      */     
/*      */ 
/* 2533 */     if (c != '>') {
/* 2534 */       throwDTDUnexpectedChar(c, "; expected closing '>' after NOTATION declaration");
/*      */     }
/*      */     
/*      */ 
/* 2538 */     if (this.mEventListener != null) {
/* 2539 */       this.mEventListener.dtdNotationDecl(id, pubId, sysId, this.mInput.getSource());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2546 */     Location evtLoc = getStartLocation();
/* 2547 */     NotationDecl nd = new NotationDecl(evtLoc, id, pubId, sysId);
/*      */     
/*      */ 
/* 2550 */     if (this.mPredefdNotations != null) {
/* 2551 */       NotationDecl oldDecl = (NotationDecl)this.mPredefdNotations.get(id);
/* 2552 */       if (oldDecl != null) {
/* 2553 */         DTDSubsetImpl.throwNotationException(oldDecl, nd);
/*      */       }
/*      */     }
/*      */     
/* 2557 */     HashMap m = this.mNotations;
/* 2558 */     if (m == null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2563 */       this.mNotations = (m = JdkFeatures.getInstance().getInsertOrderedMap());
/*      */     } else {
/* 2565 */       NotationDecl oldDecl = (NotationDecl)m.get(id);
/* 2566 */       if (oldDecl != null) {
/* 2567 */         DTDSubsetImpl.throwNotationException(oldDecl, nd);
/*      */       }
/*      */     }
/* 2570 */     m.put(id, nd);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void handleTargetNsDecl()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2583 */     this.mAnyDTDppFeatures = true;
/*      */     
/* 2585 */     char c = skipObligatoryDtdWs();
/*      */     
/*      */     String name;
/*      */     
/* 2589 */     if (isNameStartChar(c)) {
/* 2590 */       String name = readDTDLocalName(c, false);
/* 2591 */       c = skipObligatoryDtdWs();
/*      */     } else {
/* 2593 */       name = null;
/*      */     }
/*      */     
/*      */ 
/* 2597 */     if ((c != '"') && (c != '\'')) {
/* 2598 */       if (c == '>') {
/* 2599 */         reportWFCViolation("Missing namespace URI for TARGETNS directive");
/*      */       }
/* 2601 */       throwDTDUnexpectedChar(c, "; expected a single or double quote to enclose the namespace URI");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2607 */     String uri = parseSystemId(c, false, "in namespace URI");
/*      */     
/*      */ 
/* 2610 */     if ((this.mConfigFlags & 0x400) != 0) {
/* 2611 */       uri = InternCache.getInstance().intern(uri);
/*      */     }
/*      */     
/*      */ 
/* 2615 */     c = skipDtdWs(true);
/* 2616 */     if (c != '>') {
/* 2617 */       throwDTDUnexpectedChar(c, "; expected '>' to end TARGETNS directive");
/*      */     }
/*      */     
/* 2620 */     if (name == null) {
/* 2621 */       this.mDefaultNsURI = uri;
/*      */     } else {
/* 2623 */       if (this.mNamespaces == null) {
/* 2624 */         this.mNamespaces = new HashMap();
/*      */       }
/* 2626 */       this.mNamespaces.put(name, uri);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void handleAttrDecl(DTDElement elem, char c, int index, Location loc)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2648 */     NameKey attrName = readDTDQName(c);
/*      */     
/*      */ 
/* 2651 */     c = skipObligatoryDtdWs();
/*      */     
/* 2653 */     int type = 0;
/* 2654 */     WordResolver enumValues = null;
/*      */     
/* 2656 */     if (c == '(') {
/* 2657 */       enumValues = parseEnumerated(elem, attrName, false);
/* 2658 */       type = 1;
/*      */     } else {
/* 2660 */       String typeStr = readDTDName(c);
/*      */       
/*      */ 
/*      */ 
/* 2664 */       switch (typeStr.charAt(0)) {
/*      */       case 'C': 
/* 2666 */         if (typeStr == "CDATA")
/* 2667 */           type = 0;
/* 2668 */         break;
/*      */       
/*      */ 
/*      */       case 'I': 
/* 2672 */         if (typeStr == "ID") {
/* 2673 */           type = 2;
/*      */         }
/* 2675 */         else if (typeStr == "IDREF") {
/* 2676 */           type = 3;
/*      */         }
/* 2678 */         else if (typeStr == "IDREFS")
/* 2679 */           type = 4;
/* 2680 */         break;
/*      */       
/*      */ 
/*      */       case 'E': 
/* 2684 */         if (typeStr == "ENTITY") {
/* 2685 */           type = 5;
/*      */         }
/* 2687 */         else if (typeStr == "ENTITIES")
/* 2688 */           type = 6;
/* 2689 */         break;
/*      */       
/*      */ 
/*      */       case 'N': 
/* 2693 */         if (typeStr == "NOTATION") {
/* 2694 */           type = 7;
/*      */           
/*      */ 
/*      */ 
/* 2698 */           c = skipObligatoryDtdWs();
/* 2699 */           if (c != '(') {
/* 2700 */             throwDTDUnexpectedChar(c, "Excepted '(' to start the list of NOTATION ids");
/*      */           }
/* 2702 */           enumValues = parseEnumerated(elem, attrName, true);
/*      */         }
/* 2704 */         else if (typeStr == "NMTOKEN") {
/* 2705 */           type = 8;
/*      */         }
/* 2707 */         else if (typeStr == "NMTOKENS") {
/* 2708 */           type = 9; }
/* 2709 */         break;
/*      */       }
/*      */       
/*      */       
/*      */ 
/*      */ 
/* 2715 */       throwDTDAttrError("Unrecognized attribute type '" + typeStr + "'" + ErrorConsts.ERR_DTD_ATTR_TYPE, elem, attrName);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2723 */     c = skipObligatoryDtdWs();
/* 2724 */     DefaultAttrValue defVal; DefaultAttrValue defVal; if (c == '#') {
/* 2725 */       String defTypeStr = readDTDName(getNextExpanded());
/* 2726 */       DefaultAttrValue defVal; if (defTypeStr == "REQUIRED") {
/* 2727 */         defVal = DefaultAttrValue.constructRequired(); } else { DefaultAttrValue defVal;
/* 2728 */         if (defTypeStr == "IMPLIED") {
/* 2729 */           defVal = DefaultAttrValue.constructImplied();
/* 2730 */         } else if (defTypeStr == "FIXED") {
/* 2731 */           DefaultAttrValue defVal = DefaultAttrValue.constructFixed();
/* 2732 */           c = skipObligatoryDtdWs();
/* 2733 */           parseAttrDefaultValue(defVal, c, attrName, loc, true);
/*      */         } else {
/* 2735 */           throwDTDAttrError("Unrecognized attribute default value directive #" + defTypeStr + ErrorConsts.ERR_DTD_DEFAULT_TYPE, elem, attrName);
/*      */           
/*      */ 
/* 2738 */           defVal = null;
/*      */         }
/*      */       }
/* 2741 */     } else { defVal = DefaultAttrValue.constructOptional();
/* 2742 */       parseAttrDefaultValue(defVal, c, attrName, loc, false);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2750 */     if ((type == 2) && (defVal.hasDefaultValue()))
/*      */     {
/* 2752 */       if (this.mCfgFullyValidating) {
/* 2753 */         throwDTDAttrError("has type ID; can not have a default (or #FIXED) value (XML 1.0/#3.3.1)", elem, attrName);
/*      */       }
/*      */       
/*      */     }
/* 2757 */     else if ((this.mConfig.willDoXmlIdTyping()) && 
/* 2758 */       (attrName.isXmlReservedAttr(this.mCfgNsEnabled, "id")))
/*      */     {
/* 2760 */       checkXmlIdAttr(type);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2768 */     if (attrName.isXmlReservedAttr(this.mCfgNsEnabled, "space")) {
/* 2769 */       checkXmlSpaceAttr(type, enumValues);
/*      */     }
/*      */     
/*      */ 
/*      */     DTDAttribute attr;
/*      */     
/*      */     DTDAttribute attr;
/*      */     
/* 2777 */     if ((this.mCfgNsEnabled) && (attrName.isaNsDeclaration()))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2782 */       if (!defVal.hasDefaultValue()) {
/* 2783 */         return;
/*      */       }
/*      */       
/* 2786 */       attr = elem.addNsDefault(this, attrName, type, defVal, this.mCfgFullyValidating);
/*      */     }
/*      */     else {
/* 2789 */       attr = elem.addAttribute(this, attrName, type, defVal, enumValues, this.mCfgFullyValidating);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2795 */     if (attr == null)
/*      */     {
/* 2797 */       XMLReporter rep = this.mConfig.getXMLReporter();
/* 2798 */       if (rep != null) {
/* 2799 */         String msg = MessageFormat.format(ErrorConsts.W_DTD_ATTR_REDECL, new Object[] { attrName, elem });
/* 2800 */         reportWarning(rep, ErrorConsts.WT_ATTR_DECL, msg, loc, elem);
/*      */       }
/*      */     }
/* 2803 */     else if (defVal.hasDefaultValue())
/*      */     {
/* 2805 */       attr.normalizeDefault();
/*      */       
/* 2807 */       if (this.mCfgFullyValidating) {
/* 2808 */         attr.validateDefault(this, this.mCfgNormAttrs);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private WordResolver parseEnumerated(DTDElement elem, NameKey attrName, boolean isNotation)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2825 */     TreeSet set = new TreeSet();
/*      */     
/* 2827 */     char c = skipDtdWs(true);
/* 2828 */     if (c == ')') {
/* 2829 */       throwDTDUnexpectedChar(c, " (empty list; missing identifier(s))?");
/*      */     }
/*      */     
/*      */     HashMap sharedEnums;
/*      */     HashMap sharedEnums;
/* 2834 */     if (isNotation) {
/* 2835 */       sharedEnums = null;
/*      */     } else {
/* 2837 */       sharedEnums = this.mSharedEnumValues;
/* 2838 */       if ((sharedEnums == null) && (!isNotation)) {
/* 2839 */         this.mSharedEnumValues = (sharedEnums = new HashMap());
/*      */       }
/*      */     }
/*      */     
/* 2843 */     String id = isNotation ? readNotationEntry(c, attrName) : readEnumEntry(c, sharedEnums);
/*      */     
/* 2845 */     set.add(id);
/*      */     for (;;)
/*      */     {
/* 2848 */       c = skipDtdWs(true);
/* 2849 */       if (c == ')') {
/*      */         break;
/*      */       }
/* 2852 */       if (c != '|') {
/* 2853 */         throwDTDUnexpectedChar(c, "; missing '|' separator?");
/*      */       }
/* 2855 */       c = skipDtdWs(true);
/* 2856 */       id = isNotation ? readNotationEntry(c, attrName) : readEnumEntry(c, sharedEnums);
/*      */       
/* 2858 */       if ((!set.add(id)) && 
/*      */       
/*      */ 
/*      */ 
/* 2862 */         (this.mCfgFullyValidating)) {
/* 2863 */         throwDTDAttrError("Duplicate enumeration value '" + id + "'", elem, attrName);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2870 */     return WordResolver.constructInstance(set);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String readNotationEntry(char c, NameKey attrName)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2886 */     String id = readDTDName(c);
/*      */     
/* 2888 */     if (this.mPredefdNotations != null) {
/* 2889 */       NotationDecl decl = (NotationDecl)this.mPredefdNotations.get(id);
/* 2890 */       if (decl != null) {
/* 2891 */         this.mUsesPredefdNotations = true;
/* 2892 */         return decl.getName();
/*      */       }
/*      */     }
/*      */     
/* 2896 */     NotationDecl decl = this.mNotations == null ? null : (NotationDecl)this.mNotations.get(id);
/*      */     
/* 2898 */     if (decl == null)
/*      */     {
/* 2900 */       if (this.mCfgFullyValidating) {
/* 2901 */         String msg = "Notation '" + id + "' not defined; ";
/* 2902 */         if (attrName == null) {
/* 2903 */           reportVCViolation(msg + "can not refer to from an entity");
/*      */         }
/*      */         
/* 2906 */         reportVCViolation(msg + "can not be used as value for attribute list of '" + attrName + "'");
/*      */       } else {
/* 2908 */         return id;
/*      */       }
/*      */     }
/*      */     
/* 2912 */     return decl.getName();
/*      */   }
/*      */   
/*      */   private String readEnumEntry(char c, HashMap sharedEnums)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2918 */     String id = readDTDNmtoken(c);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2923 */     String sid = (String)sharedEnums.get(id);
/* 2924 */     if (sid == null) {
/* 2925 */       sid = id;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2933 */       sharedEnums.put(sid, sid);
/*      */     }
/* 2935 */     return sid;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private StructValidator readMixedSpec(NameKey elemName, boolean construct)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2949 */     String keyw = checkDTDKeyword("PCDATA");
/* 2950 */     if (keyw != null) {
/* 2951 */       reportWFCViolation("Unrecognized directive #" + keyw + "'; expected #PCDATA (or element name)");
/*      */     }
/*      */     
/* 2954 */     HashMap m = JdkFeatures.getInstance().getInsertOrderedMap();
/*      */     for (;;) {
/* 2956 */       char c = skipDtdWs(true);
/* 2957 */       if (c == ')') {
/*      */         break;
/*      */       }
/* 2960 */       if (c == '|') {
/* 2961 */         c = skipDtdWs(true);
/* 2962 */       } else if (c == ',') {
/* 2963 */         throwDTDUnexpectedChar(c, " (sequences not allowed within mixed content)");
/* 2964 */       } else if (c == '(') {
/* 2965 */         throwDTDUnexpectedChar(c, " (sub-content specs not allowed within mixed content)");
/*      */       } else {
/* 2967 */         throwDTDUnexpectedChar(c, "; expected either '|' to separate elements, or ')' to close the list");
/*      */       }
/* 2969 */       NameKey n = readDTDQName(c);
/* 2970 */       Object old = m.put(n, TokenContentSpec.construct(' ', n));
/* 2971 */       if (old != null)
/*      */       {
/*      */ 
/*      */ 
/* 2975 */         if (this.mCfgFullyValidating) {
/* 2976 */           throwDTDElemError("duplicate child element <" + n + "> in mixed content model", elemName);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2985 */     char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextChar(getErrorMsg());
/*      */     
/* 2987 */     if (c != '*') {
/* 2988 */       if (m.size() > 0) {
/* 2989 */         reportWFCViolation("Missing trailing '*' after a non-empty mixed content specification");
/*      */       }
/* 2991 */       this.mInputPtr -= 1;
/*      */     }
/* 2993 */     if (!construct) {
/* 2994 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3000 */     if (m.isEmpty()) {
/* 3001 */       return EmptyValidator.getPcdataInstance();
/*      */     }
/* 3003 */     ContentSpec spec = ChoiceContentSpec.constructMixed(this.mCfgNsEnabled, m.values());
/* 3004 */     StructValidator val = spec.getSimpleValidator();
/* 3005 */     if (val == null) {
/* 3006 */       DFAState dfa = DFAState.constructDFA(spec);
/* 3007 */       val = new DFAValidator(dfa);
/*      */     }
/* 3009 */     return val;
/*      */   }
/*      */   
/*      */ 
/*      */   private ContentSpec readContentSpec(NameKey elemName, boolean mainLevel, boolean construct)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 3016 */     ArrayList subSpecs = new ArrayList();
/* 3017 */     boolean isChoice = false;
/* 3018 */     boolean choiceSet = false;
/*      */     for (;;)
/*      */     {
/* 3021 */       char c = skipDtdWs(true);
/* 3022 */       if (c == ')')
/*      */       {
/* 3024 */         if (!subSpecs.isEmpty()) break;
/* 3025 */         reportWFCViolation("Empty content specification for '" + elemName + "' (need at least one entry)"); break;
/*      */       }
/*      */       
/*      */ 
/* 3029 */       if ((c == '|') || (c == ',')) {
/* 3030 */         boolean newChoice = c == '|';
/* 3031 */         if (!choiceSet) {
/* 3032 */           isChoice = newChoice;
/* 3033 */           choiceSet = true;
/*      */         }
/* 3035 */         else if (isChoice != newChoice) {
/* 3036 */           reportWFCViolation("Can not mix content spec separators ('|' and ','); need to use parenthesis groups");
/*      */         }
/*      */         
/* 3039 */         c = skipDtdWs(true);
/*      */ 
/*      */       }
/* 3042 */       else if (!subSpecs.isEmpty()) {
/* 3043 */         throwDTDUnexpectedChar(c, " (missing separator '|' or ','?)");
/*      */       }
/*      */       
/* 3046 */       if (c == '(') {
/* 3047 */         ContentSpec cs = readContentSpec(elemName, false, construct);
/* 3048 */         subSpecs.add(cs);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 3053 */         if ((c == '|') || (c == ',')) {
/* 3054 */           throwDTDUnexpectedChar(c, " (missing element name?)");
/*      */         }
/* 3056 */         NameKey thisName = readDTDQName(c);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 3061 */         char arity = readArity();
/* 3062 */         ContentSpec cs = construct ? TokenContentSpec.construct(arity, thisName) : TokenContentSpec.getDummySpec();
/*      */         
/*      */ 
/* 3065 */         subSpecs.add(cs);
/*      */       }
/*      */     }
/* 3068 */     char arity = readArity();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3073 */     if (!construct) {
/* 3074 */       return TokenContentSpec.getDummySpec();
/*      */     }
/*      */     
/*      */ 
/* 3078 */     if (subSpecs.size() == 1) {
/* 3079 */       ContentSpec cs = (ContentSpec)subSpecs.get(0);
/* 3080 */       char otherArity = cs.getArity();
/* 3081 */       if (arity != otherArity) {
/* 3082 */         cs.setArity(combineArities(arity, otherArity));
/*      */       }
/* 3084 */       return cs;
/*      */     }
/*      */     
/* 3087 */     if (isChoice) {
/* 3088 */       return ChoiceContentSpec.constructChoice(this.mCfgNsEnabled, arity, subSpecs);
/*      */     }
/* 3090 */     return SeqContentSpec.construct(this.mCfgNsEnabled, arity, subSpecs);
/*      */   }
/*      */   
/*      */   private static char combineArities(char arity1, char arity2)
/*      */   {
/* 3095 */     if (arity1 == arity2) {
/* 3096 */       return arity1;
/*      */     }
/*      */     
/*      */ 
/* 3100 */     if (arity1 == ' ') {
/* 3101 */       return arity2;
/*      */     }
/* 3103 */     if (arity2 == ' ') {
/* 3104 */       return arity1;
/*      */     }
/*      */     
/* 3107 */     if ((arity1 == '*') || (arity2 == '*')) {
/* 3108 */       return '*';
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3114 */     return '*';
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private EntityDecl handleExternalEntityDecl(WstxInputSource inputSource, boolean isParam, String id, char c, Location evtLoc)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 3134 */     String errId = null;
/* 3135 */     boolean isPublic = checkPublicSystemKeyword(c);
/*      */     
/* 3137 */     String pubId = null;
/*      */     
/*      */ 
/* 3140 */     if (isPublic) {
/* 3141 */       c = skipObligatoryDtdWs();
/* 3142 */       if ((c != '"') && (c != '\'')) {
/* 3143 */         throwDTDUnexpectedChar(c, "; expected a quote to start the public identifier");
/*      */       }
/* 3145 */       pubId = parsePublicId(c, this.mCfgNormAttrs, getErrorMsg());
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 3150 */       c = getNextExpanded();
/* 3151 */       if (c <= ' ') {
/* 3152 */         c = skipDtdWs(true);
/*      */ 
/*      */       }
/* 3155 */       else if (c != '>') {
/* 3156 */         this.mInputPtr -= 1;
/* 3157 */         c = skipObligatoryDtdWs();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3164 */       if (c == '>') {
/* 3165 */         reportWFCViolation("Unexpected end of ENTITY declaration (expected a system id after public id): trying to use an SGML DTD instead of XML one?");
/*      */       }
/*      */     }
/*      */     else {
/* 3169 */       c = skipObligatoryDtdWs();
/*      */     }
/* 3171 */     if ((c != '"') && (c != '\'')) {
/* 3172 */       throwDTDUnexpectedChar(c, "; expected a quote to start the system identifier");
/*      */     }
/* 3174 */     String sysId = parseSystemId(c, this.mCfgNormalizeLFs, getErrorMsg());
/*      */     
/*      */ 
/* 3177 */     String notationId = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3182 */     if (isParam) {
/* 3183 */       c = skipDtdWs(true);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/* 3189 */       int i = peekNext();
/* 3190 */       if (i == 62) {
/* 3191 */         c = '>';
/* 3192 */         this.mInputPtr += 1;
/* 3193 */       } else if (i < 0) {
/* 3194 */         c = skipDtdWs(true);
/* 3195 */       } else if (i == 37) {
/* 3196 */         c = getNextExpanded();
/*      */       } else {
/* 3198 */         this.mInputPtr += 1;
/* 3199 */         c = (char)i;
/* 3200 */         if (!isSpaceChar(c)) {
/* 3201 */           throwDTDUnexpectedChar(c, "; expected a separating space or closing '>'");
/*      */         }
/* 3203 */         c = skipDtdWs(true);
/*      */       }
/*      */       
/* 3206 */       if (c != '>') {
/* 3207 */         if (!isNameStartChar(c)) {
/* 3208 */           throwDTDUnexpectedChar(c, "; expected either NDATA keyword, or closing '>'");
/*      */         }
/* 3210 */         String keyw = checkDTDKeyword("DATA");
/* 3211 */         if (keyw != null) {
/* 3212 */           reportWFCViolation("Unrecognized keyword '" + keyw + "'; expected NOTATION (or closing '>')");
/*      */         }
/* 3214 */         c = skipObligatoryDtdWs();
/* 3215 */         notationId = readNotationEntry(c, null);
/* 3216 */         c = skipDtdWs(true);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 3221 */     if (c != '>') {
/* 3222 */       throwDTDUnexpectedChar(c, "; expected closing '>'");
/*      */     }
/*      */     
/* 3225 */     URL ctxt = inputSource.getSource();
/* 3226 */     if (notationId == null) {
/* 3227 */       return new ParsedExtEntity(evtLoc, id, ctxt, pubId, sysId);
/*      */     }
/* 3229 */     return new UnparsedExtEntity(evtLoc, id, ctxt, pubId, sysId, notationId);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private HashMap getElementMap()
/*      */   {
/* 3239 */     HashMap m = this.mElements;
/* 3240 */     if (m == null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3245 */       this.mElements = (m = JdkFeatures.getInstance().getInsertOrderedMap());
/*      */     }
/* 3247 */     return m;
/*      */   }
/*      */   
/* 3250 */   final NameKey mAccessKey = new NameKey(null, null);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private NameKey findSharedName(String prefix, String localName)
/*      */   {
/* 3265 */     HashMap m = this.mSharedNames;
/*      */     
/* 3267 */     if (this.mSharedNames == null) {
/* 3268 */       this.mSharedNames = (m = new HashMap());
/*      */     }
/*      */     else {
/* 3271 */       NameKey key = this.mAccessKey;
/* 3272 */       key.reset(prefix, localName);
/* 3273 */       key = (NameKey)m.get(key);
/* 3274 */       if (key != null) {
/* 3275 */         return key;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 3280 */     NameKey result = new NameKey(prefix, localName);
/* 3281 */     m.put(result, result);
/* 3282 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected EntityDecl findEntity(String id, Object arg)
/*      */   {
/* 3299 */     if (arg == ENTITY_EXP_PE) {
/* 3300 */       EntityDecl ed = this.mPredefdPEs == null ? null : (EntityDecl)this.mPredefdPEs.get(id);
/* 3301 */       if (ed != null) {
/* 3302 */         this.mUsesPredefdEntities = true;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 3307 */         this.mRefdPEs = null;
/* 3308 */       } else if (this.mParamEntities != null) {
/* 3309 */         ed = (EntityDecl)this.mParamEntities.get(id);
/* 3310 */         if ((ed != null) && 
/* 3311 */           (!this.mUsesPredefdEntities))
/*      */         {
/* 3313 */           Set used = this.mRefdPEs;
/* 3314 */           if (used == null) {
/* 3315 */             this.mRefdPEs = (used = new HashSet());
/*      */           }
/* 3317 */           used.add(id);
/*      */         }
/*      */       }
/*      */       
/* 3321 */       return ed;
/*      */     }
/*      */     
/*      */ 
/* 3325 */     if (arg == ENTITY_EXP_GE)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3330 */       EntityDecl ed = this.mPredefdGEs == null ? null : (EntityDecl)this.mPredefdGEs.get(id);
/* 3331 */       if (ed != null) {
/* 3332 */         this.mUsesPredefdEntities = true;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 3337 */         this.mRefdGEs = null;
/* 3338 */       } else if (this.mGeneralEntities != null) {
/* 3339 */         ed = (EntityDecl)this.mGeneralEntities.get(id);
/* 3340 */         if (ed != null)
/*      */         {
/* 3342 */           if (!this.mUsesPredefdEntities)
/*      */           {
/* 3344 */             if (this.mRefdGEs == null) {
/* 3345 */               this.mRefdGEs = new HashSet();
/*      */             }
/* 3347 */             this.mRefdGEs.add(id);
/*      */           }
/*      */         }
/*      */       }
/* 3351 */       return ed;
/*      */     }
/*      */     
/* 3354 */     throw new Error(ErrorConsts.ERR_INTERNAL);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void handleUndeclaredEntity(String id)
/*      */     throws XMLStreamException
/*      */   {
/* 3364 */     reportVCViolation("Undeclared parameter entity '" + id + "'.");
/* 3365 */     if (this.mCurrAttrDefault != null) {
/* 3366 */       Location loc = getLastCharLocation();
/* 3367 */       if (this.mExpandingPE) {
/* 3368 */         this.mCurrAttrDefault.addUndeclaredPE(id, loc);
/*      */       } else {
/* 3370 */         this.mCurrAttrDefault.addUndeclaredGE(id, loc);
/*      */       }
/*      */     }
/* 3373 */     if (this.mEventListener != null)
/*      */     {
/* 3375 */       if (this.mExpandingPE) {
/* 3376 */         this.mEventListener.dtdSkippedEntity("%" + id);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void handleIncompleteEntityProblem(WstxInputSource closing)
/*      */     throws XMLStreamException
/*      */   {
/* 3393 */     if (closing.getScopeId() == 0)
/*      */     {
/* 3395 */       reportWFCViolation(entityDesc(closing) + ": " + "Incomplete PE: has to fully contain a declaration (as per xml 1.0.3, section 2.8, WFC 'PE Between Declarations')");
/*      */ 
/*      */ 
/*      */     }
/* 3399 */     else if (this.mCfgFullyValidating) {
/* 3400 */       reportVCViolation(entityDesc(closing) + ": " + "Incomplete PE: has to be fully contained in a declaration (as per xml 1.0.3, section 2.8, VC 'Proper Declaration/PE Nesting')");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void handleGreedyEntityProblem(WstxInputSource input)
/*      */     throws XMLStreamException
/*      */   {
/* 3410 */     if (this.mCfgFullyValidating) {
/* 3411 */       reportWFCViolation(entityDesc(input) + ": " + "Unbalanced PE: has to be fully contained in a declaration (as per xml 1.0.3, section 2.8, VC 'Proper Declaration/PE Nesting')");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected char handleExpandedSurrogate(char first, char second)
/*      */   {
/* 3430 */     this.mSurrogateSecond = second;
/* 3431 */     return first;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void checkXmlSpaceAttr(int type, WordResolver enumValues)
/*      */     throws XMLStreamException
/*      */   {
/* 3443 */     boolean ok = type == 1;
/* 3444 */     if (ok) {
/* 3445 */       switch (enumValues.size()) {
/*      */       case 1: 
/* 3447 */         ok = (enumValues.find("preserve") != null) || (enumValues.find("default") != null);
/*      */         
/* 3449 */         break;
/*      */       case 2: 
/* 3451 */         ok = (enumValues.find("preserve") != null) && (enumValues.find("default") != null);
/*      */         
/* 3453 */         break;
/*      */       default: 
/* 3455 */         ok = false;
/*      */       }
/*      */       
/*      */     }
/* 3459 */     if (!ok) {
/* 3460 */       reportVCViolation(ErrorConsts.ERR_DTD_XML_SPACE);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void checkXmlIdAttr(int type)
/*      */     throws XMLStreamException
/*      */   {
/* 3467 */     if (type != 2) {
/* 3468 */       reportVCViolation(ErrorConsts.ERR_DTD_XML_ID);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void reportWarning(XMLReporter rep, String probType, String msg, Location loc, Object extraArg)
/*      */     throws XMLStreamException
/*      */   {
/* 3482 */     if (rep != null) {
/* 3483 */       rep.report(msg, probType, extraArg, loc);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\FullDTDReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */