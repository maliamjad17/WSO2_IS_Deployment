/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ import com.ctc.wstx.io.WstxInputData;
/*     */ import com.ctc.wstx.sr.InputProblemReporter;
/*     */ import org.codehaus.stax2.validation.XMLValidationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DTDNmTokenAttr
/*     */   extends DTDAttribute
/*     */ {
/*     */   public DTDNmTokenAttr(NameKey name, DefaultAttrValue defValue, int specIndex, boolean nsAware, boolean xml11)
/*     */   {
/*  31 */     super(name, defValue, specIndex, nsAware, xml11);
/*     */   }
/*     */   
/*     */   public DTDAttribute cloneWith(int specIndex)
/*     */   {
/*  36 */     return new DTDNmTokenAttr(this.mName, this.mDefValue, specIndex, this.mCfgNsAware, this.mCfgXml11);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getValueType()
/*     */   {
/*  46 */     return 8;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validate(DTDValidatorBase v, char[] cbuf, int start, int end, boolean normalize)
/*     */     throws XMLValidationException
/*     */   {
/*  63 */     int origLen = end - start;
/*     */     
/*     */ 
/*  66 */     while ((start < end) && (WstxInputData.isSpaceChar(cbuf[start]))) {
/*  67 */       start++;
/*     */     }
/*     */     
/*     */ 
/*  71 */     if (start >= end) {
/*  72 */       return reportValidationProblem(v, "Empty NMTOKEN value");
/*     */     }
/*     */     
/*  75 */     end--;
/*  76 */     while ((end > start) && (WstxInputData.isSpaceChar(cbuf[end]))) {
/*  77 */       end--;
/*     */     }
/*     */     
/*     */ 
/*  81 */     for (int i = start; i <= end; i++) {
/*  82 */       char c = cbuf[i];
/*  83 */       if (!WstxInputData.isNameChar(c, this.mCfgNsAware, this.mCfgXml11)) {
/*  84 */         return reportInvalidChar(v, c, "not valid NMTOKEN character");
/*     */       }
/*     */     }
/*     */     
/*  88 */     if (normalize)
/*     */     {
/*  90 */       int len = end - start + 1;
/*  91 */       if (len != origLen) {
/*  92 */         return new String(cbuf, start, len);
/*     */       }
/*     */     }
/*  95 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validateDefault(InputProblemReporter rep, boolean normalize)
/*     */     throws XMLValidationException
/*     */   {
/* 106 */     String def = validateDefaultNmToken(rep, normalize);
/* 107 */     if (normalize) {
/* 108 */       this.mDefValue.setValue(def);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\DTDNmTokenAttr.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */