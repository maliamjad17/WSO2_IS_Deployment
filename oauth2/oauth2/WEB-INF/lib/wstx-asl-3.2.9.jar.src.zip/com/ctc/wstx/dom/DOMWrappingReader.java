/*      */ package com.ctc.wstx.dom;
/*      */ 
/*      */ import com.ctc.wstx.api.ReaderConfig;
/*      */ import com.ctc.wstx.cfg.ErrorConsts;
/*      */ import com.ctc.wstx.exc.WstxParsingException;
/*      */ import com.ctc.wstx.io.WstxInputLocation;
/*      */ import com.ctc.wstx.util.EmptyIterator;
/*      */ import com.ctc.wstx.util.EmptyNamespaceContext;
/*      */ import com.ctc.wstx.util.SingletonIterator;
/*      */ import com.ctc.wstx.util.TextAccumulator;
/*      */ import java.io.IOException;
/*      */ import java.io.Writer;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.NoSuchElementException;
/*      */ import javax.xml.namespace.NamespaceContext;
/*      */ import javax.xml.namespace.QName;
/*      */ import javax.xml.stream.Location;
/*      */ import javax.xml.stream.XMLStreamConstants;
/*      */ import javax.xml.stream.XMLStreamException;
/*      */ import javax.xml.transform.dom.DOMSource;
/*      */ import org.codehaus.stax2.AttributeInfo;
/*      */ import org.codehaus.stax2.DTDInfo;
/*      */ import org.codehaus.stax2.LocationInfo;
/*      */ import org.codehaus.stax2.XMLStreamLocation2;
/*      */ import org.codehaus.stax2.XMLStreamReader2;
/*      */ import org.codehaus.stax2.validation.DTDValidationSchema;
/*      */ import org.codehaus.stax2.validation.ValidationProblemHandler;
/*      */ import org.codehaus.stax2.validation.XMLValidationSchema;
/*      */ import org.codehaus.stax2.validation.XMLValidator;
/*      */ import org.w3c.dom.Attr;
/*      */ import org.w3c.dom.DocumentType;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.NamedNodeMap;
/*      */ import org.w3c.dom.Node;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DOMWrappingReader
/*      */   implements XMLStreamReader2, DTDInfo, LocationInfo, NamespaceContext, XMLStreamConstants
/*      */ {
/*      */   private static final int MASK_GET_TEXT = 6768;
/*      */   private static final int MASK_GET_ELEMENT_TEXT = 4688;
/*      */   protected final ReaderConfig mConfig;
/*      */   protected final String mSystemId;
/*      */   protected final Node mRootNode;
/*      */   protected final boolean mNsAware;
/*      */   protected final boolean mCoalescing;
/*  106 */   protected int mCurrEvent = 7;
/*      */   
/*      */ 
/*      */ 
/*      */   protected Node mCurrNode;
/*      */   
/*      */ 
/*      */ 
/*  114 */   protected int mDepth = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String mCoalescedText;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  127 */   protected TextAccumulator mTextBuffer = new TextAccumulator();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  143 */   protected List mAttrList = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  152 */   protected List mNsDeclList = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private DOMWrappingReader(ReaderConfig cfg, Node treeRoot, String sysId)
/*      */     throws XMLStreamException
/*      */   {
/*  168 */     if (treeRoot == null) {
/*  169 */       throw new IllegalArgumentException("Can not pass null Node for constructing a DOM-based XMLStreamReader");
/*      */     }
/*      */     
/*  172 */     this.mConfig = cfg;
/*  173 */     this.mNsAware = cfg.willSupportNamespaces();
/*  174 */     this.mCoalescing = cfg.willCoalesceText();
/*  175 */     this.mSystemId = sysId;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  180 */     switch (treeRoot.getNodeType())
/*      */     {
/*      */     case 1: 
/*      */     case 9: 
/*      */     case 11: 
/*      */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     default: 
/*  194 */       throw new XMLStreamException("Can not create an XMLStreamReader for a DOM node of type " + treeRoot.getClass());
/*      */     }
/*  196 */     this.mRootNode = (this.mCurrNode = treeRoot);
/*      */   }
/*      */   
/*      */   public static DOMWrappingReader createFrom(ReaderConfig cfg, DOMSource src)
/*      */     throws XMLStreamException
/*      */   {
/*  202 */     Node rootNode = src.getNode();
/*  203 */     String systemId = src.getSystemId();
/*  204 */     return new DOMWrappingReader(cfg, rootNode, systemId);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCharacterEncodingScheme()
/*      */   {
/*  221 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getEncoding()
/*      */   {
/*  234 */     return getCharacterEncodingScheme();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getVersion()
/*      */   {
/*  242 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isStandalone()
/*      */   {
/*  249 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean standaloneSet()
/*      */   {
/*  256 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getProperty(String name)
/*      */   {
/*  267 */     if (name.equals("javax.xml.stream.entities"))
/*      */     {
/*  269 */       return Collections.EMPTY_LIST;
/*      */     }
/*  271 */     if (name.equals("javax.xml.stream.notations"))
/*      */     {
/*  273 */       return Collections.EMPTY_LIST;
/*      */     }
/*      */     
/*  276 */     if (("org.codehaus.stax2.internNames".equals(name)) || ("org.codehaus.stax2.internNsUris".equals(name)))
/*      */     {
/*  278 */       return Boolean.FALSE;
/*      */     }
/*  280 */     return this.mConfig.getProperty(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getAttributeCount()
/*      */   {
/*  293 */     if (this.mCurrEvent != 1) {
/*  294 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/*  296 */     if (this.mAttrList == null) {
/*  297 */       calcNsAndAttrLists(true);
/*      */     }
/*  299 */     return this.mAttrList.size();
/*      */   }
/*      */   
/*      */   public String getAttributeLocalName(int index)
/*      */   {
/*  304 */     if (this.mCurrEvent != 1) {
/*  305 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/*  307 */     if (this.mAttrList == null) {
/*  308 */       calcNsAndAttrLists(true);
/*      */     }
/*  310 */     if ((index >= this.mAttrList.size()) || (index < 0)) {
/*  311 */       handleIllegalAttrIndex(index);
/*  312 */       return null;
/*      */     }
/*  314 */     Attr attr = (Attr)this.mAttrList.get(index);
/*  315 */     return safeGetLocalName(attr);
/*      */   }
/*      */   
/*      */   public QName getAttributeName(int index)
/*      */   {
/*  320 */     if (this.mCurrEvent != 1) {
/*  321 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/*  323 */     if (this.mAttrList == null) {
/*  324 */       calcNsAndAttrLists(true);
/*      */     }
/*  326 */     if ((index >= this.mAttrList.size()) || (index < 0)) {
/*  327 */       handleIllegalAttrIndex(index);
/*  328 */       return null;
/*      */     }
/*  330 */     Attr attr = (Attr)this.mAttrList.get(index);
/*  331 */     return constructQName(attr.getNamespaceURI(), safeGetLocalName(attr), attr.getPrefix());
/*      */   }
/*      */   
/*      */ 
/*      */   public String getAttributeNamespace(int index)
/*      */   {
/*  337 */     if (this.mCurrEvent != 1) {
/*  338 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/*  340 */     if (this.mAttrList == null) {
/*  341 */       calcNsAndAttrLists(true);
/*      */     }
/*  343 */     if ((index >= this.mAttrList.size()) || (index < 0)) {
/*  344 */       handleIllegalAttrIndex(index);
/*  345 */       return null;
/*      */     }
/*  347 */     Attr attr = (Attr)this.mAttrList.get(index);
/*  348 */     return attr.getNamespaceURI();
/*      */   }
/*      */   
/*      */   public String getAttributePrefix(int index)
/*      */   {
/*  353 */     if (this.mCurrEvent != 1) {
/*  354 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/*  356 */     if (this.mAttrList == null) {
/*  357 */       calcNsAndAttrLists(true);
/*      */     }
/*  359 */     if ((index >= this.mAttrList.size()) || (index < 0)) {
/*  360 */       handleIllegalAttrIndex(index);
/*  361 */       return null;
/*      */     }
/*  363 */     Attr attr = (Attr)this.mAttrList.get(index);
/*  364 */     return attr.getPrefix();
/*      */   }
/*      */   
/*      */   public String getAttributeType(int index)
/*      */   {
/*  369 */     if (this.mCurrEvent != 1) {
/*  370 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/*  372 */     if (this.mAttrList == null) {
/*  373 */       calcNsAndAttrLists(true);
/*      */     }
/*  375 */     if ((index >= this.mAttrList.size()) || (index < 0)) {
/*  376 */       handleIllegalAttrIndex(index);
/*  377 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  393 */     return "CDATA";
/*      */   }
/*      */   
/*      */   public String getAttributeValue(int index)
/*      */   {
/*  398 */     if (this.mCurrEvent != 1) {
/*  399 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/*  401 */     if (this.mAttrList == null) {
/*  402 */       calcNsAndAttrLists(true);
/*      */     }
/*  404 */     if ((index >= this.mAttrList.size()) || (index < 0)) {
/*  405 */       handleIllegalAttrIndex(index);
/*  406 */       return null;
/*      */     }
/*  408 */     Attr attr = (Attr)this.mAttrList.get(index);
/*  409 */     return attr.getValue();
/*      */   }
/*      */   
/*      */   public String getAttributeValue(String nsURI, String localName)
/*      */   {
/*  414 */     if (this.mCurrEvent != 1) {
/*  415 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/*  417 */     Element elem = (Element)this.mCurrNode;
/*  418 */     NamedNodeMap attrs = elem.getAttributes();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  424 */     if ((nsURI != null) && (nsURI.length() == 0)) {
/*  425 */       nsURI = null;
/*      */     }
/*  427 */     Attr attr = (Attr)attrs.getNamedItemNS(nsURI, localName);
/*  428 */     return attr == null ? null : attr.getValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getElementText()
/*      */     throws XMLStreamException
/*      */   {
/*  445 */     if (this.mCurrEvent != 1) {
/*  446 */       throwParseError(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     for (;;)
/*      */     {
/*  453 */       int type = next();
/*  454 */       if (type == 2) {
/*      */         break;
/*      */       }
/*  457 */       if ((type != 5) && (type != 3))
/*      */       {
/*      */ 
/*  460 */         if ((1 << type & 0x1250) == 0) {
/*  461 */           throwParseError("Expected a text token, got " + ErrorConsts.tokenTypeDesc(type) + ".");
/*      */         }
/*  463 */         this.mTextBuffer.addText(getText());
/*      */       } }
/*  465 */     return this.mTextBuffer.getAndClear();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getEventType()
/*      */   {
/*  474 */     return this.mCurrEvent;
/*      */   }
/*      */   
/*      */   public String getLocalName()
/*      */   {
/*  479 */     if ((this.mCurrEvent == 1) || (this.mCurrEvent == 2)) {
/*  480 */       return safeGetLocalName(this.mCurrNode);
/*      */     }
/*  482 */     if (this.mCurrEvent == 9) {
/*  483 */       return this.mCurrNode.getNodeName();
/*      */     }
/*  485 */     throw new IllegalStateException("Current state (" + ErrorConsts.tokenTypeDesc(this.mCurrEvent) + ") not START_ELEMENT, END_ELEMENT or ENTITY_REFERENCE");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public QName getName()
/*      */   {
/*  492 */     if ((this.mCurrEvent != 1) && (this.mCurrEvent != 2)) {
/*  493 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_ELEM);
/*      */     }
/*  495 */     return constructQName(this.mCurrNode.getNamespaceURI(), safeGetLocalName(this.mCurrNode), this.mCurrNode.getPrefix());
/*      */   }
/*      */   
/*      */ 
/*      */   public NamespaceContext getNamespaceContext()
/*      */   {
/*  501 */     return this;
/*      */   }
/*      */   
/*      */   public int getNamespaceCount() {
/*  505 */     if ((this.mCurrEvent != 1) && (this.mCurrEvent != 2)) {
/*  506 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_ELEM);
/*      */     }
/*  508 */     if (this.mNsDeclList == null) {
/*  509 */       if (!this.mNsAware) {
/*  510 */         return 0;
/*      */       }
/*  512 */       calcNsAndAttrLists(this.mCurrEvent == 1);
/*      */     }
/*  514 */     return this.mNsDeclList.size() / 2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getNamespacePrefix(int index)
/*      */   {
/*  523 */     if ((this.mCurrEvent != 1) && (this.mCurrEvent != 2)) {
/*  524 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_ELEM);
/*      */     }
/*  526 */     if (this.mNsDeclList == null) {
/*  527 */       if (!this.mNsAware) {
/*  528 */         handleIllegalNsIndex(index);
/*      */       }
/*  530 */       calcNsAndAttrLists(this.mCurrEvent == 1);
/*      */     }
/*  532 */     if ((index < 0) || (index + index >= this.mNsDeclList.size())) {
/*  533 */       handleIllegalNsIndex(index);
/*      */     }
/*  535 */     return (String)this.mNsDeclList.get(index + index);
/*      */   }
/*      */   
/*      */   public String getNamespaceURI() {
/*  539 */     if ((this.mCurrEvent != 1) && (this.mCurrEvent != 2)) {
/*  540 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_ELEM);
/*      */     }
/*  542 */     return this.mCurrNode.getNamespaceURI();
/*      */   }
/*      */   
/*      */   public String getNamespaceURI(int index) {
/*  546 */     if ((this.mCurrEvent != 1) && (this.mCurrEvent != 2)) {
/*  547 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_ELEM);
/*      */     }
/*  549 */     if (this.mNsDeclList == null) {
/*  550 */       if (!this.mNsAware) {
/*  551 */         handleIllegalNsIndex(index);
/*      */       }
/*  553 */       calcNsAndAttrLists(this.mCurrEvent == 1);
/*      */     }
/*  555 */     if ((index < 0) || (index + index >= this.mNsDeclList.size())) {
/*  556 */       handleIllegalNsIndex(index);
/*      */     }
/*  558 */     return (String)this.mNsDeclList.get(index + index + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getPIData()
/*      */   {
/*  565 */     if (this.mCurrEvent != 3) {
/*  566 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_PI);
/*      */     }
/*  568 */     return this.mCurrNode.getNodeValue();
/*      */   }
/*      */   
/*      */   public String getPITarget() {
/*  572 */     if (this.mCurrEvent != 3) {
/*  573 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_PI);
/*      */     }
/*  575 */     return this.mCurrNode.getNodeName();
/*      */   }
/*      */   
/*      */   public String getPrefix() {
/*  579 */     if ((this.mCurrEvent != 1) && (this.mCurrEvent != 2)) {
/*  580 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_ELEM);
/*      */     }
/*  582 */     return this.mCurrNode.getPrefix();
/*      */   }
/*      */   
/*      */   public String getText()
/*      */   {
/*  587 */     if (this.mCoalescedText != null) {
/*  588 */       return this.mCoalescedText;
/*      */     }
/*  590 */     if ((1 << this.mCurrEvent & 0x1A70) == 0) {
/*  591 */       throwNotTextual(this.mCurrEvent);
/*      */     }
/*  593 */     return this.mCurrNode.getNodeValue();
/*      */   }
/*      */   
/*      */   public char[] getTextCharacters()
/*      */   {
/*  598 */     String text = getText();
/*  599 */     return text.toCharArray();
/*      */   }
/*      */   
/*      */   public int getTextCharacters(int sourceStart, char[] target, int targetStart, int len)
/*      */   {
/*  604 */     if ((1 << this.mCurrEvent & 0x1A70) == 0) {
/*  605 */       throwNotTextual(this.mCurrEvent);
/*      */     }
/*  607 */     String text = getText();
/*  608 */     if (len > text.length()) {
/*  609 */       len = text.length();
/*      */     }
/*  611 */     text.getChars(sourceStart, sourceStart + len, target, targetStart);
/*  612 */     return len;
/*      */   }
/*      */   
/*      */   public int getTextLength()
/*      */   {
/*  617 */     if ((1 << this.mCurrEvent & 0x1A70) == 0) {
/*  618 */       throwNotTextual(this.mCurrEvent);
/*      */     }
/*  620 */     return getText().length();
/*      */   }
/*      */   
/*      */   public int getTextStart()
/*      */   {
/*  625 */     if ((1 << this.mCurrEvent & 0x1A70) == 0) {
/*  626 */       throwNotTextual(this.mCurrEvent);
/*      */     }
/*  628 */     return 0;
/*      */   }
/*      */   
/*      */   public boolean hasName() {
/*  632 */     return (this.mCurrEvent == 1) || (this.mCurrEvent == 2);
/*      */   }
/*      */   
/*      */   public boolean hasNext() {
/*  636 */     return this.mCurrEvent != 8;
/*      */   }
/*      */   
/*      */   public boolean hasText() {
/*  640 */     return (1 << this.mCurrEvent & 0x1A70) != 0;
/*      */   }
/*      */   
/*      */   public boolean isAttributeSpecified(int index)
/*      */   {
/*  645 */     if (this.mCurrEvent != 1) {
/*  646 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/*  648 */     Element elem = (Element)this.mCurrNode;
/*  649 */     Attr attr = (Attr)elem.getAttributes().item(index);
/*  650 */     if (attr == null) {
/*  651 */       handleIllegalAttrIndex(index);
/*  652 */       return false;
/*      */     }
/*  654 */     return attr.getSpecified();
/*      */   }
/*      */   
/*      */   public boolean isCharacters()
/*      */   {
/*  659 */     return this.mCurrEvent == 4;
/*      */   }
/*      */   
/*      */   public boolean isEndElement() {
/*  663 */     return this.mCurrEvent == 2;
/*      */   }
/*      */   
/*      */   public boolean isStartElement() {
/*  667 */     return this.mCurrEvent == 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isWhiteSpace()
/*      */   {
/*  678 */     if ((this.mCurrEvent == 4) || (this.mCurrEvent == 12)) {
/*  679 */       String text = getText();
/*  680 */       int i = 0; for (int len = text.length(); i < len; i++)
/*      */       {
/*      */ 
/*      */ 
/*  684 */         if (text.charAt(i) > ' ') {
/*  685 */           return false;
/*      */         }
/*      */       }
/*  688 */       return true;
/*      */     }
/*  690 */     return this.mCurrEvent == 6;
/*      */   }
/*      */   
/*      */   public void require(int type, String nsUri, String localName)
/*      */     throws XMLStreamException
/*      */   {
/*  696 */     int curr = this.mCurrEvent;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  702 */     if (curr != type) {
/*  703 */       if (curr == 12) {
/*  704 */         curr = 4;
/*  705 */       } else if (curr == 6) {
/*  706 */         curr = 4;
/*      */       }
/*      */     }
/*      */     
/*  710 */     if (type != curr) {
/*  711 */       throwParseError("Expected type " + ErrorConsts.tokenTypeDesc(type) + ", current type " + ErrorConsts.tokenTypeDesc(curr));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  716 */     if (localName != null) {
/*  717 */       if ((curr != 1) && (curr != 2) && (curr != 9))
/*      */       {
/*  719 */         throwParseError("Expected non-null local name, but current token not a START_ELEMENT, END_ELEMENT or ENTITY_REFERENCE (was " + ErrorConsts.tokenTypeDesc(this.mCurrEvent) + ")");
/*      */       }
/*  721 */       String n = getLocalName();
/*  722 */       if ((n != localName) && (!n.equals(localName))) {
/*  723 */         throwParseError("Expected local name '" + localName + "'; current local name '" + n + "'.");
/*      */       }
/*      */     }
/*  726 */     if (nsUri != null) {
/*  727 */       if ((curr != 1) && (curr != 2)) {
/*  728 */         throwParseError("Expected non-null NS URI, but current token not a START_ELEMENT or END_ELEMENT (was " + ErrorConsts.tokenTypeDesc(curr) + ")");
/*      */       }
/*      */       
/*  731 */       String uri = getNamespaceURI();
/*      */       
/*  733 */       if (nsUri.length() == 0) {
/*  734 */         if ((uri != null) && (uri.length() > 0)) {
/*  735 */           throwParseError("Expected empty namespace, instead have '" + uri + "'.");
/*      */         }
/*      */       }
/*  738 */       else if ((nsUri != uri) && (!nsUri.equals(uri))) {
/*  739 */         throwParseError("Expected namespace '" + nsUri + "'; have '" + uri + "'.");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int next()
/*      */     throws XMLStreamException
/*      */   {
/*  756 */     this.mCoalescedText = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  762 */     switch (this.mCurrEvent)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */     case 7: 
/*  768 */       switch (this.mCurrNode.getNodeType())
/*      */       {
/*      */       case 9: 
/*      */       case 11: 
/*  772 */         this.mCurrNode = this.mCurrNode.getFirstChild();
/*  773 */         break;
/*      */       
/*      */ 
/*      */       case 1: 
/*  777 */         return this.mCurrEvent = 1;
/*      */       
/*      */       default: 
/*  780 */         throw new XMLStreamException("Internal error: unexpected DOM root node type " + this.mCurrNode.getNodeType() + " for node '" + this.mCurrNode + "'");
/*      */       }
/*      */       
/*      */       break;
/*      */     case 8: 
/*  785 */       throw new NoSuchElementException("Can not call next() after receiving END_DOCUMENT");
/*      */     
/*      */     case 1: 
/*  788 */       this.mDepth += 1;
/*  789 */       this.mAttrList = null;
/*      */       
/*  791 */       Node firstChild = this.mCurrNode.getFirstChild();
/*  792 */       if (firstChild == null)
/*      */       {
/*      */ 
/*      */ 
/*  796 */         return this.mCurrEvent = 2;
/*      */       }
/*  798 */       this.mNsDeclList = null;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  803 */       this.mCurrNode = firstChild;
/*  804 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 2: 
/*  809 */       this.mDepth -= 1;
/*      */       
/*  811 */       this.mAttrList = null;
/*  812 */       this.mNsDeclList = null;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  819 */       if (this.mCurrNode == this.mRootNode) {
/*  820 */         return this.mCurrEvent = 8;
/*      */       }
/*      */       
/*      */ 
/*      */       break;
/*      */     }
/*      */     
/*      */     
/*      */ 
/*  829 */     Node next = this.mCurrNode.getNextSibling();
/*      */     
/*  831 */     if (next != null) {
/*  832 */       this.mCurrNode = next;
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*  839 */       this.mCurrNode = this.mCurrNode.getParentNode();
/*  840 */       int type = this.mCurrNode.getNodeType();
/*  841 */       if (type == 1) {
/*  842 */         return this.mCurrEvent = 2;
/*      */       }
/*      */       
/*  845 */       if ((this.mCurrNode != this.mRootNode) || ((type != 9) && (type != 11)))
/*      */       {
/*  847 */         throw new XMLStreamException("Internal error: non-element parent node (" + type + ") that is not the initial root node");
/*      */       }
/*  849 */       return this.mCurrEvent = 8;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  854 */     switch (this.mCurrNode.getNodeType()) {
/*      */     case 4: 
/*  856 */       if (this.mCoalescing) {
/*  857 */         coalesceText(12);
/*      */       } else {
/*  859 */         this.mCurrEvent = 12;
/*      */       }
/*  861 */       break;
/*      */     case 8: 
/*  863 */       this.mCurrEvent = 5;
/*  864 */       break;
/*      */     case 10: 
/*  866 */       this.mCurrEvent = 11;
/*  867 */       break;
/*      */     case 1: 
/*  869 */       this.mCurrEvent = 1;
/*  870 */       break;
/*      */     case 5: 
/*  872 */       this.mCurrEvent = 9;
/*  873 */       break;
/*      */     case 7: 
/*  875 */       this.mCurrEvent = 3;
/*  876 */       break;
/*      */     case 3: 
/*  878 */       if (this.mCoalescing) {
/*  879 */         coalesceText(4);
/*      */       } else {
/*  881 */         this.mCurrEvent = 4;
/*      */       }
/*  883 */       break;
/*      */     
/*      */ 
/*      */     case 2: 
/*      */     case 6: 
/*      */     case 12: 
/*  889 */       throw new XMLStreamException("Internal error: unexpected DOM node type " + this.mCurrNode.getNodeType() + " (attr/entity/notation?), for node '" + this.mCurrNode + "'");
/*      */     case 9: case 11: 
/*      */     default: 
/*  892 */       throw new XMLStreamException("Internal error: unrecognized DOM node type " + this.mCurrNode.getNodeType() + ", for node '" + this.mCurrNode + "'");
/*      */     }
/*      */     
/*  895 */     return this.mCurrEvent;
/*      */   }
/*      */   
/*      */   public int nextTag() throws XMLStreamException
/*      */   {
/*      */     for (;;)
/*      */     {
/*  902 */       int next = next();
/*      */       
/*  904 */       switch (next) {
/*      */       case 3: 
/*      */       case 5: 
/*      */       case 6: 
/*      */         break;
/*      */       case 4: 
/*      */       case 12: 
/*  911 */         if (!isWhiteSpace())
/*      */         {
/*      */ 
/*  914 */           throwParseError("Received non-all-whitespace CHARACTERS or CDATA event in nextTag()."); }
/*  915 */         break;
/*      */       case 1: 
/*      */       case 2: 
/*  918 */         return next;
/*      */       case 7: case 8: case 9: case 10: case 11: default: 
/*  920 */         throwParseError("Received event " + ErrorConsts.tokenTypeDesc(next) + ", instead of START_ELEMENT or END_ELEMENT.");
/*      */       }
/*      */       
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws XMLStreamException
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getNamespaceURI(String prefix)
/*      */   {
/*  956 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPrefix(String namespaceURI)
/*      */   {
/*  974 */     return null;
/*      */   }
/*      */   
/*      */   public Iterator getPrefixes(String namespaceURI)
/*      */   {
/*  979 */     String prefix = getPrefix(namespaceURI);
/*  980 */     if (prefix == null) {
/*  981 */       return EmptyIterator.getInstance();
/*      */     }
/*  983 */     return new SingletonIterator(prefix);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getFeature(String name)
/*      */   {
/*  997 */     throw new IllegalArgumentException(MessageFormat.format(ErrorConsts.ERR_UNKNOWN_FEATURE, new Object[] { name }));
/*      */   }
/*      */   
/*      */ 
/*      */   public void setFeature(String name, Object value)
/*      */   {
/* 1003 */     throw new IllegalArgumentException(MessageFormat.format(ErrorConsts.ERR_UNKNOWN_FEATURE, new Object[] { name }));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isPropertySupported(String name)
/*      */   {
/* 1010 */     return this.mConfig.isPropertySupported(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setProperty(String name, Object value)
/*      */   {
/* 1025 */     if (("org.codehaus.stax2.internNames".equals(name)) || ("org.codehaus.stax2.internNsUris".equals(name)))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1031 */       if ((!(value instanceof Boolean)) || (((Boolean)value).booleanValue())) {
/* 1032 */         throw new IllegalArgumentException("DOM-based reader does not support interning of names or namespace URIs");
/*      */       }
/* 1034 */       return true;
/*      */     }
/* 1036 */     return this.mConfig.setProperty(name, value);
/*      */   }
/*      */   
/*      */ 
/*      */   public void skipElement()
/*      */     throws XMLStreamException
/*      */   {
/* 1043 */     if (this.mCurrEvent != 1) {
/* 1044 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/* 1046 */     int nesting = 1;
/*      */     for (;;)
/*      */     {
/* 1049 */       int type = next();
/* 1050 */       if (type == 1) {
/* 1051 */         nesting++;
/* 1052 */       } else if (type == 2) {
/* 1053 */         nesting--; if (nesting == 0) {
/*      */           break;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public AttributeInfo getAttributeInfo()
/*      */     throws XMLStreamException
/*      */   {
/* 1064 */     if (this.mCurrEvent != 1) {
/* 1065 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/*      */     
/* 1068 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public DTDInfo getDTDInfo()
/*      */     throws XMLStreamException
/*      */   {
/* 1082 */     if (this.mCurrEvent != 11) {
/* 1083 */       return null;
/*      */     }
/* 1085 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final LocationInfo getLocationInfo()
/*      */   {
/* 1094 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getText(Writer w, boolean preserveContents)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1124 */     if ((1 << this.mCurrEvent & 0x1A70) == 0) {
/* 1125 */       throwNotTextual(this.mCurrEvent);
/*      */     }
/* 1127 */     String text = getText();
/* 1128 */     w.write(text);
/* 1129 */     return text.length();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getDepth()
/*      */   {
/* 1139 */     return this.mDepth;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isEmptyElement()
/*      */     throws XMLStreamException
/*      */   {
/* 1150 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public NamespaceContext getNonTransientNamespaceContext()
/*      */   {
/* 1160 */     return EmptyNamespaceContext.getInstance();
/*      */   }
/*      */   
/*      */   public String getPrefixedName()
/*      */   {
/* 1165 */     switch (this.mCurrEvent)
/*      */     {
/*      */     case 1: 
/*      */     case 2: 
/* 1169 */       String prefix = getPrefix();
/* 1170 */       String ln = getLocalName();
/*      */       
/* 1172 */       if (prefix == null) {
/* 1173 */         return ln;
/*      */       }
/* 1175 */       StringBuffer sb = new StringBuffer(ln.length() + 1 + prefix.length());
/* 1176 */       sb.append(prefix);
/* 1177 */       sb.append(':');
/* 1178 */       sb.append(ln);
/* 1179 */       return sb.toString();
/*      */     
/*      */     case 9: 
/* 1182 */       return getLocalName();
/*      */     case 3: 
/* 1184 */       return getPITarget();
/*      */     case 11: 
/* 1186 */       return getDTDRootName();
/*      */     }
/*      */     
/* 1189 */     throw new IllegalStateException("Current state (" + ErrorConsts.tokenTypeDesc(this.mCurrEvent) + ") not START_ELEMENT, END_ELEMENT, ENTITY_REFERENCE, PROCESSING_INSTRUCTION or DTD");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void closeCompletely()
/*      */     throws XMLStreamException
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getProcessedDTD()
/*      */   {
/* 1204 */     return null;
/*      */   }
/*      */   
/*      */   public String getDTDRootName() {
/* 1208 */     if (this.mCurrEvent == 11) {
/* 1209 */       return ((DocumentType)this.mCurrNode).getName();
/*      */     }
/* 1211 */     return null;
/*      */   }
/*      */   
/*      */   public String getDTDPublicId() {
/* 1215 */     if (this.mCurrEvent == 11) {
/* 1216 */       return ((DocumentType)this.mCurrNode).getPublicId();
/*      */     }
/* 1218 */     return null;
/*      */   }
/*      */   
/*      */   public String getDTDSystemId() {
/* 1222 */     if (this.mCurrEvent == 11) {
/* 1223 */       return ((DocumentType)this.mCurrNode).getSystemId();
/*      */     }
/* 1225 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDTDInternalSubset()
/*      */   {
/* 1237 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public DTDValidationSchema getProcessedDTDSchema()
/*      */   {
/* 1243 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getStartingByteOffset()
/*      */   {
/* 1256 */     return -1L;
/*      */   }
/*      */   
/*      */   public long getStartingCharOffset()
/*      */   {
/* 1261 */     return 0L;
/*      */   }
/*      */   
/*      */   public long getEndingByteOffset()
/*      */     throws XMLStreamException
/*      */   {
/* 1267 */     return -1L;
/*      */   }
/*      */   
/*      */   public long getEndingCharOffset()
/*      */     throws XMLStreamException
/*      */   {
/* 1273 */     return -1L;
/*      */   }
/*      */   
/*      */ 
/*      */   public final Location getLocation()
/*      */   {
/* 1279 */     return getStartLocation();
/*      */   }
/*      */   
/*      */ 
/*      */   public XMLStreamLocation2 getStartLocation()
/*      */   {
/* 1285 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public XMLStreamLocation2 getCurrentLocation()
/*      */   {
/* 1291 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public final XMLStreamLocation2 getEndLocation()
/*      */     throws XMLStreamException
/*      */   {
/* 1298 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public XMLValidator validateAgainst(XMLValidationSchema schema)
/*      */     throws XMLStreamException
/*      */   {
/* 1311 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public XMLValidator stopValidatingAgainst(XMLValidationSchema schema)
/*      */     throws XMLStreamException
/*      */   {
/* 1318 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public XMLValidator stopValidatingAgainst(XMLValidator validator)
/*      */     throws XMLStreamException
/*      */   {
/* 1325 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public ValidationProblemHandler setValidationProblemHandler(ValidationProblemHandler h)
/*      */   {
/* 1331 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void coalesceText(int initialType)
/*      */   {
/* 1342 */     this.mTextBuffer.addText(this.mCurrNode.getNodeValue());
/*      */     
/*      */     Node n;
/* 1345 */     while ((n = this.mCurrNode.getNextSibling()) != null) {
/* 1346 */       int type = n.getNodeType();
/* 1347 */       if ((type != 3) && (type != 4)) {
/*      */         break;
/*      */       }
/* 1350 */       this.mCurrNode = n;
/* 1351 */       this.mTextBuffer.addText(this.mCurrNode.getNodeValue());
/*      */     }
/* 1353 */     this.mCoalescedText = this.mTextBuffer.getAndClear();
/*      */     
/*      */ 
/* 1356 */     this.mCurrEvent = 4;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private QName constructQName(String uri, String ln, String prefix)
/*      */   {
/* 1368 */     return new QName(uri == null ? "" : uri, ln, prefix == null ? "" : prefix);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void calcNsAndAttrLists(boolean attrsToo)
/*      */   {
/* 1378 */     NamedNodeMap attrsIn = this.mCurrNode.getAttributes();
/*      */     
/*      */ 
/* 1381 */     int len = attrsIn.getLength();
/* 1382 */     if (len == 0) {
/* 1383 */       this.mAttrList = (this.mNsDeclList = Collections.EMPTY_LIST);
/* 1384 */       return;
/*      */     }
/*      */     
/* 1387 */     if (!this.mNsAware) {
/* 1388 */       this.mAttrList = new ArrayList(len);
/* 1389 */       for (int i = 0; i < len; i++) {
/* 1390 */         this.mAttrList.add(attrsIn.item(i));
/*      */       }
/* 1392 */       this.mNsDeclList = Collections.EMPTY_LIST;
/* 1393 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1397 */     ArrayList attrsOut = null;
/* 1398 */     ArrayList nsOut = null;
/*      */     
/* 1400 */     for (int i = 0; i < len; i++) {
/* 1401 */       Node attr = attrsIn.item(i);
/* 1402 */       String prefix = attr.getPrefix();
/*      */       
/*      */ 
/* 1405 */       if ((prefix == null) || (prefix.length() == 0))
/*      */       {
/* 1407 */         if (!"xmlns".equals(attr.getLocalName())) {
/* 1408 */           if (!attrsToo) continue;
/* 1409 */           if (attrsOut == null) {
/* 1410 */             attrsOut = new ArrayList(len - i);
/*      */           }
/* 1412 */           attrsOut.add(attr); continue;
/*      */         }
/*      */         
/*      */ 
/* 1416 */         prefix = "";
/*      */       } else {
/* 1418 */         if (!"xmlns".equals(prefix)) {
/* 1419 */           if (!attrsToo) continue;
/* 1420 */           if (attrsOut == null) {
/* 1421 */             attrsOut = new ArrayList(len - i);
/*      */           }
/* 1423 */           attrsOut.add(attr); continue;
/*      */         }
/*      */         
/*      */ 
/* 1427 */         prefix = attr.getLocalName();
/*      */       }
/* 1429 */       if (nsOut == null) {
/* 1430 */         nsOut = new ArrayList((len - i) * 2);
/*      */       }
/* 1432 */       nsOut.add(prefix);
/* 1433 */       nsOut.add(attr.getNodeValue());
/*      */     }
/*      */     
/* 1436 */     this.mAttrList = (attrsOut == null ? Collections.EMPTY_LIST : attrsOut);
/* 1437 */     this.mNsDeclList = (nsOut == null ? Collections.EMPTY_LIST : nsOut);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected WstxInputLocation getLastCharLocation()
/*      */   {
/* 1448 */     return null;
/*      */   }
/*      */   
/*      */   private void throwNotTextual(int type)
/*      */   {
/* 1453 */     throw new IllegalStateException("Not a textual event (" + ErrorConsts.tokenTypeDesc(this.mCurrEvent) + ")");
/*      */   }
/*      */   
/*      */ 
/*      */   private void throwParseError(String msg)
/*      */     throws WstxParsingException
/*      */   {
/* 1460 */     throw new WstxParsingException(msg, getLastCharLocation());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void handleIllegalAttrIndex(int index)
/*      */   {
/* 1474 */     Element elem = (Element)this.mCurrNode;
/* 1475 */     NamedNodeMap attrs = elem.getAttributes();
/* 1476 */     int len = attrs.getLength();
/* 1477 */     String msg = "Illegal attribute index " + index + "; element <" + elem.getNodeName() + "> has " + (len == 0 ? "no" : String.valueOf(len)) + " attributes";
/* 1478 */     throw new IllegalArgumentException(msg);
/*      */   }
/*      */   
/*      */   private void handleIllegalNsIndex(int index)
/*      */   {
/* 1483 */     String msg = "Illegal namespace declaration index " + index + " (has " + getNamespaceCount() + " ns declarations)";
/* 1484 */     throw new IllegalArgumentException(msg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String safeGetLocalName(Node n)
/*      */   {
/* 1496 */     String ln = n.getLocalName();
/* 1497 */     if (ln == null) {
/* 1498 */       ln = n.getNodeName();
/*      */     }
/* 1500 */     return ln;
/*      */   }
/*      */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dom\DOMWrappingReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */