/*      */ package com.ctc.wstx.sr;
/*      */ 
/*      */ import com.ctc.wstx.api.ReaderConfig;
/*      */ import com.ctc.wstx.cfg.ErrorConsts;
/*      */ import com.ctc.wstx.cfg.InputConfigFlags;
/*      */ import com.ctc.wstx.cfg.ParsingErrorMsgs;
/*      */ import com.ctc.wstx.compat.JdkFeatures;
/*      */ import com.ctc.wstx.compat.JdkImpl;
/*      */ import com.ctc.wstx.ent.EntityDecl;
/*      */ import com.ctc.wstx.exc.WstxEOFException;
/*      */ import com.ctc.wstx.exc.WstxException;
/*      */ import com.ctc.wstx.exc.WstxIOException;
/*      */ import com.ctc.wstx.exc.WstxLazyException;
/*      */ import com.ctc.wstx.exc.WstxParsingException;
/*      */ import com.ctc.wstx.exc.WstxUnexpectedCharException;
/*      */ import com.ctc.wstx.exc.WstxValidationException;
/*      */ import com.ctc.wstx.io.DefaultInputResolver;
/*      */ import com.ctc.wstx.io.WstxInputData;
/*      */ import com.ctc.wstx.io.WstxInputLocation;
/*      */ import com.ctc.wstx.io.WstxInputSource;
/*      */ import com.ctc.wstx.util.ExceptionUtil;
/*      */ import com.ctc.wstx.util.SymbolTable;
/*      */ import com.ctc.wstx.util.TextBuffer;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.net.URL;
/*      */ import java.text.MessageFormat;
/*      */ import javax.xml.stream.Location;
/*      */ import javax.xml.stream.XMLReporter;
/*      */ import javax.xml.stream.XMLResolver;
/*      */ import javax.xml.stream.XMLStreamException;
/*      */ import org.codehaus.stax2.XMLStreamLocation2;
/*      */ import org.codehaus.stax2.validation.XMLValidationException;
/*      */ import org.codehaus.stax2.validation.XMLValidationProblem;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class StreamScanner
/*      */   extends WstxInputData
/*      */   implements InputProblemReporter, InputConfigFlags, ParsingErrorMsgs
/*      */ {
/*      */   public static final boolean SAX_COMPAT_MODE = false;
/*      */   public static final char CHAR_CR_LF_OR_NULL = '\r';
/*      */   public static final int INT_CR_LF_OR_NULL = 13;
/*      */   protected static final char CHAR_FIRST_PURE_TEXT = '?';
/*      */   protected static final char CHAR_LOWEST_LEGAL_LOCALNAME_CHAR = '-';
/*      */   private static final int VALID_CHAR_COUNT = 256;
/*      */   private static final byte NAME_CHAR_INVALID_B = 0;
/*      */   private static final byte NAME_CHAR_ALL_VALID_B = 1;
/*      */   private static final byte NAME_CHAR_VALID_NONFIRST_B = -1;
/*      */   private static final int NAME_CHAR_INVALID_I = 0;
/*      */   private static final int NAME_CHAR_ALL_VALID_I = 1;
/*      */   private static final int NAME_CHAR_VALID_NONFIRST_I = -1;
/*  113 */   private static final byte[] sCharValidity = new byte['Ā'];
/*      */   private static final int VALID_PUBID_CHAR_COUNT = 128;
/*      */   private static final byte[] sPubidValidity;
/*      */   private static final byte PUBID_CHAR_INVALID_B = 0;
/*      */   
/*      */   static {
/*  119 */     sCharValidity[95] = 1;
/*  120 */     int i = 0; for (int last = 25; i <= last; i++) {
/*  121 */       sCharValidity[(65 + i)] = 1;
/*  122 */       sCharValidity[(97 + i)] = 1;
/*      */     }
/*  124 */     for (int i = 192; i < 246; i++) {
/*  125 */       sCharValidity[i] = 1;
/*      */     }
/*      */     
/*  128 */     sCharValidity['×'] = 0;
/*  129 */     sCharValidity['÷'] = 0;
/*      */     
/*      */ 
/*      */ 
/*  133 */     sCharValidity[45] = -1;
/*  134 */     sCharValidity[46] = -1;
/*  135 */     sCharValidity['·'] = -1;
/*  136 */     for (int i = 48; i <= 57; i++) {
/*  137 */       sCharValidity[i] = -1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  145 */     sPubidValidity = new byte[''];
/*      */     
/*      */ 
/*      */ 
/*  149 */     int i = 0; for (int last = 25; i <= last; i++) {
/*  150 */       sPubidValidity[(65 + i)] = 1;
/*  151 */       sPubidValidity[(97 + i)] = 1;
/*      */     }
/*  153 */     for (int i = 48; i <= 57; i++) {
/*  154 */       sPubidValidity[i] = 1;
/*      */     }
/*      */     
/*      */ 
/*  158 */     sPubidValidity[10] = 1;
/*  159 */     sPubidValidity[13] = 1;
/*  160 */     sPubidValidity[32] = 1;
/*      */     
/*      */ 
/*  163 */     sPubidValidity[45] = 1;
/*  164 */     sPubidValidity[39] = 1;
/*  165 */     sPubidValidity[40] = 1;
/*  166 */     sPubidValidity[41] = 1;
/*  167 */     sPubidValidity[43] = 1;
/*  168 */     sPubidValidity[44] = 1;
/*  169 */     sPubidValidity[46] = 1;
/*  170 */     sPubidValidity[47] = 1;
/*  171 */     sPubidValidity[58] = 1;
/*  172 */     sPubidValidity[61] = 1;
/*  173 */     sPubidValidity[63] = 1;
/*  174 */     sPubidValidity[59] = 1;
/*  175 */     sPubidValidity[33] = 1;
/*  176 */     sPubidValidity[42] = 1;
/*  177 */     sPubidValidity[35] = 1;
/*  178 */     sPubidValidity[64] = 1;
/*  179 */     sPubidValidity[36] = 1;
/*  180 */     sPubidValidity[95] = 1;
/*  181 */     sPubidValidity[37] = 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final byte PUBID_CHAR_VALID_B = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final ReaderConfig mConfig;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final boolean mCfgNsEnabled;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean mCfgReplaceEntities;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean mCfgNormalizeLFs;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final SymbolTable mSymbols;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String mCurrName;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected WstxInputSource mInput;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final WstxInputSource mRootInput;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  269 */   XMLResolver mEntityResolver = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  282 */   protected int mCurrDepth = 0;
/*      */   
/*  284 */   protected int mInputTopDepth = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  296 */   protected char[] mNameBuffer = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  312 */   protected long mTokenInputTotal = 0L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  317 */   protected int mTokenInputRow = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  323 */   protected int mTokenInputCol = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  337 */   String mDocInputEncoding = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  343 */   String mDocXmlEncoding = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  349 */   protected int mDocXmlVersion = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected StreamScanner(WstxInputSource input, ReaderConfig cfg, XMLResolver res)
/*      */   {
/*  365 */     this.mInput = input;
/*      */     
/*  367 */     this.mRootInput = input;
/*      */     
/*  369 */     this.mConfig = cfg;
/*  370 */     this.mSymbols = cfg.getSymbols();
/*  371 */     int cf = cfg.getConfigFlags();
/*  372 */     this.mCfgNsEnabled = ((cf & 0x1) != 0);
/*  373 */     this.mCfgReplaceEntities = ((cf & 0x4) != 0);
/*  374 */     this.mCfgNormalizeLFs = ((cf & 0x2000) != 0);
/*      */     
/*  376 */     this.mInputBuffer = null;
/*  377 */     this.mInputPtr = (this.mInputLen = 0);
/*  378 */     this.mEntityResolver = res;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected WstxInputLocation getLastCharLocation()
/*      */   {
/*  394 */     return this.mInput.getLocation(this.mCurrInputProcessed + this.mInputPtr - 1L, this.mCurrInputRow, this.mInputPtr - this.mCurrInputRowStart);
/*      */   }
/*      */   
/*      */ 
/*      */   protected URL getSource()
/*      */   {
/*  400 */     return this.mInput.getSource();
/*      */   }
/*      */   
/*      */   protected String getSystemId() {
/*  404 */     return this.mInput.getSystemId();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public XMLStreamLocation2 getStartLocation()
/*      */   {
/*  424 */     return this.mInput.getLocation(this.mTokenInputTotal, this.mTokenInputRow, this.mTokenInputCol + 1);
/*      */   }
/*      */   
/*      */ 
/*      */   public XMLStreamLocation2 getCurrentLocation()
/*      */   {
/*  430 */     return this.mInput.getLocation(this.mCurrInputProcessed + this.mInputPtr, this.mCurrInputRow, this.mInputPtr - this.mCurrInputRowStart + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WstxException throwWfcException(String msg, boolean deferErrors)
/*      */     throws WstxException
/*      */   {
/*  444 */     WstxException ex = constructWfcException(msg);
/*  445 */     if (!deferErrors) {
/*  446 */       throw ex;
/*      */     }
/*  448 */     return ex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void throwParseError(String msg)
/*      */     throws WstxException
/*      */   {
/*  461 */     throw constructWfcException(msg);
/*      */   }
/*      */   
/*      */   public void throwParseError(String format, Object arg)
/*      */     throws WstxException
/*      */   {
/*  467 */     throw constructWfcException(MessageFormat.format(format, new Object[] { arg }));
/*      */   }
/*      */   
/*      */   public void throwParseError(String format, Object arg, Object arg2)
/*      */     throws WstxException
/*      */   {
/*  473 */     throw constructWfcException(MessageFormat.format(format, new Object[] { arg, arg2 }));
/*      */   }
/*      */   
/*      */   public void reportProblem(String probType, String msg)
/*      */   {
/*  478 */     doReportProblem(this.mConfig.getXMLReporter(), probType, msg, null);
/*      */   }
/*      */   
/*      */   public void reportProblem(String probType, String format, Object arg)
/*      */   {
/*  483 */     XMLReporter rep = this.mConfig.getXMLReporter();
/*  484 */     if (rep != null) {
/*  485 */       doReportProblem(rep, probType, MessageFormat.format(format, new Object[] { arg }), null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void reportProblem(String probType, String format, Object arg, Object arg2)
/*      */   {
/*  494 */     XMLReporter rep = this.mConfig.getXMLReporter();
/*  495 */     if (rep != null) {
/*  496 */       doReportProblem(rep, probType, MessageFormat.format(format, new Object[] { arg, arg2 }), null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void reportProblem(String probType, String format, Object arg, Object arg2, Location loc)
/*      */   {
/*  505 */     XMLReporter rep = this.mConfig.getXMLReporter();
/*  506 */     if (rep != null) {
/*  507 */       doReportProblem(rep, probType, MessageFormat.format(format, new Object[] { arg, arg2 }), loc);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void doReportProblem(XMLReporter rep, String probType, String msg, Location loc)
/*      */   {
/*  515 */     if (loc == null) {
/*  516 */       loc = getLastCharLocation();
/*      */     }
/*  518 */     doReportProblem(rep, new XMLValidationProblem(loc, msg, 2), probType);
/*      */   }
/*      */   
/*      */ 
/*      */   protected void doReportProblem(XMLReporter rep, XMLValidationProblem prob, String probType)
/*      */   {
/*  524 */     if (rep != null) {
/*  525 */       Location loc = prob.getLocation();
/*  526 */       if (loc == null) {
/*  527 */         loc = getLastCharLocation();
/*      */       }
/*      */       try {
/*  530 */         rep.report(prob.getMessage(), probType, prob, loc);
/*      */ 
/*      */       }
/*      */       catch (XMLStreamException e)
/*      */       {
/*      */ 
/*  536 */         System.err.println("Internal error - problem reporting a problem: " + e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void reportValidationProblem(XMLValidationProblem prob)
/*      */     throws XMLValidationException
/*      */   {
/*  561 */     if (prob.getSeverity() > 2) {
/*  562 */       throw WstxValidationException.create(prob);
/*      */     }
/*  564 */     XMLReporter rep = this.mConfig.getXMLReporter();
/*  565 */     if (rep != null) {
/*  566 */       doReportProblem(rep, ErrorConsts.WT_VALIDATION, prob.getMessage(), prob.getLocation());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*  572 */     else if (prob.getSeverity() >= 2) {
/*  573 */       throw WstxValidationException.create(prob);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void reportValidationProblem(String msg, Location loc, int severity)
/*      */     throws XMLValidationException
/*      */   {
/*  581 */     reportValidationProblem(new XMLValidationProblem(loc, msg, severity));
/*      */   }
/*      */   
/*      */   public void reportValidationProblem(String msg, int severity)
/*      */     throws XMLValidationException
/*      */   {
/*  587 */     reportValidationProblem(new XMLValidationProblem(getLastCharLocation(), msg, severity));
/*      */   }
/*      */   
/*      */ 
/*      */   public void reportValidationProblem(String msg)
/*      */     throws XMLValidationException
/*      */   {
/*  594 */     reportValidationProblem(new XMLValidationProblem(getLastCharLocation(), msg, 2));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void reportValidationProblem(Location loc, String msg)
/*      */     throws XMLValidationException
/*      */   {
/*  602 */     reportValidationProblem(new XMLValidationProblem(getLastCharLocation(), msg));
/*      */   }
/*      */   
/*      */ 
/*      */   public void reportValidationProblem(String format, Object arg)
/*      */     throws XMLValidationException
/*      */   {
/*  609 */     String msg = MessageFormat.format(format, new Object[] { arg });
/*  610 */     reportValidationProblem(new XMLValidationProblem(getLastCharLocation(), msg));
/*      */   }
/*      */   
/*      */ 
/*      */   public void reportValidationProblem(String format, Object arg, Object arg2)
/*      */     throws XMLValidationException
/*      */   {
/*  617 */     String msg = MessageFormat.format(format, new Object[] { arg, arg2 });
/*  618 */     reportValidationProblem(new XMLValidationProblem(getLastCharLocation(), msg));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected WstxException constructWfcException(String msg)
/*      */   {
/*  630 */     return new WstxParsingException(msg, getLastCharLocation());
/*      */   }
/*      */   
/*      */   protected WstxException constructFromIoe(IOException ioe)
/*      */   {
/*  635 */     return new WstxIOException(ioe);
/*      */   }
/*      */   
/*      */   protected WstxException constructNullCharException()
/*      */   {
/*  640 */     return new WstxUnexpectedCharException("Illegal character (NULL, unicode 0) encountered: not valid in any content", getLastCharLocation(), '\000');
/*      */   }
/*      */   
/*      */   protected void throwUnexpectedChar(int i, String msg)
/*      */     throws WstxException
/*      */   {
/*  646 */     char c = (char)i;
/*  647 */     String excMsg = "Unexpected character " + getCharDesc(c) + msg;
/*  648 */     throw new WstxUnexpectedCharException(excMsg, getLastCharLocation(), c);
/*      */   }
/*      */   
/*      */   protected void throwNullChar()
/*      */     throws WstxException
/*      */   {
/*  654 */     throw constructNullCharException();
/*      */   }
/*      */   
/*      */   protected void throwInvalidSpace(int i)
/*      */     throws WstxException
/*      */   {
/*  660 */     throwInvalidSpace(i, false);
/*      */   }
/*      */   
/*      */   protected WstxException throwInvalidSpace(int i, boolean deferErrors)
/*      */     throws WstxException
/*      */   {
/*  666 */     char c = (char)i;
/*      */     WstxException ex;
/*  668 */     WstxException ex; if (c == 0) {
/*  669 */       ex = constructNullCharException();
/*      */     } else {
/*  671 */       String msg = "Illegal character (" + getCharDesc(c) + ")";
/*  672 */       if (this.mXml11) {
/*  673 */         msg = msg + " [note: in XML 1.1, it could be included via entity expansion]";
/*      */       }
/*  675 */       ex = new WstxUnexpectedCharException(msg, getLastCharLocation(), c);
/*      */     }
/*  677 */     if (!deferErrors) {
/*  678 */       throw ex;
/*      */     }
/*  680 */     return ex;
/*      */   }
/*      */   
/*      */   protected void throwUnexpectedEOF(String msg)
/*      */     throws WstxException
/*      */   {
/*  686 */     throw new WstxEOFException("Unexpected EOF" + (msg == null ? "" : msg), getLastCharLocation());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void throwUnexpectedEOB(String msg)
/*      */     throws WstxException
/*      */   {
/*  700 */     throw new WstxEOFException("Unexpected end of input block" + (msg == null ? "" : msg), getLastCharLocation());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void throwFromIOE(IOException ioe)
/*      */     throws WstxException
/*      */   {
/*  708 */     throw new WstxIOException(ioe);
/*      */   }
/*      */   
/*      */   protected void throwFromStrE(XMLStreamException strex)
/*      */     throws WstxException
/*      */   {
/*  714 */     if ((strex instanceof WstxException)) {
/*  715 */       throw ((WstxException)strex);
/*      */     }
/*  717 */     WstxException newEx = new WstxException(strex);
/*  718 */     JdkFeatures.getInstance().setInitCause(newEx, strex);
/*  719 */     throw newEx;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void throwLazyError(Exception e)
/*      */   {
/*  728 */     if ((e instanceof XMLStreamException)) {
/*  729 */       WstxLazyException.throwLazily((XMLStreamException)e);
/*      */     }
/*  731 */     ExceptionUtil.throwRuntimeException(e);
/*      */   }
/*      */   
/*      */   protected String tokenTypeDesc(int type)
/*      */   {
/*  736 */     return ErrorConsts.tokenTypeDesc(type);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final WstxInputSource getCurrentInput()
/*      */   {
/*  752 */     return this.mInput;
/*      */   }
/*      */   
/*      */   protected final int inputInBuffer() {
/*  756 */     return this.mInputLen - this.mInputPtr;
/*      */   }
/*      */   
/*      */   protected final int getNext()
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  762 */     if ((this.mInputPtr >= this.mInputLen) && 
/*  763 */       (!loadMore())) {
/*  764 */       return -1;
/*      */     }
/*      */     
/*  767 */     return this.mInputBuffer[(this.mInputPtr++)];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final int peekNext()
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  782 */     if ((this.mInputPtr >= this.mInputLen) && 
/*  783 */       (!loadMoreFromCurrent())) {
/*  784 */       return -1;
/*      */     }
/*      */     
/*  787 */     return this.mInputBuffer[this.mInputPtr];
/*      */   }
/*      */   
/*      */   protected final char getNextChar(String errorMsg)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  793 */     if (this.mInputPtr >= this.mInputLen) {
/*  794 */       loadMore(errorMsg);
/*      */     }
/*  796 */     return this.mInputBuffer[(this.mInputPtr++)];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final char getNextCharFromCurrent(String errorMsg)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  810 */     if (this.mInputPtr >= this.mInputLen) {
/*  811 */       loadMoreFromCurrent(errorMsg);
/*      */     }
/*  813 */     return this.mInputBuffer[(this.mInputPtr++)];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final int getNextAfterWS()
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  824 */     if ((this.mInputPtr >= this.mInputLen) && 
/*  825 */       (!loadMore())) {
/*  826 */       return -1;
/*      */     }
/*      */     
/*  829 */     char c = this.mInputBuffer[(this.mInputPtr++)];
/*  830 */     while (c <= ' ')
/*      */     {
/*  832 */       if ((c == '\n') || (c == '\r')) {
/*  833 */         skipCRLF(c);
/*  834 */       } else if ((c != ' ') && (c != '\t')) {
/*  835 */         throwInvalidSpace(c);
/*      */       }
/*      */       
/*  838 */       if ((this.mInputPtr >= this.mInputLen) && 
/*  839 */         (!loadMore())) {
/*  840 */         return -1;
/*      */       }
/*      */       
/*  843 */       c = this.mInputBuffer[(this.mInputPtr++)];
/*      */     }
/*  845 */     return c;
/*      */   }
/*      */   
/*      */   protected final char getNextCharAfterWS(String errorMsg)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  851 */     if (this.mInputPtr >= this.mInputLen) {
/*  852 */       loadMore(errorMsg);
/*      */     }
/*      */     
/*  855 */     char c = this.mInputBuffer[(this.mInputPtr++)];
/*  856 */     while (c <= ' ')
/*      */     {
/*  858 */       if ((c == '\n') || (c == '\r')) {
/*  859 */         skipCRLF(c);
/*  860 */       } else if ((c != ' ') && (c != '\t')) {
/*  861 */         throwInvalidSpace(c);
/*      */       }
/*      */       
/*      */ 
/*  865 */       if (this.mInputPtr >= this.mInputLen) {
/*  866 */         loadMore(errorMsg);
/*      */       }
/*  868 */       c = this.mInputBuffer[(this.mInputPtr++)];
/*      */     }
/*  870 */     return c;
/*      */   }
/*      */   
/*      */   protected final char getNextInCurrAfterWS(String errorMsg)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  876 */     return getNextInCurrAfterWS(errorMsg, getNextCharFromCurrent(errorMsg));
/*      */   }
/*      */   
/*      */   protected final char getNextInCurrAfterWS(String errorMsg, char c)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  882 */     while (c <= ' ')
/*      */     {
/*  884 */       if ((c == '\n') || (c == '\r')) {
/*  885 */         skipCRLF(c);
/*  886 */       } else if ((c != ' ') && (c != '\t')) {
/*  887 */         throwInvalidSpace(c);
/*      */       }
/*      */       
/*      */ 
/*  891 */       if (this.mInputPtr >= this.mInputLen) {
/*  892 */         loadMoreFromCurrent(errorMsg);
/*      */       }
/*  894 */       c = this.mInputBuffer[(this.mInputPtr++)];
/*      */     }
/*  896 */     return c;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final boolean skipCRLF(char c)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*      */     boolean result;
/*      */     
/*      */ 
/*      */ 
/*      */     boolean result;
/*      */     
/*      */ 
/*  912 */     if ((c == '\r') && (peekNext() == 10)) {
/*  913 */       this.mInputPtr += 1;
/*  914 */       result = true;
/*      */     } else {
/*  916 */       result = false;
/*      */     }
/*  918 */     this.mCurrInputRow += 1;
/*  919 */     this.mCurrInputRowStart = this.mInputPtr;
/*  920 */     return result;
/*      */   }
/*      */   
/*      */   protected final void markLF() {
/*  924 */     this.mCurrInputRow += 1;
/*  925 */     this.mCurrInputRowStart = this.mInputPtr;
/*      */   }
/*      */   
/*      */   protected final void markLF(int inputPtr) {
/*  929 */     this.mCurrInputRow += 1;
/*  930 */     this.mCurrInputRowStart = inputPtr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void pushback()
/*      */   {
/*  938 */     this.mInputPtr -= 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void initInputSource(WstxInputSource newInput, boolean isExt)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  954 */     this.mInput = newInput;
/*      */     
/*  956 */     this.mInputPtr = 0;
/*  957 */     this.mInputLen = 0;
/*      */     
/*      */ 
/*      */ 
/*  961 */     this.mInputTopDepth = this.mCurrDepth;
/*  962 */     this.mInput.initInputLocation(this, this.mCurrDepth);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  967 */     if (isExt) {
/*  968 */       this.mCfgNormalizeLFs = this.mConfig.willNormalizeLFs();
/*      */     } else {
/*  970 */       this.mCfgNormalizeLFs = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean loadMore()
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  984 */     WstxInputSource input = this.mInput;
/*      */     
/*      */ 
/*      */ 
/*      */     do
/*      */     {
/*  990 */       this.mCurrInputProcessed += this.mInputLen;
/*  991 */       this.mCurrInputRowStart -= this.mInputLen;
/*  992 */       int count = input.readInto(this);
/*  993 */       if (count > 0) {
/*  994 */         return true;
/*      */       }
/*  996 */       input.close();
/*  997 */       if (input == this.mRootInput)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1002 */         return false;
/*      */       }
/* 1004 */       WstxInputSource parent = input.getParent();
/* 1005 */       if (parent == null) {
/* 1006 */         throwNullParent(input);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1011 */       if (this.mCurrDepth != input.getScopeId()) {
/* 1012 */         handleIncompleteEntityProblem(input);
/*      */       }
/*      */       
/* 1015 */       this.mInput = (input = parent);
/* 1016 */       input.restoreContext(this);
/* 1017 */       this.mInputTopDepth = input.getScopeId();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1022 */       if (this.mCfgNormalizeLFs != this.mConfig.willNormalizeLFs()) {
/* 1023 */         this.mCfgNormalizeLFs = (!input.fromInternalEntity());
/*      */       }
/*      */       
/* 1026 */     } while (this.mInputPtr >= this.mInputLen);
/*      */     
/* 1028 */     return true;
/*      */   }
/*      */   
/*      */   protected final boolean loadMore(String errorMsg)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1034 */     if (!loadMore()) {
/* 1035 */       throwUnexpectedEOF(errorMsg);
/*      */     }
/* 1037 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */   protected boolean loadMoreFromCurrent()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1044 */     this.mCurrInputProcessed += this.mInputLen;
/* 1045 */     this.mCurrInputRowStart -= this.mInputLen;
/* 1046 */     int count = this.mInput.readInto(this);
/* 1047 */     return count > 0;
/*      */   }
/*      */   
/*      */   protected final boolean loadMoreFromCurrent(String errorMsg)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1053 */     if (!loadMoreFromCurrent()) {
/* 1054 */       throwUnexpectedEOB(errorMsg);
/*      */     }
/* 1056 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean ensureInput(int minAmount)
/*      */     throws IOException
/*      */   {
/* 1076 */     int currAmount = this.mInputLen - this.mInputPtr;
/* 1077 */     if (currAmount >= minAmount) {
/* 1078 */       return true;
/*      */     }
/* 1080 */     return this.mInput.readMore(this, minAmount);
/*      */   }
/*      */   
/*      */   protected void closeAllInput(boolean force)
/*      */     throws XMLStreamException
/*      */   {
/* 1086 */     WstxInputSource input = this.mInput;
/*      */     for (;;) {
/*      */       try {
/* 1089 */         if (force) {
/* 1090 */           input.closeCompletely();
/*      */         } else {
/* 1092 */           input.close();
/*      */         }
/*      */       } catch (IOException ie) {
/* 1095 */         throwFromIOE(ie);
/*      */       }
/* 1097 */       if (input == this.mRootInput) {
/*      */         break;
/*      */       }
/* 1100 */       WstxInputSource parent = input.getParent();
/* 1101 */       if (parent == null) {
/* 1102 */         throwNullParent(input);
/*      */       }
/* 1104 */       this.mInput = (input = parent);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void throwNullParent(WstxInputSource curr)
/*      */   {
/* 1110 */     throw new Error(ErrorConsts.ERR_INTERNAL);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected char resolveSimpleEntity(boolean checkStd)
/*      */     throws XMLStreamException
/*      */   {
/* 1149 */     char[] buf = this.mInputBuffer;
/* 1150 */     int ptr = this.mInputPtr;
/* 1151 */     char c = buf[(ptr++)];
/*      */     
/*      */ 
/* 1154 */     if (c == '#') {
/* 1155 */       c = buf[(ptr++)];
/* 1156 */       int value = 0;
/* 1157 */       int inputLen = this.mInputLen;
/* 1158 */       if (c == 'x') {
/* 1159 */         while (ptr < inputLen) {
/* 1160 */           c = buf[(ptr++)];
/* 1161 */           if (c == ';') {
/*      */             break;
/*      */           }
/* 1164 */           value <<= 4;
/* 1165 */           if ((c <= '9') && (c >= '0')) {
/* 1166 */             value += c - '0';
/* 1167 */           } else if ((c >= 'a') && (c <= 'f')) {
/* 1168 */             value += 10 + (c - 'a');
/* 1169 */           } else if ((c >= 'A') && (c <= 'F')) {
/* 1170 */             value += 10 + (c - 'A');
/*      */           } else {
/* 1172 */             this.mInputPtr = ptr;
/* 1173 */             throwUnexpectedChar(c, "; expected a hex digit (0-9a-fA-F).");
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1178 */           if (value > 1114111) {
/* 1179 */             reportUnicodeOverflow();
/*      */           }
/*      */         }
/*      */       }
/* 1183 */       while (c != ';') {
/* 1184 */         if ((c <= '9') && (c >= '0')) {
/* 1185 */           value = value * 10 + (c - '0');
/*      */           
/* 1187 */           if (value > 1114111) {
/* 1188 */             reportUnicodeOverflow();
/*      */           }
/*      */         } else {
/* 1191 */           this.mInputPtr = ptr;
/* 1192 */           throwUnexpectedChar(c, "; expected a decimal number.");
/*      */         }
/* 1194 */         if (ptr >= inputLen) {
/*      */           break;
/*      */         }
/* 1197 */         c = buf[(ptr++)];
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1203 */       if (c == ';') {
/* 1204 */         this.mInputPtr = ptr;
/* 1205 */         return checkAndExpandChar(value);
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */     }
/* 1211 */     else if (checkStd)
/*      */     {
/*      */ 
/*      */ 
/* 1215 */       if (c == 'a') {
/* 1216 */         c = buf[(ptr++)];
/*      */         
/* 1218 */         if (c == 'm') {
/* 1219 */           if ((buf[(ptr++)] == 'p') && 
/* 1220 */             (ptr < this.mInputLen) && (buf[(ptr++)] == ';')) {
/* 1221 */             this.mInputPtr = ptr;
/* 1222 */             return '&';
/*      */           }
/*      */         }
/* 1225 */         else if ((c == 'p') && 
/* 1226 */           (buf[(ptr++)] == 'o')) {
/* 1227 */           int len = this.mInputLen;
/* 1228 */           if ((ptr < len) && (buf[(ptr++)] == 's') && 
/* 1229 */             (ptr < len) && (buf[(ptr++)] == ';')) {
/* 1230 */             this.mInputPtr = ptr;
/* 1231 */             return '\'';
/*      */           }
/*      */           
/*      */         }
/*      */       }
/* 1236 */       else if (c == 'g') {
/* 1237 */         if ((buf[(ptr++)] == 't') && (buf[(ptr++)] == ';')) {
/* 1238 */           this.mInputPtr = ptr;
/* 1239 */           return '>';
/*      */         }
/* 1241 */       } else if (c == 'l') {
/* 1242 */         if ((buf[(ptr++)] == 't') && (buf[(ptr++)] == ';')) {
/* 1243 */           this.mInputPtr = ptr;
/* 1244 */           return '<';
/*      */         }
/* 1246 */       } else if ((c == 'q') && 
/* 1247 */         (buf[(ptr++)] == 'u') && (buf[(ptr++)] == 'o')) {
/* 1248 */         int len = this.mInputLen;
/* 1249 */         if ((ptr < len) && (buf[(ptr++)] == 't') && 
/* 1250 */           (ptr < len) && (buf[(ptr++)] == ';')) {
/* 1251 */           this.mInputPtr = ptr;
/* 1252 */           return '"';
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1258 */     return '\000';
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected char resolveCharOnlyEntity(boolean checkStd)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1295 */     int avail = this.mInputLen - this.mInputPtr;
/* 1296 */     if (avail < 6)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1301 */       this.mInputPtr -= 1;
/*      */       
/*      */ 
/*      */ 
/* 1305 */       if (!ensureInput(6)) {
/* 1306 */         avail = inputInBuffer();
/* 1307 */         if (avail < 3) {
/* 1308 */           throwUnexpectedEOF(" in entity reference");
/*      */         }
/*      */       } else {
/* 1311 */         avail = 6;
/*      */       }
/*      */       
/* 1314 */       this.mInputPtr += 1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1320 */     char c = this.mInputBuffer[this.mInputPtr];
/*      */     
/*      */ 
/* 1323 */     if (c == '#') {
/* 1324 */       this.mInputPtr += 1;
/* 1325 */       return resolveCharEnt();
/*      */     }
/*      */     
/*      */ 
/* 1329 */     if (checkStd) {
/* 1330 */       if (c == 'a') {
/* 1331 */         char d = this.mInputBuffer[(this.mInputPtr + 1)];
/* 1332 */         if (d == 'm') {
/* 1333 */           if ((avail >= 4) && (this.mInputBuffer[(this.mInputPtr + 2)] == 'p') && (this.mInputBuffer[(this.mInputPtr + 3)] == ';'))
/*      */           {
/*      */ 
/* 1336 */             this.mInputPtr += 4;
/* 1337 */             return '&';
/*      */           }
/* 1339 */         } else if ((d == 'p') && 
/* 1340 */           (avail >= 5) && (this.mInputBuffer[(this.mInputPtr + 2)] == 'o') && (this.mInputBuffer[(this.mInputPtr + 3)] == 's') && (this.mInputBuffer[(this.mInputPtr + 4)] == ';'))
/*      */         {
/*      */ 
/*      */ 
/* 1344 */           this.mInputPtr += 5;
/* 1345 */           return '\'';
/*      */         }
/*      */       }
/* 1348 */       else if (c == 'l') {
/* 1349 */         if ((avail >= 3) && (this.mInputBuffer[(this.mInputPtr + 1)] == 't') && (this.mInputBuffer[(this.mInputPtr + 2)] == ';'))
/*      */         {
/*      */ 
/* 1352 */           this.mInputPtr += 3;
/* 1353 */           return '<';
/*      */         }
/* 1355 */       } else if (c == 'g') {
/* 1356 */         if ((avail >= 3) && (this.mInputBuffer[(this.mInputPtr + 1)] == 't') && (this.mInputBuffer[(this.mInputPtr + 2)] == ';'))
/*      */         {
/*      */ 
/* 1359 */           this.mInputPtr += 3;
/* 1360 */           return '>';
/*      */         }
/* 1362 */       } else if ((c == 'q') && 
/* 1363 */         (avail >= 5) && (this.mInputBuffer[(this.mInputPtr + 1)] == 'u') && (this.mInputBuffer[(this.mInputPtr + 2)] == 'o') && (this.mInputBuffer[(this.mInputPtr + 3)] == 't') && (this.mInputBuffer[(this.mInputPtr + 4)] == ';'))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1368 */         this.mInputPtr += 5;
/* 1369 */         return '"';
/*      */       }
/*      */     }
/*      */     
/* 1373 */     return '\000';
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected EntityDecl resolveNonCharEntity()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1387 */     int avail = this.mInputLen - this.mInputPtr;
/* 1388 */     if (avail < 6)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1393 */       this.mInputPtr -= 1;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1398 */       if (!ensureInput(6)) {
/* 1399 */         avail = inputInBuffer();
/* 1400 */         if (avail < 3) {
/* 1401 */           throwUnexpectedEOF(" in entity reference");
/*      */         }
/*      */       } else {
/* 1404 */         avail = 6;
/*      */       }
/*      */       
/* 1407 */       this.mInputPtr += 1;
/*      */     }
/*      */     
/*      */ 
/* 1411 */     char c = this.mInputBuffer[this.mInputPtr];
/* 1412 */     if (c == '#') {
/* 1413 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1422 */     if (c == 'a') {
/* 1423 */       char d = this.mInputBuffer[(this.mInputPtr + 1)];
/* 1424 */       if (d == 'm') {
/* 1425 */         if ((avail >= 4) && (this.mInputBuffer[(this.mInputPtr + 2)] == 'p') && (this.mInputBuffer[(this.mInputPtr + 3)] == ';'))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1431 */           return null;
/*      */         }
/* 1433 */       } else if ((d == 'p') && 
/* 1434 */         (avail >= 5) && (this.mInputBuffer[(this.mInputPtr + 2)] == 'o') && (this.mInputBuffer[(this.mInputPtr + 3)] == 's') && (this.mInputBuffer[(this.mInputPtr + 4)] == ';'))
/*      */       {
/*      */ 
/*      */ 
/* 1438 */         return null;
/*      */       }
/*      */     }
/* 1441 */     else if (c == 'l') {
/* 1442 */       if ((avail >= 3) && (this.mInputBuffer[(this.mInputPtr + 1)] == 't') && (this.mInputBuffer[(this.mInputPtr + 2)] == ';'))
/*      */       {
/*      */ 
/* 1445 */         return null;
/*      */       }
/* 1447 */     } else if (c == 'g') {
/* 1448 */       if ((avail >= 3) && (this.mInputBuffer[(this.mInputPtr + 1)] == 't') && (this.mInputBuffer[(this.mInputPtr + 2)] == ';'))
/*      */       {
/*      */ 
/* 1451 */         return null;
/*      */       }
/* 1453 */     } else if ((c == 'q') && 
/* 1454 */       (avail >= 5) && (this.mInputBuffer[(this.mInputPtr + 1)] == 'u') && (this.mInputBuffer[(this.mInputPtr + 2)] == 'o') && (this.mInputBuffer[(this.mInputPtr + 3)] == 't') && (this.mInputBuffer[(this.mInputPtr + 4)] == ';'))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1459 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1464 */     this.mInputPtr += 1;
/* 1465 */     String id = parseEntityName(c);
/* 1466 */     this.mCurrName = id;
/*      */     
/* 1468 */     return findEntity(id, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected char fullyResolveEntity(boolean allowExt)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1489 */     char c = getNextCharFromCurrent(" in entity reference");
/*      */     
/*      */ 
/* 1492 */     if (c == '#') {
/* 1493 */       return resolveCharEnt();
/*      */     }
/*      */     
/* 1496 */     String id = parseEntityName(c);
/*      */     
/*      */ 
/* 1499 */     c = id.charAt(0);
/*      */     
/*      */ 
/*      */ 
/* 1503 */     if (c == 'a') {
/* 1504 */       if (id.equals("amp")) {
/* 1505 */         return '&';
/*      */       }
/* 1507 */       if (id.equals("apos")) {
/* 1508 */         return '\'';
/*      */       }
/* 1510 */     } else if (c == 'g') {
/* 1511 */       if ((id.length() == 2) && (id.charAt(1) == 't')) {
/* 1512 */         return '>';
/*      */       }
/* 1514 */     } else if (c == 'l') {
/* 1515 */       if ((id.length() == 2) && (id.charAt(1) == 't')) {
/* 1516 */         return '<';
/*      */       }
/* 1518 */     } else if ((c == 'q') && 
/* 1519 */       (id.equals("quot"))) {
/* 1520 */       return '"';
/*      */     }
/*      */     
/* 1523 */     expandEntity(id, allowExt, null);
/* 1524 */     return '\000';
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected EntityDecl expandEntity(String id, boolean allowExt, Object extraArg)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1542 */     this.mCurrName = id;
/*      */     
/* 1544 */     EntityDecl ed = findEntity(id, extraArg);
/*      */     
/* 1546 */     if (ed == null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1554 */       if (this.mCfgReplaceEntities) {
/* 1555 */         expandUnresolvedEntity(id);
/*      */       }
/* 1557 */       return null;
/*      */     }
/* 1559 */     expandEntity(ed, allowExt);
/* 1560 */     return ed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void expandEntity(EntityDecl ed, boolean allowExt)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1576 */     String id = ed.getName();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1581 */     if (this.mInput.isOrIsExpandedFrom(id)) {
/* 1582 */       throwRecursionError(id);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1589 */     if (!ed.isParsed()) {
/* 1590 */       throwParseError("Illegal reference to unparsed external entity '" + id + "'.");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1595 */     boolean isExt = ed.isExternal();
/* 1596 */     if (isExt) {
/* 1597 */       if (!allowExt) {
/* 1598 */         throwParseError("Encountered a reference to external parsed entity '" + id + "' when expanding attribute value: not legal as per XML 1.0/1.1 #3.1.");
/*      */       }
/*      */       
/* 1601 */       if (!this.mConfig.hasConfigFlags(8)) {
/* 1602 */         throwParseError("Encountered a reference to external entity '" + id + "', but Reader has feature '" + "javax.xml.stream.isSupportingExternalEntities" + "' disabled.");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1610 */     WstxInputSource oldInput = this.mInput;
/* 1611 */     oldInput.saveContext(this);
/* 1612 */     WstxInputSource newInput = null;
/*      */     try {
/* 1614 */       newInput = ed.expand(oldInput, this.mEntityResolver, this.mConfig, this.mDocXmlVersion);
/*      */ 
/*      */     }
/*      */     catch (FileNotFoundException fex)
/*      */     {
/* 1619 */       throwParseError("(was " + fex.getClass().getName() + ") " + fex.getMessage());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1624 */     initInputSource(newInput, isExt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void expandUnresolvedEntity(String id)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1634 */     XMLResolver resolver = this.mConfig.getUndeclaredEntityResolver();
/* 1635 */     if (resolver != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1641 */       if (this.mInput.isOrIsExpandedFrom(id)) {
/* 1642 */         throwRecursionError(id);
/*      */       }
/*      */       
/* 1645 */       WstxInputSource oldInput = this.mInput;
/* 1646 */       oldInput.saveContext(this);
/*      */       
/* 1648 */       int xmlVersion = this.mDocXmlVersion;
/*      */       
/* 1650 */       if (xmlVersion == 0) {
/* 1651 */         xmlVersion = 256;
/*      */       }
/* 1653 */       WstxInputSource newInput = DefaultInputResolver.resolveEntityUsing(oldInput, id, null, null, resolver, this.mConfig, xmlVersion);
/*      */       
/* 1655 */       if (newInput != null)
/*      */       {
/* 1657 */         initInputSource(newInput, true);
/* 1658 */         return;
/*      */       }
/*      */     }
/* 1661 */     handleUndeclaredEntity(id);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String parseLocalName(char c)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1733 */     if (!isNameStartChar(c)) {
/* 1734 */       if (c == ':') {
/* 1735 */         throwUnexpectedChar(c, " (missing namespace prefix?)");
/*      */       }
/* 1737 */       throwUnexpectedChar(c, " (expected a name start character)");
/*      */     }
/*      */     
/* 1740 */     int ptr = this.mInputPtr;
/* 1741 */     int hash = c;
/* 1742 */     int inputLen = this.mInputLen;
/* 1743 */     int startPtr = ptr - 1;
/* 1744 */     char[] inputBuf = this.mInputBuffer;
/*      */     
/*      */ 
/*      */ 
/*      */     for (;;)
/*      */     {
/* 1750 */       if (ptr >= inputLen)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1755 */         this.mInputPtr = ptr;
/* 1756 */         return parseLocalName2(startPtr, hash);
/*      */       }
/*      */       
/* 1759 */       c = inputBuf[ptr];
/* 1760 */       if (c < '-') {
/*      */         break;
/*      */       }
/* 1763 */       if (!isNameChar(c)) {
/*      */         break;
/*      */       }
/* 1766 */       hash = hash * 31 + c;
/* 1767 */       ptr++;
/*      */     }
/* 1769 */     this.mInputPtr = ptr;
/* 1770 */     return this.mSymbols.findSymbol(this.mInputBuffer, startPtr, ptr - startPtr, hash);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String parseLocalName2(int start, int hash)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1784 */     int ptr = this.mInputLen - start;
/*      */     
/* 1786 */     char[] outBuf = getNameBuffer(ptr + 8);
/*      */     
/* 1788 */     if (ptr > 0) {
/* 1789 */       System.arraycopy(this.mInputBuffer, start, outBuf, 0, ptr);
/*      */     }
/*      */     
/* 1792 */     int outLen = outBuf.length;
/*      */     
/*      */ 
/* 1795 */     while ((this.mInputPtr < this.mInputLen) || 
/* 1796 */       (loadMoreFromCurrent()))
/*      */     {
/*      */ 
/*      */ 
/* 1800 */       char c = this.mInputBuffer[this.mInputPtr];
/* 1801 */       if (c < '-') {
/*      */         break;
/*      */       }
/* 1804 */       if (!isNameChar(c)) {
/*      */         break;
/*      */       }
/* 1807 */       this.mInputPtr += 1;
/* 1808 */       if (ptr >= outLen) {
/* 1809 */         this.mNameBuffer = (outBuf = expandBy50Pct(outBuf));
/* 1810 */         outLen = outBuf.length;
/*      */       }
/* 1812 */       outBuf[(ptr++)] = c;
/* 1813 */       hash = hash * 31 + c;
/*      */     }
/*      */     
/* 1816 */     return this.mSymbols.findSymbol(outBuf, 0, ptr, hash);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String parseFullName()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1841 */     if (this.mInputPtr >= this.mInputLen) {
/* 1842 */       loadMoreFromCurrent();
/*      */     }
/* 1844 */     return parseFullName(this.mInputBuffer[(this.mInputPtr++)]);
/*      */   }
/*      */   
/*      */ 
/*      */   protected String parseFullName(char c)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1851 */     if (!isNameStartChar(c)) {
/* 1852 */       if (c == ':') {
/* 1853 */         if (this.mCfgNsEnabled) {
/* 1854 */           throwNsColonException(parseFNameForError());
/*      */         }
/*      */       }
/*      */       else {
/* 1858 */         if (c <= ' ') {
/* 1859 */           throwUnexpectedChar(c, " (missing name?)");
/*      */         }
/* 1861 */         throwUnexpectedChar(c, " (expected a name start character)");
/*      */       }
/*      */     }
/*      */     
/* 1865 */     int ptr = this.mInputPtr;
/* 1866 */     int hash = c;
/* 1867 */     int inputLen = this.mInputLen;
/* 1868 */     int startPtr = ptr - 1;
/*      */     
/*      */ 
/*      */ 
/*      */     for (;;)
/*      */     {
/* 1874 */       if (ptr >= inputLen)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1879 */         this.mInputPtr = ptr;
/* 1880 */         return parseFullName2(startPtr, hash);
/*      */       }
/* 1882 */       c = this.mInputBuffer[ptr];
/* 1883 */       if (c == ':') {
/* 1884 */         if (this.mCfgNsEnabled) {
/* 1885 */           this.mInputPtr = ptr;
/* 1886 */           throwNsColonException(new String(this.mInputBuffer, startPtr, ptr - startPtr) + parseFNameForError());
/*      */         }
/*      */       } else {
/* 1889 */         if (c < '-') {
/*      */           break;
/*      */         }
/* 1892 */         if (!isNameChar(c)) {
/*      */           break;
/*      */         }
/*      */       }
/* 1896 */       hash = hash * 31 + c;
/* 1897 */       ptr++;
/*      */     }
/* 1899 */     this.mInputPtr = ptr;
/* 1900 */     return this.mSymbols.findSymbol(this.mInputBuffer, startPtr, ptr - startPtr, hash);
/*      */   }
/*      */   
/*      */   protected String parseFullName2(int start, int hash)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1906 */     int ptr = this.mInputLen - start;
/*      */     
/* 1908 */     char[] outBuf = getNameBuffer(ptr + 8);
/*      */     
/* 1910 */     if (ptr > 0) {
/* 1911 */       System.arraycopy(this.mInputBuffer, start, outBuf, 0, ptr);
/*      */     }
/*      */     
/* 1914 */     int outLen = outBuf.length;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1921 */     while ((this.mInputPtr < this.mInputLen) || 
/* 1922 */       (loadMoreFromCurrent()))
/*      */     {
/*      */ 
/*      */ 
/* 1926 */       char c = this.mInputBuffer[this.mInputPtr];
/* 1927 */       if (c == ':') {
/* 1928 */         if (this.mCfgNsEnabled)
/* 1929 */           throwNsColonException(new String(outBuf, 0, ptr) + c + parseFNameForError());
/*      */       } else {
/* 1931 */         if (c < '-')
/*      */           break;
/* 1933 */         if (!isNameChar(c))
/*      */           break;
/*      */       }
/* 1936 */       this.mInputPtr += 1;
/*      */       
/* 1938 */       if (ptr >= outLen) {
/* 1939 */         this.mNameBuffer = (outBuf = expandBy50Pct(outBuf));
/* 1940 */         outLen = outBuf.length;
/*      */       }
/* 1942 */       outBuf[(ptr++)] = c;
/* 1943 */       hash = hash * 31 + c;
/*      */     }
/*      */     
/*      */ 
/* 1947 */     return this.mSymbols.findSymbol(outBuf, 0, ptr, hash);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String parseFNameForError()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1960 */     StringBuffer sb = new StringBuffer(100);
/*      */     for (;;) {
/*      */       char c;
/*      */       char c;
/* 1964 */       if (this.mInputPtr < this.mInputLen) {
/* 1965 */         c = this.mInputBuffer[(this.mInputPtr++)];
/*      */       } else {
/* 1967 */         int i = getNext();
/* 1968 */         if (i < 0) {
/*      */           break;
/*      */         }
/* 1971 */         c = (char)i;
/*      */       }
/* 1973 */       if ((c != ':') && (!isNameChar(c))) {
/* 1974 */         this.mInputPtr -= 1;
/* 1975 */         break;
/*      */       }
/* 1977 */       sb.append(c);
/*      */     }
/* 1979 */     return sb.toString();
/*      */   }
/*      */   
/*      */   protected final String parseEntityName(char c)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1985 */     String id = parseFullName(c);
/*      */     
/* 1987 */     if ((this.mInputPtr >= this.mInputLen) && 
/* 1988 */       (!loadMoreFromCurrent())) {
/* 1989 */       throwParseError("Missing semicolon after reference for entity '" + id + "'");
/*      */     }
/*      */     
/* 1992 */     c = this.mInputBuffer[(this.mInputPtr++)];
/* 1993 */     if (c != ';') {
/* 1994 */       throwUnexpectedChar(c, "; expected a semi-colon after the reference for entity '" + id + "'");
/*      */     }
/* 1996 */     return id;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int skipFullName(char c)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2011 */     if (!isNameStartChar(c)) {
/* 2012 */       this.mInputPtr -= 1;
/* 2013 */       return 0;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2019 */     int count = 1;
/*      */     for (;;) {
/* 2021 */       c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextChar("; expected an identifier");
/*      */       
/* 2023 */       if ((c != ':') && (!isNameChar(c))) {
/*      */         break;
/*      */       }
/* 2026 */       count++;
/*      */     }
/* 2028 */     return count;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final String parseSystemId(char quoteChar, boolean convertLFs, String errorMsg)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2047 */     char[] buf = getNameBuffer(-1);
/* 2048 */     int ptr = 0;
/*      */     for (;;)
/*      */     {
/* 2051 */       char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextChar(errorMsg);
/*      */       
/* 2053 */       if (c == quoteChar) {
/*      */         break;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2060 */       if (c == '\n') {
/* 2061 */         markLF();
/* 2062 */       } else if (c == '\r') {
/* 2063 */         if (peekNext() == 10) {
/* 2064 */           this.mInputPtr += 1;
/* 2065 */           if (!convertLFs)
/*      */           {
/*      */ 
/*      */ 
/* 2069 */             if (ptr >= buf.length) {
/* 2070 */               buf = expandBy50Pct(buf);
/*      */             }
/* 2072 */             buf[(ptr++)] = '\r';
/*      */           }
/* 2074 */           c = '\n';
/* 2075 */         } else if (convertLFs) {
/* 2076 */           c = '\n';
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 2081 */       if (ptr >= buf.length) {
/* 2082 */         buf = expandBy50Pct(buf);
/*      */       }
/* 2084 */       buf[(ptr++)] = c;
/*      */     }
/*      */     
/* 2087 */     return ptr == 0 ? "" : new String(buf, 0, ptr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final String parsePublicId(char quoteChar, boolean normalize, String errorMsg)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2112 */     char[] buf = getNameBuffer(-1);
/* 2113 */     int ptr = 0;
/* 2114 */     boolean spaceToAdd = false;
/*      */     for (;;)
/*      */     {
/* 2117 */       char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextChar(errorMsg);
/*      */       
/* 2119 */       if (c == quoteChar) {
/*      */         break;
/*      */       }
/* 2122 */       if (c == '\n') {
/* 2123 */         markLF();
/* 2124 */         if (normalize) {
/* 2125 */           spaceToAdd = true;
/*      */         }
/*      */       }
/* 2128 */       else if (c == '\r') {
/* 2129 */         if (peekNext() == 10) {
/* 2130 */           this.mInputPtr += 1;
/* 2131 */           if (normalize) {
/* 2132 */             spaceToAdd = true;
/* 2133 */             continue;
/*      */           }
/* 2135 */           if (ptr >= buf.length) {
/* 2136 */             buf = expandBy50Pct(buf);
/*      */           }
/* 2138 */           buf[(ptr++)] = '\r';
/* 2139 */           c = '\n';
/* 2140 */         } else if (normalize) {
/* 2141 */           spaceToAdd = true;
/*      */         }
/*      */       }
/* 2144 */       else if (c == ' ') {
/* 2145 */         if (normalize) {
/* 2146 */           spaceToAdd = true;
/*      */         }
/*      */         
/*      */ 
/*      */       }
/* 2151 */       else if ((c >= '') || (sPubidValidity[c] != 1))
/*      */       {
/* 2153 */         throwUnexpectedChar(c, " in public identifier");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2158 */       if (ptr >= buf.length) {
/* 2159 */         buf = expandBy50Pct(buf);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2164 */       if (spaceToAdd) {
/* 2165 */         if (c == ' ') {
/*      */           continue;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2172 */         spaceToAdd = false;
/* 2173 */         if (ptr > 0) {
/* 2174 */           buf[(ptr++)] = ' ';
/* 2175 */           if (ptr >= buf.length) {
/* 2176 */             buf = expandBy50Pct(buf);
/*      */           }
/*      */         }
/*      */       }
/* 2180 */       buf[(ptr++)] = c;
/*      */     }
/*      */     
/* 2183 */     return ptr == 0 ? "" : new String(buf, 0, ptr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected final void parseUntil(TextBuffer tb, char endChar, boolean convertLFs, String errorMsg)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2191 */     if (this.mInputPtr >= this.mInputLen) {
/* 2192 */       loadMore(errorMsg);
/*      */     }
/*      */     for (;;)
/*      */     {
/* 2196 */       char[] inputBuf = this.mInputBuffer;
/* 2197 */       int inputLen = this.mInputLen;
/* 2198 */       int ptr = this.mInputPtr;
/* 2199 */       int startPtr = ptr;
/* 2200 */       while (ptr < inputLen) {
/* 2201 */         char c = inputBuf[(ptr++)];
/* 2202 */         if (c == endChar) {
/* 2203 */           int thisLen = ptr - startPtr - 1;
/* 2204 */           if (thisLen > 0) {
/* 2205 */             tb.append(inputBuf, startPtr, thisLen);
/*      */           }
/* 2207 */           this.mInputPtr = ptr;
/* 2208 */           return;
/*      */         }
/* 2210 */         if (c == '\n') {
/* 2211 */           this.mInputPtr = ptr;
/* 2212 */           markLF();
/* 2213 */         } else if (c == '\r') {
/* 2214 */           if ((!convertLFs) && (ptr < inputLen)) {
/* 2215 */             if (inputBuf[ptr] == '\n') {
/* 2216 */               ptr++;
/*      */             }
/* 2218 */             this.mInputPtr = ptr;
/* 2219 */             markLF();
/*      */           } else {
/* 2221 */             int thisLen = ptr - startPtr - 1;
/* 2222 */             if (thisLen > 0) {
/* 2223 */               tb.append(inputBuf, startPtr, thisLen);
/*      */             }
/* 2225 */             this.mInputPtr = ptr;
/* 2226 */             c = getNextChar(errorMsg);
/* 2227 */             if (c != '\n') {
/* 2228 */               this.mInputPtr -= 1;
/* 2229 */               tb.append(convertLFs ? '\n' : '\r');
/*      */             }
/* 2231 */             else if (convertLFs) {
/* 2232 */               tb.append('\n');
/*      */             } else {
/* 2234 */               tb.append('\r');
/* 2235 */               tb.append('\n');
/*      */             }
/*      */             
/* 2238 */             startPtr = ptr = this.mInputPtr;
/* 2239 */             markLF();
/*      */           }
/*      */         }
/*      */       }
/* 2243 */       int thisLen = ptr - startPtr;
/* 2244 */       if (thisLen > 0) {
/* 2245 */         tb.append(inputBuf, startPtr, thisLen);
/*      */       }
/* 2247 */       loadMore(errorMsg);
/* 2248 */       startPtr = ptr = this.mInputPtr;
/* 2249 */       inputBuf = this.mInputBuffer;
/* 2250 */       inputLen = this.mInputLen;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private char resolveCharEnt()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2263 */     int value = 0;
/* 2264 */     char c = getNextChar(" in entity reference");
/* 2265 */     if (c == 'x') {
/*      */       for (;;) {
/* 2267 */         c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in entity reference");
/*      */         
/* 2269 */         if (c == ';') {
/*      */           break;
/*      */         }
/* 2272 */         value <<= 4;
/* 2273 */         if ((c <= '9') && (c >= '0')) {
/* 2274 */           value += c - '0';
/* 2275 */         } else if ((c >= 'a') && (c <= 'f')) {
/* 2276 */           value += 10 + (c - 'a');
/* 2277 */         } else if ((c >= 'A') && (c <= 'F')) {
/* 2278 */           value += 10 + (c - 'A');
/*      */         } else {
/* 2280 */           throwUnexpectedChar(c, "; expected a hex digit (0-9a-fA-F).");
/*      */         }
/*      */         
/* 2283 */         if (value > 1114111) {
/* 2284 */           reportUnicodeOverflow();
/*      */         }
/*      */       }
/*      */     }
/* 2288 */     while (c != ';') {
/* 2289 */       if ((c <= '9') && (c >= '0')) {
/* 2290 */         value = value * 10 + (c - '0');
/*      */         
/* 2292 */         if (value > 1114111) {
/* 2293 */           reportUnicodeOverflow();
/*      */         }
/*      */       } else {
/* 2296 */         throwUnexpectedChar(c, "; expected a decimal number.");
/*      */       }
/* 2298 */       c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in entity reference");
/*      */     }
/*      */     
/*      */ 
/* 2302 */     return checkAndExpandChar(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final char checkAndExpandChar(int value)
/*      */     throws XMLStreamException
/*      */   {
/* 2318 */     if (value >= 55296) {
/* 2319 */       if (value < 57344) {
/* 2320 */         reportIllegalChar(value);
/*      */       }
/* 2322 */       if (value > 65535)
/*      */       {
/* 2324 */         if (value > 1114111) {
/* 2325 */           reportUnicodeOverflow();
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 2330 */         value -= 65536;
/* 2331 */         char first = (char)((value >> 10) + 55296);
/* 2332 */         char second = (char)((value & 0x3FF) + 56320);
/*      */         
/* 2334 */         return handleExpandedSurrogate(first, second); }
/* 2335 */       if (value >= 65534) {
/* 2336 */         reportIllegalChar(value);
/*      */       }
/*      */     }
/* 2339 */     else if (value < 32) {
/* 2340 */       if (value == 0) {
/* 2341 */         throwParseError("Invalid character reference: null character not allowed in XML content.");
/*      */       }
/*      */       
/* 2344 */       if ((!this.mXml11) && (value != 9) && (value != 10) && (value != 13))
/*      */       {
/* 2346 */         reportIllegalChar(value);
/*      */       }
/*      */     }
/* 2349 */     return (char)value;
/*      */   }
/*      */   
/*      */   protected final char[] getNameBuffer(int minSize)
/*      */   {
/* 2354 */     char[] buf = this.mNameBuffer;
/*      */     
/* 2356 */     if (buf == null) {
/* 2357 */       this.mNameBuffer = (buf = new char[minSize > 48 ? minSize + 16 : 64]);
/* 2358 */     } else if (minSize >= buf.length) {
/* 2359 */       int len = buf.length;
/* 2360 */       len += (len >> 1);
/* 2361 */       this.mNameBuffer = (buf = new char[minSize >= len ? minSize + 16 : len]);
/*      */     }
/* 2363 */     return buf;
/*      */   }
/*      */   
/*      */   protected final char[] expandBy50Pct(char[] buf)
/*      */   {
/* 2368 */     int len = buf.length;
/* 2369 */     char[] newBuf = new char[len + (len >> 1)];
/* 2370 */     System.arraycopy(buf, 0, newBuf, 0, len);
/* 2371 */     return newBuf;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void throwNsColonException(String name)
/*      */     throws WstxException
/*      */   {
/* 2382 */     throwParseError("Illegal name '" + name + "' (PI target, entity/notation name): can not contain a colon (XML Namespaces 1.0#6)");
/*      */   }
/*      */   
/*      */   private void throwRecursionError(String entityName)
/*      */     throws WstxException
/*      */   {
/* 2388 */     throwParseError("Illegal entity expansion: entity '" + entityName + "' expands itself recursively.");
/*      */   }
/*      */   
/*      */   private void reportUnicodeOverflow()
/*      */     throws WstxException
/*      */   {
/* 2394 */     throwParseError("Illegal character entity: value higher than max allowed (0x" + Integer.toHexString(1114111) + ")");
/*      */   }
/*      */   
/*      */   private void reportIllegalChar(int value)
/*      */     throws WstxException
/*      */   {
/* 2400 */     throwParseError("Illegal character entity: expansion character (code 0x" + Integer.toHexString(value) + ") not a valid XML character");
/*      */   }
/*      */   
/*      */   protected void throwIllegalCall()
/*      */     throws Error
/*      */   {
/* 2406 */     throw new Error("Internal error: this method should never be called");
/*      */   }
/*      */   
/*      */   public abstract Location getLocation();
/*      */   
/*      */   protected abstract EntityDecl findEntity(String paramString, Object paramObject)
/*      */     throws XMLStreamException;
/*      */   
/*      */   protected abstract void handleUndeclaredEntity(String paramString)
/*      */     throws XMLStreamException;
/*      */   
/*      */   protected abstract void handleIncompleteEntityProblem(WstxInputSource paramWstxInputSource)
/*      */     throws XMLStreamException;
/*      */   
/*      */   protected abstract char handleExpandedSurrogate(char paramChar1, char paramChar2);
/*      */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sr\StreamScanner.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */