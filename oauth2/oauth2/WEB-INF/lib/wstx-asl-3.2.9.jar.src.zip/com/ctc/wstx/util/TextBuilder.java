/*     */ package com.ctc.wstx.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TextBuilder
/*     */ {
/*     */   private static final int MIN_LEN = 64;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int MAX_LEN = 120;
/*     */   
/*     */ 
/*     */ 
/*     */   private char[] mBuffer;
/*     */   
/*     */ 
/*     */ 
/*     */   private int[] mBufferOffsets;
/*     */   
/*     */ 
/*     */ 
/*     */   private int mBufferLen;
/*     */   
/*     */ 
/*     */   private String mResultString;
/*     */   
/*     */ 
/*     */   private int mEntryCount;
/*     */   
/*     */ 
/*     */ 
/*     */   public TextBuilder(int initialSize)
/*     */   {
/*  36 */     this.mBufferOffsets = new int[initialSize];
/*  37 */     int charSize = initialSize << 4;
/*  38 */     if (charSize < 64) {
/*  39 */       charSize = 64;
/*  40 */     } else if (charSize > 120) {
/*  41 */       charSize = 120;
/*     */     }
/*  43 */     this.mBuffer = new char[charSize];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/*  51 */     this.mBufferLen = 0;
/*  52 */     this.mEntryCount = 0;
/*  53 */     this.mResultString = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/*  63 */     return this.mEntryCount == 0;
/*     */   }
/*     */   
/*     */   public int size() {
/*  67 */     return this.mEntryCount;
/*     */   }
/*     */   
/*     */   public String getEntry(int index)
/*     */   {
/*  72 */     int len = this.mEntryCount;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  81 */     if (this.mResultString == null) {
/*  82 */       this.mResultString = new String(this.mBuffer, 0, this.mBufferLen);
/*     */     }
/*     */     
/*  85 */     if ((index == 0) && (len == 1)) {
/*  86 */       return this.mResultString;
/*     */     }
/*  88 */     if (index == len - 1) {
/*  89 */       return this.mResultString.substring(this.mBufferOffsets[index]);
/*     */     }
/*  91 */     return this.mResultString.substring(this.mBufferOffsets[index], this.mBufferOffsets[(index + 1)]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOffset(int index)
/*     */   {
/* 116 */     if (index >= this.mEntryCount) {
/* 117 */       return this.mBufferLen;
/*     */     }
/* 119 */     return this.mBufferOffsets[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public char[] getCharBuffer()
/*     */   {
/* 126 */     return this.mBuffer;
/*     */   }
/*     */   
/*     */   public int getCharSize() {
/* 130 */     return this.mBufferLen;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void startNewEntry()
/*     */   {
/* 141 */     if (this.mEntryCount >= this.mBufferOffsets.length) {
/* 142 */       int[] old = this.mBufferOffsets;
/* 143 */       this.mBufferOffsets = new int[old.length << 1];
/* 144 */       System.arraycopy(old, 0, this.mBufferOffsets, 0, old.length);
/*     */     }
/* 146 */     this.mBufferOffsets[this.mEntryCount] = this.mBufferLen;
/* 147 */     this.mEntryCount += 1;
/*     */   }
/*     */   
/*     */   public void append(char c) {
/* 151 */     if (this.mBuffer.length == this.mBufferLen) {
/* 152 */       resize(1);
/*     */     }
/* 154 */     this.mBuffer[(this.mBufferLen++)] = c;
/*     */   }
/*     */   
/*     */   public void append(char[] src, int start, int len) {
/* 158 */     char[] buf = this.mBuffer;
/* 159 */     if (len > this.mBuffer.length - this.mBufferLen) {
/* 160 */       resize(len);
/* 161 */       buf = this.mBuffer;
/*     */     }
/* 163 */     System.arraycopy(src, start, this.mBuffer, this.mBufferLen, len);
/* 164 */     this.mBufferLen += len;
/*     */   }
/*     */   
/*     */   public void setBufferSize(int newSize) {
/* 168 */     this.mBufferLen = newSize;
/*     */   }
/*     */   
/*     */   public char[] bufferFull(int needSpaceFor) {
/* 172 */     this.mBufferLen = this.mBuffer.length;
/* 173 */     resize(1);
/* 174 */     return this.mBuffer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 184 */     return new String(this.mBuffer, 0, this.mBufferLen);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void resize(int needSpaceFor)
/*     */   {
/* 194 */     char[] old = this.mBuffer;
/* 195 */     int oldLen = old.length;
/* 196 */     int addition = oldLen >> 1;
/* 197 */     needSpaceFor -= oldLen - this.mBufferLen;
/* 198 */     if (addition < needSpaceFor) {
/* 199 */       addition = needSpaceFor;
/*     */     }
/* 201 */     this.mBuffer = new char[oldLen + addition];
/* 202 */     System.arraycopy(old, 0, this.mBuffer, 0, this.mBufferLen);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\util\TextBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */