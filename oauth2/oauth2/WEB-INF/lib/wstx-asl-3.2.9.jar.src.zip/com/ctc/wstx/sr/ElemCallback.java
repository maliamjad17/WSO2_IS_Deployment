package com.ctc.wstx.sr;

import com.ctc.wstx.util.BaseNsContext;
import javax.xml.namespace.QName;
import javax.xml.stream.Location;

public abstract class ElemCallback
{
  public abstract Object withStartElement(Location paramLocation, QName paramQName, BaseNsContext paramBaseNsContext, ElemAttrs paramElemAttrs, boolean paramBoolean);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sr\ElemCallback.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */