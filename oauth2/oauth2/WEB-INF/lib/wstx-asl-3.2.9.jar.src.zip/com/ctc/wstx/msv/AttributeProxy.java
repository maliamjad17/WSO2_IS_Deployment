/*     */ package com.ctc.wstx.msv;
/*     */ 
/*     */ import org.codehaus.stax2.validation.ValidationContext;
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AttributeProxy
/*     */   implements Attributes
/*     */ {
/*     */   private static final boolean PARANOID = true;
/*     */   private final ValidationContext mContext;
/*     */   
/*     */   public AttributeProxy(ValidationContext ctxt)
/*     */   {
/*  39 */     this.mContext = ctxt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getIndex(String qName)
/*     */   {
/*  50 */     illegalAccess();
/*  51 */     return -1;
/*     */   }
/*     */   
/*     */   public int getIndex(String uri, String localName)
/*     */   {
/*  56 */     return this.mContext.findAttributeIndex(uri, localName);
/*     */   }
/*     */   
/*     */   public int getLength()
/*     */   {
/*  61 */     return this.mContext.getAttributeCount();
/*     */   }
/*     */   
/*     */   public String getLocalName(int index)
/*     */   {
/*  66 */     return this.mContext.getAttributeLocalName(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getQName(int index)
/*     */   {
/*  74 */     illegalAccess();
/*  75 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getType(int index)
/*     */   {
/*  81 */     illegalAccess();
/*  82 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getType(String qName)
/*     */   {
/*  88 */     illegalAccess();
/*  89 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getType(String uri, String localName)
/*     */   {
/*  95 */     illegalAccess();
/*  96 */     return null;
/*     */   }
/*     */   
/*     */   public String getURI(int index)
/*     */   {
/* 101 */     return this.mContext.getAttributeNamespace(index);
/*     */   }
/*     */   
/*     */   public String getValue(int index)
/*     */   {
/* 106 */     return this.mContext.getAttributeValue(index);
/*     */   }
/*     */   
/*     */ 
/*     */   public String getValue(String qName)
/*     */   {
/* 112 */     illegalAccess();
/* 113 */     return null;
/*     */   }
/*     */   
/*     */   public String getValue(String uri, String localName)
/*     */   {
/* 118 */     return this.mContext.getAttributeValue(uri, localName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void illegalAccess()
/*     */   {
/* 129 */     throw new IllegalStateException("Unexpected call to AttributeProxy method that was assumed not to be needed");
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\msv\AttributeProxy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */