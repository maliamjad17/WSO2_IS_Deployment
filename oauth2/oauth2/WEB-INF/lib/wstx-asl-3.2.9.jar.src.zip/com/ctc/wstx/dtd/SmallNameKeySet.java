/*    */ package com.ctc.wstx.dtd;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SmallNameKeySet
/*    */   extends NameKeySet
/*    */ {
/*    */   final boolean mNsAware;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   final String[] mStrings;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SmallNameKeySet(boolean nsAware, NameKey[] names)
/*    */   {
/* 34 */     this.mNsAware = nsAware;
/* 35 */     int len = names.length;
/* 36 */     if (len == 0) {
/* 37 */       throw new Error("Trying to construct empty NameKeySet");
/*    */     }
/* 39 */     this.mStrings = new String[nsAware ? len + len : len];
/* 40 */     int out = 0; for (int in = 0; in < len; in++) {
/* 41 */       NameKey nk = names[in];
/* 42 */       if (nsAware) {
/* 43 */         this.mStrings[(out++)] = nk.getPrefix();
/*    */       }
/* 45 */       this.mStrings[(out++)] = nk.getLocalName();
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean hasMultiple() {
/* 50 */     return this.mStrings.length > 1;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean contains(NameKey name)
/*    */   {
/* 58 */     int len = this.mStrings.length;
/* 59 */     String ln = name.getLocalName();
/* 60 */     String[] strs = this.mStrings;
/*    */     
/* 62 */     if (this.mNsAware) {
/* 63 */       String prefix = name.getPrefix();
/* 64 */       if ((strs[1] == ln) && (strs[0] == prefix)) {
/* 65 */         return true;
/*    */       }
/* 67 */       for (int i = 2; i < len; i += 2) {
/* 68 */         if ((strs[(i + 1)] == ln) && (strs[i] == prefix)) {
/* 69 */           return true;
/*    */         }
/*    */       }
/*    */     } else {
/* 73 */       if (strs[0] == ln) {
/* 74 */         return true;
/*    */       }
/* 76 */       for (int i = 1; i < len; i++) {
/* 77 */         if (strs[i] == ln) {
/* 78 */           return true;
/*    */         }
/*    */       }
/*    */     }
/*    */     
/* 83 */     return false;
/*    */   }
/*    */   
/*    */   public void appendNames(StringBuffer sb, String sep)
/*    */   {
/* 88 */     for (int i = 0; i < this.mStrings.length;) {
/* 89 */       if (i > 0) {
/* 90 */         sb.append(sep);
/*    */       }
/* 92 */       if (this.mNsAware) {
/* 93 */         String prefix = this.mStrings[(i++)];
/* 94 */         if (prefix != null) {
/* 95 */           sb.append(prefix);
/* 96 */           sb.append(':');
/*    */         }
/*    */       }
/* 99 */       sb.append(this.mStrings[(i++)]);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\SmallNameKeySet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */