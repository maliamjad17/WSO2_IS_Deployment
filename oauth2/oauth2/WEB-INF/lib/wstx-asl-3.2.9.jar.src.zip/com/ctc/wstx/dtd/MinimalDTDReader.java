/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import com.ctc.wstx.ent.EntityDecl;
/*     */ import com.ctc.wstx.io.WstxInputData;
/*     */ import com.ctc.wstx.io.WstxInputSource;
/*     */ import com.ctc.wstx.sr.StreamScanner;
/*     */ import java.io.IOException;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MinimalDTDReader
/*     */   extends StreamScanner
/*     */ {
/*     */   final boolean mIsExternal;
/*     */   
/*     */   private MinimalDTDReader(WstxInputSource input, ReaderConfig cfg)
/*     */   {
/*  59 */     this(input, cfg, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MinimalDTDReader(WstxInputSource input, ReaderConfig cfg, boolean isExt)
/*     */   {
/*  68 */     super(input, cfg, cfg.getDtdResolver());
/*  69 */     this.mIsExternal = isExt;
/*     */     
/*     */ 
/*     */ 
/*  73 */     this.mCfgReplaceEntities = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void skipInternalSubset(WstxInputData srcData, WstxInputSource input, ReaderConfig cfg)
/*     */     throws IOException, XMLStreamException
/*     */   {
/*  89 */     MinimalDTDReader r = new MinimalDTDReader(input, cfg);
/*     */     
/*  91 */     r.copyBufferStateFrom(srcData);
/*     */     try {
/*  93 */       r.skipInternalSubset();
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/*  99 */       srcData.copyBufferStateFrom(r);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Location getLocation()
/*     */   {
/* 116 */     return getStartLocation();
/*     */   }
/*     */   
/*     */   protected EntityDecl findEntity(String id, Object arg)
/*     */   {
/* 121 */     throwIllegalCall();
/* 122 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void handleUndeclaredEntity(String id)
/*     */     throws XMLStreamException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void handleIncompleteEntityProblem(WstxInputSource closing)
/*     */     throws XMLStreamException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected char handleExpandedSurrogate(char first, char second)
/*     */   {
/* 148 */     return first;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EntityDecl findEntity(String entName)
/*     */   {
/* 166 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void skipInternalSubset()
/*     */     throws IOException, XMLStreamException
/*     */   {
/*     */     for (;;)
/*     */     {
/* 183 */       int i = getNextAfterWS();
/* 184 */       if (i < 0)
/*     */       {
/* 186 */         throwUnexpectedEOF(" in internal DTD subset");
/*     */       }
/* 188 */       if (i == 37) {
/* 189 */         skipPE();
/*     */ 
/*     */       }
/* 192 */       else if (i == 60)
/*     */       {
/*     */ 
/*     */ 
/* 196 */         char c = getNextSkippingPEs();
/* 197 */         if (c == '?')
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 202 */           skipPI();
/* 203 */         } else if (c == '!') {
/* 204 */           c = getNextSkippingPEs();
/* 205 */           if (c != '[')
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 211 */             if (c == '-') {
/* 212 */               skipComment();
/* 213 */             } else if ((c >= 'A') && (c <= 'Z')) {
/* 214 */               skipDeclaration(c);
/*     */ 
/*     */             }
/*     */             else
/*     */             {
/* 219 */               skipDeclaration(c);
/*     */             }
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 225 */           this.mInputPtr -= 1;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 230 */         if (i == 93)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 235 */           if (this.mInput == this.mRootInput) break;
/* 236 */           throwParseError("Encountered int. subset end marker ']]>' in an expanded entity; has to be at main level."); break;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 241 */         throwUnexpectedChar(i, " in internal DTD subset; expected a '<' to start a directive, or \"]>\" to end internal subset.");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected char dtdNextFromCurr()
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 254 */     return this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(getErrorMsg());
/*     */   }
/*     */   
/*     */ 
/*     */   protected char dtdNextChar()
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 261 */     return this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextChar(getErrorMsg());
/*     */   }
/*     */   
/*     */   protected char getNextSkippingPEs()
/*     */     throws IOException, XMLStreamException
/*     */   {
/*     */     for (;;)
/*     */     {
/* 269 */       char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextChar(getErrorMsg());
/*     */       
/* 271 */       if (c != '%') {
/* 272 */         return c;
/*     */       }
/* 274 */       skipPE();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void skipPE()
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 287 */     skipDTDName();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 292 */     char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : dtdNextFromCurr();
/*     */     
/* 294 */     if (c != ';') {
/* 295 */       this.mInputPtr -= 1;
/*     */     }
/*     */   }
/*     */   
/*     */   protected void skipComment()
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 302 */     skipCommentContent();
/*     */     
/* 304 */     char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : dtdNextFromCurr();
/*     */     
/* 306 */     if (c != '>') {
/* 307 */       throwParseError("String '--' not allowed in comment (missing '>'?)");
/*     */     }
/*     */   }
/*     */   
/*     */   protected void skipCommentContent() throws IOException, XMLStreamException
/*     */   {
/*     */     for (;;)
/*     */     {
/* 315 */       char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : dtdNextFromCurr();
/*     */       
/* 317 */       if (c == '-') {
/* 318 */         c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : dtdNextFromCurr();
/*     */         
/* 320 */         if (c != '-') {}
/*     */ 
/*     */       }
/* 323 */       else if ((c == '\n') || (c == '\r')) {
/* 324 */         skipCRLF(c);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void skipPI() throws IOException, XMLStreamException
/*     */   {
/*     */     for (;;)
/*     */     {
/* 333 */       char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : dtdNextFromCurr();
/*     */       
/* 335 */       if (c == '?') {
/*     */         do {
/* 337 */           c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : dtdNextFromCurr();
/*     */         }
/* 339 */         while (c == '?');
/* 340 */         if (c == '>') {
/*     */           break;
/*     */         }
/*     */       }
/* 344 */       if ((c == '\n') || (c == '\r')) {
/* 345 */         skipCRLF(c);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void skipDeclaration(char c)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 353 */     while (c != '>') {
/* 354 */       c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : dtdNextFromCurr();
/*     */       
/* 356 */       if ((c == '\n') || (c == '\r')) {
/* 357 */         skipCRLF(c);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/* 364 */       else if ((c == '\'') || (c == '"')) {
/* 365 */         skipLiteral(c);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void skipLiteral(char quoteChar) throws IOException, XMLStreamException
/*     */   {
/*     */     for (;;)
/*     */     {
/* 374 */       char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : dtdNextFromCurr();
/*     */       
/* 376 */       if ((c == '\n') || (c == '\r'))
/* 377 */         skipCRLF(c); else {
/* 378 */         if (c == quoteChar) {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void skipDTDName()
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 390 */     int len = skipFullName(getNextChar(getErrorMsg()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getErrorMsg()
/*     */   {
/* 403 */     return this.mIsExternal ? " in external DTD subset" : " in internal DTD subset";
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\MinimalDTDReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */