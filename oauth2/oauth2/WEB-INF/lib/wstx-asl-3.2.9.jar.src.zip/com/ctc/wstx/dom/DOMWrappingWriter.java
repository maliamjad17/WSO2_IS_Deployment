/*     */ package com.ctc.wstx.dom;
/*     */ 
/*     */ import com.ctc.wstx.api.WriterConfig;
/*     */ import com.ctc.wstx.util.EmptyNamespaceContext;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.transform.dom.DOMResult;
/*     */ import org.codehaus.stax2.XMLStreamLocation2;
/*     */ import org.codehaus.stax2.XMLStreamReader2;
/*     */ import org.codehaus.stax2.XMLStreamWriter2;
/*     */ import org.codehaus.stax2.validation.ValidationProblemHandler;
/*     */ import org.codehaus.stax2.validation.XMLValidationSchema;
/*     */ import org.codehaus.stax2.validation.XMLValidator;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMWrappingWriter
/*     */   implements XMLStreamWriter2
/*     */ {
/*     */   protected final WriterConfig mConfig;
/*     */   protected final boolean mNsAware;
/*     */   protected final boolean mNsRepairing;
/*  57 */   protected String mEncoding = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected NamespaceContext mNsContext;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final Document mDocument;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Element mParentElem;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Element mOpenElement;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private DOMWrappingWriter(WriterConfig cfg, Node treeRoot)
/*     */     throws XMLStreamException
/*     */   {
/* 101 */     if (treeRoot == null) {
/* 102 */       throw new IllegalArgumentException("Can not pass null Node for constructing a DOM-based XMLStreamWriter");
/*     */     }
/* 104 */     this.mConfig = cfg;
/* 105 */     this.mNsAware = cfg.willSupportNamespaces();
/* 106 */     this.mNsRepairing = ((this.mNsAware) && (cfg.automaticNamespacesEnabled()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 111 */     if (this.mNsRepairing) {
/* 112 */       throw new XMLStreamException("Repairing mode not (yet) supported with DOM-backed writer");
/*     */     }
/*     */     
/* 115 */     Element elem = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 120 */     switch (treeRoot.getNodeType()) {
/*     */     case 9: 
/* 122 */       this.mDocument = ((Document)treeRoot);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 127 */       break;
/*     */     
/*     */     case 1: 
/* 130 */       this.mDocument = treeRoot.getOwnerDocument();
/* 131 */       elem = (Element)treeRoot;
/* 132 */       break;
/*     */     
/*     */     case 11: 
/* 135 */       this.mDocument = treeRoot.getOwnerDocument();
/*     */       
/* 137 */       break;
/*     */     
/*     */     default: 
/* 140 */       throw new XMLStreamException("Can not create an XMLStreamWriter for a DOM node of type " + treeRoot.getClass());
/*     */     }
/* 142 */     if (this.mDocument == null) {
/* 143 */       throw new XMLStreamException("Can not create an XMLStreamWriter for given node (of type " + treeRoot.getClass() + "): did not have owner document");
/*     */     }
/* 145 */     this.mParentElem = (this.mOpenElement = elem);
/*     */   }
/*     */   
/*     */   public static DOMWrappingWriter createFrom(WriterConfig cfg, DOMResult dst)
/*     */     throws XMLStreamException
/*     */   {
/* 151 */     Node rootNode = dst.getNode();
/* 152 */     return new DOMWrappingWriter(cfg, rootNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void flush() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NamespaceContext getNamespaceContext()
/*     */   {
/* 171 */     if (!this.mNsAware) {
/* 172 */       return EmptyNamespaceContext.getInstance();
/*     */     }
/*     */     
/* 175 */     return this.mNsContext;
/*     */   }
/*     */   
/*     */   public String getPrefix(String uri)
/*     */   {
/* 180 */     if (!this.mNsAware) {
/* 181 */       return null;
/*     */     }
/*     */     
/* 184 */     return null;
/*     */   }
/*     */   
/*     */   public Object getProperty(String name)
/*     */   {
/* 189 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setDefaultNamespace(String uri) {}
/*     */   
/*     */   public void setNamespaceContext(NamespaceContext context)
/*     */   {
/* 197 */     this.mNsContext = context;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setPrefix(String prefix, String uri) {}
/*     */   
/*     */ 
/*     */   public void writeAttribute(String localName, String value)
/*     */   {
/* 206 */     outputAttribute(null, null, localName, value);
/*     */   }
/*     */   
/*     */   public void writeAttribute(String nsURI, String localName, String value) {
/* 210 */     outputAttribute(nsURI, null, localName, value);
/*     */   }
/*     */   
/*     */   public void writeAttribute(String prefix, String nsURI, String localName, String value)
/*     */   {
/* 215 */     outputAttribute(nsURI, prefix, localName, value);
/*     */   }
/*     */   
/*     */   public void writeCData(String data) {
/* 219 */     appendLeaf(this.mDocument.createCDATASection(data));
/*     */   }
/*     */   
/*     */   public void writeCharacters(char[] text, int start, int len)
/*     */   {
/* 224 */     writeCharacters(new String(text, start, len));
/*     */   }
/*     */   
/*     */   public void writeCharacters(String text) {
/* 228 */     appendLeaf(this.mDocument.createTextNode(text));
/*     */   }
/*     */   
/*     */   public void writeComment(String data) {
/* 232 */     appendLeaf(this.mDocument.createCDATASection(data));
/*     */   }
/*     */   
/*     */   public void writeDefaultNamespace(String nsURI)
/*     */   {
/* 237 */     writeNamespace(null, nsURI);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeDTD(String dtd)
/*     */   {
/* 243 */     reportUnsupported("writeDTD()");
/*     */   }
/*     */   
/*     */   public void writeEmptyElement(String localName) {
/* 247 */     writeEmptyElement(null, localName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeEmptyElement(String nsURI, String localName)
/*     */   {
/* 255 */     createStartElem(nsURI, null, localName, true);
/*     */   }
/*     */   
/*     */   public void writeEmptyElement(String prefix, String localName, String nsURI)
/*     */   {
/* 260 */     createStartElem(nsURI, prefix, localName, true);
/*     */   }
/*     */   
/*     */   public void writeEndDocument()
/*     */   {
/* 265 */     this.mParentElem = (this.mOpenElement = null);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeEndElement()
/*     */   {
/* 271 */     if (this.mParentElem == null) {
/* 272 */       throw new IllegalStateException("No open start element to close");
/*     */     }
/* 274 */     this.mOpenElement = null;
/* 275 */     Node parent = this.mParentElem.getParentNode();
/* 276 */     this.mParentElem = (parent == this.mDocument ? null : (Element)parent);
/*     */   }
/*     */   
/*     */   public void writeEntityRef(String name) {
/* 280 */     appendLeaf(this.mDocument.createEntityReference(name));
/*     */   }
/*     */   
/*     */   public void writeNamespace(String prefix, String nsURI)
/*     */   {
/* 285 */     boolean defNS = (prefix == null) || (prefix.length() == 0);
/*     */     
/* 287 */     if (!this.mNsAware) {
/* 288 */       if (defNS) {
/* 289 */         outputAttribute(null, null, "xmlns", nsURI);
/*     */       } else {
/* 291 */         outputAttribute(null, "xmlns", prefix, nsURI);
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */     }
/* 298 */     else if (defNS) {
/* 299 */       outputAttribute("http://www.w3.org/2000/xmlns/", null, "xmlns", nsURI);
/*     */     } else {
/* 301 */       outputAttribute("http://www.w3.org/2000/xmlns/", "xmlns", prefix, nsURI);
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeProcessingInstruction(String target)
/*     */   {
/* 307 */     writeProcessingInstruction(target, null);
/*     */   }
/*     */   
/*     */   public void writeProcessingInstruction(String target, String data) {
/* 311 */     appendLeaf(this.mDocument.createProcessingInstruction(target, data));
/*     */   }
/*     */   
/*     */   public void writeSpace(char[] text, int start, int len) {
/* 315 */     writeSpace(new String(text, start, len));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeSpace(String text)
/*     */   {
/* 324 */     writeCharacters(text);
/*     */   }
/*     */   
/*     */   public void writeStartDocument()
/*     */   {
/* 329 */     writeStartDocument("UTF-8", "1.0");
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeStartDocument(String version)
/*     */   {
/* 335 */     writeStartDocument(null, version);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeStartDocument(String encoding, String version)
/*     */   {
/* 341 */     this.mEncoding = encoding;
/*     */   }
/*     */   
/*     */   public void writeStartElement(String localName) {
/* 345 */     writeStartElement(null, localName);
/*     */   }
/*     */   
/*     */   public void writeStartElement(String nsURI, String localName)
/*     */   {
/* 350 */     createStartElem(nsURI, null, localName, false);
/*     */   }
/*     */   
/*     */   public void writeStartElement(String prefix, String localName, String nsURI)
/*     */   {
/* 355 */     createStartElem(nsURI, prefix, localName, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPropertySupported(String name)
/*     */   {
/* 367 */     return this.mConfig.isPropertySupported(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean setProperty(String name, Object value)
/*     */   {
/* 375 */     return this.mConfig.setProperty(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */   public XMLValidator validateAgainst(XMLValidationSchema schema)
/*     */     throws XMLStreamException
/*     */   {
/* 382 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public XMLValidator stopValidatingAgainst(XMLValidationSchema schema)
/*     */     throws XMLStreamException
/*     */   {
/* 389 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public XMLValidator stopValidatingAgainst(XMLValidator validator)
/*     */     throws XMLStreamException
/*     */   {
/* 396 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public ValidationProblemHandler setValidationProblemHandler(ValidationProblemHandler h)
/*     */   {
/* 402 */     return null;
/*     */   }
/*     */   
/*     */   public XMLStreamLocation2 getLocation() {
/* 406 */     return null;
/*     */   }
/*     */   
/*     */   public String getEncoding() {
/* 410 */     return this.mEncoding;
/*     */   }
/*     */   
/*     */   public void writeCData(char[] text, int start, int len)
/*     */     throws XMLStreamException
/*     */   {
/* 416 */     writeCData(new String(text, start, len));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeDTD(String rootName, String systemId, String publicId, String internalSubset)
/*     */     throws XMLStreamException
/*     */   {
/* 426 */     if (this.mParentElem != null) {
/* 427 */       throw new IllegalStateException("Operation only allowed to the document before adding root element");
/*     */     }
/* 429 */     reportUnsupported("writeDTD()");
/*     */   }
/*     */   
/*     */   public void writeFullEndElement()
/*     */     throws XMLStreamException
/*     */   {
/* 435 */     writeEndElement();
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeStartDocument(String version, String encoding, boolean standAlone)
/*     */     throws XMLStreamException
/*     */   {
/* 442 */     writeStartDocument(encoding, version);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeRaw(String text)
/*     */     throws XMLStreamException
/*     */   {
/* 454 */     reportUnsupported("writeRaw()");
/*     */   }
/*     */   
/*     */   public void writeRaw(String text, int start, int offset)
/*     */     throws XMLStreamException
/*     */   {
/* 460 */     reportUnsupported("writeRaw()");
/*     */   }
/*     */   
/*     */   public void writeRaw(char[] text, int offset, int length)
/*     */     throws XMLStreamException
/*     */   {
/* 466 */     reportUnsupported("writeRaw()");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void copyEventFromReader(XMLStreamReader2 r, boolean preserveEventData)
/*     */     throws XMLStreamException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void appendLeaf(Node n)
/*     */     throws IllegalStateException
/*     */   {
/* 484 */     if (this.mParentElem == null) {
/* 485 */       this.mDocument.appendChild(n);
/*     */     }
/*     */     else {
/* 488 */       this.mOpenElement = null;
/* 489 */       this.mParentElem.appendChild(n);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void createStartElem(String nsURI, String prefix, String localName, boolean isEmpty)
/*     */   {
/*     */     Element elem;
/*     */     Element elem;
/* 497 */     if (this.mNsAware) {
/* 498 */       if ((!this.mNsRepairing) || (
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 504 */         (prefix != null) && (prefix.length() > 0))) {
/* 505 */         localName = prefix + ":" + localName;
/*     */       }
/* 507 */       elem = this.mDocument.createElementNS(nsURI, localName);
/*     */     } else {
/* 509 */       if ((prefix != null) && (prefix.length() > 0)) {
/* 510 */         localName = prefix + ":" + localName;
/*     */       }
/* 512 */       elem = this.mDocument.createElement(localName);
/*     */     }
/*     */     
/* 515 */     appendLeaf(elem);
/* 516 */     this.mOpenElement = elem;
/* 517 */     if (!isEmpty) {
/* 518 */       this.mParentElem = elem;
/*     */     }
/*     */   }
/*     */   
/*     */   protected void outputAttribute(String nsURI, String prefix, String localName, String value)
/*     */   {
/* 524 */     if (this.mOpenElement == null) {
/* 525 */       throw new IllegalStateException("No currently open START_ELEMENT, cannot write attribute");
/*     */     }
/*     */     
/* 528 */     if (this.mNsAware) {
/* 529 */       if ((!this.mNsRepairing) || (
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 535 */         (prefix != null) && (prefix.length() > 0))) {
/* 536 */         localName = prefix + ":" + localName;
/*     */       }
/* 538 */       this.mOpenElement.setAttributeNS(nsURI, localName, value);
/*     */     } else {
/* 540 */       if ((prefix != null) && (prefix.length() > 0)) {
/* 541 */         localName = prefix + ":" + localName;
/*     */       }
/* 543 */       this.mOpenElement.setAttribute(localName, value);
/*     */     }
/*     */   }
/*     */   
/*     */   private void reportUnsupported(String operName)
/*     */   {
/* 549 */     throw new UnsupportedOperationException(operName + " can not be used with DOM-backed writer");
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dom\DOMWrappingWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */