/*     */ package com.ctc.wstx.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SingleByteAttrValueWriter
/*     */   extends WriterBase
/*     */ {
/*     */   private final char mHighChar;
/*     */   final char mQuoteChar;
/*     */   final String mQuoteEntity;
/*     */   
/*     */   public SingleByteAttrValueWriter(Writer out, String enc, char qchar, int charsetSize)
/*     */   {
/*  38 */     super(out);
/*  39 */     this.mQuoteChar = qchar;
/*  40 */     this.mQuoteEntity = getQuoteEntity(qchar);
/*  41 */     this.mHighChar = ((char)charsetSize);
/*     */   }
/*     */   
/*     */   public void write(int c) throws IOException
/*     */   {
/*  46 */     if (c >= this.mHighChar) {
/*  47 */       writeAsEntity(c);
/*  48 */     } else if (c <= 60) {
/*  49 */       if (c == this.mQuoteChar) {
/*  50 */         this.out.write(this.mQuoteEntity);
/*  51 */         return;
/*     */       }
/*  53 */       if (c == 60) {
/*  54 */         this.out.write("&lt;");
/*  55 */         return;
/*     */       }
/*  57 */       if (c == 38) {
/*  58 */         this.out.write("&amp;");
/*  59 */         return;
/*     */       }
/*  61 */       if (c < 32) {
/*  62 */         if (c == 0) {
/*  63 */           throwNullChar();
/*     */         } else {
/*  65 */           writeAsEntity(c);
/*  66 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  71 */     this.out.write(c);
/*     */   }
/*     */   
/*     */   public void write(char[] cbuf, int offset, int len) throws IOException
/*     */   {
/*  76 */     len += offset;
/*  77 */     char qchar = this.mQuoteChar;
/*     */     do {
/*  79 */       int start = offset;
/*  80 */       char c = '\000';
/*  81 */       String ent = null;
/*  83 */       for (; 
/*  83 */           offset < len; offset++) {
/*  84 */         c = cbuf[offset];
/*  85 */         if (c >= this.mHighChar) {
/*     */           break;
/*     */         }
/*  88 */         if (c <= '<') {
/*  89 */           if (c == qchar) {
/*  90 */             ent = this.mQuoteEntity;
/*  91 */             break; }
/*  92 */           if (c == '<') {
/*  93 */             ent = "&lt;";
/*  94 */             break; }
/*  95 */           if (c == '&') {
/*  96 */             ent = "&amp;";
/*  97 */             break; }
/*  98 */           if (c < ' ') {
/*  99 */             if (c != 0) break;
/* 100 */             throwNullChar(); break;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 107 */       int outLen = offset - start;
/* 108 */       if (outLen > 0) {
/* 109 */         this.out.write(cbuf, start, outLen);
/*     */       }
/* 111 */       if (ent != null) {
/* 112 */         this.out.write(ent);
/* 113 */         ent = null;
/* 114 */       } else if (offset < len) {
/* 115 */         writeAsEntity(c);
/*     */       }
/* 117 */       offset++; } while (offset < len);
/*     */   }
/*     */   
/*     */   public void write(String str, int offset, int len) throws IOException
/*     */   {
/* 122 */     len += offset;
/* 123 */     char qchar = this.mQuoteChar;
/*     */     do {
/* 125 */       int start = offset;
/* 126 */       char c = '\000';
/* 127 */       String ent = null;
/* 129 */       for (; 
/* 129 */           offset < len; offset++) {
/* 130 */         c = str.charAt(offset);
/* 131 */         if (c >= this.mHighChar) {
/*     */           break;
/*     */         }
/* 134 */         if (c <= '<') {
/* 135 */           if (c == qchar) {
/* 136 */             ent = this.mQuoteEntity;
/* 137 */             break; }
/* 138 */           if (c == '<') {
/* 139 */             ent = "&lt;";
/* 140 */             break; }
/* 141 */           if (c == '&') {
/* 142 */             ent = "&amp;";
/* 143 */             break; }
/* 144 */           if (c < ' ') {
/* 145 */             if (c != 0) break;
/* 146 */             throwNullChar(); break;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 153 */       int outLen = offset - start;
/* 154 */       if (outLen > 0) {
/* 155 */         this.out.write(str, start, outLen);
/*     */       }
/* 157 */       if (ent != null) {
/* 158 */         this.out.write(ent);
/* 159 */         ent = null;
/* 160 */       } else if (offset < len) {
/* 161 */         writeAsEntity(c);
/*     */       }
/* 163 */       offset++; } while (offset < len);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\io\SingleByteAttrValueWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */