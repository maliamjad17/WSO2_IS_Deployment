/*    */ package com.ctc.wstx.dtd;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmptyValidator
/*    */   extends StructValidator
/*    */ {
/* 14 */   static final EmptyValidator sPcdataInstance = new EmptyValidator("No elements allowed in pure #PCDATA content model");
/*    */   
/* 16 */   static final EmptyValidator sEmptyInstance = new EmptyValidator("No elements allowed in EMPTY content model");
/*    */   final String mErrorMsg;
/*    */   
/*    */   private EmptyValidator(String errorMsg)
/*    */   {
/* 21 */     this.mErrorMsg = errorMsg;
/*    */   }
/*    */   
/* 24 */   public static EmptyValidator getPcdataInstance() { return sPcdataInstance; }
/* 25 */   public static EmptyValidator getEmptyInstance() { return sPcdataInstance; }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public StructValidator newInstance()
/*    */   {
/* 32 */     return this;
/*    */   }
/*    */   
/*    */   public String tryToValidate(NameKey elemName)
/*    */   {
/* 37 */     return this.mErrorMsg;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String fullyValid()
/*    */   {
/* 46 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\EmptyValidator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */