/*      */ package com.ctc.wstx.sr;
/*      */ 
/*      */ import com.ctc.wstx.api.ReaderConfig;
/*      */ import com.ctc.wstx.cfg.ErrorConsts;
/*      */ import com.ctc.wstx.dtd.MinimalDTDReader;
/*      */ import com.ctc.wstx.ent.EntityDecl;
/*      */ import com.ctc.wstx.exc.WstxException;
/*      */ import com.ctc.wstx.io.BranchingReaderSource;
/*      */ import com.ctc.wstx.io.InputBootstrapper;
/*      */ import com.ctc.wstx.io.WstxInputSource;
/*      */ import com.ctc.wstx.util.DefaultXmlSymbolTable;
/*      */ import com.ctc.wstx.util.SymbolTable;
/*      */ import com.ctc.wstx.util.TextAccumulator;
/*      */ import com.ctc.wstx.util.TextBuffer;
/*      */ import com.ctc.wstx.util.TextBuilder;
/*      */ import java.io.IOException;
/*      */ import java.io.Writer;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import javax.xml.namespace.NamespaceContext;
/*      */ import javax.xml.namespace.QName;
/*      */ import javax.xml.stream.Location;
/*      */ import javax.xml.stream.XMLStreamException;
/*      */ import org.codehaus.stax2.AttributeInfo;
/*      */ import org.codehaus.stax2.DTDInfo;
/*      */ import org.codehaus.stax2.LocationInfo;
/*      */ import org.codehaus.stax2.XMLStreamLocation2;
/*      */ import org.codehaus.stax2.validation.DTDValidationSchema;
/*      */ import org.codehaus.stax2.validation.ValidationProblemHandler;
/*      */ import org.codehaus.stax2.validation.XMLValidationSchema;
/*      */ import org.codehaus.stax2.validation.XMLValidator;
/*      */ import org.xml.sax.Attributes;
/*      */ import org.xml.sax.ContentHandler;
/*      */ import org.xml.sax.SAXException;
/*      */ import org.xml.sax.ext.LexicalHandler;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BasicStreamReader
/*      */   extends StreamScanner
/*      */   implements StreamReaderImpl, DTDInfo, LocationInfo
/*      */ {
/*   79 */   protected static final String DEFAULT_NS_PREFIX = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int DOC_STANDALONE_UNKNOWN = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int DOC_STANDALONE_YES = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int DOC_STANDALONE_NO = 2;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int STATE_PROLOG = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int STATE_TREE = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int STATE_EPILOG = 2;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int STATE_MULTIDOC_HACK = 3;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int STATE_CLOSED = 4;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int TOKEN_NOT_STARTED = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int TOKEN_STARTED = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int TOKEN_PARTIAL_SINGLE = 2;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int TOKEN_FULL_SINGLE = 3;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int TOKEN_FULL_COALESCED = 4;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int MASK_GET_TEXT = 6768;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int MASK_GET_TEXT_XXX = 4208;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int MASK_GET_TEXT_WITH_WRITER = 6776;
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int MASK_GET_ELEMENT_TEXT = 4688;
/*      */   
/*      */ 
/*      */ 
/*      */   protected final int mConfigFlags;
/*      */   
/*      */ 
/*      */ 
/*      */   protected final boolean mCfgCoalesceText;
/*      */   
/*      */ 
/*      */ 
/*      */   protected final boolean mCfgNormalizeAttrs;
/*      */   
/*      */ 
/*      */ 
/*      */   protected final boolean mCfgReportTextAsChars;
/*      */   
/*      */ 
/*      */ 
/*      */   protected final boolean mCfgLazyParsing;
/*      */   
/*      */ 
/*      */ 
/*      */   protected final int mShortestTextSegment;
/*      */   
/*      */ 
/*      */ 
/*      */   final Map mCustomEntities;
/*      */   
/*      */ 
/*      */ 
/*  195 */   protected static final String sPrefixXml = DefaultXmlSymbolTable.getXmlSymbol();
/*      */   
/*  197 */   protected static final String sPrefixXmlns = DefaultXmlSymbolTable.getXmlnsSymbol();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final ReaderCreator mOwner;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  217 */   protected int mDocStandalone = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   String mRootPrefix;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   String mRootLName;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String mDtdPublicId;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String mDtdSystemId;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final TextBuffer mTextBuffer;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final InputElementStack mElementStack;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final AttributeCollector mAttrCollector;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  277 */   protected boolean mStDoctypeFound = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  286 */   protected int mTokenState = 4;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final int mStTextThreshold;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  297 */   protected boolean mStEmptyElem = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int mParseState;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  309 */   protected int mCurrToken = 7;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  316 */   protected int mSecondaryToken = 7;
/*      */   
/*      */ 
/*      */ 
/*      */   static final int ALL_WS_UNKNOWN = 0;
/*      */   
/*      */ 
/*      */ 
/*      */   static final int ALL_WS_YES = 1;
/*      */   
/*      */ 
/*      */ 
/*      */   static final int ALL_WS_NO = 2;
/*      */   
/*      */ 
/*      */ 
/*      */   protected int mWsStatus;
/*      */   
/*      */ 
/*      */ 
/*  336 */   protected boolean mValidateText = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int INDENT_CHECK_START = 16;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int INDENT_CHECK_MAX = 40;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int mCheckIndentation;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  357 */   protected XMLStreamException mPendingException = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  371 */   protected Map mGeneralEntities = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected EntityDecl mCurrEntity;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  389 */   protected int mVldContent = 3;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected BasicStreamReader(InputBootstrapper bs, BranchingReaderSource input, ReaderCreator owner, ReaderConfig cfg, InputElementStack elemStack, boolean forER)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  411 */     super(input, cfg, cfg.getEntityResolver());
/*      */     
/*  413 */     this.mOwner = owner;
/*      */     
/*  415 */     this.mTextBuffer = TextBuffer.createRecyclableBuffer(cfg);
/*      */     
/*      */ 
/*      */ 
/*  419 */     this.mConfigFlags = cfg.getConfigFlags();
/*      */     
/*  421 */     this.mCfgNormalizeAttrs = ((this.mConfigFlags & 0x4000) != 0);
/*  422 */     this.mCfgCoalesceText = ((this.mConfigFlags & 0x2) != 0);
/*  423 */     this.mCfgReportTextAsChars = ((this.mConfigFlags & 0x200) == 0);
/*  424 */     this.mXml11 = cfg.isXml11();
/*      */     
/*      */ 
/*  427 */     this.mCheckIndentation = (this.mCfgNormalizeLFs ? 16 : 0);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  436 */     this.mCfgLazyParsing = ((!forER) && ((this.mConfigFlags & 0x40000) != 0));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  441 */     if (this.mCfgCoalesceText) {
/*  442 */       this.mStTextThreshold = 4;
/*  443 */       this.mShortestTextSegment = Integer.MAX_VALUE;
/*      */     } else {
/*  445 */       this.mStTextThreshold = 2;
/*  446 */       if (forER)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  452 */         this.mShortestTextSegment = Integer.MAX_VALUE;
/*      */       } else {
/*  454 */         this.mShortestTextSegment = cfg.getShortestReportedTextSegment();
/*      */       }
/*      */     }
/*      */     
/*  458 */     this.mCustomEntities = cfg.getCustomInternalEntities();
/*      */     
/*      */ 
/*      */ 
/*  462 */     this.mDocXmlVersion = bs.getDeclaredVersion();
/*  463 */     this.mDocInputEncoding = bs.getInputEncoding();
/*  464 */     this.mDocXmlEncoding = bs.getDeclaredEncoding();
/*      */     
/*  466 */     String sa = bs.getStandalone();
/*  467 */     if (sa == null) {
/*  468 */       this.mDocStandalone = 0;
/*      */     }
/*  470 */     else if ("yes".equals(sa)) {
/*  471 */       this.mDocStandalone = 1;
/*      */     } else {
/*  473 */       this.mDocStandalone = 2;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  484 */     this.mParseState = (this.mConfig.inputParsingModeFragment() ? 1 : 0);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  489 */     this.mElementStack = elemStack;
/*  490 */     this.mAttrCollector = elemStack.getAttrCollector();
/*      */     
/*      */ 
/*  493 */     input.initInputLocation(this, this.mCurrDepth);
/*      */     
/*  495 */     elemStack.connectReporter(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static BasicStreamReader createBasicStreamReader(BranchingReaderSource input, ReaderCreator owner, ReaderConfig cfg, InputBootstrapper bs, boolean forER)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  512 */     BasicStreamReader sr = new BasicStreamReader(bs, input, owner, cfg, createElementStack(cfg), forER);
/*      */     
/*  514 */     return sr;
/*      */   }
/*      */   
/*      */   protected static InputElementStack createElementStack(ReaderConfig cfg)
/*      */   {
/*  519 */     if (cfg.willSupportNamespaces()) {
/*  520 */       return new NsInputElementStack(16, cfg);
/*      */     }
/*  522 */     return new NonNsInputElementStack(16, cfg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCharacterEncodingScheme()
/*      */   {
/*  538 */     return this.mDocXmlEncoding;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getEncoding()
/*      */   {
/*  548 */     return this.mDocInputEncoding;
/*      */   }
/*      */   
/*      */   public String getVersion()
/*      */   {
/*  553 */     if (this.mDocXmlVersion == 256) {
/*  554 */       return "1.0";
/*      */     }
/*  556 */     if (this.mDocXmlVersion == 272) {
/*  557 */       return "1.1";
/*      */     }
/*  559 */     return null;
/*      */   }
/*      */   
/*      */   public boolean isStandalone() {
/*  563 */     return this.mDocStandalone == 1;
/*      */   }
/*      */   
/*      */   public boolean standaloneSet() {
/*  567 */     return this.mDocStandalone != 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getProperty(String name)
/*      */   {
/*  578 */     return this.mConfig.getProperty(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getAttributeCount()
/*      */   {
/*  590 */     if (this.mCurrToken != 1) {
/*  591 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/*  593 */     return this.mAttrCollector.getCount();
/*      */   }
/*      */   
/*      */   public String getAttributeLocalName(int index) {
/*  597 */     if (this.mCurrToken != 1) {
/*  598 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/*  600 */     return this.mAttrCollector.getLocalName(index);
/*      */   }
/*      */   
/*      */   public QName getAttributeName(int index) {
/*  604 */     if (this.mCurrToken != 1) {
/*  605 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/*  607 */     return this.mAttrCollector.getQName(index);
/*      */   }
/*      */   
/*      */   public String getAttributeNamespace(int index) {
/*  611 */     if (this.mCurrToken != 1) {
/*  612 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/*  614 */     return this.mAttrCollector.getURI(index);
/*      */   }
/*      */   
/*      */   public String getAttributePrefix(int index) {
/*  618 */     if (this.mCurrToken != 1) {
/*  619 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/*  621 */     return this.mAttrCollector.getPrefix(index);
/*      */   }
/*      */   
/*      */   public String getAttributeType(int index) {
/*  625 */     if (this.mCurrToken != 1) {
/*  626 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/*      */     
/*  629 */     return this.mElementStack.getAttributeType(index);
/*      */   }
/*      */   
/*      */   public String getAttributeValue(int index) {
/*  633 */     if (this.mCurrToken != 1) {
/*  634 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/*  636 */     return this.mAttrCollector.getValue(index);
/*      */   }
/*      */   
/*      */   public String getAttributeValue(String nsURI, String localName) {
/*  640 */     if (this.mCurrToken != 1) {
/*  641 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/*  643 */     return this.mAttrCollector.getValue(nsURI, localName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getElementText()
/*      */     throws XMLStreamException
/*      */   {
/*  660 */     if (this.mCurrToken != 1) {
/*  661 */       throwParseError(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/*  663 */     TextAccumulator acc = new TextAccumulator();
/*      */     
/*      */ 
/*      */ 
/*      */     for (;;)
/*      */     {
/*  669 */       int type = next();
/*  670 */       if (type == 2) {
/*      */         break;
/*      */       }
/*  673 */       if ((type != 5) && (type != 3))
/*      */       {
/*      */ 
/*  676 */         if ((1 << type & 0x1250) == 0) {
/*  677 */           throwParseError("Expected a text token, got " + tokenTypeDesc(type) + ".");
/*      */         }
/*  679 */         acc.addText(getText());
/*      */       } }
/*  681 */     return acc.getAndClear();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getEventType()
/*      */   {
/*  693 */     if ((this.mCurrToken == 12) && (
/*  694 */       (this.mCfgCoalesceText) || (this.mCfgReportTextAsChars))) {
/*  695 */       return 4;
/*      */     }
/*      */     
/*  698 */     return this.mCurrToken;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getLocalName()
/*      */   {
/*  704 */     if ((this.mCurrToken == 1) || (this.mCurrToken == 2)) {
/*  705 */       return this.mElementStack.getLocalName();
/*      */     }
/*  707 */     if (this.mCurrToken == 9)
/*      */     {
/*      */ 
/*      */ 
/*  711 */       return this.mCurrEntity == null ? this.mCurrName : this.mCurrEntity.getName();
/*      */     }
/*  713 */     throw new IllegalStateException("Current state not START_ELEMENT, END_ELEMENT or ENTITY_REFERENCE");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public QName getName()
/*      */   {
/*  720 */     if ((this.mCurrToken != 1) && (this.mCurrToken != 2)) {
/*  721 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_ELEM);
/*      */     }
/*  723 */     return this.mElementStack.getCurrentElementName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public NamespaceContext getNamespaceContext()
/*      */   {
/*  735 */     return this.mElementStack;
/*      */   }
/*      */   
/*      */   public int getNamespaceCount() {
/*  739 */     if ((this.mCurrToken != 1) && (this.mCurrToken != 2)) {
/*  740 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_ELEM);
/*      */     }
/*  742 */     return this.mElementStack.getCurrentNsCount();
/*      */   }
/*      */   
/*      */   public String getNamespacePrefix(int index) {
/*  746 */     if ((this.mCurrToken != 1) && (this.mCurrToken != 2)) {
/*  747 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_ELEM);
/*      */     }
/*  749 */     return this.mElementStack.getLocalNsPrefix(index);
/*      */   }
/*      */   
/*      */   public String getNamespaceURI() {
/*  753 */     if ((this.mCurrToken != 1) && (this.mCurrToken != 2)) {
/*  754 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_ELEM);
/*      */     }
/*  756 */     return this.mElementStack.getNsURI();
/*      */   }
/*      */   
/*      */   public String getNamespaceURI(int index)
/*      */   {
/*  761 */     if ((this.mCurrToken != 1) && (this.mCurrToken != 2)) {
/*  762 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_ELEM);
/*      */     }
/*      */     
/*      */ 
/*  766 */     String uri = this.mElementStack.getLocalNsURI(index);
/*  767 */     return uri == null ? "" : uri;
/*      */   }
/*      */   
/*      */   public String getNamespaceURI(String prefix)
/*      */   {
/*  772 */     if ((this.mCurrToken != 1) && (this.mCurrToken != 2)) {
/*  773 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_ELEM);
/*      */     }
/*  775 */     return this.mElementStack.getNamespaceURI(prefix);
/*      */   }
/*      */   
/*      */   public String getPIData() {
/*  779 */     if (this.mCurrToken != 3) {
/*  780 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_PI);
/*      */     }
/*  782 */     if (this.mTokenState <= 1) {
/*  783 */       safeFinishToken();
/*      */     }
/*  785 */     return this.mTextBuffer.contentsAsString();
/*      */   }
/*      */   
/*      */   public String getPITarget() {
/*  789 */     if (this.mCurrToken != 3) {
/*  790 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_PI);
/*      */     }
/*      */     
/*  793 */     return this.mCurrName;
/*      */   }
/*      */   
/*      */   public String getPrefix() {
/*  797 */     if ((this.mCurrToken != 1) && (this.mCurrToken != 2)) {
/*  798 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_ELEM);
/*      */     }
/*  800 */     return this.mElementStack.getPrefix();
/*      */   }
/*      */   
/*      */   public String getText()
/*      */   {
/*  805 */     if ((1 << this.mCurrToken & 0x1A70) == 0) {
/*  806 */       throwNotTextual(this.mCurrToken);
/*      */     }
/*  808 */     if (this.mTokenState < this.mStTextThreshold) {
/*  809 */       safeFinishToken();
/*      */     }
/*  811 */     if (this.mCurrToken == 9) {
/*  812 */       return this.mCurrEntity == null ? null : this.mCurrEntity.getReplacementText();
/*      */     }
/*  814 */     if (this.mCurrToken == 11)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  819 */       return getDTDInternalSubset();
/*      */     }
/*  821 */     return this.mTextBuffer.contentsAsString();
/*      */   }
/*      */   
/*      */   public char[] getTextCharacters()
/*      */   {
/*  826 */     if ((1 << this.mCurrToken & 0x1070) == 0) {
/*  827 */       throwNotTextXxx(this.mCurrToken);
/*      */     }
/*  829 */     if (this.mTokenState < this.mStTextThreshold) {
/*  830 */       safeFinishToken();
/*      */     }
/*  832 */     if (this.mCurrToken == 9) {
/*  833 */       return this.mCurrEntity.getReplacementChars();
/*      */     }
/*  835 */     if (this.mCurrToken == 11) {
/*  836 */       return getDTDInternalSubsetArray();
/*      */     }
/*  838 */     return this.mTextBuffer.getTextBuffer();
/*      */   }
/*      */   
/*      */   public int getTextCharacters(int sourceStart, char[] target, int targetStart, int len)
/*      */   {
/*  843 */     if ((1 << this.mCurrToken & 0x1070) == 0) {
/*  844 */       throwNotTextXxx(this.mCurrToken);
/*      */     }
/*  846 */     if (this.mTokenState < this.mStTextThreshold) {
/*  847 */       safeFinishToken();
/*      */     }
/*  849 */     return this.mTextBuffer.contentsToArray(sourceStart, target, targetStart, len);
/*      */   }
/*      */   
/*      */   public int getTextLength()
/*      */   {
/*  854 */     if ((1 << this.mCurrToken & 0x1070) == 0) {
/*  855 */       throwNotTextXxx(this.mCurrToken);
/*      */     }
/*  857 */     if (this.mTokenState < this.mStTextThreshold) {
/*  858 */       safeFinishToken();
/*      */     }
/*  860 */     return this.mTextBuffer.size();
/*      */   }
/*      */   
/*      */   public int getTextStart()
/*      */   {
/*  865 */     if ((1 << this.mCurrToken & 0x1070) == 0) {
/*  866 */       throwNotTextXxx(this.mCurrToken);
/*      */     }
/*  868 */     if (this.mTokenState < this.mStTextThreshold) {
/*  869 */       safeFinishToken();
/*      */     }
/*  871 */     return this.mTextBuffer.getTextStart();
/*      */   }
/*      */   
/*      */   public boolean hasName() {
/*  875 */     return (this.mCurrToken == 1) || (this.mCurrToken == 2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean hasNext()
/*      */   {
/*  882 */     return (this.mCurrToken != 8) || (this.mParseState == 3);
/*      */   }
/*      */   
/*      */   public boolean hasText()
/*      */   {
/*  887 */     return (1 << this.mCurrToken & 0x1A70) != 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isAttributeSpecified(int index)
/*      */   {
/*  894 */     if (this.mCurrToken != 1) {
/*  895 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/*  897 */     return this.mAttrCollector.isSpecified(index);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isCharacters()
/*      */   {
/*  906 */     return this.mCurrToken == 4;
/*      */   }
/*      */   
/*      */   public boolean isEndElement() {
/*  910 */     return this.mCurrToken == 2;
/*      */   }
/*      */   
/*      */   public boolean isStartElement() {
/*  914 */     return this.mCurrToken == 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isWhiteSpace()
/*      */   {
/*  925 */     if ((this.mCurrToken == 4) || (this.mCurrToken == 12)) {
/*  926 */       if (this.mTokenState < this.mStTextThreshold) {
/*  927 */         safeFinishToken();
/*      */       }
/*  929 */       if (this.mWsStatus == 0) {
/*  930 */         this.mWsStatus = (this.mTextBuffer.isAllWhitespace() ? 1 : 2);
/*      */       }
/*      */       
/*  933 */       return this.mWsStatus == 1;
/*      */     }
/*  935 */     return this.mCurrToken == 6;
/*      */   }
/*      */   
/*      */   public void require(int type, String nsUri, String localName)
/*      */     throws XMLStreamException
/*      */   {
/*  941 */     int curr = this.mCurrToken;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  947 */     if (curr != type) {
/*  948 */       if (curr == 12) {
/*  949 */         if ((this.mCfgCoalesceText) || (this.mCfgReportTextAsChars)) {
/*  950 */           curr = 4;
/*      */         }
/*  952 */       } else if (curr != 6) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  959 */     if (type != curr) {
/*  960 */       throwParseError("Expected type " + tokenTypeDesc(type) + ", current type " + tokenTypeDesc(curr));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  965 */     if (localName != null) {
/*  966 */       if ((curr != 1) && (curr != 2) && (curr != 9))
/*      */       {
/*  968 */         throwParseError("Expected non-null local name, but current token not a START_ELEMENT, END_ELEMENT or ENTITY_REFERENCE (was " + tokenTypeDesc(this.mCurrToken) + ")");
/*      */       }
/*  970 */       String n = getLocalName();
/*  971 */       if ((n != localName) && (!n.equals(localName))) {
/*  972 */         throwParseError("Expected local name '" + localName + "'; current local name '" + n + "'.");
/*      */       }
/*      */     }
/*  975 */     if (nsUri != null) {
/*  976 */       if ((curr != 1) && (curr != 2)) {
/*  977 */         throwParseError("Expected non-null NS URI, but current token not a START_ELEMENT or END_ELEMENT (was " + tokenTypeDesc(curr) + ")");
/*      */       }
/*  979 */       String uri = this.mElementStack.getNsURI();
/*      */       
/*  981 */       if (nsUri.length() == 0) {
/*  982 */         if ((uri != null) && (uri.length() > 0)) {
/*  983 */           throwParseError("Expected empty namespace, instead have '" + uri + "'.");
/*      */         }
/*      */       }
/*  986 */       else if ((nsUri != uri) && (!nsUri.equals(uri))) {
/*  987 */         throwParseError("Expected namespace '" + nsUri + "'; have '" + uri + "'.");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final int next()
/*      */     throws XMLStreamException
/*      */   {
/* 1008 */     if (this.mPendingException != null) {
/* 1009 */       XMLStreamException strEx = this.mPendingException;
/* 1010 */       this.mPendingException = null;
/* 1011 */       throw strEx;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 1018 */       if (this.mParseState == 1) {
/* 1019 */         int type = nextFromTree();
/* 1020 */         this.mCurrToken = type;
/*      */         
/* 1022 */         if ((!this.mCfgLazyParsing) && (this.mTokenState < this.mStTextThreshold)) {
/* 1023 */           finishToken(false);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1030 */         if (type == 12) {
/* 1031 */           if (this.mValidateText) {
/* 1032 */             if (this.mTokenState < this.mStTextThreshold) {
/* 1033 */               finishToken(false);
/*      */             }
/* 1035 */             this.mElementStack.validateText(this.mTextBuffer, false);
/*      */           }
/* 1037 */           if ((this.mCfgCoalesceText) || (this.mCfgReportTextAsChars)) {
/* 1038 */             return 4;
/*      */ 
/*      */           }
/*      */           
/*      */ 
/*      */         }
/* 1044 */         else if ((type == 4) && 
/* 1045 */           (this.mValidateText)) {
/* 1046 */           if (this.mTokenState < this.mStTextThreshold) {
/* 1047 */             finishToken(false);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1056 */           if ((this.mInputPtr + 1 < this.mInputLen) && (this.mInputBuffer[this.mInputPtr] == '<') && (this.mInputBuffer[(this.mInputPtr + 1)] == '/'))
/*      */           {
/*      */ 
/*      */ 
/* 1060 */             this.mElementStack.validateText(this.mTextBuffer, true);
/*      */           } else {
/* 1062 */             this.mElementStack.validateText(this.mTextBuffer, false);
/*      */           }
/*      */         }
/*      */         
/* 1066 */         return type;
/*      */       }
/* 1068 */       if (this.mParseState == 0) {
/* 1069 */         nextFromProlog(true);
/* 1070 */       } else if (this.mParseState == 2) {
/* 1071 */         if (nextFromProlog(false))
/*      */         {
/* 1073 */           this.mSecondaryToken = 0;
/*      */         }
/*      */       }
/* 1076 */       else if (this.mParseState == 3) {
/* 1077 */         this.mCurrToken = nextFromMultiDocState();
/*      */       } else {
/* 1079 */         if (this.mSecondaryToken == 8) {
/* 1080 */           this.mSecondaryToken = 0;
/* 1081 */           return 8;
/*      */         }
/* 1083 */         throw new NoSuchElementException();
/*      */       }
/*      */     } catch (IOException ie) {
/* 1086 */       throwFromIOE(ie);
/*      */     }
/* 1088 */     return this.mCurrToken;
/*      */   }
/*      */   
/*      */   public int nextTag() throws XMLStreamException
/*      */   {
/*      */     for (;;)
/*      */     {
/* 1095 */       int next = next();
/*      */       
/* 1097 */       switch (next) {
/*      */       case 3: 
/*      */       case 5: 
/*      */       case 6: 
/*      */         break;
/*      */       case 4: 
/*      */       case 12: 
/* 1104 */         if (!isWhiteSpace())
/*      */         {
/*      */ 
/* 1107 */           throwParseError("Received non-all-whitespace CHARACTERS or CDATA event in nextTag()."); }
/* 1108 */         break;
/*      */       case 1: 
/*      */       case 2: 
/* 1111 */         return next;
/*      */       case 7: case 8: case 9: case 10: case 11: default: 
/* 1113 */         throwParseError("Received event " + ErrorConsts.tokenTypeDesc(next) + ", instead of START_ELEMENT or END_ELEMENT.");
/*      */       }
/*      */       
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws XMLStreamException
/*      */   {
/* 1128 */     if (this.mParseState != 4) {
/* 1129 */       this.mParseState = 4;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1134 */       if (this.mCurrToken != 8) {
/* 1135 */         this.mCurrToken = (this.mSecondaryToken = 8);
/* 1136 */         if (this.mSymbols.isDirty()) {
/* 1137 */           this.mOwner.updateSymbolTable(this.mSymbols);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1147 */       closeAllInput(false);
/*      */       
/* 1149 */       this.mTextBuffer.recycle(true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getFeature(String name)
/*      */   {
/* 1164 */     throw new IllegalArgumentException(MessageFormat.format(ErrorConsts.ERR_UNKNOWN_FEATURE, new Object[] { name }));
/*      */   }
/*      */   
/*      */ 
/*      */   public void setFeature(String name, Object value)
/*      */   {
/* 1170 */     throw new IllegalArgumentException(MessageFormat.format(ErrorConsts.ERR_UNKNOWN_FEATURE, new Object[] { name }));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isPropertySupported(String name)
/*      */   {
/* 1177 */     return this.mConfig.isPropertySupported(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setProperty(String name, Object value)
/*      */   {
/* 1192 */     return this.mConfig.setProperty(name, value);
/*      */   }
/*      */   
/*      */ 
/*      */   public void skipElement()
/*      */     throws XMLStreamException
/*      */   {
/* 1199 */     if (this.mCurrToken != 1) {
/* 1200 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/* 1202 */     int nesting = 1;
/*      */     for (;;)
/*      */     {
/* 1205 */       int type = next();
/* 1206 */       if (type == 1) {
/* 1207 */         nesting++;
/* 1208 */       } else if (type == 2) {
/* 1209 */         nesting--; if (nesting == 0) {
/*      */           break;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public AttributeInfo getAttributeInfo()
/*      */     throws XMLStreamException
/*      */   {
/* 1220 */     if (this.mCurrToken != 1) {
/* 1221 */       throw new IllegalStateException(ErrorConsts.ERR_STATE_NOT_STELEM);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1227 */     return this.mElementStack;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public DTDInfo getDTDInfo()
/*      */     throws XMLStreamException
/*      */   {
/* 1241 */     if (this.mCurrToken != 11) {
/* 1242 */       return null;
/*      */     }
/* 1244 */     if (this.mTokenState < 3) {
/* 1245 */       wrappedFinishToken();
/*      */     }
/* 1247 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final LocationInfo getLocationInfo()
/*      */   {
/* 1256 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getText(Writer w, boolean preserveContents)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1286 */     if ((1 << this.mCurrToken & 0x1A78) == 0) {
/* 1287 */       throwNotTextual(this.mCurrToken);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1294 */     if (!preserveContents) {
/* 1295 */       if (this.mCurrToken == 4) {
/* 1296 */         int count = this.mTextBuffer.rawContentsTo(w);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1302 */         this.mTextBuffer.resetWithEmpty();
/* 1303 */         if (this.mTokenState < 3) {
/* 1304 */           count += readAndWriteText(w);
/*      */         }
/* 1306 */         if ((this.mCfgCoalesceText) && (this.mTokenState < 4))
/*      */         {
/* 1308 */           if (this.mCfgCoalesceText) {
/* 1309 */             count += readAndWriteCoalesced(w, false);
/*      */           }
/*      */         }
/* 1312 */         return count; }
/* 1313 */       if (this.mCurrToken == 12) {
/* 1314 */         int count = this.mTextBuffer.rawContentsTo(w);
/* 1315 */         this.mTextBuffer.resetWithEmpty();
/* 1316 */         if (this.mTokenState < 3) {
/* 1317 */           count += readAndWriteCData(w);
/*      */         }
/* 1319 */         if ((this.mCfgCoalesceText) && (this.mTokenState < 4))
/*      */         {
/* 1321 */           if (this.mCfgCoalesceText) {
/* 1322 */             count += readAndWriteCoalesced(w, true);
/*      */           }
/*      */         }
/* 1325 */         return count;
/*      */       }
/*      */     }
/* 1328 */     if (this.mTokenState < this.mStTextThreshold)
/*      */     {
/*      */ 
/*      */ 
/* 1332 */       finishToken(false);
/*      */     }
/* 1334 */     if (this.mCurrToken == 9) {
/* 1335 */       return this.mCurrEntity.getReplacementText(w);
/*      */     }
/* 1337 */     if (this.mCurrToken == 11) {
/* 1338 */       char[] ch = getDTDInternalSubsetArray();
/* 1339 */       if (ch != null) {
/* 1340 */         w.write(ch);
/* 1341 */         return ch.length;
/*      */       }
/* 1343 */       return 0;
/*      */     }
/* 1345 */     return this.mTextBuffer.rawContentsTo(w);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getDepth()
/*      */   {
/* 1360 */     return this.mElementStack.getDepth();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isEmptyElement()
/*      */     throws XMLStreamException
/*      */   {
/* 1370 */     return this.mCurrToken == 1 ? this.mStEmptyElem : false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public NamespaceContext getNonTransientNamespaceContext()
/*      */   {
/* 1377 */     return this.mElementStack.createNonTransientNsContext(null);
/*      */   }
/*      */   
/*      */   public String getPrefixedName()
/*      */   {
/* 1382 */     switch (this.mCurrToken)
/*      */     {
/*      */     case 1: 
/*      */     case 2: 
/* 1386 */       String prefix = this.mElementStack.getPrefix();
/* 1387 */       String ln = this.mElementStack.getLocalName();
/*      */       
/* 1389 */       if (prefix == null) {
/* 1390 */         return ln;
/*      */       }
/* 1392 */       StringBuffer sb = new StringBuffer(ln.length() + 1 + prefix.length());
/* 1393 */       sb.append(prefix);
/* 1394 */       sb.append(':');
/* 1395 */       sb.append(ln);
/* 1396 */       return sb.toString();
/*      */     
/*      */     case 9: 
/* 1399 */       return getLocalName();
/*      */     case 3: 
/* 1401 */       return getPITarget();
/*      */     case 11: 
/* 1403 */       return getDTDRootName();
/*      */     }
/*      */     
/* 1406 */     throw new IllegalStateException("Current state not START_ELEMENT, END_ELEMENT, ENTITY_REFERENCE, PROCESSING_INSTRUCTION or DTD");
/*      */   }
/*      */   
/*      */   public void closeCompletely() throws XMLStreamException
/*      */   {
/* 1411 */     closeAllInput(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getProcessedDTD()
/*      */   {
/* 1425 */     return null;
/*      */   }
/*      */   
/*      */   public String getDTDRootName() {
/* 1429 */     if (this.mRootPrefix == null) {
/* 1430 */       return this.mRootLName;
/*      */     }
/* 1432 */     return this.mRootPrefix + ":" + this.mRootLName;
/*      */   }
/*      */   
/*      */   public String getDTDPublicId() {
/* 1436 */     return this.mDtdPublicId;
/*      */   }
/*      */   
/*      */   public String getDTDSystemId() {
/* 1440 */     return this.mDtdSystemId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDTDInternalSubset()
/*      */   {
/* 1448 */     if (this.mCurrToken != 11) {
/* 1449 */       return null;
/*      */     }
/* 1451 */     return this.mTextBuffer.contentsAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private char[] getDTDInternalSubsetArray()
/*      */   {
/* 1462 */     return this.mTextBuffer.contentsAsArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public DTDValidationSchema getProcessedDTDSchema()
/*      */   {
/* 1471 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getStartingByteOffset()
/*      */   {
/* 1487 */     return -1L;
/*      */   }
/*      */   
/*      */   public long getStartingCharOffset() {
/* 1491 */     return this.mTokenInputTotal;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getEndingByteOffset()
/*      */     throws XMLStreamException
/*      */   {
/* 1500 */     return -1L;
/*      */   }
/*      */   
/*      */   public long getEndingCharOffset()
/*      */     throws XMLStreamException
/*      */   {
/* 1506 */     if (this.mTokenState < this.mStTextThreshold) {
/* 1507 */       wrappedFinishToken();
/*      */     }
/* 1509 */     return this.mCurrInputProcessed + this.mInputPtr;
/*      */   }
/*      */   
/*      */ 
/*      */   public final Location getLocation()
/*      */   {
/* 1515 */     return getStartLocation();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final XMLStreamLocation2 getEndLocation()
/*      */     throws XMLStreamException
/*      */   {
/* 1525 */     if (this.mTokenState < this.mStTextThreshold) {
/* 1526 */       wrappedFinishToken();
/*      */     }
/*      */     
/* 1529 */     return getCurrentLocation();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public XMLValidator validateAgainst(XMLValidationSchema schema)
/*      */     throws XMLStreamException
/*      */   {
/* 1542 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public XMLValidator stopValidatingAgainst(XMLValidationSchema schema)
/*      */     throws XMLStreamException
/*      */   {
/* 1549 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public XMLValidator stopValidatingAgainst(XMLValidator validator)
/*      */     throws XMLStreamException
/*      */   {
/* 1556 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public ValidationProblemHandler setValidationProblemHandler(ValidationProblemHandler h)
/*      */   {
/* 1562 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EntityDecl getCurrentEntityDecl()
/*      */   {
/* 1572 */     return this.mCurrEntity;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object withStartElement(ElemCallback cb, Location loc)
/*      */   {
/* 1585 */     if (this.mCurrToken != 1) {
/* 1586 */       return null;
/*      */     }
/* 1588 */     return cb.withStartElement(loc, getName(), this.mElementStack.createNonTransientNsContext(loc), this.mAttrCollector.buildAttrOb(), this.mStEmptyElem);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isNamespaceAware()
/*      */   {
/* 1595 */     return this.mCfgNsEnabled;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputElementStack getInputElementStack()
/*      */   {
/* 1604 */     return this.mElementStack;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AttributeCollector getAttributeCollector()
/*      */   {
/* 1613 */     return this.mAttrCollector;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fireSaxStartElement(ContentHandler h, Attributes attrs)
/*      */     throws SAXException
/*      */   {
/* 1624 */     if (h != null)
/*      */     {
/* 1626 */       int nsCount = this.mElementStack.getCurrentNsCount();
/* 1627 */       for (int i = 0; i < nsCount; i++) {
/* 1628 */         String prefix = this.mElementStack.getLocalNsPrefix(i);
/* 1629 */         String uri = this.mElementStack.getLocalNsURI(i);
/* 1630 */         h.startPrefixMapping(prefix == null ? "" : prefix, uri);
/*      */       }
/*      */       
/*      */ 
/* 1634 */       String uri = this.mElementStack.getNsURI();
/*      */       
/* 1636 */       h.startElement(uri == null ? "" : uri, this.mElementStack.getLocalName(), getPrefixedName(), attrs);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void fireSaxEndElement(ContentHandler h)
/*      */     throws SAXException
/*      */   {
/* 1644 */     if (h != null)
/*      */     {
/*      */ 
/*      */ 
/* 1648 */       String uri = this.mElementStack.getNsURI();
/*      */       
/* 1650 */       h.endElement(uri == null ? "" : uri, this.mElementStack.getLocalName(), getPrefixedName());
/*      */       
/*      */ 
/* 1653 */       int nsCount = this.mElementStack.getCurrentNsCount();
/* 1654 */       for (int i = 0; i < nsCount; i++) {
/* 1655 */         String prefix = this.mElementStack.getLocalNsPrefix(i);
/* 1656 */         String nsUri = this.mElementStack.getLocalNsURI(i);
/* 1657 */         h.endPrefixMapping(prefix == null ? "" : prefix);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void fireSaxCharacterEvents(ContentHandler h)
/*      */     throws IOException, XMLStreamException, SAXException
/*      */   {
/* 1665 */     if (h != null) {
/* 1666 */       if (this.mPendingException != null) {
/* 1667 */         XMLStreamException sex = this.mPendingException;
/* 1668 */         this.mPendingException = null;
/* 1669 */         throw sex;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1674 */       if (this.mTokenState < this.mStTextThreshold) {
/* 1675 */         finishToken(false);
/*      */       }
/* 1677 */       this.mTextBuffer.fireSaxCharacterEvents(h);
/*      */     }
/*      */   }
/*      */   
/*      */   public void fireSaxSpaceEvents(ContentHandler h)
/*      */     throws IOException, XMLStreamException, SAXException
/*      */   {
/* 1684 */     if (h != null) {
/* 1685 */       if (this.mTokenState < this.mStTextThreshold) {
/* 1686 */         finishToken(false);
/*      */       }
/* 1688 */       this.mTextBuffer.fireSaxSpaceEvents(h);
/*      */     }
/*      */   }
/*      */   
/*      */   public void fireSaxCommentEvent(LexicalHandler h)
/*      */     throws IOException, XMLStreamException, SAXException
/*      */   {
/* 1695 */     if (h != null) {
/* 1696 */       if (this.mTokenState < this.mStTextThreshold) {
/* 1697 */         finishToken(false);
/*      */       }
/* 1699 */       this.mTextBuffer.fireSaxCommentEvent(h);
/*      */     }
/*      */   }
/*      */   
/*      */   public void fireSaxPIEvent(ContentHandler h)
/*      */     throws IOException, XMLStreamException, SAXException
/*      */   {
/* 1706 */     if (h != null) {
/* 1707 */       if (this.mTokenState < this.mStTextThreshold) {
/* 1708 */         finishToken(false);
/*      */       }
/* 1710 */       h.processingInstruction(this.mCurrName, this.mTextBuffer.contentsAsString());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final boolean hasConfigFlags(int flags)
/*      */   {
/* 1721 */     return (this.mConfigFlags & flags) == flags;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String checkKeyword(char c, String expected)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1737 */     int ptr = 0;
/* 1738 */     int len = expected.length();
/*      */     
/* 1740 */     while (expected.charAt(ptr) == c) { ptr++; if (ptr >= len) break;
/* 1741 */       if (this.mInputPtr < this.mInputLen) {
/* 1742 */         c = this.mInputBuffer[(this.mInputPtr++)];
/*      */       } else {
/* 1744 */         int ci = getNext();
/* 1745 */         if (ci < 0) {
/*      */           break;
/*      */         }
/* 1748 */         c = (char)ci;
/*      */       }
/*      */     }
/*      */     
/* 1752 */     if (ptr == len)
/*      */     {
/* 1754 */       int i = peekNext();
/* 1755 */       if ((i < 0) || ((!isNameChar((char)i)) && (i != 58))) {
/* 1756 */         return null;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1761 */     StringBuffer sb = new StringBuffer(expected.length() + 16);
/* 1762 */     sb.append(expected.substring(0, ptr));
/* 1763 */     sb.append(c);
/*      */     for (;;)
/*      */     {
/* 1766 */       if (this.mInputPtr < this.mInputLen) {
/* 1767 */         c = this.mInputBuffer[(this.mInputPtr++)];
/*      */       } else {
/* 1769 */         int ci = getNext();
/* 1770 */         if (ci < 0) {
/*      */           break;
/*      */         }
/* 1773 */         c = (char)ci;
/*      */       }
/* 1775 */       if (!isNameChar(c))
/*      */       {
/* 1777 */         this.mInputPtr -= 1;
/* 1778 */         break;
/*      */       }
/* 1780 */       sb.append(c);
/*      */     }
/*      */     
/* 1783 */     return sb.toString();
/*      */   }
/*      */   
/*      */   protected void checkCData()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1789 */     String wrong = checkKeyword(getNextCharFromCurrent(" in CDATA section"), "CDATA");
/* 1790 */     if (wrong != null) {
/* 1791 */       throwParseError("Unrecognized XML directive '" + wrong + "'; expected 'CDATA'.");
/*      */     }
/*      */     
/* 1794 */     char c = getNextCharFromCurrent(" in CDATA section");
/* 1795 */     if (c != '[') {
/* 1796 */       throwUnexpectedChar(c, "excepted '[' after '<![CDATA'");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void parseNonNormalizedAttrValue(char openingQuote, TextBuilder tb)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1809 */     char[] outBuf = tb.getCharBuffer();
/* 1810 */     int outPtr = tb.getCharSize();
/* 1811 */     int outLen = outBuf.length;
/* 1812 */     WstxInputSource currScope = this.mInput;
/*      */     for (;;)
/*      */     {
/* 1815 */       char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextChar(" in attribute value");
/*      */       
/*      */ 
/* 1818 */       if (c < '?') {
/* 1819 */         if (c < ' ') {
/* 1820 */           if (c == '\n') {
/* 1821 */             markLF();
/* 1822 */           } else if (c == '\r') {
/* 1823 */             c = getNextChar(" in attribute value");
/* 1824 */             if (c != '\n') {
/* 1825 */               this.mInputPtr -= 1;
/* 1826 */               c = this.mCfgNormalizeLFs ? '\n' : '\r';
/*      */             }
/* 1828 */             else if (!this.mCfgNormalizeLFs)
/*      */             {
/*      */ 
/*      */ 
/* 1832 */               if (outPtr >= outLen) {
/* 1833 */                 outBuf = tb.bufferFull(1);
/* 1834 */                 outLen = outBuf.length;
/*      */               }
/* 1836 */               outBuf[(outPtr++)] = '\r';
/*      */             }
/*      */             
/*      */ 
/* 1840 */             markLF();
/* 1841 */           } else if (c != '\t') {
/* 1842 */             throwInvalidSpace(c);
/*      */           }
/* 1844 */         } else if (c == openingQuote)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1850 */           if (this.mInput == currScope) {
/*      */             break;
/*      */           }
/* 1853 */         } else if (c == '&') {
/* 1854 */           if ((inputInBuffer() < 3) || ((c = resolveSimpleEntity(true)) == 0))
/*      */           {
/*      */ 
/*      */ 
/* 1858 */             c = fullyResolveEntity(false);
/*      */             
/* 1860 */             if (c != 0) {}
/*      */           }
/*      */           
/*      */         }
/* 1864 */         else if (c == '<') {
/* 1865 */           throwParseError("Unexpected '<'  in attribute value");
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1870 */       if (outPtr >= outLen) {
/* 1871 */         outBuf = tb.bufferFull(1);
/* 1872 */         outLen = outBuf.length;
/*      */       }
/* 1874 */       outBuf[(outPtr++)] = c;
/*      */     }
/*      */     
/*      */ 
/* 1878 */     tb.setBufferSize(outPtr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void parseNormalizedAttrValue(char openingQuote, TextBuilder tb)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 1894 */     char[] outBuf = tb.getCharBuffer();
/* 1895 */     int outPtr = tb.getCharSize();
/* 1896 */     int outLen = outBuf.length;
/* 1897 */     WstxInputSource currScope = this.mInput;
/*      */     for (;;)
/*      */     {
/* 1900 */       char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextChar(" in attribute value");
/*      */       
/*      */ 
/* 1903 */       if (c <= '\'') {
/* 1904 */         if (c < ' ') {
/* 1905 */           if (c == '\n') {
/* 1906 */             markLF();
/* 1907 */           } else if (c == '\r')
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1916 */             if (this.mCfgNormalizeLFs) {
/* 1917 */               c = getNextChar(" in attribute value");
/* 1918 */               if (c != '\n') {
/* 1919 */                 this.mInputPtr -= 1;
/*      */               }
/*      */             }
/* 1922 */             markLF();
/* 1923 */           } else if (c != '\t') {
/* 1924 */             throwInvalidSpace(c);
/*      */           }
/*      */           
/* 1927 */           c = ' ';
/* 1928 */         } else if (c == openingQuote)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1934 */           if (this.mInput == currScope) {
/*      */             break;
/*      */           }
/* 1937 */         } else if ((c == '&') && (
/* 1938 */           (inputInBuffer() < 3) || ((c = resolveSimpleEntity(true)) == 0)))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 1943 */           c = fullyResolveEntity(false);
/* 1944 */           if (c != 0) {}
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */       }
/* 1950 */       else if (c == '<') {
/* 1951 */         throwParseError("Unexpected '<'  in attribute value");
/*      */       }
/*      */       
/*      */ 
/* 1955 */       if (outPtr >= outLen) {
/* 1956 */         outBuf = tb.bufferFull(1);
/* 1957 */         outLen = outBuf.length;
/*      */       }
/* 1959 */       outBuf[(outPtr++)] = c;
/*      */     }
/*      */     
/*      */ 
/* 1963 */     tb.setBufferSize(outPtr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean nextFromProlog(boolean isProlog)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*      */     int i;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     int i;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1986 */     if (this.mTokenState < this.mStTextThreshold) {
/* 1987 */       this.mTokenState = 4;
/* 1988 */       i = skipToken();
/*      */     }
/*      */     else
/*      */     {
/* 1992 */       this.mTokenInputTotal = (this.mCurrInputProcessed + this.mInputPtr);
/* 1993 */       this.mTokenInputRow = this.mCurrInputRow;
/* 1994 */       this.mTokenInputCol = (this.mInputPtr - this.mCurrInputRowStart);
/* 1995 */       i = getNext();
/*      */     }
/*      */     
/*      */ 
/* 1999 */     if ((i <= 32) && (i >= 0))
/*      */     {
/* 2001 */       if (hasConfigFlags(256)) {
/* 2002 */         this.mCurrToken = 6;
/* 2003 */         if (readSpacePrimary((char)i, true))
/*      */         {
/*      */ 
/*      */ 
/* 2007 */           this.mTokenState = 4;
/*      */         }
/* 2009 */         else if (this.mCfgLazyParsing)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 2014 */           this.mTokenState = 1;
/*      */         } else {
/* 2016 */           readSpaceSecondary(true);
/* 2017 */           this.mTokenState = 4;
/*      */         }
/*      */         
/* 2020 */         return false;
/*      */       }
/*      */       
/* 2023 */       this.mInputPtr -= 1;
/* 2024 */       i = getNextAfterWS();
/* 2025 */       if (i >= 0)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2032 */         this.mTokenInputTotal = (this.mCurrInputProcessed + this.mInputPtr - 1L);
/* 2033 */         this.mTokenInputRow = this.mCurrInputRow;
/* 2034 */         this.mTokenInputCol = (this.mInputPtr - this.mCurrInputRowStart - 1);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2039 */     if (i < 0) {
/* 2040 */       handleEOF(isProlog);
/* 2041 */       this.mParseState = 4;
/* 2042 */       return true;
/*      */     }
/*      */     
/*      */ 
/* 2046 */     if (i != 60) {
/* 2047 */       throwUnexpectedChar(i, (isProlog ? " in prolog" : " in epilog") + "; expected '<'");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2052 */     char c = getNextChar(isProlog ? " in prolog" : " in epilog");
/*      */     
/* 2054 */     if (c == '?') {
/* 2055 */       this.mCurrToken = readPIPrimary();
/* 2056 */     } else if (c == '!')
/*      */     {
/* 2058 */       nextFromPrologBang(isProlog);
/* 2059 */     } else if (c == '/') {
/* 2060 */       if (isProlog) {
/* 2061 */         throwParseError("Unexpected character combination '</' in prolog.");
/*      */       }
/* 2063 */       throwParseError("Unexpected character combination '</' in epilog (extra close tag?).");
/* 2064 */     } else if ((c == ':') || (isNameStartChar(c)))
/*      */     {
/* 2066 */       if (!isProlog)
/*      */       {
/*      */ 
/*      */ 
/* 2070 */         this.mCurrToken = handleExtraRoot(c);
/* 2071 */         return false;
/*      */       }
/* 2073 */       handleRootElem(c);
/* 2074 */       this.mCurrToken = 1;
/*      */     } else {
/* 2076 */       throwUnexpectedChar(c, (isProlog ? " in prolog" : " in epilog") + ", after '<'.");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2081 */     if ((!this.mCfgLazyParsing) && (this.mTokenState < this.mStTextThreshold)) {
/* 2082 */       finishToken(false);
/*      */     }
/*      */     
/* 2085 */     return false;
/*      */   }
/*      */   
/*      */   protected void handleRootElem(char c)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2091 */     this.mParseState = 1;
/* 2092 */     initValidation();
/* 2093 */     handleStartElem(c);
/*      */     
/*      */ 
/* 2096 */     if ((this.mRootLName != null) && 
/* 2097 */       (hasConfigFlags(32)) && 
/* 2098 */       (!this.mElementStack.matches(this.mRootPrefix, this.mRootLName))) {
/* 2099 */       String actual = this.mRootPrefix + ":" + this.mRootLName;
/*      */       
/* 2101 */       reportValidationProblem(ErrorConsts.ERR_VLD_WRONG_ROOT, actual, this.mRootLName);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void initValidation()
/*      */     throws XMLStreamException
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int handleEOF(boolean isProlog)
/*      */     throws XMLStreamException
/*      */   {
/* 2125 */     this.mCurrToken = (this.mSecondaryToken = 8);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2131 */     this.mTextBuffer.recycle(true);
/*      */     
/* 2133 */     if (isProlog) {
/* 2134 */       throwUnexpectedEOF(" in prolog");
/*      */     }
/* 2136 */     return this.mCurrToken;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int handleExtraRoot(char c)
/*      */     throws XMLStreamException
/*      */   {
/* 2150 */     if (!this.mConfig.inputParsingModeDocuments())
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2155 */       throwParseError("Illegal to have multiple roots (start tag in epilog?).");
/*      */     }
/*      */     
/* 2158 */     this.mInputPtr -= 1;
/* 2159 */     return handleMultiDocStart(1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int handleMultiDocStart(int nextEvent)
/*      */   {
/* 2172 */     this.mParseState = 3;
/* 2173 */     this.mTokenState = 4;
/* 2174 */     this.mSecondaryToken = nextEvent;
/* 2175 */     return 8;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int nextFromMultiDocState()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2186 */     if (this.mCurrToken == 8)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2191 */       if (this.mSecondaryToken == 7) {
/* 2192 */         handleMultiDocXmlDecl();
/*      */       } else {
/* 2194 */         this.mDocXmlEncoding = null;
/* 2195 */         this.mDocXmlVersion = 0;
/* 2196 */         this.mDocStandalone = 0;
/*      */       }
/* 2198 */       return 7;
/*      */     }
/* 2200 */     if (this.mCurrToken == 7) {
/* 2201 */       this.mParseState = 0;
/*      */       
/*      */ 
/* 2204 */       if (this.mSecondaryToken == 7) {
/* 2205 */         nextFromProlog(true);
/* 2206 */         return this.mCurrToken;
/*      */       }
/*      */       
/* 2209 */       if (this.mSecondaryToken == 1) {
/* 2210 */         handleRootElem(getNextChar(" in start tag"));
/* 2211 */         return 1;
/*      */       }
/* 2213 */       if (this.mSecondaryToken == 11) {
/* 2214 */         this.mStDoctypeFound = true;
/* 2215 */         startDTD();
/* 2216 */         return 11;
/*      */       }
/*      */     }
/* 2219 */     throw new IllegalStateException("Internal error: unexpected state; current event " + tokenTypeDesc(this.mCurrToken) + ", sec. state: " + tokenTypeDesc(this.mSecondaryToken));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void handleMultiDocXmlDecl()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2227 */     this.mDocStandalone = 0;
/* 2228 */     this.mDocXmlEncoding = null;
/*      */     
/* 2230 */     char c = getNextInCurrAfterWS(" in xml declaration");
/* 2231 */     String wrong = checkKeyword(c, "version");
/* 2232 */     if (wrong != null) {
/* 2233 */       throwParseError(ErrorConsts.ERR_UNEXP_KEYWORD, wrong, "version");
/*      */     }
/* 2235 */     c = skipEquals("version", " in xml declaration");
/* 2236 */     TextBuffer tb = this.mTextBuffer;
/* 2237 */     tb.resetInitialized();
/* 2238 */     parseQuoted("version", c, tb);
/*      */     
/* 2240 */     if (tb.equalsString("1.0")) {
/* 2241 */       this.mDocXmlVersion = 256;
/* 2242 */       this.mXml11 = false;
/* 2243 */     } else if (tb.equalsString("1.1")) {
/* 2244 */       this.mDocXmlVersion = 272;
/* 2245 */       this.mXml11 = true;
/*      */     } else {
/* 2247 */       this.mDocXmlVersion = 0;
/* 2248 */       this.mXml11 = false;
/* 2249 */       throwParseError("Unexpected xml version '" + tb.toString() + "'; expected '" + "1.0" + "' or '" + "1.1" + "'");
/*      */     }
/*      */     
/* 2252 */     c = getNextInCurrAfterWS(" in xml declaration");
/*      */     
/* 2254 */     if (c != '?') {
/* 2255 */       if (c == 'e') {
/* 2256 */         wrong = checkKeyword(c, "encoding");
/* 2257 */         if (wrong != null) {
/* 2258 */           throwParseError(ErrorConsts.ERR_UNEXP_KEYWORD, wrong, "encoding");
/*      */         }
/* 2260 */         c = skipEquals("encoding", " in xml declaration");
/* 2261 */         tb.resetWithEmpty();
/* 2262 */         parseQuoted("encoding", c, tb);
/* 2263 */         this.mDocXmlEncoding = tb.toString();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2268 */         c = getNextInCurrAfterWS(" in xml declaration");
/* 2269 */       } else if (c != 's') {
/* 2270 */         throwUnexpectedChar(c, " in xml declaration; expected either 'encoding' or 'standalone' pseudo-attribute");
/*      */       }
/*      */       
/*      */ 
/* 2274 */       if (c == 's') {
/* 2275 */         wrong = checkKeyword(c, "standalone");
/* 2276 */         if (wrong != null) {
/* 2277 */           throwParseError(ErrorConsts.ERR_UNEXP_KEYWORD, wrong, "standalone");
/*      */         }
/* 2279 */         c = skipEquals("standalone", " in xml declaration");
/* 2280 */         tb.resetWithEmpty();
/* 2281 */         parseQuoted("standalone", c, tb);
/* 2282 */         if (tb.equalsString("yes")) {
/* 2283 */           this.mDocStandalone = 1;
/* 2284 */         } else if (tb.equalsString("no")) {
/* 2285 */           this.mDocStandalone = 2;
/*      */         } else {
/* 2287 */           throwParseError("Unexpected xml 'standalone' pseudo-attribute value '" + tb.toString() + "'; expected '" + "yes" + "' or '" + "no" + "'");
/*      */         }
/*      */         
/*      */ 
/* 2291 */         c = getNextInCurrAfterWS(" in xml declaration");
/*      */       }
/*      */     }
/*      */     
/* 2295 */     if (c != '?') {
/* 2296 */       throwUnexpectedChar(c, " in xml declaration; expected '?>' as the end marker");
/*      */     }
/* 2298 */     c = getNextCharFromCurrent(" in xml declaration");
/* 2299 */     if (c != '>') {
/* 2300 */       throwUnexpectedChar(c, " in xml declaration; expected '>' to close the declaration");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final char skipEquals(String name, String eofMsg)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2313 */     char c = getNextInCurrAfterWS(eofMsg);
/* 2314 */     if (c != '=') {
/* 2315 */       throwUnexpectedChar(c, " in xml declaration; expected '=' to follow pseudo-attribute '" + name + "'");
/*      */     }
/*      */     
/* 2318 */     return getNextInCurrAfterWS(eofMsg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void parseQuoted(String name, char quoteChar, TextBuffer tbuf)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2335 */     if ((quoteChar != '"') && (quoteChar != '\'')) {
/* 2336 */       throwUnexpectedChar(quoteChar, " in xml declaration; waited ' or \" to start a value for pseudo-attribute '" + name + "'");
/*      */     }
/* 2338 */     char[] outBuf = tbuf.getCurrentSegment();
/* 2339 */     int outPtr = 0;
/*      */     for (;;)
/*      */     {
/* 2342 */       char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextChar(" in xml declaration");
/*      */       
/*      */ 
/* 2345 */       if (c == quoteChar) {
/*      */         break;
/*      */       }
/* 2348 */       if ((c < ' ') || (c == '<')) {
/* 2349 */         throwUnexpectedChar(c, " in xml declaration");
/* 2350 */       } else if (c == 0) {
/* 2351 */         throwNullChar();
/*      */       }
/* 2353 */       if (outPtr >= outBuf.length) {
/* 2354 */         outBuf = tbuf.finishCurrentSegment();
/* 2355 */         outPtr = 0;
/*      */       }
/* 2357 */       outBuf[(outPtr++)] = c;
/*      */     }
/* 2359 */     tbuf.setCurrentLength(outPtr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void nextFromPrologBang(boolean isProlog)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2371 */     int i = getNext();
/* 2372 */     if (i < 0) {
/* 2373 */       throwUnexpectedEOF(" in prolog");
/*      */     }
/* 2375 */     if (i == 68) {
/* 2376 */       String keyw = checkKeyword('D', "DOCTYPE");
/* 2377 */       if (keyw != null) {
/* 2378 */         throwParseError("Unrecognized XML directive '<!" + keyw + "' (misspelled DOCTYPE?).");
/*      */       }
/*      */       
/* 2381 */       if (!isProlog)
/*      */       {
/* 2383 */         if (this.mConfig.inputParsingModeDocuments()) {
/* 2384 */           if (!this.mStDoctypeFound) {
/* 2385 */             this.mCurrToken = handleMultiDocStart(11);
/*      */           }
/*      */         }
/*      */         else {
/* 2389 */           throwParseError(ErrorConsts.ERR_DTD_IN_EPILOG);
/*      */         }
/*      */       }
/* 2392 */       if (this.mStDoctypeFound) {
/* 2393 */         throwParseError(ErrorConsts.ERR_DTD_DUP);
/*      */       }
/* 2395 */       this.mStDoctypeFound = true;
/*      */       
/* 2397 */       this.mCurrToken = 11;
/* 2398 */       startDTD();
/* 2399 */       return; }
/* 2400 */     if (i == 45) {
/* 2401 */       char c = getNextChar(isProlog ? " in prolog" : " in epilog");
/* 2402 */       if (c != '-') {
/* 2403 */         throwUnexpectedChar(i, " (malformed comment?)");
/*      */       }
/*      */       
/* 2406 */       this.mTokenState = 1;
/* 2407 */       this.mCurrToken = 5;
/* 2408 */       return; }
/* 2409 */     if (i == 91) {
/* 2410 */       i = peekNext();
/*      */       
/* 2412 */       if (i == 67) {
/* 2413 */         throwUnexpectedChar(i, ErrorConsts.ERR_CDATA_IN_EPILOG);
/*      */       }
/*      */     }
/*      */     
/* 2417 */     throwUnexpectedChar(i, " after '<!' (malformed comment?)");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void startDTD()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2431 */     this.mTextBuffer.resetInitialized();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2438 */     char c = getNextInCurrAfterWS(" in DOCTYPE declaration");
/* 2439 */     if (this.mCfgNsEnabled) {
/* 2440 */       String str = parseLocalName(c);
/* 2441 */       c = getNextChar(" in DOCTYPE declaration");
/* 2442 */       if (c == ':') {
/* 2443 */         this.mRootPrefix = str;
/* 2444 */         this.mRootLName = parseLocalName(getNextChar("; expected an identifier"));
/* 2445 */       } else if ((c <= ' ') || (c == '[') || (c == '>'))
/*      */       {
/* 2447 */         this.mInputPtr -= 1;
/* 2448 */         this.mRootPrefix = null;
/* 2449 */         this.mRootLName = str;
/*      */       } else {
/* 2451 */         throwUnexpectedChar(c, " in DOCTYPE declaration; expected '[' or white space.");
/*      */       }
/*      */     } else {
/* 2454 */       this.mRootLName = parseFullName(c);
/* 2455 */       this.mRootPrefix = null;
/*      */     }
/*      */     
/*      */ 
/* 2459 */     c = getNextInCurrAfterWS(" in DOCTYPE declaration");
/* 2460 */     if ((c != '[') && (c != '>')) {
/* 2461 */       String keyw = null;
/*      */       
/* 2463 */       if (c == 'P') {
/* 2464 */         keyw = checkKeyword(getNextChar(" in DOCTYPE declaration"), "UBLIC");
/* 2465 */         if (keyw != null) {
/* 2466 */           keyw = "P" + keyw;
/*      */         } else {
/* 2468 */           if (!skipWS(getNextChar(" in DOCTYPE declaration"))) {
/* 2469 */             throwUnexpectedChar(c, " in DOCTYPE declaration; expected a space between PUBLIC keyword and public id");
/*      */           }
/* 2471 */           c = getNextCharFromCurrent(" in DOCTYPE declaration");
/* 2472 */           if ((c != '"') && (c != '\'')) {
/* 2473 */             throwUnexpectedChar(c, " in DOCTYPE declaration; expected a public identifier.");
/*      */           }
/* 2475 */           this.mDtdPublicId = parsePublicId(c, this.mCfgNormalizeAttrs, " in DOCTYPE declaration");
/* 2476 */           if ((this.mDtdPublicId.length() != 0) || 
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 2481 */             (!skipWS(getNextChar(" in DOCTYPE declaration")))) {
/* 2482 */             throwUnexpectedChar(c, " in DOCTYPE declaration; expected a space between public and system identifiers");
/*      */           }
/* 2484 */           c = getNextCharFromCurrent(" in DOCTYPE declaration");
/* 2485 */           if ((c != '"') && (c != '\'')) {
/* 2486 */             throwParseError(" in DOCTYPE declaration; expected a system identifier.");
/*      */           }
/* 2488 */           this.mDtdSystemId = parseSystemId(c, this.mCfgNormalizeLFs, " in DOCTYPE declaration");
/* 2489 */           if (this.mDtdSystemId.length() != 0) {}
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */       }
/* 2495 */       else if (c == 'S') {
/* 2496 */         this.mDtdPublicId = null;
/* 2497 */         keyw = checkKeyword(getNextChar(" in DOCTYPE declaration"), "YSTEM");
/* 2498 */         if (keyw != null) {
/* 2499 */           keyw = "S" + keyw;
/*      */         } else {
/* 2501 */           c = getNextInCurrAfterWS(" in DOCTYPE declaration");
/* 2502 */           if ((c != '"') && (c != '\'')) {
/* 2503 */             throwUnexpectedChar(c, " in DOCTYPE declaration; expected a system identifier.");
/*      */           }
/* 2505 */           this.mDtdSystemId = parseSystemId(c, this.mCfgNormalizeLFs, " in DOCTYPE declaration");
/* 2506 */           if (this.mDtdSystemId.length() == 0)
/*      */           {
/* 2508 */             this.mDtdSystemId = null;
/*      */           }
/*      */         }
/*      */       }
/* 2512 */       else if (!isNameStartChar(c)) {
/* 2513 */         throwUnexpectedChar(c, " in DOCTYPE declaration; expected keywords 'PUBLIC' or 'SYSTEM'.");
/*      */       } else {
/* 2515 */         this.mInputPtr -= 1;
/* 2516 */         keyw = checkKeyword(c, "SYSTEM");
/*      */       }
/*      */       
/*      */ 
/* 2520 */       if (keyw != null) {
/* 2521 */         throwParseError("Unexpected keyword '" + keyw + "'; expected 'PUBLIC' or 'SYSTEM'");
/*      */       }
/*      */       
/*      */ 
/* 2525 */       c = getNextInCurrAfterWS(" in DOCTYPE declaration");
/*      */     }
/*      */     
/* 2528 */     if (c != '[')
/*      */     {
/*      */ 
/* 2531 */       if (c != '>') {
/* 2532 */         throwUnexpectedChar(c, " in DOCTYPE declaration; expected closing '>'.");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2540 */     this.mInputPtr -= 1;
/* 2541 */     this.mTokenState = 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void finishDTD(boolean copyContents)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2564 */     char c = getNextChar(" in DOCTYPE declaration");
/* 2565 */     if (c == '[')
/*      */     {
/* 2567 */       if (copyContents) {
/* 2568 */         ((BranchingReaderSource)this.mInput).startBranch(this.mTextBuffer, this.mInputPtr, this.mCfgNormalizeLFs);
/*      */       }
/*      */       try
/*      */       {
/* 2572 */         MinimalDTDReader.skipInternalSubset(this, this.mInput, this.mConfig);
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/* 2577 */         if (copyContents)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 2582 */           ((BranchingReaderSource)this.mInput).endBranch(this.mInputPtr - 1);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 2587 */       c = getNextCharAfterWS(" in internal DTD subset");
/*      */     }
/*      */     
/* 2590 */     if (c != '>') {
/* 2591 */       throwUnexpectedChar(c, "; expected '>' to finish DOCTYPE declaration.");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int nextFromTree()
/*      */     throws IOException, XMLStreamException
/*      */   {
/*      */     int i;
/*      */     
/*      */ 
/*      */ 
/*      */     label353:
/*      */     
/*      */ 
/*      */     int i;
/*      */     
/*      */ 
/* 2611 */     if (this.mTokenState < this.mStTextThreshold)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2617 */       if ((this.mVldContent == 2) && (
/* 2618 */         (this.mCurrToken == 4) || (this.mCurrToken == 12))) {
/* 2619 */         throwParseError("Internal error: skipping validatable text");
/*      */       }
/*      */       
/* 2622 */       i = skipToken();
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/* 2628 */       if (this.mCurrToken == 1)
/*      */       {
/* 2630 */         if (this.mStEmptyElem)
/*      */         {
/* 2632 */           this.mStEmptyElem = false;
/*      */           
/* 2634 */           return 2;
/*      */         }
/* 2636 */       } else if (this.mCurrToken == 2)
/*      */       {
/* 2638 */         int vld = this.mElementStack.pop();
/* 2639 */         this.mVldContent = vld;
/* 2640 */         this.mValidateText = (vld == 2);
/*      */         
/* 2642 */         if (this.mElementStack.isEmpty())
/*      */         {
/* 2644 */           if (!this.mConfig.inputParsingModeFragment()) {
/* 2645 */             this.mParseState = 2;
/*      */             
/* 2647 */             if (nextFromProlog(false)) {
/* 2648 */               this.mSecondaryToken = 0;
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 2654 */             if (this.mSymbols.isDirty()) {
/* 2655 */               this.mOwner.updateSymbolTable(this.mSymbols);
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 2661 */             this.mTextBuffer.recycle(false);
/* 2662 */             return this.mCurrToken;
/*      */           }
/*      */         }
/*      */       }
/* 2666 */       else if ((this.mCurrToken == 12) && (this.mTokenState <= 2))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2677 */         this.mTokenInputTotal = (this.mCurrInputProcessed + this.mInputPtr);
/* 2678 */         this.mTokenInputRow = this.mCurrInputRow;
/* 2679 */         this.mTokenInputCol = (this.mInputPtr - this.mCurrInputRowStart);
/* 2680 */         char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextChar(" in CDATA section");
/*      */         
/* 2682 */         if (readCDataPrimary(c))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2688 */           if (this.mTextBuffer.size() > 0) {
/* 2689 */             return 12;
/*      */           }
/*      */           
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/* 2697 */           if (this.mTextBuffer.size() == 0) { if (readCDataSecondary(this.mCfgLazyParsing ? 1 : this.mShortestTextSegment))
/*      */             {
/*      */ 
/*      */ 
/* 2701 */               if (this.mTextBuffer.size() <= 0)
/*      */                 break label353;
/* 2703 */               this.mTokenState = 3;
/* 2704 */               return 12;
/*      */             }
/*      */           }
/*      */           
/* 2708 */           this.mTokenState = 2;
/* 2709 */           return 12;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2718 */       this.mTokenInputTotal = (this.mCurrInputProcessed + this.mInputPtr);
/* 2719 */       this.mTokenInputRow = this.mCurrInputRow;
/* 2720 */       this.mTokenInputCol = (this.mInputPtr - this.mCurrInputRowStart);
/* 2721 */       i = getNext();
/*      */     }
/*      */     
/* 2724 */     if (i < 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2729 */       if (!this.mElementStack.isEmpty()) {
/* 2730 */         throwUnexpectedEOF("; was expecting a close tag for element <" + this.mElementStack.getTopElementDesc() + ">");
/*      */       }
/*      */       
/* 2733 */       return handleEOF(false);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2741 */     while (i == 38) {
/* 2742 */       this.mWsStatus = 0;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2747 */       if (this.mVldContent == 0)
/*      */       {
/*      */ 
/*      */ 
/* 2751 */         reportInvalidContent(9);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2757 */       char c = this.mCfgReplaceEntities ? fullyResolveEntity(true) : resolveCharOnlyEntity(true);
/*      */       
/*      */ 
/* 2760 */       if (c != 0)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2767 */         if (this.mVldContent <= 1)
/*      */         {
/* 2769 */           if (c > ' ')
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2776 */             if ((this.mVldContent < 1) || (this.mElementStack.reallyValidating()))
/*      */             {
/* 2778 */               reportInvalidContent(4);
/*      */             }
/*      */           }
/*      */         }
/*      */         
/* 2783 */         TextBuffer tb = this.mTextBuffer;
/* 2784 */         tb.resetInitialized();
/* 2785 */         tb.append(c);
/* 2786 */         this.mTokenState = 1;
/* 2787 */         return 4;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2793 */       if (!this.mCfgReplaceEntities) {
/* 2794 */         EntityDecl ed = resolveNonCharEntity();
/*      */         
/* 2796 */         this.mTokenState = 4;
/* 2797 */         this.mCurrEntity = ed;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2804 */         return 9;
/*      */       }
/*      */       
/*      */ 
/* 2808 */       i = getNextChar(" in main document content");
/*      */     }
/*      */     
/* 2811 */     if (i == 60)
/*      */     {
/* 2813 */       char c = getNextChar(" in start tag");
/* 2814 */       if (c == '?')
/*      */       {
/* 2816 */         if (this.mVldContent == 0) {
/* 2817 */           reportInvalidContent(3);
/*      */         }
/* 2819 */         return readPIPrimary();
/*      */       }
/*      */       
/* 2822 */       if (c == '!')
/*      */       {
/* 2824 */         int type = nextFromTreeCommentOrCData();
/*      */         
/* 2826 */         if (this.mVldContent == 0) {
/* 2827 */           reportInvalidContent(type);
/*      */         }
/* 2829 */         return type;
/*      */       }
/* 2831 */       if (c == '/') {
/* 2832 */         readEndElem();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2837 */         if (this.mCurrDepth == this.mInputTopDepth) {
/* 2838 */           handleGreedyEntityProblem(this.mInput);
/*      */         }
/* 2840 */         this.mCurrDepth -= 1;
/* 2841 */         return 2;
/*      */       }
/*      */       
/* 2844 */       if ((c == ':') || (isNameStartChar(c)))
/*      */       {
/*      */ 
/*      */ 
/* 2848 */         handleStartElem(c);
/* 2849 */         return 1;
/*      */       }
/* 2851 */       if (c == '[') {
/* 2852 */         throwUnexpectedChar(c, " in content after '<' (malformed <![CDATA[]] directive?)");
/*      */       }
/* 2854 */       throwUnexpectedChar(c, " in content after '<' (malformed start element?).");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2864 */     if (this.mVldContent <= 1) {
/* 2865 */       if ((this.mVldContent == 0) && 
/* 2866 */         (this.mElementStack.reallyValidating())) {
/* 2867 */         reportInvalidContent(4);
/*      */       }
/*      */       
/* 2870 */       if (i <= 32)
/*      */       {
/*      */ 
/*      */ 
/* 2874 */         this.mTokenState = (readSpacePrimary((char)i, false) ? 4 : 1);
/*      */         
/* 2876 */         return 6;
/*      */       }
/*      */       
/* 2879 */       if (this.mElementStack.reallyValidating()) {
/* 2880 */         reportInvalidContent(4);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2888 */     if (readTextPrimary((char)i)) {
/* 2889 */       this.mTokenState = 3;
/*      */ 
/*      */     }
/* 2892 */     else if ((!this.mCfgCoalesceText) && (this.mTextBuffer.size() >= this.mShortestTextSegment))
/*      */     {
/* 2894 */       this.mTokenState = 2;
/*      */     } else {
/* 2896 */       this.mTokenState = 1;
/*      */     }
/*      */     
/* 2899 */     return 4;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void handleStartElem(char c)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2910 */     this.mTokenState = 4;
/*      */     boolean empty;
/*      */     boolean empty;
/* 2913 */     if (this.mCfgNsEnabled) {
/* 2914 */       String str = parseLocalName(c);
/* 2915 */       c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent("; expected an identifier");
/*      */       
/* 2917 */       if (c == ':') {
/* 2918 */         c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent("; expected an identifier");
/*      */         
/* 2920 */         this.mElementStack.push(str, parseLocalName(c));
/* 2921 */         c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in start tag");
/*      */       }
/*      */       else {
/* 2924 */         this.mElementStack.push(DEFAULT_NS_PREFIX, str);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2936 */       empty = c == '>' ? false : handleNsAttrs(c);
/*      */     } else {
/* 2938 */       this.mElementStack.push(parseFullName(c));
/* 2939 */       c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in start tag");
/*      */       
/* 2941 */       empty = c == '>' ? false : handleNonNsAttrs(c);
/*      */     }
/* 2943 */     if (!empty) {
/* 2944 */       this.mCurrDepth += 1;
/*      */     }
/* 2946 */     this.mStEmptyElem = empty;
/* 2947 */     int vld = this.mElementStack.resolveAndValidateElement();
/* 2948 */     this.mVldContent = vld;
/* 2949 */     this.mValidateText = (vld == 2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final boolean handleNsAttrs(char c)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 2958 */     AttributeCollector ac = this.mAttrCollector;
/* 2959 */     boolean gotDefaultNS = false;
/*      */     for (;;)
/*      */     {
/* 2962 */       if (c <= ' ') {
/* 2963 */         c = getNextInCurrAfterWS(" in start tag", c);
/* 2964 */       } else if ((c != '/') && (c != '>')) {
/* 2965 */         throwUnexpectedChar(c, " excepted space, or '>' or \"/>\"");
/*      */       }
/*      */       
/* 2968 */       if (c == '/') {
/* 2969 */         c = getNextCharFromCurrent(" in start tag");
/* 2970 */         if (c != '>') {
/* 2971 */           throwUnexpectedChar(c, " expected '>'");
/*      */         }
/* 2973 */         return true; }
/* 2974 */       if (c == '>')
/* 2975 */         return false;
/* 2976 */       if (c == '<') {
/* 2977 */         throwParseError("Unexpected '<' character in element (missing closing '>'?)");
/*      */       }
/*      */       
/*      */ 
/* 2981 */       String str = parseLocalName(c);
/* 2982 */       c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent("; expected an identifier");
/*      */       String localName;
/* 2984 */       String prefix; String localName; if (c == ':') {
/* 2985 */         String prefix = str;
/* 2986 */         c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent("; expected an identifier");
/*      */         
/* 2988 */         localName = parseLocalName(c);
/*      */       } else {
/* 2990 */         this.mInputPtr -= 1;
/* 2991 */         prefix = DEFAULT_NS_PREFIX;
/* 2992 */         localName = str;
/*      */       }
/*      */       
/* 2995 */       c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in start tag");
/*      */       
/* 2997 */       if (c <= ' ') {
/* 2998 */         c = getNextInCurrAfterWS(" in start tag", c);
/*      */       }
/* 3000 */       if (c != '=') {
/* 3001 */         throwUnexpectedChar(c, " expected '='");
/*      */       }
/* 3003 */       c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in start tag");
/*      */       
/* 3005 */       if (c <= ' ') {
/* 3006 */         c = getNextInCurrAfterWS(" in start tag", c);
/*      */       }
/*      */       
/*      */ 
/* 3010 */       if ((c != '"') && (c != '\'')) {
/* 3011 */         throwUnexpectedChar(c, " in start tag Expected a quote");
/*      */       }
/*      */       
/*      */ 
/* 3015 */       int startLen = -1;
/*      */       
/*      */       TextBuilder tb;
/* 3018 */       if (prefix == sPrefixXmlns) {
/* 3019 */         TextBuilder tb = ac.getNsBuilder(localName);
/*      */         
/* 3021 */         if (null == tb) {
/* 3022 */           throwParseError("Duplicate declaration for namespace prefix '" + localName + "'.");
/*      */         }
/* 3024 */         startLen = tb.getCharSize();
/* 3025 */       } else if ((localName == sPrefixXmlns) && (prefix == DEFAULT_NS_PREFIX)) {
/* 3026 */         TextBuilder tb = ac.getDefaultNsBuilder();
/*      */         
/* 3028 */         if (null == tb) {
/* 3029 */           throwParseError("Duplicate default namespace declaration.");
/*      */         }
/*      */       } else {
/* 3032 */         tb = ac.getAttrBuilder(prefix, localName);
/*      */       }
/* 3034 */       tb.startNewEntry();
/*      */       
/* 3036 */       if (this.mCfgNormalizeAttrs) {
/* 3037 */         parseNormalizedAttrValue(c, tb);
/*      */       } else {
/* 3039 */         parseNonNormalizedAttrValue(c, tb);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3052 */       if ((!this.mXml11) && 
/* 3053 */         (startLen >= 0) && (tb.getCharSize() == startLen)) {
/* 3054 */         throwParseError(ErrorConsts.ERR_NS_EMPTY);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3059 */       c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in start tag");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final boolean handleNonNsAttrs(char c)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 3071 */     AttributeCollector ac = this.mAttrCollector;
/*      */     for (;;)
/*      */     {
/* 3074 */       if (c <= ' ') {
/* 3075 */         c = getNextInCurrAfterWS(" in start tag", c);
/* 3076 */       } else if ((c != '/') && (c != '>')) {
/* 3077 */         throwUnexpectedChar(c, " excepted space, or '>' or \"/>\"");
/*      */       }
/* 3079 */       if (c == '/') {
/* 3080 */         c = getNextCharFromCurrent(" in start tag");
/* 3081 */         if (c != '>') {
/* 3082 */           throwUnexpectedChar(c, " expected '>'");
/*      */         }
/* 3084 */         return true; }
/* 3085 */       if (c == '>')
/* 3086 */         return false;
/* 3087 */       if (c == '<') {
/* 3088 */         throwParseError("Unexpected '<' character in element (missing closing '>'?)");
/*      */       }
/*      */       
/* 3091 */       String name = parseFullName(c);
/* 3092 */       TextBuilder tb = ac.getAttrBuilder(null, name);
/* 3093 */       c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in start tag");
/*      */       
/* 3095 */       if (c <= ' ') {
/* 3096 */         c = getNextInCurrAfterWS(" in start tag", c);
/*      */       }
/* 3098 */       if (c != '=') {
/* 3099 */         throwUnexpectedChar(c, " expected '='");
/*      */       }
/* 3101 */       c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in start tag");
/*      */       
/* 3103 */       if (c <= ' ') {
/* 3104 */         c = getNextInCurrAfterWS(" in start tag", c);
/*      */       }
/*      */       
/*      */ 
/* 3108 */       if ((c != '"') && (c != '\'')) {
/* 3109 */         throwUnexpectedChar(c, " in start tag Expected a quote");
/*      */       }
/*      */       
/*      */ 
/* 3113 */       tb.startNewEntry();
/*      */       
/* 3115 */       if (this.mCfgNormalizeAttrs) {
/* 3116 */         parseNormalizedAttrValue(c, tb);
/*      */       } else {
/* 3118 */         parseNonNormalizedAttrValue(c, tb);
/*      */       }
/*      */       
/* 3121 */       c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in start tag");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void readEndElem()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 3134 */     this.mTokenState = 4;
/* 3135 */     if (this.mElementStack.isEmpty())
/*      */     {
/* 3137 */       reportExtraEndElem();
/* 3138 */       return;
/*      */     }
/*      */     
/* 3141 */     char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in end tag");
/*      */     
/*      */ 
/* 3144 */     if ((!isNameStartChar(c)) && (c != ':')) {
/* 3145 */       if (c <= ' ') {
/* 3146 */         throwUnexpectedChar(c, "; missing element name?");
/*      */       }
/* 3148 */       throwUnexpectedChar(c, "; expected an element name.");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3154 */     String expPrefix = this.mElementStack.getPrefix();
/* 3155 */     String expLocalName = this.mElementStack.getLocalName();
/*      */     
/*      */ 
/* 3158 */     if ((expPrefix != null) && (expPrefix.length() > 0)) {
/* 3159 */       int len = expPrefix.length();
/* 3160 */       int i = 0;
/*      */       for (;;)
/*      */       {
/* 3163 */         if (c != expPrefix.charAt(i)) {
/* 3164 */           reportWrongEndPrefix(expPrefix, expLocalName, i);
/* 3165 */           return;
/*      */         }
/* 3167 */         i++; if (i >= len) {
/*      */           break;
/*      */         }
/* 3170 */         c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in end tag");
/*      */       }
/*      */       
/*      */ 
/* 3174 */       c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in end tag");
/*      */       
/* 3176 */       if (c != ':') {
/* 3177 */         reportWrongEndPrefix(expPrefix, expLocalName, i);
/* 3178 */         return;
/*      */       }
/* 3180 */       c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in end tag");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/* 3187 */     else if (c == ':') {
/* 3188 */       c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in end tag");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3194 */     int len = expLocalName.length();
/* 3195 */     int i = 0;
/*      */     for (;;)
/*      */     {
/* 3198 */       if (c != expLocalName.charAt(i))
/*      */       {
/* 3200 */         reportWrongEndElem(expPrefix, expLocalName, i);
/* 3201 */         return;
/*      */       }
/* 3203 */       i++; if (i >= len) {
/*      */         break;
/*      */       }
/* 3206 */       c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in end tag");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3211 */     c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in end tag");
/*      */     
/* 3213 */     if (c <= ' ') {
/* 3214 */       c = getNextInCurrAfterWS(" in end tag", c);
/* 3215 */     } else if (c != '>')
/*      */     {
/* 3217 */       if ((c == ':') || (isNameChar(c))) {
/* 3218 */         reportWrongEndElem(expPrefix, expLocalName, len);
/*      */       }
/*      */     }
/*      */     
/* 3222 */     if (c != '>') {
/* 3223 */       throwUnexpectedChar(c, " in end tag Expected '>'.");
/*      */     }
/*      */   }
/*      */   
/*      */   private void reportExtraEndElem()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 3230 */     String name = parseFNameForError();
/* 3231 */     throwParseError("Unbalanced close tag </" + name + ">; no open start tag.");
/*      */   }
/*      */   
/*      */   private void reportWrongEndPrefix(String prefix, String localName, int done)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 3237 */     this.mInputPtr -= 1;
/* 3238 */     String fullName = prefix + ":" + localName;
/* 3239 */     String rest = parseFNameForError();
/* 3240 */     String actName = fullName.substring(0, done) + rest;
/* 3241 */     throwParseError("Unexpected close tag </" + actName + ">; expected </" + fullName + ">.");
/*      */   }
/*      */   
/*      */ 
/*      */   private void reportWrongEndElem(String prefix, String localName, int done)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 3248 */     this.mInputPtr -= 1;
/*      */     String fullName;
/* 3250 */     if ((prefix != null) && (prefix.length() > 0)) {
/* 3251 */       String fullName = prefix + ":" + localName;
/* 3252 */       done += 1 + prefix.length();
/*      */     } else {
/* 3254 */       fullName = localName;
/*      */     }
/* 3256 */     String rest = parseFNameForError();
/* 3257 */     String actName = fullName.substring(0, done) + rest;
/* 3258 */     throwParseError("Unexpected close tag </" + actName + ">; expected </" + fullName + ">.");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int nextFromTreeCommentOrCData()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 3272 */     char c = getNextCharFromCurrent(" in main document content");
/* 3273 */     if (c == '[') {
/* 3274 */       checkCData();
/*      */       
/*      */ 
/*      */ 
/* 3278 */       c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in CDATA section");
/*      */       
/* 3280 */       readCDataPrimary(c);
/* 3281 */       return 12;
/*      */     }
/* 3283 */     if ((c == '-') && (getNextCharFromCurrent(" in main document content") == '-')) {
/* 3284 */       this.mTokenState = 1;
/* 3285 */       return 5;
/*      */     }
/* 3287 */     throwParseError("Unrecognized XML directive; expected CDATA or comment ('<![CDATA[' or '<!--').");
/* 3288 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int skipToken()
/*      */     throws IOException, XMLStreamException
/*      */   {
/*      */     int result;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     int result;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3315 */     switch (this.mCurrToken)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 12: 
/* 3323 */       if (this.mTokenState <= 2)
/*      */       {
/* 3325 */         skipCommentOrCData(" in CDATA section", ']', false);
/*      */       }
/* 3327 */       result = getNext();
/*      */       
/* 3329 */       if (this.mCfgCoalesceText) {
/* 3330 */         result = skipCoalescedText(result);
/*      */       }
/*      */       
/*      */ 
/*      */       break;
/*      */     case 5: 
/* 3336 */       skipCommentOrCData(" in comment", '-', true);
/* 3337 */       result = 0;
/* 3338 */       break;
/*      */     
/*      */ 
/*      */     case 4: 
/* 3342 */       result = skipTokenText(getNext());
/*      */       
/* 3344 */       if (this.mCfgCoalesceText) {
/* 3345 */         result = skipCoalescedText(result);
/*      */       }
/*      */       
/*      */ 
/*      */       break;
/*      */     case 11: 
/* 3351 */       finishDTD(false);
/* 3352 */       result = 0;
/* 3353 */       break;
/*      */     case 3: 
/*      */       for (;;)
/*      */       {
/* 3357 */         char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in processing instruction");
/*      */         
/* 3359 */         if (c == '?') {
/*      */           do {
/* 3361 */             c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in processing instruction");
/*      */           }
/* 3363 */           while (c == '?');
/* 3364 */           if (c == '>') {
/* 3365 */             result = 0;
/* 3366 */             break;
/*      */           }
/*      */         }
/* 3369 */         if (c < ' ') {
/* 3370 */           if ((c == '\n') || (c == '\r')) {
/* 3371 */             skipCRLF(c);
/* 3372 */           } else if (c != '\t') {
/* 3373 */             throwInvalidSpace(c);
/*      */           }
/*      */         }
/*      */       }
/*      */     
/*      */ 
/*      */ 
/*      */     case 6: 
/*      */       do
/*      */       {
/* 3383 */         while (this.mInputPtr < this.mInputLen) {
/* 3384 */           char c = this.mInputBuffer[(this.mInputPtr++)];
/* 3385 */           if (c > ' ') {
/* 3386 */             int result = c;
/*      */             break label470;
/*      */           }
/* 3389 */           if ((c == '\n') || (c == '\r')) {
/* 3390 */             skipCRLF(c);
/* 3391 */           } else if ((c != ' ') && (c != '\t')) {
/* 3392 */             throwInvalidSpace(c);
/*      */           }
/*      */         }
/* 3395 */       } while (loadMore());
/* 3396 */       result = -1;
/* 3397 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 7: 
/*      */     case 8: 
/*      */     case 9: 
/*      */     case 14: 
/*      */     case 15: 
/* 3408 */       throw new IllegalStateException("skipToken() called when current token is " + tokenTypeDesc(this.mCurrToken));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/*      */     case 2: 
/*      */     case 10: 
/*      */     case 13: 
/*      */     default: 
/* 3420 */       throw new IllegalStateException("Internal error: unexpected token " + tokenTypeDesc(this.mCurrToken));
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     label470:
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3434 */     if (result < 1) {
/* 3435 */       this.mTokenInputRow = this.mCurrInputRow;
/* 3436 */       this.mTokenInputTotal = (this.mCurrInputProcessed + this.mInputPtr);
/* 3437 */       this.mTokenInputCol = (this.mInputPtr - this.mCurrInputRowStart);
/* 3438 */       return result < 0 ? result : getNext();
/*      */     }
/*      */     
/*      */ 
/* 3442 */     this.mTokenInputRow = this.mCurrInputRow;
/* 3443 */     this.mTokenInputTotal = (this.mCurrInputProcessed + this.mInputPtr - 1L);
/* 3444 */     this.mTokenInputCol = (this.mInputPtr - this.mCurrInputRowStart - 1);
/* 3445 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void skipCommentOrCData(String errorMsg, char endChar, boolean preventDoubles)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*      */     for (;;)
/*      */     {
/* 3457 */       char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(errorMsg);
/*      */       
/* 3459 */       if (c < ' ') {
/* 3460 */         if ((c == '\n') || (c == '\r')) {
/* 3461 */           skipCRLF(c);
/* 3462 */         } else if (c != '\t') {
/* 3463 */           throwInvalidSpace(c);
/*      */         }
/*      */       }
/* 3466 */       if (c == endChar)
/*      */       {
/*      */ 
/* 3469 */         c = getNextChar(errorMsg);
/* 3470 */         if (c == endChar)
/*      */         {
/* 3472 */           c = getNextChar(errorMsg);
/* 3473 */           if (c == '>') {
/*      */             break;
/*      */           }
/* 3476 */           if (preventDoubles) {
/* 3477 */             throwParseError("String '--' not allowed in comment (missing '>'?)");
/*      */           }
/*      */           
/* 3480 */           while (c == endChar) {
/* 3481 */             c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(errorMsg);
/*      */           }
/*      */           
/* 3484 */           if (c == '>') {
/*      */             break;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 3490 */         if (c < ' ') {
/* 3491 */           if ((c == '\n') || (c == '\r')) {
/* 3492 */             skipCRLF(c);
/* 3493 */           } else if (c != '\t') {
/* 3494 */             throwInvalidSpace(c);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int skipCoalescedText(int i)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*      */     do
/*      */     {
/* 3515 */       while (i == 60)
/*      */       {
/* 3517 */         if (!ensureInput(3))
/*      */         {
/*      */ 
/*      */ 
/* 3521 */           return i;
/*      */         }
/* 3523 */         if ((this.mInputBuffer[this.mInputPtr] != '!') || (this.mInputBuffer[(this.mInputPtr + 1)] != '['))
/*      */         {
/*      */ 
/* 3526 */           return i;
/*      */         }
/*      */         
/* 3529 */         this.mInputPtr += 2;
/*      */         
/* 3531 */         checkCData();
/* 3532 */         skipCommentOrCData(" in CDATA section", ']', false);
/* 3533 */         i = getNext(); }
/* 3534 */       if (i < 0) {
/* 3535 */         return i;
/*      */       }
/* 3537 */       i = skipTokenText(i);
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/* 3542 */     while ((i != 38) && (i >= 0));
/* 3543 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int skipTokenText(int i)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*      */     for (;;)
/*      */     {
/* 3557 */       if (i == 60) {
/* 3558 */         return i;
/*      */       }
/* 3560 */       if (i == 38)
/*      */       {
/* 3562 */         if (this.mCfgReplaceEntities)
/*      */         {
/* 3564 */           if ((this.mInputLen - this.mInputPtr < 3) || (resolveSimpleEntity(true) == 0))
/*      */           {
/*      */ 
/*      */ 
/* 3568 */             i = fullyResolveEntity(true);
/*      */ 
/*      */ 
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/* 3577 */         else if (resolveCharOnlyEntity(true) == 0)
/*      */         {
/*      */ 
/*      */ 
/* 3581 */           return i;
/*      */         }
/*      */       }
/* 3584 */       else if (i < 32) {
/* 3585 */         if ((i == 13) || (i == 10)) {
/* 3586 */           skipCRLF((char)i);
/* 3587 */         } else { if (i < 0)
/* 3588 */             return i;
/* 3589 */           if (i != 9) {
/* 3590 */             throwInvalidSpace(i);
/*      */           }
/*      */         }
/*      */       }
/*      */       for (;;)
/*      */       {
/* 3596 */         if (this.mInputPtr >= this.mInputLen) break label151;
/* 3597 */         char c = this.mInputBuffer[(this.mInputPtr++)];
/* 3598 */         if (c < '?') {
/* 3599 */           i = c;
/* 3600 */           break;
/*      */         }
/*      */       }
/*      */       label151:
/* 3604 */       i = getNext();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void ensureFinishToken()
/*      */     throws XMLStreamException
/*      */   {
/* 3618 */     if (this.mTokenState < this.mStTextThreshold) {
/* 3619 */       wrappedFinishToken();
/*      */     }
/*      */   }
/*      */   
/*      */   protected void safeEnsureFinishToken()
/*      */   {
/* 3625 */     if (this.mTokenState < this.mStTextThreshold) {
/* 3626 */       safeFinishToken();
/*      */     }
/*      */   }
/*      */   
/*      */   protected void wrappedFinishToken() throws XMLStreamException
/*      */   {
/*      */     try
/*      */     {
/* 3634 */       finishToken(false);
/*      */     } catch (IOException ie) {
/* 3636 */       throwFromIOE(ie);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void safeFinishToken()
/*      */   {
/*      */     try
/*      */     {
/* 3648 */       boolean deferErrors = this.mCurrToken == 4;
/* 3649 */       finishToken(deferErrors);
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (IOException ioe)
/*      */     {
/*      */ 
/*      */ 
/* 3657 */       throwLazyError(ioe);
/*      */     } catch (XMLStreamException strex) {
/* 3659 */       throwLazyError(strex);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void finishToken(boolean deferErrors)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 3676 */     switch (this.mCurrToken) {
/*      */     case 12: 
/* 3678 */       if (this.mCfgCoalesceText) {
/* 3679 */         readCoalescedText(this.mCurrToken, deferErrors);
/*      */       }
/* 3681 */       else if (readCDataSecondary(this.mShortestTextSegment)) {
/* 3682 */         this.mTokenState = 3;
/*      */       } else {
/* 3684 */         this.mTokenState = 2;
/*      */       }
/*      */       
/* 3687 */       return;
/*      */     
/*      */     case 4: 
/* 3690 */       if (this.mCfgCoalesceText)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 3695 */         if ((this.mTokenState == 3) && (this.mInputPtr + 1 < this.mInputLen) && (this.mInputBuffer[(this.mInputPtr + 1)] != '!'))
/*      */         {
/*      */ 
/* 3698 */           this.mTokenState = 4;
/* 3699 */           return;
/*      */         }
/* 3701 */         readCoalescedText(this.mCurrToken, deferErrors);
/*      */       }
/* 3703 */       else if (readTextSecondary(this.mShortestTextSegment, deferErrors)) {
/* 3704 */         this.mTokenState = 3;
/*      */       } else {
/* 3706 */         this.mTokenState = 2;
/*      */       }
/*      */       
/* 3709 */       return;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 6: 
/* 3717 */       boolean prolog = this.mParseState != 1;
/* 3718 */       readSpaceSecondary(prolog);
/* 3719 */       this.mTokenState = 4;
/*      */       
/* 3721 */       return;
/*      */     
/*      */     case 5: 
/* 3724 */       readComment();
/* 3725 */       this.mTokenState = 4;
/* 3726 */       return;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 11: 
/*      */       try
/*      */       {
/* 3737 */         finishDTD(true);
/*      */       } finally {
/* 3739 */         this.mTokenState = 4;
/*      */       }
/* 3741 */       return;
/*      */     
/*      */     case 3: 
/* 3744 */       readPI();
/* 3745 */       this.mTokenState = 4;
/* 3746 */       return;
/*      */     
/*      */     case 1: 
/*      */     case 2: 
/*      */     case 7: 
/*      */     case 8: 
/*      */     case 9: 
/*      */     case 14: 
/*      */     case 15: 
/* 3755 */       throw new IllegalStateException("finishToken() called when current token is " + tokenTypeDesc(this.mCurrToken));
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3763 */     throw new IllegalStateException("Internal error: unexpected token " + tokenTypeDesc(this.mCurrToken));
/*      */   }
/*      */   
/*      */   private void readComment()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 3769 */     char[] inputBuf = this.mInputBuffer;
/* 3770 */     int inputLen = this.mInputLen;
/* 3771 */     int ptr = this.mInputPtr;
/* 3772 */     int start = ptr;
/*      */     
/*      */ 
/* 3775 */     while (ptr < inputLen) {
/* 3776 */       char c = inputBuf[(ptr++)];
/* 3777 */       if (c <= '-')
/*      */       {
/*      */ 
/*      */ 
/* 3781 */         if (c < ' ') {
/* 3782 */           if (c == '\n') {
/* 3783 */             markLF(ptr);
/* 3784 */           } else if (c == '\r') {
/* 3785 */             if ((!this.mCfgNormalizeLFs) && (ptr < inputLen)) {
/* 3786 */               if (inputBuf[ptr] == '\n') {
/* 3787 */                 ptr++;
/*      */               }
/* 3789 */               markLF(ptr);
/*      */             } else {
/* 3791 */               ptr--;
/* 3792 */               break;
/*      */             }
/* 3794 */           } else if (c != '\t') {
/* 3795 */             throwInvalidSpace(c);
/*      */           }
/* 3797 */         } else if (c == '-')
/*      */         {
/*      */ 
/* 3800 */           if (ptr + 1 >= inputLen)
/*      */           {
/*      */ 
/*      */ 
/* 3804 */             ptr--;
/* 3805 */             break;
/*      */           }
/*      */           
/* 3808 */           if (inputBuf[ptr] == '-')
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 3813 */             c = inputBuf[(ptr + 1)];
/* 3814 */             if (c != '>') {
/* 3815 */               throwParseError("String '--' not allowed in comment (missing '>'?)");
/*      */             }
/* 3817 */             this.mTextBuffer.resetWithShared(inputBuf, start, ptr - start - 1);
/* 3818 */             this.mInputPtr = (ptr + 2);
/* 3819 */             return;
/*      */           }
/*      */         } }
/*      */     }
/* 3823 */     this.mInputPtr = ptr;
/* 3824 */     this.mTextBuffer.resetWithCopy(inputBuf, start, ptr - start);
/* 3825 */     readComment2(this.mTextBuffer);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readComment2(TextBuffer tb)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 3834 */     char[] outBuf = this.mTextBuffer.getCurrentSegment();
/* 3835 */     int outPtr = this.mTextBuffer.getCurrentSegmentSize();
/* 3836 */     int outLen = outBuf.length;
/*      */     for (;;)
/*      */     {
/* 3839 */       char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in comment");
/*      */       
/*      */ 
/* 3842 */       if (c < ' ') {
/* 3843 */         if (c == '\n') {
/* 3844 */           markLF();
/* 3845 */         } else if (c == '\r') {
/* 3846 */           if (skipCRLF(c)) {
/* 3847 */             if (!this.mCfgNormalizeLFs) {
/* 3848 */               if (outPtr >= outLen) {
/* 3849 */                 outBuf = this.mTextBuffer.finishCurrentSegment();
/* 3850 */                 outLen = outBuf.length;
/* 3851 */                 outPtr = 0;
/*      */               }
/* 3853 */               outBuf[(outPtr++)] = c;
/*      */             }
/*      */             
/* 3856 */             c = '\n';
/* 3857 */           } else if (this.mCfgNormalizeLFs) {
/* 3858 */             c = '\n';
/*      */           }
/* 3860 */         } else if (c != '\t') {
/* 3861 */           throwInvalidSpace(c);
/*      */         }
/* 3863 */       } else if (c == '-') {
/* 3864 */         c = getNextCharFromCurrent(" in comment");
/* 3865 */         if (c == '-')
/*      */         {
/* 3867 */           c = getNextCharFromCurrent(" in comment");
/* 3868 */           if (c == '>') break;
/* 3869 */           throwParseError(ErrorConsts.ERR_HYPHENS_IN_COMMENT); break;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3878 */         c = '-';
/* 3879 */         this.mInputPtr -= 1;
/*      */       }
/*      */       
/*      */ 
/* 3883 */       if (outPtr >= outLen) {
/* 3884 */         outBuf = this.mTextBuffer.finishCurrentSegment();
/* 3885 */         outLen = outBuf.length;
/* 3886 */         outPtr = 0;
/*      */       }
/*      */       
/* 3889 */       outBuf[(outPtr++)] = c;
/*      */     }
/*      */     
/*      */ 
/* 3893 */     this.mTextBuffer.setCurrentLength(outPtr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int readPIPrimary()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 3908 */     String target = parseFullName();
/* 3909 */     this.mCurrName = target;
/*      */     
/* 3911 */     if (target.length() == 0) {
/* 3912 */       throwParseError(ErrorConsts.ERR_WF_PI_MISSING_TARGET);
/*      */     }
/*      */     
/*      */ 
/* 3916 */     if (target.equalsIgnoreCase("xml"))
/*      */     {
/* 3918 */       if (!this.mConfig.inputParsingModeDocuments()) {
/* 3919 */         throwParseError(ErrorConsts.ERR_WF_PI_XML_TARGET, target);
/*      */       }
/*      */       
/* 3922 */       char c = getNextCharFromCurrent(" in xml declaration");
/* 3923 */       if (!isSpaceChar(c)) {
/* 3924 */         throwUnexpectedChar(c, "excepted a space in xml declaration after 'xml'");
/*      */       }
/* 3926 */       return handleMultiDocStart(7);
/*      */     }
/*      */     
/*      */ 
/* 3930 */     char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in processing instruction");
/*      */     
/* 3932 */     if (isSpaceChar(c)) {
/* 3933 */       this.mTokenState = 1;
/*      */       
/* 3935 */       skipWS(c);
/*      */     } else {
/* 3937 */       this.mTokenState = 4;
/* 3938 */       this.mTextBuffer.resetWithEmpty();
/*      */       
/* 3940 */       if ((c != '?') || (getNextCharFromCurrent(" in processing instruction") != '>')) {
/* 3941 */         throwUnexpectedChar(c, ErrorConsts.ERR_WF_PI_XML_MISSING_SPACE);
/*      */       }
/*      */     }
/*      */     
/* 3945 */     return 3;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readPI()
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 3955 */     int ptr = this.mInputPtr;
/* 3956 */     int start = ptr;
/* 3957 */     char[] inputBuf = this.mInputBuffer;
/* 3958 */     int inputLen = this.mInputLen;
/*      */     
/*      */ 
/* 3961 */     while (ptr < inputLen) {
/* 3962 */       char c = inputBuf[(ptr++)];
/* 3963 */       if (c < ' ') {
/* 3964 */         if (c == '\n') {
/* 3965 */           markLF(ptr);
/* 3966 */         } else if (c == '\r') {
/* 3967 */           if ((ptr < inputLen) && (!this.mCfgNormalizeLFs)) {
/* 3968 */             if (inputBuf[ptr] == '\n') {
/* 3969 */               ptr++;
/*      */             }
/* 3971 */             markLF(ptr);
/*      */           } else {
/* 3973 */             ptr--;
/* 3974 */             break;
/*      */           }
/* 3976 */         } else if (c != '\t') {
/* 3977 */           throwInvalidSpace(c);
/*      */         }
/* 3979 */       } else if (c == '?')
/*      */       {
/*      */         do {
/* 3982 */           if (ptr >= inputLen)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 3987 */             ptr--;
/* 3988 */             break;
/*      */           }
/* 3990 */           c = inputBuf[(ptr++)];
/* 3991 */           if (c == '>') {
/* 3992 */             this.mInputPtr = ptr;
/*      */             
/* 3994 */             this.mTextBuffer.resetWithShared(inputBuf, start, ptr - start - 2);
/* 3995 */             return;
/*      */           }
/* 3997 */         } while (c == '?');
/*      */         
/* 3999 */         ptr--;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4006 */     this.mInputPtr = ptr;
/*      */     
/* 4008 */     this.mTextBuffer.resetWithCopy(inputBuf, start, ptr - start);
/* 4009 */     readPI2(this.mTextBuffer);
/*      */   }
/*      */   
/*      */   private void readPI2(TextBuffer tb)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 4015 */     char[] inputBuf = this.mInputBuffer;
/* 4016 */     int inputLen = this.mInputLen;
/* 4017 */     int inputPtr = this.mInputPtr;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4022 */     char[] outBuf = tb.getCurrentSegment();
/* 4023 */     int outPtr = tb.getCurrentSegmentSize();
/*      */     
/*      */ 
/*      */     for (;;)
/*      */     {
/* 4028 */       if (inputPtr >= inputLen) {
/* 4029 */         loadMoreFromCurrent(" in processing instruction");
/* 4030 */         inputBuf = this.mInputBuffer;
/* 4031 */         inputPtr = this.mInputPtr;
/* 4032 */         inputLen = this.mInputLen;
/*      */       }
/*      */       
/*      */ 
/* 4036 */       char c = inputBuf[(inputPtr++)];
/* 4037 */       if (c < ' ') {
/* 4038 */         if (c == '\n') {
/* 4039 */           markLF(inputPtr);
/* 4040 */         } else if (c == '\r') {
/* 4041 */           this.mInputPtr = inputPtr;
/* 4042 */           if (skipCRLF(c)) {
/* 4043 */             if (!this.mCfgNormalizeLFs)
/*      */             {
/* 4045 */               if (outPtr >= outBuf.length) {
/* 4046 */                 outBuf = this.mTextBuffer.finishCurrentSegment();
/* 4047 */                 outPtr = 0;
/*      */               }
/* 4049 */               outBuf[(outPtr++)] = c;
/*      */             }
/*      */             
/* 4052 */             c = '\n';
/* 4053 */           } else if (this.mCfgNormalizeLFs) {
/* 4054 */             c = '\n';
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 4059 */           inputPtr = this.mInputPtr;
/* 4060 */           inputBuf = this.mInputBuffer;
/* 4061 */           inputLen = this.mInputLen;
/* 4062 */         } else if (c != '\t') {
/* 4063 */           throwInvalidSpace(c);
/*      */         }
/* 4065 */       } else if (c == '?') {
/* 4066 */         this.mInputPtr = inputPtr;
/*      */         
/*      */         for (;;)
/*      */         {
/* 4070 */           c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in processing instruction");
/*      */           
/* 4072 */           if (c == '>')
/*      */             break label361;
/* 4074 */           if (c != '?') break;
/* 4075 */           if (outPtr >= outBuf.length) {
/* 4076 */             outBuf = tb.finishCurrentSegment();
/* 4077 */             outPtr = 0;
/*      */           }
/* 4079 */           outBuf[(outPtr++)] = c;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4087 */         inputPtr = --this.mInputPtr;
/* 4088 */         inputBuf = this.mInputBuffer;
/* 4089 */         inputLen = this.mInputLen;
/* 4090 */         c = '?';
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4097 */       if (outPtr >= outBuf.length) {
/* 4098 */         outBuf = tb.finishCurrentSegment();
/* 4099 */         outPtr = 0;
/*      */       }
/*      */       
/* 4102 */       outBuf[(outPtr++)] = c;
/*      */     }
/*      */     
/*      */     label361:
/* 4106 */     tb.setCurrentLength(outPtr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readCoalescedText(int currType, boolean deferErrors)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*      */     boolean wasCData;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4125 */     if ((currType == 4) || (currType == 6)) {
/* 4126 */       readTextSecondary(Integer.MAX_VALUE, deferErrors);
/* 4127 */       wasCData = false; } else { boolean wasCData;
/* 4128 */       if (currType == 12)
/*      */       {
/*      */ 
/*      */ 
/* 4132 */         if (this.mTokenState <= 2) {
/* 4133 */           readCDataSecondary(Integer.MAX_VALUE);
/*      */         }
/* 4135 */         wasCData = true;
/*      */       } else {
/* 4137 */         throw new IllegalStateException("Internal error: unexpected token " + tokenTypeDesc(this.mCurrToken) + "; expected CHARACTERS, CDATA or SPACE.");
/*      */       }
/*      */     }
/*      */     boolean wasCData;
/* 4141 */     while ((!deferErrors) || (this.mPendingException == null)) {
/* 4142 */       if (this.mInputPtr >= this.mInputLen) {
/* 4143 */         this.mTextBuffer.ensureNotShared();
/* 4144 */         if (!loadMore()) {
/*      */           break;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 4150 */       char c = this.mInputBuffer[this.mInputPtr];
/* 4151 */       if (c == '<')
/*      */       {
/* 4153 */         if (this.mInputLen - this.mInputPtr < 3) {
/* 4154 */           this.mTextBuffer.ensureNotShared();
/* 4155 */           if (!ensureInput(3)) {
/*      */             break;
/*      */           }
/*      */         }
/* 4159 */         if ((this.mInputBuffer[(this.mInputPtr + 1)] != '!') || (this.mInputBuffer[(this.mInputPtr + 2)] != '[')) {
/*      */           break;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 4165 */         this.mInputPtr += 3;
/*      */         
/* 4167 */         checkCData();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 4172 */         readCDataSecondary(Integer.MAX_VALUE);
/* 4173 */         wasCData = true;
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 4178 */         if ((c == '&') && (!wasCData)) {
/*      */           break;
/*      */         }
/*      */         
/* 4182 */         readTextSecondary(Integer.MAX_VALUE, deferErrors);
/* 4183 */         wasCData = false;
/*      */       }
/*      */     }
/*      */     
/* 4187 */     this.mTokenState = 4;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final boolean readCDataPrimary(char c)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 4209 */     this.mWsStatus = (c <= ' ' ? 0 : 2);
/*      */     
/* 4211 */     int ptr = this.mInputPtr;
/* 4212 */     int inputLen = this.mInputLen;
/* 4213 */     char[] inputBuf = this.mInputBuffer;
/* 4214 */     int start = ptr - 1;
/*      */     
/*      */     for (;;)
/*      */     {
/* 4218 */       if (c < ' ') {
/* 4219 */         if (c == '\n') {
/* 4220 */           markLF(ptr);
/* 4221 */         } else if (c == '\r') {
/* 4222 */           if (ptr >= inputLen) {
/* 4223 */             ptr--;
/* 4224 */             break;
/*      */           }
/* 4226 */           if (this.mCfgNormalizeLFs) {
/* 4227 */             if (inputBuf[ptr] == '\n') {
/* 4228 */               ptr--;
/* 4229 */               break;
/*      */             }
/* 4231 */             inputBuf[(ptr - 1)] = '\n';
/*      */ 
/*      */           }
/* 4234 */           else if (inputBuf[ptr] == '\n') {
/* 4235 */             ptr++;
/*      */           }
/*      */           
/* 4238 */           markLF(ptr);
/* 4239 */         } else if (c != '\t') {
/* 4240 */           throwInvalidSpace(c);
/*      */         }
/* 4242 */       } else if (c == ']')
/*      */       {
/* 4244 */         if (ptr + 1 >= inputLen) {
/* 4245 */           ptr--;
/* 4246 */           break;
/*      */         }
/*      */         
/*      */ 
/* 4250 */         if (inputBuf[ptr] == ']') {
/* 4251 */           ptr++;
/*      */           do
/*      */           {
/* 4254 */             if (ptr >= inputLen)
/*      */             {
/*      */ 
/*      */ 
/* 4258 */               ptr -= 2;
/* 4259 */               break;
/*      */             }
/* 4261 */             c = inputBuf[(ptr++)];
/* 4262 */             if (c == '>') {
/* 4263 */               this.mInputPtr = ptr;
/* 4264 */               ptr -= start + 3;
/* 4265 */               this.mTextBuffer.resetWithShared(inputBuf, start, ptr);
/* 4266 */               this.mTokenState = 3;
/* 4267 */               return true;
/*      */             }
/* 4269 */           } while (c == ']');
/*      */           
/* 4271 */           ptr--;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4279 */       if (ptr >= inputLen) {
/*      */         break;
/*      */       }
/* 4282 */       c = inputBuf[(ptr++)];
/*      */     }
/*      */     
/* 4285 */     this.mInputPtr = ptr;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4293 */     int len = ptr - start;
/* 4294 */     this.mTextBuffer.resetWithShared(inputBuf, start, len);
/* 4295 */     if ((this.mCfgCoalesceText) || (this.mTextBuffer.size() < this.mShortestTextSegment))
/*      */     {
/* 4297 */       this.mTokenState = 1;
/*      */     } else {
/* 4299 */       this.mTokenState = 2;
/*      */     }
/* 4301 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean readCDataSecondary(int shortestSegment)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 4312 */     char[] inputBuf = this.mInputBuffer;
/* 4313 */     int inputLen = this.mInputLen;
/* 4314 */     int inputPtr = this.mInputPtr;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4319 */     char[] outBuf = this.mTextBuffer.getCurrentSegment();
/* 4320 */     int outPtr = this.mTextBuffer.getCurrentSegmentSize();
/*      */     for (;;)
/*      */     {
/* 4323 */       if (inputPtr >= inputLen) {
/* 4324 */         loadMore(" in CDATA section");
/* 4325 */         inputBuf = this.mInputBuffer;
/* 4326 */         inputPtr = this.mInputPtr;
/* 4327 */         inputLen = this.mInputLen;
/*      */       }
/* 4329 */       char c = inputBuf[(inputPtr++)];
/*      */       
/* 4331 */       if (c < ' ') {
/* 4332 */         if (c == '\n') {
/* 4333 */           markLF(inputPtr);
/* 4334 */         } else if (c == '\r') {
/* 4335 */           this.mInputPtr = inputPtr;
/* 4336 */           if (skipCRLF(c)) {
/* 4337 */             if (!this.mCfgNormalizeLFs)
/*      */             {
/* 4339 */               outBuf[(outPtr++)] = c;
/* 4340 */               if (outPtr >= outBuf.length) {
/* 4341 */                 outBuf = this.mTextBuffer.finishCurrentSegment();
/* 4342 */                 outPtr = 0;
/*      */               }
/*      */             }
/*      */             
/* 4346 */             c = '\n';
/* 4347 */           } else if (this.mCfgNormalizeLFs) {
/* 4348 */             c = '\n';
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 4353 */           inputPtr = this.mInputPtr;
/* 4354 */           inputBuf = this.mInputBuffer;
/* 4355 */           inputLen = this.mInputLen;
/* 4356 */         } else if (c != '\t') {
/* 4357 */           throwInvalidSpace(c);
/*      */         }
/* 4359 */       } else if (c == ']')
/*      */       {
/* 4361 */         this.mInputPtr = inputPtr;
/* 4362 */         if (checkCDataEnd(outBuf, outPtr)) {
/* 4363 */           return true;
/*      */         }
/* 4365 */         inputPtr = this.mInputPtr;
/* 4366 */         inputBuf = this.mInputBuffer;
/* 4367 */         inputLen = this.mInputLen;
/*      */         
/* 4369 */         outBuf = this.mTextBuffer.getCurrentSegment();
/* 4370 */         outPtr = this.mTextBuffer.getCurrentSegmentSize();
/* 4371 */         continue;
/*      */       }
/*      */       
/*      */ 
/* 4375 */       outBuf[(outPtr++)] = c;
/*      */       
/*      */ 
/* 4378 */       if (outPtr >= outBuf.length) {
/* 4379 */         TextBuffer tb = this.mTextBuffer;
/*      */         
/* 4381 */         if (!this.mCfgCoalesceText) {
/* 4382 */           tb.setCurrentLength(outBuf.length);
/* 4383 */           if (tb.size() >= this.mShortestTextSegment) {
/* 4384 */             this.mInputPtr = inputPtr;
/* 4385 */             return false;
/*      */           }
/*      */         }
/*      */         
/* 4389 */         outBuf = tb.finishCurrentSegment();
/* 4390 */         outPtr = 0;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean checkCDataEnd(char[] outBuf, int outPtr)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 4407 */     int bracketCount = 0;
/*      */     char c;
/*      */     do {
/* 4410 */       bracketCount++;
/* 4411 */       c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in CDATA section");
/*      */     }
/* 4413 */     while (c == ']');
/*      */     
/* 4415 */     boolean match = (bracketCount >= 2) && (c == '>');
/* 4416 */     if (match) {
/* 4417 */       bracketCount -= 2;
/*      */     }
/* 4419 */     while (bracketCount > 0) {
/* 4420 */       bracketCount--;
/* 4421 */       outBuf[(outPtr++)] = ']';
/* 4422 */       if (outPtr >= outBuf.length)
/*      */       {
/*      */ 
/*      */ 
/* 4426 */         outBuf = this.mTextBuffer.finishCurrentSegment();
/* 4427 */         outPtr = 0;
/*      */       }
/*      */     }
/* 4430 */     this.mTextBuffer.setCurrentLength(outPtr);
/*      */     
/* 4432 */     if (match) {
/* 4433 */       return true;
/*      */     }
/*      */     
/* 4436 */     this.mInputPtr -= 1;
/* 4437 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final boolean readTextPrimary(char c)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 4458 */     int ptr = this.mInputPtr;
/* 4459 */     int start = ptr - 1;
/*      */     
/*      */ 
/* 4462 */     if (c <= ' ') {
/* 4463 */       int len = this.mInputLen;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4473 */       if ((ptr < len) && (this.mCfgNormalizeLFs)) {
/* 4474 */         if (c == '\r') {
/* 4475 */           c = '\n';
/* 4476 */           if (this.mInputBuffer[ptr] == c)
/*      */           {
/*      */ 
/*      */ 
/* 4480 */             start++;
/*      */             
/* 4482 */             ptr++; if (ptr >= len) {
/*      */               break label122;
/*      */             }
/*      */           } else {
/* 4486 */             this.mInputBuffer[start] = c;
/*      */           }
/* 4488 */         } else { if (c != '\n')
/*      */             break label122;
/*      */         }
/* 4491 */         markLF(ptr);
/* 4492 */         if (this.mCheckIndentation > 0) {
/* 4493 */           ptr = readIndentation(c, ptr);
/* 4494 */           if (ptr < 0) {
/* 4495 */             return true;
/*      */           }
/*      */         }
/*      */         
/* 4499 */         c = this.mInputBuffer[(ptr++)];
/*      */       }
/*      */       
/*      */       label122:
/*      */       
/* 4504 */       this.mWsStatus = 0;
/*      */     } else {
/* 4506 */       this.mWsStatus = 2;
/*      */     }
/*      */     
/* 4509 */     char[] inputBuf = this.mInputBuffer;
/* 4510 */     int inputLen = this.mInputLen;
/*      */     
/*      */     for (;;)
/*      */     {
/* 4514 */       if (c < '?') {
/* 4515 */         if (c == '<') {
/* 4516 */           this.mInputPtr = (--ptr);
/* 4517 */           this.mTextBuffer.resetWithShared(inputBuf, start, ptr - start);
/* 4518 */           return true;
/*      */         }
/* 4520 */         if (c < ' ') {
/* 4521 */           if (c == '\n') {
/* 4522 */             markLF(ptr);
/* 4523 */           } else if (c == '\r') {
/* 4524 */             if (ptr >= inputLen) {
/* 4525 */               ptr--;
/* 4526 */               break;
/*      */             }
/* 4528 */             if (this.mCfgNormalizeLFs) {
/* 4529 */               if (inputBuf[ptr] == '\n') {
/* 4530 */                 ptr--;
/* 4531 */                 break;
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4539 */               inputBuf[(ptr - 1)] = '\n';
/*      */ 
/*      */             }
/* 4542 */             else if (inputBuf[ptr] == '\n') {
/* 4543 */               ptr++;
/*      */             }
/*      */             
/* 4546 */             markLF(ptr);
/* 4547 */           } else if (c != '\t')
/*      */           {
/* 4549 */             this.mInputPtr = ptr;
/* 4550 */             this.mTextBuffer.resetWithShared(inputBuf, start, ptr - start - 1);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 4555 */             boolean deferErrors = ptr - start > 1;
/* 4556 */             this.mPendingException = throwInvalidSpace(c, deferErrors);
/* 4557 */             return true;
/*      */           }
/* 4559 */         } else { if (c == '&')
/*      */           {
/* 4561 */             ptr--;
/* 4562 */             break; }
/* 4563 */           if (c == '>')
/*      */           {
/* 4565 */             if ((ptr - start >= 3) && 
/* 4566 */               (inputBuf[(ptr - 3)] == ']') && (inputBuf[(ptr - 2)] == ']'))
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/* 4571 */               this.mInputPtr = ptr;
/* 4572 */               this.mTextBuffer.resetWithShared(inputBuf, start, ptr - start - 1);
/* 4573 */               this.mPendingException = throwWfcException(ErrorConsts.ERR_BRACKET_IN_TEXT, true);
/* 4574 */               return true;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 4580 */       if (ptr >= inputLen) {
/*      */         break;
/*      */       }
/* 4583 */       c = inputBuf[(ptr++)];
/*      */     }
/*      */     
/* 4586 */     this.mInputPtr = ptr;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4594 */     this.mTextBuffer.resetWithShared(inputBuf, start, ptr - start);
/* 4595 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final boolean readTextSecondary(int shortestSegment, boolean deferErrors)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 4614 */     char[] outBuf = this.mTextBuffer.getCurrentSegment();
/* 4615 */     int outPtr = this.mTextBuffer.getCurrentSegmentSize();
/* 4616 */     int inputPtr = this.mInputPtr;
/* 4617 */     char[] inputBuffer = this.mInputBuffer;
/* 4618 */     int inputLen = this.mInputLen;
/*      */     for (;;)
/*      */     {
/* 4621 */       if (inputPtr >= inputLen)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4627 */         this.mInputPtr = inputPtr;
/* 4628 */         if (!loadMore()) {
/*      */           break;
/*      */         }
/* 4631 */         inputPtr = this.mInputPtr;
/* 4632 */         inputBuffer = this.mInputBuffer;
/* 4633 */         inputLen = this.mInputLen;
/*      */       }
/* 4635 */       char c = inputBuffer[(inputPtr++)];
/*      */       
/*      */ 
/* 4638 */       if (c < '?') {
/* 4639 */         if (c < ' ') {
/* 4640 */           if (c == '\n') {
/* 4641 */             markLF(inputPtr);
/* 4642 */           } else if (c == '\r') {
/* 4643 */             this.mInputPtr = inputPtr;
/* 4644 */             if (skipCRLF(c)) {
/* 4645 */               if (!this.mCfgNormalizeLFs)
/*      */               {
/* 4647 */                 outBuf[(outPtr++)] = c;
/* 4648 */                 if (outPtr >= outBuf.length) {
/* 4649 */                   outBuf = this.mTextBuffer.finishCurrentSegment();
/* 4650 */                   outPtr = 0;
/*      */                 }
/*      */               }
/*      */               
/* 4654 */               c = '\n';
/* 4655 */             } else if (this.mCfgNormalizeLFs) {
/* 4656 */               c = '\n';
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4663 */             inputLen = this.mInputLen;
/* 4664 */             inputPtr = this.mInputPtr;
/* 4665 */           } else if (c != '\t') {
/* 4666 */             this.mTextBuffer.setCurrentLength(outPtr);
/* 4667 */             this.mInputPtr = inputPtr;
/* 4668 */             this.mPendingException = throwInvalidSpace(c, deferErrors);
/* 4669 */             break;
/*      */           }
/* 4671 */         } else { if (c == '<') {
/* 4672 */             this.mInputPtr = (inputPtr - 1);
/* 4673 */             break; }
/* 4674 */           if (c == '&') {
/* 4675 */             this.mInputPtr = inputPtr;
/* 4676 */             if (this.mCfgReplaceEntities) {
/* 4677 */               if ((inputLen - inputPtr < 3) || ((c = resolveSimpleEntity(true)) == 0))
/*      */               {
/*      */ 
/*      */ 
/* 4681 */                 c = fullyResolveEntity(true);
/* 4682 */                 if (c == 0)
/*      */                 {
/* 4684 */                   inputBuffer = this.mInputBuffer;
/* 4685 */                   inputLen = this.mInputLen;
/* 4686 */                   inputPtr = this.mInputPtr;
/*      */                 }
/*      */                 
/*      */               }
/*      */               
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/* 4695 */               c = resolveCharOnlyEntity(true);
/* 4696 */               if (c == 0)
/*      */               {
/*      */ 
/*      */ 
/* 4700 */                 this.mInputPtr -= 1;
/* 4701 */                 break;
/*      */               }
/*      */             }
/*      */             
/* 4705 */             inputPtr = this.mInputPtr;
/*      */             
/* 4707 */             inputLen = this.mInputLen;
/* 4708 */           } else if (c == '>')
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4716 */             if (inputPtr > 2)
/*      */             {
/* 4718 */               if ((inputBuffer[(inputPtr - 3)] == ']') && (inputBuffer[(inputPtr - 2)] == ']'))
/*      */               {
/* 4720 */                 this.mInputPtr = inputPtr;
/*      */                 
/*      */ 
/*      */ 
/*      */ 
/* 4725 */                 this.mTextBuffer.setCurrentLength(outPtr);
/* 4726 */                 this.mPendingException = throwWfcException(ErrorConsts.ERR_BRACKET_IN_TEXT, deferErrors);
/* 4727 */                 break;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4739 */       outBuf[(outPtr++)] = c;
/*      */       
/*      */ 
/* 4742 */       if (outPtr >= outBuf.length) {
/* 4743 */         TextBuffer tb = this.mTextBuffer;
/*      */         
/* 4745 */         tb.setCurrentLength(outBuf.length);
/* 4746 */         if (tb.size() >= shortestSegment) {
/* 4747 */           this.mInputPtr = inputPtr;
/* 4748 */           return false;
/*      */         }
/*      */         
/* 4751 */         outBuf = tb.finishCurrentSegment();
/* 4752 */         outPtr = 0;
/*      */       }
/*      */     }
/*      */     
/* 4756 */     this.mTextBuffer.setCurrentLength(outPtr);
/* 4757 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int readIndentation(char c, int ptr)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 4787 */     int inputLen = this.mInputLen;
/* 4788 */     char[] inputBuf = this.mInputBuffer;
/* 4789 */     int start = ptr - 1;
/* 4790 */     char lf = c;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4795 */     c = inputBuf[(ptr++)];
/* 4796 */     if ((c == ' ') || (c == '\t'))
/*      */     {
/* 4798 */       int lastIndCharPos = c == ' ' ? 32 : 8;
/* 4799 */       lastIndCharPos += ptr;
/* 4800 */       if (lastIndCharPos > inputLen) {
/* 4801 */         lastIndCharPos = inputLen;
/*      */       }
/*      */       
/*      */       for (;;)
/*      */       {
/* 4806 */         if (ptr >= lastIndCharPos) {
/* 4807 */           ptr--;
/*      */           break label196;
/*      */         }
/* 4810 */         char d = inputBuf[(ptr++)];
/* 4811 */         if (d != c) {
/* 4812 */           if (d == '<') {
/*      */             break;
/*      */           }
/* 4815 */           ptr--;
/*      */           break label196;
/*      */         }
/*      */       }
/*      */     }
/* 4820 */     else if (c != '<') {
/* 4821 */       ptr--;
/*      */       
/*      */       break label196;
/*      */     }
/*      */     
/* 4826 */     if ((ptr < inputLen) && (inputBuf[ptr] != '!'))
/*      */     {
/* 4828 */       this.mInputPtr = (--ptr);
/* 4829 */       this.mTextBuffer.resetWithIndentation(ptr - start - 1, c);
/*      */       
/* 4831 */       if (this.mCheckIndentation < 40) {
/* 4832 */         this.mCheckIndentation += 16;
/*      */       }
/* 4834 */       this.mWsStatus = 1;
/* 4835 */       return -1;
/*      */     }
/*      */     
/* 4838 */     ptr--;
/*      */     
/*      */ 
/*      */ 
/*      */     label196:
/*      */     
/*      */ 
/* 4845 */     this.mCheckIndentation -= 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4851 */     if (lf == '\r') {
/* 4852 */       inputBuf[start] = '\n';
/*      */     }
/* 4854 */     return ptr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final boolean readSpacePrimary(char c, boolean prologWS)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 4875 */     int ptr = this.mInputPtr;
/* 4876 */     char[] inputBuf = this.mInputBuffer;
/* 4877 */     int inputLen = this.mInputLen;
/* 4878 */     int start = ptr - 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     for (;;)
/*      */     {
/* 4889 */       if (c > ' ') {
/* 4890 */         this.mInputPtr = (--ptr);
/* 4891 */         this.mTextBuffer.resetWithShared(this.mInputBuffer, start, ptr - start);
/* 4892 */         return true;
/*      */       }
/*      */       
/* 4895 */       if (c == '\n') {
/* 4896 */         markLF(ptr);
/* 4897 */       } else if (c == '\r') {
/* 4898 */         if (ptr >= this.mInputLen) {
/* 4899 */           ptr--;
/* 4900 */           break;
/*      */         }
/* 4902 */         if (this.mCfgNormalizeLFs) {
/* 4903 */           if (inputBuf[ptr] == '\n') {
/* 4904 */             ptr--;
/* 4905 */             break;
/*      */           }
/* 4907 */           inputBuf[(ptr - 1)] = '\n';
/*      */ 
/*      */         }
/* 4910 */         else if (inputBuf[ptr] == '\n') {
/* 4911 */           ptr++;
/*      */         }
/*      */         
/* 4914 */         markLF(ptr);
/* 4915 */       } else if ((c != ' ') && (c != '\t')) {
/* 4916 */         throwInvalidSpace(c);
/*      */       }
/* 4918 */       if (ptr >= inputLen) {
/*      */         break;
/*      */       }
/* 4921 */       c = inputBuf[(ptr++)];
/*      */     }
/*      */     
/* 4924 */     this.mInputPtr = ptr;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4929 */     this.mTextBuffer.resetWithShared(inputBuf, start, ptr - start);
/* 4930 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readSpaceSecondary(boolean prologWS)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 4947 */     char[] outBuf = this.mTextBuffer.getCurrentSegment();
/* 4948 */     int outPtr = this.mTextBuffer.getCurrentSegmentSize();
/*      */     
/*      */ 
/* 4951 */     while ((this.mInputPtr < this.mInputLen) || 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4956 */       (loadMore()))
/*      */     {
/*      */ 
/*      */ 
/* 4960 */       char c = this.mInputBuffer[this.mInputPtr];
/* 4961 */       if (c > ' ') {
/*      */         break;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4972 */       this.mInputPtr += 1;
/* 4973 */       if (c == '\n') {
/* 4974 */         markLF();
/* 4975 */       } else if (c == '\r') {
/* 4976 */         if (skipCRLF(c)) {
/* 4977 */           if (!this.mCfgNormalizeLFs)
/*      */           {
/* 4979 */             outBuf[(outPtr++)] = c;
/* 4980 */             if (outPtr >= outBuf.length) {
/* 4981 */               outBuf = this.mTextBuffer.finishCurrentSegment();
/* 4982 */               outPtr = 0;
/*      */             }
/*      */           }
/* 4985 */           c = '\n';
/* 4986 */         } else if (this.mCfgNormalizeLFs) {
/* 4987 */           c = '\n';
/*      */         }
/* 4989 */       } else if ((c != ' ') && (c != '\t')) {
/* 4990 */         throwInvalidSpace(c);
/*      */       }
/*      */       
/*      */ 
/* 4994 */       outBuf[(outPtr++)] = c;
/*      */       
/*      */ 
/* 4997 */       if (outPtr >= outBuf.length) {
/* 4998 */         outBuf = this.mTextBuffer.finishCurrentSegment();
/* 4999 */         outPtr = 0;
/*      */       }
/*      */     }
/* 5002 */     this.mTextBuffer.setCurrentLength(outPtr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int readAndWriteText(Writer w)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 5016 */     this.mTokenState = 3;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5024 */     int start = this.mInputPtr;
/* 5025 */     int count = 0;
/*      */     
/*      */     for (;;)
/*      */     {
/*      */       char c;
/*      */       
/* 5031 */       if (this.mInputPtr >= this.mInputLen) {
/* 5032 */         int len = this.mInputPtr - start;
/* 5033 */         if (len > 0) {
/* 5034 */           w.write(this.mInputBuffer, start, len);
/* 5035 */           count += len;
/*      */         }
/* 5037 */         char c = getNextChar(" in document text content");
/* 5038 */         start = this.mInputPtr - 1;
/*      */       } else {
/* 5040 */         c = this.mInputBuffer[(this.mInputPtr++)];
/*      */       }
/*      */       
/* 5043 */       if (c < '?') {
/* 5044 */         if (c < ' ') {
/* 5045 */           if (c == '\n') {
/* 5046 */             markLF();
/* 5047 */           } else if (c == '\r') {
/*      */             char d;
/* 5049 */             if (this.mInputPtr >= this.mInputLen)
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/* 5054 */               int len = this.mInputPtr - start;
/* 5055 */               if (len > 0) {
/* 5056 */                 w.write(this.mInputBuffer, start, len);
/* 5057 */                 count += len;
/*      */               }
/* 5059 */               char d = getNextChar(" in document text content");
/* 5060 */               start = this.mInputPtr;
/*      */             } else {
/* 5062 */               d = this.mInputBuffer[(this.mInputPtr++)];
/*      */             }
/* 5064 */             if (d == '\n') {
/* 5065 */               if (this.mCfgNormalizeLFs)
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5071 */                 int len = this.mInputPtr - 2 - start;
/* 5072 */                 if (len > 0) {
/* 5073 */                   w.write(this.mInputBuffer, start, len);
/* 5074 */                   count += len;
/*      */                 }
/* 5076 */                 start = this.mInputPtr - 1;
/*      */               }
/*      */             }
/*      */             else
/*      */             {
/* 5081 */               this.mInputPtr -= 1;
/* 5082 */               if (this.mCfgNormalizeLFs) {
/* 5083 */                 this.mInputBuffer[(this.mInputPtr - 1)] = '\n';
/*      */               }
/*      */             }
/* 5086 */             markLF();
/* 5087 */           } else if (c != '\t') {
/* 5088 */             throwInvalidSpace(c);
/*      */           }
/* 5090 */         } else { if (c == '<')
/*      */             break;
/* 5092 */           if (c == '&')
/*      */           {
/*      */ 
/*      */ 
/* 5096 */             int len = this.mInputPtr - 1 - start;
/* 5097 */             if (len > 0) {
/* 5098 */               w.write(this.mInputBuffer, start, len);
/* 5099 */               count += len;
/*      */             }
/* 5101 */             if (this.mCfgReplaceEntities) {
/* 5102 */               if ((this.mInputLen - this.mInputPtr < 3) || ((c = resolveSimpleEntity(true)) == 0))
/*      */               {
/* 5104 */                 c = fullyResolveEntity(true);
/*      */               }
/*      */             } else {
/* 5107 */               c = resolveCharOnlyEntity(true);
/* 5108 */               if (c == 0)
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5114 */                 start = this.mInputPtr;
/* 5115 */                 break;
/*      */               }
/*      */             }
/* 5118 */             if (c != 0) {
/* 5119 */               w.write(c);
/* 5120 */               count++;
/*      */             }
/* 5122 */             start = this.mInputPtr;
/* 5123 */           } else if (c == '>')
/*      */           {
/*      */ 
/*      */ 
/* 5127 */             if ((this.mInputPtr >= 2) && 
/* 5128 */               (this.mInputBuffer[(this.mInputPtr - 2)] == ']') && (this.mInputBuffer[(this.mInputPtr - 1)] == ']'))
/*      */             {
/*      */ 
/* 5131 */               int len = this.mInputPtr - start;
/* 5132 */               if (len > 0) {
/* 5133 */                 w.write(this.mInputBuffer, start, len);
/*      */               }
/* 5135 */               throwParseError(ErrorConsts.ERR_BRACKET_IN_TEXT);
/*      */             }
/*      */             
/*      */ 
/*      */           }
/* 5140 */           else if (c == 0) {
/* 5141 */             throwNullChar();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 5149 */     this.mInputPtr -= 1;
/*      */     
/*      */ 
/* 5152 */     int len = this.mInputPtr - start;
/* 5153 */     if (len > 0) {
/* 5154 */       w.write(this.mInputBuffer, start, len);
/* 5155 */       count += len;
/*      */     }
/* 5157 */     return count;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int readAndWriteCData(Writer w)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 5173 */     this.mTokenState = 3;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5180 */     char c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextChar(" in CDATA section");
/*      */     
/* 5182 */     int count = 0;
/*      */     
/*      */     for (;;)
/*      */     {
/* 5186 */       int start = this.mInputPtr - 1;
/*      */       
/*      */       for (;;)
/*      */       {
/* 5190 */         if (c > '\r') {
/* 5191 */           if (c == ']') {
/*      */             break;
/*      */           }
/*      */         }
/* 5195 */         else if (c < ' ') {
/* 5196 */           if (c == '\n') {
/* 5197 */             markLF();
/* 5198 */           } else if (c == '\r') {
/*      */             char d;
/* 5200 */             if (this.mInputPtr >= this.mInputLen)
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/* 5205 */               int len = this.mInputPtr - start;
/* 5206 */               if (len > 0) {
/* 5207 */                 w.write(this.mInputBuffer, start, len);
/* 5208 */                 count += len;
/*      */               }
/* 5210 */               char d = getNextChar(" in CDATA section");
/* 5211 */               start = this.mInputPtr;
/*      */             } else {
/* 5213 */               d = this.mInputBuffer[(this.mInputPtr++)];
/*      */             }
/* 5215 */             if (d == '\n') {
/* 5216 */               if (this.mCfgNormalizeLFs)
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5222 */                 int len = this.mInputPtr - 2 - start;
/* 5223 */                 if (len > 0) {
/* 5224 */                   w.write(this.mInputBuffer, start, len);
/* 5225 */                   count += len;
/*      */                 }
/* 5227 */                 start = this.mInputPtr - 1;
/*      */               }
/*      */             }
/*      */             else
/*      */             {
/* 5232 */               this.mInputPtr -= 1;
/* 5233 */               if (this.mCfgNormalizeLFs) {
/* 5234 */                 this.mInputBuffer[(this.mInputPtr - 1)] = '\n';
/*      */               }
/*      */             }
/* 5237 */             markLF();
/* 5238 */           } else if (c != '\t') {
/* 5239 */             throwInvalidSpace(c);
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 5244 */         if (this.mInputPtr >= this.mInputLen) {
/* 5245 */           int len = this.mInputPtr - start;
/* 5246 */           if (len > 0) {
/* 5247 */             w.write(this.mInputBuffer, start, len);
/* 5248 */             count += len;
/*      */           }
/* 5250 */           start = 0;
/* 5251 */           c = getNextChar(" in CDATA section");
/*      */         } else {
/* 5253 */           c = this.mInputBuffer[(this.mInputPtr++)];
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5262 */       int len = this.mInputPtr - start - 1;
/* 5263 */       if (len > 0) {
/* 5264 */         w.write(this.mInputBuffer, start, len);
/* 5265 */         count += len;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5273 */       int bracketCount = 0;
/*      */       do {
/* 5275 */         bracketCount++;
/* 5276 */         c = this.mInputPtr < this.mInputLen ? this.mInputBuffer[(this.mInputPtr++)] : getNextCharFromCurrent(" in CDATA section");
/*      */       }
/* 5278 */       while (c == ']');
/*      */       
/* 5280 */       boolean match = (bracketCount >= 2) && (c == '>');
/* 5281 */       if (match) {
/* 5282 */         bracketCount -= 2;
/*      */       }
/* 5284 */       while (bracketCount > 0) {
/* 5285 */         bracketCount--;
/* 5286 */         w.write(93);
/* 5287 */         count++;
/*      */       }
/* 5289 */       if (match) {
/*      */         break;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5297 */     return count;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int readAndWriteCoalesced(Writer w, boolean wasCData)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 5306 */     this.mTokenState = 4;
/* 5307 */     int count = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5314 */     while ((this.mInputPtr < this.mInputLen) || 
/* 5315 */       (loadMore()))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5323 */       char c = this.mInputBuffer[this.mInputPtr];
/* 5324 */       if (c == '<')
/*      */       {
/* 5326 */         if ((this.mInputLen - this.mInputPtr < 3) && 
/* 5327 */           (!ensureInput(3))) {
/*      */           break;
/*      */         }
/*      */         
/* 5331 */         if ((this.mInputBuffer[(this.mInputPtr + 1)] != '!') || (this.mInputBuffer[(this.mInputPtr + 2)] != '[')) {
/*      */           break;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 5337 */         this.mInputPtr += 3;
/*      */         
/* 5339 */         checkCData();
/*      */         
/* 5341 */         count += readAndWriteCData(w);
/* 5342 */         wasCData = true;
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 5348 */         if ((c == '&') && (!wasCData)) {
/*      */           break;
/*      */         }
/* 5351 */         count += readAndWriteText(w);
/* 5352 */         wasCData = false;
/*      */       }
/*      */     }
/*      */     
/* 5356 */     return count;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final boolean skipWS(char c)
/*      */     throws IOException, XMLStreamException
/*      */   {
/* 5374 */     if (c > ' ') {
/* 5375 */       return false;
/*      */     }
/*      */     for (;;)
/*      */     {
/* 5379 */       if ((c == '\n') || (c == '\r')) {
/* 5380 */         skipCRLF(c);
/* 5381 */       } else if ((c != ' ') && (c != '\t')) {
/* 5382 */         throwInvalidSpace(c);
/*      */       }
/* 5384 */       if (this.mInputPtr >= this.mInputLen)
/*      */       {
/* 5386 */         if (!loadMoreFromCurrent()) {
/* 5387 */           return true;
/*      */         }
/*      */       }
/* 5390 */       c = this.mInputBuffer[this.mInputPtr];
/* 5391 */       if (c > ' ') {
/* 5392 */         return true;
/*      */       }
/* 5394 */       this.mInputPtr += 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected EntityDecl findEntity(String id, Object arg)
/*      */     throws XMLStreamException
/*      */   {
/* 5408 */     EntityDecl ed = null;
/*      */     
/* 5410 */     if (this.mCustomEntities != null) {
/* 5411 */       ed = (EntityDecl)this.mCustomEntities.get(id);
/*      */     }
/* 5413 */     if ((ed == null) && (this.mGeneralEntities != null)) {
/* 5414 */       ed = (EntityDecl)this.mGeneralEntities.get(id);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 5419 */     if ((this.mDocStandalone == 1) && 
/* 5420 */       (ed != null) && (ed.wasDeclaredExternally())) {
/* 5421 */       throwParseError(ErrorConsts.ERR_WF_ENTITY_EXT_DECLARED, ed.getName());
/*      */     }
/*      */     
/*      */ 
/* 5425 */     return ed;
/*      */   }
/*      */   
/*      */   protected void handleUndeclaredEntity(String id)
/*      */     throws XMLStreamException
/*      */   {
/* 5431 */     throwParseError(this.mDocStandalone == 1 ? ErrorConsts.ERR_WF_GE_UNDECLARED_SA : ErrorConsts.ERR_WF_GE_UNDECLARED, id);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void handleIncompleteEntityProblem(WstxInputSource closing)
/*      */     throws XMLStreamException
/*      */   {
/* 5440 */     String top = this.mElementStack.isEmpty() ? "[ROOT]" : this.mElementStack.getTopElementDesc();
/* 5441 */     throwParseError("Unexpected end of entity expansion for entity &" + closing.getEntityId() + "; was expecting a close tag for element <" + top + ">");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected char handleExpandedSurrogate(char first, char second)
/*      */   {
/* 5452 */     this.mInputBuffer[(--this.mInputPtr)] = second;
/* 5453 */     return first;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void handleGreedyEntityProblem(WstxInputSource input)
/*      */     throws XMLStreamException
/*      */   {
/* 5471 */     String top = this.mElementStack.isEmpty() ? "[ROOT]" : this.mElementStack.getTopElementDesc();
/* 5472 */     throwParseError("Improper GE/element nesting: entity &" + input.getEntityId() + " contains closing tag for <" + top + ">");
/*      */   }
/*      */   
/*      */ 
/*      */   private void throwNotTextual(int type)
/*      */   {
/* 5478 */     throw new IllegalStateException("Not a textual event (" + tokenTypeDesc(this.mCurrToken) + ")");
/*      */   }
/*      */   
/*      */ 
/*      */   private void throwNotTextXxx(int type)
/*      */   {
/* 5484 */     throw new IllegalStateException("getTextXxx() methods can not be called on " + tokenTypeDesc(this.mCurrToken));
/*      */   }
/*      */   
/*      */ 
/*      */   private void throwNotWS(char c)
/*      */     throws WstxException
/*      */   {
/* 5491 */     throwUnexpectedChar(c, "; element <" + this.mElementStack.getTopElementDesc() + "> does not allow mixed content");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void reportInvalidContent(int evtType)
/*      */     throws XMLStreamException
/*      */   {
/* 5507 */     throwParseError("Internal error: sub-class should override method");
/*      */   }
/*      */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sr\BasicStreamReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */