/*    */ package com.ctc.wstx.dtd;
/*    */ 
/*    */ import com.ctc.wstx.sr.InputProblemReporter;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import org.codehaus.stax2.validation.XMLValidationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DTDCdataAttr
/*    */   extends DTDAttribute
/*    */ {
/*    */   public DTDCdataAttr(NameKey name, DefaultAttrValue defValue, int specIndex, boolean nsAware, boolean xml11)
/*    */   {
/* 24 */     super(name, defValue, specIndex, nsAware, xml11);
/*    */   }
/*    */   
/*    */   public DTDAttribute cloneWith(int specIndex)
/*    */   {
/* 29 */     return new DTDCdataAttr(this.mName, this.mDefValue, specIndex, this.mCfgNsAware, this.mCfgXml11);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String validate(DTDValidatorBase v, char[] cbuf, int start, int end, boolean normalize)
/*    */     throws XMLValidationException
/*    */   {
/* 43 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void validateDefault(InputProblemReporter rep, boolean normalize)
/*    */     throws XMLStreamException
/*    */   {}
/*    */   
/*    */ 
/*    */ 
/*    */   public String normalize(DTDValidatorBase v, char[] cbuf, int start, int end)
/*    */   {
/* 57 */     return null;
/*    */   }
/*    */   
/*    */   public void normalizeDefault() {}
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\DTDCdataAttr.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */