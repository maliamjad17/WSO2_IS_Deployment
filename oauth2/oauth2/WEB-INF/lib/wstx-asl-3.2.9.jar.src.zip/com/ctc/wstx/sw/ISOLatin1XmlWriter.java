/*     */ package com.ctc.wstx.sw;
/*     */ 
/*     */ import com.ctc.wstx.api.WriterConfig;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ISOLatin1XmlWriter
/*     */   extends EncodingXmlWriter
/*     */ {
/*     */   public ISOLatin1XmlWriter(OutputStream out, WriterConfig cfg, boolean autoclose)
/*     */     throws IOException
/*     */   {
/*  39 */     super(out, cfg, "ISO-8859-1", autoclose);
/*     */   }
/*     */   
/*     */   public void writeRaw(char[] cbuf, int offset, int len)
/*     */     throws IOException
/*     */   {
/*  45 */     if (this.mSurrogate != 0) {
/*  46 */       throwUnpairedSurrogate();
/*     */     }
/*     */     
/*  49 */     int ptr = this.mOutputPtr;
/*  50 */     while (len > 0) {
/*  51 */       int max = this.mOutputBuffer.length - ptr;
/*  52 */       if (max < 1) {
/*  53 */         this.mOutputPtr = ptr;
/*  54 */         flushBuffer();
/*  55 */         ptr = 0;
/*  56 */         max = this.mOutputBuffer.length;
/*     */       }
/*     */       
/*  59 */       if (max > len) {
/*  60 */         max = len;
/*     */       }
/*  62 */       if (this.mCheckContent) {
/*  63 */         for (int inEnd = offset + max; offset < inEnd; offset++) {
/*  64 */           int c = cbuf[offset];
/*  65 */           if (c < 32) {
/*  66 */             if (c != 10)
/*     */             {
/*  68 */               if (c != 13)
/*     */               {
/*  70 */                 if (c != 9)
/*  71 */                   throwInvalidChar(c); }
/*     */             }
/*  73 */           } else if (c > 126) {
/*  74 */             if (c > 255) {
/*  75 */               this.mOutputPtr = ptr;
/*  76 */               throwInvalidLatinChar(c);
/*  77 */             } else if ((this.mXml11) && 
/*  78 */               (c < 159) && (c != 133)) {
/*  79 */               this.mOutputPtr = ptr;
/*  80 */               throwInvalidChar(c);
/*     */             }
/*     */           }
/*     */           
/*  84 */           this.mOutputBuffer[(ptr++)] = ((byte)c);
/*     */         }
/*     */       } else {
/*  87 */         for (int inEnd = offset + max; offset < inEnd; offset++) {
/*  88 */           this.mOutputBuffer[(ptr++)] = ((byte)cbuf[offset]);
/*     */         }
/*     */       }
/*  91 */       len -= max;
/*     */     }
/*  93 */     this.mOutputPtr = ptr;
/*     */   }
/*     */   
/*     */   public void writeRaw(String str, int offset, int len)
/*     */     throws IOException
/*     */   {
/*  99 */     if (this.mSurrogate != 0) {
/* 100 */       throwUnpairedSurrogate();
/*     */     }
/* 102 */     int ptr = this.mOutputPtr;
/* 103 */     while (len > 0) {
/* 104 */       int max = this.mOutputBuffer.length - ptr;
/* 105 */       if (max < 1) {
/* 106 */         this.mOutputPtr = ptr;
/* 107 */         flushBuffer();
/* 108 */         ptr = 0;
/* 109 */         max = this.mOutputBuffer.length;
/*     */       }
/*     */       
/* 112 */       if (max > len) {
/* 113 */         max = len;
/*     */       }
/* 115 */       if (this.mCheckContent) {
/* 116 */         for (int inEnd = offset + max; offset < inEnd; offset++) {
/* 117 */           int c = str.charAt(offset);
/* 118 */           if (c < 32) {
/* 119 */             if (c != 10)
/*     */             {
/* 121 */               if (c != 13)
/*     */               {
/* 123 */                 if (c != 9)
/* 124 */                   throwInvalidChar(c); }
/*     */             }
/* 126 */           } else if (c > 126) {
/* 127 */             if (c > 255) {
/* 128 */               this.mOutputPtr = ptr;
/* 129 */               throwInvalidLatinChar(c);
/* 130 */             } else if ((this.mXml11) && 
/* 131 */               (c < 159) && (c != 133)) {
/* 132 */               this.mOutputPtr = ptr;
/* 133 */               throwInvalidChar(c);
/*     */             }
/*     */           }
/*     */           
/* 137 */           this.mOutputBuffer[(ptr++)] = ((byte)c);
/*     */         }
/*     */       } else {
/* 140 */         for (int inEnd = offset + max; offset < inEnd; offset++) {
/* 141 */           this.mOutputBuffer[(ptr++)] = ((byte)str.charAt(offset));
/*     */         }
/*     */       }
/* 144 */       len -= max;
/*     */     }
/* 146 */     this.mOutputPtr = ptr;
/*     */   }
/*     */   
/*     */   protected void writeAttrValue(String data)
/*     */     throws IOException
/*     */   {
/* 152 */     int offset = 0;
/* 153 */     int len = data.length();
/* 154 */     int ptr = this.mOutputPtr;
/*     */     
/*     */ 
/* 157 */     while (len > 0) {
/* 158 */       int max = this.mOutputBuffer.length - ptr;
/* 159 */       if (max < 1) {
/* 160 */         this.mOutputPtr = ptr;
/* 161 */         flushBuffer();
/* 162 */         ptr = 0;
/* 163 */         max = this.mOutputBuffer.length;
/*     */       }
/*     */       
/* 166 */       if (this.mSurrogate != 0) {
/* 167 */         int sec = data.charAt(offset++);
/* 168 */         sec = calcSurrogate(sec);
/* 169 */         this.mOutputPtr = ptr;
/* 170 */         ptr = writeAsEntity(sec);
/* 171 */         len--;
/*     */       }
/*     */       else
/*     */       {
/* 175 */         if (max > len) {
/* 176 */           max = len;
/*     */         }
/*     */         
/* 179 */         int inEnd = offset + max; for (;;) { if (offset < inEnd) {
/* 180 */             int c = data.charAt(offset++);
/* 181 */             if (c < 32)
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/* 186 */               if ((this.mCheckContent) && 
/* 187 */                 (c != 10) && (c != 13) && (c != 9) && ((!this.mXml11) || (c == 0)))
/*     */               {
/* 189 */                 throwInvalidChar(c);
/*     */               }
/*     */               
/*     */             }
/* 193 */             else if (c < 127) {
/* 194 */               if ((c != 60) && (c != 38) && (c != 34)) {
/* 195 */                 this.mOutputBuffer[(ptr++)] = ((byte)c);
/*     */               }
/*     */             }
/*     */             else {
/* 199 */               if ((c > 159) && (c <= 255)) {
/* 200 */                 this.mOutputBuffer[(ptr++)] = ((byte)c);
/* 201 */                 continue;
/*     */               }
/*     */               
/* 204 */               if ((c >= 55296) && (c <= 57343)) {
/* 205 */                 this.mSurrogate = c;
/*     */                 
/* 207 */                 if (offset == inEnd) {
/*     */                   break label328;
/*     */                 }
/* 210 */                 c = calcSurrogate(data.charAt(offset++));
/*     */               }
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/* 217 */             this.mOutputPtr = ptr;
/* 218 */             ptr = writeAsEntity(c);
/* 219 */             len = data.length() - offset;
/* 220 */             break; } }
/*     */         label328:
/* 222 */         len -= max;
/*     */       } }
/* 224 */     this.mOutputPtr = ptr;
/*     */   }
/*     */   
/*     */   protected void writeAttrValue(char[] data, int offset, int len)
/*     */     throws IOException
/*     */   {
/* 230 */     int ptr = this.mOutputPtr;
/*     */     
/*     */ 
/* 233 */     while (len > 0) {
/* 234 */       int max = this.mOutputBuffer.length - ptr;
/* 235 */       if (max < 1) {
/* 236 */         this.mOutputPtr = ptr;
/* 237 */         flushBuffer();
/* 238 */         ptr = 0;
/* 239 */         max = this.mOutputBuffer.length;
/*     */       }
/*     */       
/* 242 */       if (this.mSurrogate != 0) {
/* 243 */         int sec = data[(offset++)];
/* 244 */         sec = calcSurrogate(sec);
/* 245 */         this.mOutputPtr = ptr;
/* 246 */         ptr = writeAsEntity(sec);
/* 247 */         len--;
/*     */       }
/*     */       else
/*     */       {
/* 251 */         if (max > len) {
/* 252 */           max = len;
/*     */         }
/*     */         
/* 255 */         for (int inEnd = offset + max; offset < inEnd;) {
/* 256 */           int c = data[(offset++)];
/* 257 */           if (c < 32)
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/* 262 */             if ((this.mCheckContent) && 
/* 263 */               (c != 10) && (c != 13) && (c != 9) && ((!this.mXml11) || (c == 0)))
/*     */             {
/* 265 */               throwInvalidChar(c);
/*     */             }
/*     */             
/*     */           }
/* 269 */           else if (c < 127) {
/* 270 */             if ((c != 60) && (c != 38) && (c != 34)) {
/* 271 */               this.mOutputBuffer[(ptr++)] = ((byte)c);
/*     */             }
/*     */           }
/*     */           else {
/* 275 */             if ((c > 159) && (c <= 255)) {
/* 276 */               this.mOutputBuffer[(ptr++)] = ((byte)c);
/* 277 */               continue;
/*     */             }
/*     */             
/* 280 */             if ((c >= 55296) && (c <= 57343)) {
/* 281 */               this.mSurrogate = c;
/*     */               
/* 283 */               if (offset == inEnd) {
/*     */                 break;
/*     */               }
/* 286 */               c = calcSurrogate(data[(offset++)]);
/*     */             }
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 293 */           this.mOutputPtr = ptr;
/* 294 */           ptr = writeAsEntity(c);
/* 295 */           max -= inEnd - offset;
/*     */         }
/*     */         
/* 298 */         len -= max;
/*     */       } }
/* 300 */     this.mOutputPtr = ptr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected int writeCDataContent(String data)
/*     */     throws IOException
/*     */   {
/* 308 */     int offset = 0;
/* 309 */     int len = data.length();
/* 310 */     if (!this.mCheckContent) {
/* 311 */       writeRaw(data, offset, len);
/* 312 */       return -1;
/*     */     }
/* 314 */     int ptr = this.mOutputPtr;
/*     */     
/*     */ 
/* 317 */     while (len > 0) {
/* 318 */       int max = this.mOutputBuffer.length - ptr;
/* 319 */       if (max < 1) {
/* 320 */         this.mOutputPtr = ptr;
/* 321 */         flushBuffer();
/* 322 */         ptr = 0;
/* 323 */         max = this.mOutputBuffer.length;
/*     */       }
/*     */       
/* 326 */       if (max > len) {
/* 327 */         max = len;
/*     */       }
/* 329 */       int inEnd = offset + max; for (;;) { if (offset >= inEnd) break label310;
/* 330 */         int c = data.charAt(offset++);
/* 331 */         if (c < 32) {
/* 332 */           if (c != 10)
/*     */           {
/* 334 */             if (c != 13)
/*     */             {
/* 336 */               if (c != 9)
/* 337 */                 throwInvalidChar(c); }
/*     */           }
/* 339 */         } else if (c > 126) {
/* 340 */           if (c > 255) {
/* 341 */             this.mOutputPtr = ptr;
/* 342 */             throwInvalidLatinChar(c);
/* 343 */           } else if ((this.mXml11) && 
/* 344 */             (c < 159) && (c != 133)) {
/* 345 */             this.mOutputPtr = ptr;
/* 346 */             throwInvalidChar(c);
/*     */           }
/*     */         }
/* 349 */         else if ((c == 62) && 
/* 350 */           (offset > 2) && (data.charAt(offset - 2) == ']') && (data.charAt(offset - 3) == ']'))
/*     */         {
/* 352 */           if (!this.mFixContent) {
/* 353 */             return offset - 3;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 358 */           this.mOutputPtr = ptr;
/* 359 */           writeCDataEnd();
/* 360 */           writeCDataStart();
/* 361 */           writeAscii((byte)62);
/* 362 */           ptr = this.mOutputPtr;
/*     */           
/*     */ 
/*     */ 
/* 366 */           len = data.length() - offset;
/* 367 */           break;
/*     */         }
/*     */         
/* 370 */         this.mOutputBuffer[(ptr++)] = ((byte)c); }
/*     */       label310:
/* 372 */       len -= max;
/*     */     }
/* 374 */     this.mOutputPtr = ptr;
/* 375 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected int writeCDataContent(char[] cbuf, int start, int len)
/*     */     throws IOException
/*     */   {
/* 383 */     if (!this.mCheckContent) {
/* 384 */       writeRaw(cbuf, start, len);
/* 385 */       return -1;
/*     */     }
/*     */     
/* 388 */     int ptr = this.mOutputPtr;
/* 389 */     int offset = start;
/*     */     
/*     */ 
/* 392 */     while (len > 0) {
/* 393 */       int max = this.mOutputBuffer.length - ptr;
/* 394 */       if (max < 1) {
/* 395 */         this.mOutputPtr = ptr;
/* 396 */         flushBuffer();
/* 397 */         ptr = 0;
/* 398 */         max = this.mOutputBuffer.length;
/*     */       }
/*     */       
/* 401 */       if (max > len) {
/* 402 */         max = len;
/*     */       }
/*     */       
/* 405 */       for (int inEnd = offset + max; offset < inEnd;) {
/* 406 */         int c = cbuf[(offset++)];
/* 407 */         if (c < 32) {
/* 408 */           if (c != 10)
/*     */           {
/* 410 */             if (c != 13)
/*     */             {
/* 412 */               if (c != 9)
/* 413 */                 throwInvalidChar(c); }
/*     */           }
/* 415 */         } else if (c > 126) {
/* 416 */           if (c > 255) {
/* 417 */             this.mOutputPtr = ptr;
/* 418 */             throwInvalidLatinChar(c);
/* 419 */           } else if ((this.mXml11) && 
/* 420 */             (c < 159) && (c != 133)) {
/* 421 */             this.mOutputPtr = ptr;
/* 422 */             throwInvalidChar(c);
/*     */           }
/*     */         }
/* 425 */         else if ((c == 62) && 
/* 426 */           (offset >= start + 3) && (cbuf[(offset - 2)] == ']') && (cbuf[(offset - 3)] == ']'))
/*     */         {
/* 428 */           if (!this.mFixContent) {
/* 429 */             return offset - 3;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 434 */           this.mOutputPtr = ptr;
/* 435 */           writeCDataEnd();
/* 436 */           writeCDataStart();
/* 437 */           writeAscii((byte)62);
/* 438 */           ptr = this.mOutputPtr;
/*     */           
/*     */ 
/*     */ 
/* 442 */           max -= inEnd - offset;
/* 443 */           break;
/*     */         }
/*     */         
/* 446 */         this.mOutputBuffer[(ptr++)] = ((byte)c);
/*     */       }
/* 448 */       len -= max;
/*     */     }
/* 450 */     this.mOutputPtr = ptr;
/* 451 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected int writeCommentContent(String data)
/*     */     throws IOException
/*     */   {
/* 459 */     int offset = 0;
/* 460 */     int len = data.length();
/* 461 */     if (!this.mCheckContent) {
/* 462 */       writeRaw(data, offset, len);
/* 463 */       return -1;
/*     */     }
/*     */     
/* 466 */     int ptr = this.mOutputPtr;
/*     */     
/*     */ 
/* 469 */     while (len > 0) {
/* 470 */       int max = this.mOutputBuffer.length - ptr;
/* 471 */       if (max < 1) {
/* 472 */         this.mOutputPtr = ptr;
/* 473 */         flushBuffer();
/* 474 */         ptr = 0;
/* 475 */         max = this.mOutputBuffer.length;
/*     */       }
/*     */       
/* 478 */       if (max > len) {
/* 479 */         max = len;
/*     */       }
/*     */       
/* 482 */       for (int inEnd = offset + max; offset < inEnd;) {
/* 483 */         int c = data.charAt(offset++);
/* 484 */         if (c < 32) {
/* 485 */           if (c != 10)
/*     */           {
/* 487 */             if (c != 13)
/*     */             {
/* 489 */               if (c != 9)
/* 490 */                 throwInvalidChar(c); }
/*     */           }
/* 492 */         } else if (c > 126) {
/* 493 */           if (c > 255) {
/* 494 */             this.mOutputPtr = ptr;
/* 495 */             throwInvalidLatinChar(c);
/* 496 */           } else if ((this.mXml11) && 
/* 497 */             (c < 159) && (c != 133)) {
/* 498 */             this.mOutputPtr = ptr;
/* 499 */             throwInvalidChar(c);
/*     */           }
/*     */         }
/* 502 */         else if ((c == 45) && 
/* 503 */           (offset > 1) && (data.charAt(offset - 2) == '-')) {
/* 504 */           if (!this.mFixContent) {
/* 505 */             return offset - 2;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 512 */           this.mOutputBuffer[(ptr++)] = 32;
/* 513 */           if (ptr >= this.mOutputBuffer.length) {
/* 514 */             this.mOutputPtr = ptr;
/* 515 */             flushBuffer();
/* 516 */             ptr = 0;
/*     */           }
/* 518 */           this.mOutputBuffer[(ptr++)] = 45;
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 523 */           max -= inEnd - offset;
/* 524 */           break;
/*     */         }
/*     */         
/* 527 */         this.mOutputBuffer[(ptr++)] = ((byte)c);
/*     */       }
/* 529 */       len -= max;
/*     */     }
/* 531 */     this.mOutputPtr = ptr;
/* 532 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected int writePIData(String data)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 540 */     int offset = 0;
/* 541 */     int len = data.length();
/* 542 */     if (!this.mCheckContent) {
/* 543 */       writeRaw(data, offset, len);
/* 544 */       return -1;
/*     */     }
/*     */     
/* 547 */     int ptr = this.mOutputPtr;
/* 548 */     while (len > 0) {
/* 549 */       int max = this.mOutputBuffer.length - ptr;
/* 550 */       if (max < 1) {
/* 551 */         this.mOutputPtr = ptr;
/* 552 */         flushBuffer();
/* 553 */         ptr = 0;
/* 554 */         max = this.mOutputBuffer.length;
/*     */       }
/*     */       
/* 557 */       if (max > len) {
/* 558 */         max = len;
/*     */       }
/* 560 */       for (int inEnd = offset + max; offset < inEnd; offset++) {
/* 561 */         int c = data.charAt(offset);
/* 562 */         if (c < 32) {
/* 563 */           if (c != 10)
/*     */           {
/* 565 */             if (c != 13)
/*     */             {
/* 567 */               if (c != 9)
/* 568 */                 throwInvalidChar(c); }
/*     */           }
/* 570 */         } else if (c > 126) {
/* 571 */           if (c > 255) {
/* 572 */             this.mOutputPtr = ptr;
/* 573 */             throwInvalidLatinChar(c);
/* 574 */           } else if ((this.mXml11) && 
/* 575 */             (c < 159) && (c != 133)) {
/* 576 */             this.mOutputPtr = ptr;
/* 577 */             throwInvalidChar(c);
/*     */           }
/*     */         }
/* 580 */         else if ((c == 62) && 
/* 581 */           (offset > 0) && (data.charAt(offset - 1) == '?')) {
/* 582 */           return offset - 2;
/*     */         }
/*     */         
/* 585 */         this.mOutputBuffer[(ptr++)] = ((byte)c);
/*     */       }
/* 587 */       len -= max;
/*     */     }
/* 589 */     this.mOutputPtr = ptr;
/* 590 */     return -1;
/*     */   }
/*     */   
/*     */   protected void writeTextContent(String data)
/*     */     throws IOException
/*     */   {
/* 596 */     int offset = 0;
/* 597 */     int len = data.length();
/* 598 */     int ptr = this.mOutputPtr;
/*     */     
/*     */ 
/* 601 */     while (len > 0) {
/* 602 */       int max = this.mOutputBuffer.length - this.mOutputPtr;
/* 603 */       if (max < 1) {
/* 604 */         flushBuffer();
/* 605 */         max = this.mOutputBuffer.length;
/*     */       }
/*     */       
/* 608 */       if (this.mSurrogate != 0) {
/* 609 */         int sec = data.charAt(offset++);
/* 610 */         sec = calcSurrogate(sec);
/* 611 */         writeAsEntity(sec);
/* 612 */         len--;
/*     */       }
/*     */       else
/*     */       {
/* 616 */         if (max > len) {
/* 617 */           max = len;
/*     */         }
/*     */         
/* 620 */         int inEnd = offset + max; for (;;) { if (offset < inEnd) {
/* 621 */             int c = data.charAt(offset++);
/* 622 */             if (c < 32) {
/* 623 */               if ((c == 10) || (c == 9)) {
/* 624 */                 this.mOutputBuffer[(this.mOutputPtr++)] = ((byte)c);
/* 625 */                 continue; }
/* 626 */               if (c == 13) {
/* 627 */                 if (!this.mEscapeCR) {
/* 628 */                   this.mOutputBuffer[(this.mOutputPtr++)] = ((byte)c);
/*     */                 }
/*     */               }
/* 631 */               else if (((!this.mXml11) || (c == 0)) && 
/* 632 */                 (this.mCheckContent)) {
/* 633 */                 throwInvalidChar(c);
/*     */               }
/*     */               
/*     */ 
/*     */             }
/* 638 */             else if (c < 127) {
/* 639 */               if ((c != 60) && (c != 38) && (
/* 640 */                 (c != 62) || ((offset > 1) && (data.charAt(offset - 2) != ']')))) {
/* 641 */                 this.mOutputBuffer[(this.mOutputPtr++)] = ((byte)c);
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/* 646 */               if ((c > 159) && (c <= 255)) {
/* 647 */                 this.mOutputBuffer[(this.mOutputPtr++)] = ((byte)c);
/* 648 */                 continue;
/*     */               }
/*     */               
/* 651 */               if ((c >= 55296) && (c <= 57343)) {
/* 652 */                 this.mSurrogate = c;
/*     */                 
/* 654 */                 if (offset == inEnd) {
/*     */                   break label387;
/*     */                 }
/* 657 */                 c = calcSurrogate(data.charAt(offset++));
/*     */               }
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/* 664 */             writeAsEntity(c);
/* 665 */             len = data.length() - offset;
/* 666 */             break; } }
/*     */         label387:
/* 668 */         len -= max;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void writeTextContent(char[] cbuf, int offset, int len)
/*     */     throws IOException
/*     */   {
/* 676 */     while (len > 0) {
/* 677 */       int max = this.mOutputBuffer.length - this.mOutputPtr;
/* 678 */       if (max < 1) {
/* 679 */         flushBuffer();
/* 680 */         max = this.mOutputBuffer.length;
/*     */       }
/*     */       
/* 683 */       if (this.mSurrogate != 0) {
/* 684 */         int sec = cbuf[(offset++)];
/* 685 */         sec = calcSurrogate(sec);
/* 686 */         writeAsEntity(sec);
/* 687 */         len--;
/*     */       }
/*     */       else
/*     */       {
/* 691 */         if (max > len) {
/* 692 */           max = len;
/*     */         }
/*     */         
/* 695 */         for (int inEnd = offset + max; offset < inEnd;) {
/* 696 */           int c = cbuf[(offset++)];
/* 697 */           if (c < 32) {
/* 698 */             if ((c == 10) || (c == 9)) {
/* 699 */               this.mOutputBuffer[(this.mOutputPtr++)] = ((byte)c);
/* 700 */               continue; }
/* 701 */             if (c == 13) {
/* 702 */               if (!this.mEscapeCR) {
/* 703 */                 this.mOutputBuffer[(this.mOutputPtr++)] = ((byte)c);
/*     */               }
/*     */             }
/* 706 */             else if (((!this.mXml11) || (c == 0)) && 
/* 707 */               (this.mCheckContent)) {
/* 708 */               throwInvalidChar(c);
/*     */             }
/*     */             
/*     */ 
/*     */           }
/* 713 */           else if (c < 127) {
/* 714 */             if ((c != 60) && (c != 38))
/*     */             {
/*     */ 
/*     */ 
/* 718 */               if ((c != 62) || ((offset > 1) && (cbuf[(offset - 2)] != ']'))) {
/* 719 */                 this.mOutputBuffer[(this.mOutputPtr++)] = ((byte)c);
/*     */               }
/*     */             }
/*     */           }
/*     */           else {
/* 724 */             if ((c > 159) && (c <= 255)) {
/* 725 */               this.mOutputBuffer[(this.mOutputPtr++)] = ((byte)c);
/* 726 */               continue;
/*     */             }
/*     */             
/* 729 */             if ((c >= 55296) && (c <= 57343)) {
/* 730 */               this.mSurrogate = c;
/*     */               
/* 732 */               if (offset == inEnd) {
/*     */                 break;
/*     */               }
/* 735 */               c = calcSurrogate(cbuf[(offset++)]);
/*     */             }
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 742 */           writeAsEntity(c);
/* 743 */           max -= inEnd - offset;
/*     */         }
/*     */         
/* 746 */         len -= max;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void throwInvalidLatinChar(int c)
/*     */     throws IOException
/*     */   {
/* 760 */     flush();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 768 */     throw new IOException("Invalid XML character (0x" + Integer.toHexString(c) + "); can only be output using character entity when using ISO-8859-1 encoding");
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sw\ISOLatin1XmlWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */