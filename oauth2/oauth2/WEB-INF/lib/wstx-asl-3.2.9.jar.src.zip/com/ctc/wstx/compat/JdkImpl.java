package com.ctc.wstx.compat;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public abstract class JdkImpl
{
  public abstract boolean leakingThreadLocal();
  
  public abstract List getEmptyList();
  
  public abstract Map getEmptyMap();
  
  public abstract Set getEmptySet();
  
  public abstract HashMap getInsertOrderedMap();
  
  public abstract HashMap getInsertOrderedMap(int paramInt);
  
  public abstract HashMap getLRULimitMap(int paramInt);
  
  public abstract boolean setInitCause(Throwable paramThrowable1, Throwable paramThrowable2);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\compat\JdkImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */