/*     */ package com.ctc.wstx.sr;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import com.ctc.wstx.cfg.ErrorConsts;
/*     */ import com.ctc.wstx.dtd.DTDId;
/*     */ import com.ctc.wstx.dtd.DTDSubset;
/*     */ import com.ctc.wstx.dtd.DTDValidatorBase;
/*     */ import com.ctc.wstx.dtd.FullDTDReader;
/*     */ import com.ctc.wstx.io.BranchingReaderSource;
/*     */ import com.ctc.wstx.io.DefaultInputResolver;
/*     */ import com.ctc.wstx.io.InputBootstrapper;
/*     */ import com.ctc.wstx.io.WstxInputSource;
/*     */ import com.ctc.wstx.util.URLUtil;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.codehaus.stax2.validation.DTDValidationSchema;
/*     */ import org.codehaus.stax2.validation.ValidationProblemHandler;
/*     */ import org.codehaus.stax2.validation.XMLValidationSchema;
/*     */ import org.codehaus.stax2.validation.XMLValidator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidatingStreamReader
/*     */   extends BasicStreamReader
/*     */ {
/*     */   static final String STAX_PROP_ENTITIES = "javax.xml.stream.entities";
/*     */   static final String STAX_PROP_NOTATIONS = "javax.xml.stream.notations";
/*  74 */   DTDValidationSchema mDTD = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  81 */   XMLValidator mAutoDtdValidator = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  89 */   boolean mDTDOverridden = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  95 */   boolean mDtdValidatorSet = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 100 */   protected ValidationProblemHandler mVldProbHandler = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ValidatingStreamReader(InputBootstrapper bs, BranchingReaderSource input, ReaderCreator owner, ReaderConfig cfg, InputElementStack elemStack, boolean forER)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 120 */     super(bs, input, owner, cfg, elemStack, forER);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ValidatingStreamReader createValidatingStreamReader(BranchingReaderSource input, ReaderCreator owner, ReaderConfig cfg, InputBootstrapper bs, boolean forER)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 141 */     ValidatingStreamReader sr = new ValidatingStreamReader(bs, input, owner, cfg, createElementStack(cfg), forER);
/*     */     
/* 143 */     return sr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getProperty(String name)
/*     */   {
/* 155 */     if (name.equals("javax.xml.stream.entities")) {
/* 156 */       safeEnsureFinishToken();
/* 157 */       if ((this.mDTD == null) || (!(this.mDTD instanceof DTDSubset))) {
/* 158 */         return null;
/*     */       }
/* 160 */       List l = ((DTDSubset)this.mDTD).getGeneralEntityList();
/*     */       
/*     */ 
/*     */ 
/* 164 */       return new ArrayList(l);
/*     */     }
/* 166 */     if (name.equals("javax.xml.stream.notations")) {
/* 167 */       safeEnsureFinishToken();
/* 168 */       if ((this.mDTD == null) || (!(this.mDTD instanceof DTDSubset))) {
/* 169 */         return null;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 174 */       List l = ((DTDSubset)this.mDTD).getNotationList();
/* 175 */       return new ArrayList(l);
/*     */     }
/* 177 */     return super.getProperty(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFeature(String name, Object value)
/*     */   {
/* 194 */     if (name.equals("org.codehaus.stax2.propDtdOverride")) {
/* 195 */       this.mDTDOverridden = true;
/*     */       
/* 197 */       if ((value != null) && (!(value instanceof DTDValidationSchema))) {
/* 198 */         throw new IllegalArgumentException("Value to set for feature " + name + " not of type DTDValidationSchema");
/*     */       }
/* 200 */       this.mDTD = ((DTDValidationSchema)value);
/*     */     } else {
/* 202 */       super.setFeature(name, value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getProcessedDTD()
/*     */   {
/* 224 */     return this.mDTD;
/*     */   }
/*     */   
/*     */   public DTDValidationSchema getProcessedDTDSchema() {
/* 228 */     return this.mDTD;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLValidator validateAgainst(XMLValidationSchema schema)
/*     */     throws XMLStreamException
/*     */   {
/* 241 */     return this.mElementStack.validateAgainst(schema);
/*     */   }
/*     */   
/*     */ 
/*     */   public XMLValidator stopValidatingAgainst(XMLValidationSchema schema)
/*     */     throws XMLStreamException
/*     */   {
/* 248 */     return this.mElementStack.stopValidatingAgainst(schema);
/*     */   }
/*     */   
/*     */ 
/*     */   public XMLValidator stopValidatingAgainst(XMLValidator validator)
/*     */     throws XMLStreamException
/*     */   {
/* 255 */     return this.mElementStack.stopValidatingAgainst(validator);
/*     */   }
/*     */   
/*     */ 
/*     */   public ValidationProblemHandler setValidationProblemHandler(ValidationProblemHandler h)
/*     */   {
/* 261 */     ValidationProblemHandler oldH = this.mVldProbHandler;
/* 262 */     this.mVldProbHandler = h;
/* 263 */     return oldH;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void finishDTD(boolean copyContents)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 289 */     if (!hasConfigFlags(16)) {
/* 290 */       super.finishDTD(copyContents);
/* 291 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 297 */     char c = getNextChar(" in DOCTYPE declaration");
/* 298 */     DTDSubset intSubset = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 303 */     if (c == '[')
/*     */     {
/* 305 */       if (copyContents) {
/* 306 */         ((BranchingReaderSource)this.mInput).startBranch(this.mTextBuffer, this.mInputPtr, this.mCfgNormalizeLFs);
/*     */       }
/*     */       try
/*     */       {
/* 310 */         intSubset = FullDTDReader.readInternalSubset(this, this.mInput, this.mConfig, hasConfigFlags(32), this.mDocXmlVersion);
/*     */ 
/*     */ 
/*     */       }
/*     */       finally
/*     */       {
/*     */ 
/* 317 */         if (copyContents)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 322 */           ((BranchingReaderSource)this.mInput).endBranch(this.mInputPtr - 1);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 327 */       c = getNextCharAfterWS(" in internal DTD subset");
/*     */     }
/*     */     
/* 330 */     if (c != '>') {
/* 331 */       throwUnexpectedChar(c, "; expected '>' to finish DOCTYPE declaration.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 341 */     if (!this.mDTDOverridden)
/*     */     {
/*     */ 
/* 344 */       DTDSubset extSubset = null;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 357 */       if ((this.mDtdPublicId != null) || (this.mDtdSystemId != null)) {
/* 358 */         extSubset = findDtdExtSubset(this.mDtdPublicId, this.mDtdSystemId, intSubset);
/*     */       }
/*     */       
/* 361 */       if (intSubset == null) {
/* 362 */         this.mDTD = extSubset;
/* 363 */       } else if (extSubset == null) {
/* 364 */         this.mDTD = intSubset;
/*     */       } else {
/* 366 */         this.mDTD = intSubset.combineWithExternalSubset(this, extSubset);
/*     */       }
/*     */     }
/*     */     
/* 370 */     if (this.mDTD == null) {
/* 371 */       this.mGeneralEntities = null;
/*     */     } else {
/* 373 */       if ((this.mDTD instanceof DTDSubset)) {
/* 374 */         this.mGeneralEntities = ((DTDSubset)this.mDTD).getGeneralEntityMap();
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 379 */         doReportProblem(this.mConfig.getXMLReporter(), ErrorConsts.WT_DT_DECL, "Value to set for feature org.codehaus.stax2.propDtdOverride not a native Woodstox DTD implementation (but " + this.mDTD.getClass() + "): can not access full entity or notation information", null);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 387 */       this.mAutoDtdValidator = this.mDTD.createValidator(this.mElementStack);
/* 388 */       this.mDtdValidatorSet = true;
/* 389 */       Object nsDefs = null;
/* 390 */       if ((this.mAutoDtdValidator instanceof DTDValidatorBase)) {
/* 391 */         DTDValidatorBase dtdv = (DTDValidatorBase)this.mAutoDtdValidator;
/* 392 */         dtdv.setAttrValueNormalization(this.mCfgNormalizeAttrs);
/*     */         
/* 394 */         if (dtdv.hasNsDefaults()) {
/* 395 */           nsDefs = dtdv;
/*     */         }
/*     */       }
/* 398 */       this.mElementStack.setAutomaticDTDValidator(this.mAutoDtdValidator, (NsDefaultProvider)nsDefs);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initValidation()
/*     */     throws XMLStreamException
/*     */   {
/* 410 */     if ((hasConfigFlags(32)) && (!this.mDtdValidatorSet))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 415 */       reportProblem(ErrorConsts.WT_DT_DECL, ErrorConsts.W_MISSING_DTD);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private DTDSubset findDtdExtSubset(String pubId, String sysId, DTDSubset intSubset)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 435 */     boolean cache = hasConfigFlags(65536);
/* 436 */     DTDId dtdId = constructDtdId(pubId, sysId);
/*     */     
/* 438 */     if (cache) {
/* 439 */       DTDSubset extSubset = findCachedSubset(dtdId, intSubset);
/* 440 */       if (extSubset != null) {
/* 441 */         return extSubset;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 450 */     if (sysId == null) {
/* 451 */       throwParseError("Can not resolve DTD with public id '" + this.mDtdPublicId + "'; missing system identifier.");
/*     */     }
/*     */     
/* 454 */     WstxInputSource src = null;
/*     */     try
/*     */     {
/* 457 */       int xmlVersion = this.mDocXmlVersion;
/*     */       
/* 459 */       if (xmlVersion == 0) {
/* 460 */         xmlVersion = 256;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 468 */       src = DefaultInputResolver.resolveEntity(this.mInput, null, null, pubId, sysId, this.mConfig.getDtdResolver(), this.mConfig, xmlVersion);
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (FileNotFoundException fex)
/*     */     {
/*     */ 
/* 475 */       throwParseError("(was " + fex.getClass().getName() + ") " + fex.getMessage());
/*     */     }
/*     */     
/* 478 */     DTDSubset extSubset = FullDTDReader.readExternalSubset(src, this.mConfig, intSubset, hasConfigFlags(32), this.mDocXmlVersion);
/*     */     
/*     */ 
/*     */ 
/* 482 */     if (cache)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 488 */       if (extSubset.isCachable()) {
/* 489 */         this.mOwner.addCachedDTD(dtdId, extSubset);
/*     */       }
/*     */     }
/*     */     
/* 493 */     return extSubset;
/*     */   }
/*     */   
/*     */   private DTDSubset findCachedSubset(DTDId id, DTDSubset intSubset)
/*     */     throws XMLStreamException
/*     */   {
/* 499 */     DTDSubset extSubset = this.mOwner.findCachedDTD(id);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 504 */     if ((extSubset != null) && (
/* 505 */       (intSubset == null) || (extSubset.isReusableWith(intSubset)))) {
/* 506 */       return extSubset;
/*     */     }
/*     */     
/* 509 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private URL resolveExtSubsetPath(String systemId)
/*     */     throws IOException
/*     */   {
/* 520 */     URL ctxt = this.mInput == null ? null : this.mInput.getSource();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 525 */     if (ctxt == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 530 */       return URLUtil.urlFromSystemId(systemId);
/*     */     }
/* 532 */     return URLUtil.urlFromSystemId(systemId, ctxt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected DTDId constructDtdId(String pubId, String sysId)
/*     */     throws IOException
/*     */   {
/* 541 */     int significantFlags = this.mConfigFlags & 0x286021;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 558 */     URL sysRef = (sysId == null) || (sysId.length() == 0) ? null : resolveExtSubsetPath(sysId);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 566 */     boolean usePublicId = (this.mConfigFlags & 0x20000) != 0;
/* 567 */     if ((usePublicId) && (pubId != null) && (pubId.length() > 0)) {
/* 568 */       return DTDId.construct(pubId, sysRef, significantFlags, this.mXml11);
/*     */     }
/* 570 */     if (sysRef == null) {
/* 571 */       return null;
/*     */     }
/* 573 */     return DTDId.constructFromSystemId(sysRef, significantFlags, this.mXml11);
/*     */   }
/*     */   
/*     */   protected DTDId constructDtdId(URL sysId)
/*     */     throws IOException
/*     */   {
/* 579 */     int significantFlags = this.mConfigFlags & 0x86021;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 591 */     return DTDId.constructFromSystemId(sysId, significantFlags, this.mXml11);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void reportInvalidContent(int evtType)
/*     */     throws XMLStreamException
/*     */   {
/* 610 */     switch (this.mVldContent) {
/*     */     case 0: 
/* 612 */       reportValidationProblem(ErrorConsts.ERR_VLD_EMPTY, this.mElementStack.getTopElementDesc(), ErrorConsts.tokenTypeDesc(evtType));
/*     */       
/*     */ 
/* 615 */       break;
/*     */     case 1: 
/* 617 */       reportValidationProblem(ErrorConsts.ERR_VLD_NON_MIXED, this.mElementStack.getTopElementDesc());
/*     */       
/* 619 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */     case 2: 
/*     */     case 3: 
/* 625 */       reportValidationProblem(ErrorConsts.ERR_VLD_ANY, this.mElementStack.getTopElementDesc(), ErrorConsts.tokenTypeDesc(evtType));
/*     */       
/*     */ 
/* 628 */       break;
/*     */     default: 
/* 630 */       throwParseError("Internal error: trying to report invalid content for " + evtType);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sr\ValidatingStreamReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */