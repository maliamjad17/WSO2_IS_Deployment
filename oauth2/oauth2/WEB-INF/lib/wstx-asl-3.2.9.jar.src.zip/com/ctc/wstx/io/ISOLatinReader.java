/*     */ package com.ctc.wstx.io;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ISOLatinReader
/*     */   extends BaseReader
/*     */ {
/*  33 */   boolean mXml11 = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  38 */   int mByteCount = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ISOLatinReader(ReaderConfig cfg, InputStream in, byte[] buf, int ptr, int len)
/*     */   {
/*  48 */     super(cfg, in, buf, ptr, len);
/*     */   }
/*     */   
/*     */   public void setXmlCompliancy(int xmlVersion)
/*     */   {
/*  53 */     this.mXml11 = (xmlVersion == 272);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(char[] cbuf, int start, int len)
/*     */     throws IOException
/*     */   {
/*  66 */     if (this.mBuffer == null) {
/*  67 */       return -1;
/*     */     }
/*     */     
/*  70 */     if ((start < 0) || (start + len > cbuf.length)) {
/*  71 */       reportBounds(cbuf, start, len);
/*     */     }
/*     */     
/*     */ 
/*  75 */     int avail = this.mLength - this.mPtr;
/*  76 */     if (avail <= 0) {
/*  77 */       this.mByteCount += this.mLength;
/*     */       
/*  79 */       int count = this.mIn.read(this.mBuffer);
/*  80 */       if (count <= 0) {
/*  81 */         if (count == 0) {
/*  82 */           reportStrangeStream();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*  87 */         freeBuffers();
/*  88 */         return -1;
/*     */       }
/*  90 */       this.mLength = (avail = count);
/*  91 */       this.mPtr = 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  98 */     if (len > avail) {
/*  99 */       len = avail;
/*     */     }
/* 101 */     int i = this.mPtr;
/* 102 */     int last = i + len;
/*     */     
/* 104 */     if (this.mXml11) {
/* 105 */       while (i < last) {
/* 106 */         char c = (char)(this.mBuffer[(i++)] & 0xFF);
/* 107 */         if ((c >= '') && 
/* 108 */           (c <= '')) {
/* 109 */           if (c == '') {
/* 110 */             c = '\n';
/* 111 */           } else if (c >= '') {
/* 112 */             int pos = this.mByteCount + this.mPtr;
/* 113 */             reportInvalidXml11(c, pos, pos);
/*     */           }
/*     */         }
/*     */         
/* 117 */         cbuf[(start++)] = c;
/*     */       }
/*     */     }
/*     */     
/* 121 */     while (i < last) {
/* 122 */       cbuf[(start++)] = ((char)(this.mBuffer[(i++)] & 0xFF));
/*     */     }
/*     */     
/*     */ 
/* 126 */     this.mPtr = last;
/* 127 */     return len;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\io\ISOLatinReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */