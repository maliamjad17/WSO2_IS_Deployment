/*    */ package com.ctc.wstx.compat;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import javax.xml.namespace.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class QNameCreator
/*    */ {
/*    */   private static final Helper _helper;
/*    */   
/*    */   static
/*    */   {
/* 24 */     Helper h = null;
/*    */     try
/*    */     {
/* 27 */       Helper h0 = new Helper();
/* 28 */       h0.create("elem", "http://dummy", "ns");
/* 29 */       h = h0;
/*    */     } catch (Throwable t) {
/* 31 */       System.err.println("WARN: Could not construct QNameCreator.Helper; assume 3-arg QName constructor not available and use 2-arg method instead. Problem: " + t.getMessage());
/*    */     }
/* 33 */     _helper = h;
/*    */   }
/*    */   
/*    */   public static QName create(String uri, String localName, String prefix)
/*    */   {
/* 38 */     if (_helper == null) {
/* 39 */       return new QName(uri, localName);
/*    */     }
/* 41 */     return _helper.create(uri, localName, prefix);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static final class Helper
/*    */   {
/*    */     public QName create(String localName, String nsURI, String prefix)
/*    */     {
/* 53 */       return new QName(localName, nsURI, prefix);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\compat\QNameCreator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */