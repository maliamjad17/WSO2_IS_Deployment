/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SeqContentSpec
/*     */   extends ContentSpec
/*     */ {
/*     */   final boolean mNsAware;
/*     */   final ContentSpec[] mContentSpecs;
/*     */   
/*     */   public SeqContentSpec(boolean nsAware, char arity, ContentSpec[] subSpecs)
/*     */   {
/*  24 */     super(arity);
/*  25 */     this.mNsAware = nsAware;
/*  26 */     this.mContentSpecs = subSpecs;
/*     */   }
/*     */   
/*     */   public static SeqContentSpec construct(boolean nsAware, char arity, Collection subSpecs)
/*     */   {
/*  31 */     ContentSpec[] specs = new ContentSpec[subSpecs.size()];
/*  32 */     subSpecs.toArray(specs);
/*  33 */     return new SeqContentSpec(nsAware, arity, specs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StructValidator getSimpleValidator()
/*     */   {
/*  47 */     ContentSpec[] specs = this.mContentSpecs;
/*  48 */     int i = 0;
/*  49 */     int len = specs.length;
/*  51 */     for (; 
/*  51 */         i < len; i++) {
/*  52 */       if (!specs[i].isLeaf()) {
/*     */         break;
/*     */       }
/*     */     }
/*     */     
/*  57 */     if (i == len) {
/*  58 */       NameKey[] set = new NameKey[len];
/*  59 */       for (i = 0; i < len; i++) {
/*  60 */         TokenContentSpec ss = (TokenContentSpec)specs[i];
/*  61 */         set[i] = ss.getName();
/*     */       }
/*  63 */       return new Validator(this.mArity, set);
/*     */     }
/*     */     
/*     */ 
/*  67 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModelNode rewrite()
/*     */   {
/*  77 */     ModelNode model = rewrite(this.mContentSpecs, 0, this.mContentSpecs.length);
/*     */     
/*     */ 
/*  80 */     if (this.mArity == '*') {
/*  81 */       return new StarModel(model);
/*     */     }
/*  83 */     if (this.mArity == '?') {
/*  84 */       return new OptionalModel(model);
/*     */     }
/*  86 */     if (this.mArity == '+') {
/*  87 */       return new ConcatModel(model, new StarModel(model.cloneModel()));
/*     */     }
/*     */     
/*  90 */     return model;
/*     */   }
/*     */   
/*     */ 
/*     */   private ModelNode rewrite(ContentSpec[] specs, int first, int last)
/*     */   {
/*  96 */     int count = last - first;
/*  97 */     if (count > 3) {
/*  98 */       int mid = last + first + 1 >> 1;
/*  99 */       return new ConcatModel(rewrite(specs, first, mid), rewrite(specs, mid, last));
/*     */     }
/*     */     
/* 102 */     ConcatModel model = new ConcatModel(specs[first].rewrite(), specs[(first + 1)].rewrite());
/*     */     
/* 104 */     if (count == 3) {
/* 105 */       model = new ConcatModel(model, specs[(first + 2)].rewrite());
/*     */     }
/* 107 */     return model;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 112 */     StringBuffer sb = new StringBuffer();
/* 113 */     sb.append('(');
/*     */     
/* 115 */     for (int i = 0; i < this.mContentSpecs.length; i++) {
/* 116 */       if (i > 0) {
/* 117 */         sb.append(", ");
/*     */       }
/* 119 */       sb.append(this.mContentSpecs[i].toString());
/*     */     }
/* 121 */     sb.append(')');
/*     */     
/* 123 */     if (this.mArity != ' ') {
/* 124 */       sb.append(this.mArity);
/*     */     }
/* 126 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final class Validator
/*     */     extends StructValidator
/*     */   {
/*     */     final char mArity;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     final NameKey[] mNames;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 149 */     int mRounds = 0;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 154 */     int mStep = 0;
/*     */     
/*     */     public Validator(char arity, NameKey[] names)
/*     */     {
/* 158 */       this.mArity = arity;
/* 159 */       this.mNames = names;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public StructValidator newInstance()
/*     */     {
/* 168 */       return new Validator(this.mArity, this.mNames);
/*     */     }
/*     */     
/*     */ 
/*     */     public String tryToValidate(NameKey elemName)
/*     */     {
/* 174 */       if ((this.mStep == 0) && (this.mRounds == 1) && (
/* 175 */         (this.mArity == '?') || (this.mArity == ' '))) {
/* 176 */         return "was not expecting any more elements in the sequence (" + concatNames(this.mNames) + ")";
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 181 */       NameKey next = this.mNames[this.mStep];
/* 182 */       if (!elemName.equals(next)) {
/* 183 */         return expElem(this.mStep);
/*     */       }
/* 185 */       if (++this.mStep == this.mNames.length) {
/* 186 */         this.mRounds += 1;
/* 187 */         this.mStep = 0;
/*     */       }
/* 189 */       return null;
/*     */     }
/*     */     
/*     */     public String fullyValid()
/*     */     {
/* 194 */       if (this.mStep != 0) {
/* 195 */         return expElem(this.mStep) + "; got end element";
/*     */       }
/*     */       
/* 198 */       switch (this.mArity) {
/*     */       case '*': 
/*     */       case '?': 
/* 201 */         return null;
/*     */       case ' ': 
/*     */       case '+': 
/* 204 */         if (this.mRounds > 0) {
/* 205 */           return null;
/*     */         }
/* 207 */         return "Expected sequence (" + concatNames(this.mNames) + "); got end element";
/*     */       }
/*     */       
/* 210 */       throw new Error("Internal error");
/*     */     }
/*     */     
/*     */     private String expElem(int step)
/*     */     {
/* 215 */       return "expected element <" + this.mNames[step] + "> in sequence (" + concatNames(this.mNames) + ")";
/*     */     }
/*     */     
/*     */ 
/*     */     static final String concatNames(NameKey[] names)
/*     */     {
/* 221 */       StringBuffer sb = new StringBuffer();
/* 222 */       int i = 0; for (int len = names.length; i < len; i++) {
/* 223 */         if (i > 0) {
/* 224 */           sb.append(", ");
/*     */         }
/* 226 */         sb.append(names[i].toString());
/*     */       }
/* 228 */       return sb.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\SeqContentSpec.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */