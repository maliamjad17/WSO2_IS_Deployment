/*    */ package com.ctc.wstx.evt;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ import javax.xml.stream.Location;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import javax.xml.stream.XMLStreamWriter;
/*    */ import javax.xml.stream.events.EntityDeclaration;
/*    */ import javax.xml.stream.events.EntityReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WEntityReference
/*    */   extends WEvent
/*    */   implements EntityReference
/*    */ {
/*    */   final EntityDeclaration mDecl;
/*    */   final String mName;
/*    */   
/*    */   public WEntityReference(Location loc, EntityDeclaration decl)
/*    */   {
/* 24 */     super(loc);
/* 25 */     this.mDecl = decl;
/* 26 */     this.mName = null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public WEntityReference(Location loc, String name)
/*    */   {
/* 36 */     super(loc);
/* 37 */     this.mDecl = null;
/* 38 */     this.mName = name;
/*    */   }
/*    */   
/*    */   public EntityDeclaration getDeclaration() {
/* 42 */     return this.mDecl;
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 47 */     if (this.mName != null) {
/* 48 */       return this.mName;
/*    */     }
/* 50 */     return this.mDecl.getName();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getEventType()
/*    */   {
/* 60 */     return 9;
/*    */   }
/*    */   
/*    */   public boolean isEntityReference() {
/* 64 */     return true;
/*    */   }
/*    */   
/*    */   public void writeAsEncodedUnicode(Writer w) throws XMLStreamException
/*    */   {
/*    */     try
/*    */     {
/* 71 */       w.write(38);
/* 72 */       w.write(getName());
/* 73 */       w.write(59);
/*    */     } catch (IOException ie) {
/* 75 */       throwFromIOE(ie);
/*    */     }
/*    */   }
/*    */   
/*    */   public void writeUsing(XMLStreamWriter w) throws XMLStreamException
/*    */   {
/* 81 */     w.writeEntityRef(getName());
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\evt\WEntityReference.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */