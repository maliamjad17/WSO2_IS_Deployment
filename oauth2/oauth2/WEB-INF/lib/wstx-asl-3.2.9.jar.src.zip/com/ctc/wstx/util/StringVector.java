/*     */ package com.ctc.wstx.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StringVector
/*     */ {
/*     */   private String[] mStrings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int mSize;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringVector(int initialCount)
/*     */   {
/*  25 */     this.mStrings = new String[initialCount];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  51 */   public int size() { return this.mSize; }
/*     */   
/*  53 */   public boolean isEmpty() { return this.mSize == 0; }
/*     */   
/*     */   public String getString(int index) {
/*  56 */     if ((index < 0) || (index >= this.mSize)) {
/*  57 */       throw new IllegalArgumentException("Index " + index + " out of valid range; current size: " + this.mSize + ".");
/*     */     }
/*  59 */     return this.mStrings[index];
/*     */   }
/*     */   
/*     */   public String getLastString() {
/*  63 */     if (this.mSize < 1) {
/*  64 */       throw new IllegalStateException("getLastString() called on empty StringVector.");
/*     */     }
/*  66 */     return this.mStrings[(this.mSize - 1)];
/*     */   }
/*     */   
/*     */   public String[] getInternalArray() {
/*  70 */     return this.mStrings;
/*     */   }
/*     */   
/*     */   public String[] asArray() {
/*  74 */     String[] strs = new String[this.mSize];
/*  75 */     System.arraycopy(this.mStrings, 0, strs, 0, this.mSize);
/*  76 */     return strs;
/*     */   }
/*     */   
/*     */   public boolean containsInterned(String value) {
/*  80 */     String[] str = this.mStrings;
/*  81 */     int i = 0; for (int len = this.mSize; i < len; i++) {
/*  82 */       if (str[i] == value) {
/*  83 */         return true;
/*     */       }
/*     */     }
/*  86 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addString(String str)
/*     */   {
/*  96 */     if (this.mSize == this.mStrings.length) {
/*  97 */       String[] old = this.mStrings;
/*  98 */       int oldSize = old.length;
/*  99 */       this.mStrings = new String[oldSize + (oldSize << 1)];
/* 100 */       System.arraycopy(old, 0, this.mStrings, 0, oldSize);
/*     */     }
/* 102 */     this.mStrings[(this.mSize++)] = str;
/*     */   }
/*     */   
/*     */   public void addStrings(String str1, String str2) {
/* 106 */     if (this.mSize + 2 > this.mStrings.length) {
/* 107 */       String[] old = this.mStrings;
/* 108 */       int oldSize = old.length;
/* 109 */       this.mStrings = new String[oldSize + (oldSize << 1)];
/* 110 */       System.arraycopy(old, 0, this.mStrings, 0, oldSize);
/*     */     }
/* 112 */     this.mStrings[this.mSize] = str1;
/* 113 */     this.mStrings[(this.mSize + 1)] = str2;
/* 114 */     this.mSize += 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setString(int index, String str)
/*     */   {
/* 140 */     this.mStrings[index] = str;
/*     */   }
/*     */   
/*     */   public void clear(boolean removeRefs) {
/* 144 */     if (removeRefs) {
/* 145 */       int i = 0; for (int len = this.mSize; i < len; i++) {
/* 146 */         this.mStrings[i] = null;
/*     */       }
/*     */     }
/* 149 */     this.mSize = 0;
/*     */   }
/*     */   
/*     */   public String removeLast() {
/* 153 */     String result = this.mStrings[(--this.mSize)];
/* 154 */     this.mStrings[this.mSize] = null;
/* 155 */     return result;
/*     */   }
/*     */   
/*     */   public void removeLast(int count) { for (;;) { 
/* 159 */       if (count < 0) break;
/* 160 */       this.mStrings[(--this.mSize)] = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String findLastFromMap(String key)
/*     */   {
/* 180 */     int index = this.mSize;
/* 181 */     do { index -= 2; if (index < 0) break;
/* 182 */     } while (this.mStrings[index] != key);
/* 183 */     return this.mStrings[(index + 1)];
/*     */     
/*     */ 
/* 186 */     return null;
/*     */   }
/*     */   
/*     */   public String findLastNonInterned(String key)
/*     */   {
/* 191 */     int index = this.mSize;
/* 192 */     for (;;) { index -= 2; if (index < 0) break;
/* 193 */       String curr = this.mStrings[index];
/* 194 */       if ((curr == key) || ((curr != null) && (curr.equals(key)))) {
/* 195 */         return this.mStrings[(index + 1)];
/*     */       }
/*     */     }
/* 198 */     return null;
/*     */   }
/*     */   
/*     */   public int findLastIndexNonInterned(String key) {
/* 202 */     int index = this.mSize;
/* 203 */     for (;;) { index -= 2; if (index < 0) break;
/* 204 */       String curr = this.mStrings[index];
/* 205 */       if ((curr == key) || ((curr != null) && (curr.equals(key)))) {
/* 206 */         return index;
/*     */       }
/*     */     }
/* 209 */     return -1;
/*     */   }
/*     */   
/*     */   public String findLastByValueNonInterned(String value) {
/* 213 */     for (int index = this.mSize - 1; index > 0; index -= 2) {
/* 214 */       String currVal = this.mStrings[index];
/* 215 */       if ((currVal == value) || ((currVal != null) && (currVal.equals(value)))) {
/* 216 */         return this.mStrings[(index - 1)];
/*     */       }
/*     */     }
/* 219 */     return null;
/*     */   }
/*     */   
/*     */   public int findLastIndexByValueNonInterned(String value) {
/* 223 */     for (int index = this.mSize - 1; index > 0; index -= 2) {
/* 224 */       String currVal = this.mStrings[index];
/* 225 */       if ((currVal == value) || ((currVal != null) && (currVal.equals(value)))) {
/* 226 */         return index - 1;
/*     */       }
/*     */     }
/* 229 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 268 */     StringBuffer sb = new StringBuffer(this.mSize * 16);
/* 269 */     sb.append("[(size = ");
/* 270 */     sb.append(this.mSize);
/* 271 */     sb.append(" ) ");
/* 272 */     for (int i = 0; i < this.mSize; i++) {
/* 273 */       if (i > 0) {
/* 274 */         sb.append(", ");
/*     */       }
/* 276 */       sb.append('"');
/* 277 */       sb.append(this.mStrings[i]);
/* 278 */       sb.append('"');
/*     */       
/* 280 */       sb.append(" == ");
/* 281 */       sb.append(Integer.toHexString(System.identityHashCode(this.mStrings[i])));
/*     */     }
/* 283 */     sb.append(']');
/* 284 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\util\StringVector.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */