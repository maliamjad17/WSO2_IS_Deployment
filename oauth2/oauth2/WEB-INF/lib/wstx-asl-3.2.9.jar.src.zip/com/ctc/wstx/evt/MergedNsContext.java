/*     */ package com.ctc.wstx.evt;
/*     */ 
/*     */ import com.ctc.wstx.compat.JdkFeatures;
/*     */ import com.ctc.wstx.compat.JdkImpl;
/*     */ import com.ctc.wstx.util.BaseNsContext;
/*     */ import com.ctc.wstx.util.EmptyIterator;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.stream.events.Namespace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MergedNsContext
/*     */   extends BaseNsContext
/*     */ {
/*     */   final NamespaceContext mParentCtxt;
/*     */   final List mNamespaces;
/*  41 */   Map mNsByPrefix = null;
/*     */   
/*  43 */   Map mNsByURI = null;
/*     */   
/*     */   protected MergedNsContext(NamespaceContext parentCtxt, List localNs)
/*     */   {
/*  47 */     this.mParentCtxt = parentCtxt;
/*  48 */     this.mNamespaces = (localNs == null ? JdkFeatures.getInstance().getEmptyList() : localNs);
/*     */   }
/*     */   
/*     */ 
/*     */   public static BaseNsContext construct(NamespaceContext parentCtxt, List localNs)
/*     */   {
/*  54 */     return new MergedNsContext(parentCtxt, localNs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String doGetNamespaceURI(String prefix)
/*     */   {
/*  66 */     if (this.mNsByPrefix == null) {
/*  67 */       this.mNsByPrefix = buildByPrefixMap();
/*     */     }
/*  69 */     Namespace ns = (Namespace)this.mNsByPrefix.get(prefix);
/*  70 */     if ((ns == null) && (this.mParentCtxt != null)) {
/*  71 */       return this.mParentCtxt.getNamespaceURI(prefix);
/*     */     }
/*  73 */     return ns == null ? null : ns.getNamespaceURI();
/*     */   }
/*     */   
/*     */ 
/*     */   public String doGetPrefix(String nsURI)
/*     */   {
/*  79 */     if (this.mNsByURI == null) {
/*  80 */       this.mNsByURI = buildByNsURIMap();
/*     */     }
/*  82 */     Namespace ns = (Namespace)this.mNsByURI.get(nsURI);
/*  83 */     if ((ns == null) && (this.mParentCtxt != null)) {
/*  84 */       return this.mParentCtxt.getPrefix(nsURI);
/*     */     }
/*  86 */     return ns == null ? null : ns.getPrefix();
/*     */   }
/*     */   
/*     */ 
/*     */   public Iterator doGetPrefixes(String nsURI)
/*     */   {
/*  92 */     ArrayList l = null;
/*     */     
/*  94 */     int i = 0; for (int len = this.mNamespaces.size(); i < len; i++) {
/*  95 */       Namespace ns = (Namespace)this.mNamespaces.get(i);
/*  96 */       String uri = ns.getNamespaceURI();
/*  97 */       if (uri == null) {
/*  98 */         uri = "";
/*     */       }
/* 100 */       if (uri.equals(nsURI)) {
/* 101 */         if (l == null) {
/* 102 */           l = new ArrayList();
/*     */         }
/* 104 */         String prefix = ns.getPrefix();
/* 105 */         l.add(prefix == null ? "" : prefix);
/*     */       }
/*     */     }
/*     */     
/* 109 */     if (this.mParentCtxt != null) {
/* 110 */       Iterator it = this.mParentCtxt.getPrefixes(nsURI);
/* 111 */       if (l == null) {
/* 112 */         return it;
/*     */       }
/* 114 */       while (it.hasNext()) {
/* 115 */         l.add(it.next());
/*     */       }
/*     */     }
/*     */     
/* 119 */     return l == null ? EmptyIterator.getInstance() : l.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator getNamespaces()
/*     */   {
/* 134 */     return this.mNamespaces.iterator();
/*     */   }
/*     */   
/*     */   public void outputNamespaceDeclarations(Writer w) throws IOException
/*     */   {
/* 139 */     int i = 0; for (int len = this.mNamespaces.size(); i < len; i++) {
/* 140 */       Namespace ns = (Namespace)this.mNamespaces.get(i);
/* 141 */       w.write(32);
/* 142 */       w.write("xmlns");
/* 143 */       if (!ns.isDefaultNamespaceDeclaration()) {
/* 144 */         w.write(58);
/* 145 */         w.write(ns.getPrefix());
/*     */       }
/* 147 */       w.write("=\"");
/* 148 */       w.write(ns.getNamespaceURI());
/* 149 */       w.write(34);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void outputNamespaceDeclarations(XMLStreamWriter w)
/*     */     throws XMLStreamException
/*     */   {
/* 160 */     int i = 0; for (int len = this.mNamespaces.size(); i < len; i++) {
/* 161 */       Namespace ns = (Namespace)this.mNamespaces.get(i);
/* 162 */       if (ns.isDefaultNamespaceDeclaration()) {
/* 163 */         w.writeDefaultNamespace(ns.getNamespaceURI());
/*     */       } else {
/* 165 */         w.writeNamespace(ns.getPrefix(), ns.getNamespaceURI());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Map buildByPrefixMap()
/*     */   {
/* 178 */     int len = this.mNamespaces.size();
/* 179 */     if (len == 0) {
/* 180 */       return JdkFeatures.getInstance().getEmptyMap();
/*     */     }
/*     */     
/* 183 */     Map m = JdkFeatures.getInstance().getInsertOrderedMap(1 + len + (len >> 1));
/* 184 */     for (int i = 0; i < len; i++) {
/* 185 */       Namespace ns = (Namespace)this.mNamespaces.get(i);
/* 186 */       String prefix = ns.getPrefix();
/* 187 */       if (prefix == null) {
/* 188 */         prefix = "";
/*     */       }
/* 190 */       m.put(prefix, ns);
/*     */     }
/* 192 */     return m;
/*     */   }
/*     */   
/*     */   private Map buildByNsURIMap()
/*     */   {
/* 197 */     int len = this.mNamespaces.size();
/* 198 */     if (len == 0) {
/* 199 */       return JdkFeatures.getInstance().getEmptyMap();
/*     */     }
/*     */     
/* 202 */     Map m = JdkFeatures.getInstance().getInsertOrderedMap(1 + len + (len >> 1));
/* 203 */     for (int i = 0; i < len; i++) {
/* 204 */       Namespace ns = (Namespace)this.mNamespaces.get(i);
/* 205 */       String uri = ns.getNamespaceURI();
/* 206 */       if (uri == null) {
/* 207 */         uri = "";
/*     */       }
/* 209 */       m.put(uri, ns);
/*     */     }
/* 211 */     return m;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\evt\MergedNsContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */