/*    */ package com.ctc.wstx.evt;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ import javax.xml.stream.Location;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import javax.xml.stream.XMLStreamWriter;
/*    */ import javax.xml.stream.events.Comment;
/*    */ 
/*    */ 
/*    */ public class WComment
/*    */   extends WEvent
/*    */   implements Comment
/*    */ {
/*    */   final String mContent;
/*    */   
/*    */   public WComment(Location loc, String content)
/*    */   {
/* 19 */     super(loc);
/* 20 */     this.mContent = content;
/*    */   }
/*    */   
/*    */   public String getText() {
/* 24 */     return this.mContent;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getEventType()
/*    */   {
/* 34 */     return 5;
/*    */   }
/*    */   
/*    */   public void writeAsEncodedUnicode(Writer w) throws XMLStreamException
/*    */   {
/*    */     try
/*    */     {
/* 41 */       w.write("<!--");
/* 42 */       w.write(this.mContent);
/* 43 */       w.write("-->");
/*    */     } catch (IOException ie) {
/* 45 */       throwFromIOE(ie);
/*    */     }
/*    */   }
/*    */   
/*    */   public void writeUsing(XMLStreamWriter w) throws XMLStreamException
/*    */   {
/* 51 */     w.writeComment(this.mContent);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\evt\WComment.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */