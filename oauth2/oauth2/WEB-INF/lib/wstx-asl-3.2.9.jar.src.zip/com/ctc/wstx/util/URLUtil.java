/*     */ package com.ctc.wstx.util;
/*     */ 
/*     */ import com.ctc.wstx.compat.JdkFeatures;
/*     */ import com.ctc.wstx.compat.JdkImpl;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class URLUtil
/*     */ {
/*     */   public static URL urlFromSystemId(String sysId)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/*  32 */       int ix = sysId.indexOf(':', 0);
/*     */       
/*     */ 
/*     */ 
/*  36 */       if ((ix >= 3) && (ix <= 8)) {
/*  37 */         return new URL(sysId);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  48 */       String absPath = new File(sysId).getAbsolutePath();
/*     */       
/*     */ 
/*  51 */       char sep = File.separatorChar;
/*  52 */       if (sep != '/') {
/*  53 */         absPath = absPath.replace(sep, '/');
/*     */       }
/*     */       
/*  56 */       if ((absPath.length() > 0) && (absPath.charAt(0) != '/')) {
/*  57 */         absPath = "/" + absPath;
/*     */       }
/*  59 */       return new URL("file", "", absPath);
/*     */     } catch (MalformedURLException e) {
/*  61 */       throwIOException(e, sysId); }
/*  62 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public static URL urlFromSystemId(String sysId, URL ctxt)
/*     */     throws IOException
/*     */   {
/*  69 */     if (ctxt == null) {
/*  70 */       return urlFromSystemId(sysId);
/*     */     }
/*     */     try {
/*  73 */       return new URL(ctxt, sysId);
/*     */     } catch (MalformedURLException e) {
/*  75 */       throwIOException(e, sysId); }
/*  76 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static URL urlFromCurrentDir()
/*     */     throws MalformedURLException
/*     */   {
/*  91 */     return new File("a").getAbsoluteFile().getParentFile().toURL();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static InputStream optimizedStreamFromURL(URL url)
/*     */     throws IOException
/*     */   {
/* 102 */     if ("file".equals(url.getProtocol()))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 109 */       if (url.getHost() == null) {
/* 110 */         return new FileInputStream(url.getPath());
/*     */       }
/*     */     }
/* 113 */     return url.openStream();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void throwIOException(MalformedURLException mex, String sysId)
/*     */     throws IOException
/*     */   {
/* 131 */     IOException ie = new IOException("[resolving systemId '" + sysId + "']: " + mex.toString());
/*     */     
/* 133 */     JdkFeatures.getInstance().setInitCause(ie, mex);
/* 134 */     throw ie;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\util\URLUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */