/*    */ package com.ctc.wstx.sax;
/*    */ 
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WrappedSaxException
/*    */   extends RuntimeException
/*    */ {
/*    */   final SAXException mCause;
/*    */   
/*    */   public WrappedSaxException(SAXException cause)
/*    */   {
/* 31 */     this.mCause = cause;
/*    */   }
/*    */   
/* 34 */   public SAXException getSaxException() { return this.mCause; }
/*    */   
/* 36 */   public String toString() { return this.mCause.toString(); }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sax\WrappedSaxException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */