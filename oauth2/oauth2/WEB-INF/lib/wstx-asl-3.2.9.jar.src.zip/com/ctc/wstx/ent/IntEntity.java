/*     */ package com.ctc.wstx.ent;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import com.ctc.wstx.io.InputSourceFactory;
/*     */ import com.ctc.wstx.io.TextEscaper;
/*     */ import com.ctc.wstx.io.WstxInputLocation;
/*     */ import com.ctc.wstx.io.WstxInputSource;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.net.URL;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntEntity
/*     */   extends EntityDecl
/*     */ {
/*     */   protected final Location mContentLocation;
/*     */   final char[] mRepl;
/*  35 */   String mReplText = null;
/*     */   
/*     */ 
/*     */   public IntEntity(Location loc, String name, URL ctxt, char[] repl, Location defLoc)
/*     */   {
/*  40 */     super(loc, name, ctxt);
/*  41 */     this.mRepl = repl;
/*  42 */     this.mContentLocation = defLoc;
/*     */   }
/*     */   
/*     */   public static IntEntity create(String id, String repl)
/*     */   {
/*  47 */     return create(id, repl.toCharArray());
/*     */   }
/*     */   
/*     */   public static IntEntity create(String id, char[] val)
/*     */   {
/*  52 */     WstxInputLocation loc = WstxInputLocation.getEmptyLocation();
/*  53 */     return new IntEntity(loc, id, null, val, loc);
/*     */   }
/*     */   
/*     */   public String getNotationName() {
/*  57 */     return null;
/*     */   }
/*     */   
/*     */   public String getPublicId() {
/*  61 */     return null;
/*     */   }
/*     */   
/*     */   public String getReplacementText()
/*     */   {
/*  66 */     String repl = this.mReplText;
/*  67 */     if (repl == null) {
/*  68 */       repl = this.mRepl.length == 0 ? "" : new String(this.mRepl);
/*  69 */       this.mReplText = repl;
/*     */     }
/*  71 */     return this.mReplText;
/*     */   }
/*     */   
/*     */   public int getReplacementText(Writer w)
/*     */     throws IOException
/*     */   {
/*  77 */     w.write(this.mRepl);
/*  78 */     return this.mRepl.length;
/*     */   }
/*     */   
/*     */   public String getSystemId() {
/*  82 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeEnc(Writer w)
/*     */     throws IOException
/*     */   {
/*  93 */     w.write("<!ENTITY ");
/*  94 */     w.write(this.mName);
/*  95 */     w.write(" \"");
/*  96 */     TextEscaper.outputDTDText(w, this.mRepl, 0, this.mRepl.length);
/*  97 */     w.write("\">");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] getReplacementChars()
/*     */   {
/* 116 */     return this.mRepl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 121 */   public boolean isExternal() { return false; }
/*     */   
/* 123 */   public boolean isParsed() { return true; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WstxInputSource expand(WstxInputSource parent, XMLResolver res, ReaderConfig cfg, int xmlVersion)
/*     */   {
/* 133 */     return InputSourceFactory.constructCharArraySource(parent, this.mName, this.mRepl, 0, this.mRepl.length, this.mContentLocation, null);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\ent\IntEntity.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */