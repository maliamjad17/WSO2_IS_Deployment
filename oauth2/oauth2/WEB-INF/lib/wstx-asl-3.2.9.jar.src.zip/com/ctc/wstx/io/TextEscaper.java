/*     */ package com.ctc.wstx.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TextEscaper
/*     */ {
/*     */   public static Writer constructAttrValueWriter(Writer w, String enc, char qchar)
/*     */     throws UnsupportedEncodingException
/*     */   {
/*  23 */     int bitSize = guessEncodingBitSize(enc);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  29 */     if (bitSize < 16) {
/*  30 */       return new SingleByteAttrValueWriter(w, enc, qchar, 1 << bitSize);
/*     */     }
/*  32 */     return new UTFAttrValueWriter(w, enc, qchar, true);
/*     */   }
/*     */   
/*     */   public static Writer constructTextWriter(Writer w, String enc)
/*     */     throws UnsupportedEncodingException
/*     */   {
/*  38 */     int bitSize = guessEncodingBitSize(enc);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  44 */     if (bitSize < 16) {
/*  45 */       return new SingleByteTextWriter(w, enc, 1 << bitSize);
/*     */     }
/*  47 */     return new UTFTextWriter(w, enc, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void writeEscapedXMLText(Writer w, String text)
/*     */     throws IOException
/*     */   {
/*  59 */     int len = text.length();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  69 */     if (len < 2) {
/*  70 */       if (len == 1) {
/*  71 */         char c = text.charAt(0);
/*  72 */         if (c == '<') {
/*  73 */           w.write("&lt;");
/*  74 */         } else if (c == '&') {
/*  75 */           w.write("&amp;");
/*     */         } else {
/*  77 */           w.write(text.charAt(0));
/*     */         }
/*     */       }
/*  80 */       return;
/*     */     }
/*     */     
/*  83 */     int i = 0;
/*  84 */     while (i < len) {
/*  85 */       int start = i;
/*  86 */       char c = '\000';
/*     */       
/*  88 */       while (i < len) {
/*  89 */         c = text.charAt(i);
/*  90 */         if ((c == '<') || (c == '&')) {
/*     */           break;
/*     */         }
/*  93 */         if ((c == '>') && (i >= 2) && (text.charAt(i - 1) == ']') && (text.charAt(i - 2) == ']')) {
/*     */           break;
/*     */         }
/*     */         
/*  97 */         i++;
/*     */       }
/*  99 */       int outLen = i - start;
/* 100 */       if (outLen > 0) {
/* 101 */         w.write(text, start, outLen);
/*     */       }
/* 103 */       if (i < len) {
/* 104 */         if (c == '<') {
/* 105 */           w.write("&lt;");
/* 106 */         } else if (c == '&') {
/* 107 */           w.write("&amp;");
/* 108 */         } else if (c == '>') {
/* 109 */           w.write("&gt;");
/*     */         }
/*     */       }
/* 112 */       i++;
/*     */     }
/*     */   }
/*     */   
/*     */   public static void writeEscapedAttrValue(Writer w, String value)
/*     */     throws IOException
/*     */   {
/* 119 */     int i = 0;
/* 120 */     int len = value.length();
/*     */     do {
/* 122 */       int start = i;
/* 123 */       char c = '\000';
/* 125 */       for (; 
/* 125 */           i < len; i++) {
/* 126 */         c = value.charAt(i);
/* 127 */         if ((c == '<') || (c == '&') || (c == '"')) {
/*     */           break;
/*     */         }
/*     */       }
/* 131 */       int outLen = i - start;
/* 132 */       if (outLen > 0) {
/* 133 */         w.write(value, start, outLen);
/*     */       }
/* 135 */       if (i < len) {
/* 136 */         if (c == '<') {
/* 137 */           w.write("&lt;");
/* 138 */         } else if (c == '&') {
/* 139 */           w.write("&amp;");
/* 140 */         } else if (c == '"') {
/* 141 */           w.write("&quot;");
/*     */         }
/*     */       }
/*     */       
/* 145 */       i++; } while (i < len);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void outputDTDText(Writer w, char[] ch, int offset, int len)
/*     */     throws IOException
/*     */   {
/* 156 */     int i = offset;
/* 157 */     len += offset;
/*     */     do {
/* 159 */       int start = i;
/* 160 */       char c = '\000';
/* 162 */       for (; 
/* 162 */           i < len; i++) {
/* 163 */         c = ch[i];
/* 164 */         if ((c == '&') || (c == '%') || (c == '"')) {
/*     */           break;
/*     */         }
/*     */       }
/* 168 */       int outLen = i - start;
/* 169 */       if (outLen > 0) {
/* 170 */         w.write(ch, start, outLen);
/*     */       }
/* 172 */       if (i < len) {
/* 173 */         if (c == '&')
/*     */         {
/*     */ 
/*     */ 
/* 177 */           w.write("&amp;");
/* 178 */         } else if (c == '%')
/*     */         {
/* 180 */           w.write("&#37;");
/* 181 */         } else if (c == '"')
/*     */         {
/* 183 */           w.write("&#34;");
/*     */         }
/*     */       }
/* 186 */       i++; } while (i < len);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int guessEncodingBitSize(String enc)
/*     */   {
/* 198 */     if (enc.length() < 1) {
/* 199 */       return 16;
/*     */     }
/*     */     
/* 202 */     enc = CharsetNames.normalize(enc);
/*     */     
/*     */ 
/* 205 */     if (enc == "UTF-8")
/* 206 */       return 16;
/* 207 */     if (enc == "ISO-8859-1")
/* 208 */       return 8;
/* 209 */     if (enc == "US-ASCII")
/* 210 */       return 7;
/* 211 */     if ((enc == "UTF-16") || (enc == "UTF-16BE") || (enc == "UTF-16LE") || (enc == "UTF-32BE") || (enc == "UTF-32LE"))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 216 */       return 16;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 224 */     return 8;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\io\TextEscaper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */