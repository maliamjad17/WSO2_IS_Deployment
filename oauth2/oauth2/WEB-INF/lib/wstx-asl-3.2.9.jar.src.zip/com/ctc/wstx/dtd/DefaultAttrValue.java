/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ import com.ctc.wstx.cfg.ErrorConsts;
/*     */ import java.text.MessageFormat;
/*     */ import javax.xml.stream.Location;
/*     */ import org.codehaus.stax2.validation.ValidationContext;
/*     */ import org.codehaus.stax2.validation.XMLValidationException;
/*     */ import org.codehaus.stax2.validation.XMLValidationProblem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DefaultAttrValue
/*     */ {
/*     */   public static final int DEF_DEFAULT = 1;
/*     */   public static final int DEF_IMPLIED = 2;
/*     */   public static final int DEF_REQUIRED = 3;
/*     */   public static final int DEF_FIXED = 4;
/*  56 */   static final DefaultAttrValue sImplied = new DefaultAttrValue(2);
/*     */   
/*  58 */   static final DefaultAttrValue sRequired = new DefaultAttrValue(3);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final int mDefValueType;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  76 */   private String mValue = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  82 */   private UndeclaredEntity mUndeclaredEntity = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private DefaultAttrValue(int defValueType)
/*     */   {
/*  92 */     this.mDefValueType = defValueType;
/*     */   }
/*     */   
/*  95 */   public static DefaultAttrValue constructImplied() { return sImplied; }
/*  96 */   public static DefaultAttrValue constructRequired() { return sRequired; }
/*     */   
/*     */   public static DefaultAttrValue constructFixed() {
/*  99 */     return new DefaultAttrValue(4);
/*     */   }
/*     */   
/*     */   public static DefaultAttrValue constructOptional() {
/* 103 */     return new DefaultAttrValue(1);
/*     */   }
/*     */   
/*     */   public void setValue(String v) {
/* 107 */     this.mValue = v;
/*     */   }
/*     */   
/*     */   public void addUndeclaredPE(String name, Location loc)
/*     */   {
/* 112 */     addUndeclaredEntity(name, loc, true);
/*     */   }
/*     */   
/*     */   public void addUndeclaredGE(String name, Location loc)
/*     */   {
/* 117 */     addUndeclaredEntity(name, loc, false);
/*     */   }
/*     */   
/*     */   public void reportUndeclared(ValidationContext ctxt)
/*     */     throws XMLValidationException
/*     */   {
/* 123 */     this.mUndeclaredEntity.reportUndeclared(ctxt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasUndeclaredEntities()
/*     */   {
/* 133 */     return this.mUndeclaredEntity != null;
/*     */   }
/*     */   
/*     */   public String getValue() {
/* 137 */     return this.mValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getValueIfOk()
/*     */   {
/* 148 */     return this.mUndeclaredEntity == null ? this.mValue : null;
/*     */   }
/*     */   
/*     */   public boolean isRequired() {
/* 152 */     return this == sRequired;
/*     */   }
/*     */   
/*     */   public boolean isFixed() {
/* 156 */     return this.mDefValueType == 4;
/*     */   }
/*     */   
/*     */   public boolean hasDefaultValue() {
/* 160 */     return (this.mDefValueType == 1) || (this.mDefValueType == 4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSpecial()
/*     */   {
/* 172 */     return this != sImplied;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addUndeclaredEntity(String name, Location loc, boolean isPe)
/*     */   {
/* 183 */     if (this.mUndeclaredEntity == null) {
/* 184 */       this.mUndeclaredEntity = new UndeclaredEntity(name, loc, isPe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static final class UndeclaredEntity
/*     */   {
/*     */     final String mName;
/*     */     
/*     */ 
/*     */     final boolean mIsPe;
/*     */     
/*     */     final Location mLocation;
/*     */     
/*     */ 
/*     */     UndeclaredEntity(String name, Location loc, boolean isPe)
/*     */     {
/* 202 */       this.mName = name;
/* 203 */       this.mIsPe = isPe;
/* 204 */       this.mLocation = loc;
/*     */     }
/*     */     
/*     */     public void reportUndeclared(ValidationContext ctxt)
/*     */       throws XMLValidationException
/*     */     {
/* 210 */       String msg = MessageFormat.format(ErrorConsts.ERR_DTD_UNDECLARED_ENTITY, new Object[] { this.mIsPe ? "parsed" : "general", this.mName });
/* 211 */       ctxt.reportProblem(new XMLValidationProblem(this.mLocation, msg, 3));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\DefaultAttrValue.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */