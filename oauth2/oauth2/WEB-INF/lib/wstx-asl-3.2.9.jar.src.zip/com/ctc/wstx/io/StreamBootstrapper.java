/*     */ package com.ctc.wstx.io;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import com.ctc.wstx.exc.WstxEOFException;
/*     */ import com.ctc.wstx.exc.WstxException;
/*     */ import com.ctc.wstx.exc.WstxIOException;
/*     */ import java.io.CharConversionException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StreamBootstrapper
/*     */   extends InputBootstrapper
/*     */ {
/*     */   static final int MIN_BUF_SIZE = 128;
/*     */   final InputStream mIn;
/*     */   private byte[] mByteBuffer;
/*     */   private int mInputPtr;
/*     */   private int mInputLen;
/*  65 */   boolean mBigEndian = true;
/*     */   
/*  67 */   boolean mHadBOM = false;
/*     */   
/*  69 */   boolean mByteSizeFound = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int mBytesPerChar;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */   boolean mEBCDIC = false;
/*     */   
/*  87 */   String mInputEncoding = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */   int[] mSingleByteTranslation = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private StreamBootstrapper(InputStream in, String pubId, String sysId)
/*     */   {
/* 103 */     super(pubId, sysId);
/* 104 */     this.mIn = in;
/* 105 */     this.mInputPtr = (this.mInputLen = 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static StreamBootstrapper getInstance(InputStream in, String pubId, String sysId)
/*     */   {
/* 116 */     return new StreamBootstrapper(in, pubId, sysId);
/*     */   }
/*     */   
/*     */   public Reader bootstrapInput(ReaderConfig cfg, boolean mainDoc, int xmlVersion)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 122 */     String normEnc = null;
/*     */     
/*     */ 
/* 125 */     int bufSize = cfg.getInputBufferLength();
/* 126 */     if (bufSize < 128) {
/* 127 */       bufSize = 128;
/*     */     }
/* 129 */     this.mByteBuffer = cfg.allocFullBBuffer(bufSize);
/*     */     
/* 131 */     resolveStreamEncoding();
/*     */     
/* 133 */     if (hasXmlDecl())
/*     */     {
/* 135 */       readXmlDecl(mainDoc, xmlVersion);
/* 136 */       if (this.mFoundEncoding != null) {
/* 137 */         normEnc = verifyXmlEncoding(this.mFoundEncoding);
/*     */       }
/*     */       
/*     */     }
/*     */     else
/*     */     {
/* 143 */       this.mXml11Handling = (272 == xmlVersion);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 148 */     if (normEnc == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 153 */       if ((this.mEBCDIC) && (
/* 154 */         (this.mFoundEncoding == null) || (this.mFoundEncoding.length() == 0))) {
/* 155 */         reportXmlProblem("Missing encoding declaration: underlying encoding looks like an EBCDIC variant, but no xml encoding declaration found");
/*     */       }
/*     */       
/*     */ 
/* 159 */       if (this.mBytesPerChar == 2) {
/* 160 */         normEnc = this.mBigEndian ? "UTF-16BE" : "UTF-16LE";
/* 161 */       } else if (this.mBytesPerChar == 4)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 167 */         normEnc = this.mBigEndian ? "UTF-32BE" : "UTF-32LE";
/*     */       }
/*     */       else {
/* 170 */         normEnc = "UTF-8";
/*     */       }
/*     */     }
/*     */     
/* 174 */     this.mInputEncoding = normEnc;
/*     */     
/*     */ 
/*     */ 
/*     */     BaseReader r;
/*     */     
/*     */ 
/*     */ 
/* 182 */     if (normEnc == "UTF-8") {
/* 183 */       r = new UTF8Reader(cfg, this.mIn, this.mByteBuffer, this.mInputPtr, this.mInputLen); } else { BaseReader r;
/* 184 */       if (normEnc == "ISO-8859-1") {
/* 185 */         r = new ISOLatinReader(cfg, this.mIn, this.mByteBuffer, this.mInputPtr, this.mInputLen); } else { BaseReader r;
/* 186 */         if (normEnc == "US-ASCII") {
/* 187 */           r = new AsciiReader(cfg, this.mIn, this.mByteBuffer, this.mInputPtr, this.mInputLen); } else { BaseReader r;
/* 188 */           if (normEnc.startsWith("UTF-32"))
/*     */           {
/* 190 */             if (normEnc == "UTF-32") {
/* 191 */               this.mInputEncoding = (this.mBigEndian ? "UTF-32BE" : "UTF-32LE");
/*     */             }
/* 193 */             r = new UTF32Reader(cfg, this.mIn, this.mByteBuffer, this.mInputPtr, this.mInputLen, this.mBigEndian);
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 198 */             InputStream in = this.mIn;
/* 199 */             if (this.mInputPtr < this.mInputLen) {
/* 200 */               in = new MergedStream(cfg, in, this.mByteBuffer, this.mInputPtr, this.mInputLen);
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/* 206 */             if (normEnc == "UTF-16") {
/* 207 */               this.mInputEncoding = (normEnc = this.mBigEndian ? "UTF-16BE" : "UTF-16LE");
/*     */             }
/*     */             try {
/* 210 */               return new InputStreamReader(in, normEnc);
/*     */             } catch (UnsupportedEncodingException usex) {
/* 212 */               throw new WstxIOException("Unsupported encoding: " + usex.getMessage());
/*     */             }
/*     */           } } } }
/*     */     BaseReader r;
/* 216 */     if (this.mXml11Handling) {
/* 217 */       r.setXmlCompliancy(272);
/*     */     }
/*     */     
/* 220 */     return r;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getInputEncoding()
/*     */   {
/* 228 */     return this.mInputEncoding;
/*     */   }
/*     */   
/*     */   public int getInputTotal() {
/* 232 */     int total = this.mInputProcessed + this.mInputPtr;
/* 233 */     if (this.mBytesPerChar > 1) {
/* 234 */       total /= this.mBytesPerChar;
/*     */     }
/* 236 */     return total;
/*     */   }
/*     */   
/*     */   public int getInputColumn() {
/* 240 */     int col = this.mInputPtr - this.mInputRowStart;
/* 241 */     if (this.mBytesPerChar > 1) {
/* 242 */       col /= this.mBytesPerChar;
/*     */     }
/* 244 */     return col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void resolveStreamEncoding()
/*     */     throws IOException, WstxException
/*     */   {
/* 261 */     this.mBytesPerChar = 0;
/* 262 */     this.mBigEndian = true;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 267 */     if (ensureLoaded(4))
/*     */     {
/*     */ 
/* 270 */       int quartet = this.mByteBuffer[0] << 24 | (this.mByteBuffer[1] & 0xFF) << 16 | (this.mByteBuffer[2] & 0xFF) << 8 | this.mByteBuffer[3] & 0xFF;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 278 */       switch (quartet) {
/*     */       case 65279: 
/* 280 */         this.mBigEndian = true;
/* 281 */         this.mInputPtr = (this.mBytesPerChar = 4);
/* 282 */         break;
/*     */       case -131072: 
/* 284 */         this.mInputPtr = (this.mBytesPerChar = 4);
/* 285 */         this.mBigEndian = false;
/* 286 */         break;
/*     */       case 65534: 
/* 288 */         reportWeirdUCS4("2143");
/* 289 */         break;
/*     */       case -16842752: 
/* 291 */         reportWeirdUCS4("3412");
/* 292 */         break;
/*     */       
/*     */ 
/*     */       default: 
/* 296 */         int msw = quartet >>> 16;
/* 297 */         if (msw == 65279) {
/* 298 */           this.mInputPtr = (this.mBytesPerChar = 2);
/* 299 */           this.mBigEndian = true;
/*     */ 
/*     */         }
/* 302 */         else if (msw == 65534) {
/* 303 */           this.mInputPtr = (this.mBytesPerChar = 2);
/* 304 */           this.mBigEndian = false;
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 309 */         else if (quartet >>> 8 == 15711167) {
/* 310 */           this.mInputPtr = 3;
/* 311 */           this.mBytesPerChar = 1;
/* 312 */           this.mBigEndian = true;
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/*     */ 
/* 321 */           switch (quartet) {
/*     */           case 60: 
/* 323 */             this.mBigEndian = true;
/* 324 */             this.mBytesPerChar = 4;
/* 325 */             break;
/*     */           case 1006632960: 
/* 327 */             this.mBytesPerChar = 4;
/* 328 */             this.mBigEndian = false;
/* 329 */             break;
/*     */           case 15360: 
/* 331 */             reportWeirdUCS4("2143");
/* 332 */             break;
/*     */           case 3932160: 
/* 334 */             reportWeirdUCS4("3412");
/* 335 */             break;
/*     */           case 3932223: 
/* 337 */             this.mBytesPerChar = 2;
/* 338 */             this.mBigEndian = true;
/* 339 */             break;
/*     */           case 1006649088: 
/* 341 */             this.mBytesPerChar = 2;
/* 342 */             this.mBigEndian = false;
/* 343 */             break;
/*     */           case 1010792557: 
/* 345 */             this.mBytesPerChar = 1;
/* 346 */             this.mBigEndian = true;
/* 347 */             break;
/*     */           
/*     */           case 1282385812: 
/* 350 */             this.mBytesPerChar = -1;
/* 351 */             this.mEBCDIC = true;
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 358 */             this.mSingleByteTranslation = EBCDICCodec.getCp037Mapping(); } }
/* 359 */         break;
/*     */       }
/*     */       
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 367 */       this.mHadBOM = (this.mInputPtr > 0);
/*     */       
/*     */ 
/* 370 */       this.mInputProcessed = (-this.mInputPtr);
/* 371 */       this.mInputRowStart = this.mInputPtr;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 377 */     this.mByteSizeFound = (this.mBytesPerChar != 0);
/* 378 */     if (!this.mByteSizeFound) {
/* 379 */       this.mBytesPerChar = 1;
/* 380 */       this.mBigEndian = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String verifyXmlEncoding(String enc)
/*     */     throws WstxException
/*     */   {
/* 390 */     enc = CharsetNames.normalize(enc);
/*     */     
/*     */ 
/* 393 */     if (enc == "UTF-8") {
/* 394 */       verifyEncoding(enc, 1);
/* 395 */     } else if (enc == "ISO-8859-1") {
/* 396 */       verifyEncoding(enc, 1);
/* 397 */     } else if (enc == "US-ASCII") {
/* 398 */       verifyEncoding(enc, 1);
/* 399 */     } else if (enc == "UTF-16")
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 409 */       verifyEncoding(enc, 2);
/* 410 */     } else if (enc == "UTF-16LE") {
/* 411 */       verifyEncoding(enc, 2, false);
/* 412 */     } else if (enc == "UTF-16BE") {
/* 413 */       verifyEncoding(enc, 2, true);
/*     */     }
/* 415 */     else if (enc == "UTF-32")
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 420 */       verifyEncoding(enc, 4);
/* 421 */     } else if (enc == "UTF-32LE") {
/* 422 */       verifyEncoding(enc, 4, false);
/* 423 */     } else if (enc == "UTF-32BE") {
/* 424 */       verifyEncoding(enc, 4, true);
/*     */     }
/* 426 */     return enc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean ensureLoaded(int minimum)
/*     */     throws IOException
/*     */   {
/* 441 */     int gotten = this.mInputLen - this.mInputPtr;
/* 442 */     while (gotten < minimum) {
/* 443 */       int count = this.mIn.read(this.mByteBuffer, this.mInputLen, this.mByteBuffer.length - this.mInputLen);
/*     */       
/* 445 */       if (count < 1) {
/* 446 */         return false;
/*     */       }
/* 448 */       this.mInputLen += count;
/* 449 */       gotten += count;
/*     */     }
/* 451 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void loadMore()
/*     */     throws IOException, WstxException
/*     */   {
/* 464 */     this.mInputProcessed += this.mInputLen;
/* 465 */     this.mInputRowStart -= this.mInputLen;
/*     */     
/* 467 */     this.mInputPtr = 0;
/* 468 */     this.mInputLen = this.mIn.read(this.mByteBuffer, 0, this.mByteBuffer.length);
/* 469 */     if (this.mInputLen < 1) {
/* 470 */       throw new WstxEOFException(" in xml declaration", getLocation());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void pushback()
/*     */   {
/* 482 */     if (this.mBytesPerChar < 0) {
/* 483 */       this.mInputPtr += this.mBytesPerChar;
/*     */     } else {
/* 485 */       this.mInputPtr -= this.mBytesPerChar;
/*     */     }
/*     */   }
/*     */   
/*     */   protected int getNext()
/*     */     throws IOException, WstxException
/*     */   {
/* 492 */     if (this.mBytesPerChar != 1) {
/* 493 */       if (this.mBytesPerChar == -1) {
/* 494 */         return nextTranslated();
/*     */       }
/* 496 */       return nextMultiByte();
/*     */     }
/* 498 */     byte b = this.mInputPtr < this.mInputLen ? this.mByteBuffer[(this.mInputPtr++)] : nextByte();
/*     */     
/* 500 */     return b & 0xFF;
/*     */   }
/*     */   
/*     */ 
/*     */   protected int getNextAfterWs(boolean reqWs)
/*     */     throws IOException, WstxException
/*     */   {
/*     */     int count;
/*     */     int count;
/* 509 */     if (this.mBytesPerChar == 1) {
/* 510 */       count = skipSbWs();
/*     */     } else { int count;
/* 512 */       if (this.mBytesPerChar == -1) {
/* 513 */         count = skipTranslatedWs();
/*     */       } else {
/* 515 */         count = skipMbWs();
/*     */       }
/*     */     }
/*     */     
/* 519 */     if ((reqWs) && (count == 0)) {
/* 520 */       reportUnexpectedChar(getNext(), "; expected a white space");
/*     */     }
/*     */     
/*     */ 
/* 524 */     if (this.mBytesPerChar != 1) {
/* 525 */       if (this.mBytesPerChar == -1) {
/* 526 */         return nextTranslated();
/*     */       }
/* 528 */       return nextMultiByte();
/*     */     }
/* 530 */     byte b = this.mInputPtr < this.mInputLen ? this.mByteBuffer[(this.mInputPtr++)] : nextByte();
/*     */     
/* 532 */     return b & 0xFF;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int checkKeyword(String exp)
/*     */     throws IOException, WstxException
/*     */   {
/* 542 */     if (this.mBytesPerChar != 1) {
/* 543 */       if (this.mBytesPerChar == -1) {
/* 544 */         return checkTranslatedKeyword(exp);
/*     */       }
/* 546 */       return checkMbKeyword(exp);
/*     */     }
/* 548 */     return checkSbKeyword(exp);
/*     */   }
/*     */   
/*     */   protected int readQuotedValue(char[] kw, int quoteChar)
/*     */     throws IOException, WstxException
/*     */   {
/* 554 */     int i = 0;
/* 555 */     int len = kw.length;
/* 556 */     boolean simple = this.mBytesPerChar == 1;
/* 557 */     boolean mb = (!simple) && (this.mBytesPerChar > 1);
/*     */     
/* 559 */     while (i < len) {
/*     */       int c;
/*     */       int c;
/* 562 */       if (simple) {
/* 563 */         byte b = this.mInputPtr < this.mInputLen ? this.mByteBuffer[(this.mInputPtr++)] : nextByte();
/*     */         
/* 565 */         if (b == 0) {
/* 566 */           reportNull();
/*     */         }
/* 568 */         if ((b == 13) || (b == 10)) {
/* 569 */           skipSbLF(b);
/* 570 */           b = 10;
/*     */         }
/* 572 */         c = b & 0xFF;
/*     */       }
/* 574 */       else if (mb) {
/* 575 */         int c = nextMultiByte();
/* 576 */         if ((c == 13) || (c == 10)) {
/* 577 */           skipMbLF(c);
/* 578 */           c = 10;
/*     */         }
/*     */       } else {
/* 581 */         c = nextTranslated();
/* 582 */         if ((c == 13) || (c == 10)) {
/* 583 */           skipTranslatedLF(c);
/* 584 */           c = 10;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 589 */       if (c == quoteChar) {
/* 590 */         return i < len ? i : -1;
/*     */       }
/*     */       
/* 593 */       if (i < len) {
/* 594 */         kw[(i++)] = ((char)c);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 601 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean hasXmlDecl()
/*     */     throws IOException, WstxException
/*     */   {
/* 610 */     if (this.mBytesPerChar == 1)
/*     */     {
/*     */ 
/*     */ 
/* 614 */       if ((ensureLoaded(6)) && 
/* 615 */         (this.mByteBuffer[this.mInputPtr] == 60) && (this.mByteBuffer[(this.mInputPtr + 1)] == 63) && (this.mByteBuffer[(this.mInputPtr + 2)] == 120) && (this.mByteBuffer[(this.mInputPtr + 3)] == 109) && (this.mByteBuffer[(this.mInputPtr + 4)] == 108) && ((this.mByteBuffer[(this.mInputPtr + 5)] & 0xFF) <= 32))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 623 */         this.mInputPtr += 6;
/* 624 */         return true;
/*     */       }
/*     */     }
/* 627 */     else if (this.mBytesPerChar == -1) {
/* 628 */       if (ensureLoaded(6)) {
/* 629 */         int start = this.mInputPtr;
/* 630 */         if ((nextTranslated() == 60) && (nextTranslated() == 63) && (nextTranslated() == 120) && (nextTranslated() == 109) && (nextTranslated() == 108) && (nextTranslated() <= 32))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 636 */           return true;
/*     */         }
/* 638 */         this.mInputPtr = start;
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */     }
/* 644 */     else if (ensureLoaded(6 * this.mBytesPerChar)) {
/* 645 */       int start = this.mInputPtr;
/* 646 */       if ((nextMultiByte() == 60) && (nextMultiByte() == 63) && (nextMultiByte() == 120) && (nextMultiByte() == 109) && (nextMultiByte() == 108) && (nextMultiByte() <= 32))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 652 */         return true;
/*     */       }
/* 654 */       this.mInputPtr = start;
/*     */     }
/*     */     
/*     */ 
/* 658 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Location getLocation()
/*     */   {
/* 668 */     int total = this.mInputProcessed + this.mInputPtr;
/* 669 */     int col = this.mInputPtr - this.mInputRowStart;
/*     */     
/* 671 */     if (this.mBytesPerChar > 1) {
/* 672 */       total /= this.mBytesPerChar;
/* 673 */       col /= this.mBytesPerChar;
/*     */     }
/*     */     
/* 676 */     return new WstxInputLocation(null, this.mPublicId, this.mSystemId, total - 1, this.mInputRow, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected byte nextByte()
/*     */     throws IOException, WstxException
/*     */   {
/* 690 */     if (this.mInputPtr >= this.mInputLen) {
/* 691 */       loadMore();
/*     */     }
/* 693 */     return this.mByteBuffer[(this.mInputPtr++)];
/*     */   }
/*     */   
/*     */   protected int skipSbWs()
/*     */     throws IOException, WstxException
/*     */   {
/* 699 */     int count = 0;
/*     */     for (;;)
/*     */     {
/* 702 */       byte b = this.mInputPtr < this.mInputLen ? this.mByteBuffer[(this.mInputPtr++)] : nextByte();
/*     */       
/*     */ 
/* 705 */       if ((b & 0xFF) > 32) {
/* 706 */         this.mInputPtr -= 1;
/* 707 */         break;
/*     */       }
/* 709 */       if ((b == 13) || (b == 10)) {
/* 710 */         skipSbLF(b);
/* 711 */       } else if (b == 0) {
/* 712 */         reportNull();
/*     */       }
/* 714 */       count++;
/*     */     }
/* 716 */     return count;
/*     */   }
/*     */   
/*     */   protected void skipSbLF(byte lfByte)
/*     */     throws IOException, WstxException
/*     */   {
/* 722 */     if (lfByte == 13) {
/* 723 */       byte b = this.mInputPtr < this.mInputLen ? this.mByteBuffer[(this.mInputPtr++)] : nextByte();
/*     */       
/* 725 */       if (b != 10) {
/* 726 */         this.mInputPtr -= 1;
/*     */       }
/*     */     }
/* 729 */     this.mInputRow += 1;
/* 730 */     this.mInputRowStart = this.mInputPtr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int checkSbKeyword(String expected)
/*     */     throws IOException, WstxException
/*     */   {
/* 740 */     int len = expected.length();
/*     */     
/* 742 */     for (int ptr = 1; ptr < len; ptr++) {
/* 743 */       byte b = this.mInputPtr < this.mInputLen ? this.mByteBuffer[(this.mInputPtr++)] : nextByte();
/*     */       
/*     */ 
/* 746 */       if (b == 0) {
/* 747 */         reportNull();
/*     */       }
/* 749 */       if ((b & 0xFF) != expected.charAt(ptr)) {
/* 750 */         return b & 0xFF;
/*     */       }
/*     */     }
/*     */     
/* 754 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int nextMultiByte()
/*     */     throws IOException, WstxException
/*     */   {
/* 766 */     byte b = this.mInputPtr < this.mInputLen ? this.mByteBuffer[(this.mInputPtr++)] : nextByte();
/*     */     
/* 768 */     byte b2 = this.mInputPtr < this.mInputLen ? this.mByteBuffer[(this.mInputPtr++)] : nextByte();
/*     */     
/*     */     int c;
/*     */     int c;
/* 772 */     if (this.mBytesPerChar == 2) { int c;
/* 773 */       if (this.mBigEndian) {
/* 774 */         c = (b & 0xFF) << 8 | b2 & 0xFF;
/*     */       } else {
/* 776 */         c = b & 0xFF | (b2 & 0xFF) << 8;
/*     */       }
/*     */     }
/*     */     else {
/* 780 */       byte b3 = this.mInputPtr < this.mInputLen ? this.mByteBuffer[(this.mInputPtr++)] : nextByte();
/*     */       
/* 782 */       byte b4 = this.mInputPtr < this.mInputLen ? this.mByteBuffer[(this.mInputPtr++)] : nextByte();
/*     */       
/*     */       int c;
/* 785 */       if (this.mBigEndian) {
/* 786 */         c = b << 24 | (b2 & 0xFF) << 16 | (b3 & 0xFF) << 8 | b4 & 0xFF;
/*     */       }
/*     */       else {
/* 789 */         c = b4 << 24 | (b3 & 0xFF) << 16 | (b2 & 0xFF) << 8 | b & 0xFF;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 795 */     if (c == 0) {
/* 796 */       reportNull();
/*     */     }
/* 798 */     return c;
/*     */   }
/*     */   
/*     */   protected int nextTranslated()
/*     */     throws IOException, WstxException
/*     */   {
/* 804 */     byte b = this.mInputPtr < this.mInputLen ? this.mByteBuffer[(this.mInputPtr++)] : nextByte();
/*     */     
/* 806 */     int ch = this.mSingleByteTranslation[(b & 0xFF)];
/* 807 */     if (ch < 0) {
/* 808 */       ch = -ch;
/*     */     }
/* 810 */     return ch;
/*     */   }
/*     */   
/*     */   protected int skipMbWs()
/*     */     throws IOException, WstxException
/*     */   {
/* 816 */     int count = 0;
/*     */     for (;;)
/*     */     {
/* 819 */       int c = nextMultiByte();
/*     */       
/* 821 */       if (c > 32) {
/* 822 */         this.mInputPtr -= this.mBytesPerChar;
/* 823 */         break;
/*     */       }
/* 825 */       if ((c == 13) || (c == 10)) {
/* 826 */         skipMbLF(c);
/* 827 */       } else if (c == 0) {
/* 828 */         reportNull();
/*     */       }
/* 830 */       count++;
/*     */     }
/* 832 */     return count;
/*     */   }
/*     */   
/*     */   protected int skipTranslatedWs()
/*     */     throws IOException, WstxException
/*     */   {
/* 838 */     int count = 0;
/*     */     for (;;)
/*     */     {
/* 841 */       int c = nextTranslated();
/*     */       
/*     */ 
/* 844 */       if ((c > 32) && (c != 133)) {
/* 845 */         this.mInputPtr -= 1;
/* 846 */         break;
/*     */       }
/* 848 */       if ((c == 13) || (c == 10)) {
/* 849 */         skipTranslatedLF(c);
/* 850 */       } else if (c == 0) {
/* 851 */         reportNull();
/*     */       }
/* 853 */       count++;
/*     */     }
/* 855 */     return count;
/*     */   }
/*     */   
/*     */   protected void skipMbLF(int lf)
/*     */     throws IOException, WstxException
/*     */   {
/* 861 */     if (lf == 13) {
/* 862 */       int c = nextMultiByte();
/* 863 */       if (c != 10) {
/* 864 */         this.mInputPtr -= this.mBytesPerChar;
/*     */       }
/*     */     }
/* 867 */     this.mInputRow += 1;
/* 868 */     this.mInputRowStart = this.mInputPtr;
/*     */   }
/*     */   
/*     */   protected void skipTranslatedLF(int lf)
/*     */     throws IOException, WstxException
/*     */   {
/* 874 */     if (lf == 13) {
/* 875 */       int c = nextTranslated();
/* 876 */       if (c != 10) {
/* 877 */         this.mInputPtr -= 1;
/*     */       }
/*     */     }
/* 880 */     this.mInputRow += 1;
/* 881 */     this.mInputRowStart = this.mInputPtr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int checkMbKeyword(String expected)
/*     */     throws IOException, WstxException
/*     */   {
/* 891 */     int len = expected.length();
/*     */     
/* 893 */     for (int ptr = 1; ptr < len; ptr++) {
/* 894 */       int c = nextMultiByte();
/* 895 */       if (c == 0) {
/* 896 */         reportNull();
/*     */       }
/* 898 */       if (c != expected.charAt(ptr)) {
/* 899 */         return c;
/*     */       }
/*     */     }
/*     */     
/* 903 */     return 0;
/*     */   }
/*     */   
/*     */   protected int checkTranslatedKeyword(String expected)
/*     */     throws IOException, WstxException
/*     */   {
/* 909 */     int len = expected.length();
/*     */     
/* 911 */     for (int ptr = 1; ptr < len; ptr++) {
/* 912 */       int c = nextTranslated();
/* 913 */       if (c == 0) {
/* 914 */         reportNull();
/*     */       }
/* 916 */       if (c != expected.charAt(ptr)) {
/* 917 */         return c;
/*     */       }
/*     */     }
/*     */     
/* 921 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void verifyEncoding(String id, int bpc)
/*     */     throws WstxException
/*     */   {
/* 933 */     if (this.mByteSizeFound)
/*     */     {
/*     */ 
/*     */ 
/* 937 */       if (bpc != this.mBytesPerChar)
/*     */       {
/* 939 */         if (this.mEBCDIC) {
/* 940 */           reportXmlProblem("Declared encoding '" + id + "' incompatible with auto-detected physical encoding (EBCDIC variant), can not decode input since actual code page not known");
/*     */         }
/* 942 */         reportXmlProblem("Declared encoding '" + id + "' uses " + bpc + " bytes per character; but physical encoding appeared to use " + this.mBytesPerChar + "; cannot decode");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void verifyEncoding(String id, int bpc, boolean bigEndian)
/*     */     throws WstxException
/*     */   {
/* 951 */     if (this.mByteSizeFound) {
/* 952 */       verifyEncoding(id, bpc);
/*     */       
/* 954 */       if (bigEndian != this.mBigEndian) {
/* 955 */         String bigStr = bigEndian ? "big" : "little";
/* 956 */         reportXmlProblem("Declared encoding '" + id + "' has different endianness (" + bigStr + " endian) than what physical ordering appeared to be; cannot decode");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void reportWeirdUCS4(String type)
/*     */     throws IOException
/*     */   {
/* 966 */     throw new CharConversionException("Unsupported UCS-4 endianness (" + type + ") detected");
/*     */   }
/*     */   
/*     */   private void reportMissingBOM(String enc)
/*     */     throws WstxException
/*     */   {
/* 972 */     throw new WstxException("Missing BOM for encoding '" + enc + "'; can not be omitted", getLocation());
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\io\StreamBootstrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */