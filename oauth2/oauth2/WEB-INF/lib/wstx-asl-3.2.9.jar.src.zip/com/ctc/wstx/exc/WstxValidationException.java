/*     */ package com.ctc.wstx.exc;
/*     */ 
/*     */ import com.ctc.wstx.util.StringUtil;
/*     */ import javax.xml.stream.Location;
/*     */ import org.codehaus.stax2.validation.XMLValidationException;
/*     */ import org.codehaus.stax2.validation.XMLValidationProblem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WstxValidationException
/*     */   extends XMLValidationException
/*     */ {
/*     */   protected WstxValidationException(XMLValidationProblem cause, String msg)
/*     */   {
/*  33 */     super(cause, msg);
/*     */   }
/*     */   
/*     */ 
/*     */   protected WstxValidationException(XMLValidationProblem cause, String msg, Location loc)
/*     */   {
/*  39 */     super(cause, msg, loc);
/*     */   }
/*     */   
/*     */ 
/*     */   public static WstxValidationException create(String msg, Location loc, int severity)
/*     */   {
/*  45 */     return create(new XMLValidationProblem(loc, msg, severity));
/*     */   }
/*     */   
/*     */ 
/*     */   public static WstxValidationException create(XMLValidationProblem cause)
/*     */   {
/*  51 */     Location loc = cause.getLocation();
/*  52 */     if (loc == null) {
/*  53 */       return new WstxValidationException(cause, cause.getMessage());
/*     */     }
/*  55 */     return new WstxValidationException(cause, cause.getMessage(), loc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage()
/*     */   {
/*  72 */     String locMsg = getLocationDesc();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  77 */     if (locMsg == null) {
/*  78 */       return super.getMessage();
/*     */     }
/*  80 */     String msg = getValidationProblem().getMessage();
/*  81 */     StringBuffer sb = new StringBuffer(msg.length() + locMsg.length() + 20);
/*  82 */     sb.append(msg);
/*  83 */     StringUtil.appendLF(sb);
/*  84 */     sb.append(" at ");
/*  85 */     sb.append(locMsg);
/*  86 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  91 */     return getClass().getName() + ": " + getMessage();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getLocationDesc()
/*     */   {
/* 102 */     Location loc = getLocation();
/* 103 */     return loc == null ? null : loc.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\exc\WstxValidationException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */