/*     */ package com.ctc.wstx.io;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import java.io.CharConversionException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AsciiReader
/*     */   extends BaseReader
/*     */ {
/*  32 */   boolean mXml11 = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  38 */   int mCharCount = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AsciiReader(ReaderConfig cfg, InputStream in, byte[] buf, int ptr, int len)
/*     */   {
/*  48 */     super(cfg, in, buf, ptr, len);
/*     */   }
/*     */   
/*     */   public void setXmlCompliancy(int xmlVersion)
/*     */   {
/*  53 */     this.mXml11 = (xmlVersion == 272);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(char[] cbuf, int start, int len)
/*     */     throws IOException
/*     */   {
/*  66 */     if (this.mBuffer == null) {
/*  67 */       return -1;
/*     */     }
/*     */     
/*  70 */     if ((start < 0) || (start + len > cbuf.length)) {
/*  71 */       reportBounds(cbuf, start, len);
/*     */     }
/*     */     
/*     */ 
/*  75 */     int avail = this.mLength - this.mPtr;
/*  76 */     if (avail <= 0)
/*     */     {
/*  78 */       int count = this.mIn.read(this.mBuffer);
/*  79 */       if (count <= 0) {
/*  80 */         if (count == 0) {
/*  81 */           reportStrangeStream();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*  86 */         freeBuffers();
/*  87 */         return -1;
/*     */       }
/*  89 */       this.mLength = (avail = count);
/*  90 */       this.mCharCount += count;
/*  91 */       this.mPtr = 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  96 */     if (len > avail) {
/*  97 */       len = avail;
/*     */     }
/*  99 */     int i = this.mPtr;
/* 100 */     int last = i + len;
/*     */     
/* 102 */     while (i < last) {
/* 103 */       char c = (char)this.mBuffer[(i++)];
/* 104 */       if (c >= '') {
/* 105 */         if (c > '') {
/* 106 */           reportInvalidAscii(c);
/*     */         }
/* 108 */         else if (this.mXml11) {
/* 109 */           int pos = this.mCharCount + this.mPtr;
/* 110 */           reportInvalidXml11(c, pos, pos);
/*     */         }
/*     */       }
/*     */       
/* 114 */       cbuf[(start++)] = c;
/*     */     }
/*     */     
/* 117 */     this.mPtr = last;
/* 118 */     return len;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void reportInvalidAscii(char c)
/*     */     throws IOException
/*     */   {
/* 130 */     throw new CharConversionException("Invalid ascii byte; value above 7-bit ascii range (" + c + "; at pos #" + (this.mCharCount + this.mPtr) + ")");
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\io\AsciiReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */