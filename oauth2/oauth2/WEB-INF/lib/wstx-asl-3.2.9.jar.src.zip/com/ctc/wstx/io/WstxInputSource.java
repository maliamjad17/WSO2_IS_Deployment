/*     */ package com.ctc.wstx.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class WstxInputSource
/*     */ {
/*     */   protected final WstxInputSource mParent;
/*     */   final String mFromEntity;
/*  52 */   int mScopeId = 0;
/*     */   
/*     */   protected WstxInputSource(WstxInputSource parent, String fromEntity)
/*     */   {
/*  56 */     this.mParent = parent;
/*  57 */     this.mFromEntity = fromEntity;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final WstxInputSource getParent()
/*     */   {
/*  67 */     return this.mParent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isOrIsExpandedFrom(String entityId)
/*     */   {
/*  80 */     if (entityId != null) {
/*  81 */       WstxInputSource curr = this;
/*  82 */       while (curr != null) {
/*  83 */         if (entityId == curr.mFromEntity) {
/*  84 */           return true;
/*     */         }
/*  86 */         curr = curr.mParent;
/*     */       }
/*     */     }
/*  89 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean fromInternalEntity();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract URL getSource();
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract String getPublicId();
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract String getSystemId();
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract WstxInputLocation getLocation();
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract WstxInputLocation getLocation(long paramLong, int paramInt1, int paramInt2);
/*     */   
/*     */ 
/*     */ 
/* 120 */   public String getEntityId() { return this.mFromEntity; }
/*     */   
/* 122 */   public int getScopeId() { return this.mScopeId; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void initInputLocation(WstxInputData reader, int currScopeId)
/*     */   {
/* 140 */     this.mScopeId = currScopeId;
/* 141 */     doInitInputLocation(reader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void doInitInputLocation(WstxInputData paramWstxInputData);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int readInto(WstxInputData paramWstxInputData)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean readMore(WstxInputData paramWstxInputData, int paramInt)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void saveContext(WstxInputData paramWstxInputData);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void restoreContext(WstxInputData paramWstxInputData);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void close()
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void closeCompletely()
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 206 */     StringBuffer sb = new StringBuffer(80);
/* 207 */     sb.append("<WstxInputSource [class ");
/* 208 */     sb.append(getClass().toString());
/* 209 */     sb.append("]; systemId: ");
/* 210 */     sb.append(getSystemId());
/* 211 */     sb.append(", source: ");
/* 212 */     sb.append(getSource());
/* 213 */     sb.append('>');
/* 214 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\io\WstxInputSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */