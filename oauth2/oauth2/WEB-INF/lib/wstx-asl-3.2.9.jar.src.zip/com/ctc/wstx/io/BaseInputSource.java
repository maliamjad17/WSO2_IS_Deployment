/*     */ package com.ctc.wstx.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseInputSource
/*     */   extends WstxInputSource
/*     */ {
/*     */   final String mPublicId;
/*     */   final String mSystemId;
/*     */   final URL mSource;
/*     */   protected char[] mBuffer;
/*     */   protected int mInputLen;
/*  50 */   long mSavedInputProcessed = 0L;
/*     */   
/*  52 */   int mSavedInputRow = 1;
/*  53 */   int mSavedInputRowStart = 0;
/*     */   
/*  55 */   int mSavedInputPtr = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  63 */   transient WstxInputLocation mParentLocation = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BaseInputSource(WstxInputSource parent, String fromEntity, String publicId, String systemId, URL src)
/*     */   {
/*  73 */     super(parent, fromEntity);
/*  74 */     this.mSystemId = systemId;
/*  75 */     this.mPublicId = publicId;
/*  76 */     this.mSource = src;
/*     */   }
/*     */   
/*     */   public abstract boolean fromInternalEntity();
/*     */   
/*     */   public URL getSource() {
/*  82 */     return this.mSource;
/*     */   }
/*     */   
/*     */   public String getPublicId() {
/*  86 */     return this.mPublicId;
/*     */   }
/*     */   
/*     */   public String getSystemId() {
/*  90 */     return this.mSystemId;
/*     */   }
/*     */   
/*     */ 
/*     */   protected abstract void doInitInputLocation(WstxInputData paramWstxInputData);
/*     */   
/*     */   public abstract int readInto(WstxInputData paramWstxInputData)
/*     */     throws IOException;
/*     */   
/*     */   public abstract boolean readMore(WstxInputData paramWstxInputData, int paramInt)
/*     */     throws IOException;
/*     */   
/*     */   public void saveContext(WstxInputData reader)
/*     */   {
/* 104 */     this.mSavedInputPtr = reader.mInputPtr;
/*     */     
/*     */ 
/* 107 */     this.mSavedInputProcessed = reader.mCurrInputProcessed;
/* 108 */     this.mSavedInputRow = reader.mCurrInputRow;
/* 109 */     this.mSavedInputRowStart = reader.mCurrInputRowStart;
/*     */   }
/*     */   
/*     */   public void restoreContext(WstxInputData reader)
/*     */   {
/* 114 */     reader.mInputBuffer = this.mBuffer;
/* 115 */     reader.mInputLen = this.mInputLen;
/* 116 */     reader.mInputPtr = this.mSavedInputPtr;
/*     */     
/*     */ 
/* 119 */     reader.mCurrInputProcessed = this.mSavedInputProcessed;
/* 120 */     reader.mCurrInputRow = this.mSavedInputRow;
/* 121 */     reader.mCurrInputRowStart = this.mSavedInputRowStart;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void close()
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final WstxInputLocation getLocation()
/*     */   {
/* 139 */     return getLocation(this.mSavedInputProcessed + this.mSavedInputPtr - 1L, this.mSavedInputRow, this.mSavedInputPtr - this.mSavedInputRowStart + 1);
/*     */   }
/*     */   
/*     */ 
/*     */   public final WstxInputLocation getLocation(long total, int row, int col)
/*     */   {
/*     */     WstxInputLocation pl;
/*     */     
/*     */     WstxInputLocation pl;
/* 148 */     if (this.mParent == null) {
/* 149 */       pl = null;
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 154 */       pl = this.mParentLocation;
/* 155 */       if (pl == null) {
/* 156 */         this.mParentLocation = (pl = this.mParent.getLocation());
/*     */       }
/* 158 */       pl = this.mParent.getLocation();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 164 */     return new WstxInputLocation(pl, getPublicId(), getSystemId(), (int)total, row, col);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\io\BaseInputSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */