/*    */ package com.ctc.wstx.evt;
/*    */ 
/*    */ import java.io.Writer;
/*    */ import javax.xml.stream.Location;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import javax.xml.stream.XMLStreamWriter;
/*    */ import javax.xml.stream.events.EndDocument;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WEndDocument
/*    */   extends WEvent
/*    */   implements EndDocument
/*    */ {
/*    */   public WEndDocument(Location loc)
/*    */   {
/* 17 */     super(loc);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getEventType()
/*    */   {
/* 27 */     return 8;
/*    */   }
/*    */   
/*    */   public boolean isEndDocument() {
/* 31 */     return true;
/*    */   }
/*    */   
/*    */   public void writeAsEncodedUnicode(Writer w)
/*    */     throws XMLStreamException
/*    */   {}
/*    */   
/*    */   public void writeUsing(XMLStreamWriter w)
/*    */     throws XMLStreamException
/*    */   {
/* 41 */     w.writeEndDocument();
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\evt\WEndDocument.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */