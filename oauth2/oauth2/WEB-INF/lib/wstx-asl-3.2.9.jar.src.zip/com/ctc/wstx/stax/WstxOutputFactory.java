/*     */ package com.ctc.wstx.stax;
/*     */ 
/*     */ import com.ctc.wstx.api.WriterConfig;
/*     */ import com.ctc.wstx.cfg.OutputConfigFlags;
/*     */ import com.ctc.wstx.dom.DOMWrappingWriter;
/*     */ import com.ctc.wstx.evt.WstxEventWriter;
/*     */ import com.ctc.wstx.exc.WstxIOException;
/*     */ import com.ctc.wstx.io.CharsetNames;
/*     */ import com.ctc.wstx.io.UTF8Writer;
/*     */ import com.ctc.wstx.sw.AsciiXmlWriter;
/*     */ import com.ctc.wstx.sw.BaseStreamWriter;
/*     */ import com.ctc.wstx.sw.BufferingXmlWriter;
/*     */ import com.ctc.wstx.sw.ISOLatin1XmlWriter;
/*     */ import com.ctc.wstx.sw.NonNsStreamWriter;
/*     */ import com.ctc.wstx.sw.RepairingNsStreamWriter;
/*     */ import com.ctc.wstx.sw.SimpleNsStreamWriter;
/*     */ import com.ctc.wstx.sw.XmlWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import javax.xml.stream.XMLEventWriter;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.dom.DOMResult;
/*     */ import javax.xml.transform.sax.SAXResult;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import org.codehaus.stax2.XMLOutputFactory2;
/*     */ import org.codehaus.stax2.XMLStreamWriter2;
/*     */ import org.codehaus.stax2.io.Stax2Result;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WstxOutputFactory
/*     */   extends XMLOutputFactory2
/*     */   implements OutputConfigFlags
/*     */ {
/*     */   protected final WriterConfig mConfig;
/*     */   
/*     */   public WstxOutputFactory()
/*     */   {
/*  73 */     this.mConfig = WriterConfig.createFullDefaults();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLEventWriter createXMLEventWriter(OutputStream out)
/*     */     throws XMLStreamException
/*     */   {
/*  85 */     return createXMLEventWriter(out, null);
/*     */   }
/*     */   
/*     */   public XMLEventWriter createXMLEventWriter(OutputStream out, String enc)
/*     */     throws XMLStreamException
/*     */   {
/*  91 */     if (out == null) {
/*  92 */       throw new IllegalArgumentException("Null OutputStream is not a valid argument");
/*     */     }
/*  94 */     return new WstxEventWriter(createSW(out, null, enc, false));
/*     */   }
/*     */   
/*     */   public XMLEventWriter createXMLEventWriter(Result result)
/*     */     throws XMLStreamException
/*     */   {
/* 100 */     return new WstxEventWriter(createSW(result));
/*     */   }
/*     */   
/*     */   public XMLEventWriter createXMLEventWriter(Writer w)
/*     */     throws XMLStreamException
/*     */   {
/* 106 */     if (w == null) {
/* 107 */       throw new IllegalArgumentException("Null Writer is not a valid argument");
/*     */     }
/* 109 */     return new WstxEventWriter(createSW(null, w, null, false));
/*     */   }
/*     */   
/*     */   public XMLStreamWriter createXMLStreamWriter(OutputStream out)
/*     */     throws XMLStreamException
/*     */   {
/* 115 */     return createXMLStreamWriter(out, null);
/*     */   }
/*     */   
/*     */   public XMLStreamWriter createXMLStreamWriter(OutputStream out, String enc)
/*     */     throws XMLStreamException
/*     */   {
/* 121 */     if (out == null) {
/* 122 */       throw new IllegalArgumentException("Null OutputStream is not a valid argument");
/*     */     }
/* 124 */     return createSW(out, null, enc, false);
/*     */   }
/*     */   
/*     */   public XMLStreamWriter createXMLStreamWriter(Result result)
/*     */     throws XMLStreamException
/*     */   {
/* 130 */     return createSW(result);
/*     */   }
/*     */   
/*     */   public XMLStreamWriter createXMLStreamWriter(Writer w)
/*     */     throws XMLStreamException
/*     */   {
/* 136 */     if (w == null) {
/* 137 */       throw new IllegalArgumentException("Null Writer is not a valid argument");
/*     */     }
/* 139 */     return createSW(null, w, null, false);
/*     */   }
/*     */   
/*     */   public Object getProperty(String name)
/*     */   {
/* 144 */     return this.mConfig.getProperty(name);
/*     */   }
/*     */   
/*     */   public boolean isPropertySupported(String name) {
/* 148 */     return this.mConfig.isPropertySupported(name);
/*     */   }
/*     */   
/*     */   public void setProperty(String name, Object value)
/*     */   {
/* 153 */     this.mConfig.setProperty(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLEventWriter createXMLEventWriter(Writer w, String enc)
/*     */     throws XMLStreamException
/*     */   {
/* 167 */     return new WstxEventWriter(createSW(null, w, enc, false));
/*     */   }
/*     */   
/*     */   public XMLEventWriter createXMLEventWriter(XMLStreamWriter sw)
/*     */     throws XMLStreamException
/*     */   {
/* 173 */     return new WstxEventWriter(sw);
/*     */   }
/*     */   
/*     */   public XMLStreamWriter2 createXMLStreamWriter(Writer w, String enc)
/*     */     throws XMLStreamException
/*     */   {
/* 179 */     return createSW(null, w, enc, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void configureForXmlConformance()
/*     */   {
/* 186 */     this.mConfig.configureForXmlConformance();
/*     */   }
/*     */   
/*     */   public void configureForRobustness()
/*     */   {
/* 191 */     this.mConfig.configureForRobustness();
/*     */   }
/*     */   
/*     */   public void configureForSpeed()
/*     */   {
/* 196 */     this.mConfig.configureForSpeed();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WriterConfig getConfig()
/*     */   {
/* 206 */     return this.mConfig;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private BaseStreamWriter createSW(OutputStream out, Writer w, String enc, boolean autoCloseOutput)
/*     */     throws XMLStreamException
/*     */   {
/* 230 */     WriterConfig cfg = this.mConfig.createNonShared();
/*     */     
/*     */     XmlWriter xw;
/* 233 */     if (w == null) {
/* 234 */       if (enc == null) {
/* 235 */         enc = "UTF-8";
/*     */       } else {
/* 237 */         enc = CharsetNames.normalize(enc);
/*     */       }
/*     */       try {
/*     */         XmlWriter xw;
/* 241 */         if (enc == "UTF-8")
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 246 */           w = new UTF8Writer(cfg, out, autoCloseOutput);
/* 247 */           xw = new BufferingXmlWriter(w, cfg, enc, true, out); } else { XmlWriter xw;
/* 248 */           if (enc == "ISO-8859-1") {
/* 249 */             xw = new ISOLatin1XmlWriter(out, cfg, autoCloseOutput); } else { XmlWriter xw;
/* 250 */             if (enc == "US-ASCII") {
/* 251 */               xw = new AsciiXmlWriter(out, cfg, autoCloseOutput);
/*     */             } else {
/* 253 */               w = new OutputStreamWriter(out, enc);
/* 254 */               xw = new BufferingXmlWriter(w, cfg, enc, autoCloseOutput, out);
/*     */             }
/*     */           }
/* 257 */         } } catch (IOException ex) { throw new XMLStreamException(ex);
/*     */       }
/*     */     }
/*     */     else {
/* 261 */       if (enc == null) {
/* 262 */         enc = CharsetNames.findEncodingFor(w);
/*     */       }
/*     */       try {
/* 265 */         xw = new BufferingXmlWriter(w, cfg, enc, autoCloseOutput, out);
/*     */       } catch (IOException ex) {
/* 267 */         throw new XMLStreamException(ex);
/*     */       }
/*     */     }
/*     */     
/* 271 */     if (cfg.willSupportNamespaces()) {
/* 272 */       if (cfg.automaticNamespacesEnabled()) {
/* 273 */         return new RepairingNsStreamWriter(xw, enc, cfg);
/*     */       }
/* 275 */       return new SimpleNsStreamWriter(xw, enc, cfg);
/*     */     }
/* 277 */     return new NonNsStreamWriter(xw, enc, cfg);
/*     */   }
/*     */   
/*     */   private XMLStreamWriter createSW(Result res)
/*     */     throws XMLStreamException
/*     */   {
/* 283 */     OutputStream out = null;
/* 284 */     Writer w = null;
/* 285 */     String encoding = null;
/*     */     
/*     */     boolean autoclose;
/* 288 */     if ((res instanceof Stax2Result)) {
/* 289 */       Stax2Result sr = (Stax2Result)res;
/*     */       try {
/* 291 */         out = sr.constructOutputStream();
/* 292 */         if (out == null) {
/* 293 */           w = sr.constructWriter();
/*     */         }
/*     */       } catch (IOException ioe) {
/* 296 */         throw new WstxIOException(ioe);
/*     */       }
/* 298 */       autoclose = true; } else { boolean autoclose;
/* 299 */       if ((res instanceof StreamResult)) {
/* 300 */         StreamResult sr = (StreamResult)res;
/* 301 */         out = sr.getOutputStream();
/* 302 */         if (out == null) {
/* 303 */           w = sr.getWriter();
/*     */         }
/* 305 */         autoclose = false;
/* 306 */       } else { if ((res instanceof SAXResult))
/*     */         {
/*     */ 
/* 309 */           throw new XMLStreamException("Can not create a STaX writer for a SAXResult -- not implemented."); }
/* 310 */         if ((res instanceof DOMResult)) {
/* 311 */           return DOMWrappingWriter.createFrom(this.mConfig.createNonShared(), (DOMResult)res);
/*     */         }
/* 313 */         throw new IllegalArgumentException("Can not instantiate a writer for XML result type " + res.getClass() + " (unrecognized type)");
/*     */       } }
/*     */     boolean autoclose;
/* 316 */     if (out != null) {
/* 317 */       return createSW(out, null, encoding, autoclose);
/*     */     }
/* 319 */     if (w != null) {
/* 320 */       return createSW(null, w, encoding, autoclose);
/*     */     }
/* 322 */     throw new XMLStreamException("Can not create StAX writer for passed-in Result -- neither writer nor output stream was accessible");
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\stax\WstxOutputFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */