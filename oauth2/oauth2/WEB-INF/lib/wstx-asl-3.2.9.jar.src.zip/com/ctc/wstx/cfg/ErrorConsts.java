/*     */ package com.ctc.wstx.cfg;
/*     */ 
/*     */ import javax.xml.stream.XMLStreamConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ErrorConsts
/*     */   implements XMLStreamConstants
/*     */ {
/*  18 */   public static String WT_ENT_DECL = "entity declaration";
/*  19 */   public static String WT_ELEM_DECL = "element declaration";
/*  20 */   public static String WT_ATTR_DECL = "attribute declaration";
/*  21 */   public static String WT_XML_DECL = "xml declaration";
/*  22 */   public static String WT_DT_DECL = "doctype declaration";
/*  23 */   public static String WT_NS_DECL = "namespace declaration";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  29 */   public static String WT_VALIDATION = "schema validation";
/*     */   
/*     */ 
/*     */ 
/*  33 */   public static String W_UNDEFINED_ELEM = "Undefined element \"{0}\"; referred to by attribute(s)";
/*  34 */   public static String W_MIXED_ENCODINGS = "Inconsistent text encoding; declared as \"{0}\" in xml declaration, application had passed \"{1}\"";
/*  35 */   public static String W_MISSING_DTD = "Missing DOCTYPE declaration in validating mode; can not validate elements or attributes";
/*  36 */   public static String W_DTD_DUP_ATTR = "Attribute \"{0}\" (for element <{1}>) declared multiple times";
/*  37 */   public static String W_DTD_ATTR_REDECL = "Attribute \"{0}\" already declared for element <{1}>; ignoring re-declaration";
/*     */   
/*     */ 
/*     */ 
/*  41 */   public static String ERR_INTERNAL = "Internal error";
/*  42 */   public static String ERR_NULL_ARG = "Illegal to pass null as argument";
/*  43 */   public static String ERR_UNKNOWN_FEATURE = "Unrecognized feature \"{1}\"";
/*     */   
/*     */ 
/*     */ 
/*  47 */   public static String ERR_STATE_NOT_STELEM = "Current state not START_ELEMENT";
/*  48 */   public static String ERR_STATE_NOT_ELEM = "Current state not START_ELEMENT or END_ELEMENT";
/*  49 */   public static String ERR_STATE_NOT_PI = "Current state not PROCESSING_INSTRUCTION";
/*     */   
/*     */ 
/*     */ 
/*  53 */   public static String ERR_XML_10_VS_11 = "XML 1.0 document can not refer to XML 1.1 parsed external entities";
/*     */   
/*     */ 
/*     */ 
/*  57 */   public static String ERR_DTD_IN_EPILOG = "Can not have DOCTYPE declaration in epilog";
/*  58 */   public static String ERR_DTD_DUP = "Duplicate DOCTYPE declaration";
/*  59 */   public static String ERR_CDATA_IN_EPILOG = " (CDATA not allowed in prolog/epilog)";
/*     */   
/*     */ 
/*     */ 
/*  63 */   public static String ERR_HYPHENS_IN_COMMENT = "String '--' not allowed in comment (missing '>'?)";
/*  64 */   public static String ERR_BRACKET_IN_TEXT = "String ']]>' not allowed in textual content, except as the end marker of CDATA section";
/*     */   
/*     */ 
/*     */ 
/*  68 */   public static String ERR_UNEXP_KEYWORD = "Unexpected keyword \"{0}\"; expected \"{1}\"";
/*     */   
/*  70 */   public static String ERR_WF_PI_MISSING_TARGET = "Missing processing instruction target";
/*  71 */   public static String ERR_WF_PI_XML_TARGET = "Illegal processing instruction target (\"{0}\"); 'xml' (case insensitive) is reserved by the specs.";
/*  72 */   public static String ERR_WF_PI_XML_MISSING_SPACE = "excepted either space or \"?>\" after PI target";
/*     */   
/*     */ 
/*     */ 
/*  76 */   public static String ERR_WF_ENTITY_EXT_DECLARED = "Entity \"{0}\" declared externally, but referenced from a document declared 'standalone=\"yes\"'";
/*     */   
/*  78 */   public static String ERR_WF_GE_UNDECLARED = "Undeclared general entity \"{0}\"";
/*     */   
/*  80 */   public static String ERR_WF_GE_UNDECLARED_SA = "Undeclared general entity \"{0}\" (document in stand-alone mode; perhaps declared externally?)";
/*     */   
/*     */ 
/*     */ 
/*  84 */   public static String ERR_NS_UNDECLARED = "Undeclared namespace prefix \"{0}\"";
/*  85 */   public static String ERR_NS_UNDECLARED_FOR_ATTR = "Undeclared namespace prefix \"{0}\" (for attribute \"{1}\")";
/*     */   
/*  87 */   public static String ERR_NS_REDECL_XML = "Trying to redeclare prefix 'xml' from its default URI 'http://www.w3.org/XML/1998/namespace' to \"{0}\"";
/*     */   
/*     */ 
/*     */ 
/*  91 */   public static String ERR_NS_REDECL_XMLNS = "Trying to declare prefix 'xmlns' (illegal as per NS 1.1 #4)";
/*     */   
/*  93 */   public static String ERR_NS_REDECL_XML_URI = "Trying to bind URI 'http://www.w3.org/XML/1998/namespace to prefix \"{0}\" (can only bind to 'xml')";
/*     */   
/*     */ 
/*  96 */   public static String ERR_NS_REDECL_XMLNS_URI = "Trying to bind URI 'http://www.w3.org/2000/xmlns/ to prefix \"{0}\" (can not be explicitly bound)";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */   public static String ERR_DTD_MAINLEVEL_KEYWORD = "; expected a keyword (ATTLIST, ELEMENT, ENTITY, NOTATION), comment, or conditional section";
/*     */   
/* 104 */   public static String ERR_DTD_ATTR_TYPE = "; expected one of type (CDATA, ID, IDREF, IDREFS, ENTITY, ENTITIES NOTATION, NMTOKEN or NMTOKENS)";
/*     */   
/* 106 */   public static String ERR_DTD_DEFAULT_TYPE = "; expected #REQUIRED, #IMPLIED or #FIXED";
/*     */   
/* 108 */   public static String ERR_DTD_ELEM_REDEFD = "Trying to redefine element \"{0}\" (originally defined at {1})";
/*     */   
/* 110 */   public static String ERR_DTD_NOTATION_REDEFD = "Trying to redefine notation \"{0}\" (originally defined at {1})";
/*     */   
/*     */ 
/* 113 */   public static String ERR_DTD_UNDECLARED_ENTITY = "Undeclared {0} entity \"{1}\"";
/*     */   
/*     */ 
/* 116 */   public static String ERR_DTD_XML_SPACE = "Attribute xml:space has to be defined of type enumerated, and have 1 or 2 values, 'default' and/or 'preserve'";
/*     */   
/* 118 */   public static String ERR_DTD_XML_ID = "Attribute xml:id has to have attribute type of ID, as per Xml:id specification";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 123 */   public static String ERR_VLD_UNKNOWN_ELEM = "Undefined element <{0}> encountered";
/*     */   
/* 125 */   public static String ERR_VLD_EMPTY = "Element <{0}> has EMPTY content specification; can not contain {1}";
/* 126 */   public static String ERR_VLD_NON_MIXED = "Element <{0}> has non-mixed content specification; can not contain non-white space text, or any CDATA sections";
/* 127 */   public static String ERR_VLD_ANY = "Element <{0}> has ANY content specification; can not contain {1}";
/* 128 */   public static String ERR_VLD_UNKNOWN_ATTR = "Element <{0}> has no attribute \"{1}\"";
/* 129 */   public static String ERR_VLD_WRONG_ROOT = "Unexpected root element <{0}>; expected <{0}> as per DOCTYPE declaration";
/*     */   
/*     */ 
/*     */ 
/* 133 */   public static String ERR_NS_EMPTY = "Non-default namespace can not map to empty URI (as per Namespace 1.0 # 2) in XML 1.0 documents";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 138 */   public static String WERR_PROLOG_CDATA = "Trying to output a CDATA block outside main element tree (in prolog or epilog)";
/*     */   
/* 140 */   public static String WERR_PROLOG_NONWS_TEXT = "Trying to output non-whitespace characters outside main element tree (in prolog or epilog)";
/*     */   
/* 142 */   public static String WERR_PROLOG_SECOND_ROOT = "Trying to output second root, <{0}>";
/*     */   
/*     */ 
/* 145 */   public static String WERR_CDATA_CONTENT = "Illegal input: CDATA block has embedded ']]>' in it (index {0})";
/*     */   
/* 147 */   public static String WERR_COMMENT_CONTENT = "Illegal input: comment content has embedded '--' in it (index {0})";
/*     */   
/*     */ 
/* 150 */   public static String WERR_ATTR_NO_ELEM = "Trying to write an attribute when there is no open start element.";
/*     */   
/*     */ 
/* 153 */   public static String WERR_NAME_EMPTY = "Illegal to pass empty name";
/*     */   
/* 155 */   public static String WERR_NAME_ILLEGAL_FIRST_CHAR = "Illegal first name character {0}";
/* 156 */   public static String WERR_NAME_ILLEGAL_CHAR = "Illegal name character {0}";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String tokenTypeDesc(int type)
/*     */   {
/* 166 */     switch (type) {
/*     */     case 1: 
/* 168 */       return "START_ELEMENT";
/*     */     case 2: 
/* 170 */       return "END_ELEMENT";
/*     */     case 7: 
/* 172 */       return "START_DOCUMENT";
/*     */     case 8: 
/* 174 */       return "END_DOCUMENT";
/*     */     
/*     */     case 4: 
/* 177 */       return "CHARACTERS";
/*     */     case 12: 
/* 179 */       return "CDATA";
/*     */     case 6: 
/* 181 */       return "SPACE";
/*     */     
/*     */     case 5: 
/* 184 */       return "COMMENT";
/*     */     case 3: 
/* 186 */       return "PROCESSING_INSTRUCTION";
/*     */     case 11: 
/* 188 */       return "DTD";
/*     */     case 9: 
/* 190 */       return "ENTITY_REFERENCE";
/*     */     }
/* 192 */     return "[" + type + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\cfg\ErrorConsts.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */