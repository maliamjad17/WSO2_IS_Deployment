package com.ctc.wstx.cfg;

public abstract interface XmlConsts
{
  public static final String XML_DECL_KW_ENCODING = "encoding";
  public static final String XML_DECL_KW_VERSION = "version";
  public static final String XML_DECL_KW_STANDALONE = "standalone";
  public static final String XML_V_10_STR = "1.0";
  public static final String XML_V_11_STR = "1.1";
  public static final int XML_V_UNKNOWN = 0;
  public static final int XML_V_10 = 256;
  public static final int XML_V_11 = 272;
  public static final String XML_SA_YES = "yes";
  public static final String XML_SA_NO = "no";
  public static final int MAX_UNICODE_CHAR = 1114111;
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\cfg\XmlConsts.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */