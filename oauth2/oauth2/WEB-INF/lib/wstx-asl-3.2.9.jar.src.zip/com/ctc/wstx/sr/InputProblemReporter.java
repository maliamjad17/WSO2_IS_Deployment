package com.ctc.wstx.sr;

import javax.xml.stream.Location;
import javax.xml.stream.XMLStreamException;
import org.codehaus.stax2.validation.XMLValidationException;
import org.codehaus.stax2.validation.XMLValidationProblem;

public abstract interface InputProblemReporter
{
  public abstract void throwParseError(String paramString)
    throws XMLStreamException;
  
  public abstract void throwParseError(String paramString, Object paramObject)
    throws XMLStreamException;
  
  public abstract void throwParseError(String paramString, Object paramObject1, Object paramObject2)
    throws XMLStreamException;
  
  public abstract void reportProblem(String paramString1, String paramString2);
  
  public abstract void reportProblem(String paramString1, String paramString2, Object paramObject);
  
  public abstract void reportProblem(String paramString1, String paramString2, Object paramObject1, Object paramObject2);
  
  public abstract void reportProblem(String paramString1, String paramString2, Object paramObject1, Object paramObject2, Location paramLocation);
  
  public abstract void reportValidationProblem(XMLValidationProblem paramXMLValidationProblem)
    throws XMLValidationException;
  
  public abstract void reportValidationProblem(String paramString)
    throws XMLValidationException;
  
  public abstract void reportValidationProblem(String paramString, Location paramLocation, int paramInt)
    throws XMLValidationException;
  
  public abstract void reportValidationProblem(String paramString, Object paramObject)
    throws XMLValidationException;
  
  public abstract void reportValidationProblem(String paramString, Object paramObject1, Object paramObject2)
    throws XMLValidationException;
  
  public abstract Location getLocation();
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sr\InputProblemReporter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */