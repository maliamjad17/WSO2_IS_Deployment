/*     */ package com.ctc.wstx.io;
/*     */ 
/*     */ import java.net.URL;
/*     */ import javax.xml.stream.Location;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CharArraySource
/*     */   extends BaseInputSource
/*     */ {
/*     */   int mOffset;
/*     */   int mInputPtr;
/*     */   final Location mContentStart;
/*     */   
/*     */   CharArraySource(WstxInputSource parent, String fromEntity, char[] chars, int offset, int len, Location loc, URL src)
/*     */   {
/*  29 */     super(parent, fromEntity, loc.getPublicId(), loc.getSystemId(), src);
/*  30 */     this.mBuffer = chars;
/*  31 */     this.mOffset = offset;
/*  32 */     this.mInputLen = (offset + len);
/*  33 */     this.mContentStart = loc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fromInternalEntity()
/*     */   {
/*  41 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doInitInputLocation(WstxInputData reader)
/*     */   {
/*  50 */     reader.mCurrInputProcessed = this.mContentStart.getCharacterOffset();
/*  51 */     reader.mCurrInputRow = this.mContentStart.getLineNumber();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  56 */     reader.mCurrInputRowStart = (-this.mContentStart.getColumnNumber() + 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int readInto(WstxInputData reader)
/*     */   {
/*  64 */     if (this.mBuffer == null) {
/*  65 */       return -1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  73 */     int len = this.mInputLen - this.mOffset;
/*  74 */     if (len < 1) {
/*  75 */       return -1;
/*     */     }
/*  77 */     reader.mInputBuffer = this.mBuffer;
/*  78 */     reader.mInputPtr = this.mOffset;
/*  79 */     reader.mInputLen = this.mInputLen;
/*     */     
/*  81 */     this.mOffset = this.mInputLen;
/*  82 */     return len;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean readMore(WstxInputData reader, int minAmount)
/*     */   {
/*  91 */     if (reader.mInputPtr >= reader.mInputLen) {
/*  92 */       int len = this.mInputLen - this.mOffset;
/*  93 */       if (len >= minAmount) {
/*  94 */         return readInto(reader) > 0;
/*     */       }
/*     */     }
/*  97 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */   {
/* 105 */     this.mBuffer = null;
/*     */   }
/*     */   
/*     */   public void closeCompletely() {
/* 109 */     close();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\io\CharArraySource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */