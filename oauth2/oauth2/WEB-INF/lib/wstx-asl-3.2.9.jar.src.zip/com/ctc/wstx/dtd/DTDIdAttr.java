/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ import com.ctc.wstx.cfg.ErrorConsts;
/*     */ import com.ctc.wstx.io.WstxInputData;
/*     */ import com.ctc.wstx.sr.InputProblemReporter;
/*     */ import javax.xml.stream.Location;
/*     */ import org.codehaus.stax2.validation.XMLValidationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DTDIdAttr
/*     */   extends DTDAttribute
/*     */ {
/*     */   public DTDIdAttr(NameKey name, DefaultAttrValue defValue, int specIndex, boolean nsAware, boolean xml11)
/*     */   {
/*  37 */     super(name, defValue, specIndex, nsAware, xml11);
/*     */   }
/*     */   
/*     */   public DTDAttribute cloneWith(int specIndex)
/*     */   {
/*  42 */     return new DTDIdAttr(this.mName, this.mDefValue, specIndex, this.mCfgNsAware, this.mCfgXml11);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getValueType()
/*     */   {
/*  52 */     return 2;
/*     */   }
/*     */   
/*     */   public boolean typeIsId() {
/*  56 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validate(DTDValidatorBase v, char[] cbuf, int start, int end, boolean normalize)
/*     */     throws XMLValidationException
/*     */   {
/*  74 */     while ((start < end) && (WstxInputData.isSpaceChar(cbuf[start]))) {
/*  75 */       start++;
/*     */     }
/*     */     
/*     */ 
/*  79 */     if (start >= end) {
/*  80 */       return reportValidationProblem(v, "Empty ID value");
/*     */     }
/*  82 */     end--;
/*  83 */     while ((end > start) && (WstxInputData.isSpaceChar(cbuf[end]))) {
/*  84 */       end--;
/*     */     }
/*     */     
/*     */ 
/*  88 */     char c = cbuf[start];
/*  89 */     if (!WstxInputData.isNameStartChar(c, this.mCfgNsAware, this.mCfgXml11)) {
/*  90 */       return reportInvalidChar(v, c, "not valid as the first ID character");
/*     */     }
/*  92 */     int hash = c;
/*  93 */     for (int i = start + 1; i <= end; i++) {
/*  94 */       c = cbuf[i];
/*  95 */       if (!WstxInputData.isNameChar(c, this.mCfgNsAware, this.mCfgXml11)) {
/*  96 */         return reportInvalidChar(v, c, "not valid as an ID character");
/*     */       }
/*  98 */       hash = hash * 31 + c;
/*     */     }
/*     */     
/*     */ 
/* 102 */     ElementIdMap m = v.getIdMap();
/* 103 */     NameKey elemName = v.getElemName();
/* 104 */     Location loc = v.getLocation();
/* 105 */     ElementId id = m.addDefined(cbuf, start, end - start + 1, hash, loc, elemName, this.mName);
/*     */     
/*     */ 
/*     */ 
/* 109 */     if (id.getLocation() != loc) {
/* 110 */       return reportValidationProblem(v, "Duplicate id '" + id.getId() + "', first declared at " + id.getLocation());
/*     */     }
/*     */     
/*     */ 
/* 114 */     if (normalize) {
/* 115 */       return id.getId();
/*     */     }
/* 117 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validateDefault(InputProblemReporter rep, boolean normalize)
/*     */     throws XMLValidationException
/*     */   {
/* 129 */     throw new Error(ErrorConsts.ERR_INTERNAL);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\DTDIdAttr.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */