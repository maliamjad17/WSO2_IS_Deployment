/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ import com.ctc.wstx.ent.EntityDecl;
/*     */ import com.ctc.wstx.io.WstxInputData;
/*     */ import com.ctc.wstx.sr.InputProblemReporter;
/*     */ import org.codehaus.stax2.validation.XMLValidationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DTDEntityAttr
/*     */   extends DTDAttribute
/*     */ {
/*     */   public DTDEntityAttr(NameKey name, DefaultAttrValue defValue, int specIndex, boolean nsAware, boolean xml11)
/*     */   {
/*  36 */     super(name, defValue, specIndex, nsAware, xml11);
/*     */   }
/*     */   
/*     */   public DTDAttribute cloneWith(int specIndex)
/*     */   {
/*  41 */     return new DTDEntityAttr(this.mName, this.mDefValue, specIndex, this.mCfgNsAware, this.mCfgXml11);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getValueType()
/*     */   {
/*  51 */     return 5;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validate(DTDValidatorBase v, char[] cbuf, int start, int end, boolean normalize)
/*     */     throws XMLValidationException
/*     */   {
/*  68 */     while ((start < end) && (WstxInputData.isSpaceChar(cbuf[start]))) {
/*  69 */       start++;
/*     */     }
/*     */     
/*     */ 
/*  73 */     if (start >= end) {
/*  74 */       return reportValidationProblem(v, "Empty ENTITY value");
/*     */     }
/*  76 */     end--;
/*  77 */     while ((end > start) && (WstxInputData.isSpaceChar(cbuf[end]))) {
/*  78 */       end--;
/*     */     }
/*     */     
/*     */ 
/*  82 */     char c = cbuf[start];
/*  83 */     if ((!WstxInputData.isNameStartChar(c, this.mCfgNsAware, this.mCfgXml11)) && (c != ':')) {
/*  84 */       return reportInvalidChar(v, c, "not valid as the first ID character");
/*     */     }
/*  86 */     int hash = c;
/*     */     
/*  88 */     for (int i = start + 1; i <= end; i++) {
/*  89 */       c = cbuf[i];
/*  90 */       if (!WstxInputData.isNameChar(c, this.mCfgNsAware, this.mCfgXml11)) {
/*  91 */         return reportInvalidChar(v, c, "not valid as an ID character");
/*     */       }
/*  93 */       hash = hash * 31 + c;
/*     */     }
/*     */     
/*  96 */     EntityDecl ent = findEntityDecl(v, cbuf, start, end - start + 1, hash);
/*     */     
/*     */ 
/*  99 */     return normalize ? ent.getName() : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validateDefault(InputProblemReporter rep, boolean normalize)
/*     */     throws XMLValidationException
/*     */   {
/* 110 */     String normStr = validateDefaultName(rep, normalize);
/* 111 */     if (normalize) {
/* 112 */       this.mDefValue.setValue(normStr);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 121 */     EntityDecl ent = ((MinimalDTDReader)rep).findEntity(normStr);
/* 122 */     checkEntity(rep, normStr, ent);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\DTDEntityAttr.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */