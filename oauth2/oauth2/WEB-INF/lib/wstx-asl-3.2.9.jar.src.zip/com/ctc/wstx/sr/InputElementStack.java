/*     */ package com.ctc.wstx.sr;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import com.ctc.wstx.dtd.DTDValidatorBase;
/*     */ import com.ctc.wstx.util.BaseNsContext;
/*     */ import com.ctc.wstx.util.StringUtil;
/*     */ import com.ctc.wstx.util.TextBuffer;
/*     */ import com.ctc.wstx.util.TextBuilder;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.codehaus.stax2.AttributeInfo;
/*     */ import org.codehaus.stax2.validation.ValidationContext;
/*     */ import org.codehaus.stax2.validation.ValidatorPair;
/*     */ import org.codehaus.stax2.validation.XMLValidationException;
/*     */ import org.codehaus.stax2.validation.XMLValidationProblem;
/*     */ import org.codehaus.stax2.validation.XMLValidationSchema;
/*     */ import org.codehaus.stax2.validation.XMLValidator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class InputElementStack
/*     */   implements AttributeInfo, NamespaceContext, ValidationContext
/*     */ {
/*     */   static final int ID_ATTR_NONE = -1;
/*     */   protected final ReaderConfig mConfig;
/*  62 */   protected InputProblemReporter mReporter = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  76 */   protected XMLValidator mValidator = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */   protected int mIdAttrIndex = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected InputElementStack(ReaderConfig cfg)
/*     */   {
/*  93 */     this.mConfig = cfg;
/*     */   }
/*     */   
/*     */   protected void connectReporter(InputProblemReporter rep)
/*     */   {
/*  98 */     this.mReporter = rep;
/*     */   }
/*     */   
/*     */   protected XMLValidator addValidator(XMLValidator vld)
/*     */   {
/* 103 */     if (this.mValidator == null) {
/* 104 */       this.mValidator = vld;
/*     */     } else {
/* 106 */       this.mValidator = new ValidatorPair(this.mValidator, vld);
/*     */     }
/* 108 */     return vld;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void setAutomaticDTDValidator(XMLValidator paramXMLValidator, NsDefaultProvider paramNsDefaultProvider);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLValidator validateAgainst(XMLValidationSchema schema)
/*     */     throws XMLStreamException
/*     */   {
/* 132 */     return addValidator(schema.createValidator(this));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public XMLValidator stopValidatingAgainst(XMLValidationSchema schema)
/*     */     throws XMLStreamException
/*     */   {
/* 140 */     XMLValidator[] results = new XMLValidator[2];
/* 141 */     if (ValidatorPair.removeValidator(this.mValidator, schema, results)) {
/* 142 */       XMLValidator found = results[0];
/* 143 */       this.mValidator = results[1];
/* 144 */       found.validationCompleted(false);
/* 145 */       return found;
/*     */     }
/* 147 */     return null;
/*     */   }
/*     */   
/*     */   public XMLValidator stopValidatingAgainst(XMLValidator validator)
/*     */     throws XMLStreamException
/*     */   {
/* 153 */     XMLValidator[] results = new XMLValidator[2];
/* 154 */     if (ValidatorPair.removeValidator(this.mValidator, validator, results)) {
/* 155 */       XMLValidator found = results[0];
/* 156 */       this.mValidator = results[1];
/* 157 */       found.validationCompleted(false);
/* 158 */       return found;
/*     */     }
/* 160 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean reallyValidating()
/*     */   {
/* 186 */     if (this.mValidator == null)
/*     */     {
/* 188 */       return false;
/*     */     }
/* 190 */     if (!(this.mValidator instanceof DTDValidatorBase))
/*     */     {
/* 192 */       return true;
/*     */     }
/* 194 */     return ((DTDValidatorBase)this.mValidator).reallyValidating();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract AttributeCollector getAttrCollector();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract BaseNsContext createNonTransientNsContext(Location paramLocation);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void push(String paramString1, String paramString2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void push(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int pop()
/*     */     throws XMLStreamException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int resolveAndValidateElement()
/*     */     throws XMLStreamException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int getAttributeCount();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int findAttributeIndex(String paramString1, String paramString2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getIdAttributeIndex()
/*     */   {
/* 268 */     if (this.mIdAttrIndex >= 0) {
/* 269 */       return this.mIdAttrIndex;
/*     */     }
/* 271 */     return this.mValidator == null ? -1 : this.mValidator.getIdAttrIndex();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getNotationAttributeIndex()
/*     */   {
/* 281 */     return this.mValidator == null ? -1 : this.mValidator.getNotationAttrIndex();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String getNamespaceURI(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String getPrefix(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Iterator getPrefixes(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getXmlVersion()
/*     */   {
/* 305 */     return this.mConfig.isXml11() ? "1.1" : "1.0";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getAttributeLocalName(int index)
/*     */   {
/* 312 */     return getAttrCollector().getLocalName(index);
/*     */   }
/*     */   
/*     */   public String getAttributeNamespace(int index) {
/* 316 */     return getAttrCollector().getURI(index);
/*     */   }
/*     */   
/*     */   public String getAttributePrefix(int index) {
/* 320 */     return getAttrCollector().getPrefix(index);
/*     */   }
/*     */   
/*     */   public String getAttributeValue(int index) {
/* 324 */     return getAttrCollector().getValue(index);
/*     */   }
/*     */   
/*     */   public String getAttributeValue(String nsURI, String localName)
/*     */   {
/* 329 */     int ix = findAttributeIndex(nsURI, localName);
/* 330 */     return ix < 0 ? null : getAttributeValue(ix);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isNotationDeclared(String name)
/*     */   {
/* 339 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isUnparsedEntityDeclared(String name)
/*     */   {
/* 345 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getBaseUri()
/*     */   {
/* 351 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract QName getCurrentElementName();
/*     */   
/*     */ 
/*     */   public Location getValidationLocation()
/*     */   {
/* 361 */     return this.mReporter.getLocation();
/*     */   }
/*     */   
/*     */   public void reportProblem(XMLValidationProblem problem)
/*     */     throws XMLValidationException
/*     */   {
/* 367 */     this.mReporter.reportValidationProblem(problem);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int addDefaultAttribute(String paramString1, String paramString2, String paramString3, String paramString4);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean isPrefixLocallyDeclared(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void addNsBinding(String paramString1, String paramString2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void validateText(TextBuffer tb, boolean lastTextSegment)
/*     */     throws XMLValidationException
/*     */   {
/* 402 */     tb.validateText(this.mValidator, lastTextSegment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean isNamespaceAware();
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract int getDepth();
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract boolean isEmpty();
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract String getDefaultNsURI();
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract String getNsURI();
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract String getPrefix();
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract String getLocalName();
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract boolean matches(String paramString1, String paramString2);
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract String getTopElementDesc();
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract int getTotalNsCount();
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract int getCurrentNsCount();
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract String getLocalNsPrefix(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract String getLocalNsURI(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */   public final String getAttributeType(int index)
/*     */   {
/* 462 */     if ((index == this.mIdAttrIndex) && (index >= 0)) {
/* 463 */       return "ID";
/*     */     }
/* 465 */     return this.mValidator == null ? "CDATA" : this.mValidator.getAttributeType(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void normalizeXmlIdAttr(AttributeCollector ac, int ix)
/*     */   {
/* 482 */     TextBuilder attrBuilder = ac.getAttrBuilder();
/* 483 */     char[] attrCB = attrBuilder.getCharBuffer();
/* 484 */     String normValue = StringUtil.normalizeSpaces(attrCB, attrBuilder.getOffset(ix), attrBuilder.getOffset(ix + 1));
/*     */     
/*     */ 
/* 487 */     if (normValue != null) {
/* 488 */       ac.setNormalizedValue(ix, normValue);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sr\InputElementStack.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */