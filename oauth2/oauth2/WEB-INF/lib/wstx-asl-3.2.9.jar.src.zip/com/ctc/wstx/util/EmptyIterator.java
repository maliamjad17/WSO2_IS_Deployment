/*    */ package com.ctc.wstx.util;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class EmptyIterator
/*    */   implements Iterator
/*    */ {
/* 13 */   static final String[] sNoStrings = new String[0];
/* 14 */   static final char[] sNoChars = new char[0];
/* 15 */   static final int[] sNoInts = new int[0];
/*    */   
/* 17 */   static final EmptyIterator sInstance = new EmptyIterator();
/*    */   
/*    */ 
/*    */   public static EmptyIterator getInstance()
/*    */   {
/* 22 */     return sInstance;
/*    */   }
/*    */   
/* 25 */   public boolean hasNext() { return false; }
/*    */   
/*    */   public Object next() {
/* 28 */     throw new NoSuchElementException();
/*    */   }
/*    */   
/*    */   public void remove()
/*    */   {
/* 33 */     throw new IllegalStateException();
/*    */   }
/*    */   
/*    */   public static final String[] getEmptyStringArray() {
/* 37 */     return sNoStrings;
/*    */   }
/*    */   
/*    */   public static final int[] getEmptyIntArray() {
/* 41 */     return sNoInts;
/*    */   }
/*    */   
/*    */   public static final char[] getEmptyCharArray() {
/* 45 */     return sNoChars;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\util\EmptyIterator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */