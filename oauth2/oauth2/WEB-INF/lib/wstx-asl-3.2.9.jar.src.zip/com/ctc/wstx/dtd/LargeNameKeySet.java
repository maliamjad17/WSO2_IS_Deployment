/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LargeNameKeySet
/*     */   extends NameKeySet
/*     */ {
/*     */   static final int MIN_HASH_AREA = 8;
/*     */   final boolean mNsAware;
/*     */   final NameKey[] mNames;
/*     */   final Bucket[] mBuckets;
/*     */   
/*     */   public LargeNameKeySet(boolean nsAware, NameKey[] names)
/*     */   {
/*  52 */     this.mNsAware = nsAware;
/*  53 */     int len = names.length;
/*     */     
/*     */ 
/*  56 */     int minSize = len + (len + 7 >> 3);
/*     */     
/*  58 */     int tableSize = 8;
/*     */     
/*  60 */     while (tableSize < minSize) {
/*  61 */       tableSize += tableSize;
/*     */     }
/*     */     
/*  64 */     this.mNames = new NameKey[tableSize];
/*     */     
/*     */ 
/*  67 */     Bucket[] buckets = null;
/*  68 */     int mask = tableSize - 1;
/*     */     
/*  70 */     for (int i = 0; i < len; i++) {
/*  71 */       NameKey nk = names[i];
/*  72 */       int ix = nk.hashCode() & mask;
/*  73 */       if (this.mNames[ix] == null) {
/*  74 */         this.mNames[ix] = nk;
/*     */       } else {
/*  76 */         ix >>= 2;
/*     */         Bucket old;
/*     */         Bucket old;
/*  79 */         if (buckets == null) {
/*  80 */           buckets = new Bucket[tableSize >> 2];
/*  81 */           old = null;
/*     */         } else {
/*  83 */           old = buckets[ix];
/*     */         }
/*  85 */         buckets[ix] = new Bucket(nk, old);
/*     */       }
/*     */     }
/*     */     
/*  89 */     this.mBuckets = buckets;
/*     */   }
/*     */   
/*  92 */   public boolean hasMultiple() { return true; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean contains(NameKey name)
/*     */   {
/*  99 */     NameKey[] hashArea = this.mNames;
/* 100 */     int index = name.hashCode() & hashArea.length - 1;
/* 101 */     NameKey res = hashArea[index];
/*     */     
/* 103 */     if ((res != null) && (res.equals(name))) {
/* 104 */       return true;
/*     */     }
/*     */     
/* 107 */     Bucket[] buckets = this.mBuckets;
/* 108 */     if (buckets != null) {
/* 109 */       for (Bucket bucket = buckets[(index >> 2)]; bucket != null; 
/* 110 */           bucket = bucket.getNext()) {
/* 111 */         res = bucket.getName();
/* 112 */         if (res.equals(name)) {
/* 113 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 117 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void appendNames(StringBuffer sb, String sep)
/*     */   {
/* 127 */     TreeSet ts = new TreeSet();
/* 128 */     for (int i = 0; i < this.mNames.length; i++) {
/* 129 */       NameKey name = this.mNames[i];
/* 130 */       if (name != null) {
/* 131 */         ts.add(name);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 136 */     if (this.mBuckets != null) {
/* 137 */       for (int i = 0; i < this.mNames.length >> 2; i++) {
/* 138 */         Bucket b = this.mBuckets[i];
/* 139 */         while (b != null) {
/* 140 */           ts.add(b.getName());
/* 141 */           b = b.getNext();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 147 */     Iterator it = ts.iterator();
/* 148 */     boolean first = true;
/* 149 */     while (it.hasNext()) {
/* 150 */       if (first) {
/* 151 */         first = false;
/*     */       } else {
/* 153 */         sb.append(sep);
/*     */       }
/* 155 */       sb.append(it.next().toString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final class Bucket
/*     */   {
/*     */     final NameKey mName;
/*     */     
/*     */ 
/*     */     final Bucket mNext;
/*     */     
/*     */ 
/*     */ 
/*     */     public Bucket(NameKey name, Bucket next)
/*     */     {
/* 172 */       this.mName = name;
/* 173 */       this.mNext = next;
/*     */     }
/*     */     
/* 176 */     public NameKey getName() { return this.mName; }
/* 177 */     public Bucket getNext() { return this.mNext; }
/*     */     
/*     */     public boolean contains(NameKey n) {
/* 180 */       return this.mName.equals(n);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\LargeNameKeySet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */