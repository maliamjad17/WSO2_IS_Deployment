/*    */ package com.ctc.wstx.msv;
/*    */ 
/*    */ import com.sun.msv.grammar.trex.TREXGrammar;
/*    */ import com.sun.msv.verifier.regexp.REDocumentDeclaration;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import org.codehaus.stax2.validation.ValidationContext;
/*    */ import org.codehaus.stax2.validation.XMLValidationSchema;
/*    */ import org.codehaus.stax2.validation.XMLValidator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RelaxNGSchema
/*    */   implements XMLValidationSchema
/*    */ {
/*    */   protected final TREXGrammar mGrammar;
/*    */   
/*    */   public RelaxNGSchema(TREXGrammar grammar)
/*    */   {
/* 48 */     this.mGrammar = grammar;
/*    */   }
/*    */   
/*    */   public String getSchemaType() {
/* 52 */     return "http://relaxng.org/ns/structure/0.9";
/*    */   }
/*    */   
/*    */   public XMLValidator createValidator(ValidationContext ctxt)
/*    */     throws XMLStreamException
/*    */   {
/* 58 */     REDocumentDeclaration dd = new REDocumentDeclaration(this.mGrammar);
/* 59 */     return new RelaxNGValidator(this, ctxt, dd);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\msv\RelaxNGSchema.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */