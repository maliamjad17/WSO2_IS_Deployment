/*    */ package com.ctc.wstx.exc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WstxOutputException
/*    */   extends WstxException
/*    */ {
/*    */   public WstxOutputException(String msg)
/*    */   {
/* 15 */     super(msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\exc\WstxOutputException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */