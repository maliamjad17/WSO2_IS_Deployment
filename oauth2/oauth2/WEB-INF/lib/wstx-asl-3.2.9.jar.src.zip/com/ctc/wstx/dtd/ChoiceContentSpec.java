/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ import com.ctc.wstx.util.ExceptionUtil;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChoiceContentSpec
/*     */   extends ContentSpec
/*     */ {
/*     */   final boolean mNsAware;
/*     */   final boolean mHasMixed;
/*     */   final ContentSpec[] mContentSpecs;
/*     */   
/*     */   private ChoiceContentSpec(boolean nsAware, char arity, boolean mixed, ContentSpec[] specs)
/*     */   {
/*  33 */     super(arity);
/*  34 */     this.mNsAware = nsAware;
/*  35 */     this.mHasMixed = mixed;
/*  36 */     this.mContentSpecs = specs;
/*     */   }
/*     */   
/*     */   private ChoiceContentSpec(boolean nsAware, char arity, boolean mixed, Collection specs)
/*     */   {
/*  41 */     super(arity);
/*  42 */     this.mNsAware = nsAware;
/*  43 */     this.mHasMixed = mixed;
/*  44 */     this.mContentSpecs = new ContentSpec[specs.size()];
/*  45 */     specs.toArray(this.mContentSpecs);
/*     */   }
/*     */   
/*     */ 
/*     */   public static ChoiceContentSpec constructChoice(boolean nsAware, char arity, Collection specs)
/*     */   {
/*  51 */     return new ChoiceContentSpec(nsAware, arity, false, specs);
/*     */   }
/*     */   
/*     */   public static ChoiceContentSpec constructMixed(boolean nsAware, Collection specs)
/*     */   {
/*  56 */     return new ChoiceContentSpec(nsAware, '*', true, specs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StructValidator getSimpleValidator()
/*     */   {
/*  71 */     ContentSpec[] specs = this.mContentSpecs;
/*  72 */     int len = specs.length;
/*     */     int i;
/*     */     int i;
/*  75 */     if (this.mHasMixed) {
/*  76 */       i = len;
/*     */     } else {
/*  78 */       for (i = 0; 
/*  79 */           i < len; i++) {
/*  80 */         if (!specs[i].isLeaf()) {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  86 */     if (i == len) {
/*  87 */       NameKeySet keyset = namesetFromSpecs(this.mNsAware, specs);
/*  88 */       return new Validator(this.mArity, keyset);
/*     */     }
/*     */     
/*     */ 
/*  92 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public ModelNode rewrite()
/*     */   {
/*  98 */     ContentSpec[] specs = this.mContentSpecs;
/*  99 */     int len = specs.length;
/* 100 */     ModelNode[] models = new ModelNode[len];
/* 101 */     for (int i = 0; i < len; i++) {
/* 102 */       models[i] = specs[i].rewrite();
/*     */     }
/* 104 */     ChoiceModel model = new ChoiceModel(models);
/*     */     
/*     */ 
/* 107 */     if (this.mArity == '*') {
/* 108 */       return new StarModel(model);
/*     */     }
/* 110 */     if (this.mArity == '?') {
/* 111 */       return new OptionalModel(model);
/*     */     }
/* 113 */     if (this.mArity == '+') {
/* 114 */       return new ConcatModel(model, new StarModel(model.cloneModel()));
/*     */     }
/*     */     
/* 117 */     return model;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 122 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 124 */     if (this.mHasMixed) {
/* 125 */       sb.append("(#PCDATA | ");
/*     */     } else {
/* 127 */       sb.append('(');
/*     */     }
/* 129 */     for (int i = 0; i < this.mContentSpecs.length; i++) {
/* 130 */       if (i > 0) {
/* 131 */         sb.append(" | ");
/*     */       }
/* 133 */       sb.append(this.mContentSpecs[i].toString());
/*     */     }
/* 135 */     sb.append(')');
/*     */     
/* 137 */     if (this.mArity != ' ') {
/* 138 */       sb.append(this.mArity);
/*     */     }
/* 140 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static NameKeySet namesetFromSpecs(boolean nsAware, ContentSpec[] specs)
/*     */   {
/* 157 */     int len = specs.length;
/* 158 */     NameKey[] nameArray = new NameKey[len];
/* 159 */     for (int i = 0; i < len; i++) {
/* 160 */       nameArray[i] = ((TokenContentSpec)specs[i]).getName();
/*     */     }
/*     */     
/* 163 */     if (len < 5) {
/* 164 */       return new SmallNameKeySet(nsAware, nameArray);
/*     */     }
/* 166 */     return new LargeNameKeySet(nsAware, nameArray);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final class Validator
/*     */     extends StructValidator
/*     */   {
/*     */     final char mArity;
/*     */     
/*     */ 
/*     */ 
/*     */     final NameKeySet mNames;
/*     */     
/*     */ 
/* 182 */     int mCount = 0;
/*     */     
/*     */     public Validator(char arity, NameKeySet names)
/*     */     {
/* 186 */       this.mArity = arity;
/* 187 */       this.mNames = names;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public StructValidator newInstance()
/*     */     {
/* 198 */       return this.mArity == '*' ? this : new Validator(this.mArity, this.mNames);
/*     */     }
/*     */     
/*     */     public String tryToValidate(NameKey elemName)
/*     */     {
/* 203 */       if (!this.mNames.contains(elemName)) {
/* 204 */         if (this.mNames.hasMultiple()) {
/* 205 */           return "Expected one of (" + this.mNames.toString(" | ") + ")";
/*     */         }
/* 207 */         return "Expected <" + this.mNames.toString("") + ">";
/*     */       }
/* 209 */       if ((++this.mCount > 1) && ((this.mArity == '?') || (this.mArity == ' '))) {
/* 210 */         if (this.mNames.hasMultiple()) {
/* 211 */           return "Expected $END (already had one of [" + this.mNames.toString(" | ") + "]";
/*     */         }
/*     */         
/* 214 */         return "Expected $END (already had one <" + this.mNames.toString("") + ">]";
/*     */       }
/*     */       
/* 217 */       return null;
/*     */     }
/*     */     
/*     */     public String fullyValid()
/*     */     {
/* 222 */       switch (this.mArity) {
/*     */       case '*': 
/*     */       case '?': 
/* 225 */         return null;
/*     */       case ' ': 
/*     */       case '+': 
/* 228 */         if (this.mCount > 0) {
/* 229 */           return null;
/*     */         }
/* 231 */         return "Expected " + (this.mArity == '+' ? "at least" : "") + " one of elements (" + this.mNames + ")";
/*     */       }
/*     */       
/*     */       
/* 235 */       ExceptionUtil.throwGenericInternal();
/* 236 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\ChoiceContentSpec.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */