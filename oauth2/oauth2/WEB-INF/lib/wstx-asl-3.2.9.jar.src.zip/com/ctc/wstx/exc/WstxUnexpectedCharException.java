/*    */ package com.ctc.wstx.exc;
/*    */ 
/*    */ import javax.xml.stream.Location;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WstxUnexpectedCharException
/*    */   extends WstxParsingException
/*    */ {
/*    */   final char mChar;
/*    */   
/*    */   public WstxUnexpectedCharException(String msg, Location loc, char c)
/*    */   {
/* 18 */     super(msg, loc);
/* 19 */     this.mChar = c;
/*    */   }
/*    */   
/*    */   public char getChar() {
/* 23 */     return this.mChar;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\exc\WstxUnexpectedCharException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */