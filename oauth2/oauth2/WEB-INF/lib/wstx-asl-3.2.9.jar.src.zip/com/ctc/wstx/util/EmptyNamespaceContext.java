/*    */ package com.ctc.wstx.util;
/*    */ 
/*    */ import java.io.Writer;
/*    */ import java.util.Iterator;
/*    */ import javax.xml.stream.XMLStreamWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class EmptyNamespaceContext
/*    */   extends BaseNsContext
/*    */ {
/* 17 */   static final EmptyNamespaceContext sInstance = new EmptyNamespaceContext();
/*    */   
/*    */   public static EmptyNamespaceContext getInstance()
/*    */   {
/* 21 */     return sInstance;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Iterator getNamespaces()
/*    */   {
/* 30 */     return EmptyIterator.getInstance();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void outputNamespaceDeclarations(Writer w) {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void outputNamespaceDeclarations(XMLStreamWriter w) {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String doGetNamespaceURI(String prefix)
/*    */   {
/* 55 */     return null;
/*    */   }
/*    */   
/*    */   public String doGetPrefix(String nsURI) {
/* 59 */     return null;
/*    */   }
/*    */   
/*    */   public Iterator doGetPrefixes(String nsURI) {
/* 63 */     return EmptyIterator.getInstance();
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\util\EmptyNamespaceContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */