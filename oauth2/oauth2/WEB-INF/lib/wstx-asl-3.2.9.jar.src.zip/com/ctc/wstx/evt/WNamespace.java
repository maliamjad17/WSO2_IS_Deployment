/*    */ package com.ctc.wstx.evt;
/*    */ 
/*    */ import javax.xml.stream.Location;
/*    */ import javax.xml.stream.events.Namespace;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WNamespace
/*    */   extends WAttribute
/*    */   implements Namespace
/*    */ {
/*    */   final String mPrefix;
/*    */   final String mURI;
/*    */   
/*    */   public WNamespace(Location loc, String nsURI)
/*    */   {
/* 31 */     super(loc, "xml", "http://www.w3.org/2000/xmlns/", null, nsURI, true);
/*    */     
/*    */ 
/* 34 */     this.mPrefix = "";
/* 35 */     this.mURI = nsURI;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public WNamespace(Location loc, String nsPrefix, String nsURI)
/*    */   {
/* 44 */     super(loc, nsPrefix, "http://www.w3.org/2000/xmlns/", "xmlns", nsURI, true);
/*    */     
/*    */ 
/* 47 */     this.mPrefix = nsPrefix;
/* 48 */     this.mURI = nsURI;
/*    */   }
/*    */   
/*    */   public static WNamespace constructFor(Location loc, String nsPrefix, String nsURI)
/*    */   {
/* 53 */     if ((nsPrefix == null) || (nsPrefix.length() == 0)) {
/* 54 */       return new WNamespace(loc, nsURI);
/*    */     }
/* 56 */     return new WNamespace(loc, nsPrefix, nsURI);
/*    */   }
/*    */   
/*    */   public String getNamespaceURI() {
/* 60 */     return this.mURI;
/*    */   }
/*    */   
/*    */   public String getPrefix() {
/* 64 */     return this.mPrefix;
/*    */   }
/*    */   
/*    */   public boolean isDefaultNamespaceDeclaration() {
/* 68 */     return this.mPrefix.length() == 0;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getEventType()
/*    */   {
/* 78 */     return 13;
/*    */   }
/*    */   
/*    */   public boolean isNamespace() {
/* 82 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\evt\WNamespace.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */