/*    */ package com.ctc.wstx.ent;
/*    */ 
/*    */ import com.ctc.wstx.api.ReaderConfig;
/*    */ import com.ctc.wstx.io.DefaultInputResolver;
/*    */ import com.ctc.wstx.io.WstxInputSource;
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ import java.net.URL;
/*    */ import javax.xml.stream.Location;
/*    */ import javax.xml.stream.XMLResolver;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParsedExtEntity
/*    */   extends ExtEntity
/*    */ {
/*    */   public ParsedExtEntity(Location loc, String name, URL ctxt, String pubId, String sysId)
/*    */   {
/* 26 */     super(loc, name, ctxt, pubId, sysId);
/*    */   }
/*    */   
/*    */   public String getNotationName() {
/* 30 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void writeEnc(Writer w)
/*    */     throws IOException
/*    */   {
/* 41 */     w.write("<!ENTITY ");
/* 42 */     w.write(this.mName);
/* 43 */     String pubId = getPublicId();
/* 44 */     if (pubId != null) {
/* 45 */       w.write("PUBLIC \"");
/* 46 */       w.write(pubId);
/* 47 */       w.write("\" ");
/*    */     } else {
/* 49 */       w.write("SYSTEM ");
/*    */     }
/* 51 */     w.write(34);
/* 52 */     w.write(getSystemId());
/* 53 */     w.write("\">");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isParsed()
/*    */   {
/* 64 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public WstxInputSource expand(WstxInputSource parent, XMLResolver res, ReaderConfig cfg, int xmlVersion)
/*    */     throws IOException, XMLStreamException
/*    */   {
/* 74 */     if (xmlVersion == 0) {
/* 75 */       xmlVersion = 256;
/*    */     }
/* 77 */     return DefaultInputResolver.resolveEntity(parent, this.mContext, this.mName, getPublicId(), getSystemId(), res, cfg, xmlVersion);
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\ent\ParsedExtEntity.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */