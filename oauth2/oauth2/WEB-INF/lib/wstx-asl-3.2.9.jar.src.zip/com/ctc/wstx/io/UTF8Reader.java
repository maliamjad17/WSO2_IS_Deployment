/*     */ package com.ctc.wstx.io;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import java.io.CharConversionException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UTF8Reader
/*     */   extends BaseReader
/*     */ {
/*  32 */   boolean mXml11 = false;
/*     */   
/*  34 */   char mSurrogate = '\000';
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  39 */   int mCharCount = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  44 */   int mByteCount = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UTF8Reader(ReaderConfig cfg, InputStream in, byte[] buf, int ptr, int len)
/*     */   {
/*  54 */     super(cfg, in, buf, ptr, len);
/*     */   }
/*     */   
/*     */   public void setXmlCompliancy(int xmlVersion)
/*     */   {
/*  59 */     this.mXml11 = (xmlVersion == 272);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(char[] cbuf, int start, int len)
/*     */     throws IOException
/*     */   {
/*  72 */     if (this.mBuffer == null) {
/*  73 */       return -1;
/*     */     }
/*  75 */     if (len < 1) {
/*  76 */       return len;
/*     */     }
/*     */     
/*  79 */     if ((start < 0) || (start + len > cbuf.length)) {
/*  80 */       reportBounds(cbuf, start, len);
/*     */     }
/*     */     
/*  83 */     len += start;
/*  84 */     int outPtr = start;
/*     */     
/*     */ 
/*  87 */     if (this.mSurrogate != 0) {
/*  88 */       cbuf[(outPtr++)] = this.mSurrogate;
/*  89 */       this.mSurrogate = '\000';
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*  95 */       int left = this.mLength - this.mPtr;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */       if (left < 4)
/*     */       {
/* 109 */         if (((left < 1) || (this.mBuffer[this.mPtr] < 0)) && 
/* 110 */           (!loadMore(left))) {
/* 111 */           return -1;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 121 */     byte[] buf = this.mBuffer;
/* 122 */     int inPtr = this.mPtr;
/* 123 */     int inBufLen = this.mLength;
/*     */     
/*     */ 
/* 126 */     while (outPtr < len)
/*     */     {
/* 128 */       int c = buf[(inPtr++)];
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 133 */       if (c >= 0) {
/* 134 */         if ((c == 127) && (this.mXml11)) {
/* 135 */           int bytePos = this.mByteCount + inPtr - 1;
/* 136 */           int charPos = this.mCharCount + (outPtr - start);
/* 137 */           reportInvalidXml11(c, bytePos, charPos);
/*     */         }
/* 139 */         cbuf[(outPtr++)] = ((char)c);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 145 */         int outMax = len - outPtr;
/* 146 */         int inMax = inBufLen - inPtr;
/* 147 */         int inEnd = inPtr + (inMax < outMax ? inMax : outMax);
/*     */         
/*     */         for (;;)
/*     */         {
/* 151 */           if (inPtr >= inEnd) {
/*     */             break label906;
/*     */           }
/* 154 */           c = buf[(inPtr++)] & 0xFF;
/* 155 */           if (c >= 127) {
/*     */             break;
/*     */           }
/* 158 */           cbuf[(outPtr++)] = ((char)c);
/*     */         }
/* 160 */         if (c == 127) {
/* 161 */           if (this.mXml11) {
/* 162 */             int bytePos = this.mByteCount + inPtr - 1;
/* 163 */             int charPos = this.mCharCount + (outPtr - start);
/* 164 */             reportInvalidXml11(c, bytePos, charPos);
/*     */           }
/* 166 */           cbuf[(outPtr++)] = ((char)c);
/* 167 */           if (inPtr < inEnd) continue;
/* 168 */           break;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */       int needed;
/*     */       
/*     */       int needed;
/*     */       
/* 177 */       if ((c & 0xE0) == 192) {
/* 178 */         c &= 0x1F;
/* 179 */         needed = 1; } else { int needed;
/* 180 */         if ((c & 0xF0) == 224) {
/* 181 */           c &= 0xF;
/* 182 */           needed = 2; } else { int needed;
/* 183 */           if ((c & 0xF8) == 240)
/*     */           {
/* 185 */             c &= 0xF;
/* 186 */             needed = 3;
/*     */           } else {
/* 188 */             reportInvalidInitial(c & 0xFF, outPtr - start);
/*     */             
/* 190 */             needed = 1;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 197 */       if (inBufLen - inPtr < needed) {
/* 198 */         inPtr--;
/*     */       }
/*     */       else
/*     */       {
/* 202 */         int d = buf[(inPtr++)];
/* 203 */         if ((d & 0xC0) != 128) {
/* 204 */           reportInvalidOther(d & 0xFF, outPtr - start);
/*     */         }
/* 206 */         c = c << 6 | d & 0x3F;
/*     */         
/* 208 */         if (needed > 1) {
/* 209 */           d = buf[(inPtr++)];
/* 210 */           if ((d & 0xC0) != 128) {
/* 211 */             reportInvalidOther(d & 0xFF, outPtr - start);
/*     */           }
/* 213 */           c = c << 6 | d & 0x3F;
/* 214 */           if (needed > 2) {
/* 215 */             d = buf[(inPtr++)];
/* 216 */             if ((d & 0xC0) != 128) {
/* 217 */               reportInvalidOther(d & 0xFF, outPtr - start);
/*     */             }
/* 219 */             c = c << 6 | d & 0x3F;
/* 220 */             if (c > 1114111) {
/* 221 */               reportInvalid(c, outPtr - start, "(above " + Integer.toHexString(1114111) + ") ");
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 228 */             c -= 65536;
/* 229 */             cbuf[(outPtr++)] = ((char)(55296 + (c >> 10)));
/*     */             
/* 231 */             c = 0xDC00 | c & 0x3FF;
/*     */             
/*     */ 
/* 234 */             if (outPtr >= len) {
/* 235 */               this.mSurrogate = ((char)c);
/* 236 */               break;
/*     */ 
/*     */ 
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */           }
/* 244 */           else if (c >= 55296)
/*     */           {
/* 246 */             if (c < 57344) {
/* 247 */               reportInvalid(c, outPtr - start, "(a surrogate character) ");
/* 248 */             } else if (c >= 65534) {
/* 249 */               reportInvalid(c, outPtr - start, "");
/*     */             }
/* 251 */           } else if ((this.mXml11) && (c == 8232))
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 258 */             if ((outPtr > start) && (cbuf[(outPtr - 1)] == '\r')) {
/* 259 */               cbuf[(outPtr - 1)] = '\n';
/*     */             }
/* 261 */             c = 10;
/*     */           }
/*     */           
/*     */         }
/* 265 */         else if ((this.mXml11) && 
/* 266 */           (c <= 159)) {
/* 267 */           if (c == 133) {
/* 268 */             c = 10;
/* 269 */           } else if (c >= 127) {
/* 270 */             int bytePos = this.mByteCount + inPtr - 1;
/* 271 */             int charPos = this.mCharCount + (outPtr - start);
/* 272 */             reportInvalidXml11(c, bytePos, charPos);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 277 */         cbuf[(outPtr++)] = ((char)c);
/* 278 */         if (inPtr >= inBufLen)
/*     */           break;
/*     */       }
/*     */     }
/*     */     label906:
/* 283 */     this.mPtr = inPtr;
/* 284 */     len = outPtr - start;
/* 285 */     this.mCharCount += len;
/* 286 */     return len;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void reportInvalidInitial(int mask, int offset)
/*     */     throws IOException
/*     */   {
/* 299 */     int bytePos = this.mByteCount + this.mPtr - 1;
/* 300 */     int charPos = this.mCharCount + offset + 1;
/*     */     
/* 302 */     throw new CharConversionException("Invalid UTF-8 start byte 0x" + Integer.toHexString(mask) + " (at char #" + charPos + ", byte #" + bytePos + ")");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void reportInvalidOther(int mask, int offset)
/*     */     throws IOException
/*     */   {
/* 310 */     int bytePos = this.mByteCount + this.mPtr - 1;
/* 311 */     int charPos = this.mCharCount + offset;
/*     */     
/* 313 */     throw new CharConversionException("Invalid UTF-8 middle byte 0x" + Integer.toHexString(mask) + " (at char #" + charPos + ", byte #" + bytePos + ")");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void reportUnexpectedEOF(int gotBytes, int needed)
/*     */     throws IOException
/*     */   {
/* 321 */     int bytePos = this.mByteCount + gotBytes;
/* 322 */     int charPos = this.mCharCount;
/*     */     
/* 324 */     throw new CharConversionException("Unexpected EOF in the middle of a multi-byte char: got " + gotBytes + ", needed " + needed + ", at char #" + charPos + ", byte #" + bytePos + ")");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void reportInvalid(int value, int offset, String msg)
/*     */     throws IOException
/*     */   {
/* 332 */     int bytePos = this.mByteCount + this.mPtr - 1;
/* 333 */     int charPos = this.mCharCount + offset;
/*     */     
/* 335 */     throw new CharConversionException("Invalid UTF-8 character 0x" + Integer.toHexString(value) + msg + " at char #" + charPos + ", byte #" + bytePos + ")");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean loadMore(int available)
/*     */     throws IOException
/*     */   {
/* 349 */     this.mByteCount += this.mLength - available;
/*     */     
/*     */ 
/* 352 */     if (available > 0) {
/* 353 */       if (this.mPtr > 0) {
/* 354 */         for (int i = 0; i < available; i++) {
/* 355 */           this.mBuffer[i] = this.mBuffer[(this.mPtr + i)];
/*     */         }
/* 357 */         this.mPtr = 0;
/*     */       }
/* 359 */       this.mLength = available;
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 364 */       this.mPtr = 0;
/* 365 */       int count = this.mIn.read(this.mBuffer);
/* 366 */       if (count < 1) {
/* 367 */         this.mLength = 0;
/* 368 */         if (count < 0) {
/* 369 */           freeBuffers();
/* 370 */           return false;
/*     */         }
/*     */         
/* 373 */         reportStrangeStream();
/*     */       }
/* 375 */       this.mLength = count;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 381 */     int c = this.mBuffer[0];
/* 382 */     if (c >= 0) {
/* 383 */       return true;
/*     */     }
/*     */     
/*     */     int needed;
/*     */     int needed;
/* 388 */     if ((c & 0xE0) == 192) {
/* 389 */       needed = 2; } else { int needed;
/* 390 */       if ((c & 0xF0) == 224) {
/* 391 */         needed = 3; } else { int needed;
/* 392 */         if ((c & 0xF8) == 240)
/*     */         {
/* 394 */           needed = 4;
/*     */         } else {
/* 396 */           reportInvalidInitial(c & 0xFF, 0);
/*     */           
/* 398 */           needed = 1;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 405 */     while (this.mLength < needed) {
/* 406 */       int count = this.mIn.read(this.mBuffer, this.mLength, this.mBuffer.length - this.mLength);
/* 407 */       if (count < 1) {
/* 408 */         if (count < 0) {
/* 409 */           freeBuffers();
/* 410 */           reportUnexpectedEOF(this.mLength, needed);
/*     */         }
/*     */         
/* 413 */         reportStrangeStream();
/*     */       }
/* 415 */       this.mLength += count;
/*     */     }
/* 417 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\io\UTF8Reader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */