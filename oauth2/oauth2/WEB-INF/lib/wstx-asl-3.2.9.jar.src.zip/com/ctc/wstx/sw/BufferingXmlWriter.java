/*      */ package com.ctc.wstx.sw;
/*      */ 
/*      */ import com.ctc.wstx.api.WriterConfig;
/*      */ import com.ctc.wstx.io.CharsetNames;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Writer;
/*      */ import javax.xml.stream.XMLStreamConstants;
/*      */ import javax.xml.stream.XMLStreamException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class BufferingXmlWriter
/*      */   extends XmlWriter
/*      */   implements XMLStreamConstants
/*      */ {
/*      */   static final int DEFAULT_BUFFER_SIZE = 1000;
/*      */   static final int DEFAULT_SMALL_SIZE = 256;
/*      */   protected static final int HIGHEST_ENCODABLE_ATTR_CHAR = 60;
/*      */   protected static final int HIGHEST_ENCODABLE_TEXT_CHAR = 62;
/*      */   protected Writer mOut;
/*      */   protected char[] mOutputBuffer;
/*      */   protected final int mSmallWriteSize;
/*      */   protected int mOutputPtr;
/*      */   protected int mOutputBufLen;
/*      */   protected OutputStream mUnderlyingStream;
/*      */   private final int mEncHighChar;
/*      */   final char mEncQuoteChar;
/*      */   final String mEncQuoteEntity;
/*      */   
/*      */   public BufferingXmlWriter(Writer out, WriterConfig cfg, String enc, boolean autoclose, OutputStream outs)
/*      */     throws IOException
/*      */   {
/*  144 */     super(cfg, enc, autoclose);
/*  145 */     this.mOut = out;
/*  146 */     this.mOutputBuffer = cfg.allocFullCBuffer(1000);
/*  147 */     this.mOutputBufLen = this.mOutputBuffer.length;
/*  148 */     this.mSmallWriteSize = 256;
/*  149 */     this.mOutputPtr = 0;
/*      */     
/*  151 */     this.mUnderlyingStream = outs;
/*      */     
/*      */ 
/*  154 */     this.mEncQuoteChar = '"';
/*  155 */     this.mEncQuoteEntity = "&quot;";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  160 */     int bitsize = guessEncodingBitSize(enc);
/*  161 */     this.mEncHighChar = (bitsize < 16 ? 1 << bitsize : 65534);
/*      */   }
/*      */   
/*      */   protected int getOutputPtr() {
/*  165 */     return this.mOutputPtr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final OutputStream getOutputStream()
/*      */   {
/*  176 */     return this.mUnderlyingStream;
/*      */   }
/*      */   
/*      */   protected final Writer getWriter()
/*      */   {
/*  181 */     return this.mOut;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws IOException
/*      */   {
/*  193 */     if (this.mOut != null) {
/*  194 */       flush();
/*  195 */       Writer w = this.mOut;
/*  196 */       this.mOut = null;
/*  197 */       this.mUnderlyingStream = null;
/*  198 */       this.mTextWriter = null;
/*  199 */       this.mAttrValueWriter = null;
/*  200 */       char[] buf = this.mOutputBuffer;
/*  201 */       this.mOutputBuffer = null;
/*  202 */       this.mConfig.freeFullCBuffer(buf);
/*  203 */       if (this.mAutoCloseOutput) {
/*  204 */         w.close();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public final void flush()
/*      */     throws IOException
/*      */   {
/*  212 */     if (this.mOut != null) {
/*  213 */       flushBuffer();
/*  214 */       this.mOut.flush();
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeRaw(char[] cbuf, int offset, int len)
/*      */     throws IOException
/*      */   {
/*  221 */     if (this.mOut == null) {
/*  222 */       return;
/*      */     }
/*      */     
/*      */ 
/*  226 */     if (len < this.mSmallWriteSize)
/*      */     {
/*  228 */       if (this.mOutputPtr + len > this.mOutputBufLen) {
/*  229 */         flushBuffer();
/*      */       }
/*  231 */       System.arraycopy(cbuf, offset, this.mOutputBuffer, this.mOutputPtr, len);
/*  232 */       this.mOutputPtr += len;
/*  233 */       return;
/*      */     }
/*      */     
/*      */ 
/*  237 */     int ptr = this.mOutputPtr;
/*  238 */     if (ptr > 0)
/*      */     {
/*  240 */       if (ptr < this.mSmallWriteSize)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  247 */         int needed = this.mSmallWriteSize - ptr;
/*      */         
/*      */ 
/*  250 */         System.arraycopy(cbuf, offset, this.mOutputBuffer, ptr, needed);
/*  251 */         this.mOutputPtr = (ptr + needed);
/*  252 */         len -= needed;
/*  253 */         offset += needed;
/*      */       }
/*  255 */       flushBuffer();
/*      */     }
/*      */     
/*      */ 
/*  259 */     this.mOut.write(cbuf, offset, len);
/*      */   }
/*      */   
/*      */   public void writeRaw(String str)
/*      */     throws IOException
/*      */   {
/*  265 */     if (this.mOut == null) {
/*  266 */       return;
/*      */     }
/*  268 */     int len = str.length();
/*      */     
/*      */ 
/*  271 */     if (len < this.mSmallWriteSize)
/*      */     {
/*  273 */       if (this.mOutputPtr + len >= this.mOutputBufLen) {
/*  274 */         flushBuffer();
/*      */       }
/*  276 */       str.getChars(0, len, this.mOutputBuffer, this.mOutputPtr);
/*  277 */       this.mOutputPtr += len;
/*  278 */       return;
/*      */     }
/*      */     
/*  281 */     writeRaw(str, 0, len);
/*      */   }
/*      */   
/*      */   public void writeRaw(String str, int offset, int len)
/*      */     throws IOException
/*      */   {
/*  287 */     if (this.mOut == null) {
/*  288 */       return;
/*      */     }
/*      */     
/*      */ 
/*  292 */     if (len < this.mSmallWriteSize)
/*      */     {
/*  294 */       if (this.mOutputPtr + len >= this.mOutputBufLen) {
/*  295 */         flushBuffer();
/*      */       }
/*  297 */       str.getChars(offset, offset + len, this.mOutputBuffer, this.mOutputPtr);
/*  298 */       this.mOutputPtr += len;
/*  299 */       return;
/*      */     }
/*      */     
/*      */ 
/*  303 */     int ptr = this.mOutputPtr;
/*  304 */     if (ptr > 0)
/*      */     {
/*  306 */       if (ptr < this.mSmallWriteSize)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  313 */         int needed = this.mSmallWriteSize - ptr;
/*      */         
/*      */ 
/*  316 */         str.getChars(offset, offset + needed, this.mOutputBuffer, ptr);
/*  317 */         this.mOutputPtr = (ptr + needed);
/*  318 */         len -= needed;
/*  319 */         offset += needed;
/*      */       }
/*  321 */       flushBuffer();
/*      */     }
/*      */     
/*      */ 
/*  325 */     this.mOut.write(str, offset, len);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void writeCDataStart()
/*      */     throws IOException
/*      */   {
/*  337 */     fastWriteRaw("<![CDATA[");
/*      */   }
/*      */   
/*      */   public final void writeCDataEnd()
/*      */     throws IOException
/*      */   {
/*  343 */     fastWriteRaw("]]>");
/*      */   }
/*      */   
/*      */   public final void writeCommentStart()
/*      */     throws IOException
/*      */   {
/*  349 */     fastWriteRaw("<!--");
/*      */   }
/*      */   
/*      */   public final void writeCommentEnd()
/*      */     throws IOException
/*      */   {
/*  355 */     fastWriteRaw("-->");
/*      */   }
/*      */   
/*      */   public final void writePIStart(String target, boolean addSpace)
/*      */     throws IOException
/*      */   {
/*  361 */     fastWriteRaw('<', '?');
/*  362 */     fastWriteRaw(target);
/*  363 */     if (addSpace) {
/*  364 */       fastWriteRaw(' ');
/*      */     }
/*      */   }
/*      */   
/*      */   public final void writePIEnd()
/*      */     throws IOException
/*      */   {
/*  371 */     fastWriteRaw('?', '>');
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int writeCData(String data)
/*      */     throws IOException
/*      */   {
/*  383 */     if (this.mCheckContent) {
/*  384 */       int ix = verifyCDataContent(data);
/*  385 */       if (ix >= 0) {
/*  386 */         if (!this.mFixContent) {
/*  387 */           return ix;
/*      */         }
/*      */         
/*  390 */         writeSegmentedCData(data, ix);
/*  391 */         return -1;
/*      */       }
/*      */     }
/*  394 */     fastWriteRaw("<![CDATA[");
/*  395 */     writeRaw(data, 0, data.length());
/*  396 */     fastWriteRaw("]]>");
/*  397 */     return -1;
/*      */   }
/*      */   
/*      */   public int writeCData(char[] cbuf, int offset, int len)
/*      */     throws IOException
/*      */   {
/*  403 */     if (this.mCheckContent) {
/*  404 */       int ix = verifyCDataContent(cbuf, offset, len);
/*  405 */       if (ix >= 0) {
/*  406 */         if (!this.mFixContent) {
/*  407 */           return ix;
/*      */         }
/*      */         
/*  410 */         writeSegmentedCData(cbuf, offset, len, ix);
/*  411 */         return -1;
/*      */       }
/*      */     }
/*  414 */     fastWriteRaw("<![CDATA[");
/*  415 */     writeRaw(cbuf, offset, len);
/*  416 */     fastWriteRaw("]]>");
/*  417 */     return -1;
/*      */   }
/*      */   
/*      */   public void writeCharacters(String text)
/*      */     throws IOException
/*      */   {
/*  423 */     if (this.mOut == null) {
/*  424 */       return;
/*      */     }
/*  426 */     if (this.mTextWriter != null) {
/*  427 */       this.mTextWriter.write(text);
/*  428 */       return;
/*      */     }
/*  430 */     int inPtr = 0;
/*  431 */     int len = text.length();
/*  432 */     int highChar = this.mEncHighChar;
/*      */     
/*      */     for (;;)
/*      */     {
/*  436 */       String ent = null;
/*      */       
/*      */       for (;;)
/*      */       {
/*  440 */         if (inPtr >= len) {
/*      */           return;
/*      */         }
/*  443 */         char c = text.charAt(inPtr++);
/*  444 */         if (c <= '>') {
/*  445 */           if (c <= ' ') {
/*  446 */             if ((c != ' ') && (c != '\n') && (c != '\t')) {
/*  447 */               if (c == '\r') {
/*  448 */                 if (this.mEscapeCR) {
/*      */                   break;
/*      */                 }
/*      */               } else {
/*  452 */                 if ((this.mXml11) && (c != 0)) break;
/*  453 */                 throwInvalidChar(c); break;
/*      */               }
/*      */             }
/*      */           }
/*      */           else {
/*  458 */             if (c == '<') {
/*  459 */               ent = "&lt;";
/*  460 */               break; }
/*  461 */             if (c == '&') {
/*  462 */               ent = "&amp;";
/*  463 */               break; }
/*  464 */             if (c == '>')
/*      */             {
/*      */ 
/*  467 */               if ((inPtr < 2) || (text.charAt(inPtr - 2) == ']')) {
/*  468 */                 ent = "&gt;";
/*  469 */                 break;
/*      */               } }
/*      */           }
/*  472 */         } else if (c >= highChar) {
/*      */             break;
/*      */           }
/*  475 */         if (this.mOutputPtr >= this.mOutputBufLen) {
/*  476 */           flushBuffer();
/*      */         }
/*  478 */         this.mOutputBuffer[(this.mOutputPtr++)] = c;
/*      */       }
/*  480 */       if (ent != null) {
/*  481 */         writeRaw(ent);
/*      */       } else {
/*  483 */         writeAsEntity(text.charAt(inPtr - 1));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeCharacters(char[] cbuf, int offset, int len)
/*      */     throws IOException
/*      */   {
/*  491 */     if (this.mOut == null) {
/*  492 */       return;
/*      */     }
/*      */     
/*  495 */     if (this.mTextWriter != null) {
/*  496 */       this.mTextWriter.write(cbuf, offset, len);
/*      */     } else {
/*  498 */       len += offset;
/*      */       do {
/*  500 */         int c = 0;
/*  501 */         int highChar = this.mEncHighChar;
/*  502 */         int start = offset;
/*  503 */         String ent = null;
/*  505 */         for (; 
/*  505 */             offset < len; offset++) {
/*  506 */           c = cbuf[offset];
/*  507 */           if (c <= 62) {
/*  508 */             if (c == 60) {
/*  509 */               ent = "&lt;";
/*  510 */               break; }
/*  511 */             if (c == 38) {
/*  512 */               ent = "&amp;";
/*  513 */               break; }
/*  514 */             if (c == 62)
/*      */             {
/*      */ 
/*      */ 
/*  518 */               if ((offset == start) || (cbuf[(offset - 1)] == ']')) {
/*  519 */                 ent = "&gt;";
/*  520 */                 break;
/*      */               }
/*  522 */             } else if ((c < 32) && 
/*  523 */               (c != 10) && (c != 9))
/*      */             {
/*  525 */               if (c == 13) {
/*  526 */                 if (this.mEscapeCR) {
/*      */                   break;
/*      */                 }
/*      */               } else {
/*  530 */                 if ((this.mXml11) && (c != 0)) break;
/*  531 */                 throwInvalidChar(c); break;
/*      */               }
/*      */             }
/*      */           }
/*      */           else {
/*  536 */             if (c >= highChar) {
/*      */               break;
/*      */             }
/*      */           }
/*      */         }
/*  541 */         int outLen = offset - start;
/*  542 */         if (outLen > 0) {
/*  543 */           writeRaw(cbuf, start, outLen);
/*      */         }
/*  545 */         if (ent != null) {
/*  546 */           writeRaw(ent);
/*  547 */           ent = null;
/*  548 */         } else if (offset < len) {
/*  549 */           writeAsEntity(c);
/*      */         }
/*  551 */         offset++; } while (offset < len);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int writeComment(String data)
/*      */     throws IOException
/*      */   {
/*  565 */     if (this.mCheckContent) {
/*  566 */       int ix = verifyCommentContent(data);
/*  567 */       if (ix >= 0) {
/*  568 */         if (!this.mFixContent) {
/*  569 */           return ix;
/*      */         }
/*      */         
/*  572 */         writeSegmentedComment(data, ix);
/*  573 */         return -1;
/*      */       }
/*      */     }
/*  576 */     fastWriteRaw("<!--");
/*  577 */     writeRaw(data);
/*  578 */     fastWriteRaw("-->");
/*  579 */     return -1;
/*      */   }
/*      */   
/*      */   public void writeDTD(String data)
/*      */     throws IOException
/*      */   {
/*  585 */     writeRaw(data);
/*      */   }
/*      */   
/*      */ 
/*      */   public void writeDTD(String rootName, String systemId, String publicId, String internalSubset)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  592 */     fastWriteRaw("<!DOCTYPE ");
/*  593 */     if (this.mCheckNames)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  599 */       verifyNameValidity(rootName, false);
/*      */     }
/*  601 */     fastWriteRaw(rootName);
/*  602 */     if (systemId != null) {
/*  603 */       if (publicId != null) {
/*  604 */         fastWriteRaw(" PUBLIC \"");
/*  605 */         fastWriteRaw(publicId);
/*  606 */         fastWriteRaw("\" \"");
/*      */       } else {
/*  608 */         fastWriteRaw(" SYSTEM \"");
/*      */       }
/*  610 */       fastWriteRaw(systemId);
/*  611 */       fastWriteRaw('"');
/*      */     }
/*      */     
/*  614 */     if ((internalSubset != null) && (internalSubset.length() > 0)) {
/*  615 */       fastWriteRaw(' ', '[');
/*  616 */       fastWriteRaw(internalSubset);
/*  617 */       fastWriteRaw(']');
/*      */     }
/*  619 */     fastWriteRaw('>');
/*      */   }
/*      */   
/*      */   public void writeEntityReference(String name)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  625 */     if (this.mCheckNames) {
/*  626 */       verifyNameValidity(name, this.mNsAware);
/*      */     }
/*  628 */     fastWriteRaw('&');
/*  629 */     fastWriteRaw(name);
/*  630 */     fastWriteRaw(';');
/*      */   }
/*      */   
/*      */   public void writeXmlDeclaration(String version, String encoding, String standalone)
/*      */     throws IOException
/*      */   {
/*  636 */     fastWriteRaw("<?xml version='");
/*  637 */     fastWriteRaw(version);
/*  638 */     fastWriteRaw('\'');
/*      */     
/*  640 */     if ((encoding != null) && (encoding.length() > 0)) {
/*  641 */       fastWriteRaw(" encoding='");
/*  642 */       fastWriteRaw(encoding);
/*  643 */       fastWriteRaw('\'');
/*      */     }
/*  645 */     if (standalone != null) {
/*  646 */       fastWriteRaw(" standalone='");
/*  647 */       fastWriteRaw(standalone);
/*  648 */       fastWriteRaw('\'');
/*      */     }
/*  650 */     fastWriteRaw('?', '>');
/*      */   }
/*      */   
/*      */   public int writePI(String target, String data)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  656 */     if (this.mCheckNames)
/*      */     {
/*  658 */       verifyNameValidity(target, this.mNsAware);
/*      */     }
/*  660 */     fastWriteRaw('<', '?');
/*  661 */     fastWriteRaw(target);
/*  662 */     if ((data != null) && (data.length() > 0)) {
/*  663 */       if (this.mCheckContent) {
/*  664 */         int ix = data.indexOf('?');
/*  665 */         if (ix >= 0) {
/*  666 */           ix = data.indexOf("?>", ix);
/*  667 */           if (ix >= 0) {
/*  668 */             return ix;
/*      */           }
/*      */         }
/*      */       }
/*  672 */       fastWriteRaw(' ');
/*      */       
/*  674 */       writeRaw(data);
/*      */     }
/*  676 */     fastWriteRaw('?', '>');
/*  677 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeStartTagStart(String localName)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  689 */     if (this.mCheckNames) {
/*  690 */       verifyNameValidity(localName, this.mNsAware);
/*      */     }
/*      */     
/*  693 */     int ptr = this.mOutputPtr;
/*  694 */     int extra = this.mOutputBufLen - ptr - (1 + localName.length());
/*  695 */     if (extra < 0) {
/*  696 */       fastWriteRaw('<');
/*  697 */       fastWriteRaw(localName);
/*      */     } else {
/*  699 */       char[] buf = this.mOutputBuffer;
/*  700 */       buf[(ptr++)] = '<';
/*  701 */       int len = localName.length();
/*  702 */       localName.getChars(0, len, buf, ptr);
/*  703 */       this.mOutputPtr = (ptr + len);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeStartTagStart(String prefix, String localName)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  710 */     if ((prefix == null) || (prefix.length() == 0)) {
/*  711 */       writeStartTagStart(localName);
/*  712 */       return;
/*      */     }
/*      */     
/*  715 */     if (this.mCheckNames) {
/*  716 */       verifyNameValidity(prefix, this.mNsAware);
/*  717 */       verifyNameValidity(localName, this.mNsAware);
/*      */     }
/*      */     
/*  720 */     int ptr = this.mOutputPtr;
/*  721 */     int len = prefix.length();
/*  722 */     int extra = this.mOutputBufLen - ptr - (2 + localName.length() + len);
/*  723 */     if (extra < 0) {
/*  724 */       fastWriteRaw('<');
/*  725 */       fastWriteRaw(prefix);
/*  726 */       fastWriteRaw(':');
/*  727 */       fastWriteRaw(localName);
/*      */     } else {
/*  729 */       char[] buf = this.mOutputBuffer;
/*  730 */       buf[(ptr++)] = '<';
/*  731 */       prefix.getChars(0, len, buf, ptr);
/*  732 */       ptr += len;
/*  733 */       buf[(ptr++)] = ':';
/*  734 */       len = localName.length();
/*  735 */       localName.getChars(0, len, buf, ptr);
/*  736 */       this.mOutputPtr = (ptr + len);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeStartTagEnd()
/*      */     throws IOException
/*      */   {
/*  743 */     fastWriteRaw('>');
/*      */   }
/*      */   
/*      */   public void writeStartTagEmptyEnd()
/*      */     throws IOException
/*      */   {
/*  749 */     int ptr = this.mOutputPtr;
/*  750 */     if (ptr + 3 >= this.mOutputBufLen) {
/*  751 */       if (this.mOut == null) {
/*  752 */         return;
/*      */       }
/*  754 */       flushBuffer();
/*  755 */       ptr = this.mOutputPtr;
/*      */     }
/*  757 */     char[] buf = this.mOutputBuffer;
/*  758 */     buf[(ptr++)] = ' ';
/*  759 */     buf[(ptr++)] = '/';
/*  760 */     buf[(ptr++)] = '>';
/*  761 */     this.mOutputPtr = ptr;
/*      */   }
/*      */   
/*      */   public void writeEndTag(String localName)
/*      */     throws IOException
/*      */   {
/*  767 */     int ptr = this.mOutputPtr;
/*  768 */     int extra = this.mOutputBufLen - ptr - (3 + localName.length());
/*  769 */     if (extra < 0) {
/*  770 */       fastWriteRaw('<', '/');
/*  771 */       fastWriteRaw(localName);
/*  772 */       fastWriteRaw('>');
/*      */     } else {
/*  774 */       char[] buf = this.mOutputBuffer;
/*  775 */       buf[(ptr++)] = '<';
/*  776 */       buf[(ptr++)] = '/';
/*  777 */       int len = localName.length();
/*  778 */       localName.getChars(0, len, buf, ptr);
/*  779 */       ptr += len;
/*  780 */       buf[(ptr++)] = '>';
/*  781 */       this.mOutputPtr = ptr;
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeEndTag(String prefix, String localName)
/*      */     throws IOException
/*      */   {
/*  788 */     if ((prefix == null) || (prefix.length() == 0)) {
/*  789 */       writeEndTag(localName);
/*  790 */       return;
/*      */     }
/*  792 */     int ptr = this.mOutputPtr;
/*  793 */     int len = prefix.length();
/*  794 */     int extra = this.mOutputBufLen - ptr - (4 + localName.length() + len);
/*  795 */     if (extra < 0) {
/*  796 */       fastWriteRaw('<', '/');
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  801 */       fastWriteRaw(prefix);
/*  802 */       fastWriteRaw(':');
/*  803 */       fastWriteRaw(localName);
/*  804 */       fastWriteRaw('>');
/*      */     } else {
/*  806 */       char[] buf = this.mOutputBuffer;
/*  807 */       buf[(ptr++)] = '<';
/*  808 */       buf[(ptr++)] = '/';
/*  809 */       prefix.getChars(0, len, buf, ptr);
/*  810 */       ptr += len;
/*  811 */       buf[(ptr++)] = ':';
/*  812 */       len = localName.length();
/*  813 */       localName.getChars(0, len, buf, ptr);
/*  814 */       ptr += len;
/*  815 */       buf[(ptr++)] = '>';
/*  816 */       this.mOutputPtr = ptr;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeAttribute(String localName, String value)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  829 */     if (this.mOut == null) {
/*  830 */       return;
/*      */     }
/*  832 */     if (this.mCheckNames) {
/*  833 */       verifyNameValidity(localName, this.mNsAware);
/*      */     }
/*  835 */     int len = localName.length();
/*  836 */     if (this.mOutputBufLen - this.mOutputPtr - (3 + len) < 0) {
/*  837 */       fastWriteRaw(' ');
/*  838 */       fastWriteRaw(localName);
/*  839 */       fastWriteRaw('=', '"');
/*      */     } else {
/*  841 */       int ptr = this.mOutputPtr;
/*  842 */       char[] buf = this.mOutputBuffer;
/*  843 */       buf[(ptr++)] = ' ';
/*  844 */       localName.getChars(0, len, buf, ptr);
/*  845 */       ptr += len;
/*  846 */       buf[(ptr++)] = '=';
/*  847 */       buf[(ptr++)] = '"';
/*  848 */       this.mOutputPtr = ptr;
/*      */     }
/*      */     
/*  851 */     len = value == null ? 0 : value.length();
/*  852 */     if (len > 0) {
/*  853 */       if (this.mAttrValueWriter != null) {
/*  854 */         this.mAttrValueWriter.write(value, 0, len);
/*      */       } else {
/*  856 */         writeAttrValue(value, len);
/*      */       }
/*      */     }
/*  859 */     fastWriteRaw('"');
/*      */   }
/*      */   
/*      */   public void writeAttribute(String localName, char[] value, int offset, int vlen)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  865 */     if (this.mOut == null) {
/*  866 */       return;
/*      */     }
/*  868 */     if (this.mCheckNames) {
/*  869 */       verifyNameValidity(localName, this.mNsAware);
/*      */     }
/*  871 */     int len = localName.length();
/*  872 */     if (this.mOutputBufLen - this.mOutputPtr - (3 + len) < 0) {
/*  873 */       fastWriteRaw(' ');
/*  874 */       fastWriteRaw(localName);
/*  875 */       fastWriteRaw('=', '"');
/*      */     } else {
/*  877 */       int ptr = this.mOutputPtr;
/*  878 */       char[] buf = this.mOutputBuffer;
/*  879 */       buf[(ptr++)] = ' ';
/*  880 */       localName.getChars(0, len, buf, ptr);
/*  881 */       ptr += len;
/*  882 */       buf[(ptr++)] = '=';
/*  883 */       buf[(ptr++)] = '"';
/*  884 */       this.mOutputPtr = ptr;
/*      */     }
/*      */     
/*  887 */     if (vlen > 0) {
/*  888 */       if (this.mAttrValueWriter != null) {
/*  889 */         this.mAttrValueWriter.write(value, offset, vlen);
/*      */       } else {
/*  891 */         writeAttrValue(value, offset, vlen);
/*      */       }
/*      */     }
/*  894 */     fastWriteRaw('"');
/*      */   }
/*      */   
/*      */   public void writeAttribute(String prefix, String localName, String value)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  900 */     if (this.mOut == null) {
/*  901 */       return;
/*      */     }
/*  903 */     if (this.mCheckNames) {
/*  904 */       verifyNameValidity(prefix, this.mNsAware);
/*  905 */       verifyNameValidity(localName, this.mNsAware);
/*      */     }
/*  907 */     int len = prefix.length();
/*  908 */     if (this.mOutputBufLen - this.mOutputPtr - (4 + localName.length() + len) < 0) {
/*  909 */       fastWriteRaw(' ');
/*  910 */       if ((prefix != null) && (prefix.length() > 0)) {
/*  911 */         fastWriteRaw(prefix);
/*  912 */         fastWriteRaw(':');
/*      */       }
/*  914 */       fastWriteRaw(localName);
/*  915 */       fastWriteRaw('=', '"');
/*      */     } else {
/*  917 */       int ptr = this.mOutputPtr;
/*  918 */       char[] buf = this.mOutputBuffer;
/*  919 */       buf[(ptr++)] = ' ';
/*  920 */       prefix.getChars(0, len, buf, ptr);
/*  921 */       ptr += len;
/*  922 */       buf[(ptr++)] = ':';
/*  923 */       len = localName.length();
/*  924 */       localName.getChars(0, len, buf, ptr);
/*  925 */       ptr += len;
/*  926 */       buf[(ptr++)] = '=';
/*  927 */       buf[(ptr++)] = '"';
/*  928 */       this.mOutputPtr = ptr;
/*      */     }
/*      */     
/*  931 */     len = value == null ? 0 : value.length();
/*  932 */     if (len > 0) {
/*  933 */       if (this.mAttrValueWriter != null) {
/*  934 */         this.mAttrValueWriter.write(value, 0, len);
/*      */       } else {
/*  936 */         writeAttrValue(value, len);
/*      */       }
/*      */     }
/*  939 */     fastWriteRaw('"');
/*      */   }
/*      */   
/*      */   public void writeAttribute(String prefix, String localName, char[] value, int offset, int vlen)
/*      */     throws IOException, XMLStreamException
/*      */   {
/*  945 */     if (this.mOut == null) {
/*  946 */       return;
/*      */     }
/*  948 */     if (this.mCheckNames) {
/*  949 */       verifyNameValidity(prefix, this.mNsAware);
/*  950 */       verifyNameValidity(localName, this.mNsAware);
/*      */     }
/*  952 */     int len = prefix.length();
/*  953 */     if (this.mOutputBufLen - this.mOutputPtr - (4 + localName.length() + len) < 0) {
/*  954 */       fastWriteRaw(' ');
/*  955 */       if ((prefix != null) && (prefix.length() > 0)) {
/*  956 */         fastWriteRaw(prefix);
/*  957 */         fastWriteRaw(':');
/*      */       }
/*  959 */       fastWriteRaw(localName);
/*  960 */       fastWriteRaw('=', '"');
/*      */     } else {
/*  962 */       int ptr = this.mOutputPtr;
/*  963 */       char[] buf = this.mOutputBuffer;
/*  964 */       buf[(ptr++)] = ' ';
/*  965 */       prefix.getChars(0, len, buf, ptr);
/*  966 */       ptr += len;
/*  967 */       buf[(ptr++)] = ':';
/*  968 */       len = localName.length();
/*  969 */       localName.getChars(0, len, buf, ptr);
/*  970 */       ptr += len;
/*  971 */       buf[(ptr++)] = '=';
/*  972 */       buf[(ptr++)] = '"';
/*  973 */       this.mOutputPtr = ptr;
/*      */     }
/*      */     
/*  976 */     if (vlen > 0) {
/*  977 */       if (this.mAttrValueWriter != null) {
/*  978 */         this.mAttrValueWriter.write(value, offset, vlen);
/*      */       } else {
/*  980 */         writeAttrValue(value, offset, vlen);
/*      */       }
/*      */     }
/*  983 */     fastWriteRaw('"');
/*      */   }
/*      */   
/*      */   private final void writeAttrValue(String value, int len)
/*      */     throws IOException
/*      */   {
/*  989 */     int inPtr = 0;
/*  990 */     char qchar = this.mEncQuoteChar;
/*  991 */     int highChar = this.mEncHighChar;
/*      */     
/*      */     for (;;)
/*      */     {
/*  995 */       String ent = null;
/*      */       
/*      */       for (;;)
/*      */       {
/*  999 */         if (inPtr >= len) {
/*      */           return;
/*      */         }
/* 1002 */         char c = value.charAt(inPtr++);
/* 1003 */         if (c <= '<') {
/* 1004 */           if (c < ' ') {
/* 1005 */             if ((c == '\n') || (c == '\r') || (c == '\t') || (
/* 1006 */               (this.mXml11) && (c != 0))) break;
/* 1007 */             throwInvalidChar(c); break;
/*      */           }
/*      */           
/*      */ 
/* 1011 */           if (c == qchar) {
/* 1012 */             ent = this.mEncQuoteEntity;
/* 1013 */             break; }
/* 1014 */           if (c == '<') {
/* 1015 */             ent = "&lt;";
/* 1016 */             break; }
/* 1017 */           if (c == '&') {
/* 1018 */             ent = "&amp;";
/* 1019 */             break;
/*      */           }
/* 1021 */         } else { if (c >= highChar)
/*      */             break;
/*      */         }
/* 1024 */         if (this.mOutputPtr >= this.mOutputBufLen) {
/* 1025 */           flushBuffer();
/*      */         }
/* 1027 */         this.mOutputBuffer[(this.mOutputPtr++)] = c;
/*      */       }
/* 1029 */       if (ent != null) {
/* 1030 */         writeRaw(ent);
/*      */       } else {
/* 1032 */         writeAsEntity(value.charAt(inPtr - 1));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private final void writeAttrValue(char[] value, int offset, int len)
/*      */     throws IOException
/*      */   {
/* 1040 */     len += offset;
/* 1041 */     char qchar = this.mEncQuoteChar;
/* 1042 */     int highChar = this.mEncHighChar;
/*      */     
/*      */     for (;;)
/*      */     {
/* 1046 */       String ent = null;
/*      */       
/*      */       for (;;)
/*      */       {
/* 1050 */         if (offset >= len) {
/*      */           return;
/*      */         }
/* 1053 */         char c = value[(offset++)];
/* 1054 */         if (c <= '<') {
/* 1055 */           if (c < ' ') {
/* 1056 */             if ((c == '\n') || (c == '\r') || (c == '\t') || (
/* 1057 */               (this.mXml11) && (c != 0))) break;
/* 1058 */             throwInvalidChar(c); break;
/*      */           }
/*      */           
/*      */ 
/* 1062 */           if (c == qchar) {
/* 1063 */             ent = this.mEncQuoteEntity;
/* 1064 */             break; }
/* 1065 */           if (c == '<') {
/* 1066 */             ent = "&lt;";
/* 1067 */             break; }
/* 1068 */           if (c == '&') {
/* 1069 */             ent = "&amp;";
/* 1070 */             break;
/*      */           }
/* 1072 */         } else { if (c >= highChar)
/*      */             break;
/*      */         }
/* 1075 */         if (this.mOutputPtr >= this.mOutputBufLen) {
/* 1076 */           flushBuffer();
/*      */         }
/* 1078 */         this.mOutputBuffer[(this.mOutputPtr++)] = c;
/*      */       }
/* 1080 */       if (ent != null) {
/* 1081 */         writeRaw(ent);
/*      */       } else {
/* 1083 */         writeAsEntity(value[(offset - 1)]);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void flushBuffer()
/*      */     throws IOException
/*      */   {
/* 1097 */     if ((this.mOutputPtr > 0) && (this.mOut != null)) {
/* 1098 */       int ptr = this.mOutputPtr;
/*      */       
/* 1100 */       this.mLocPastChars += ptr;
/* 1101 */       this.mLocRowStartOffset -= ptr;
/* 1102 */       this.mOutputPtr = 0;
/* 1103 */       this.mOut.write(this.mOutputBuffer, 0, ptr);
/*      */     }
/*      */   }
/*      */   
/*      */   private final void fastWriteRaw(char c)
/*      */     throws IOException
/*      */   {
/* 1110 */     if (this.mOutputPtr >= this.mOutputBufLen) {
/* 1111 */       if (this.mOut == null) {
/* 1112 */         return;
/*      */       }
/* 1114 */       flushBuffer();
/*      */     }
/* 1116 */     this.mOutputBuffer[(this.mOutputPtr++)] = c;
/*      */   }
/*      */   
/*      */   private final void fastWriteRaw(char c1, char c2)
/*      */     throws IOException
/*      */   {
/* 1122 */     if (this.mOutputPtr + 1 >= this.mOutputBufLen) {
/* 1123 */       if (this.mOut == null) {
/* 1124 */         return;
/*      */       }
/* 1126 */       flushBuffer();
/*      */     }
/* 1128 */     this.mOutputBuffer[(this.mOutputPtr++)] = c1;
/* 1129 */     this.mOutputBuffer[(this.mOutputPtr++)] = c2;
/*      */   }
/*      */   
/*      */   private final void fastWriteRaw(String str)
/*      */     throws IOException
/*      */   {
/* 1135 */     int len = str.length();
/* 1136 */     int ptr = this.mOutputPtr;
/* 1137 */     if (ptr + len >= this.mOutputBufLen) {
/* 1138 */       if (this.mOut == null) {
/* 1139 */         return;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1145 */       if (len > this.mOutputBufLen) {
/* 1146 */         writeRaw(str);
/* 1147 */         return;
/*      */       }
/* 1149 */       flushBuffer();
/* 1150 */       ptr = this.mOutputPtr;
/*      */     }
/* 1152 */     str.getChars(0, len, this.mOutputBuffer, ptr);
/* 1153 */     this.mOutputPtr = (ptr + len);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int verifyCDataContent(String content)
/*      */   {
/* 1168 */     if ((content != null) && (content.length() >= 3)) {
/* 1169 */       int ix = content.indexOf(']');
/* 1170 */       if (ix >= 0) {
/* 1171 */         return content.indexOf("]]>", ix);
/*      */       }
/*      */     }
/* 1174 */     return -1;
/*      */   }
/*      */   
/*      */   protected int verifyCDataContent(char[] c, int start, int end)
/*      */   {
/* 1179 */     if (c != null) {
/* 1180 */       start += 2;
/*      */       
/*      */ 
/*      */ 
/* 1184 */       while (start < end) {
/* 1185 */         char ch = c[start];
/* 1186 */         if (ch == ']') {
/* 1187 */           start++;
/*      */         }
/*      */         else {
/* 1190 */           if ((ch == '>') && 
/* 1191 */             (c[(start - 1)] == ']') && (c[(start - 2)] == ']'))
/*      */           {
/* 1193 */             return start - 2;
/*      */           }
/*      */           
/* 1196 */           start += 2;
/*      */         }
/*      */       } }
/* 1199 */     return -1;
/*      */   }
/*      */   
/*      */   protected int verifyCommentContent(String content)
/*      */   {
/* 1204 */     int ix = content.indexOf('-');
/* 1205 */     if (ix >= 0)
/*      */     {
/*      */ 
/*      */ 
/* 1209 */       if (ix < content.length() - 1) {
/* 1210 */         ix = content.indexOf("--", ix);
/*      */       }
/*      */     }
/* 1213 */     return ix;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void writeSegmentedCData(String content, int index)
/*      */     throws IOException
/*      */   {
/* 1223 */     int start = 0;
/* 1224 */     while (index >= 0) {
/* 1225 */       fastWriteRaw("<![CDATA[");
/* 1226 */       writeRaw(content, start, index + 2 - start);
/* 1227 */       fastWriteRaw("]]>");
/* 1228 */       start = index + 2;
/* 1229 */       index = content.indexOf("]]>", start);
/*      */     }
/*      */     
/* 1232 */     fastWriteRaw("<![CDATA[");
/* 1233 */     writeRaw(content, start, content.length() - start);
/* 1234 */     fastWriteRaw("]]>");
/*      */   }
/*      */   
/*      */   protected void writeSegmentedCData(char[] c, int start, int len, int index)
/*      */     throws IOException
/*      */   {
/* 1240 */     int end = start + len;
/* 1241 */     while (index >= 0) {
/* 1242 */       fastWriteRaw("<![CDATA[");
/* 1243 */       writeRaw(c, start, index + 2 - start);
/* 1244 */       fastWriteRaw("]]>");
/* 1245 */       start = index + 2;
/* 1246 */       index = verifyCDataContent(c, start, end);
/*      */     }
/*      */     
/* 1249 */     fastWriteRaw("<![CDATA[");
/* 1250 */     writeRaw(c, start, end - start);
/* 1251 */     fastWriteRaw("]]>");
/*      */   }
/*      */   
/*      */   protected void writeSegmentedComment(String content, int index)
/*      */     throws IOException
/*      */   {
/* 1257 */     int len = content.length();
/*      */     
/* 1259 */     if (index == len - 1) {
/* 1260 */       fastWriteRaw("<!--");
/* 1261 */       writeRaw(content);
/*      */       
/* 1263 */       fastWriteRaw(" -->");
/* 1264 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1276 */     fastWriteRaw("<!--");
/* 1277 */     int start = 0;
/* 1278 */     while (index >= 0)
/*      */     {
/* 1280 */       writeRaw(content, start, index + 1 - start);
/*      */       
/* 1282 */       fastWriteRaw(' ');
/*      */       
/* 1284 */       start = index + 1;
/* 1285 */       index = content.indexOf("--", start);
/*      */     }
/*      */     
/* 1288 */     writeRaw(content, start, len - start);
/*      */     
/* 1290 */     if (content.charAt(len - 1) == '-') {
/* 1291 */       fastWriteRaw(' ');
/*      */     }
/* 1293 */     fastWriteRaw("-->");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int guessEncodingBitSize(String enc)
/*      */   {
/* 1305 */     if ((enc == null) || (enc.length() == 0)) {
/* 1306 */       return 16;
/*      */     }
/*      */     
/* 1309 */     enc = CharsetNames.normalize(enc);
/*      */     
/*      */ 
/* 1312 */     if (enc == "UTF-8")
/* 1313 */       return 16;
/* 1314 */     if (enc == "ISO-8859-1")
/* 1315 */       return 8;
/* 1316 */     if (enc == "US-ASCII")
/* 1317 */       return 7;
/* 1318 */     if ((enc == "UTF-16") || (enc == "UTF-16BE") || (enc == "UTF-16LE") || (enc == "UTF-32BE") || (enc == "UTF-32LE"))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1323 */       return 16;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1331 */     return 8;
/*      */   }
/*      */   
/*      */   protected final void writeAsEntity(int c)
/*      */     throws IOException
/*      */   {
/* 1337 */     char[] buf = this.mOutputBuffer;
/* 1338 */     int ptr = this.mOutputPtr;
/* 1339 */     if (ptr + 10 >= buf.length) {
/* 1340 */       flushBuffer();
/* 1341 */       ptr = this.mOutputPtr;
/*      */     }
/* 1343 */     buf[(ptr++)] = '&';
/*      */     
/*      */ 
/* 1346 */     if (c < 256)
/*      */     {
/*      */ 
/*      */ 
/* 1350 */       if (c == 38) {
/* 1351 */         buf[(ptr++)] = 'a';
/* 1352 */         buf[(ptr++)] = 'm';
/* 1353 */         buf[(ptr++)] = 'p';
/* 1354 */       } else if (c == 60) {
/* 1355 */         buf[(ptr++)] = 'l';
/* 1356 */         buf[(ptr++)] = 't';
/* 1357 */       } else if (c == 62) {
/* 1358 */         buf[(ptr++)] = 'g';
/* 1359 */         buf[(ptr++)] = 't';
/* 1360 */       } else if (c == 39) {
/* 1361 */         buf[(ptr++)] = 'a';
/* 1362 */         buf[(ptr++)] = 'p';
/* 1363 */         buf[(ptr++)] = 'o';
/* 1364 */         buf[(ptr++)] = 's';
/* 1365 */       } else if (c == 34) {
/* 1366 */         buf[(ptr++)] = 'q';
/* 1367 */         buf[(ptr++)] = 'u';
/* 1368 */         buf[(ptr++)] = 'o';
/* 1369 */         buf[(ptr++)] = 't';
/*      */       } else {
/* 1371 */         buf[(ptr++)] = '#';
/* 1372 */         buf[(ptr++)] = 'x';
/*      */         
/* 1374 */         if (c >= 16) {
/* 1375 */           int digit = c >> 4;
/* 1376 */           buf[(ptr++)] = ((char)(digit < 10 ? 48 + digit : 87 + digit));
/* 1377 */           c &= 0xF;
/*      */         }
/* 1379 */         buf[(ptr++)] = ((char)(c < 10 ? 48 + c : 87 + c));
/*      */       }
/*      */     } else {
/* 1382 */       buf[(ptr++)] = '#';
/* 1383 */       buf[(ptr++)] = 'x';
/*      */       
/*      */ 
/* 1386 */       int shift = 20;
/* 1387 */       int origPtr = ptr;
/*      */       do
/*      */       {
/* 1390 */         int digit = c >> shift & 0xF;
/* 1391 */         if ((digit > 0) || (ptr != origPtr)) {
/* 1392 */           buf[(ptr++)] = ((char)(digit < 10 ? 48 + digit : 87 + digit));
/*      */         }
/* 1394 */         shift -= 4;
/* 1395 */       } while (shift > 0);
/* 1396 */       c &= 0xF;
/* 1397 */       buf[(ptr++)] = ((char)(c < 10 ? 48 + c : 87 + c));
/*      */     }
/* 1399 */     buf[(ptr++)] = ';';
/* 1400 */     this.mOutputPtr = ptr;
/*      */   }
/*      */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sw\BufferingXmlWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */