/*     */ package com.ctc.wstx.sr;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import com.ctc.wstx.sw.XmlWriter;
/*     */ import com.ctc.wstx.util.StringVector;
/*     */ import com.ctc.wstx.util.TextBuilder;
/*     */ import java.io.IOException;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AttributeCollector
/*     */ {
/*     */   protected static final int LONG_ATTR_LIST_LEN = 4;
/*     */   protected static final int EXP_ATTR_COUNT = 16;
/*     */   protected static final int XMLID_IX_DISABLED = -2;
/*     */   protected static final int XMLID_IX_NONE = -1;
/*     */   protected int mAttrCount;
/*     */   protected int mNonDefCount;
/*  92 */   protected TextBuilder mValueBuffer = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */   protected StringVector mAttrNames = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int mXmlIdAttrIndex;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 122 */   protected String[] mAttrValues = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 146 */   protected int[] mAttrMap = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int mAttrHashSize;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int mAttrSpillEnd;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AttributeCollector(ReaderConfig cfg)
/*     */   {
/* 168 */     this.mXmlIdAttrIndex = (cfg.willDoXmlIdTyping() ? -1 : -2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void reset();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int getNsCount();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String getNsPrefix(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String getNsURI(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getCount()
/*     */   {
/* 196 */     return this.mAttrCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSpecifiedCount()
/*     */   {
/* 205 */     return this.mNonDefCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract String getPrefix(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract String getLocalName(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract String getURI(int paramInt);
/*     */   
/*     */ 
/*     */   public abstract QName getQName(int paramInt);
/*     */   
/*     */ 
/*     */   public final String getValue(int index)
/*     */   {
/* 226 */     if ((index < 0) || (index >= this.mAttrCount)) {
/* 227 */       throwIndex(index);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 233 */     if (this.mAttrValues == null) {
/* 234 */       this.mAttrValues = new String[this.mAttrCount];
/*     */     }
/* 236 */     String str = this.mAttrValues[index];
/* 237 */     if (str == null) {
/* 238 */       str = this.mValueBuffer.getEntry(index);
/* 239 */       this.mAttrValues[index] = str;
/*     */     }
/* 241 */     return str;
/*     */   }
/*     */   
/*     */   public abstract String getValue(String paramString1, String paramString2);
/*     */   
/*     */   public final boolean isSpecified(int index) {
/* 247 */     return index < this.mNonDefCount;
/*     */   }
/*     */   
/*     */   public final int getXmlIdAttrIndex() {
/* 251 */     return this.mXmlIdAttrIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract TextBuilder getDefaultNsBuilder();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract TextBuilder getNsBuilder(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract TextBuilder getAttrBuilder(String paramString1, String paramString2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract ElemAttrs buildAttrOb();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final TextBuilder getAttrBuilder()
/*     */   {
/* 286 */     return this.mValueBuffer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setNormalizedValue(int index, String value)
/*     */   {
/* 297 */     if (this.mAttrValues == null) {
/* 298 */       this.mAttrValues = new String[this.mAttrCount];
/*     */     }
/* 300 */     this.mAttrValues[index] = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void throwIndex(int index)
/*     */   {
/* 310 */     throw new IllegalArgumentException("Invalid index " + index + "; current element has only " + getCount() + " attributes");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final StringVector getNameList()
/*     */   {
/* 318 */     return this.mAttrNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writeAttribute(int paramInt, XmlWriter paramXmlWriter)
/*     */     throws IOException, XMLStreamException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void allocBuffers()
/*     */   {
/* 336 */     if (this.mValueBuffer == null) {
/* 337 */       this.mValueBuffer = new TextBuilder(16);
/*     */     }
/* 339 */     if (this.mAttrNames == null) {
/* 340 */       this.mAttrNames = new StringVector(16);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static String[] resize(String[] old)
/*     */   {
/* 366 */     int len = old.length;
/* 367 */     String[] result = new String[len];
/* 368 */     System.arraycopy(old, 0, result, 0, len);
/* 369 */     return result;
/*     */   }
/*     */   
/*     */   protected void throwDupAttr(InputProblemReporter rep, int index)
/*     */     throws XMLStreamException
/*     */   {
/* 375 */     rep.throwParseError("Duplicate attribute '" + getQName(index) + "'.");
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sr\AttributeCollector.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */