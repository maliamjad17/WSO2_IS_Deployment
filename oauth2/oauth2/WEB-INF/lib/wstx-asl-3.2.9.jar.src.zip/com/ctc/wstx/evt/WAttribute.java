/*     */ package com.ctc.wstx.evt;
/*     */ 
/*     */ import com.ctc.wstx.io.TextEscaper;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.stream.events.Attribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WAttribute
/*     */   extends WEvent
/*     */   implements Attribute
/*     */ {
/*     */   final QName mName;
/*     */   final String mValue;
/*     */   final boolean mWasSpecified;
/*     */   
/*     */   public WAttribute(Location loc, String localName, String uri, String prefix, String value, boolean wasSpec)
/*     */   {
/*  25 */     super(loc);
/*  26 */     this.mValue = value;
/*  27 */     if (prefix == null) {
/*  28 */       if (uri == null) {
/*  29 */         this.mName = new QName(localName);
/*     */       } else {
/*  31 */         this.mName = new QName(uri, localName);
/*     */       }
/*     */     } else {
/*  34 */       if (uri == null) {
/*  35 */         uri = "";
/*     */       }
/*  37 */       this.mName = new QName(uri, localName, prefix);
/*     */     }
/*  39 */     this.mWasSpecified = wasSpec;
/*     */   }
/*     */   
/*     */   public WAttribute(Location loc, QName name, String value, boolean wasSpec)
/*     */   {
/*  44 */     super(loc);
/*  45 */     this.mName = name;
/*  46 */     this.mValue = value;
/*  47 */     this.mWasSpecified = wasSpec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getEventType()
/*     */   {
/*  57 */     return 10;
/*     */   }
/*     */   
/*  60 */   public boolean isAttribute() { return true; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeAsEncodedUnicode(Writer w)
/*     */     throws XMLStreamException
/*     */   {
/*  68 */     String prefix = this.mName.getPrefix();
/*     */     try {
/*  70 */       if ((prefix != null) && (prefix.length() > 0)) {
/*  71 */         w.write(prefix);
/*  72 */         w.write(58);
/*     */       }
/*  74 */       w.write(this.mName.getLocalPart());
/*  75 */       w.write(61);
/*  76 */       w.write(34);
/*  77 */       TextEscaper.writeEscapedAttrValue(w, this.mValue);
/*  78 */       w.write(34);
/*     */     } catch (IOException ie) {
/*  80 */       throwFromIOE(ie);
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeUsing(XMLStreamWriter w) throws XMLStreamException
/*     */   {
/*  86 */     QName n = this.mName;
/*  87 */     w.writeAttribute(n.getPrefix(), n.getLocalPart(), n.getNamespaceURI(), this.mValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDTDType()
/*     */   {
/* 101 */     return "CDATA";
/*     */   }
/*     */   
/*     */   public QName getName()
/*     */   {
/* 106 */     return this.mName;
/*     */   }
/*     */   
/*     */   public String getValue()
/*     */   {
/* 111 */     return this.mValue;
/*     */   }
/*     */   
/*     */   public boolean isSpecified()
/*     */   {
/* 116 */     return this.mWasSpecified;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\evt\WAttribute.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */