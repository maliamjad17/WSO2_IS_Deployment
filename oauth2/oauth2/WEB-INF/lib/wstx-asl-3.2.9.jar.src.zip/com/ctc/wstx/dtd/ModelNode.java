package com.ctc.wstx.dtd;

import java.util.BitSet;
import java.util.List;

public abstract class ModelNode
{
  public abstract ModelNode cloneModel();
  
  public abstract boolean isNullable();
  
  public abstract void indexTokens(List paramList);
  
  public abstract void addFirstPos(BitSet paramBitSet);
  
  public abstract void addLastPos(BitSet paramBitSet);
  
  public abstract void calcFollowPos(BitSet[] paramArrayOfBitSet);
}


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\ModelNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */