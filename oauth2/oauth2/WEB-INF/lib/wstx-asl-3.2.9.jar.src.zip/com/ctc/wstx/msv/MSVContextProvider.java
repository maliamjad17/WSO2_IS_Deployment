/*    */ package com.ctc.wstx.msv;
/*    */ 
/*    */ import com.sun.msv.grammar.IDContextProvider2;
/*    */ import com.sun.msv.verifier.regexp.StringToken;
/*    */ import org.codehaus.stax2.validation.ValidationContext;
/*    */ import org.relaxng.datatype.Datatype;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MSVContextProvider
/*    */   implements IDContextProvider2
/*    */ {
/*    */   final ValidationContext mContext;
/*    */   
/*    */   public MSVContextProvider(ValidationContext ctxt)
/*    */   {
/* 38 */     this.mContext = ctxt;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getBaseUri()
/*    */   {
/* 51 */     return this.mContext.getBaseUri();
/*    */   }
/*    */   
/*    */   public boolean isNotation(String notationName)
/*    */   {
/* 56 */     return this.mContext.isNotationDeclared(notationName);
/*    */   }
/*    */   
/*    */   public boolean isUnparsedEntity(String entityName)
/*    */   {
/* 61 */     return this.mContext.isUnparsedEntityDeclared(entityName);
/*    */   }
/*    */   
/*    */   public String resolveNamespacePrefix(String prefix)
/*    */   {
/* 66 */     return this.mContext.getNamespaceURI(prefix);
/*    */   }
/*    */   
/*    */   public void onID(Datatype datatype, StringToken literal) {}
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\msv\MSVContextProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */