/*    */ package com.ctc.wstx.util;
/*    */ 
/*    */ import com.ctc.wstx.compat.JdkFeatures;
/*    */ import com.ctc.wstx.compat.JdkImpl;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SimpleCache
/*    */ {
/*    */   final Map mItems;
/*    */   final int mMaxSize;
/*    */   
/*    */   public SimpleCache(int maxSize)
/*    */   {
/* 33 */     this.mItems = JdkFeatures.getInstance().getLRULimitMap(maxSize);
/* 34 */     this.mMaxSize = maxSize;
/*    */   }
/*    */   
/*    */   public Object find(Object key) {
/* 38 */     return this.mItems.get(key);
/*    */   }
/*    */   
/*    */   public void add(Object key, Object value)
/*    */   {
/* 43 */     this.mItems.put(key, value);
/*    */     
/*    */ 
/*    */ 
/* 47 */     if (this.mItems.size() >= this.mMaxSize)
/*    */     {
/* 49 */       Iterator it = this.mItems.entrySet().iterator();
/* 50 */       while (it.hasNext()) {
/* 51 */         Object foo = it.next();
/* 52 */         it.remove();
/* 53 */         if (this.mItems.size() < this.mMaxSize) {
/*    */           break;
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\util\SimpleCache.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */