/*      */ package com.ctc.wstx.sax;
/*      */ 
/*      */ import com.ctc.wstx.api.ReaderConfig;
/*      */ import com.ctc.wstx.dtd.DTDEventListener;
/*      */ import com.ctc.wstx.exc.WstxIOException;
/*      */ import com.ctc.wstx.io.InputBootstrapper;
/*      */ import com.ctc.wstx.io.ReaderBootstrapper;
/*      */ import com.ctc.wstx.io.StreamBootstrapper;
/*      */ import com.ctc.wstx.sr.AttributeCollector;
/*      */ import com.ctc.wstx.sr.BasicStreamReader;
/*      */ import com.ctc.wstx.sr.InputElementStack;
/*      */ import com.ctc.wstx.stax.WstxInputFactory;
/*      */ import com.ctc.wstx.util.URLUtil;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.io.Reader;
/*      */ import java.net.URL;
/*      */ import java.util.Locale;
/*      */ import javax.xml.parsers.SAXParser;
/*      */ import javax.xml.stream.Location;
/*      */ import javax.xml.stream.XMLResolver;
/*      */ import javax.xml.stream.XMLStreamException;
/*      */ import org.codehaus.stax2.DTDInfo;
/*      */ import org.xml.sax.AttributeList;
/*      */ import org.xml.sax.Attributes;
/*      */ import org.xml.sax.ContentHandler;
/*      */ import org.xml.sax.DTDHandler;
/*      */ import org.xml.sax.DocumentHandler;
/*      */ import org.xml.sax.EntityResolver;
/*      */ import org.xml.sax.ErrorHandler;
/*      */ import org.xml.sax.HandlerBase;
/*      */ import org.xml.sax.InputSource;
/*      */ import org.xml.sax.Locator;
/*      */ import org.xml.sax.Parser;
/*      */ import org.xml.sax.SAXException;
/*      */ import org.xml.sax.SAXNotRecognizedException;
/*      */ import org.xml.sax.SAXNotSupportedException;
/*      */ import org.xml.sax.SAXParseException;
/*      */ import org.xml.sax.XMLReader;
/*      */ import org.xml.sax.ext.Attributes2;
/*      */ import org.xml.sax.ext.DeclHandler;
/*      */ import org.xml.sax.ext.LexicalHandler;
/*      */ import org.xml.sax.ext.Locator2;
/*      */ import org.xml.sax.helpers.DefaultHandler;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class WstxSAXParser
/*      */   extends SAXParser
/*      */   implements Parser, XMLReader, Attributes2, Locator2, DTDEventListener
/*      */ {
/*      */   static final boolean FEAT_DEFAULT_NS_PREFIXES = false;
/*      */   final WstxInputFactory mStaxFactory;
/*      */   final ReaderConfig mConfig;
/*      */   boolean mFeatNsPrefixes;
/*      */   BasicStreamReader mScanner;
/*      */   AttributeCollector mAttrCollector;
/*      */   InputElementStack mElemStack;
/*      */   String mEncoding;
/*      */   String mXmlVersion;
/*      */   boolean mStandalone;
/*      */   protected ContentHandler mContentHandler;
/*      */   protected DTDHandler mDTDHandler;
/*      */   private EntityResolver mEntityResolver;
/*      */   private ErrorHandler mErrorHandler;
/*      */   private LexicalHandler mLexicalHandler;
/*      */   private DeclHandler mDeclHandler;
/*      */   private int mAttrCount;
/*  117 */   private int mNsCount = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   WstxSAXParser(WstxInputFactory sf, boolean nsPrefixes)
/*      */   {
/*  127 */     this.mStaxFactory = sf;
/*  128 */     this.mFeatNsPrefixes = nsPrefixes;
/*  129 */     this.mConfig = sf.createPrivateConfig();
/*  130 */     this.mConfig.doSupportDTDs(true);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  136 */     ResolverProxy r = new ResolverProxy();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  141 */     this.mConfig.setDtdResolver(r);
/*  142 */     this.mConfig.setEntityResolver(r);
/*  143 */     this.mConfig.setDTDEventListener(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WstxSAXParser()
/*      */   {
/*  156 */     this(new WstxInputFactory(), false);
/*      */   }
/*      */   
/*      */   public final Parser getParser()
/*      */   {
/*  161 */     return this;
/*      */   }
/*      */   
/*      */   public final XMLReader getXMLReader()
/*      */   {
/*  166 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isNamespaceAware()
/*      */   {
/*  176 */     return this.mConfig.willSupportNamespaces();
/*      */   }
/*      */   
/*      */   public boolean isValidating() {
/*  180 */     return this.mConfig.willValidateWithDTD();
/*      */   }
/*      */   
/*      */   public Object getProperty(String name)
/*      */     throws SAXNotRecognizedException, SAXNotSupportedException
/*      */   {
/*  186 */     SAXProperty prop = SAXProperty.findByUri(name);
/*  187 */     if (prop == SAXProperty.DECLARATION_HANDLER)
/*  188 */       return this.mDeclHandler;
/*  189 */     if (prop == SAXProperty.DOCUMENT_XML_VERSION)
/*  190 */       return this.mXmlVersion;
/*  191 */     if (prop == SAXProperty.DOM_NODE)
/*  192 */       return null;
/*  193 */     if (prop == SAXProperty.LEXICAL_HANDLER)
/*  194 */       return this.mLexicalHandler;
/*  195 */     if (prop == SAXProperty.XML_STRING) {
/*  196 */       return null;
/*      */     }
/*      */     
/*  199 */     throw new SAXNotRecognizedException("Property '" + name + "' not recognized");
/*      */   }
/*      */   
/*      */   public void setProperty(String name, Object value)
/*      */     throws SAXNotRecognizedException, SAXNotSupportedException
/*      */   {
/*  205 */     SAXProperty prop = SAXProperty.findByUri(name);
/*  206 */     if (prop == SAXProperty.DECLARATION_HANDLER) {
/*  207 */       this.mDeclHandler = ((DeclHandler)value);
/*  208 */       return; }
/*  209 */     if (prop != SAXProperty.DOCUMENT_XML_VERSION)
/*      */     {
/*  211 */       if (prop != SAXProperty.DOM_NODE)
/*      */       {
/*  213 */         if (prop == SAXProperty.LEXICAL_HANDLER) {
/*  214 */           this.mLexicalHandler = ((LexicalHandler)value);
/*  215 */           return; }
/*  216 */         if (prop != SAXProperty.XML_STRING)
/*      */         {
/*      */ 
/*  219 */           throw new SAXNotRecognizedException("Property '" + name + "' not recognized");
/*      */         }
/*      */       }
/*      */     }
/*  223 */     throw new SAXNotSupportedException("Property '" + name + "' is read-only, can not be modified");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void parse(InputSource is, HandlerBase hb)
/*      */     throws SAXException, IOException
/*      */   {
/*  240 */     if (hb != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  245 */       if (this.mContentHandler == null) {
/*  246 */         setDocumentHandler(hb);
/*      */       }
/*  248 */       if (this.mEntityResolver == null) {
/*  249 */         setEntityResolver(hb);
/*      */       }
/*  251 */       if (this.mErrorHandler == null) {
/*  252 */         setErrorHandler(hb);
/*      */       }
/*  254 */       if (this.mDTDHandler == null) {
/*  255 */         setDTDHandler(hb);
/*      */       }
/*      */     }
/*  258 */     parse(is);
/*      */   }
/*      */   
/*      */   public void parse(InputSource is, DefaultHandler dh)
/*      */     throws SAXException, IOException
/*      */   {
/*  264 */     if (dh != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  269 */       if (this.mContentHandler == null) {
/*  270 */         setContentHandler(dh);
/*      */       }
/*  272 */       if (this.mEntityResolver == null) {
/*  273 */         setEntityResolver(dh);
/*      */       }
/*  275 */       if (this.mErrorHandler == null) {
/*  276 */         setErrorHandler(dh);
/*      */       }
/*  278 */       if (this.mDTDHandler == null) {
/*  279 */         setDTDHandler(dh);
/*      */       }
/*      */     }
/*  282 */     parse(is);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ContentHandler getContentHandler()
/*      */   {
/*  293 */     return this.mContentHandler;
/*      */   }
/*      */   
/*      */   public DTDHandler getDTDHandler()
/*      */   {
/*  298 */     return this.mDTDHandler;
/*      */   }
/*      */   
/*      */   public EntityResolver getEntityResolver()
/*      */   {
/*  303 */     return this.mEntityResolver;
/*      */   }
/*      */   
/*      */   public ErrorHandler getErrorHandler()
/*      */   {
/*  308 */     return this.mErrorHandler;
/*      */   }
/*      */   
/*      */   public boolean getFeature(String name)
/*      */     throws SAXNotRecognizedException
/*      */   {
/*  314 */     SAXFeature stdFeat = SAXFeature.findByUri(name);
/*      */     
/*  316 */     if (stdFeat == SAXFeature.EXTERNAL_GENERAL_ENTITIES)
/*  317 */       return this.mConfig.willSupportExternalEntities();
/*  318 */     if (stdFeat == SAXFeature.EXTERNAL_PARAMETER_ENTITIES)
/*  319 */       return this.mConfig.willSupportExternalEntities();
/*  320 */     if (stdFeat == SAXFeature.IS_STANDALONE)
/*  321 */       return this.mStandalone;
/*  322 */     if (stdFeat == SAXFeature.LEXICAL_HANDLER_PARAMETER_ENTITIES)
/*      */     {
/*  324 */       return false; }
/*  325 */     if (stdFeat == SAXFeature.NAMESPACES)
/*  326 */       return this.mConfig.willSupportNamespaces();
/*  327 */     if (stdFeat == SAXFeature.NAMESPACE_PREFIXES)
/*  328 */       return !this.mConfig.willSupportNamespaces();
/*  329 */     if (stdFeat == SAXFeature.RESOLVE_DTD_URIS)
/*      */     {
/*  331 */       return false; }
/*  332 */     if (stdFeat == SAXFeature.STRING_INTERNING)
/*  333 */       return true;
/*  334 */     if (stdFeat == SAXFeature.UNICODE_NORMALIZATION_CHECKING)
/*  335 */       return false;
/*  336 */     if (stdFeat == SAXFeature.USE_ATTRIBUTES2)
/*  337 */       return true;
/*  338 */     if (stdFeat == SAXFeature.USE_LOCATOR2)
/*  339 */       return true;
/*  340 */     if (stdFeat == SAXFeature.USE_ENTITY_RESOLVER2)
/*  341 */       return true;
/*  342 */     if (stdFeat == SAXFeature.VALIDATION)
/*  343 */       return this.mConfig.willValidateWithDTD();
/*  344 */     if (stdFeat == SAXFeature.XMLNS_URIS)
/*      */     {
/*      */ 
/*      */ 
/*  348 */       return true; }
/*  349 */     if (stdFeat == SAXFeature.XML_1_1) {
/*  350 */       return true;
/*      */     }
/*      */     
/*  353 */     throw new SAXNotRecognizedException("Feature '" + name + "' not recognized");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setContentHandler(ContentHandler handler)
/*      */   {
/*  367 */     this.mContentHandler = handler;
/*      */   }
/*      */   
/*      */   public void setDTDHandler(DTDHandler handler)
/*      */   {
/*  372 */     this.mDTDHandler = handler;
/*      */   }
/*      */   
/*      */   public void setEntityResolver(EntityResolver resolver)
/*      */   {
/*  377 */     this.mEntityResolver = resolver;
/*      */   }
/*      */   
/*      */   public void setErrorHandler(ErrorHandler handler)
/*      */   {
/*  382 */     this.mErrorHandler = handler;
/*      */   }
/*      */   
/*      */   public void setFeature(String name, boolean value)
/*      */     throws SAXNotRecognizedException, SAXNotSupportedException
/*      */   {
/*  388 */     boolean invalidValue = false;
/*  389 */     boolean readOnly = false;
/*  390 */     SAXFeature stdFeat = SAXFeature.findByUri(name);
/*      */     
/*  392 */     if (stdFeat == SAXFeature.EXTERNAL_GENERAL_ENTITIES) {
/*  393 */       this.mConfig.doSupportExternalEntities(value);
/*  394 */     } else if (stdFeat != SAXFeature.EXTERNAL_PARAMETER_ENTITIES)
/*      */     {
/*  396 */       if (stdFeat == SAXFeature.IS_STANDALONE) {
/*  397 */         readOnly = true;
/*  398 */       } else if (stdFeat != SAXFeature.LEXICAL_HANDLER_PARAMETER_ENTITIES)
/*      */       {
/*  400 */         if (stdFeat == SAXFeature.NAMESPACES) {
/*  401 */           this.mConfig.doSupportNamespaces(value);
/*  402 */         } else if (stdFeat == SAXFeature.NAMESPACE_PREFIXES) {
/*  403 */           this.mFeatNsPrefixes = value;
/*  404 */         } else if (stdFeat != SAXFeature.RESOLVE_DTD_URIS)
/*      */         {
/*  406 */           if (stdFeat == SAXFeature.STRING_INTERNING) {
/*  407 */             invalidValue = !value;
/*  408 */           } else if (stdFeat == SAXFeature.UNICODE_NORMALIZATION_CHECKING) {
/*  409 */             invalidValue = value;
/*  410 */           } else if (stdFeat == SAXFeature.USE_ATTRIBUTES2) {
/*  411 */             readOnly = true;
/*  412 */           } else if (stdFeat == SAXFeature.USE_LOCATOR2) {
/*  413 */             readOnly = true;
/*  414 */           } else if (stdFeat == SAXFeature.USE_ENTITY_RESOLVER2) {
/*  415 */             readOnly = true;
/*  416 */           } else if (stdFeat == SAXFeature.VALIDATION) {
/*  417 */             this.mConfig.doValidateWithDTD(value);
/*  418 */           } else if (stdFeat == SAXFeature.XMLNS_URIS) {
/*  419 */             invalidValue = !value;
/*  420 */           } else if (stdFeat == SAXFeature.XML_1_1) {
/*  421 */             readOnly = true;
/*      */           } else
/*  423 */             throw new SAXNotRecognizedException("Feature '" + name + "' not recognized");
/*      */         }
/*      */       }
/*      */     }
/*  427 */     if (readOnly) {
/*  428 */       throw new SAXNotSupportedException("Feature '" + name + "' is read-only, can not be modified");
/*      */     }
/*  430 */     if (invalidValue) {
/*  431 */       throw new SAXNotSupportedException("Trying to set invalid value for feature '" + name + "', '" + value + "'");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void parse(InputSource input)
/*      */     throws SAXException
/*      */   {
/*  447 */     this.mScanner = null;
/*  448 */     String systemId = input.getSystemId();
/*  449 */     ReaderConfig cfg = this.mConfig;
/*  450 */     URL srcUrl = null;
/*      */     
/*      */ 
/*  453 */     InputStream is = null;
/*  454 */     Reader r = input.getCharacterStream();
/*  455 */     if (r == null) {
/*  456 */       is = input.getByteStream();
/*  457 */       if (is == null) {
/*  458 */         if (systemId == null) {
/*  459 */           throw new SAXException("Invalid InputSource passed: neither character or byte stream passed, nor system id specified");
/*      */         }
/*      */         try {
/*  462 */           srcUrl = URLUtil.urlFromSystemId(systemId);
/*  463 */           is = URLUtil.optimizedStreamFromURL(srcUrl);
/*      */         } catch (IOException ioe) {
/*  465 */           SAXException saxe = new SAXException(ioe);
/*  466 */           saxe.initCause(ioe);
/*  467 */           throw saxe;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  472 */     if (this.mContentHandler != null) {
/*  473 */       this.mContentHandler.setDocumentLocator(this);
/*  474 */       this.mContentHandler.startDocument();
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  479 */       String inputEnc = input.getEncoding();
/*  480 */       String publicId = input.getPublicId();
/*  481 */       InputBootstrapper bs; InputBootstrapper bs; if (r != null) {
/*  482 */         bs = ReaderBootstrapper.getInstance(r, publicId, systemId, inputEnc);
/*      */       } else {
/*  484 */         bs = StreamBootstrapper.getInstance(is, publicId, systemId);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  489 */       cfg.resetState();
/*      */       
/*  491 */       this.mScanner = ((BasicStreamReader)this.mStaxFactory.createSR(cfg, systemId, bs, false, false));
/*      */       
/*      */ 
/*      */ 
/*  495 */       String enc2 = this.mScanner.getEncoding();
/*  496 */       if (enc2 == null) {
/*  497 */         enc2 = this.mScanner.getCharacterEncodingScheme();
/*      */       }
/*  499 */       this.mEncoding = enc2;
/*      */       
/*  501 */       this.mXmlVersion = this.mScanner.getVersion();
/*  502 */       this.mStandalone = this.mScanner.standaloneSet();
/*  503 */       this.mAttrCollector = this.mScanner.getAttributeCollector();
/*  504 */       this.mElemStack = this.mScanner.getInputElementStack();
/*  505 */       fireEvents();
/*      */     } catch (IOException io) {
/*  507 */       throwSaxException(io);
/*      */     } catch (XMLStreamException strex) {
/*  509 */       throwSaxException(strex);
/*      */     } finally {
/*  511 */       if (this.mContentHandler != null) {
/*  512 */         this.mContentHandler.endDocument();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  517 */       if (this.mScanner != null) {
/*  518 */         BasicStreamReader sr = this.mScanner;
/*  519 */         this.mScanner = null;
/*      */         try {
/*  521 */           sr.close();
/*      */         } catch (XMLStreamException sex) {}
/*      */       }
/*  524 */       if (r != null) {
/*      */         try {
/*  526 */           r.close();
/*      */         } catch (IOException ioe) {}
/*      */       }
/*  529 */       if (is != null) {
/*      */         try {
/*  531 */           is.close();
/*      */         }
/*      */         catch (IOException ioe) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void parse(String systemId) throws SAXException
/*      */   {
/*  540 */     InputSource src = new InputSource(systemId);
/*  541 */     parse(src);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void fireEvents()
/*      */     throws IOException, SAXException, XMLStreamException
/*      */   {
/*  566 */     this.mConfig.doParseLazily(false);
/*      */     int type;
/*  568 */     while ((type = this.mScanner.next()) != 1) {
/*  569 */       fireAuxEvent(type, false);
/*      */     }
/*      */     
/*      */ 
/*  573 */     fireStartTag();
/*      */     
/*  575 */     int depth = 1;
/*      */     for (;;) {
/*  577 */       type = this.mScanner.next();
/*  578 */       if (type == 1) {
/*  579 */         fireStartTag();
/*  580 */         depth++;
/*  581 */       } else if (type == 2) {
/*  582 */         this.mScanner.fireSaxEndElement(this.mContentHandler);
/*  583 */         depth--; if (depth < 1) {
/*      */           break;
/*      */         }
/*  586 */       } else if (type == 4) {
/*  587 */         this.mScanner.fireSaxCharacterEvents(this.mContentHandler);
/*      */       } else {
/*  589 */         fireAuxEvent(type, true);
/*      */       }
/*      */     }
/*      */     
/*      */     for (;;)
/*      */     {
/*  595 */       type = this.mScanner.next();
/*  596 */       if (type == 8) {
/*      */         break;
/*      */       }
/*  599 */       if (type != 6)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  604 */         fireAuxEvent(type, false);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private final void fireAuxEvent(int type, boolean inTree) throws IOException, SAXException, XMLStreamException
/*      */   {
/*  611 */     switch (type) {
/*      */     case 5: 
/*  613 */       this.mScanner.fireSaxCommentEvent(this.mLexicalHandler);
/*  614 */       break;
/*      */     case 12: 
/*  616 */       if (this.mLexicalHandler != null) {
/*  617 */         this.mLexicalHandler.startCDATA();
/*  618 */         this.mScanner.fireSaxCharacterEvents(this.mContentHandler);
/*  619 */         this.mLexicalHandler.endCDATA();
/*      */       } else {
/*  621 */         this.mScanner.fireSaxCharacterEvents(this.mContentHandler);
/*      */       }
/*  623 */       break;
/*      */     case 11: 
/*  625 */       if (this.mLexicalHandler != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  632 */         String rootName = this.mScanner.getDTDRootName();
/*  633 */         String sysId = this.mScanner.getDTDSystemId();
/*  634 */         String pubId = this.mScanner.getDTDPublicId();
/*  635 */         this.mLexicalHandler.startDTD(rootName, pubId, sysId);
/*      */         try
/*      */         {
/*  638 */           dtdInfo = this.mScanner.getDTDInfo();
/*      */         } catch (WrappedSaxException wse) { DTDInfo dtdInfo;
/*  640 */           throw wse.getSaxException();
/*      */         }
/*  642 */         this.mLexicalHandler.endDTD(); }
/*  643 */       break;
/*      */     
/*      */     case 3: 
/*  646 */       this.mScanner.fireSaxPIEvent(this.mContentHandler);
/*  647 */       break;
/*      */     
/*      */ 
/*      */     case 6: 
/*  651 */       if (inTree) {
/*  652 */         this.mScanner.fireSaxSpaceEvents(this.mContentHandler);
/*      */       }
/*      */       break;
/*      */     case 4: case 7: case 8: case 9: case 10: default: 
/*  656 */       if (type == 8) {
/*  657 */         throwSaxException("Unexpected end-of-input in " + (inTree ? "tree" : "prolog"));
/*      */       }
/*  659 */       throw new RuntimeException("Internal error: unexpected type, " + type);
/*      */     }
/*      */   }
/*      */   
/*      */   private final void fireStartTag()
/*      */     throws SAXException
/*      */   {
/*  666 */     this.mAttrCount = this.mAttrCollector.getCount();
/*  667 */     if (this.mFeatNsPrefixes)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  678 */       this.mNsCount = this.mElemStack.getCurrentNsCount();
/*      */     }
/*  680 */     this.mScanner.fireSaxStartElement(this.mContentHandler, this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDocumentHandler(DocumentHandler handler)
/*      */   {
/*  697 */     setContentHandler(new DocHandlerWrapper(handler));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLocale(Locale locale) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getIndex(String qName)
/*      */   {
/*  713 */     if (this.mElemStack == null) {
/*  714 */       return -1;
/*      */     }
/*  716 */     int ix = this.mElemStack.findAttributeIndex(null, qName);
/*      */     
/*  718 */     return ix;
/*      */   }
/*      */   
/*      */   public int getIndex(String uri, String localName)
/*      */   {
/*  723 */     if (this.mElemStack == null) {
/*  724 */       return -1;
/*      */     }
/*  726 */     int ix = this.mElemStack.findAttributeIndex(uri, localName);
/*      */     
/*  728 */     return ix;
/*      */   }
/*      */   
/*      */   public int getLength()
/*      */   {
/*  733 */     return this.mAttrCount + this.mNsCount;
/*      */   }
/*      */   
/*      */   public String getLocalName(int index)
/*      */   {
/*  738 */     if (index < this.mAttrCount) {
/*  739 */       return index < 0 ? null : this.mAttrCollector.getLocalName(index);
/*      */     }
/*  741 */     index -= this.mAttrCount;
/*  742 */     if (index < this.mNsCount)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  747 */       String prefix = this.mElemStack.getLocalNsPrefix(index);
/*  748 */       return (prefix == null) || (prefix.length() == 0) ? "xmlns" : prefix;
/*      */     }
/*      */     
/*  751 */     return null;
/*      */   }
/*      */   
/*      */   public String getQName(int index)
/*      */   {
/*  756 */     if (index < this.mAttrCount) {
/*  757 */       if (index < 0) {
/*  758 */         return null;
/*      */       }
/*  760 */       String prefix = this.mAttrCollector.getPrefix(index);
/*  761 */       String ln = this.mAttrCollector.getLocalName(index);
/*  762 */       return prefix + ":" + ln;
/*      */     }
/*      */     
/*  765 */     index -= this.mAttrCount;
/*  766 */     if (index < this.mNsCount)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  771 */       String prefix = this.mElemStack.getLocalNsPrefix(index);
/*  772 */       if ((prefix == null) || (prefix.length() == 0)) {
/*  773 */         return "xmlns";
/*      */       }
/*  775 */       return "xmlns:" + prefix;
/*      */     }
/*  777 */     return null;
/*      */   }
/*      */   
/*      */   public String getType(int index)
/*      */   {
/*  782 */     if (index < this.mAttrCount) {
/*  783 */       if (index < 0) {
/*  784 */         return null;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  790 */       String type = this.mElemStack.getAttributeType(index);
/*      */       
/*  792 */       if (type == "ENUMERATED") {
/*  793 */         type = "NMTOKEN";
/*      */       }
/*  795 */       return type;
/*      */     }
/*      */     
/*  798 */     index -= this.mAttrCount;
/*  799 */     if (index < this.mNsCount) {
/*  800 */       return "CDATA";
/*      */     }
/*  802 */     return null;
/*      */   }
/*      */   
/*      */   public String getType(String qName)
/*      */   {
/*  807 */     return getType(getIndex(qName));
/*      */   }
/*      */   
/*      */   public String getType(String uri, String localName)
/*      */   {
/*  812 */     return getType(getIndex(uri, localName));
/*      */   }
/*      */   
/*      */   public String getURI(int index)
/*      */   {
/*  817 */     if (index < this.mAttrCount) {
/*  818 */       if (index < 0) {
/*  819 */         return null;
/*      */       }
/*  821 */       String uri = this.mAttrCollector.getURI(index);
/*  822 */       return uri == null ? "" : uri;
/*      */     }
/*  824 */     if (index - this.mAttrCount < this.mNsCount) {
/*  825 */       return "http://www.w3.org/2000/xmlns/";
/*      */     }
/*  827 */     return null;
/*      */   }
/*      */   
/*      */   public String getValue(int index)
/*      */   {
/*  832 */     if (index < this.mAttrCount) {
/*  833 */       return index < 0 ? null : this.mAttrCollector.getValue(index);
/*      */     }
/*  835 */     index -= this.mAttrCount;
/*  836 */     if (index < this.mNsCount)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  841 */       String uri = this.mElemStack.getLocalNsURI(index);
/*  842 */       return uri == null ? "" : uri;
/*      */     }
/*  844 */     return null;
/*      */   }
/*      */   
/*      */   public String getValue(String qName)
/*      */   {
/*  849 */     return getValue(getIndex(qName));
/*      */   }
/*      */   
/*      */   public String getValue(String uri, String localName)
/*      */   {
/*  854 */     return getValue(getIndex(uri, localName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isDeclared(int index)
/*      */   {
/*  865 */     if (index < this.mAttrCount) {
/*  866 */       if (index >= 0)
/*      */       {
/*  868 */         return true;
/*      */       }
/*      */     } else {
/*  871 */       index -= this.mAttrCount;
/*  872 */       if (index < this.mNsCount)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  878 */         return true;
/*      */       }
/*      */     }
/*  881 */     throwNoSuchAttribute(index);
/*  882 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isDeclared(String qName)
/*      */   {
/*  887 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isDeclared(String uri, String localName)
/*      */   {
/*  892 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isSpecified(int index)
/*      */   {
/*  897 */     if (index < this.mAttrCount) {
/*  898 */       if (index >= 0) {
/*  899 */         return this.mAttrCollector.isSpecified(index);
/*      */       }
/*      */     } else {
/*  902 */       index -= this.mAttrCount;
/*  903 */       if (index < this.mNsCount)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  908 */         return true;
/*      */       }
/*      */     }
/*  911 */     throwNoSuchAttribute(index);
/*  912 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isSpecified(String qName)
/*      */   {
/*  917 */     int ix = getIndex(qName);
/*  918 */     if (ix < 0) {
/*  919 */       throw new IllegalArgumentException("No attribute with qName '" + qName + "'");
/*      */     }
/*  921 */     return isSpecified(ix);
/*      */   }
/*      */   
/*      */   public boolean isSpecified(String uri, String localName)
/*      */   {
/*  926 */     int ix = getIndex(uri, localName);
/*  927 */     if (ix < 0) {
/*  928 */       throw new IllegalArgumentException("No attribute with uri " + uri + ", local name '" + localName + "'");
/*      */     }
/*  930 */     return isSpecified(ix);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getColumnNumber()
/*      */   {
/*  941 */     if (this.mScanner != null) {
/*  942 */       Location loc = this.mScanner.getLocation();
/*  943 */       return loc.getColumnNumber();
/*      */     }
/*  945 */     return -1;
/*      */   }
/*      */   
/*      */   public int getLineNumber()
/*      */   {
/*  950 */     if (this.mScanner != null) {
/*  951 */       Location loc = this.mScanner.getLocation();
/*  952 */       return loc.getLineNumber();
/*      */     }
/*  954 */     return -1;
/*      */   }
/*      */   
/*      */   public String getPublicId()
/*      */   {
/*  959 */     if (this.mScanner != null) {
/*  960 */       Location loc = this.mScanner.getLocation();
/*  961 */       return loc.getPublicId();
/*      */     }
/*  963 */     return null;
/*      */   }
/*      */   
/*      */   public String getSystemId()
/*      */   {
/*  968 */     if (this.mScanner != null) {
/*  969 */       Location loc = this.mScanner.getLocation();
/*  970 */       return loc.getSystemId();
/*      */     }
/*  972 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getEncoding()
/*      */   {
/*  983 */     return this.mEncoding;
/*      */   }
/*      */   
/*      */   public String getXMLVersion()
/*      */   {
/*  988 */     return this.mXmlVersion;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean dtdReportComments()
/*      */   {
/*  999 */     return this.mLexicalHandler != null;
/*      */   }
/*      */   
/*      */   public void dtdComment(char[] data, int offset, int len)
/*      */   {
/* 1004 */     if (this.mLexicalHandler != null) {
/*      */       try {
/* 1006 */         this.mLexicalHandler.comment(data, offset, len);
/*      */       } catch (SAXException sex) {
/* 1008 */         throw new WrappedSaxException(sex);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void dtdProcessingInstruction(String target, String data)
/*      */   {
/* 1015 */     if (this.mContentHandler != null) {
/*      */       try {
/* 1017 */         this.mContentHandler.processingInstruction(target, data);
/*      */       } catch (SAXException sex) {
/* 1019 */         throw new WrappedSaxException(sex);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void dtdSkippedEntity(String name)
/*      */   {
/* 1026 */     if (this.mContentHandler != null) {
/*      */       try {
/* 1028 */         this.mContentHandler.skippedEntity(name);
/*      */       } catch (SAXException sex) {
/* 1030 */         throw new WrappedSaxException(sex);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void dtdNotationDecl(String name, String publicId, String systemId, URL baseURL)
/*      */     throws XMLStreamException
/*      */   {
/* 1039 */     if (this.mDTDHandler != null)
/*      */     {
/*      */ 
/*      */ 
/* 1043 */       if ((systemId != null) && (systemId.indexOf(':') < 0)) {
/*      */         try {
/* 1045 */           systemId = URLUtil.urlFromSystemId(systemId, baseURL).toExternalForm();
/*      */         } catch (IOException ioe) {
/* 1047 */           throw new WstxIOException(ioe);
/*      */         }
/*      */       }
/*      */       try {
/* 1051 */         this.mDTDHandler.notationDecl(name, publicId, systemId);
/*      */       } catch (SAXException sex) {
/* 1053 */         throw new WrappedSaxException(sex);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void dtdUnparsedEntityDecl(String name, String publicId, String systemId, String notationName, URL baseURL)
/*      */     throws XMLStreamException
/*      */   {
/* 1061 */     if (this.mDTDHandler != null)
/*      */     {
/* 1063 */       if (systemId.indexOf(':') < 0) {
/*      */         try {
/* 1065 */           systemId = URLUtil.urlFromSystemId(systemId, baseURL).toExternalForm();
/*      */         } catch (IOException ioe) {
/* 1067 */           throw new WstxIOException(ioe);
/*      */         }
/*      */       }
/*      */       try {
/* 1071 */         this.mDTDHandler.unparsedEntityDecl(name, publicId, systemId, notationName);
/*      */       } catch (SAXException sex) {
/* 1073 */         throw new WrappedSaxException(sex);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void attributeDecl(String eName, String aName, String type, String mode, String value)
/*      */   {
/* 1082 */     if (this.mDeclHandler != null) {
/*      */       try {
/* 1084 */         this.mDeclHandler.attributeDecl(eName, aName, type, mode, value);
/*      */       } catch (SAXException sex) {
/* 1086 */         throw new WrappedSaxException(sex);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void dtdElementDecl(String name, String model)
/*      */   {
/* 1093 */     if (this.mDeclHandler != null) {
/*      */       try {
/* 1095 */         this.mDeclHandler.elementDecl(name, model);
/*      */       } catch (SAXException sex) {
/* 1097 */         throw new WrappedSaxException(sex);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void dtdExternalEntityDecl(String name, String publicId, String systemId)
/*      */   {
/* 1104 */     if (this.mDeclHandler != null) {
/*      */       try {
/* 1106 */         this.mDeclHandler.externalEntityDecl(name, publicId, systemId);
/*      */       } catch (SAXException sex) {
/* 1108 */         throw new WrappedSaxException(sex);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void dtdInternalEntityDecl(String name, String value)
/*      */   {
/* 1115 */     if (this.mDeclHandler != null) {
/*      */       try {
/* 1117 */         this.mDeclHandler.internalEntityDecl(name, value);
/*      */       } catch (SAXException sex) {
/* 1119 */         throw new WrappedSaxException(sex);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void throwSaxException(Exception e)
/*      */     throws SAXException
/*      */   {
/* 1133 */     SAXParseException se = new SAXParseException(e.getMessage(), this, e);
/* 1134 */     se.initCause(e);
/* 1135 */     if (this.mErrorHandler != null) {
/* 1136 */       this.mErrorHandler.fatalError(se);
/*      */     }
/* 1138 */     throw se;
/*      */   }
/*      */   
/*      */   private void throwSaxException(String msg)
/*      */     throws SAXException
/*      */   {
/* 1144 */     SAXParseException se = new SAXParseException(msg, this);
/* 1145 */     if (this.mErrorHandler != null) {
/* 1146 */       this.mErrorHandler.fatalError(se);
/*      */     }
/* 1148 */     throw se;
/*      */   }
/*      */   
/*      */   private void throwNoSuchAttribute(int index)
/*      */   {
/* 1153 */     throw new IllegalArgumentException("No attribute with index " + index + " (have " + (this.mAttrCount + this.mNsCount) + " attributes)");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final class ResolverProxy
/*      */     implements XMLResolver
/*      */   {
/*      */     public ResolverProxy() {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Object resolveEntity(String publicID, String systemID, String baseURI, String namespace)
/*      */       throws XMLStreamException
/*      */     {
/* 1174 */       System.err.println("Resolve called, -> " + WstxSAXParser.this.mEntityResolver);
/* 1175 */       if (WstxSAXParser.this.mEntityResolver != null)
/*      */       {
/*      */         try
/*      */         {
/*      */ 
/* 1180 */           URL url = new URL(baseURI);
/* 1181 */           String ref = new URL(url, systemID).toExternalForm();
/* 1182 */           InputSource isrc = WstxSAXParser.this.mEntityResolver.resolveEntity(publicID, ref);
/* 1183 */           if (isrc != null)
/*      */           {
/* 1185 */             InputStream in = isrc.getByteStream();
/* 1186 */             if (in != null) {
/* 1187 */               return in;
/*      */             }
/* 1189 */             Reader r = isrc.getCharacterStream();
/* 1190 */             if (r != null) {
/* 1191 */               return r;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/* 1196 */           return null;
/*      */         } catch (Exception ex) {
/* 1198 */           throw new XMLStreamException(ex);
/*      */         }
/*      */       }
/* 1201 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final class DocHandlerWrapper
/*      */     implements ContentHandler
/*      */   {
/*      */     final DocumentHandler mDocHandler;
/*      */     
/*      */ 
/*      */ 
/* 1216 */     final WstxSAXParser.AttributesWrapper mAttrWrapper = new WstxSAXParser.AttributesWrapper();
/*      */     
/*      */     DocHandlerWrapper(DocumentHandler h)
/*      */     {
/* 1220 */       this.mDocHandler = h;
/*      */     }
/*      */     
/*      */     public void characters(char[] ch, int start, int length)
/*      */       throws SAXException
/*      */     {
/* 1226 */       this.mDocHandler.characters(ch, start, length);
/*      */     }
/*      */     
/*      */     public void endDocument() throws SAXException
/*      */     {
/* 1231 */       this.mDocHandler.endDocument();
/*      */     }
/*      */     
/*      */     public void endElement(String uri, String localName, String qName)
/*      */       throws SAXException
/*      */     {
/* 1237 */       if (qName == null) {
/* 1238 */         qName = localName;
/*      */       }
/* 1240 */       this.mDocHandler.endElement(qName);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void endPrefixMapping(String prefix) {}
/*      */     
/*      */ 
/*      */     public void ignorableWhitespace(char[] ch, int start, int length)
/*      */       throws SAXException
/*      */     {
/* 1251 */       this.mDocHandler.ignorableWhitespace(ch, start, length);
/*      */     }
/*      */     
/*      */     public void processingInstruction(String target, String data)
/*      */       throws SAXException
/*      */     {
/* 1257 */       this.mDocHandler.processingInstruction(target, data);
/*      */     }
/*      */     
/*      */     public void setDocumentLocator(Locator locator)
/*      */     {
/* 1262 */       this.mDocHandler.setDocumentLocator(locator);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void skippedEntity(String name) {}
/*      */     
/*      */ 
/*      */     public void startDocument()
/*      */       throws SAXException
/*      */     {
/* 1273 */       this.mDocHandler.startDocument();
/*      */     }
/*      */     
/*      */ 
/*      */     public void startElement(String uri, String localName, String qName, Attributes attrs)
/*      */       throws SAXException
/*      */     {
/* 1280 */       if (qName == null) {
/* 1281 */         qName = localName;
/*      */       }
/*      */       
/* 1284 */       this.mAttrWrapper.setAttributes(attrs);
/* 1285 */       this.mDocHandler.startElement(qName, this.mAttrWrapper);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void startPrefixMapping(String prefix, String uri) {}
/*      */   }
/*      */   
/*      */ 
/*      */   static final class AttributesWrapper
/*      */     implements AttributeList
/*      */   {
/*      */     Attributes mAttrs;
/*      */     
/*      */ 
/*      */     public void setAttributes(Attributes a)
/*      */     {
/* 1302 */       this.mAttrs = a;
/*      */     }
/*      */     
/*      */     public int getLength()
/*      */     {
/* 1307 */       return this.mAttrs.getLength();
/*      */     }
/*      */     
/*      */     public String getName(int i)
/*      */     {
/* 1312 */       String n = this.mAttrs.getQName(i);
/* 1313 */       return n == null ? this.mAttrs.getLocalName(i) : n;
/*      */     }
/*      */     
/*      */     public String getType(int i)
/*      */     {
/* 1318 */       return this.mAttrs.getType(i);
/*      */     }
/*      */     
/*      */     public String getType(String name)
/*      */     {
/* 1323 */       return this.mAttrs.getType(name);
/*      */     }
/*      */     
/*      */     public String getValue(int i)
/*      */     {
/* 1328 */       return this.mAttrs.getValue(i);
/*      */     }
/*      */     
/*      */     public String getValue(String name)
/*      */     {
/* 1333 */       return this.mAttrs.getValue(name);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sax\WstxSAXParser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */