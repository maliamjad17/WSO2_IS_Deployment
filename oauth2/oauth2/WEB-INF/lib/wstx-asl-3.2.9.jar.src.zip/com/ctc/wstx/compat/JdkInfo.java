/*     */ package com.ctc.wstx.compat;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JdkInfo
/*     */ {
/*     */   static final int JDK_INFO_UNKNOWN = 0;
/*     */   
/*     */   public static int getJDKVersion()
/*     */   {
/*  21 */     int id = 0;
/*     */     try
/*     */     {
/*  24 */       id = findVersion("java.specification.version");
/*  25 */       if (id == 0)
/*     */       {
/*  27 */         findVersion("java.vm.version");
/*  28 */         if (id == 0)
/*     */         {
/*  30 */           findVersion("java.version");
/*     */         }
/*     */       }
/*  33 */       return id;
/*     */     }
/*     */     catch (Throwable t) {
/*  36 */       System.err.println("Problems trying to access System properties: " + t);
/*     */     }
/*  38 */     return id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JdkImpl constructImpl(int version)
/*     */     throws Exception
/*     */   {
/*  48 */     Class cls = Class.forName("com.ctc.wstx.compat.Jdk" + version + "Impl");
/*  49 */     return (JdkImpl)cls.newInstance();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int findVersion(String propId)
/*     */   {
/*  60 */     String str = System.getProperty(propId);
/*  61 */     if ((str == null) || (str.length() < 3)) {
/*  62 */       return 0;
/*     */     }
/*  64 */     int ix = str.indexOf('.');
/*  65 */     if (ix < 1) {
/*  66 */       return 0;
/*     */     }
/*     */     int major;
/*     */     try {
/*  70 */       major = Integer.parseInt(str.substring(0, ix));
/*     */     } catch (NumberFormatException nex) {
/*  72 */       return 0;
/*     */     }
/*  74 */     if ((major < 1) || (major > 99)) {
/*  75 */       return 0;
/*     */     }
/*     */     
/*  78 */     str = str.substring(ix + 1);
/*  79 */     int len = str.length();
/*     */     
/*  81 */     if ((len < 1) || (str.charAt(0) < '0') || (str.charAt(0) > '9')) {
/*  82 */       return 0;
/*     */     }
/*  84 */     int med = 0;
/*  85 */     for (int i = 0; 
/*     */         
/*  87 */         i < len; i++) {
/*  88 */       char c = str.charAt(i);
/*  89 */       if ((c >= '0') && (c <= '9')) {
/*  90 */         med = med * 10 + (c - '0');
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */     if (med > 9) {
/* 100 */       return 0;
/*     */     }
/*     */     
/*     */ 
/* 104 */     return major * 100 + med;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\compat\JdkInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */