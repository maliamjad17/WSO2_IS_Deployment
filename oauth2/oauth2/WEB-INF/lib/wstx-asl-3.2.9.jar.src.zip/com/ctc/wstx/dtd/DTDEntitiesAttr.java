/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ import com.ctc.wstx.ent.EntityDecl;
/*     */ import com.ctc.wstx.io.WstxInputData;
/*     */ import com.ctc.wstx.sr.InputProblemReporter;
/*     */ import java.util.StringTokenizer;
/*     */ import org.codehaus.stax2.validation.XMLValidationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DTDEntitiesAttr
/*     */   extends DTDAttribute
/*     */ {
/*     */   public DTDEntitiesAttr(NameKey name, DefaultAttrValue defValue, int specIndex, boolean nsAware, boolean xml11)
/*     */   {
/*  37 */     super(name, defValue, specIndex, nsAware, xml11);
/*     */   }
/*     */   
/*     */   public DTDAttribute cloneWith(int specIndex)
/*     */   {
/*  42 */     return new DTDEntitiesAttr(this.mName, this.mDefValue, specIndex, this.mCfgNsAware, this.mCfgXml11);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getValueType()
/*     */   {
/*  52 */     return 6;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validate(DTDValidatorBase v, char[] cbuf, int start, int end, boolean normalize)
/*     */     throws XMLValidationException
/*     */   {
/*  75 */     while ((start < end) && (WstxInputData.isSpaceChar(cbuf[start]))) {
/*  76 */       start++;
/*     */     }
/*     */     
/*     */ 
/*  80 */     if (start >= end) {
/*  81 */       return reportValidationProblem(v, "Empty ENTITIES value");
/*     */     }
/*  83 */     end--;
/*  84 */     while ((end > start) && (WstxInputData.isSpaceChar(cbuf[end]))) {
/*  85 */       end--;
/*     */     }
/*     */     
/*     */ 
/*  89 */     String idStr = null;
/*  90 */     StringBuffer sb = null;
/*  92 */     for (; 
/*  92 */         start <= end; 
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 135 */         goto 257)
/*     */     {
/*  94 */       char c = cbuf[start];
/*  95 */       if (!WstxInputData.isNameStartChar(c, this.mCfgNsAware, this.mCfgXml11)) {
/*  96 */         return reportInvalidChar(v, c, "not valid as the first ENTITIES character");
/*     */       }
/*  98 */       int hash = c;
/*  99 */       for (int i = start + 1; 
/* 100 */           i <= end; i++) {
/* 101 */         c = cbuf[i];
/* 102 */         if (WstxInputData.isSpaceChar(c)) {
/*     */           break;
/*     */         }
/* 105 */         if (!WstxInputData.isNameChar(c, this.mCfgNsAware, this.mCfgXml11)) {
/* 106 */           return reportInvalidChar(v, c, "not valid as an ENTITIES character");
/*     */         }
/* 108 */         hash = hash * 31 + c;
/*     */       }
/*     */       
/* 111 */       EntityDecl ent = findEntityDecl(v, cbuf, start, i - start, hash);
/*     */       
/*     */ 
/*     */ 
/* 115 */       start = i + 1;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 120 */       if (normalize) {
/* 121 */         if (idStr == null) {
/* 122 */           idStr = ent.getName();
/*     */         } else {
/* 124 */           if (sb == null) {
/* 125 */             sb = new StringBuffer(idStr);
/*     */           }
/* 127 */           idStr = ent.getName();
/* 128 */           sb.append(' ');
/* 129 */           sb.append(idStr);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 134 */       if ((start <= end) && (WstxInputData.isSpaceChar(cbuf[start]))) {
/* 135 */         start++;
/*     */       }
/*     */     }
/*     */     
/* 139 */     if (normalize) {
/* 140 */       if (sb != null) {
/* 141 */         idStr = sb.toString();
/*     */       }
/* 143 */       return idStr;
/*     */     }
/*     */     
/* 146 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validateDefault(InputProblemReporter rep, boolean normalize)
/*     */     throws XMLValidationException
/*     */   {
/* 157 */     String normStr = validateDefaultNames(rep, true);
/* 158 */     if (normalize) {
/* 159 */       this.mDefValue.setValue(normStr);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 168 */     StringTokenizer st = new StringTokenizer(normStr);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 173 */     MinimalDTDReader dtdr = (MinimalDTDReader)rep;
/* 174 */     while (st.hasMoreTokens()) {
/* 175 */       String str = st.nextToken();
/* 176 */       EntityDecl ent = dtdr.findEntity(str);
/*     */       
/* 178 */       checkEntity(rep, normStr, ent);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\DTDEntitiesAttr.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */