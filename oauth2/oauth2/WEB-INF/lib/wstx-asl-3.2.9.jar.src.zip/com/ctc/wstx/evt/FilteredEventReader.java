/*     */ package com.ctc.wstx.evt;
/*     */ 
/*     */ import com.ctc.wstx.exc.WstxLazyException;
/*     */ import com.ctc.wstx.util.ExceptionUtil;
/*     */ import javax.xml.stream.EventFilter;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLStreamConstants;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilteredEventReader
/*     */   implements XMLEventReader, XMLStreamConstants
/*     */ {
/*     */   final XMLEventReader mReader;
/*     */   final EventFilter mFilter;
/*     */   XMLEvent mNextEvent;
/*     */   
/*     */   public FilteredEventReader(XMLEventReader r, EventFilter f)
/*     */   {
/*  38 */     this.mReader = r;
/*  39 */     this.mFilter = f;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws XMLStreamException
/*     */   {
/*  51 */     this.mReader.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getElementText()
/*     */     throws XMLStreamException
/*     */   {
/*  60 */     return this.mReader.getElementText();
/*     */   }
/*     */   
/*     */   public Object getProperty(String name) {
/*  64 */     return this.mReader.getProperty(name);
/*     */   }
/*     */   
/*     */   public boolean hasNext()
/*     */   {
/*     */     try {
/*  70 */       return peek() != null;
/*     */     } catch (XMLStreamException sex) {
/*  72 */       WstxLazyException.throwLazily(sex); }
/*  73 */     return false;
/*     */   }
/*     */   
/*     */   public XMLEvent nextEvent()
/*     */     throws XMLStreamException
/*     */   {
/*     */     for (;;)
/*     */     {
/*  81 */       XMLEvent evt = this.mReader.nextEvent();
/*  82 */       if ((evt == null) || (this.mFilter.accept(evt)))
/*     */       {
/*  84 */         return evt;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Object next()
/*     */   {
/*     */     try {
/*  92 */       return nextEvent();
/*     */     } catch (XMLStreamException sex) {
/*  94 */       ExceptionUtil.throwRuntimeException(sex); }
/*  95 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public XMLEvent nextTag()
/*     */     throws XMLStreamException
/*     */   {
/*     */     for (;;)
/*     */     {
/* 105 */       XMLEvent evt = this.mReader.nextTag();
/* 106 */       if ((evt == null) || (this.mFilter.accept(evt))) {
/* 107 */         return evt;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLEvent peek()
/*     */     throws XMLStreamException
/*     */   {
/*     */     for (;;)
/*     */     {
/* 120 */       XMLEvent evt = this.mReader.peek();
/* 121 */       if ((evt == null) || (this.mFilter.accept(evt))) {
/* 122 */         return evt;
/*     */       }
/*     */       
/* 125 */       this.mReader.nextEvent();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void remove()
/*     */   {
/* 133 */     this.mReader.remove();
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\evt\FilteredEventReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */