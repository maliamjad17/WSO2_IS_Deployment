/*     */ package com.ctc.wstx.api;
/*     */ 
/*     */ import com.ctc.wstx.cfg.OutputConfigFlags;
/*     */ import com.ctc.wstx.io.BufferRecycler;
/*     */ import com.ctc.wstx.util.ArgUtil;
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.util.HashMap;
/*     */ import javax.xml.stream.XMLReporter;
/*     */ import org.codehaus.stax2.io.EscapingWriterFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WriterConfig
/*     */   extends CommonConfig
/*     */   implements OutputConfigFlags
/*     */ {
/*     */   protected static final String DEFAULT_AUTOMATIC_NS_PREFIX = "wstxns";
/*     */   static final int PROP_AUTOMATIC_NS = 1;
/*     */   static final int PROP_AUTOMATIC_EMPTY_ELEMENTS = 2;
/*     */   static final int PROP_ENABLE_NS = 3;
/*     */   static final int PROP_AUTOMATIC_NS_PREFIX = 4;
/*     */   static final int PROP_TEXT_ESCAPER = 5;
/*     */   static final int PROP_ATTR_VALUE_ESCAPER = 6;
/*     */   static final int PROP_PROBLEM_REPORTER = 7;
/*     */   static final int PROP_OUTPUT_CDATA_AS_TEXT = 11;
/*     */   static final int PROP_COPY_DEFAULT_ATTRS = 12;
/*     */   static final int PROP_ESCAPE_CR = 13;
/*     */   static final int PROP_AUTOMATIC_END_ELEMENTS = 14;
/*     */   static final int PROP_VALIDATE_STRUCTURE = 15;
/*     */   static final int PROP_VALIDATE_CONTENT = 16;
/*     */   static final int PROP_VALIDATE_ATTR = 17;
/*     */   static final int PROP_VALIDATE_NAMES = 18;
/*     */   static final int PROP_FIX_CONTENT = 19;
/*     */   static final int PROP_UNDERLYING_STREAM = 30;
/*     */   static final int PROP_UNDERLYING_WRITER = 31;
/*     */   static final boolean DEFAULT_ENABLE_NS = true;
/*     */   static final boolean DEFAULT_AUTOMATIC_EMPTY_ELEMENTS = true;
/*     */   static final boolean DEFAULT_OUTPUT_CDATA_AS_TEXT = false;
/*     */   static final boolean DEFAULT_COPY_DEFAULT_ATTRS = false;
/*     */   static final boolean DEFAULT_ESCAPE_CR = true;
/*     */   static final boolean DEFAULT_VALIDATE_STRUCTURE = true;
/*     */   static final boolean DEFAULT_VALIDATE_CONTENT = true;
/*     */   static final boolean DEFAULT_VALIDATE_ATTR = false;
/*     */   static final boolean DEFAULT_VALIDATE_NAMES = false;
/*     */   static final boolean DEFAULT_FIX_CONTENT = true;
/*     */   static final int DEFAULT_FLAGS_J2ME = 5029;
/*     */   static final int DEFAULT_FLAGS_FULL = 5029;
/* 144 */   static final HashMap sProperties = new HashMap(8);
/*     */   final boolean mIsJ2MESubset;
/*     */   
/* 147 */   static { sProperties.put("javax.xml.stream.isRepairingNamespaces", new Integer(1));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 153 */     sProperties.put("javax.xml.stream.isNamespaceAware", new Integer(3));
/*     */     
/*     */ 
/*     */ 
/* 157 */     sProperties.put("org.codehaus.stax2.automaticEmptyElements", new Integer(2));
/*     */     
/*     */ 
/* 160 */     sProperties.put("org.codehaus.stax2.automaticNsPrefix", new Integer(4));
/*     */     
/*     */ 
/* 163 */     sProperties.put("org.codehaus.stax2.textEscaper", new Integer(5));
/*     */     
/* 165 */     sProperties.put("org.codehaus.stax2.attrValueEscaper", new Integer(6));
/*     */     
/*     */ 
/* 168 */     sProperties.put("javax.xml.stream.reporter", new Integer(7));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 174 */     sProperties.put("com.ctc.wstx.outputCDataAsText", new Integer(11));
/*     */     
/* 176 */     sProperties.put("com.ctc.wstx.copyDefaultAttrs", new Integer(12));
/*     */     
/* 178 */     sProperties.put("com.ctc.wstx.outputEscapeCr", new Integer(13));
/*     */     
/* 180 */     sProperties.put("com.ctc.wstx.automaticEndElements", new Integer(14));
/*     */     
/*     */ 
/*     */ 
/* 184 */     sProperties.put("com.ctc.wstx.outputValidateStructure", new Integer(15));
/*     */     
/* 186 */     sProperties.put("com.ctc.wstx.outputValidateContent", new Integer(16));
/*     */     
/* 188 */     sProperties.put("com.ctc.wstx.outputValidateAttr", new Integer(17));
/*     */     
/* 190 */     sProperties.put("com.ctc.wstx.outputValidateNames", new Integer(18));
/*     */     
/* 192 */     sProperties.put("com.ctc.wstx.outputFixContent", new Integer(19));
/*     */     
/*     */ 
/*     */ 
/* 196 */     sProperties.put("com.ctc.wstx.outputUnderlyingStream", new Integer(30));
/*     */     
/* 198 */     sProperties.put("com.ctc.wstx.outputUnderlyingStream", new Integer(30));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int mConfigFlags;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String mAutoNsPrefix;
/*     */   
/*     */ 
/*     */ 
/* 214 */   protected EscapingWriterFactory mTextEscaperFactory = null;
/*     */   
/* 216 */   protected EscapingWriterFactory mAttrValueEscaperFactory = null;
/*     */   
/* 218 */   protected XMLReporter mProblemReporter = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 231 */   static final ThreadLocal mRecyclerRef = new ThreadLocal();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 239 */   BufferRecycler mCurrRecycler = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private WriterConfig(boolean j2meSubset, int flags, String autoNsPrefix, EscapingWriterFactory textEscaperF, EscapingWriterFactory attrValueEscaperF, XMLReporter problemReporter)
/*     */   {
/* 252 */     this.mIsJ2MESubset = j2meSubset;
/* 253 */     this.mConfigFlags = flags;
/* 254 */     this.mAutoNsPrefix = autoNsPrefix;
/* 255 */     this.mTextEscaperFactory = textEscaperF;
/* 256 */     this.mAttrValueEscaperFactory = attrValueEscaperF;
/* 257 */     this.mProblemReporter = problemReporter;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 264 */     SoftReference ref = (SoftReference)mRecyclerRef.get();
/* 265 */     if (ref != null) {
/* 266 */       this.mCurrRecycler = ((BufferRecycler)ref.get());
/*     */     }
/*     */   }
/*     */   
/*     */   public static WriterConfig createJ2MEDefaults()
/*     */   {
/* 272 */     WriterConfig rc = new WriterConfig(true, 5029, "wstxns", null, null, null);
/*     */     
/*     */ 
/* 275 */     return rc;
/*     */   }
/*     */   
/*     */   public static WriterConfig createFullDefaults()
/*     */   {
/* 280 */     WriterConfig rc = new WriterConfig(true, 5029, "wstxns", null, null, null);
/*     */     
/*     */ 
/* 283 */     return rc;
/*     */   }
/*     */   
/*     */   public WriterConfig createNonShared()
/*     */   {
/* 288 */     WriterConfig rc = new WriterConfig(this.mIsJ2MESubset, this.mConfigFlags, this.mAutoNsPrefix, this.mTextEscaperFactory, this.mAttrValueEscaperFactory, this.mProblemReporter);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 293 */     return rc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int findPropertyId(String propName)
/*     */   {
/* 304 */     Integer I = (Integer)sProperties.get(propName);
/* 305 */     return I == null ? -1 : I.intValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getProperty(int id)
/*     */   {
/* 316 */     switch (id)
/*     */     {
/*     */ 
/*     */ 
/*     */     case 1: 
/* 321 */       return automaticNamespacesEnabled() ? Boolean.TRUE : Boolean.FALSE;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 3: 
/* 328 */       return willSupportNamespaces() ? Boolean.TRUE : Boolean.FALSE;
/*     */     case 7: 
/* 330 */       return getProblemReporter();
/*     */     
/*     */ 
/*     */     case 2: 
/* 334 */       return automaticEmptyElementsEnabled() ? Boolean.TRUE : Boolean.FALSE;
/*     */     case 4: 
/* 336 */       return getAutomaticNsPrefix();
/*     */     case 5: 
/* 338 */       return getTextEscaperFactory();
/*     */     case 6: 
/* 340 */       return getAttrValueEscaperFactory();
/*     */     
/*     */ 
/*     */ 
/*     */     case 11: 
/* 345 */       return willOutputCDataAsText() ? Boolean.TRUE : Boolean.FALSE;
/*     */     case 12: 
/* 347 */       return willCopyDefaultAttrs() ? Boolean.TRUE : Boolean.FALSE;
/*     */     case 13: 
/* 349 */       return willEscapeCr() ? Boolean.TRUE : Boolean.FALSE;
/*     */     case 14: 
/* 351 */       return automaticEndElementsEnabled() ? Boolean.TRUE : Boolean.FALSE;
/*     */     
/*     */     case 15: 
/* 354 */       return willValidateStructure() ? Boolean.TRUE : Boolean.FALSE;
/*     */     case 16: 
/* 356 */       return willValidateContent() ? Boolean.TRUE : Boolean.FALSE;
/*     */     case 17: 
/* 358 */       return willValidateAttributes() ? Boolean.TRUE : Boolean.FALSE;
/*     */     case 18: 
/* 360 */       return willValidateNames() ? Boolean.TRUE : Boolean.FALSE;
/*     */     case 19: 
/* 362 */       return willFixContent() ? Boolean.TRUE : Boolean.FALSE;
/*     */     
/*     */ 
/*     */     case 30: 
/*     */     case 31: 
/* 367 */       throw new IllegalStateException("Can not access per-stream-writer properties via factory");
/*     */     }
/*     */     
/* 370 */     throw new Error("Internal error: no handler for property with internal id " + id + ".");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean setProperty(String name, int id, Object value)
/*     */   {
/* 379 */     switch (id)
/*     */     {
/*     */ 
/*     */     case 1: 
/* 383 */       enableAutomaticNamespaces(ArgUtil.convertToBoolean(name, value));
/* 384 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */     case 3: 
/* 389 */       doSupportNamespaces(ArgUtil.convertToBoolean(name, value));
/* 390 */       break;
/*     */     case 7: 
/* 392 */       setProblemReporter((XMLReporter)value);
/* 393 */       break;
/*     */     
/*     */     case 2: 
/* 396 */       enableAutomaticEmptyElements(ArgUtil.convertToBoolean(name, value));
/* 397 */       break;
/*     */     
/*     */     case 4: 
/* 400 */       setAutomaticNsPrefix(value.toString());
/* 401 */       break;
/*     */     
/*     */     case 5: 
/* 404 */       setTextEscaperFactory((EscapingWriterFactory)value);
/* 405 */       break;
/*     */     
/*     */     case 6: 
/* 408 */       setAttrValueEscaperFactory((EscapingWriterFactory)value);
/* 409 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */     case 11: 
/* 414 */       doOutputCDataAsText(ArgUtil.convertToBoolean(name, value));
/* 415 */       break;
/*     */     case 12: 
/* 417 */       doCopyDefaultAttrs(ArgUtil.convertToBoolean(name, value));
/* 418 */       break;
/*     */     case 13: 
/* 420 */       doEscapeCr(ArgUtil.convertToBoolean(name, value));
/* 421 */       break;
/*     */     case 14: 
/* 423 */       enableAutomaticEndElements(ArgUtil.convertToBoolean(name, value));
/* 424 */       break;
/*     */     
/*     */     case 15: 
/* 427 */       doValidateStructure(ArgUtil.convertToBoolean(name, value));
/* 428 */       break;
/*     */     case 16: 
/* 430 */       doValidateContent(ArgUtil.convertToBoolean(name, value));
/* 431 */       break;
/*     */     case 17: 
/* 433 */       doValidateAttributes(ArgUtil.convertToBoolean(name, value));
/* 434 */       break;
/*     */     case 18: 
/* 436 */       doValidateNames(ArgUtil.convertToBoolean(name, value));
/* 437 */       break;
/*     */     case 19: 
/* 439 */       doFixContent(ArgUtil.convertToBoolean(name, value));
/* 440 */       break;
/*     */     
/*     */     case 30: 
/*     */     case 31: 
/* 444 */       throw new IllegalStateException("Can not modify per-stream-writer properties via factory");
/*     */     case 8: case 9: case 10: case 20: case 21: case 22: case 23: 
/*     */     case 24: case 25: case 26: case 27: case 28: case 29: default: 
/* 447 */       throw new Error("Internal error: no handler for property with internal id " + id + ".");
/*     */     }
/*     */     
/* 450 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getConfigFlags()
/*     */   {
/* 461 */     return this.mConfigFlags;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean automaticNamespacesEnabled()
/*     */   {
/* 467 */     return hasConfigFlag(2);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean automaticEmptyElementsEnabled()
/*     */   {
/* 473 */     return hasConfigFlag(4);
/*     */   }
/*     */   
/*     */   public boolean willSupportNamespaces() {
/* 477 */     return hasConfigFlag(1);
/*     */   }
/*     */   
/*     */   public boolean willOutputCDataAsText() {
/* 481 */     return hasConfigFlag(8);
/*     */   }
/*     */   
/*     */   public boolean willCopyDefaultAttrs() {
/* 485 */     return hasConfigFlag(16);
/*     */   }
/*     */   
/*     */   public boolean willEscapeCr() {
/* 489 */     return hasConfigFlag(32);
/*     */   }
/*     */   
/*     */   public boolean automaticEndElementsEnabled() {
/* 493 */     return hasConfigFlag(128);
/*     */   }
/*     */   
/*     */   public boolean willValidateStructure() {
/* 497 */     return hasConfigFlag(256);
/*     */   }
/*     */   
/*     */   public boolean willValidateContent() {
/* 501 */     return hasConfigFlag(512);
/*     */   }
/*     */   
/*     */   public boolean willValidateAttributes() {
/* 505 */     return hasConfigFlag(2048);
/*     */   }
/*     */   
/*     */   public boolean willValidateNames() {
/* 509 */     return hasConfigFlag(1024);
/*     */   }
/*     */   
/*     */   public boolean willFixContent() {
/* 513 */     return hasConfigFlag(4096);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAutomaticNsPrefix()
/*     */   {
/* 522 */     return this.mAutoNsPrefix;
/*     */   }
/*     */   
/*     */   public EscapingWriterFactory getTextEscaperFactory() {
/* 526 */     return this.mTextEscaperFactory;
/*     */   }
/*     */   
/*     */   public EscapingWriterFactory getAttrValueEscaperFactory() {
/* 530 */     return this.mAttrValueEscaperFactory;
/*     */   }
/*     */   
/*     */   public XMLReporter getProblemReporter() {
/* 534 */     return this.mProblemReporter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void enableAutomaticNamespaces(boolean state)
/*     */   {
/* 542 */     setConfigFlag(2, state);
/*     */   }
/*     */   
/*     */ 
/*     */   public void enableAutomaticEmptyElements(boolean state)
/*     */   {
/* 548 */     setConfigFlag(4, state);
/*     */   }
/*     */   
/*     */   public void doSupportNamespaces(boolean state) {
/* 552 */     setConfigFlag(1, state);
/*     */   }
/*     */   
/*     */   public void doOutputCDataAsText(boolean state) {
/* 556 */     setConfigFlag(8, state);
/*     */   }
/*     */   
/*     */   public void doCopyDefaultAttrs(boolean state) {
/* 560 */     setConfigFlag(16, state);
/*     */   }
/*     */   
/*     */   public void doEscapeCr(boolean state) {
/* 564 */     setConfigFlag(32, state);
/*     */   }
/*     */   
/*     */   public void enableAutomaticEndElements(boolean state) {
/* 568 */     setConfigFlag(128, state);
/*     */   }
/*     */   
/*     */   public void doValidateStructure(boolean state) {
/* 572 */     setConfigFlag(256, state);
/*     */   }
/*     */   
/*     */   public void doValidateContent(boolean state) {
/* 576 */     setConfigFlag(512, state);
/*     */   }
/*     */   
/*     */   public void doValidateAttributes(boolean state) {
/* 580 */     setConfigFlag(2048, state);
/*     */   }
/*     */   
/*     */   public void doValidateNames(boolean state) {
/* 584 */     setConfigFlag(1024, state);
/*     */   }
/*     */   
/*     */   public void doFixContent(boolean state) {
/* 588 */     setConfigFlag(4096, state);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutomaticNsPrefix(String prefix)
/*     */   {
/* 596 */     this.mAutoNsPrefix = prefix;
/*     */   }
/*     */   
/*     */   public void setTextEscaperFactory(EscapingWriterFactory f) {
/* 600 */     this.mTextEscaperFactory = f;
/*     */   }
/*     */   
/*     */   public void setAttrValueEscaperFactory(EscapingWriterFactory f) {
/* 604 */     this.mAttrValueEscaperFactory = f;
/*     */   }
/*     */   
/*     */   public void setProblemReporter(XMLReporter rep) {
/* 608 */     this.mProblemReporter = rep;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void configureForXmlConformance()
/*     */   {
/* 623 */     doValidateAttributes(true);
/* 624 */     doValidateContent(true);
/* 625 */     doValidateStructure(true);
/* 626 */     doValidateNames(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void configureForRobustness()
/*     */   {
/* 636 */     doValidateAttributes(true);
/* 637 */     doValidateStructure(true);
/* 638 */     doValidateNames(true);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 644 */     doValidateContent(true);
/* 645 */     doFixContent(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void configureForSpeed()
/*     */   {
/* 655 */     doValidateAttributes(false);
/* 656 */     doValidateContent(false);
/* 657 */     doValidateNames(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] allocMediumCBuffer(int minSize)
/*     */   {
/* 675 */     if (this.mCurrRecycler != null) {
/* 676 */       char[] result = this.mCurrRecycler.getMediumCBuffer(minSize);
/* 677 */       if (result != null) {
/* 678 */         return result;
/*     */       }
/*     */     }
/* 681 */     return new char[minSize];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void freeMediumCBuffer(char[] buffer)
/*     */   {
/* 688 */     if (this.mCurrRecycler == null) {
/* 689 */       this.mCurrRecycler = createRecycler();
/*     */     }
/* 691 */     this.mCurrRecycler.returnMediumCBuffer(buffer);
/*     */   }
/*     */   
/*     */ 
/*     */   public char[] allocFullCBuffer(int minSize)
/*     */   {
/* 697 */     if (this.mCurrRecycler != null) {
/* 698 */       char[] result = this.mCurrRecycler.getFullCBuffer(minSize);
/* 699 */       if (result != null) {
/* 700 */         return result;
/*     */       }
/*     */     }
/* 703 */     return new char[minSize];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void freeFullCBuffer(char[] buffer)
/*     */   {
/* 710 */     if (this.mCurrRecycler == null) {
/* 711 */       this.mCurrRecycler = createRecycler();
/*     */     }
/* 713 */     this.mCurrRecycler.returnFullCBuffer(buffer);
/*     */   }
/*     */   
/*     */ 
/*     */   public byte[] allocFullBBuffer(int minSize)
/*     */   {
/* 719 */     if (this.mCurrRecycler != null) {
/* 720 */       byte[] result = this.mCurrRecycler.getFullBBuffer(minSize);
/* 721 */       if (result != null) {
/* 722 */         return result;
/*     */       }
/*     */     }
/* 725 */     return new byte[minSize];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void freeFullBBuffer(byte[] buffer)
/*     */   {
/* 732 */     if (this.mCurrRecycler == null) {
/* 733 */       this.mCurrRecycler = createRecycler();
/*     */     }
/* 735 */     this.mCurrRecycler.returnFullBBuffer(buffer);
/*     */   }
/*     */   
/* 738 */   static int Counter = 0;
/*     */   
/*     */   private BufferRecycler createRecycler()
/*     */   {
/* 742 */     BufferRecycler recycler = new BufferRecycler();
/*     */     
/*     */ 
/* 745 */     mRecyclerRef.set(new SoftReference(recycler));
/* 746 */     return recycler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setConfigFlag(int flag, boolean state)
/*     */   {
/* 756 */     if (state) {
/* 757 */       this.mConfigFlags |= flag;
/*     */     } else {
/* 759 */       this.mConfigFlags &= (flag ^ 0xFFFFFFFF);
/*     */     }
/*     */   }
/*     */   
/*     */   private final boolean hasConfigFlag(int flag) {
/* 764 */     return (this.mConfigFlags & flag) == flag;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\api\WriterConfig.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */