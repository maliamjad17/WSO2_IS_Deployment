/*    */ package com.ctc.wstx.compat;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Jdk13Impl
/*    */   extends Jdk12Impl
/*    */ {
/*    */   public Jdk13Impl()
/*    */   {
/* 16 */     super(true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected Jdk13Impl(boolean dummy)
/*    */   {
/* 24 */     super(true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean leakingThreadLocal()
/*    */   {
/* 42 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   public List getEmptyList()
/*    */   {
/* 48 */     return Collections.EMPTY_LIST;
/*    */   }
/*    */   
/*    */   public Map getEmptyMap() {
/* 52 */     return Collections.EMPTY_MAP;
/*    */   }
/*    */   
/*    */   public Set getEmptySet() {
/* 56 */     return Collections.EMPTY_SET;
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\compat\Jdk13Impl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */