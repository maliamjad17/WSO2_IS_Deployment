/*     */ package com.ctc.wstx.sr;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import com.ctc.wstx.util.BaseNsContext;
/*     */ import com.ctc.wstx.util.EmptyIterator;
/*     */ import com.ctc.wstx.util.EmptyNamespaceContext;
/*     */ import com.ctc.wstx.util.StringVector;
/*     */ import com.ctc.wstx.util.TextBuilder;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.codehaus.stax2.validation.XMLValidator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NonNsInputElementStack
/*     */   extends InputElementStack
/*     */ {
/*     */   static final String INT_ERR_UNEXPECTED_CALL = "Internal error: method should never be called for non-namespace element stack.";
/*     */   protected final NonNsAttributeCollector mAttrCollector;
/*     */   protected String[] mElements;
/*     */   protected int mSize;
/*  64 */   protected String mLastLocalName = null;
/*     */   
/*  66 */   protected QName mLastName = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NonNsInputElementStack(int initialSize, ReaderConfig cfg)
/*     */   {
/*  76 */     super(cfg);
/*  77 */     this.mSize = 0;
/*  78 */     if (initialSize < 4) {
/*  79 */       initialSize = 4;
/*     */     }
/*  81 */     this.mElements = new String[initialSize];
/*  82 */     this.mAttrCollector = new NonNsAttributeCollector(cfg);
/*     */   }
/*     */   
/*     */   protected void setAutomaticDTDValidator(XMLValidator validator, NsDefaultProvider nsDefs)
/*     */   {
/*  87 */     addValidator(validator);
/*     */   }
/*     */   
/*     */   public final void push(String prefix, String localName)
/*     */   {
/*  92 */     throw new Error("Internal error: method should never be called for non-namespace element stack.");
/*     */   }
/*     */   
/*     */   public final void push(String fullName)
/*     */   {
/*  97 */     if (this.mSize == this.mElements.length) {
/*  98 */       String[] old = this.mElements;
/*  99 */       this.mElements = new String[old.length + 32];
/* 100 */       System.arraycopy(old, 0, this.mElements, 0, old.length);
/*     */     }
/* 102 */     this.mElements[this.mSize] = fullName;
/* 103 */     this.mSize += 1;
/* 104 */     this.mAttrCollector.reset();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int pop()
/*     */     throws XMLStreamException
/*     */   {
/* 114 */     if (this.mSize == 0) {
/* 115 */       throw new IllegalStateException("Popping from empty stack.");
/*     */     }
/*     */     
/* 118 */     if (this.mValidator == null)
/*     */     {
/*     */ 
/*     */ 
/* 122 */       this.mElements[(--this.mSize)] = null;
/* 123 */       return 3;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 131 */     int size = this.mSize - 1;
/* 132 */     int result = this.mValidator.validateElementEnd(this.mElements[size], null, null);
/* 133 */     this.mSize = size;
/* 134 */     this.mElements[size] = null;
/* 135 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int resolveAndValidateElement()
/*     */     throws XMLStreamException
/*     */   {
/* 149 */     NonNsAttributeCollector ac = this.mAttrCollector;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 154 */     int xmlidIx = ac.resolveValues(this.mReporter);
/* 155 */     this.mIdAttrIndex = xmlidIx;
/*     */     
/*     */ 
/* 158 */     if (this.mValidator == null) {
/* 159 */       if (xmlidIx >= 0) {
/* 160 */         normalizeXmlIdAttr(ac, xmlidIx);
/*     */       }
/* 162 */       return 3;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 170 */     this.mValidator.validateElementStart(this.mElements[(this.mSize - 1)], null, null);
/*     */     
/*     */ 
/* 173 */     int attrLen = ac.getCount();
/* 174 */     if (attrLen > 0) {
/* 175 */       StringVector attrNames = ac.getNameList();
/* 176 */       String[] nameData = attrNames.getInternalArray();
/* 177 */       TextBuilder attrBuilder = ac.getAttrBuilder();
/* 178 */       char[] attrCB = attrBuilder.getCharBuffer();
/* 179 */       for (int i = 0; i < attrLen; i++) {
/* 180 */         String normValue = this.mValidator.validateAttribute(nameData[i], null, null, attrCB, attrBuilder.getOffset(i), attrBuilder.getOffset(i + 1));
/*     */         
/*     */ 
/*     */ 
/* 184 */         if (normValue != null) {
/* 185 */           ac.setNormalizedValue(i, normValue);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 193 */     return this.mValidator.validateElementAndAttributes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isNamespaceAware()
/*     */   {
/* 203 */     return false;
/*     */   }
/*     */   
/* 206 */   public final int getDepth() { return this.mSize; }
/*     */   
/*     */   public final AttributeCollector getAttrCollector() {
/* 209 */     return this.mAttrCollector;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final BaseNsContext createNonTransientNsContext(Location loc)
/*     */   {
/* 218 */     return EmptyNamespaceContext.getInstance();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getNamespaceURI(String prefix)
/*     */   {
/* 228 */     return null;
/*     */   }
/*     */   
/*     */   public final String getPrefix(String nsURI) {
/* 232 */     return null;
/*     */   }
/*     */   
/*     */   public final Iterator getPrefixes(String nsURI) {
/* 236 */     return EmptyIterator.getInstance();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getAttributeCount()
/*     */   {
/* 247 */     return this.mAttrCollector.getCount();
/*     */   }
/*     */   
/*     */ 
/*     */   public final int findAttributeIndex(String nsURI, String localName)
/*     */   {
/* 253 */     if ((nsURI != null) && (nsURI.length() > 0)) {
/* 254 */       return -1;
/*     */     }
/* 256 */     return this.mAttrCollector.findIndex(localName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final QName getCurrentElementName()
/*     */   {
/* 267 */     if (this.mSize == 0) {
/* 268 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 275 */     String ln = this.mElements[(this.mSize - 1)];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 280 */     if (ln == this.mLastLocalName) {
/* 281 */       return this.mLastName;
/*     */     }
/* 283 */     QName n = new QName(ln);
/* 284 */     this.mLastLocalName = ln;
/* 285 */     this.mLastName = n;
/* 286 */     return n;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int addDefaultAttribute(String localName, String uri, String prefix, String value)
/*     */   {
/* 293 */     return this.mAttrCollector.addDefaultAttribute(localName, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPrefixLocallyDeclared(String internedPrefix)
/*     */   {
/* 304 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addNsBinding(String prefix, String uri) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isEmpty()
/*     */   {
/* 320 */     return this.mSize == 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public final String getDefaultNsURI()
/*     */   {
/* 326 */     return null;
/*     */   }
/*     */   
/*     */   public final String getNsURI() {
/* 330 */     return null;
/*     */   }
/*     */   
/*     */   public final String getPrefix() {
/* 334 */     return null;
/*     */   }
/*     */   
/*     */   public final String getLocalName() {
/* 338 */     if (this.mSize == 0) {
/* 339 */       throw new IllegalStateException("Illegal access, empty stack.");
/*     */     }
/* 341 */     return this.mElements[(this.mSize - 1)];
/*     */   }
/*     */   
/*     */   public final boolean matches(String prefix, String localName)
/*     */   {
/* 346 */     if (this.mSize == 0) {
/* 347 */       throw new IllegalStateException("Illegal access, empty stack.");
/*     */     }
/* 349 */     if ((prefix != null) && (prefix.length() > 0)) {
/* 350 */       return false;
/*     */     }
/* 352 */     String thisName = this.mElements[(this.mSize - 1)];
/* 353 */     return (thisName == localName) || (thisName.equals(localName));
/*     */   }
/*     */   
/*     */   public final String getTopElementDesc() {
/* 357 */     if (this.mSize == 0) {
/* 358 */       throw new IllegalStateException("Illegal access, empty stack.");
/*     */     }
/* 360 */     return this.mElements[(this.mSize - 1)];
/*     */   }
/*     */   
/*     */ 
/*     */   public final int getTotalNsCount()
/*     */   {
/* 366 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getCurrentNsCount()
/*     */   {
/* 374 */     return 0;
/*     */   }
/*     */   
/*     */   public final String getLocalNsPrefix(int index) {
/* 378 */     throwIllegalIndex(index);
/* 379 */     return null;
/*     */   }
/*     */   
/*     */   public final String getLocalNsURI(int index) {
/* 383 */     throwIllegalIndex(index);
/* 384 */     return null;
/*     */   }
/*     */   
/*     */   private static void throwIllegalIndex(int index) {
/* 388 */     throw new IllegalArgumentException("Illegal namespace index " + index + "; current scope has no namespace declarations.");
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sr\NonNsInputElementStack.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */