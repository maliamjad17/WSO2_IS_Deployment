/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import com.ctc.wstx.cfg.ErrorConsts;
/*     */ import com.ctc.wstx.sr.InputProblemReporter;
/*     */ import com.ctc.wstx.util.ExceptionUtil;
/*     */ import com.ctc.wstx.util.WordResolver;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DTDElement
/*     */ {
/*     */   final NameKey mName;
/*     */   final Location mLocation;
/*     */   StructValidator mValidator;
/*     */   int mAllowedContent;
/*     */   final boolean mNsAware;
/*     */   final boolean mXml11;
/*  84 */   HashMap mAttrMap = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  91 */   ArrayList mSpecAttrList = null;
/*     */   
/*  93 */   boolean mAnyFixed = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */   boolean mAnyDefaults = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 106 */   boolean mValidateAttrs = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   DTDAttribute mIdAttr;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   DTDAttribute mNotationAttr;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 133 */   HashMap mNsDefaults = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private DTDElement(Location loc, NameKey name, StructValidator val, int allowedContent, boolean nsAware, boolean xml11)
/*     */   {
/* 145 */     this.mName = name;
/* 146 */     this.mLocation = loc;
/* 147 */     this.mValidator = val;
/* 148 */     this.mAllowedContent = allowedContent;
/* 149 */     this.mNsAware = nsAware;
/* 150 */     this.mXml11 = xml11;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static DTDElement createDefined(ReaderConfig cfg, Location loc, NameKey name, StructValidator val, int allowedContent)
/*     */   {
/* 160 */     if (allowedContent == 4) {
/* 161 */       ExceptionUtil.throwInternal("trying to use XMLValidator.CONTENT_ALLOW_UNDEFINED via createDefined()");
/*     */     }
/* 163 */     return new DTDElement(loc, name, val, allowedContent, cfg.willSupportNamespaces(), cfg.isXml11());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static DTDElement createPlaceholder(ReaderConfig cfg, Location loc, NameKey name)
/*     */   {
/* 173 */     return new DTDElement(loc, name, null, 4, cfg.willSupportNamespaces(), cfg.isXml11());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DTDElement define(Location loc, StructValidator val, int allowedContent)
/*     */   {
/* 185 */     verifyUndefined();
/* 186 */     if (allowedContent == 4) {
/* 187 */       ExceptionUtil.throwInternal("trying to use CONTENT_ALLOW_UNDEFINED via define()");
/*     */     }
/*     */     
/* 190 */     DTDElement elem = new DTDElement(loc, this.mName, val, allowedContent, this.mNsAware, this.mXml11);
/*     */     
/*     */ 
/*     */ 
/* 194 */     elem.mAttrMap = this.mAttrMap;
/* 195 */     elem.mSpecAttrList = this.mSpecAttrList;
/* 196 */     elem.mAnyFixed = this.mAnyFixed;
/* 197 */     elem.mValidateAttrs = this.mValidateAttrs;
/* 198 */     elem.mAnyDefaults = this.mAnyDefaults;
/* 199 */     elem.mIdAttr = this.mIdAttr;
/* 200 */     elem.mNotationAttr = this.mNotationAttr;
/* 201 */     elem.mNsDefaults = this.mNsDefaults;
/*     */     
/* 203 */     return elem;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void defineFrom(InputProblemReporter rep, DTDElement definedElem, boolean fullyValidate)
/*     */     throws XMLStreamException
/*     */   {
/* 214 */     if (fullyValidate) {
/* 215 */       verifyUndefined();
/*     */     }
/* 217 */     this.mValidator = definedElem.mValidator;
/* 218 */     this.mAllowedContent = definedElem.mAllowedContent;
/* 219 */     mergeMissingAttributesFrom(rep, definedElem, fullyValidate);
/*     */   }
/*     */   
/*     */   private void verifyUndefined()
/*     */   {
/* 224 */     if (this.mAllowedContent != 4) {
/* 225 */       ExceptionUtil.throwInternal("redefining defined element spec");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DTDAttribute addAttribute(InputProblemReporter rep, NameKey attrName, int valueType, DefaultAttrValue defValue, WordResolver enumValues, boolean fullyValidate)
/*     */     throws XMLStreamException
/*     */   {
/* 243 */     HashMap m = this.mAttrMap;
/* 244 */     if (m == null) {
/* 245 */       this.mAttrMap = (m = new HashMap());
/*     */     }
/*     */     
/* 248 */     List specList = defValue.isSpecial() ? getSpecialList() : null;
/*     */     
/*     */ 
/* 251 */     int specIndex = specList == null ? -1 : specList.size();
/*     */     DTDAttribute attr;
/* 253 */     switch (valueType) {
/*     */     case 0: 
/* 255 */       attr = new DTDCdataAttr(attrName, defValue, specIndex, this.mNsAware, this.mXml11);
/* 256 */       break;
/*     */     
/*     */     case 1: 
/* 259 */       attr = new DTDEnumAttr(attrName, defValue, specIndex, this.mNsAware, this.mXml11, enumValues);
/* 260 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 2: 
/* 268 */       attr = new DTDIdAttr(attrName, defValue, specIndex, this.mNsAware, this.mXml11);
/* 269 */       break;
/*     */     
/*     */     case 3: 
/* 272 */       attr = new DTDIdRefAttr(attrName, defValue, specIndex, this.mNsAware, this.mXml11);
/* 273 */       break;
/*     */     
/*     */     case 4: 
/* 276 */       attr = new DTDIdRefsAttr(attrName, defValue, specIndex, this.mNsAware, this.mXml11);
/* 277 */       break;
/*     */     
/*     */     case 5: 
/* 280 */       attr = new DTDEntityAttr(attrName, defValue, specIndex, this.mNsAware, this.mXml11);
/* 281 */       break;
/*     */     
/*     */     case 6: 
/* 284 */       attr = new DTDEntitiesAttr(attrName, defValue, specIndex, this.mNsAware, this.mXml11);
/* 285 */       break;
/*     */     
/*     */     case 7: 
/* 288 */       attr = new DTDNotationAttr(attrName, defValue, specIndex, this.mNsAware, this.mXml11, enumValues);
/* 289 */       break;
/*     */     
/*     */     case 8: 
/* 292 */       attr = new DTDNmTokenAttr(attrName, defValue, specIndex, this.mNsAware, this.mXml11);
/* 293 */       break;
/*     */     
/*     */     case 9: 
/* 296 */       attr = new DTDNmTokensAttr(attrName, defValue, specIndex, this.mNsAware, this.mXml11);
/* 297 */       break;
/*     */     
/*     */ 
/*     */     default: 
/* 301 */       ExceptionUtil.throwGenericInternal();
/* 302 */       attr = null;
/*     */     }
/*     */     
/* 305 */     DTDAttribute old = doAddAttribute(m, rep, attr, specList, fullyValidate);
/* 306 */     return old == null ? attr : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DTDAttribute addNsDefault(InputProblemReporter rep, NameKey attrName, int valueType, DefaultAttrValue defValue, boolean fullyValidate)
/*     */     throws XMLStreamException
/*     */   {
/*     */     DTDAttribute nsAttr;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 328 */     switch (valueType) {
/*     */     case 0: 
/* 330 */       nsAttr = new DTDCdataAttr(attrName, defValue, -1, this.mNsAware, this.mXml11);
/* 331 */       break;
/*     */     default: 
/* 333 */       nsAttr = new DTDNmTokenAttr(attrName, defValue, -1, this.mNsAware, this.mXml11);
/*     */     }
/*     */     
/*     */     
/*     */ 
/* 338 */     String prefix = attrName.getPrefix();
/* 339 */     if ((prefix == null) || (prefix.length() == 0)) {
/* 340 */       prefix = "";
/*     */     } else {
/* 342 */       prefix = attrName.getLocalName();
/*     */     }
/*     */     
/* 345 */     if (this.mNsDefaults == null) {
/* 346 */       this.mNsDefaults = new HashMap();
/*     */     }
/* 348 */     else if (this.mNsDefaults.containsKey(prefix)) {
/* 349 */       return null;
/*     */     }
/*     */     
/* 352 */     this.mNsDefaults.put(prefix, nsAttr);
/* 353 */     return nsAttr;
/*     */   }
/*     */   
/*     */ 
/*     */   public void mergeMissingAttributesFrom(InputProblemReporter rep, DTDElement other, boolean fullyValidate)
/*     */     throws XMLStreamException
/*     */   {
/* 360 */     Map otherMap = other.getAttributes();
/* 361 */     HashMap m = this.mAttrMap;
/* 362 */     if (m == null) {
/* 363 */       this.mAttrMap = (m = new HashMap());
/*     */     }
/*     */     
/* 366 */     boolean anyAdded = false;
/*     */     
/* 368 */     if ((otherMap != null) && (otherMap.size() > 0)) {
/* 369 */       Iterator it = otherMap.entrySet().iterator();
/* 370 */       while (it.hasNext()) {
/* 371 */         Map.Entry me = (Map.Entry)it.next();
/* 372 */         Object key = me.getKey();
/*     */         
/* 374 */         if (!m.containsKey(key))
/*     */         {
/* 376 */           DTDAttribute newAttr = (DTDAttribute)me.getValue();
/*     */           
/*     */           List specList;
/* 379 */           if (newAttr.isSpecial()) {
/* 380 */             List specList = getSpecialList();
/* 381 */             newAttr = newAttr.cloneWith(specList.size());
/*     */           } else {
/* 383 */             specList = null;
/*     */           }
/* 385 */           doAddAttribute(m, rep, newAttr, specList, fullyValidate);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 390 */     HashMap otherNs = other.mNsDefaults;
/* 391 */     if (otherNs != null) {
/* 392 */       if (this.mNsDefaults == null) {
/* 393 */         this.mNsDefaults = new HashMap();
/*     */       }
/* 395 */       Iterator it = otherNs.entrySet().iterator();
/* 396 */       while (it.hasNext()) {
/* 397 */         Map.Entry me = (Map.Entry)it.next();
/* 398 */         Object key = me.getKey();
/*     */         
/* 400 */         if (!this.mNsDefaults.containsKey(key)) {
/* 401 */           this.mNsDefaults.put(key, me.getValue());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private DTDAttribute doAddAttribute(Map attrMap, InputProblemReporter rep, DTDAttribute attr, List specList, boolean fullyValidate)
/*     */     throws XMLStreamException
/*     */   {
/* 416 */     NameKey attrName = attr.getName();
/*     */     
/*     */ 
/* 419 */     DTDAttribute old = (DTDAttribute)attrMap.get(attrName);
/* 420 */     if (old != null) {
/* 421 */       rep.reportProblem(ErrorConsts.WT_ATTR_DECL, ErrorConsts.W_DTD_DUP_ATTR, attrName, this.mName);
/*     */       
/* 423 */       return old;
/*     */     }
/*     */     
/* 426 */     switch (attr.getValueType())
/*     */     {
/*     */     case 2: 
/* 429 */       if ((fullyValidate) && (this.mIdAttr != null)) {
/* 430 */         rep.throwParseError("Invalid id attribute '" + attrName + "' for element <" + this.mName + ">: already had id attribute '" + this.mIdAttr.getName() + "'");
/*     */       }
/* 432 */       this.mIdAttr = attr;
/* 433 */       break;
/*     */     
/*     */ 
/*     */     case 7: 
/* 437 */       if ((fullyValidate) && (this.mNotationAttr != null)) {
/* 438 */         rep.throwParseError("Invalid notation attribute '" + attrName + "' for element <" + this.mName + ">: already had notation attribute '" + this.mNotationAttr.getName() + "'");
/*     */       }
/* 440 */       this.mNotationAttr = attr;
/*     */     }
/*     */     
/*     */     
/* 444 */     attrMap.put(attrName, attr);
/* 445 */     if (specList != null) {
/* 446 */       specList.add(attr);
/*     */     }
/* 448 */     if (!this.mAnyFixed) {
/* 449 */       this.mAnyFixed = attr.isFixed();
/*     */     }
/* 451 */     if (!this.mValidateAttrs) {
/* 452 */       this.mValidateAttrs = attr.needsValidation();
/*     */     }
/* 454 */     if (!this.mAnyDefaults) {
/* 455 */       this.mAnyDefaults = attr.hasDefaultValue();
/*     */     }
/*     */     
/* 458 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NameKey getName()
/*     */   {
/* 467 */     return this.mName;
/*     */   }
/*     */   
/* 470 */   public String toString() { return this.mName.toString(); }
/*     */   
/*     */   public String getDisplayName()
/*     */   {
/* 474 */     return this.mName.toString();
/*     */   }
/*     */   
/* 477 */   public Location getLocation() { return this.mLocation; }
/*     */   
/*     */   public boolean isDefined() {
/* 480 */     return this.mAllowedContent != 4;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getAllowedContent()
/*     */   {
/* 488 */     return this.mAllowedContent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getAllowedContentIfSpace()
/*     */   {
/* 500 */     int vld = this.mAllowedContent;
/* 501 */     return vld <= 1 ? 1 : 3;
/*     */   }
/*     */   
/*     */ 
/*     */   public HashMap getAttributes()
/*     */   {
/* 507 */     return this.mAttrMap;
/*     */   }
/*     */   
/*     */   public int getSpecialCount() {
/* 511 */     return this.mSpecAttrList == null ? 0 : this.mSpecAttrList.size();
/*     */   }
/*     */   
/*     */   public List getSpecialAttrs() {
/* 515 */     return this.mSpecAttrList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean attrsNeedValidation()
/*     */   {
/* 523 */     return this.mValidateAttrs;
/*     */   }
/*     */   
/*     */   public boolean hasFixedAttrs() {
/* 527 */     return this.mAnyFixed;
/*     */   }
/*     */   
/*     */   public boolean hasAttrDefaultValues() {
/* 531 */     return this.mAnyDefaults;
/*     */   }
/*     */   
/*     */   public DTDAttribute getIdAttribute() {
/* 535 */     return this.mIdAttr;
/*     */   }
/*     */   
/*     */   public DTDAttribute getNotationAttribute() {
/* 539 */     return this.mNotationAttr;
/*     */   }
/*     */   
/*     */   public boolean hasNsDefaults() {
/* 543 */     return this.mNsDefaults != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StructValidator getValidator()
/*     */   {
/* 554 */     return this.mValidator == null ? null : this.mValidator.newInstance();
/*     */   }
/*     */   
/*     */   protected HashMap getNsDefaults() {
/* 558 */     return this.mNsDefaults;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private List getSpecialList()
/*     */   {
/* 569 */     ArrayList l = this.mSpecAttrList;
/* 570 */     if (l == null) {
/* 571 */       this.mSpecAttrList = (l = new ArrayList());
/*     */     }
/* 573 */     return l;
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\DTDElement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */