/*     */ package com.ctc.wstx.sw;
/*     */ 
/*     */ import com.ctc.wstx.compat.QNameCreator;
/*     */ import com.ctc.wstx.util.BijectiveNsMap;
/*     */ import com.ctc.wstx.util.EmptyIterator;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SimpleOutputElement
/*     */   implements NamespaceContext
/*     */ {
/*     */   public static final int PREFIX_UNBOUND = 0;
/*     */   public static final int PREFIX_OK = 1;
/*     */   public static final int PREFIX_MISBOUND = 2;
/*     */   static final String sXmlNsPrefix = "xml";
/*     */   static final String sXmlNsURI = "http://www.w3.org/XML/1998/namespace";
/*     */   SimpleOutputElement mParent;
/*     */   String mPrefix;
/*     */   String mLocalName;
/*     */   String mURI;
/*     */   NamespaceContext mRootNsContext;
/*     */   String mDefaultNsURI;
/*     */   boolean mDefaultNsSet;
/*     */   BijectiveNsMap mNsMapping;
/*     */   boolean mNsMapShared;
/* 133 */   HashMap mAttrMap = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private SimpleOutputElement()
/*     */   {
/* 146 */     this.mParent = null;
/* 147 */     this.mPrefix = null;
/* 148 */     this.mLocalName = "";
/* 149 */     this.mURI = null;
/* 150 */     this.mNsMapping = null;
/* 151 */     this.mNsMapShared = false;
/* 152 */     this.mDefaultNsURI = "";
/* 153 */     this.mRootNsContext = null;
/* 154 */     this.mDefaultNsSet = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private SimpleOutputElement(SimpleOutputElement parent, String prefix, String localName, String uri, BijectiveNsMap ns)
/*     */   {
/* 161 */     this.mParent = parent;
/* 162 */     this.mPrefix = prefix;
/* 163 */     this.mLocalName = localName;
/* 164 */     this.mURI = uri;
/* 165 */     this.mNsMapping = ns;
/* 166 */     this.mNsMapShared = (ns != null);
/* 167 */     this.mDefaultNsURI = parent.mDefaultNsURI;
/* 168 */     this.mRootNsContext = parent.mRootNsContext;
/* 169 */     this.mDefaultNsSet = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void relink(SimpleOutputElement parent, String prefix, String localName, String uri)
/*     */   {
/* 181 */     this.mParent = parent;
/* 182 */     this.mPrefix = prefix;
/* 183 */     this.mLocalName = localName;
/* 184 */     this.mURI = uri;
/* 185 */     this.mNsMapping = parent.mNsMapping;
/* 186 */     this.mNsMapShared = (this.mNsMapping != null);
/* 187 */     this.mDefaultNsURI = parent.mDefaultNsURI;
/* 188 */     this.mRootNsContext = parent.mRootNsContext;
/* 189 */     this.mDefaultNsSet = false;
/*     */   }
/*     */   
/*     */   public static SimpleOutputElement createRoot()
/*     */   {
/* 194 */     return new SimpleOutputElement();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SimpleOutputElement createChild(String localName)
/*     */   {
/* 208 */     this.mAttrMap = null;
/* 209 */     return new SimpleOutputElement(this, null, localName, this.mDefaultNsURI, this.mNsMapping);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SimpleOutputElement reuseAsChild(SimpleOutputElement parent, String localName)
/*     */   {
/* 219 */     this.mAttrMap = null;
/* 220 */     SimpleOutputElement poolHead = this.mParent;
/* 221 */     relink(parent, null, localName, this.mDefaultNsURI);
/* 222 */     return poolHead;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected SimpleOutputElement reuseAsChild(SimpleOutputElement parent, String prefix, String localName, String uri)
/*     */   {
/* 229 */     this.mAttrMap = null;
/* 230 */     SimpleOutputElement poolHead = this.mParent;
/* 231 */     relink(parent, prefix, localName, uri);
/* 232 */     return poolHead;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SimpleOutputElement createChild(String prefix, String localName, String uri)
/*     */   {
/* 246 */     this.mAttrMap = null;
/* 247 */     return new SimpleOutputElement(this, prefix, localName, uri, this.mNsMapping);
/*     */   }
/*     */   
/*     */   protected void setRootNsContext(NamespaceContext ctxt)
/*     */   {
/* 252 */     this.mRootNsContext = ctxt;
/*     */     
/*     */ 
/*     */ 
/* 256 */     if (!this.mDefaultNsSet) {
/* 257 */       String defURI = ctxt.getNamespaceURI("");
/* 258 */       if ((defURI != null) && (defURI.length() > 0)) {
/* 259 */         this.mDefaultNsURI = defURI;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addToPool(SimpleOutputElement poolHead)
/*     */   {
/* 270 */     this.mParent = poolHead;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SimpleOutputElement getParent()
/*     */   {
/* 280 */     return this.mParent;
/*     */   }
/*     */   
/*     */   public boolean isRoot()
/*     */   {
/* 285 */     return this.mParent == null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getNameDesc()
/*     */   {
/* 294 */     if ((this.mPrefix != null) && (this.mPrefix.length() > 0)) {
/* 295 */       return this.mPrefix + ":" + this.mLocalName;
/*     */     }
/* 297 */     if ((this.mLocalName != null) && (this.mLocalName.length() > 0)) {
/* 298 */       return this.mLocalName;
/*     */     }
/* 300 */     return "#error";
/*     */   }
/*     */   
/*     */   public String getPrefix() {
/* 304 */     return this.mPrefix;
/*     */   }
/*     */   
/*     */   public String getLocalName() {
/* 308 */     return this.mLocalName;
/*     */   }
/*     */   
/*     */   public String getNamespaceURI() {
/* 312 */     return this.mURI;
/*     */   }
/*     */   
/*     */   public String getDefaultNsUri() {
/* 316 */     return this.mDefaultNsURI;
/*     */   }
/*     */   
/*     */   public QName getName() {
/* 320 */     return QNameCreator.create(this.mURI, this.mLocalName, this.mPrefix);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getExplicitPrefix(String uri)
/*     */   {
/* 336 */     if (this.mNsMapping != null) {
/* 337 */       String prefix = this.mNsMapping.findPrefixByUri(uri);
/* 338 */       if (prefix != null) {
/* 339 */         return prefix;
/*     */       }
/*     */     }
/* 342 */     if (this.mRootNsContext != null) {
/* 343 */       String prefix = this.mRootNsContext.getPrefix(uri);
/* 344 */       if (prefix != null)
/*     */       {
/* 346 */         if (prefix.length() > 0) {
/* 347 */           return prefix;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 352 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int isPrefixValid(String prefix, String nsURI, boolean isElement)
/*     */     throws XMLStreamException
/*     */   {
/* 377 */     if (nsURI == null) {
/* 378 */       nsURI = "";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 386 */     if ((prefix == null) || (prefix.length() == 0)) {
/* 387 */       if (isElement)
/*     */       {
/* 389 */         if ((nsURI == this.mDefaultNsURI) || (nsURI.equals(this.mDefaultNsURI))) {
/* 390 */           return 1;
/*     */ 
/*     */         }
/*     */         
/*     */ 
/*     */       }
/* 396 */       else if (nsURI.length() == 0) {
/* 397 */         return 1;
/*     */       }
/*     */       
/* 400 */       return 2;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 406 */     if (prefix.equals("xml"))
/*     */     {
/*     */ 
/* 409 */       if (!nsURI.equals("http://www.w3.org/XML/1998/namespace")) {
/* 410 */         throwOutputError("Namespace prefix 'xml' can not be bound to non-default namespace ('" + nsURI + "'); has to be the default '" + "http://www.w3.org/XML/1998/namespace" + "'");
/*     */       }
/*     */       
/*     */ 
/* 414 */       return 1;
/*     */     }
/*     */     
/*     */     String act;
/*     */     
/*     */     String act;
/* 420 */     if (this.mNsMapping != null) {
/* 421 */       act = this.mNsMapping.findUriByPrefix(prefix);
/*     */     } else {
/* 423 */       act = null;
/*     */     }
/*     */     
/* 426 */     if ((act == null) && (this.mRootNsContext != null)) {
/* 427 */       act = this.mRootNsContext.getNamespaceURI(prefix);
/*     */     }
/*     */     
/*     */ 
/* 431 */     if (act == null) {
/* 432 */       return 0;
/*     */     }
/*     */     
/* 435 */     return (act == nsURI) || (act.equals(nsURI)) ? 1 : 2;
/*     */   }
/*     */   
/*     */ 
/*     */   public void checkAttrWrite(String nsURI, String localName, String value)
/*     */     throws XMLStreamException
/*     */   {
/* 442 */     AttrName an = new AttrName(nsURI, localName);
/* 443 */     if (this.mAttrMap == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 448 */       this.mAttrMap = new HashMap();
/* 449 */       this.mAttrMap.put(an, value);
/*     */     } else {
/* 451 */       Object old = this.mAttrMap.put(an, value);
/* 452 */       if (old != null) {
/* 453 */         throw new XMLStreamException("Duplicate attribute write for attribute '" + an + "' (previous value '" + old + "', new value '" + value + "').");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultNsUri(String uri)
/*     */   {
/* 465 */     this.mDefaultNsURI = uri;
/* 466 */     this.mDefaultNsSet = true;
/*     */   }
/*     */   
/*     */   public void setPrefix(String prefix) {
/* 470 */     this.mPrefix = prefix;
/*     */   }
/*     */   
/*     */ 
/*     */   public String generateMapping(String prefixBase, String uri, int[] seqArr)
/*     */   {
/* 476 */     if (this.mNsMapping == null)
/*     */     {
/* 478 */       this.mNsMapping = BijectiveNsMap.createEmpty();
/* 479 */     } else if (this.mNsMapShared)
/*     */     {
/*     */ 
/*     */ 
/* 483 */       this.mNsMapping = this.mNsMapping.createChild();
/* 484 */       this.mNsMapShared = false;
/*     */     }
/* 486 */     return this.mNsMapping.addGeneratedMapping(prefixBase, this.mRootNsContext, uri, seqArr);
/*     */   }
/*     */   
/*     */ 
/*     */   public void addPrefix(String prefix, String uri)
/*     */   {
/* 492 */     if (this.mNsMapping == null)
/*     */     {
/* 494 */       this.mNsMapping = BijectiveNsMap.createEmpty();
/* 495 */     } else if (this.mNsMapShared)
/*     */     {
/*     */ 
/*     */ 
/* 499 */       this.mNsMapping = this.mNsMapping.createChild();
/* 500 */       this.mNsMapShared = false;
/*     */     }
/* 502 */     this.mNsMapping.addMapping(prefix, uri);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getNamespaceURI(String prefix)
/*     */   {
/* 513 */     if (prefix.length() == 0) {
/* 514 */       return this.mDefaultNsURI;
/*     */     }
/* 516 */     if (this.mNsMapping != null) {
/* 517 */       String uri = this.mNsMapping.findUriByPrefix(prefix);
/* 518 */       if (uri != null) {
/* 519 */         return uri;
/*     */       }
/*     */     }
/* 522 */     return this.mRootNsContext != null ? this.mRootNsContext.getNamespaceURI(prefix) : null;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getPrefix(String uri)
/*     */   {
/* 528 */     if (this.mDefaultNsURI.equals(uri)) {
/* 529 */       return "";
/*     */     }
/* 531 */     if (this.mNsMapping != null) {
/* 532 */       String prefix = this.mNsMapping.findPrefixByUri(uri);
/* 533 */       if (prefix != null) {
/* 534 */         return prefix;
/*     */       }
/*     */     }
/* 537 */     return this.mRootNsContext != null ? this.mRootNsContext.getPrefix(uri) : null;
/*     */   }
/*     */   
/*     */ 
/*     */   public Iterator getPrefixes(String uri)
/*     */   {
/* 543 */     List l = null;
/*     */     
/* 545 */     if (this.mDefaultNsURI.equals(uri)) {
/* 546 */       l = new ArrayList();
/* 547 */       l.add("");
/*     */     }
/* 549 */     if (this.mNsMapping != null) {
/* 550 */       l = this.mNsMapping.getPrefixesBoundToUri(uri, l);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 557 */     if (this.mRootNsContext != null) {
/* 558 */       Iterator it = this.mRootNsContext.getPrefixes(uri);
/* 559 */       while (it.hasNext()) {
/* 560 */         String prefix = (String)it.next();
/* 561 */         if (prefix.length() != 0)
/*     */         {
/*     */ 
/*     */ 
/* 565 */           if (l == null)
/* 566 */             l = new ArrayList(); else {
/* 567 */             if (l.contains(prefix))
/*     */               continue;
/*     */           }
/* 570 */           l.add(prefix);
/*     */         }
/*     */       } }
/* 573 */     return l == null ? EmptyIterator.getInstance() : l.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void throwOutputError(String msg)
/*     */     throws XMLStreamException
/*     */   {
/* 586 */     throw new XMLStreamException(msg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final class AttrName
/*     */     implements Comparable
/*     */   {
/*     */     final String mNsURI;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     final String mLocalName;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     final int mHashCode;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public AttrName(String nsURI, String localName)
/*     */     {
/* 613 */       this.mNsURI = (nsURI == null ? "" : nsURI);
/* 614 */       this.mLocalName = localName;
/* 615 */       this.mHashCode = (this.mNsURI.hashCode() * 31 ^ this.mLocalName.hashCode());
/*     */     }
/*     */     
/*     */     public boolean equals(Object o) {
/* 619 */       if (o == this) {
/* 620 */         return true;
/*     */       }
/* 622 */       if (!(o instanceof AttrName)) {
/* 623 */         return false;
/*     */       }
/* 625 */       AttrName other = (AttrName)o;
/* 626 */       String otherLN = other.mLocalName;
/*     */       
/* 628 */       if ((otherLN != this.mLocalName) && (!otherLN.equals(this.mLocalName))) {
/* 629 */         return false;
/*     */       }
/* 631 */       String otherURI = other.mNsURI;
/* 632 */       return (otherURI == this.mNsURI) || (otherURI.equals(this.mNsURI));
/*     */     }
/*     */     
/*     */     public String toString() {
/* 636 */       if (this.mNsURI.length() > 0) {
/* 637 */         return "{" + this.mNsURI + "} " + this.mLocalName;
/*     */       }
/* 639 */       return this.mLocalName;
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 643 */       return this.mHashCode;
/*     */     }
/*     */     
/*     */     public int compareTo(Object o) {
/* 647 */       AttrName other = (AttrName)o;
/*     */       
/* 649 */       int result = this.mNsURI.compareTo(other.mNsURI);
/* 650 */       if (result == 0) {
/* 651 */         result = this.mLocalName.compareTo(other.mLocalName);
/*     */       }
/* 653 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sw\SimpleOutputElement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */