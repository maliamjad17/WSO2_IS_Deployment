/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ import com.ctc.wstx.sr.InputElementStack;
/*     */ import com.ctc.wstx.sr.NsDefaultProvider;
/*     */ import com.ctc.wstx.util.DataUtil;
/*     */ import com.ctc.wstx.util.ExceptionUtil;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.xml.stream.Location;
/*     */ import org.codehaus.stax2.validation.ValidationContext;
/*     */ import org.codehaus.stax2.validation.XMLValidationException;
/*     */ import org.codehaus.stax2.validation.XMLValidationProblem;
/*     */ import org.codehaus.stax2.validation.XMLValidationSchema;
/*     */ import org.codehaus.stax2.validation.XMLValidator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DTDValidatorBase
/*     */   extends XMLValidator
/*     */   implements NsDefaultProvider
/*     */ {
/*     */   static final int DEFAULT_STACK_SIZE = 16;
/*     */   static final int EXP_MAX_ATTRS = 16;
/*  63 */   protected static final HashMap EMPTY_MAP = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final boolean mHasNsDefaults;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final DTDSubset mSchema;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final ValidationContext mContext;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final Map mElemSpecs;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final Map mGeneralEntities;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean mNormAttrs;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 121 */   protected DTDElement mCurrElem = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 127 */   protected DTDElement[] mElems = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 132 */   protected int mElemCount = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 137 */   protected HashMap mCurrAttrDefs = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 144 */   protected DTDAttribute[] mAttrSpecs = new DTDAttribute[16];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 151 */   protected int mAttrCount = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 159 */   protected int mIdAttrIndex = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 167 */   protected final transient NameKey mTmpKey = new NameKey(null, null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 173 */   char[] mTmpAttrValueBuffer = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DTDValidatorBase(DTDSubset schema, ValidationContext ctxt, boolean hasNsDefaults, Map elemSpecs, Map genEntities)
/*     */   {
/* 184 */     this.mSchema = schema;
/* 185 */     this.mContext = ctxt;
/* 186 */     this.mHasNsDefaults = hasNsDefaults;
/* 187 */     this.mElemSpecs = ((elemSpecs == null) || (elemSpecs.size() == 0) ? Collections.EMPTY_MAP : elemSpecs);
/*     */     
/* 189 */     this.mGeneralEntities = genEntities;
/*     */     
/* 191 */     this.mNormAttrs = true;
/* 192 */     this.mElems = new DTDElement[16];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAttrValueNormalization(boolean state)
/*     */   {
/* 210 */     this.mNormAttrs = state;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean reallyValidating();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final XMLValidationSchema getSchema()
/*     */   {
/* 226 */     return this.mSchema;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void validateElementStart(String paramString1, String paramString2, String paramString3)
/*     */     throws XMLValidationException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String validateAttribute(String paramString1, String paramString2, String paramString3, String paramString4)
/*     */     throws XMLValidationException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String validateAttribute(String paramString1, String paramString2, String paramString3, char[] paramArrayOfChar, int paramInt1, int paramInt2)
/*     */     throws XMLValidationException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int validateElementAndAttributes()
/*     */     throws XMLValidationException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int validateElementEnd(String paramString1, String paramString2, String paramString3)
/*     */     throws XMLValidationException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validateText(String text, boolean lastTextSegment)
/*     */     throws XMLValidationException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validateText(char[] cbuf, int textStart, int textEnd, boolean lastTextSegment)
/*     */     throws XMLValidationException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void validationCompleted(boolean paramBoolean)
/*     */     throws XMLValidationException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAttributeType(int index)
/*     */   {
/* 288 */     DTDAttribute attr = this.mAttrSpecs[index];
/* 289 */     return attr == null ? "CDATA" : attr.getValueTypeString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getIdAttrIndex()
/*     */   {
/* 305 */     int ix = this.mIdAttrIndex;
/* 306 */     if (ix == -2) {
/* 307 */       ix = -1;
/* 308 */       if (this.mCurrElem != null) {
/* 309 */         DTDAttribute idAttr = this.mCurrElem.getIdAttribute();
/* 310 */         if (idAttr != null) {
/* 311 */           DTDAttribute[] attrs = this.mAttrSpecs;
/* 312 */           int i = 0; for (int len = attrs.length; i < len; i++) {
/* 313 */             if (attrs[i] == idAttr) {
/* 314 */               ix = i;
/* 315 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 320 */       this.mIdAttrIndex = ix;
/*     */     }
/* 322 */     return ix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNotationAttrIndex()
/*     */   {
/* 340 */     int i = 0; for (int len = this.mAttrCount; i < len; i++) {
/* 341 */       if (this.mAttrSpecs[i].typeIsNotation()) {
/* 342 */         return i;
/*     */       }
/*     */     }
/* 345 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean mayHaveNsDefaults(String elemPrefix, String elemLN)
/*     */   {
/* 362 */     this.mTmpKey.reset(elemPrefix, elemLN);
/* 363 */     DTDElement elem = (DTDElement)this.mElemSpecs.get(this.mTmpKey);
/* 364 */     this.mCurrElem = elem;
/* 365 */     return (elem != null) && (elem.hasNsDefaults());
/*     */   }
/*     */   
/*     */ 
/*     */   public void checkNsDefaults(InputElementStack nsStack)
/*     */     throws XMLValidationException
/*     */   {
/* 372 */     HashMap m = this.mCurrElem.getNsDefaults();
/* 373 */     if (m != null) {
/* 374 */       Iterator it = m.entrySet().iterator();
/* 375 */       while (it.hasNext()) {
/* 376 */         Map.Entry me = (Map.Entry)it.next();
/* 377 */         String prefix = (String)me.getKey();
/* 378 */         if (!nsStack.isPrefixLocallyDeclared(prefix)) {
/* 379 */           DTDAttribute attr = (DTDAttribute)me.getValue();
/* 380 */           String uri = attr.getDefaultValue(this.mContext);
/* 381 */           nsStack.addNsBinding(prefix, uri);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   NameKey getElemName()
/*     */   {
/* 397 */     DTDElement elem = this.mElems[(this.mElemCount - 1)];
/* 398 */     return elem.getName();
/*     */   }
/*     */   
/*     */   Location getLocation() {
/* 402 */     return this.mContext.getValidationLocation();
/*     */   }
/*     */   
/*     */   protected abstract ElementIdMap getIdMap();
/*     */   
/*     */   Map getEntityMap() {
/* 408 */     return this.mGeneralEntities;
/*     */   }
/*     */   
/*     */   char[] getTempAttrValueBuffer(int neededLength)
/*     */   {
/* 413 */     if ((this.mTmpAttrValueBuffer == null) || (this.mTmpAttrValueBuffer.length < neededLength))
/*     */     {
/* 415 */       int size = neededLength < 100 ? 100 : neededLength;
/* 416 */       this.mTmpAttrValueBuffer = new char[size];
/*     */     }
/* 418 */     return this.mTmpAttrValueBuffer;
/*     */   }
/*     */   
/*     */   public boolean hasNsDefaults() {
/* 422 */     return this.mHasNsDefaults;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void reportValidationProblem(String msg)
/*     */     throws XMLValidationException
/*     */   {
/* 439 */     doReportValidationProblem(msg, null);
/*     */   }
/*     */   
/*     */   void reportValidationProblem(String msg, Location loc)
/*     */     throws XMLValidationException
/*     */   {
/* 445 */     doReportValidationProblem(msg, loc);
/*     */   }
/*     */   
/*     */   void reportValidationProblem(String format, String arg)
/*     */     throws XMLValidationException
/*     */   {
/* 451 */     doReportValidationProblem(MessageFormat.format(format, new Object[] { arg }), null);
/*     */   }
/*     */   
/*     */ 
/*     */   void reportValidationProblem(String format, String arg1, String arg2)
/*     */     throws XMLValidationException
/*     */   {
/* 458 */     doReportValidationProblem(MessageFormat.format(format, new Object[] { arg1, arg2 }), null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doReportValidationProblem(String msg, Location loc)
/*     */     throws XMLValidationException
/*     */   {
/* 471 */     if (loc == null) {
/* 472 */       loc = getLocation();
/*     */     }
/* 474 */     this.mContext.reportProblem(new XMLValidationProblem(loc, msg, 2));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doAddDefaultValue(DTDAttribute attr)
/*     */     throws XMLValidationException
/*     */   {
/* 483 */     String def = attr.getDefaultValue(this.mContext);
/* 484 */     if (def == null) {
/* 485 */       ExceptionUtil.throwInternal("null default attribute value");
/*     */     }
/* 487 */     NameKey an = attr.getName();
/*     */     
/* 489 */     String prefix = an.getPrefix();
/* 490 */     String uri = "";
/* 491 */     if ((prefix != null) && (prefix.length() > 0)) {
/* 492 */       uri = this.mContext.getNamespaceURI(prefix);
/*     */       
/* 494 */       if ((uri == null) || (uri.length() == 0))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 499 */         reportValidationProblem("Unbound namespace prefix '" + prefix + "' for default attribute " + attr);
/*     */         
/* 501 */         uri = "";
/*     */       }
/*     */     }
/* 504 */     int defIx = this.mContext.addDefaultAttribute(an.getLocalName(), uri, prefix, def);
/* 505 */     if (defIx >= 0)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 513 */       while (defIx >= this.mAttrSpecs.length) {
/* 514 */         this.mAttrSpecs = ((DTDAttribute[])DataUtil.growArrayBy50Pct(this.mAttrSpecs));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 519 */       while (this.mAttrCount < defIx) {
/* 520 */         this.mAttrSpecs[(this.mAttrCount++)] = null;
/*     */       }
/* 522 */       this.mAttrSpecs[defIx] = attr;
/* 523 */       this.mAttrCount = (defIx + 1);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\DTDValidatorBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */