/*     */ package com.ctc.wstx.sr;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import com.ctc.wstx.cfg.ErrorConsts;
/*     */ import com.ctc.wstx.compat.QNameCreator;
/*     */ import com.ctc.wstx.util.BaseNsContext;
/*     */ import com.ctc.wstx.util.EmptyIterator;
/*     */ import com.ctc.wstx.util.EmptyNamespaceContext;
/*     */ import com.ctc.wstx.util.InternCache;
/*     */ import com.ctc.wstx.util.SingletonIterator;
/*     */ import com.ctc.wstx.util.StringVector;
/*     */ import com.ctc.wstx.util.TextBuilder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.codehaus.stax2.validation.XMLValidator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NsInputElementStack
/*     */   extends InputElementStack
/*     */ {
/*  56 */   static final String DEFAULT_NAMESPACE_URI = null;
/*     */   
/*     */   static final int IX_PREFIX = 0;
/*     */   
/*     */   static final int IX_LOCALNAME = 1;
/*     */   
/*     */   static final int IX_URI = 2;
/*     */   static final int IX_DEFAULT_NS = 3;
/*     */   static final int ENTRY_SIZE = 4;
/*  65 */   protected static final InternCache sInternCache = InternCache.getInstance();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final NsAttributeCollector mAttrCollector;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected NsDefaultProvider mNsDefaultProvider;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */   protected final StringVector mNamespaces = new StringVector(64);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String[] mElements;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int mSize;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int[] mNsCounts;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 115 */   protected boolean mMayHaveNsDefaults = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */   protected String mLastLocalName = null;
/* 126 */   protected String mLastPrefix = null;
/* 127 */   protected String mLastNsURI = null;
/*     */   
/* 129 */   protected QName mLastName = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 144 */   protected BaseNsContext mLastNsContext = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NsInputElementStack(int initialSize, ReaderConfig cfg)
/*     */   {
/* 154 */     super(cfg);
/* 155 */     this.mSize = 0;
/* 156 */     if (initialSize < 4) {
/* 157 */       initialSize = 4;
/*     */     }
/* 159 */     this.mElements = new String[initialSize << 2];
/* 160 */     this.mNsCounts = new int[initialSize];
/* 161 */     this.mAttrCollector = new NsAttributeCollector(cfg);
/*     */   }
/*     */   
/*     */   protected void setAutomaticDTDValidator(XMLValidator validator, NsDefaultProvider nsDefs)
/*     */   {
/* 166 */     this.mNsDefaultProvider = nsDefs;
/* 167 */     addValidator(validator);
/*     */   }
/*     */   
/*     */   public final void push(String prefix, String localName)
/*     */   {
/* 172 */     int index = this.mSize;
/* 173 */     if (index == this.mElements.length) {
/* 174 */       String[] old = this.mElements;
/* 175 */       this.mElements = new String[old.length + 64];
/* 176 */       System.arraycopy(old, 0, this.mElements, 0, old.length);
/*     */     }
/* 178 */     this.mElements[index] = prefix;
/* 179 */     this.mElements[(index + 1)] = localName;
/*     */     
/* 181 */     if (index == 0) {
/* 182 */       this.mElements[3] = DEFAULT_NAMESPACE_URI;
/*     */     }
/*     */     else {
/* 185 */       this.mElements[(index + 3)] = this.mElements[(index - 1)];
/*     */     }
/* 187 */     this.mSize = (index + 4);
/*     */     
/*     */ 
/* 190 */     index >>= 2;
/* 191 */     if (index == this.mNsCounts.length) {
/* 192 */       int[] old = this.mNsCounts;
/* 193 */       this.mNsCounts = new int[old.length + 16];
/* 194 */       System.arraycopy(old, 0, this.mNsCounts, 0, old.length);
/*     */     }
/* 196 */     this.mNsCounts[index] = this.mNamespaces.size();
/* 197 */     this.mAttrCollector.reset();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 202 */     if (this.mNsDefaultProvider != null) {
/* 203 */       this.mMayHaveNsDefaults = this.mNsDefaultProvider.mayHaveNsDefaults(prefix, localName);
/*     */     }
/*     */   }
/*     */   
/*     */   public final void push(String fullName) {
/* 208 */     throw new Error("Internal error: push(fullName) shouldn't be called for namespace aware element stack.");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int pop()
/*     */     throws XMLStreamException
/*     */   {
/* 220 */     int index = this.mSize;
/* 221 */     if (index == 0) {
/* 222 */       throw new IllegalStateException("Popping from empty stack.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 230 */     index -= 4;
/*     */     int result;
/* 232 */     int result; if (this.mValidator == null)
/*     */     {
/*     */ 
/*     */ 
/* 236 */       result = 3;
/*     */     } else {
/* 238 */       result = this.mValidator.validateElementEnd(this.mElements[(index + 1)], this.mElements[(index + 2)], this.mElements[(index + 0)]);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 245 */     this.mSize = index;
/* 246 */     this.mElements[index] = null;
/* 247 */     this.mElements[(index + 1)] = null;
/* 248 */     this.mElements[(index + 2)] = null;
/* 249 */     this.mElements[(index + 3)] = null;
/*     */     
/*     */ 
/* 252 */     int nsCount = this.mNamespaces.size() - this.mNsCounts[(index >> 2)];
/* 253 */     if (nsCount > 0) {
/* 254 */       this.mLastNsContext = null;
/* 255 */       this.mNamespaces.removeLast(nsCount);
/*     */     }
/* 257 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int resolveAndValidateElement()
/*     */     throws XMLStreamException
/*     */   {
/* 271 */     if (this.mSize == 0) {
/* 272 */       throw new IllegalStateException("Calling validate() on empty stack.");
/*     */     }
/* 274 */     NsAttributeCollector ac = this.mAttrCollector;
/*     */     
/*     */ 
/*     */ 
/* 278 */     int nsCount = ac.getNsCount();
/* 279 */     if (nsCount > 0)
/*     */     {
/*     */ 
/*     */ 
/* 283 */       this.mLastNsContext = null;
/*     */       
/* 285 */       String[] nsPrefixes = ac.getNsPrefixes();
/* 286 */       TextBuilder nsURIs = ac.getNsURIs();
/* 287 */       boolean internNsUris = this.mConfig.willInternNsURIs();
/* 288 */       for (int i = 0; i < nsCount; i++) {
/* 289 */         String nsUri = nsURIs.getEntry(i);
/* 290 */         if ((internNsUris) && (nsUri.length() > 0)) {
/* 291 */           nsUri = sInternCache.intern(nsUri);
/*     */         }
/*     */         
/* 294 */         String prefix = nsPrefixes[i];
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 299 */         if (prefix == "xmlns")
/*     */         {
/* 301 */           this.mReporter.throwParseError(ErrorConsts.ERR_NS_REDECL_XMLNS);
/* 302 */         } else if (prefix == "xml")
/*     */         {
/* 304 */           if (!nsUri.equals("http://www.w3.org/XML/1998/namespace")) {
/* 305 */             this.mReporter.throwParseError(ErrorConsts.ERR_NS_REDECL_XML, nsUri);
/*     */ 
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/*     */ 
/* 317 */           if ((nsUri == null) || (nsUri.length() == 0)) {
/* 318 */             nsUri = DEFAULT_NAMESPACE_URI;
/*     */           }
/*     */           
/* 321 */           if (prefix == null) {
/* 322 */             this.mElements[(this.mSize - 1)] = nsUri;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 328 */           if (internNsUris) {
/* 329 */             if (nsUri == "http://www.w3.org/XML/1998/namespace") {
/* 330 */               this.mReporter.throwParseError(ErrorConsts.ERR_NS_REDECL_XML_URI, prefix);
/* 331 */             } else if (nsUri == "http://www.w3.org/2000/xmlns/") {
/* 332 */               this.mReporter.throwParseError(ErrorConsts.ERR_NS_REDECL_XMLNS_URI);
/*     */             }
/*     */           }
/* 335 */           else if (nsUri.equals("http://www.w3.org/XML/1998/namespace")) {
/* 336 */             this.mReporter.throwParseError(ErrorConsts.ERR_NS_REDECL_XML_URI, prefix);
/* 337 */           } else if (nsUri.equals("http://www.w3.org/2000/xmlns/")) {
/* 338 */             this.mReporter.throwParseError(ErrorConsts.ERR_NS_REDECL_XMLNS_URI);
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 344 */           this.mNamespaces.addStrings(prefix, nsUri);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 353 */     if (this.mMayHaveNsDefaults) {
/* 354 */       this.mNsDefaultProvider.checkNsDefaults(this);
/*     */     }
/*     */     
/*     */ 
/* 358 */     String prefix = this.mElements[(this.mSize - 4)];
/*     */     String ns;
/*     */     String ns;
/* 361 */     if ((prefix == null) || (prefix.length() == 0)) {
/* 362 */       ns = this.mElements[(this.mSize - 1)]; } else { String ns;
/* 363 */       if (prefix == "xml") {
/* 364 */         ns = "http://www.w3.org/XML/1998/namespace";
/*     */       }
/*     */       else {
/* 367 */         ns = this.mNamespaces.findLastFromMap(prefix);
/* 368 */         if (ns == null)
/* 369 */           this.mReporter.throwParseError(ErrorConsts.ERR_NS_UNDECLARED, prefix);
/*     */       }
/*     */     }
/* 372 */     this.mElements[(this.mSize - 2)] = ns;
/*     */     
/*     */ 
/* 375 */     int xmlidIx = ac.resolveNamespaces(this.mReporter, this.mNamespaces);
/* 376 */     this.mIdAttrIndex = xmlidIx;
/*     */     
/* 378 */     XMLValidator vld = this.mValidator;
/*     */     
/*     */ 
/*     */ 
/* 382 */     if (vld == null) {
/* 383 */       if (xmlidIx >= 0) {
/* 384 */         normalizeXmlIdAttr(ac, xmlidIx);
/*     */       }
/* 386 */       return 3;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 394 */     vld.validateElementStart(this.mElements[(this.mSize - 3)], this.mElements[(this.mSize - 2)], prefix);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 400 */     StringVector attrNames = ac.getNameList();
/* 401 */     int attrLen = ac.getCount();
/* 402 */     if (attrLen > 0) {
/* 403 */       attrLen += attrLen;
/* 404 */       String[] attrURIs = ac.getAttrURIs();
/* 405 */       String[] nameData = attrNames.getInternalArray();
/* 406 */       TextBuilder attrBuilder = ac.getAttrBuilder();
/* 407 */       char[] attrCB = attrBuilder.getCharBuffer();
/* 408 */       int i = 0; for (int nr = 0; i < attrLen; nr++) {
/* 409 */         prefix = nameData[i];
/* 410 */         String ln = nameData[(i + 1)];
/* 411 */         String normValue = this.mValidator.validateAttribute(ln, attrURIs[nr], prefix, attrCB, attrBuilder.getOffset(nr), attrBuilder.getOffset(nr + 1));
/*     */         
/*     */ 
/*     */ 
/* 415 */         if (normValue != null) {
/* 416 */           ac.setNormalizedValue(nr, normValue);
/*     */         }
/* 408 */         i += 2;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 424 */     return this.mValidator.validateElementAndAttributes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isNamespaceAware()
/*     */   {
/* 434 */     return true;
/*     */   }
/*     */   
/* 437 */   public final int getDepth() { return this.mSize >> 2; }
/*     */   
/*     */   public final AttributeCollector getAttrCollector() {
/* 440 */     return this.mAttrCollector;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final BaseNsContext createNonTransientNsContext(Location loc)
/*     */   {
/* 451 */     if (this.mLastNsContext != null) {
/* 452 */       return this.mLastNsContext;
/*     */     }
/*     */     
/*     */ 
/* 456 */     int totalNsSize = this.mNamespaces.size();
/* 457 */     if (totalNsSize < 1) {
/* 458 */       return this.mLastNsContext = EmptyNamespaceContext.getInstance();
/*     */     }
/*     */     
/*     */ 
/* 462 */     int localCount = getCurrentNsCount() << 1;
/* 463 */     BaseNsContext nsCtxt = new CompactNsContext(loc, getDefaultNsURI(), this.mNamespaces.asArray(), totalNsSize, totalNsSize - localCount);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 471 */     if (localCount == 0) {
/* 472 */       this.mLastNsContext = nsCtxt;
/*     */     }
/* 474 */     return nsCtxt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getNamespaceURI(String prefix)
/*     */   {
/* 485 */     if (prefix == null) {
/* 486 */       throw new IllegalArgumentException(ErrorConsts.ERR_NULL_ARG);
/*     */     }
/* 488 */     if (prefix.length() == 0) {
/* 489 */       if (this.mSize == 0) {
/* 490 */         return null;
/*     */       }
/* 492 */       return this.mElements[(this.mSize - 1)];
/*     */     }
/* 494 */     if (prefix.equals("xml")) {
/* 495 */       return "http://www.w3.org/XML/1998/namespace";
/*     */     }
/* 497 */     if (prefix.equals("xmlns")) {
/* 498 */       return "http://www.w3.org/2000/xmlns/";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 504 */     return this.mNamespaces.findLastNonInterned(prefix);
/*     */   }
/*     */   
/*     */   public final String getPrefix(String nsURI) {
/* 508 */     if ((nsURI == null) || (nsURI.length() == 0)) {
/* 509 */       throw new IllegalArgumentException("Illegal to pass null/empty prefix as argument.");
/*     */     }
/* 511 */     if (nsURI.equals("http://www.w3.org/XML/1998/namespace")) {
/* 512 */       return "xml";
/*     */     }
/* 514 */     if (nsURI.equals("http://www.w3.org/2000/xmlns/")) {
/* 515 */       return "xmlns";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 523 */     String prefix = null;
/*     */     
/*     */ 
/*     */ 
/* 527 */     String[] strs = this.mNamespaces.getInternalArray();
/* 528 */     int len = this.mNamespaces.size();
/*     */     
/*     */     label135:
/* 531 */     for (int index = len - 1; index > 0; index -= 2) {
/* 532 */       if (nsURI.equals(strs[index]))
/*     */       {
/* 534 */         prefix = strs[(index - 1)];
/* 535 */         for (int j = index + 1; j < len; j += 2) {
/* 536 */           if (strs[j] == prefix) {
/* 537 */             prefix = null;
/*     */             
/*     */             break label135;
/*     */           }
/*     */         }
/*     */         
/* 543 */         if (prefix != null) break;
/* 544 */         prefix = ""; break;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 550 */     return prefix;
/*     */   }
/*     */   
/*     */   public final Iterator getPrefixes(String nsURI)
/*     */   {
/* 555 */     if ((nsURI == null) || (nsURI.length() == 0)) {
/* 556 */       throw new IllegalArgumentException("Illegal to pass null/empty prefix as argument.");
/*     */     }
/* 558 */     if (nsURI.equals("http://www.w3.org/XML/1998/namespace")) {
/* 559 */       return new SingletonIterator("xml");
/*     */     }
/* 561 */     if (nsURI.equals("http://www.w3.org/2000/xmlns/")) {
/* 562 */       return new SingletonIterator("xmlns");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 569 */     String[] strs = this.mNamespaces.getInternalArray();
/* 570 */     int len = this.mNamespaces.size();
/* 571 */     ArrayList l = null;
/*     */     
/*     */     label159:
/* 574 */     for (int index = len - 1; index > 0; index -= 2) {
/* 575 */       if (nsURI.equals(strs[index]))
/*     */       {
/* 577 */         String prefix = strs[(index - 1)];
/* 578 */         for (int j = index + 1; j < len; j += 2) {
/* 579 */           if (strs[j] == prefix) {
/*     */             break label159;
/*     */           }
/*     */         }
/*     */         
/* 584 */         if (l == null) {
/* 585 */           l = new ArrayList();
/*     */         }
/* 587 */         l.add(prefix);
/*     */       }
/*     */     }
/*     */     
/* 591 */     return l == null ? EmptyIterator.getInstance() : l.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getAttributeCount()
/*     */   {
/* 602 */     return this.mAttrCollector.getCount();
/*     */   }
/*     */   
/*     */   public final int findAttributeIndex(String nsURI, String localName)
/*     */   {
/* 607 */     return this.mAttrCollector.findIndex(nsURI, localName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final QName getCurrentElementName()
/*     */   {
/* 618 */     if (this.mSize == 0) {
/* 619 */       return null;
/*     */     }
/* 621 */     String prefix = this.mElements[(this.mSize - 4)];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 626 */     if (prefix == null) {
/* 627 */       prefix = "";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 634 */     String nsURI = this.mElements[(this.mSize - 2)];
/* 635 */     String ln = this.mElements[(this.mSize - 3)];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 640 */     if (ln != this.mLastLocalName) {
/* 641 */       this.mLastLocalName = ln;
/* 642 */       this.mLastPrefix = prefix;
/* 643 */       this.mLastNsURI = nsURI;
/* 644 */     } else if (prefix != this.mLastPrefix) {
/* 645 */       this.mLastPrefix = prefix;
/* 646 */       this.mLastNsURI = nsURI;
/* 647 */     } else if (nsURI != this.mLastNsURI) {
/* 648 */       this.mLastNsURI = nsURI;
/*     */     } else {
/* 650 */       return this.mLastName;
/*     */     }
/* 652 */     QName n = QNameCreator.create(nsURI, ln, prefix);
/* 653 */     this.mLastName = n;
/* 654 */     return n;
/*     */   }
/*     */   
/*     */ 
/*     */   public int addDefaultAttribute(String localName, String uri, String prefix, String value)
/*     */   {
/* 660 */     return this.mAttrCollector.addDefaultAttribute(localName, uri, prefix, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPrefixLocallyDeclared(String internedPrefix)
/*     */   {
/* 671 */     if ((internedPrefix != null) && (internedPrefix.length() == 0)) {
/* 672 */       internedPrefix = null;
/*     */     }
/*     */     
/* 675 */     int offset = this.mNsCounts[(this.mSize - 1 >> 2)];
/* 676 */     for (int len = this.mNamespaces.size(); offset < len; offset += 2)
/*     */     {
/* 678 */       String thisPrefix = this.mNamespaces.getString(offset);
/* 679 */       if (thisPrefix == internedPrefix) {
/* 680 */         return true;
/*     */       }
/*     */     }
/* 683 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addNsBinding(String prefix, String uri)
/*     */   {
/* 694 */     if ((uri == null) || (uri.length() == 0)) {
/* 695 */       uri = null;
/*     */     }
/*     */     
/*     */ 
/* 699 */     if ((prefix == null) || (prefix.length() == 0)) {
/* 700 */       prefix = null;
/* 701 */       this.mElements[(this.mSize - 1)] = uri;
/*     */     }
/* 703 */     this.mNamespaces.addStrings(prefix, uri);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isEmpty()
/*     */   {
/* 715 */     return this.mSize == 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public final String getDefaultNsURI()
/*     */   {
/* 721 */     if (this.mSize == 0) {
/* 722 */       throw new IllegalStateException("Illegal access, empty stack.");
/*     */     }
/* 724 */     return this.mElements[(this.mSize - 1)];
/*     */   }
/*     */   
/*     */   public final String getNsURI() {
/* 728 */     if (this.mSize == 0) {
/* 729 */       throw new IllegalStateException("Illegal access, empty stack.");
/*     */     }
/* 731 */     return this.mElements[(this.mSize - 2)];
/*     */   }
/*     */   
/*     */   public final String getPrefix() {
/* 735 */     if (this.mSize == 0) {
/* 736 */       throw new IllegalStateException("Illegal access, empty stack.");
/*     */     }
/* 738 */     return this.mElements[(this.mSize - 4)];
/*     */   }
/*     */   
/*     */   public final String getLocalName() {
/* 742 */     if (this.mSize == 0) {
/* 743 */       throw new IllegalStateException("Illegal access, empty stack.");
/*     */     }
/* 745 */     return this.mElements[(this.mSize - 3)];
/*     */   }
/*     */   
/*     */   public final boolean matches(String prefix, String localName) {
/* 749 */     if (this.mSize == 0) {
/* 750 */       throw new IllegalStateException("Illegal access, empty stack.");
/*     */     }
/* 752 */     String thisPrefix = this.mElements[(this.mSize - 4)];
/* 753 */     if ((prefix == null) || (prefix.length() == 0)) {
/* 754 */       if ((thisPrefix != null) && (thisPrefix.length() > 0)) {
/* 755 */         return false;
/*     */       }
/*     */     }
/* 758 */     else if ((thisPrefix != prefix) && (!thisPrefix.equals(prefix))) {
/* 759 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 763 */     String thisName = this.mElements[(this.mSize - 3)];
/* 764 */     return (thisName == localName) || (thisName.equals(localName));
/*     */   }
/*     */   
/*     */   public final String getTopElementDesc() {
/* 768 */     if (this.mSize == 0) {
/* 769 */       throw new IllegalStateException("Illegal access, empty stack.");
/*     */     }
/* 771 */     String name = this.mElements[(this.mSize - 3)];
/* 772 */     String prefix = this.mElements[(this.mSize - 4)];
/* 773 */     if ((prefix == null) || (prefix.length() == 0)) {
/* 774 */       return name;
/*     */     }
/* 776 */     return prefix + ":" + name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getTotalNsCount()
/*     */   {
/* 786 */     return this.mNamespaces.size() >> 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getCurrentNsCount()
/*     */   {
/* 795 */     return this.mNamespaces.size() - this.mNsCounts[(this.mSize - 1 >> 2)] >> 1;
/*     */   }
/*     */   
/*     */   public final String getLocalNsPrefix(int index) {
/* 799 */     int offset = this.mNsCounts[(this.mSize - 1 >> 2)];
/* 800 */     int localCount = this.mNamespaces.size() - offset;
/* 801 */     index <<= 1;
/* 802 */     if ((index < 0) || (index >= localCount)) {
/* 803 */       throwIllegalIndex(index >> 1, localCount >> 1);
/*     */     }
/* 805 */     return this.mNamespaces.getString(offset + index);
/*     */   }
/*     */   
/*     */   public final String getLocalNsURI(int index)
/*     */   {
/* 810 */     int offset = this.mNsCounts[(this.mSize - 1 >> 2)];
/* 811 */     int localCount = this.mNamespaces.size() - offset;
/* 812 */     index <<= 1;
/* 813 */     if ((index < 0) || (index >= localCount)) {
/* 814 */       throwIllegalIndex(index >> 1, localCount >> 1);
/*     */     }
/* 816 */     return this.mNamespaces.getString(offset + index + 1);
/*     */   }
/*     */   
/*     */   private void throwIllegalIndex(int index, int localCount)
/*     */   {
/* 821 */     throw new IllegalArgumentException("Illegal namespace index " + (index >> 1) + "; current scope only has " + (localCount >> 1) + " namespace declarations.");
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sr\NsInputElementStack.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */