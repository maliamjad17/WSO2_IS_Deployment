/*      */ package com.ctc.wstx.util;
/*      */ 
/*      */ import com.ctc.wstx.api.ReaderConfig;
/*      */ import com.ctc.wstx.dtd.DTDEventListener;
/*      */ import java.io.CharArrayReader;
/*      */ import java.io.IOException;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.io.Writer;
/*      */ import java.util.ArrayList;
/*      */ import org.codehaus.stax2.validation.XMLValidationException;
/*      */ import org.codehaus.stax2.validation.XMLValidator;
/*      */ import org.xml.sax.ContentHandler;
/*      */ import org.xml.sax.SAXException;
/*      */ import org.xml.sax.ext.LexicalHandler;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class TextBuffer
/*      */ {
/*      */   static final int DEF_INITIAL_BUFFER_SIZE = 500;
/*      */   private final ReaderConfig mConfig;
/*      */   private final int mInitialBufSize;
/*      */   private char[] mInputBuffer;
/*      */   private int mInputStart;
/*      */   private int mInputLen;
/*      */   private ArrayList mSegments;
/*      */   private int mSegmentSize;
/*      */   private char[] mCurrentSegment;
/*      */   private int mCurrentSize;
/*      */   private String mResultString;
/*      */   private char[] mResultArray;
/*      */   public static final int MAX_INDENT_SPACES = 32;
/*      */   public static final int MAX_INDENT_TABS = 8;
/*      */   private static final String sIndSpaces = "\n                                 ";
/*  118 */   private static final char[] sIndSpacesArray = "\n                                 ".toCharArray();
/*  119 */   private static final String[] sIndSpacesStrings = new String[sIndSpacesArray.length];
/*      */   
/*      */ 
/*      */   private static final String sIndTabs = "\n\t\t\t\t\t\t\t\t\t";
/*      */   
/*  124 */   private static final char[] sIndTabsArray = "\n\t\t\t\t\t\t\t\t\t".toCharArray();
/*  125 */   private static final String[] sIndTabsStrings = new String[sIndTabsArray.length];
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private TextBuffer(int initialSize, ReaderConfig cfg)
/*      */   {
/*  135 */     this.mInitialBufSize = initialSize;
/*  136 */     this.mConfig = cfg;
/*      */   }
/*      */   
/*      */   public static TextBuffer createRecyclableBuffer(ReaderConfig cfg)
/*      */   {
/*  141 */     return new TextBuffer(500, cfg);
/*      */   }
/*      */   
/*      */   public static TextBuffer createTemporaryBuffer(int initialSize)
/*      */   {
/*  146 */     return new TextBuffer(initialSize, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void recycle(boolean force)
/*      */   {
/*  160 */     if ((this.mConfig != null) && (this.mCurrentSegment != null)) {
/*  161 */       if (force)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  166 */         resetWithEmpty();
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  171 */         if ((this.mInputStart < 0) && (this.mSegmentSize + this.mCurrentSize > 0)) {
/*  172 */           return;
/*      */         }
/*      */         
/*  175 */         if ((this.mSegments != null) && (this.mSegments.size() > 0))
/*      */         {
/*  177 */           this.mSegments.clear();
/*  178 */           this.mSegmentSize = 0;
/*      */         }
/*      */       }
/*      */       
/*  182 */       char[] buf = this.mCurrentSegment;
/*  183 */       this.mCurrentSegment = null;
/*  184 */       this.mConfig.freeMediumCBuffer(buf);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resetWithEmpty()
/*      */   {
/*  195 */     this.mInputBuffer = null;
/*  196 */     this.mInputStart = -1;
/*  197 */     this.mInputLen = 0;
/*      */     
/*  199 */     this.mResultString = null;
/*  200 */     this.mResultArray = null;
/*      */     
/*      */ 
/*  203 */     if ((this.mSegments != null) && (this.mSegments.size() > 0))
/*      */     {
/*      */ 
/*      */ 
/*  207 */       this.mCurrentSegment = ((char[])this.mSegments.get(this.mSegments.size() - 1));
/*  208 */       this.mSegments.clear();
/*  209 */       this.mSegmentSize = 0;
/*      */     }
/*  211 */     this.mCurrentSize = 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resetWithShared(char[] buf, int start, int len)
/*      */   {
/*  224 */     this.mInputBuffer = buf;
/*  225 */     this.mInputStart = start;
/*  226 */     this.mInputLen = len;
/*      */     
/*      */ 
/*  229 */     this.mResultString = null;
/*  230 */     this.mResultArray = null;
/*      */     
/*      */ 
/*  233 */     if ((this.mSegments != null) && (this.mSegments.size() > 0))
/*      */     {
/*      */ 
/*      */ 
/*  237 */       this.mCurrentSegment = ((char[])this.mSegments.get(this.mSegments.size() - 1));
/*  238 */       this.mSegments.clear();
/*  239 */       this.mCurrentSize = (this.mSegmentSize = 0);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void resetWithCopy(char[] buf, int start, int len)
/*      */   {
/*  246 */     this.mInputBuffer = null;
/*  247 */     this.mInputStart = -1;
/*  248 */     this.mInputLen = 0;
/*      */     
/*  250 */     this.mResultString = null;
/*  251 */     this.mResultArray = null;
/*      */     
/*      */ 
/*  254 */     if ((this.mSegments != null) && (this.mSegments.size() > 0))
/*      */     {
/*      */ 
/*      */ 
/*  258 */       this.mCurrentSegment = ((char[])this.mSegments.get(this.mSegments.size() - 1));
/*  259 */       this.mSegments.clear();
/*      */     }
/*  261 */     else if (this.mCurrentSegment == null) {
/*  262 */       this.mCurrentSegment = allocBuffer(this.mInitialBufSize);
/*      */     }
/*      */     
/*  265 */     this.mCurrentSize = (this.mSegmentSize = 0);
/*  266 */     append(buf, start, len);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resetInitialized()
/*      */   {
/*  275 */     resetWithEmpty();
/*  276 */     if (this.mCurrentSegment == null) {
/*  277 */       this.mCurrentSegment = allocBuffer(this.mInitialBufSize);
/*      */     }
/*      */   }
/*      */   
/*      */   private final char[] allocBuffer(int needed)
/*      */   {
/*  283 */     char[] buf = null;
/*  284 */     if (this.mConfig != null) {
/*  285 */       buf = this.mConfig.allocMediumCBuffer(needed);
/*  286 */       if (buf != null) {
/*  287 */         return buf;
/*      */       }
/*      */     }
/*  290 */     return new char[needed];
/*      */   }
/*      */   
/*      */   public void resetWithIndentation(int indCharCount, char indChar)
/*      */   {
/*  295 */     this.mInputStart = 0;
/*  296 */     this.mInputLen = (indCharCount + 1);
/*      */     String text;
/*  298 */     if (indChar == '\t') {
/*  299 */       this.mInputBuffer = sIndTabsArray;
/*  300 */       String text = sIndTabsStrings[indCharCount];
/*  301 */       if (text == null) {
/*  302 */         sIndTabsStrings[indCharCount] = (text = "\n\t\t\t\t\t\t\t\t\t".substring(0, this.mInputLen));
/*      */       }
/*      */     } else {
/*  305 */       this.mInputBuffer = sIndSpacesArray;
/*  306 */       text = sIndSpacesStrings[indCharCount];
/*  307 */       if (text == null) {
/*  308 */         sIndSpacesStrings[indCharCount] = (text = "\n                                 ".substring(0, this.mInputLen));
/*      */       }
/*      */     }
/*  311 */     this.mResultString = text;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  316 */     this.mResultArray = null;
/*      */     
/*      */ 
/*  319 */     if ((this.mSegments != null) && (this.mSegments.size() > 0)) {
/*  320 */       this.mCurrentSegment = ((char[])this.mSegments.get(this.mSegments.size() - 1));
/*  321 */       this.mSegments.clear();
/*  322 */       this.mCurrentSize = (this.mSegmentSize = 0);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int size()
/*      */   {
/*  336 */     if (this.mInputStart >= 0) {
/*  337 */       return this.mInputLen;
/*      */     }
/*      */     
/*  340 */     return this.mSegmentSize + this.mCurrentSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTextStart()
/*      */   {
/*  349 */     return this.mInputStart >= 0 ? this.mInputStart : 0;
/*      */   }
/*      */   
/*      */ 
/*      */   public char[] getTextBuffer()
/*      */   {
/*  355 */     if (this.mInputStart >= 0) {
/*  356 */       return this.mInputBuffer;
/*      */     }
/*      */     
/*  359 */     if ((this.mSegments == null) || (this.mSegments.size() == 0)) {
/*  360 */       return this.mCurrentSegment;
/*      */     }
/*      */     
/*  363 */     return contentsAsArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String contentsAsString()
/*      */   {
/*  374 */     if (this.mResultString == null)
/*      */     {
/*  376 */       if (this.mResultArray != null) {
/*  377 */         this.mResultString = new String(this.mResultArray);
/*      */ 
/*      */       }
/*  380 */       else if (this.mInputStart >= 0) {
/*  381 */         if (this.mInputLen < 1) {
/*  382 */           return this.mResultString = "";
/*      */         }
/*  384 */         this.mResultString = new String(this.mInputBuffer, this.mInputStart, this.mInputLen);
/*      */       }
/*      */       else {
/*  387 */         int segLen = this.mSegmentSize;
/*  388 */         int currLen = this.mCurrentSize;
/*      */         
/*  390 */         if (segLen == 0) {
/*  391 */           this.mResultString = (currLen == 0 ? "" : new String(this.mCurrentSegment, 0, currLen));
/*      */         } else {
/*  393 */           StringBuffer sb = new StringBuffer(segLen + currLen);
/*      */           
/*  395 */           if (this.mSegments != null) {
/*  396 */             int i = 0; for (int len = this.mSegments.size(); i < len; i++) {
/*  397 */               char[] curr = (char[])this.mSegments.get(i);
/*  398 */               sb.append(curr, 0, curr.length);
/*      */             }
/*      */           }
/*      */           
/*  402 */           sb.append(this.mCurrentSegment, 0, this.mCurrentSize);
/*  403 */           this.mResultString = sb.toString();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  408 */     return this.mResultString;
/*      */   }
/*      */   
/*      */   public char[] contentsAsArray()
/*      */   {
/*  413 */     char[] result = this.mResultArray;
/*  414 */     if (result == null) {
/*  415 */       this.mResultArray = (result = buildResultArray());
/*      */     }
/*  417 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int contentsToArray(int srcStart, char[] dst, int dstStart, int len)
/*      */   {
/*  424 */     if (this.mInputStart >= 0)
/*      */     {
/*      */ 
/*  427 */       int amount = this.mInputLen - srcStart;
/*  428 */       if (amount > len) {
/*  429 */         amount = len;
/*  430 */       } else if (amount < 0) {
/*  431 */         amount = 0;
/*      */       }
/*  433 */       if (amount > 0) {
/*  434 */         System.arraycopy(this.mInputBuffer, this.mInputStart + srcStart, dst, dstStart, amount);
/*      */       }
/*      */       
/*  437 */       return amount;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  448 */     int totalAmount = 0;
/*  449 */     if (this.mSegments != null) {
/*  450 */       int i = 0; for (int segc = this.mSegments.size(); i < segc; i++) {
/*  451 */         char[] segment = (char[])this.mSegments.get(i);
/*  452 */         int segLen = segment.length;
/*  453 */         int amount = segLen - srcStart;
/*  454 */         if (amount < 1) {
/*  455 */           srcStart -= segLen;
/*      */         }
/*      */         else {
/*  458 */           if (amount >= len) {
/*  459 */             System.arraycopy(segment, srcStart, dst, dstStart, len);
/*  460 */             return totalAmount + len;
/*      */           }
/*      */           
/*  463 */           System.arraycopy(segment, srcStart, dst, dstStart, amount);
/*  464 */           totalAmount += amount;
/*  465 */           dstStart += amount;
/*  466 */           len -= amount;
/*  467 */           srcStart = 0;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  472 */     if (len > 0) {
/*  473 */       int maxAmount = this.mCurrentSize - srcStart;
/*  474 */       if (len > maxAmount) {
/*  475 */         len = maxAmount;
/*      */       }
/*  477 */       if (len > 0) {
/*  478 */         System.arraycopy(this.mCurrentSegment, srcStart, dst, dstStart, len);
/*  479 */         totalAmount += len;
/*      */       }
/*      */     }
/*      */     
/*  483 */     return totalAmount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int rawContentsTo(Writer w)
/*      */     throws IOException
/*      */   {
/*  494 */     if (this.mResultArray != null) {
/*  495 */       w.write(this.mResultArray);
/*  496 */       return this.mResultArray.length;
/*      */     }
/*  498 */     if (this.mResultString != null) {
/*  499 */       w.write(this.mResultString);
/*  500 */       return this.mResultString.length();
/*      */     }
/*      */     
/*      */ 
/*  504 */     if (this.mInputStart >= 0) {
/*  505 */       if (this.mInputLen > 0) {
/*  506 */         w.write(this.mInputBuffer, this.mInputStart, this.mInputLen);
/*      */       }
/*  508 */       return this.mInputLen;
/*      */     }
/*      */     
/*  511 */     int rlen = 0;
/*  512 */     if (this.mSegments != null) {
/*  513 */       int i = 0; for (int len = this.mSegments.size(); i < len; i++) {
/*  514 */         char[] ch = (char[])this.mSegments.get(i);
/*  515 */         w.write(ch);
/*  516 */         rlen += ch.length;
/*      */       }
/*      */     }
/*  519 */     if (this.mCurrentSize > 0) {
/*  520 */       w.write(this.mCurrentSegment, 0, this.mCurrentSize);
/*  521 */       rlen += this.mCurrentSize;
/*      */     }
/*  523 */     return rlen;
/*      */   }
/*      */   
/*      */ 
/*      */   public Reader rawContentsViaReader()
/*      */     throws IOException
/*      */   {
/*  530 */     if (this.mResultArray != null) {
/*  531 */       return new CharArrayReader(this.mResultArray);
/*      */     }
/*  533 */     if (this.mResultString != null) {
/*  534 */       return new StringReader(this.mResultString);
/*      */     }
/*      */     
/*      */ 
/*  538 */     if (this.mInputStart >= 0) {
/*  539 */       if (this.mInputLen > 0) {
/*  540 */         return new CharArrayReader(this.mInputBuffer, this.mInputStart, this.mInputLen);
/*      */       }
/*  542 */       return new StringReader("");
/*      */     }
/*      */     
/*  545 */     if ((this.mSegments == null) || (this.mSegments.size() == 0)) {
/*  546 */       return new CharArrayReader(this.mCurrentSegment, 0, this.mCurrentSize);
/*      */     }
/*      */     
/*  549 */     return new BufferReader(this.mSegments, this.mCurrentSegment, this.mCurrentSize);
/*      */   }
/*      */   
/*      */   public boolean isAllWhitespace()
/*      */   {
/*  554 */     if (this.mInputStart >= 0) {
/*  555 */       char[] buf = this.mInputBuffer;
/*  556 */       int i = this.mInputStart;
/*  557 */       int last = i + this.mInputLen;
/*  558 */       for (; i < last; i++) {
/*  559 */         if (buf[i] > ' ') {
/*  560 */           return false;
/*      */         }
/*      */       }
/*  563 */       return true;
/*      */     }
/*      */     
/*      */ 
/*  567 */     if (this.mSegments != null) {
/*  568 */       int i = 0; for (int len = this.mSegments.size(); i < len; i++) {
/*  569 */         char[] buf = (char[])this.mSegments.get(i);
/*  570 */         int j = 0; for (int len2 = buf.length; j < len2; j++) {
/*  571 */           if (buf[j] > ' ') {
/*  572 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  578 */     char[] buf = this.mCurrentSegment;
/*  579 */     int i = 0; for (int len = this.mCurrentSize; i < len; i++) {
/*  580 */       if (buf[i] > ' ') {
/*  581 */         return false;
/*      */       }
/*      */     }
/*  584 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean endsWith(String str)
/*      */   {
/*  600 */     if (this.mInputStart >= 0) {
/*  601 */       unshare(16);
/*      */     }
/*      */     
/*  604 */     int segIndex = this.mSegments == null ? 0 : this.mSegments.size();
/*  605 */     int inIndex = str.length() - 1;
/*  606 */     char[] buf = this.mCurrentSegment;
/*  607 */     int bufIndex = this.mCurrentSize - 1;
/*      */     
/*  609 */     while (inIndex >= 0) {
/*  610 */       if (str.charAt(inIndex) != buf[bufIndex]) {
/*  611 */         return false;
/*      */       }
/*  613 */       inIndex--; if (inIndex == 0) {
/*      */         break;
/*      */       }
/*  616 */       bufIndex--; if (bufIndex < 0) {
/*  617 */         segIndex--; if (segIndex < 0) {
/*  618 */           return false;
/*      */         }
/*  620 */         buf = (char[])this.mSegments.get(segIndex);
/*  621 */         bufIndex = buf.length - 1;
/*      */       }
/*      */     }
/*      */     
/*  625 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean equalsString(String str)
/*      */   {
/*  636 */     int expLen = str.length();
/*      */     
/*      */ 
/*  639 */     if (this.mInputStart >= 0) {
/*  640 */       if (this.mInputLen != expLen) {
/*  641 */         return false;
/*      */       }
/*  643 */       for (int i = 0; i < expLen; i++) {
/*  644 */         if (str.charAt(i) != this.mInputBuffer[(this.mInputStart + i)]) {
/*  645 */           return false;
/*      */         }
/*      */       }
/*  648 */       return true;
/*      */     }
/*      */     
/*      */ 
/*  652 */     if (expLen != size())
/*  653 */       return false;
/*      */     char[] seg;
/*      */     char[] seg;
/*  656 */     if ((this.mSegments == null) || (this.mSegments.size() == 0))
/*      */     {
/*  658 */       seg = this.mCurrentSegment;
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*  664 */       seg = contentsAsArray();
/*      */     }
/*      */     
/*  667 */     for (int i = 0; i < expLen; i++) {
/*  668 */       if (seg[i] != str.charAt(i)) {
/*  669 */         return false;
/*      */       }
/*      */     }
/*  672 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fireSaxCharacterEvents(ContentHandler h)
/*      */     throws SAXException
/*      */   {
/*  684 */     if (this.mResultArray != null) {
/*  685 */       h.characters(this.mResultArray, 0, this.mResultArray.length);
/*  686 */     } else if (this.mInputStart >= 0) {
/*  687 */       h.characters(this.mInputBuffer, this.mInputStart, this.mInputLen);
/*      */     } else {
/*  689 */       if (this.mSegments != null) {
/*  690 */         int i = 0; for (int len = this.mSegments.size(); i < len; i++) {
/*  691 */           char[] ch = (char[])this.mSegments.get(i);
/*  692 */           h.characters(ch, 0, ch.length);
/*      */         }
/*      */       }
/*  695 */       if (this.mCurrentSize > 0) {
/*  696 */         h.characters(this.mCurrentSegment, 0, this.mCurrentSize);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void fireSaxSpaceEvents(ContentHandler h)
/*      */     throws SAXException
/*      */   {
/*  704 */     if (this.mResultArray != null) {
/*  705 */       h.ignorableWhitespace(this.mResultArray, 0, this.mResultArray.length);
/*  706 */     } else if (this.mInputStart >= 0) {
/*  707 */       h.ignorableWhitespace(this.mInputBuffer, this.mInputStart, this.mInputLen);
/*      */     } else {
/*  709 */       if (this.mSegments != null) {
/*  710 */         int i = 0; for (int len = this.mSegments.size(); i < len; i++) {
/*  711 */           char[] ch = (char[])this.mSegments.get(i);
/*  712 */           h.ignorableWhitespace(ch, 0, ch.length);
/*      */         }
/*      */       }
/*  715 */       if (this.mCurrentSize > 0) {
/*  716 */         h.ignorableWhitespace(this.mCurrentSegment, 0, this.mCurrentSize);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void fireSaxCommentEvent(LexicalHandler h)
/*      */     throws SAXException
/*      */   {
/*  725 */     if (this.mResultArray != null) {
/*  726 */       h.comment(this.mResultArray, 0, this.mResultArray.length);
/*  727 */     } else if (this.mInputStart >= 0) {
/*  728 */       h.comment(this.mInputBuffer, this.mInputStart, this.mInputLen);
/*  729 */     } else if ((this.mSegments != null) && (this.mSegments.size() > 0)) {
/*  730 */       char[] ch = contentsAsArray();
/*  731 */       h.comment(ch, 0, ch.length);
/*      */     } else {
/*  733 */       h.comment(this.mCurrentSegment, 0, this.mCurrentSize);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void fireDtdCommentEvent(DTDEventListener l)
/*      */   {
/*  740 */     if (this.mResultArray != null) {
/*  741 */       l.dtdComment(this.mResultArray, 0, this.mResultArray.length);
/*  742 */     } else if (this.mInputStart >= 0) {
/*  743 */       l.dtdComment(this.mInputBuffer, this.mInputStart, this.mInputLen);
/*  744 */     } else if ((this.mSegments != null) && (this.mSegments.size() > 0)) {
/*  745 */       char[] ch = contentsAsArray();
/*  746 */       l.dtdComment(ch, 0, ch.length);
/*      */     } else {
/*  748 */       l.dtdComment(this.mCurrentSegment, 0, this.mCurrentSize);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void validateText(XMLValidator vld, boolean lastSegment)
/*      */     throws XMLValidationException
/*      */   {
/*  762 */     if (this.mInputStart >= 0) {
/*  763 */       vld.validateText(this.mInputBuffer, this.mInputStart, this.mInputStart + this.mInputLen, lastSegment);
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*  770 */       vld.validateText(contentsAsString(), lastSegment);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void ensureNotShared()
/*      */   {
/*  785 */     if (this.mInputStart >= 0) {
/*  786 */       unshare(16);
/*      */     }
/*      */   }
/*      */   
/*      */   public void append(char c)
/*      */   {
/*  792 */     if (this.mInputStart >= 0) {
/*  793 */       unshare(16);
/*      */     }
/*  795 */     this.mResultString = null;
/*  796 */     this.mResultArray = null;
/*      */     
/*  798 */     char[] curr = this.mCurrentSegment;
/*  799 */     if (this.mCurrentSize >= curr.length) {
/*  800 */       expand(1);
/*      */     }
/*  802 */     curr[(this.mCurrentSize++)] = c;
/*      */   }
/*      */   
/*      */ 
/*      */   public void append(char[] c, int start, int len)
/*      */   {
/*  808 */     if (this.mInputStart >= 0) {
/*  809 */       unshare(len);
/*      */     }
/*  811 */     this.mResultString = null;
/*  812 */     this.mResultArray = null;
/*      */     
/*      */ 
/*  815 */     char[] curr = this.mCurrentSegment;
/*  816 */     int max = curr.length - this.mCurrentSize;
/*      */     
/*  818 */     if (max >= len) {
/*  819 */       System.arraycopy(c, start, curr, this.mCurrentSize, len);
/*  820 */       this.mCurrentSize += len;
/*      */     }
/*      */     else {
/*  823 */       if (max > 0) {
/*  824 */         System.arraycopy(c, start, curr, this.mCurrentSize, max);
/*  825 */         start += max;
/*  826 */         len -= max;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  831 */       expand(len);
/*  832 */       System.arraycopy(c, start, this.mCurrentSegment, 0, len);
/*  833 */       this.mCurrentSize = len;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void append(String str)
/*      */   {
/*  840 */     int len = str.length();
/*  841 */     if (this.mInputStart >= 0) {
/*  842 */       unshare(len);
/*      */     }
/*  844 */     this.mResultString = null;
/*  845 */     this.mResultArray = null;
/*      */     
/*      */ 
/*  848 */     char[] curr = this.mCurrentSegment;
/*  849 */     int max = curr.length - this.mCurrentSize;
/*  850 */     if (max >= len) {
/*  851 */       str.getChars(0, len, curr, this.mCurrentSize);
/*  852 */       this.mCurrentSize += len;
/*      */     }
/*      */     else {
/*  855 */       if (max > 0) {
/*  856 */         str.getChars(0, max, curr, this.mCurrentSize);
/*  857 */         len -= max;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  862 */       expand(len);
/*  863 */       str.getChars(max, len, this.mCurrentSegment, 0);
/*  864 */       this.mCurrentSize = len;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public char[] getCurrentSegment()
/*      */   {
/*  880 */     if (this.mInputStart >= 0) {
/*  881 */       unshare(1);
/*      */     } else {
/*  883 */       char[] curr = this.mCurrentSegment;
/*  884 */       if (curr == null) {
/*  885 */         this.mCurrentSegment = allocBuffer(this.mInitialBufSize);
/*  886 */       } else if (this.mCurrentSize >= curr.length)
/*      */       {
/*  888 */         expand(1);
/*      */       }
/*      */     }
/*  891 */     return this.mCurrentSegment;
/*      */   }
/*      */   
/*      */   public int getCurrentSegmentSize() {
/*  895 */     return this.mCurrentSize;
/*      */   }
/*      */   
/*      */   public void setCurrentLength(int len) {
/*  899 */     this.mCurrentSize = len;
/*      */   }
/*      */   
/*      */   public char[] finishCurrentSegment()
/*      */   {
/*  904 */     if (this.mSegments == null) {
/*  905 */       this.mSegments = new ArrayList();
/*      */     }
/*  907 */     this.mSegments.add(this.mCurrentSegment);
/*  908 */     int oldLen = this.mCurrentSegment.length;
/*  909 */     this.mSegmentSize += oldLen;
/*      */     
/*  911 */     char[] curr = new char[oldLen + (oldLen >> 1)];
/*  912 */     this.mCurrentSize = 0;
/*  913 */     this.mCurrentSegment = curr;
/*  914 */     return curr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/*  929 */     return contentsAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void unshare(int needExtra)
/*      */   {
/*  945 */     int len = this.mInputLen;
/*  946 */     this.mInputLen = 0;
/*  947 */     char[] inputBuf = this.mInputBuffer;
/*  948 */     this.mInputBuffer = null;
/*  949 */     int start = this.mInputStart;
/*  950 */     this.mInputStart = -1;
/*      */     
/*      */ 
/*  953 */     int needed = len + needExtra;
/*  954 */     if ((this.mCurrentSegment == null) || (needed > this.mCurrentSegment.length)) {
/*  955 */       this.mCurrentSegment = allocBuffer(needed > this.mInitialBufSize ? needed : this.mInitialBufSize);
/*      */     }
/*      */     
/*  958 */     if (len > 0) {
/*  959 */       System.arraycopy(inputBuf, start, this.mCurrentSegment, 0, len);
/*      */     }
/*  961 */     this.mSegmentSize = 0;
/*  962 */     this.mCurrentSize = len;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void expand(int minNewSegmentSize)
/*      */   {
/*  972 */     if (this.mSegments == null) {
/*  973 */       this.mSegments = new ArrayList();
/*      */     }
/*  975 */     char[] curr = this.mCurrentSegment;
/*  976 */     this.mSegments.add(curr);
/*  977 */     this.mSegmentSize += curr.length;
/*  978 */     int oldLen = curr.length;
/*      */     
/*  980 */     int sizeAddition = oldLen >> 1;
/*  981 */     if (sizeAddition < minNewSegmentSize) {
/*  982 */       sizeAddition = minNewSegmentSize;
/*      */     }
/*  984 */     curr = new char[oldLen + sizeAddition];
/*  985 */     this.mCurrentSize = 0;
/*  986 */     this.mCurrentSegment = curr;
/*      */   }
/*      */   
/*      */   private char[] buildResultArray()
/*      */   {
/*  991 */     if (this.mResultString != null) {
/*  992 */       return this.mResultString.toCharArray();
/*      */     }
/*      */     
/*      */     char[] result;
/*      */     
/*  997 */     if (this.mInputStart >= 0) {
/*  998 */       if (this.mInputLen < 1) {
/*  999 */         return EmptyIterator.getEmptyCharArray();
/*      */       }
/* 1001 */       char[] result = new char[this.mInputLen];
/* 1002 */       System.arraycopy(this.mInputBuffer, this.mInputStart, result, 0, this.mInputLen);
/*      */     }
/*      */     else {
/* 1005 */       int size = size();
/* 1006 */       if (size < 1) {
/* 1007 */         return EmptyIterator.getEmptyCharArray();
/*      */       }
/* 1009 */       int offset = 0;
/* 1010 */       result = new char[size];
/* 1011 */       if (this.mSegments != null) {
/* 1012 */         int i = 0; for (int len = this.mSegments.size(); i < len; i++) {
/* 1013 */           char[] curr = (char[])this.mSegments.get(i);
/* 1014 */           int currLen = curr.length;
/* 1015 */           System.arraycopy(curr, 0, result, offset, currLen);
/* 1016 */           offset += currLen;
/*      */         }
/*      */       }
/* 1019 */       System.arraycopy(this.mCurrentSegment, 0, result, offset, this.mCurrentSize);
/*      */     }
/* 1021 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */   private static final class BufferReader
/*      */     extends Reader
/*      */   {
/*      */     ArrayList _Segments;
/*      */     char[] _CurrentSegment;
/*      */     final int _CurrentLength;
/*      */     int _SegmentIndex;
/*      */     int _SegmentOffset;
/*      */     int _CurrentOffset;
/*      */     
/*      */     public BufferReader(ArrayList segs, char[] currSeg, int currSegLen)
/*      */     {
/* 1037 */       this._Segments = segs;
/* 1038 */       this._CurrentSegment = currSeg;
/* 1039 */       this._CurrentLength = currSegLen;
/*      */       
/* 1041 */       this._SegmentIndex = 0;
/* 1042 */       this._SegmentOffset = (this._CurrentOffset = 0);
/*      */     }
/*      */     
/*      */     public void close() {
/* 1046 */       this._Segments = null;
/* 1047 */       this._CurrentSegment = null;
/*      */     }
/*      */     
/*      */     public void mark(int x)
/*      */       throws IOException
/*      */     {
/* 1053 */       throw new IOException("mark() not supported");
/*      */     }
/*      */     
/*      */     public boolean markSupported() {
/* 1057 */       return false;
/*      */     }
/*      */     
/*      */     public int read(char[] cbuf, int offset, int len)
/*      */     {
/* 1062 */       if (len < 1) {
/* 1063 */         return 0;
/*      */       }
/*      */       
/* 1066 */       int origOffset = offset;
/*      */       
/* 1068 */       while (this._Segments != null) {
/* 1069 */         char[] curr = (char[])this._Segments.get(this._SegmentIndex);
/* 1070 */         int max = curr.length - this._SegmentOffset;
/* 1071 */         if (len <= max) {
/* 1072 */           System.arraycopy(curr, this._SegmentOffset, cbuf, offset, len);
/* 1073 */           this._SegmentOffset += len;
/* 1074 */           offset += len;
/* 1075 */           return offset - origOffset;
/*      */         }
/*      */         
/* 1078 */         if (max > 0) {
/* 1079 */           System.arraycopy(curr, this._SegmentOffset, cbuf, offset, max);
/* 1080 */           offset += max;
/*      */         }
/* 1082 */         if (++this._SegmentIndex >= this._Segments.size()) {
/* 1083 */           this._Segments = null;
/*      */         } else {
/* 1085 */           this._SegmentOffset = 0;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1090 */       if ((len > 0) && (this._CurrentSegment != null)) {
/* 1091 */         int max = this._CurrentLength - this._CurrentOffset;
/* 1092 */         if (len >= max) {
/* 1093 */           len = max;
/* 1094 */           System.arraycopy(this._CurrentSegment, this._CurrentOffset, cbuf, offset, len);
/*      */           
/* 1096 */           this._CurrentSegment = null;
/*      */         } else {
/* 1098 */           System.arraycopy(this._CurrentSegment, this._CurrentOffset, cbuf, offset, len);
/*      */           
/* 1100 */           this._CurrentOffset += len;
/*      */         }
/* 1102 */         offset += len;
/*      */       }
/*      */       
/* 1105 */       return origOffset == offset ? -1 : offset - origOffset;
/*      */     }
/*      */     
/*      */     public boolean ready() {
/* 1109 */       return true;
/*      */     }
/*      */     
/*      */     public void reset()
/*      */       throws IOException
/*      */     {
/* 1115 */       throw new IOException("reset() not supported");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public long skip(long amount)
/*      */     {
/* 1123 */       if (amount < 0L) {
/* 1124 */         return 0L;
/*      */       }
/*      */       
/* 1127 */       long origAmount = amount;
/*      */       
/* 1129 */       while (this._Segments != null) {
/* 1130 */         char[] curr = (char[])this._Segments.get(this._SegmentIndex);
/* 1131 */         int max = curr.length - this._SegmentOffset;
/* 1132 */         if (max >= amount) {
/* 1133 */           this._SegmentOffset += (int)amount;
/* 1134 */           return origAmount;
/*      */         }
/*      */         
/* 1137 */         amount -= max;
/* 1138 */         if (++this._SegmentIndex >= this._Segments.size()) {
/* 1139 */           this._Segments = null;
/*      */         } else {
/* 1141 */           this._SegmentOffset = 0;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1146 */       if ((amount > 0L) && (this._CurrentSegment != null)) {
/* 1147 */         int max = this._CurrentLength - this._CurrentOffset;
/* 1148 */         if (amount >= max) {
/* 1149 */           amount -= max;
/* 1150 */           this._CurrentSegment = null;
/*      */         } else {
/* 1152 */           amount = 0L;
/* 1153 */           this._CurrentOffset += (int)amount;
/*      */         }
/*      */       }
/*      */       
/* 1157 */       return amount == origAmount ? -1L : origAmount - amount;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\util\TextBuffer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */