/*     */ package com.ctc.wstx.evt;
/*     */ 
/*     */ import com.ctc.wstx.io.TextEscaper;
/*     */ import com.ctc.wstx.sr.ElemAttrs;
/*     */ import com.ctc.wstx.util.BaseNsContext;
/*     */ import com.ctc.wstx.util.EmptyIterator;
/*     */ import com.ctc.wstx.util.SingletonIterator;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.stream.events.Attribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompactStartElement
/*     */   extends BaseStartElement
/*     */ {
/*     */   private static final int OFFSET_LOCAL_NAME = 0;
/*     */   private static final int OFFSET_NS_URI = 1;
/*     */   private static final int OFFSET_NS_PREFIX = 2;
/*     */   private static final int OFFSET_VALUE = 3;
/*     */   final ElemAttrs mAttrs;
/*     */   final String[] mRawAttrs;
/*  64 */   private ArrayList mAttrList = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected CompactStartElement(Location loc, QName name, BaseNsContext nsCtxt, ElemAttrs attrs)
/*     */   {
/*  76 */     super(loc, name, nsCtxt);
/*  77 */     this.mAttrs = attrs;
/*  78 */     this.mRawAttrs = (attrs == null ? null : attrs.getRawAttrs());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Attribute getAttributeByName(QName name)
/*     */   {
/*  89 */     if (this.mAttrs == null) {
/*  90 */       return null;
/*     */     }
/*  92 */     int ix = this.mAttrs.findIndex(name);
/*  93 */     if (ix < 0) {
/*  94 */       return null;
/*     */     }
/*  96 */     return constructAttr(this.mRawAttrs, ix, !this.mAttrs.isDefault(ix));
/*     */   }
/*     */   
/*     */   public Iterator getAttributes()
/*     */   {
/* 101 */     if (this.mAttrList == null) {
/* 102 */       if (this.mAttrs == null) {
/* 103 */         return EmptyIterator.getInstance();
/*     */       }
/* 105 */       String[] rawAttrs = this.mRawAttrs;
/* 106 */       int rawLen = rawAttrs.length;
/* 107 */       int defOffset = this.mAttrs.getFirstDefaultOffset();
/* 108 */       if (rawLen == 4) {
/* 109 */         return new SingletonIterator(constructAttr(rawAttrs, 0, defOffset == 0));
/*     */       }
/*     */       
/* 112 */       ArrayList l = new ArrayList(rawLen >> 2);
/* 113 */       for (int i = 0; i < rawLen; i += 4) {
/* 114 */         l.add(constructAttr(rawAttrs, i, i >= defOffset));
/*     */       }
/* 116 */       this.mAttrList = l;
/*     */     }
/* 118 */     return this.mAttrList.iterator();
/*     */   }
/*     */   
/*     */   protected void outputNsAndAttr(Writer w) throws IOException
/*     */   {
/* 123 */     if (this.mNsCtxt != null) {
/* 124 */       this.mNsCtxt.outputNamespaceDeclarations(w);
/*     */     }
/*     */     
/* 127 */     String[] raw = this.mRawAttrs;
/* 128 */     if (raw != null) {
/* 129 */       int i = 0; for (int len = raw.length; i < len; i += 4) {
/* 130 */         w.write(32);
/* 131 */         String prefix = raw[(i + 2)];
/* 132 */         if ((prefix != null) && (prefix.length() > 0)) {
/* 133 */           w.write(prefix);
/* 134 */           w.write(58);
/*     */         }
/* 136 */         w.write(raw[i]);
/* 137 */         w.write("=\"");
/* 138 */         TextEscaper.writeEscapedAttrValue(w, raw[(i + 3)]);
/* 139 */         w.write(34);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void outputNsAndAttr(XMLStreamWriter w) throws XMLStreamException
/*     */   {
/* 146 */     if (this.mNsCtxt != null) {
/* 147 */       this.mNsCtxt.outputNamespaceDeclarations(w);
/*     */     }
/* 149 */     String[] raw = this.mRawAttrs;
/* 150 */     if (raw != null) {
/* 151 */       int i = 0; for (int len = raw.length; i < len; i += 4) {
/* 152 */         String ln = raw[i];
/* 153 */         String prefix = raw[(i + 2)];
/* 154 */         String nsURI = raw[(i + 1)];
/* 155 */         w.writeAttribute(prefix, nsURI, ln, raw[(i + 3)]);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WAttribute constructAttr(String[] raw, int rawIndex, boolean isDef)
/*     */   {
/* 168 */     return new WAttribute(this.mLocation, raw[rawIndex], raw[(rawIndex + 1)], raw[(rawIndex + 2)], raw[(rawIndex + 3)], isDef);
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\evt\CompactStartElement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */