/*     */ package com.ctc.wstx.stax;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import com.ctc.wstx.cfg.InputConfigFlags;
/*     */ import com.ctc.wstx.dom.DOMWrappingReader;
/*     */ import com.ctc.wstx.dtd.DTDId;
/*     */ import com.ctc.wstx.dtd.DTDSubset;
/*     */ import com.ctc.wstx.evt.DefaultEventAllocator;
/*     */ import com.ctc.wstx.evt.FilteredEventReader;
/*     */ import com.ctc.wstx.evt.WstxEventReader;
/*     */ import com.ctc.wstx.exc.WstxIOException;
/*     */ import com.ctc.wstx.io.BranchingReaderSource;
/*     */ import com.ctc.wstx.io.DefaultInputResolver;
/*     */ import com.ctc.wstx.io.InputBootstrapper;
/*     */ import com.ctc.wstx.io.InputSourceFactory;
/*     */ import com.ctc.wstx.io.ReaderBootstrapper;
/*     */ import com.ctc.wstx.io.StreamBootstrapper;
/*     */ import com.ctc.wstx.sr.ReaderCreator;
/*     */ import com.ctc.wstx.sr.ValidatingStreamReader;
/*     */ import com.ctc.wstx.util.DefaultXmlSymbolTable;
/*     */ import com.ctc.wstx.util.SimpleCache;
/*     */ import com.ctc.wstx.util.SymbolTable;
/*     */ import com.ctc.wstx.util.URLUtil;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import javax.xml.stream.EventFilter;
/*     */ import javax.xml.stream.StreamFilter;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLReporter;
/*     */ import javax.xml.stream.XMLResolver;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.stream.util.XMLEventAllocator;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.codehaus.stax2.XMLEventReader2;
/*     */ import org.codehaus.stax2.XMLInputFactory2;
/*     */ import org.codehaus.stax2.XMLStreamReader2;
/*     */ import org.codehaus.stax2.io.Stax2Source;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WstxInputFactory
/*     */   extends XMLInputFactory2
/*     */   implements ReaderCreator, InputConfigFlags
/*     */ {
/*     */   static final int MAX_SYMBOL_TABLE_SIZE = 12000;
/*     */   static final int MAX_SYMBOL_TABLE_GENERATIONS = 500;
/*     */   protected final ReaderConfig mConfig;
/* 113 */   protected XMLEventAllocator mAllocator = null;
/*     */   
/*     */ 
/*     */ 
/* 117 */   protected SimpleCache mDTDCache = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 129 */   static final SymbolTable mRootSymbols = ;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/* 140 */     mRootSymbols.setInternStrings(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 147 */   SymbolTable mSymbols = mRootSymbols;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WstxInputFactory()
/*     */   {
/* 156 */     this.mConfig = ReaderConfig.createFullDefaults();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized DTDSubset findCachedDTD(DTDId id)
/*     */   {
/* 174 */     return this.mDTDCache == null ? null : (DTDSubset)this.mDTDCache.find(id);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void updateSymbolTable(SymbolTable t)
/*     */   {
/* 191 */     SymbolTable curr = this.mSymbols;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 196 */     if (t.isDirectChildOf(curr))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 204 */       if ((t.size() > 12000) || (t.version() > 500))
/*     */       {
/*     */ 
/* 207 */         this.mSymbols = mRootSymbols;
/*     */       }
/*     */       else {
/* 210 */         this.mSymbols.mergeChild(t);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized void addCachedDTD(DTDId id, DTDSubset extSubset)
/*     */   {
/* 219 */     if (this.mDTDCache == null) {
/* 220 */       this.mDTDCache = new SimpleCache(this.mConfig.getDtdCacheSize());
/*     */     }
/* 222 */     this.mDTDCache.add(id, extSubset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLEventReader createFilteredReader(XMLEventReader reader, EventFilter filter)
/*     */   {
/* 235 */     return new FilteredEventReader(reader, filter);
/*     */   }
/*     */   
/*     */   public XMLStreamReader createFilteredReader(XMLStreamReader reader, StreamFilter filter)
/*     */     throws XMLStreamException
/*     */   {
/* 241 */     FilteredStreamReader fr = new FilteredStreamReader(reader, filter);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 249 */     if (!filter.accept(fr))
/*     */     {
/* 251 */       fr.next();
/*     */     }
/* 253 */     return fr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLEventReader createXMLEventReader(InputStream in)
/*     */     throws XMLStreamException
/*     */   {
/* 262 */     return new WstxEventReader(createEventAllocator(), createSR(null, in, null, true, false));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public XMLEventReader createXMLEventReader(InputStream in, String enc)
/*     */     throws XMLStreamException
/*     */   {
/* 270 */     return new WstxEventReader(createEventAllocator(), createSR(null, in, enc, true, false));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public XMLEventReader createXMLEventReader(Reader r)
/*     */     throws XMLStreamException
/*     */   {
/* 278 */     return new WstxEventReader(createEventAllocator(), createSR(null, r, true, false));
/*     */   }
/*     */   
/*     */ 
/*     */   public XMLEventReader createXMLEventReader(Source source)
/*     */     throws XMLStreamException
/*     */   {
/* 285 */     return new WstxEventReader(createEventAllocator(), createSR(source, true));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public XMLEventReader createXMLEventReader(String systemId, InputStream in)
/*     */     throws XMLStreamException
/*     */   {
/* 293 */     return new WstxEventReader(createEventAllocator(), createSR(systemId, in, null, true, false));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public XMLEventReader createXMLEventReader(String systemId, Reader r)
/*     */     throws XMLStreamException
/*     */   {
/* 301 */     return new WstxEventReader(createEventAllocator(), createSR(systemId, r, true, false));
/*     */   }
/*     */   
/*     */ 
/*     */   public XMLEventReader createXMLEventReader(XMLStreamReader sr)
/*     */     throws XMLStreamException
/*     */   {
/* 308 */     return new WstxEventReader(createEventAllocator(), sr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLStreamReader createXMLStreamReader(InputStream in)
/*     */     throws XMLStreamException
/*     */   {
/* 317 */     return createSR(null, in, null, false, false);
/*     */   }
/*     */   
/*     */ 
/*     */   public XMLStreamReader createXMLStreamReader(InputStream in, String enc)
/*     */     throws XMLStreamException
/*     */   {
/* 324 */     return createSR(null, in, enc, false, false);
/*     */   }
/*     */   
/*     */ 
/*     */   public XMLStreamReader createXMLStreamReader(Reader r)
/*     */     throws XMLStreamException
/*     */   {
/* 331 */     return createSR(null, r, false, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLStreamReader createXMLStreamReader(Source src)
/*     */     throws XMLStreamException
/*     */   {
/* 341 */     return createSR(src, false);
/*     */   }
/*     */   
/*     */ 
/*     */   public XMLStreamReader createXMLStreamReader(String systemId, InputStream in)
/*     */     throws XMLStreamException
/*     */   {
/* 348 */     return createSR(systemId, in, null, false, false);
/*     */   }
/*     */   
/*     */ 
/*     */   public XMLStreamReader createXMLStreamReader(String systemId, Reader r)
/*     */     throws XMLStreamException
/*     */   {
/* 355 */     return createSR(systemId, r, false, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getProperty(String name)
/*     */   {
/* 366 */     Object ob = this.mConfig.getProperty(name);
/*     */     
/* 368 */     if ((ob == null) && 
/* 369 */       (name.equals("javax.xml.stream.allocator")))
/*     */     {
/* 371 */       return getEventAllocator();
/*     */     }
/*     */     
/* 374 */     return ob;
/*     */   }
/*     */   
/*     */   public void setProperty(String propName, Object value)
/*     */   {
/* 379 */     if ((!this.mConfig.setProperty(propName, value)) && 
/* 380 */       ("javax.xml.stream.allocator".equals(propName))) {
/* 381 */       setEventAllocator((XMLEventAllocator)value);
/*     */     }
/*     */   }
/*     */   
/*     */   public XMLEventAllocator getEventAllocator()
/*     */   {
/* 387 */     return this.mAllocator;
/*     */   }
/*     */   
/*     */   public XMLReporter getXMLReporter() {
/* 391 */     return this.mConfig.getXMLReporter();
/*     */   }
/*     */   
/*     */   public XMLResolver getXMLResolver() {
/* 395 */     return this.mConfig.getXMLResolver();
/*     */   }
/*     */   
/*     */   public boolean isPropertySupported(String name) {
/* 399 */     return this.mConfig.isPropertySupported(name);
/*     */   }
/*     */   
/*     */   public void setEventAllocator(XMLEventAllocator allocator) {
/* 403 */     this.mAllocator = allocator;
/*     */   }
/*     */   
/*     */   public void setXMLReporter(XMLReporter r) {
/* 407 */     this.mConfig.setXMLReporter(r);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXMLResolver(XMLResolver r)
/*     */   {
/* 417 */     this.mConfig.setXMLResolver(r);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLEventReader2 createXMLEventReader(URL src)
/*     */     throws XMLStreamException
/*     */   {
/* 434 */     return new WstxEventReader(createEventAllocator(), createSR(createPrivateConfig(), src, true, true));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLEventReader2 createXMLEventReader(File f)
/*     */     throws XMLStreamException
/*     */   {
/* 444 */     return new WstxEventReader(createEventAllocator(), createSR(f, true, true));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLStreamReader2 createXMLStreamReader(URL src)
/*     */     throws XMLStreamException
/*     */   {
/* 454 */     return createSR(createPrivateConfig(), src, false, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLStreamReader2 createXMLStreamReader(File f)
/*     */     throws XMLStreamException
/*     */   {
/* 467 */     return createSR(f, false, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void configureForXmlConformance()
/*     */   {
/* 474 */     this.mConfig.configureForXmlConformance();
/*     */   }
/*     */   
/*     */   public void configureForConvenience()
/*     */   {
/* 479 */     this.mConfig.configureForConvenience();
/*     */   }
/*     */   
/*     */   public void configureForSpeed()
/*     */   {
/* 484 */     this.mConfig.configureForSpeed();
/*     */   }
/*     */   
/*     */   public void configureForLowMemUsage()
/*     */   {
/* 489 */     this.mConfig.configureForLowMemUsage();
/*     */   }
/*     */   
/*     */   public void configureForRoundTripping()
/*     */   {
/* 494 */     this.mConfig.configureForRoundTripping();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReaderConfig getConfig()
/*     */   {
/* 504 */     return this.mConfig;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private XMLStreamReader2 doCreateSR(ReaderConfig cfg, String systemId, InputBootstrapper bs, URL src, boolean forER, boolean autoCloseInput)
/*     */     throws XMLStreamException
/*     */   {
/* 537 */     if (!autoCloseInput) {
/* 538 */       autoCloseInput = cfg.willAutoCloseInput();
/*     */     }
/*     */     Reader r;
/*     */     try
/*     */     {
/* 543 */       r = bs.bootstrapInput(cfg, true, 0);
/* 544 */       if (bs.declaredXml11()) {
/* 545 */         cfg.enableXml11(true);
/*     */       }
/*     */     } catch (IOException ie) {
/* 548 */       throw new WstxIOException(ie);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 554 */     BranchingReaderSource input = InputSourceFactory.constructDocumentSource(cfg, bs, null, systemId, src, r, autoCloseInput);
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 559 */       return ValidatingStreamReader.createValidatingStreamReader(input, this, cfg, bs, forER);
/*     */     }
/*     */     catch (IOException ie)
/*     */     {
/* 563 */       throw new WstxIOException(ie);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLStreamReader2 createSR(ReaderConfig cfg, String systemId, InputBootstrapper bs, boolean forER, boolean autoCloseInput)
/*     */     throws XMLStreamException
/*     */   {
/* 594 */     URL src = cfg.getBaseURL();
/*     */     
/*     */ 
/* 597 */     if ((src == null) && (systemId != null) && (systemId.length() > 0)) {
/*     */       try {
/* 599 */         src = URLUtil.urlFromSystemId(systemId);
/*     */       } catch (IOException ie) {
/* 601 */         throw new WstxIOException(ie);
/*     */       }
/*     */     }
/* 604 */     return doCreateSR(cfg, systemId, bs, src, forER, autoCloseInput);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XMLStreamReader2 createSR(String systemId, InputStream in, String enc, boolean forER, boolean autoCloseInput)
/*     */     throws XMLStreamException
/*     */   {
/* 613 */     if (in == null) {
/* 614 */       throw new IllegalArgumentException("Null InputStream is not a valid argument");
/*     */     }
/*     */     
/* 617 */     ReaderConfig cfg = createPrivateConfig();
/* 618 */     if ((enc == null) || (enc.length() == 0)) {
/* 619 */       return createSR(cfg, systemId, StreamBootstrapper.getInstance(in, null, systemId), forER, autoCloseInput);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 628 */     Reader r = DefaultInputResolver.constructOptimizedReader(cfg, in, false, enc);
/* 629 */     return createSR(cfg, systemId, ReaderBootstrapper.getInstance(r, null, systemId, enc), forER, autoCloseInput);
/*     */   }
/*     */   
/*     */   protected XMLStreamReader2 createSR(ReaderConfig cfg, URL src, boolean forER, boolean autoCloseInput)
/*     */     throws XMLStreamException
/*     */   {
/*     */     try
/*     */     {
/* 637 */       return createSR(cfg, src, URLUtil.optimizedStreamFromURL(src), forER, autoCloseInput);
/*     */     }
/*     */     catch (IOException ioe) {
/* 640 */       throw new WstxIOException(ioe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private XMLStreamReader2 createSR(ReaderConfig cfg, URL src, InputStream in, boolean forER, boolean autoCloseInput)
/*     */     throws XMLStreamException
/*     */   {
/* 649 */     String systemId = src.toExternalForm();
/* 650 */     return doCreateSR(cfg, systemId, StreamBootstrapper.getInstance(in, null, systemId), src, forER, autoCloseInput);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XMLStreamReader2 createSR(String systemId, Reader r, boolean forER, boolean autoCloseInput)
/*     */     throws XMLStreamException
/*     */   {
/* 660 */     return createSR(createPrivateConfig(), systemId, ReaderBootstrapper.getInstance(r, null, systemId, null), forER, autoCloseInput);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected XMLStreamReader2 createSR(File f, boolean forER, boolean autoCloseInput)
/*     */     throws XMLStreamException
/*     */   {
/*     */     try
/*     */     {
/* 670 */       return createSR(createPrivateConfig(), f.toURL(), new FileInputStream(f), forER, autoCloseInput);
/*     */     }
/*     */     catch (IOException ie) {
/* 673 */       throw new WstxIOException(ie);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XMLStreamReader2 createSR(Source src, boolean forER)
/*     */     throws XMLStreamException
/*     */   {
/* 687 */     ReaderConfig cfg = createPrivateConfig();
/* 688 */     Reader r = null;
/* 689 */     InputStream in = null;
/* 690 */     String pubId = null;
/* 691 */     String sysId = null;
/* 692 */     String encoding = null;
/*     */     
/*     */     boolean autoCloseInput;
/* 695 */     if ((src instanceof Stax2Source))
/*     */     {
/*     */ 
/*     */ 
/* 699 */       Stax2Source ss = (Stax2Source)src;
/* 700 */       sysId = ss.getSystemId();
/* 701 */       pubId = ss.getPublicId();
/* 702 */       encoding = ss.getEncoding();
/*     */       try {
/* 704 */         in = ss.constructInputStream();
/* 705 */         if (in == null) {
/* 706 */           r = ss.constructReader();
/*     */         }
/*     */       } catch (IOException ioe) {
/* 709 */         throw new WstxIOException(ioe);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 714 */       autoCloseInput = true; } else { boolean autoCloseInput;
/* 715 */       if ((src instanceof StreamSource)) {
/* 716 */         StreamSource ss = (StreamSource)src;
/* 717 */         sysId = ss.getSystemId();
/* 718 */         pubId = ss.getPublicId();
/* 719 */         in = ss.getInputStream();
/* 720 */         if (in == null) {
/* 721 */           r = ss.getReader();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 726 */         autoCloseInput = cfg.willAutoCloseInput(); } else { boolean autoCloseInput;
/* 727 */         if ((src instanceof SAXSource)) {
/* 728 */           SAXSource ss = (SAXSource)src;
/*     */           
/*     */ 
/*     */ 
/* 732 */           InputSource isrc = ss.getInputSource();
/* 733 */           if (isrc != null) {
/* 734 */             sysId = isrc.getSystemId();
/* 735 */             pubId = isrc.getPublicId();
/* 736 */             encoding = isrc.getEncoding();
/* 737 */             in = isrc.getByteStream();
/* 738 */             if (in == null) {
/* 739 */               r = isrc.getCharacterStream();
/*     */             }
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 745 */           autoCloseInput = cfg.willAutoCloseInput();
/* 746 */         } else { if ((src instanceof DOMSource)) {
/* 747 */             DOMSource domSrc = (DOMSource)src;
/*     */             
/* 749 */             return DOMWrappingReader.createFrom(cfg, domSrc);
/*     */           }
/* 751 */           throw new IllegalArgumentException("Can not instantiate StAX reader for XML source type " + src.getClass() + " (unrecognized type)");
/*     */         }
/*     */       } }
/*     */     boolean autoCloseInput;
/*     */     InputBootstrapper bs;
/* 756 */     if (r != null) {
/* 757 */       bs = ReaderBootstrapper.getInstance(r, pubId, sysId, encoding); } else { InputBootstrapper bs;
/* 758 */       if (in != null) {
/* 759 */         bs = StreamBootstrapper.getInstance(in, pubId, sysId);
/* 760 */       } else { if (sysId != null) {
/*     */           try {
/* 762 */             return createSR(cfg, URLUtil.urlFromSystemId(sysId), forER, autoCloseInput);
/*     */           }
/*     */           catch (IOException ioe) {
/* 765 */             throw new WstxIOException(ioe);
/*     */           }
/*     */         }
/* 768 */         throw new XMLStreamException("Can not create StAX reader for the Source passed -- neither reader, input stream nor system id was accessible; can not use other types of sources (like embedded SAX streams)"); } }
/*     */     InputBootstrapper bs;
/* 770 */     return createSR(cfg, sysId, bs, forER, autoCloseInput);
/*     */   }
/*     */   
/*     */ 
/*     */   protected XMLEventAllocator createEventAllocator()
/*     */   {
/* 776 */     if (this.mAllocator != null) {
/* 777 */       return this.mAllocator.newInstance();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 784 */     return this.mConfig.willPreserveLocation() ? DefaultEventAllocator.getDefaultInstance() : DefaultEventAllocator.getFastInstance();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReaderConfig createPrivateConfig()
/*     */   {
/* 799 */     return this.mConfig.createNonShared(this.mSymbols.makeChild());
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\stax\WstxInputFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */