/*    */ package com.ctc.wstx.evt;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ import javax.xml.stream.Location;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import javax.xml.stream.XMLStreamWriter;
/*    */ import javax.xml.stream.events.NotationDeclaration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class WNotationDeclaration
/*    */   extends WEvent
/*    */   implements NotationDeclaration
/*    */ {
/*    */   public WNotationDeclaration(Location loc)
/*    */   {
/* 24 */     super(loc);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public abstract String getName();
/*    */   
/*    */ 
/*    */   public abstract String getPublicId();
/*    */   
/*    */ 
/*    */   public abstract String getSystemId();
/*    */   
/*    */ 
/*    */   public int getEventType()
/*    */   {
/* 40 */     return 14;
/*    */   }
/*    */   
/*    */   public abstract void writeEnc(Writer paramWriter)
/*    */     throws IOException;
/*    */   
/*    */   public void writeAsEncodedUnicode(Writer w) throws XMLStreamException
/*    */   {
/*    */     try
/*    */     {
/* 50 */       writeEnc(w);
/*    */     } catch (IOException ie) {
/* 52 */       throwFromIOE(ie);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void writeUsing(XMLStreamWriter w)
/*    */     throws XMLStreamException
/*    */   {
/* 68 */     throw new XMLStreamException("Can not write notation declarations using an XMLStreamWriter");
/*    */   }
/*    */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\evt\WNotationDeclaration.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */