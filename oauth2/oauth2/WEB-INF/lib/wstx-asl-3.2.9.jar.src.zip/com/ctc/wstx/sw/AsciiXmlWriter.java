/*     */ package com.ctc.wstx.sw;
/*     */ 
/*     */ import com.ctc.wstx.api.WriterConfig;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AsciiXmlWriter
/*     */   extends EncodingXmlWriter
/*     */ {
/*     */   public AsciiXmlWriter(OutputStream out, WriterConfig cfg, boolean autoclose)
/*     */     throws IOException
/*     */   {
/*  35 */     super(out, cfg, "US-ASCII", autoclose);
/*     */   }
/*     */   
/*     */   public void writeRaw(char[] cbuf, int offset, int len)
/*     */     throws IOException
/*     */   {
/*  41 */     if (this.mSurrogate != 0) {
/*  42 */       throwUnpairedSurrogate();
/*     */     }
/*     */     
/*  45 */     int ptr = this.mOutputPtr;
/*  46 */     while (len > 0) {
/*  47 */       int max = this.mOutputBuffer.length - ptr;
/*  48 */       if (max < 1) {
/*  49 */         this.mOutputPtr = ptr;
/*  50 */         flushBuffer();
/*  51 */         ptr = 0;
/*  52 */         max = this.mOutputBuffer.length;
/*     */       }
/*     */       
/*  55 */       if (max > len) {
/*  56 */         max = len;
/*     */       }
/*  58 */       if (this.mCheckContent) {
/*  59 */         for (int inEnd = offset + max; offset < inEnd; offset++) {
/*  60 */           int c = cbuf[offset];
/*  61 */           if (c < 32) {
/*  62 */             if (c != 10)
/*     */             {
/*  64 */               if (c != 13)
/*     */               {
/*  66 */                 if (c != 9)
/*  67 */                   throwInvalidChar(c); }
/*     */             }
/*  69 */           } else if (c > 126) {
/*  70 */             this.mOutputPtr = ptr;
/*  71 */             if (c > 127) {
/*  72 */               throwInvalidAsciiChar(c);
/*  73 */             } else if (this.mXml11) {
/*  74 */               throwInvalidChar(c);
/*     */             }
/*     */           }
/*  77 */           this.mOutputBuffer[(ptr++)] = ((byte)c);
/*     */         }
/*     */       } else {
/*  80 */         for (int inEnd = offset + max; offset < inEnd; offset++) {
/*  81 */           this.mOutputBuffer[(ptr++)] = ((byte)cbuf[offset]);
/*     */         }
/*     */       }
/*  84 */       len -= max;
/*     */     }
/*  86 */     this.mOutputPtr = ptr;
/*     */   }
/*     */   
/*     */   public void writeRaw(String str, int offset, int len)
/*     */     throws IOException
/*     */   {
/*  92 */     if (this.mSurrogate != 0) {
/*  93 */       throwUnpairedSurrogate();
/*     */     }
/*  95 */     int ptr = this.mOutputPtr;
/*  96 */     while (len > 0) {
/*  97 */       int max = this.mOutputBuffer.length - ptr;
/*  98 */       if (max < 1) {
/*  99 */         this.mOutputPtr = ptr;
/* 100 */         flushBuffer();
/* 101 */         ptr = 0;
/* 102 */         max = this.mOutputBuffer.length;
/*     */       }
/*     */       
/* 105 */       if (max > len) {
/* 106 */         max = len;
/*     */       }
/* 108 */       if (this.mCheckContent) {
/* 109 */         for (int inEnd = offset + max; offset < inEnd; offset++) {
/* 110 */           int c = str.charAt(offset);
/* 111 */           if (c < 32) {
/* 112 */             if (c != 10)
/*     */             {
/* 114 */               if (c != 13)
/*     */               {
/* 116 */                 if (c != 9)
/* 117 */                   throwInvalidChar(c); }
/*     */             }
/* 119 */           } else if (c > 126) {
/* 120 */             this.mOutputPtr = ptr;
/* 121 */             if (c > 127) {
/* 122 */               throwInvalidAsciiChar(c);
/* 123 */             } else if (this.mXml11) {
/* 124 */               throwInvalidChar(c);
/*     */             }
/*     */           }
/* 127 */           this.mOutputBuffer[(ptr++)] = ((byte)c);
/*     */         }
/*     */       } else {
/* 130 */         for (int inEnd = offset + max; offset < inEnd; offset++) {
/* 131 */           this.mOutputBuffer[(ptr++)] = ((byte)str.charAt(offset));
/*     */         }
/*     */       }
/* 134 */       len -= max;
/*     */     }
/* 136 */     this.mOutputPtr = ptr;
/*     */   }
/*     */   
/*     */   protected void writeAttrValue(String data)
/*     */     throws IOException
/*     */   {
/* 142 */     int offset = 0;
/* 143 */     int len = data.length();
/* 144 */     int ptr = this.mOutputPtr;
/*     */     
/*     */ 
/* 147 */     while (len > 0) {
/* 148 */       int max = this.mOutputBuffer.length - ptr;
/* 149 */       if (max < 1) {
/* 150 */         this.mOutputPtr = ptr;
/* 151 */         flushBuffer();
/* 152 */         ptr = 0;
/* 153 */         max = this.mOutputBuffer.length;
/*     */       }
/*     */       
/* 156 */       if (this.mSurrogate != 0) {
/* 157 */         int sec = data.charAt(offset++);
/* 158 */         sec = calcSurrogate(sec);
/* 159 */         this.mOutputPtr = ptr;
/* 160 */         ptr = writeAsEntity(sec);
/* 161 */         len--;
/*     */       }
/*     */       else
/*     */       {
/* 165 */         if (max > len) {
/* 166 */           max = len;
/*     */         }
/*     */         
/* 169 */         int inEnd = offset + max; for (;;) { if (offset < inEnd) {
/* 170 */             int c = data.charAt(offset++);
/* 171 */             if (c < 32)
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/* 176 */               if ((this.mCheckContent) && 
/* 177 */                 (c != 10) && (c != 13) && (c != 9) && ((!this.mXml11) || (c == 0)))
/*     */               {
/* 179 */                 throwInvalidChar(c);
/*     */               }
/*     */               
/*     */             }
/* 183 */             else if (c < 127) {
/* 184 */               if ((c != 60) && (c != 38) && (c != 34)) {
/* 185 */                 this.mOutputBuffer[(ptr++)] = ((byte)c);
/*     */ 
/*     */               }
/*     */               
/*     */ 
/*     */             }
/* 191 */             else if ((c >= 55296) && (c <= 57343)) {
/* 192 */               this.mSurrogate = c;
/*     */               
/* 194 */               if (offset == inEnd) {
/*     */                 break label296;
/*     */               }
/* 197 */               c = calcSurrogate(data.charAt(offset++));
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 204 */             this.mOutputPtr = ptr;
/* 205 */             ptr = writeAsEntity(c);
/* 206 */             len = data.length() - offset;
/* 207 */             break; } }
/*     */         label296:
/* 209 */         len -= max;
/*     */       } }
/* 211 */     this.mOutputPtr = ptr;
/*     */   }
/*     */   
/*     */   protected void writeAttrValue(char[] data, int offset, int len)
/*     */     throws IOException
/*     */   {
/* 217 */     int ptr = this.mOutputPtr;
/*     */     
/*     */ 
/* 220 */     while (len > 0) {
/* 221 */       int max = this.mOutputBuffer.length - ptr;
/* 222 */       if (max < 1) {
/* 223 */         this.mOutputPtr = ptr;
/* 224 */         flushBuffer();
/* 225 */         ptr = 0;
/* 226 */         max = this.mOutputBuffer.length;
/*     */       }
/*     */       
/* 229 */       if (this.mSurrogate != 0) {
/* 230 */         int sec = data[(offset++)];
/* 231 */         sec = calcSurrogate(sec);
/* 232 */         this.mOutputPtr = ptr;
/* 233 */         ptr = writeAsEntity(sec);
/* 234 */         len--;
/*     */       }
/*     */       else
/*     */       {
/* 238 */         if (max > len) {
/* 239 */           max = len;
/*     */         }
/*     */         
/* 242 */         for (int inEnd = offset + max; offset < inEnd;) {
/* 243 */           int c = data[(offset++)];
/* 244 */           if (c < 32)
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/* 249 */             if ((this.mCheckContent) && 
/* 250 */               (c != 10) && (c != 13) && (c != 9) && ((!this.mXml11) || (c == 0)))
/*     */             {
/* 252 */               throwInvalidChar(c);
/*     */             }
/*     */             
/*     */           }
/* 256 */           else if (c < 127) {
/* 257 */             if ((c != 60) && (c != 38) && (c != 34)) {
/* 258 */               this.mOutputBuffer[(ptr++)] = ((byte)c);
/*     */ 
/*     */             }
/*     */             
/*     */ 
/*     */           }
/* 264 */           else if ((c >= 55296) && (c <= 57343)) {
/* 265 */             this.mSurrogate = c;
/*     */             
/* 267 */             if (offset == inEnd) {
/*     */               break;
/*     */             }
/* 270 */             c = calcSurrogate(data[(offset++)]);
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 277 */           this.mOutputPtr = ptr;
/* 278 */           ptr = writeAsEntity(c);
/* 279 */           max -= inEnd - offset;
/*     */         }
/*     */         
/* 282 */         len -= max;
/*     */       } }
/* 284 */     this.mOutputPtr = ptr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected int writeCDataContent(String data)
/*     */     throws IOException
/*     */   {
/* 292 */     int offset = 0;
/* 293 */     int len = data.length();
/* 294 */     if (!this.mCheckContent) {
/* 295 */       writeRaw(data, offset, len);
/* 296 */       return -1;
/*     */     }
/* 298 */     int ptr = this.mOutputPtr;
/*     */     
/*     */ 
/* 301 */     while (len > 0) {
/* 302 */       int max = this.mOutputBuffer.length - ptr;
/* 303 */       if (max < 1) {
/* 304 */         this.mOutputPtr = ptr;
/* 305 */         flushBuffer();
/* 306 */         ptr = 0;
/* 307 */         max = this.mOutputBuffer.length;
/*     */       }
/*     */       
/* 310 */       if (max > len) {
/* 311 */         max = len;
/*     */       }
/* 313 */       int inEnd = offset + max; for (;;) { if (offset >= inEnd) break label287;
/* 314 */         int c = data.charAt(offset++);
/* 315 */         if (c < 32) {
/* 316 */           if (c != 10)
/*     */           {
/* 318 */             if (c != 13)
/*     */             {
/* 320 */               if (c != 9)
/* 321 */                 throwInvalidChar(c); }
/*     */           }
/* 323 */         } else if (c > 126) {
/* 324 */           this.mOutputPtr = ptr;
/* 325 */           if (c > 127) {
/* 326 */             throwInvalidAsciiChar(c);
/* 327 */           } else if (this.mXml11) {
/* 328 */             throwInvalidChar(c);
/*     */           }
/* 330 */         } else if ((c == 62) && 
/* 331 */           (offset > 2) && (data.charAt(offset - 2) == ']') && (data.charAt(offset - 3) == ']'))
/*     */         {
/* 333 */           if (!this.mFixContent) {
/* 334 */             return offset - 3;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 339 */           this.mOutputPtr = ptr;
/* 340 */           writeCDataEnd();
/* 341 */           writeCDataStart();
/* 342 */           writeAscii((byte)62);
/* 343 */           ptr = this.mOutputPtr;
/*     */           
/*     */ 
/*     */ 
/* 347 */           len = data.length() - offset;
/* 348 */           break;
/*     */         }
/*     */         
/* 351 */         this.mOutputBuffer[(ptr++)] = ((byte)c); }
/*     */       label287:
/* 353 */       len -= max;
/*     */     }
/* 355 */     this.mOutputPtr = ptr;
/* 356 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected int writeCDataContent(char[] cbuf, int start, int len)
/*     */     throws IOException
/*     */   {
/* 364 */     if (!this.mCheckContent) {
/* 365 */       writeRaw(cbuf, start, len);
/* 366 */       return -1;
/*     */     }
/*     */     
/* 369 */     int ptr = this.mOutputPtr;
/* 370 */     int offset = start;
/*     */     
/*     */ 
/* 373 */     while (len > 0) {
/* 374 */       int max = this.mOutputBuffer.length - ptr;
/* 375 */       if (max < 1) {
/* 376 */         this.mOutputPtr = ptr;
/* 377 */         flushBuffer();
/* 378 */         ptr = 0;
/* 379 */         max = this.mOutputBuffer.length;
/*     */       }
/*     */       
/* 382 */       if (max > len) {
/* 383 */         max = len;
/*     */       }
/*     */       
/* 386 */       for (int inEnd = offset + max; offset < inEnd;) {
/* 387 */         int c = cbuf[(offset++)];
/* 388 */         if (c < 32) {
/* 389 */           if (c != 10)
/*     */           {
/* 391 */             if (c != 13)
/*     */             {
/* 393 */               if (c != 9)
/* 394 */                 throwInvalidChar(c); }
/*     */           }
/* 396 */         } else if (c > 126) {
/* 397 */           this.mOutputPtr = ptr;
/* 398 */           if (c > 127) {
/* 399 */             throwInvalidAsciiChar(c);
/* 400 */           } else if (this.mXml11) {
/* 401 */             throwInvalidChar(c);
/*     */           }
/* 403 */         } else if ((c == 62) && 
/* 404 */           (offset >= start + 3) && (cbuf[(offset - 2)] == ']') && (cbuf[(offset - 3)] == ']'))
/*     */         {
/* 406 */           if (!this.mFixContent) {
/* 407 */             return offset - 3;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 412 */           this.mOutputPtr = ptr;
/* 413 */           writeCDataEnd();
/* 414 */           writeCDataStart();
/* 415 */           writeAscii((byte)62);
/* 416 */           ptr = this.mOutputPtr;
/*     */           
/*     */ 
/*     */ 
/* 420 */           max -= inEnd - offset;
/* 421 */           break;
/*     */         }
/*     */         
/* 424 */         this.mOutputBuffer[(ptr++)] = ((byte)c);
/*     */       }
/* 426 */       len -= max;
/*     */     }
/* 428 */     this.mOutputPtr = ptr;
/* 429 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected int writeCommentContent(String data)
/*     */     throws IOException
/*     */   {
/* 437 */     int offset = 0;
/* 438 */     int len = data.length();
/* 439 */     if (!this.mCheckContent) {
/* 440 */       writeRaw(data, offset, len);
/* 441 */       return -1;
/*     */     }
/*     */     
/* 444 */     int ptr = this.mOutputPtr;
/*     */     
/*     */ 
/* 447 */     while (len > 0) {
/* 448 */       int max = this.mOutputBuffer.length - ptr;
/* 449 */       if (max < 1) {
/* 450 */         this.mOutputPtr = ptr;
/* 451 */         flushBuffer();
/* 452 */         ptr = 0;
/* 453 */         max = this.mOutputBuffer.length;
/*     */       }
/*     */       
/* 456 */       if (max > len) {
/* 457 */         max = len;
/*     */       }
/*     */       
/* 460 */       for (int inEnd = offset + max; offset < inEnd;) {
/* 461 */         int c = data.charAt(offset++);
/* 462 */         if (c < 32) {
/* 463 */           if (c != 10)
/*     */           {
/* 465 */             if (c != 13)
/*     */             {
/* 467 */               if (c != 9)
/* 468 */                 throwInvalidChar(c); }
/*     */           }
/* 470 */         } else if (c > 126) {
/* 471 */           this.mOutputPtr = ptr;
/* 472 */           if (c > 127) {
/* 473 */             throwInvalidAsciiChar(c);
/* 474 */           } else if (this.mXml11) {
/* 475 */             throwInvalidChar(c);
/*     */           }
/* 477 */         } else if ((c == 45) && 
/* 478 */           (offset > 1) && (data.charAt(offset - 2) == '-')) {
/* 479 */           if (!this.mFixContent) {
/* 480 */             return offset - 2;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 487 */           this.mOutputBuffer[(ptr++)] = 32;
/* 488 */           if (ptr >= this.mOutputBuffer.length) {
/* 489 */             this.mOutputPtr = ptr;
/* 490 */             flushBuffer();
/* 491 */             ptr = 0;
/*     */           }
/* 493 */           this.mOutputBuffer[(ptr++)] = 45;
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 498 */           max -= inEnd - offset;
/* 499 */           break;
/*     */         }
/*     */         
/* 502 */         this.mOutputBuffer[(ptr++)] = ((byte)c);
/*     */       }
/* 504 */       len -= max;
/*     */     }
/* 506 */     this.mOutputPtr = ptr;
/* 507 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected int writePIData(String data)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 515 */     int offset = 0;
/* 516 */     int len = data.length();
/* 517 */     if (!this.mCheckContent) {
/* 518 */       writeRaw(data, offset, len);
/* 519 */       return -1;
/*     */     }
/*     */     
/* 522 */     int ptr = this.mOutputPtr;
/* 523 */     while (len > 0) {
/* 524 */       int max = this.mOutputBuffer.length - ptr;
/* 525 */       if (max < 1) {
/* 526 */         this.mOutputPtr = ptr;
/* 527 */         flushBuffer();
/* 528 */         ptr = 0;
/* 529 */         max = this.mOutputBuffer.length;
/*     */       }
/*     */       
/* 532 */       if (max > len) {
/* 533 */         max = len;
/*     */       }
/* 535 */       for (int inEnd = offset + max; offset < inEnd; offset++) {
/* 536 */         int c = data.charAt(offset);
/* 537 */         if (c < 32) {
/* 538 */           if (c != 10)
/*     */           {
/* 540 */             if (c != 13)
/*     */             {
/* 542 */               if (c != 9)
/* 543 */                 throwInvalidChar(c); }
/*     */           }
/* 545 */         } else if (c > 126) {
/* 546 */           this.mOutputPtr = ptr;
/* 547 */           if (c > 127) {
/* 548 */             throwInvalidAsciiChar(c);
/* 549 */           } else if (this.mXml11) {
/* 550 */             throwInvalidChar(c);
/*     */           }
/* 552 */         } else if ((c == 62) && 
/* 553 */           (offset > 0) && (data.charAt(offset - 1) == '?')) {
/* 554 */           return offset - 2;
/*     */         }
/*     */         
/* 557 */         this.mOutputBuffer[(ptr++)] = ((byte)c);
/*     */       }
/* 559 */       len -= max;
/*     */     }
/* 561 */     this.mOutputPtr = ptr;
/* 562 */     return -1;
/*     */   }
/*     */   
/*     */   protected void writeTextContent(String data)
/*     */     throws IOException
/*     */   {
/* 568 */     int offset = 0;
/* 569 */     int len = data.length();
/* 570 */     int ptr = this.mOutputPtr;
/*     */     
/*     */ 
/* 573 */     while (len > 0) {
/* 574 */       int max = this.mOutputBuffer.length - this.mOutputPtr;
/* 575 */       if (max < 1) {
/* 576 */         flushBuffer();
/* 577 */         max = this.mOutputBuffer.length;
/*     */       }
/*     */       
/* 580 */       if (this.mSurrogate != 0) {
/* 581 */         int sec = data.charAt(offset++);
/* 582 */         sec = calcSurrogate(sec);
/* 583 */         writeAsEntity(sec);
/* 584 */         len--;
/*     */       }
/*     */       else
/*     */       {
/* 588 */         if (max > len) {
/* 589 */           max = len;
/*     */         }
/*     */         
/* 592 */         int inEnd = offset + max; for (;;) { if (offset < inEnd) {
/* 593 */             int c = data.charAt(offset++);
/* 594 */             if (c < 32) {
/* 595 */               if ((c == 10) || (c == 9)) {
/* 596 */                 this.mOutputBuffer[(this.mOutputPtr++)] = ((byte)c);
/* 597 */                 continue; }
/* 598 */               if (c == 13) {
/* 599 */                 if (!this.mEscapeCR) {
/* 600 */                   this.mOutputBuffer[(this.mOutputPtr++)] = ((byte)c);
/*     */                 }
/*     */               }
/* 603 */               else if (((!this.mXml11) || (c == 0)) && 
/* 604 */                 (this.mCheckContent)) {
/* 605 */                 throwInvalidChar(c);
/*     */               }
/*     */               
/*     */ 
/*     */             }
/* 610 */             else if (c < 127) {
/* 611 */               if ((c != 60) && (c != 38) && (
/* 612 */                 (c != 62) || ((offset > 1) && (data.charAt(offset - 2) != ']')))) {
/* 613 */                 this.mOutputBuffer[(this.mOutputPtr++)] = ((byte)c);
/*     */ 
/*     */               }
/*     */               
/*     */ 
/*     */ 
/*     */             }
/* 620 */             else if ((c >= 55296) && (c <= 57343)) {
/* 621 */               this.mSurrogate = c;
/*     */               
/* 623 */               if (offset == inEnd) {
/*     */                 break label349;
/*     */               }
/* 626 */               c = calcSurrogate(data.charAt(offset++));
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 633 */             writeAsEntity(c);
/* 634 */             len = data.length() - offset;
/* 635 */             break; } }
/*     */         label349:
/* 637 */         len -= max;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void writeTextContent(char[] cbuf, int offset, int len)
/*     */     throws IOException
/*     */   {
/* 645 */     while (len > 0) {
/* 646 */       int max = this.mOutputBuffer.length - this.mOutputPtr;
/* 647 */       if (max < 1) {
/* 648 */         flushBuffer();
/* 649 */         max = this.mOutputBuffer.length;
/*     */       }
/*     */       
/* 652 */       if (this.mSurrogate != 0) {
/* 653 */         int sec = cbuf[(offset++)];
/* 654 */         sec = calcSurrogate(sec);
/* 655 */         writeAsEntity(sec);
/* 656 */         len--;
/*     */       }
/*     */       else
/*     */       {
/* 660 */         if (max > len) {
/* 661 */           max = len;
/*     */         }
/*     */         
/* 664 */         for (int inEnd = offset + max; offset < inEnd;) {
/* 665 */           int c = cbuf[(offset++)];
/* 666 */           if (c < 32) {
/* 667 */             if ((c == 10) || (c == 9)) {
/* 668 */               this.mOutputBuffer[(this.mOutputPtr++)] = ((byte)c);
/* 669 */               continue; }
/* 670 */             if (c == 13) {
/* 671 */               if (!this.mEscapeCR) {
/* 672 */                 this.mOutputBuffer[(this.mOutputPtr++)] = ((byte)c);
/*     */               }
/*     */             }
/* 675 */             else if (((!this.mXml11) || (c == 0)) && 
/* 676 */               (this.mCheckContent)) {
/* 677 */               throwInvalidChar(c);
/*     */             }
/*     */             
/*     */ 
/*     */           }
/* 682 */           else if (c < 127) {
/* 683 */             if ((c != 60) && (c != 38))
/*     */             {
/*     */ 
/*     */ 
/* 687 */               if ((c != 62) || ((offset > 1) && (cbuf[(offset - 2)] != ']'))) {
/* 688 */                 this.mOutputBuffer[(this.mOutputPtr++)] = ((byte)c);
/*     */               }
/*     */               
/*     */             }
/*     */             
/*     */ 
/*     */           }
/* 695 */           else if ((c >= 55296) && (c <= 57343)) {
/* 696 */             this.mSurrogate = c;
/*     */             
/* 698 */             if (offset == inEnd) {
/*     */               break;
/*     */             }
/* 701 */             c = calcSurrogate(cbuf[(offset++)]);
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 708 */           writeAsEntity(c);
/* 709 */           max -= inEnd - offset;
/*     */         }
/*     */         
/* 712 */         len -= max;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void throwInvalidAsciiChar(int c)
/*     */     throws IOException
/*     */   {
/* 726 */     flush();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 734 */     throw new IOException("Invalid XML character (0x" + Integer.toHexString(c) + "); can only be output using character entity when using US-ASCII encoding");
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sw\AsciiXmlWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */