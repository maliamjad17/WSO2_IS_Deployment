/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ import com.ctc.wstx.cfg.ErrorConsts;
/*     */ import com.ctc.wstx.compat.JdkFeatures;
/*     */ import com.ctc.wstx.compat.JdkImpl;
/*     */ import com.ctc.wstx.ent.NotationDecl;
/*     */ import com.ctc.wstx.exc.WstxParsingException;
/*     */ import com.ctc.wstx.sr.InputProblemReporter;
/*     */ import com.ctc.wstx.util.DataUtil;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.codehaus.stax2.validation.ValidationContext;
/*     */ import org.codehaus.stax2.validation.XMLValidator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DTDSubsetImpl
/*     */   extends DTDSubset
/*     */ {
/*     */   final boolean mIsCachable;
/*     */   final boolean mFullyValidating;
/*     */   final boolean mHasNsDefaults;
/*     */   final HashMap mGeneralEntities;
/*  78 */   volatile transient List mGeneralEntityList = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final Set mRefdGEs;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final HashMap mDefinedPEs;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final Set mRefdPEs;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final HashMap mNotations;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 136 */   transient List mNotationList = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final HashMap mElements;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private DTDSubsetImpl(boolean cachable, HashMap genEnt, Set refdGEs, HashMap paramEnt, Set peRefs, HashMap notations, HashMap elements, boolean fullyValidating)
/*     */   {
/* 159 */     this.mIsCachable = cachable;
/* 160 */     this.mGeneralEntities = genEnt;
/* 161 */     this.mRefdGEs = refdGEs;
/* 162 */     this.mDefinedPEs = paramEnt;
/* 163 */     this.mRefdPEs = peRefs;
/* 164 */     this.mNotations = notations;
/* 165 */     this.mElements = elements;
/* 166 */     this.mFullyValidating = fullyValidating;
/*     */     
/* 168 */     boolean anyNsDefs = false;
/* 169 */     if (elements != null) {
/* 170 */       Iterator it = elements.values().iterator();
/* 171 */       while (it.hasNext()) {
/* 172 */         DTDElement elem = (DTDElement)it.next();
/* 173 */         if (elem.hasNsDefaults()) {
/* 174 */           anyNsDefs = true;
/* 175 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 179 */     this.mHasNsDefaults = anyNsDefs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static DTDSubsetImpl constructInstance(boolean cachable, HashMap genEnt, Set refdGEs, HashMap paramEnt, Set refdPEs, HashMap notations, HashMap elements, boolean fullyValidating)
/*     */   {
/* 188 */     return new DTDSubsetImpl(cachable, genEnt, refdGEs, paramEnt, refdPEs, notations, elements, fullyValidating);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DTDSubset combineWithExternalSubset(InputProblemReporter rep, DTDSubset extSubset)
/*     */     throws XMLStreamException
/*     */   {
/* 204 */     HashMap ge1 = getGeneralEntityMap();
/* 205 */     HashMap ge2 = extSubset.getGeneralEntityMap();
/* 206 */     if ((ge1 == null) || (ge1.isEmpty())) {
/* 207 */       ge1 = ge2;
/*     */     }
/* 209 */     else if ((ge2 != null) && (!ge2.isEmpty()))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 214 */       combineMaps(ge1, ge2);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 219 */     HashMap n1 = getNotationMap();
/* 220 */     HashMap n2 = extSubset.getNotationMap();
/* 221 */     if ((n1 == null) || (n1.isEmpty())) {
/* 222 */       n1 = n2;
/*     */     }
/* 224 */     else if ((n2 != null) && (!n2.isEmpty()))
/*     */     {
/*     */ 
/*     */ 
/* 228 */       checkNotations(n1, n2);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 234 */       combineMaps(n1, n2);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 240 */     HashMap e1 = getElementMap();
/* 241 */     HashMap e2 = extSubset.getElementMap();
/* 242 */     if ((e1 == null) || (e1.isEmpty())) {
/* 243 */       e1 = e2;
/*     */     }
/* 245 */     else if ((e2 != null) && (!e2.isEmpty()))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 250 */       combineElements(rep, e1, e2);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 257 */     return constructInstance(false, ge1, null, null, null, n1, e1, this.mFullyValidating);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLValidator createValidator(ValidationContext ctxt)
/*     */     throws XMLStreamException
/*     */   {
/* 270 */     if (this.mFullyValidating) {
/* 271 */       return new DTDValidator(this, ctxt, this.mHasNsDefaults, getElementMap(), getGeneralEntityMap());
/*     */     }
/*     */     
/* 274 */     return new DTDTypingNonValidator(this, ctxt, this.mHasNsDefaults, getElementMap(), getGeneralEntityMap());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getEntityCount()
/*     */   {
/* 286 */     return this.mGeneralEntities == null ? 0 : this.mGeneralEntities.size();
/*     */   }
/*     */   
/*     */   public int getNotationCount() {
/* 290 */     return this.mNotations == null ? 0 : this.mNotations.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCachable()
/*     */   {
/* 300 */     return this.mIsCachable;
/*     */   }
/*     */   
/*     */   public HashMap getGeneralEntityMap() {
/* 304 */     return this.mGeneralEntities;
/*     */   }
/*     */   
/*     */   public List getGeneralEntityList()
/*     */   {
/* 309 */     List l = this.mGeneralEntityList;
/* 310 */     if (l == null) {
/* 311 */       if ((this.mGeneralEntities == null) || (this.mGeneralEntities.size() == 0)) {
/* 312 */         l = JdkFeatures.getInstance().getEmptyList();
/*     */       } else {
/* 314 */         l = Collections.unmodifiableList(new ArrayList(this.mGeneralEntities.values()));
/*     */       }
/* 316 */       this.mGeneralEntityList = l;
/*     */     }
/*     */     
/* 319 */     return l;
/*     */   }
/*     */   
/*     */   public HashMap getParameterEntityMap() {
/* 323 */     return this.mDefinedPEs;
/*     */   }
/*     */   
/*     */   public HashMap getNotationMap() {
/* 327 */     return this.mNotations;
/*     */   }
/*     */   
/*     */   public synchronized List getNotationList()
/*     */   {
/* 332 */     List l = this.mNotationList;
/* 333 */     if (l == null) {
/* 334 */       if ((this.mNotations == null) || (this.mNotations.size() == 0)) {
/* 335 */         l = JdkFeatures.getInstance().getEmptyList();
/*     */       } else {
/* 337 */         l = Collections.unmodifiableList(new ArrayList(this.mNotations.values()));
/*     */       }
/* 339 */       this.mNotationList = l;
/*     */     }
/*     */     
/* 342 */     return l;
/*     */   }
/*     */   
/*     */   public HashMap getElementMap() {
/* 346 */     return this.mElements;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isReusableWith(DTDSubset intSubset)
/*     */   {
/* 360 */     Set refdPEs = this.mRefdPEs;
/*     */     
/* 362 */     if ((refdPEs != null) && (refdPEs.size() > 0)) {
/* 363 */       HashMap intPEs = intSubset.getParameterEntityMap();
/* 364 */       if ((intPEs != null) && (intPEs.size() > 0) && 
/* 365 */         (DataUtil.anyValuesInCommon(refdPEs, intPEs.keySet()))) {
/* 366 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 370 */     Set refdGEs = this.mRefdGEs;
/*     */     
/* 372 */     if ((refdGEs != null) && (refdGEs.size() > 0)) {
/* 373 */       HashMap intGEs = intSubset.getGeneralEntityMap();
/* 374 */       if ((intGEs != null) && (intGEs.size() > 0) && 
/* 375 */         (DataUtil.anyValuesInCommon(refdGEs, intGEs.keySet()))) {
/* 376 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 380 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 390 */     StringBuffer sb = new StringBuffer();
/* 391 */     sb.append("[DTDSubset: ");
/* 392 */     int count = getEntityCount();
/* 393 */     sb.append(count);
/* 394 */     sb.append(" general entities");
/* 395 */     sb.append(']');
/* 396 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void throwNotationException(NotationDecl oldDecl, NotationDecl newDecl)
/*     */     throws XMLStreamException
/*     */   {
/* 408 */     throw new WstxParsingException(MessageFormat.format(ErrorConsts.ERR_DTD_NOTATION_REDEFD, new Object[] { newDecl.getName(), oldDecl.getLocation().toString() }), newDecl.getLocation());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void throwElementException(DTDElement oldElem, Location loc)
/*     */     throws XMLStreamException
/*     */   {
/* 419 */     throw new WstxParsingException(MessageFormat.format(ErrorConsts.ERR_DTD_ELEM_REDEFD, new Object[] { oldElem.getDisplayName(), oldElem.getLocation().toString() }), loc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void combineMaps(HashMap m1, HashMap m2)
/*     */   {
/* 440 */     Iterator it = m2.entrySet().iterator();
/* 441 */     while (it.hasNext()) {
/* 442 */       Map.Entry me = (Map.Entry)it.next();
/* 443 */       Object key = me.getKey();
/*     */       
/*     */ 
/*     */ 
/* 447 */       Object old = m1.put(key, me.getValue());
/*     */       
/* 449 */       if (old != null) {
/* 450 */         m1.put(key, old);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void combineElements(InputProblemReporter rep, HashMap intElems, HashMap extElems)
/*     */     throws XMLStreamException
/*     */   {
/* 465 */     Iterator it = extElems.entrySet().iterator();
/* 466 */     while (it.hasNext()) {
/* 467 */       Map.Entry me = (Map.Entry)it.next();
/* 468 */       Object key = me.getKey();
/* 469 */       Object extVal = me.getValue();
/* 470 */       Object oldVal = intElems.get(key);
/*     */       
/*     */ 
/* 473 */       if (oldVal == null) {
/* 474 */         intElems.put(key, extVal);
/*     */       }
/*     */       else
/*     */       {
/* 478 */         DTDElement extElem = (DTDElement)extVal;
/* 479 */         DTDElement intElem = (DTDElement)oldVal;
/*     */         
/*     */ 
/* 482 */         if (extElem.isDefined()) {
/* 483 */           if (intElem.isDefined()) {
/* 484 */             throwElementException(intElem, extElem.getLocation());
/*     */ 
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/* 491 */             intElem.defineFrom(rep, extElem, this.mFullyValidating);
/*     */           }
/*     */         }
/* 494 */         else if (!intElem.isDefined())
/*     */         {
/*     */ 
/*     */ 
/* 498 */           rep.reportProblem(ErrorConsts.WT_ENT_DECL, ErrorConsts.W_UNDEFINED_ELEM, extElem.getDisplayName(), null, intElem.getLocation());
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 503 */           intElem.mergeMissingAttributesFrom(rep, extElem, this.mFullyValidating);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void checkNotations(HashMap fromInt, HashMap fromExt)
/*     */     throws XMLStreamException
/*     */   {
/* 518 */     Iterator it = fromExt.entrySet().iterator();
/* 519 */     while (it.hasNext()) {
/* 520 */       Map.Entry en = (Map.Entry)it.next();
/* 521 */       if (fromInt.containsKey(en.getKey())) {
/* 522 */         throwNotationException((NotationDecl)fromInt.get(en.getKey()), (NotationDecl)en.getValue());
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\DTDSubsetImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */