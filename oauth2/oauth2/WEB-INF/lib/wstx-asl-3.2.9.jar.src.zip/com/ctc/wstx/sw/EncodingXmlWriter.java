/*     */ package com.ctc.wstx.sw;
/*     */ 
/*     */ import com.ctc.wstx.api.WriterConfig;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class EncodingXmlWriter
/*     */   extends XmlWriter
/*     */ {
/*     */   static final int DEFAULT_BUFFER_SIZE = 4000;
/*     */   static final byte BYTE_SPACE = 32;
/*     */   static final byte BYTE_COLON = 58;
/*     */   static final byte BYTE_SEMICOLON = 59;
/*     */   static final byte BYTE_LBRACKET = 91;
/*     */   static final byte BYTE_RBRACKET = 93;
/*     */   static final byte BYTE_QMARK = 63;
/*     */   static final byte BYTE_EQ = 61;
/*     */   static final byte BYTE_SLASH = 47;
/*     */   static final byte BYTE_HASH = 35;
/*     */   static final byte BYTE_HYPHEN = 45;
/*     */   static final byte BYTE_LT = 60;
/*     */   static final byte BYTE_GT = 62;
/*     */   static final byte BYTE_AMP = 38;
/*     */   static final byte BYTE_QUOT = 34;
/*     */   static final byte BYTE_APOS = 39;
/*     */   static final byte BYTE_A = 97;
/*     */   static final byte BYTE_G = 103;
/*     */   static final byte BYTE_L = 108;
/*     */   static final byte BYTE_M = 109;
/*     */   static final byte BYTE_O = 111;
/*     */   static final byte BYTE_P = 112;
/*     */   static final byte BYTE_Q = 113;
/*     */   static final byte BYTE_S = 115;
/*     */   static final byte BYTE_T = 116;
/*     */   static final byte BYTE_U = 117;
/*     */   static final byte BYTE_X = 120;
/*     */   protected final OutputStream mOut;
/*     */   protected final byte[] mOutputBuffer;
/*     */   protected int mOutputPtr;
/* 102 */   protected int mSurrogate = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EncodingXmlWriter(OutputStream out, WriterConfig cfg, String encoding, boolean autoclose)
/*     */     throws IOException
/*     */   {
/* 114 */     super(cfg, encoding, autoclose);
/* 115 */     this.mOut = out;
/* 116 */     this.mOutputBuffer = new byte['ྠ'];
/* 117 */     this.mOutputPtr = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getOutputPtr()
/*     */   {
/* 125 */     return this.mOutputPtr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final OutputStream getOutputStream()
/*     */   {
/* 136 */     return this.mOut;
/*     */   }
/*     */   
/*     */ 
/*     */   protected final Writer getWriter()
/*     */   {
/* 142 */     return null;
/*     */   }
/*     */   
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 148 */     flush();
/* 149 */     if (this.mAutoCloseOutput) {
/* 150 */       this.mOut.close();
/*     */     }
/*     */   }
/*     */   
/*     */   public final void flush()
/*     */     throws IOException
/*     */   {
/* 157 */     flushBuffer();
/* 158 */     this.mOut.flush();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writeRaw(char[] paramArrayOfChar, int paramInt1, int paramInt2)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract void writeRaw(String paramString, int paramInt1, int paramInt2)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */   public final void writeCDataStart()
/*     */     throws IOException
/*     */   {
/* 177 */     writeAscii("<![CDATA[");
/*     */   }
/*     */   
/*     */   public final void writeCDataEnd()
/*     */     throws IOException
/*     */   {
/* 183 */     writeAscii("]]>");
/*     */   }
/*     */   
/*     */   public final void writeCommentStart()
/*     */     throws IOException
/*     */   {
/* 189 */     writeAscii("<!--");
/*     */   }
/*     */   
/*     */   public final void writeCommentEnd()
/*     */     throws IOException
/*     */   {
/* 195 */     writeAscii("-->");
/*     */   }
/*     */   
/*     */   public final void writePIStart(String target, boolean addSpace)
/*     */     throws IOException
/*     */   {
/* 201 */     writeAscii((byte)60, (byte)63);
/* 202 */     writeRaw(target);
/* 203 */     if (addSpace) {
/* 204 */       writeAscii((byte)32);
/*     */     }
/*     */   }
/*     */   
/*     */   public final void writePIEnd()
/*     */     throws IOException
/*     */   {
/* 211 */     writeAscii((byte)63, (byte)62);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int writeCData(String data)
/*     */     throws IOException
/*     */   {
/* 223 */     writeAscii("<![CDATA[");
/* 224 */     int ix = writeCDataContent(data);
/* 225 */     if (ix >= 0) {
/* 226 */       return ix;
/*     */     }
/* 228 */     writeAscii("]]>");
/* 229 */     return -1;
/*     */   }
/*     */   
/*     */   public int writeCData(char[] cbuf, int offset, int len)
/*     */     throws IOException
/*     */   {
/* 235 */     writeAscii("<![CDATA[");
/* 236 */     int ix = writeCDataContent(cbuf, offset, len);
/* 237 */     if (ix >= 0) {
/* 238 */       return ix;
/*     */     }
/* 240 */     writeAscii("]]>");
/* 241 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */   public final void writeCharacters(String data)
/*     */     throws IOException
/*     */   {
/* 248 */     if (this.mTextWriter != null) {
/* 249 */       this.mTextWriter.write(data);
/*     */     } else {
/* 251 */       writeTextContent(data);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public final void writeCharacters(char[] cbuf, int offset, int len)
/*     */     throws IOException
/*     */   {
/* 259 */     if (this.mTextWriter != null) {
/* 260 */       this.mTextWriter.write(cbuf, offset, len);
/*     */     } else {
/* 262 */       writeTextContent(cbuf, offset, len);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int writeComment(String data)
/*     */     throws IOException
/*     */   {
/* 276 */     writeAscii("<!--");
/* 277 */     int ix = writeCommentContent(data);
/* 278 */     if (ix >= 0) {
/* 279 */       return ix;
/*     */     }
/* 281 */     writeAscii("-->");
/* 282 */     return -1;
/*     */   }
/*     */   
/*     */   public void writeDTD(String data)
/*     */     throws IOException
/*     */   {
/* 288 */     if (this.mSurrogate != 0) {
/* 289 */       throwUnpairedSurrogate();
/*     */     }
/* 291 */     writeRaw(data, 0, data.length());
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeDTD(String rootName, String systemId, String publicId, String internalSubset)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 298 */     writeAscii("<!DOCTYPE ");
/* 299 */     writeAscii(rootName);
/* 300 */     if (systemId != null) {
/* 301 */       if (publicId != null) {
/* 302 */         writeAscii(" PUBLIC \"");
/* 303 */         writeRaw(publicId, 0, publicId.length());
/* 304 */         writeAscii("\" \"");
/*     */       } else {
/* 306 */         writeAscii(" SYSTEM \"");
/*     */       }
/* 308 */       writeRaw(systemId, 0, systemId.length());
/* 309 */       writeAscii((byte)34);
/*     */     }
/*     */     
/*     */ 
/* 313 */     if ((internalSubset != null) && (internalSubset.length() > 0)) {
/* 314 */       writeAscii((byte)32, (byte)91);
/* 315 */       writeRaw(internalSubset, 0, internalSubset.length());
/* 316 */       writeAscii((byte)93);
/*     */     }
/* 318 */     writeAscii((byte)62);
/*     */   }
/*     */   
/*     */   public void writeEntityReference(String name)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 324 */     if (this.mSurrogate != 0) {
/* 325 */       throwUnpairedSurrogate();
/*     */     }
/* 327 */     writeAscii((byte)38);
/* 328 */     writeName(name);
/* 329 */     writeAscii((byte)59);
/*     */   }
/*     */   
/*     */   public void writeXmlDeclaration(String version, String encoding, String standalone)
/*     */     throws IOException
/*     */   {
/* 335 */     writeAscii("<?xml version='");
/* 336 */     writeAscii(version);
/* 337 */     writeAscii((byte)39);
/*     */     
/* 339 */     if ((encoding != null) && (encoding.length() > 0)) {
/* 340 */       writeAscii(" encoding='");
/*     */       
/* 342 */       writeRaw(encoding, 0, encoding.length());
/* 343 */       writeAscii((byte)39);
/*     */     }
/* 345 */     if (standalone != null) {
/* 346 */       writeAscii(" standalone='");
/* 347 */       writeAscii(standalone);
/* 348 */       writeAscii((byte)39);
/*     */     }
/* 350 */     writeAscii((byte)63, (byte)62);
/*     */   }
/*     */   
/*     */   public int writePI(String target, String data)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 356 */     writeAscii((byte)60, (byte)63);
/* 357 */     writeName(target);
/* 358 */     if ((data != null) && (data.length() > 0)) {
/* 359 */       writeAscii((byte)32);
/* 360 */       int ix = writePIData(data);
/* 361 */       if (ix >= 0) {
/* 362 */         return ix;
/*     */       }
/*     */     }
/* 365 */     writeAscii((byte)63, (byte)62);
/* 366 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeStartTagStart(String localName)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 378 */     writeAscii((byte)60);
/* 379 */     writeName(localName);
/*     */   }
/*     */   
/*     */   public void writeStartTagStart(String prefix, String localName)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 385 */     if ((prefix == null) || (prefix.length() == 0)) {
/* 386 */       writeStartTagStart(localName);
/* 387 */       return;
/*     */     }
/* 389 */     writeAscii((byte)60);
/* 390 */     writeName(prefix);
/* 391 */     writeAscii((byte)58);
/* 392 */     writeName(localName);
/*     */   }
/*     */   
/*     */   public void writeStartTagEnd()
/*     */     throws IOException
/*     */   {
/* 398 */     writeAscii((byte)62);
/*     */   }
/*     */   
/*     */   public void writeStartTagEmptyEnd()
/*     */     throws IOException
/*     */   {
/* 404 */     writeAscii(" />");
/*     */   }
/*     */   
/*     */   public void writeEndTag(String localName)
/*     */     throws IOException
/*     */   {
/* 410 */     writeAscii((byte)60, (byte)47);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 415 */     writeNameUnchecked(localName);
/* 416 */     writeAscii((byte)62);
/*     */   }
/*     */   
/*     */   public void writeEndTag(String prefix, String localName)
/*     */     throws IOException
/*     */   {
/* 422 */     writeAscii((byte)60, (byte)47);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 427 */     if ((prefix != null) && (prefix.length() > 0)) {
/* 428 */       writeNameUnchecked(prefix);
/* 429 */       writeAscii((byte)58);
/*     */     }
/* 431 */     writeNameUnchecked(localName);
/* 432 */     writeAscii((byte)62);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeAttribute(String localName, String value)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 444 */     writeAscii((byte)32);
/* 445 */     writeName(localName);
/* 446 */     writeAscii((byte)61, (byte)34);
/*     */     
/* 448 */     int len = value.length();
/* 449 */     if (len > 0) {
/* 450 */       if (this.mAttrValueWriter != null) {
/* 451 */         this.mAttrValueWriter.write(value, 0, len);
/*     */       } else {
/* 453 */         writeAttrValue(value);
/*     */       }
/*     */     }
/* 456 */     writeAscii((byte)34);
/*     */   }
/*     */   
/*     */   public void writeAttribute(String localName, char[] value, int offset, int len)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 462 */     writeAscii((byte)32);
/* 463 */     writeName(localName);
/* 464 */     writeAscii((byte)61, (byte)34);
/*     */     
/* 466 */     if (len > 0) {
/* 467 */       if (this.mAttrValueWriter != null) {
/* 468 */         this.mAttrValueWriter.write(value, offset, len);
/*     */       } else {
/* 470 */         writeAttrValue(value, offset, len);
/*     */       }
/*     */     }
/* 473 */     writeAscii((byte)34);
/*     */   }
/*     */   
/*     */   public void writeAttribute(String prefix, String localName, String value)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 479 */     writeAscii((byte)32);
/* 480 */     writeName(prefix);
/* 481 */     writeAscii((byte)58);
/* 482 */     writeName(localName);
/* 483 */     writeAscii((byte)61, (byte)34);
/*     */     
/* 485 */     int len = value.length();
/* 486 */     if (len > 0) {
/* 487 */       if (this.mAttrValueWriter != null) {
/* 488 */         this.mAttrValueWriter.write(value, 0, len);
/*     */       } else {
/* 490 */         writeAttrValue(value);
/*     */       }
/*     */     }
/* 493 */     writeAscii((byte)34);
/*     */   }
/*     */   
/*     */   public void writeAttribute(String prefix, String localName, char[] value, int offset, int len)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 499 */     writeAscii((byte)32);
/* 500 */     writeName(prefix);
/* 501 */     writeAscii((byte)58);
/* 502 */     writeName(localName);
/* 503 */     writeAscii((byte)61, (byte)34);
/*     */     
/* 505 */     if (len > 0) {
/* 506 */       if (this.mAttrValueWriter != null) {
/* 507 */         this.mAttrValueWriter.write(value, offset, len);
/*     */       } else {
/* 509 */         writeAttrValue(value, offset, len);
/*     */       }
/*     */     }
/* 512 */     writeAscii((byte)34);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void flushBuffer()
/*     */     throws IOException
/*     */   {
/* 524 */     if (this.mOutputPtr > 0) {
/* 525 */       int ptr = this.mOutputPtr;
/* 526 */       this.mOutputPtr = 0;
/* 527 */       this.mOut.write(this.mOutputBuffer, 0, ptr);
/*     */     }
/*     */   }
/*     */   
/*     */   protected final void writeAscii(byte b)
/*     */     throws IOException
/*     */   {
/* 534 */     if (this.mSurrogate != 0) {
/* 535 */       throwUnpairedSurrogate();
/*     */     }
/* 537 */     if (this.mOutputPtr >= this.mOutputBuffer.length) {
/* 538 */       flushBuffer();
/*     */     }
/* 540 */     this.mOutputBuffer[(this.mOutputPtr++)] = b;
/*     */   }
/*     */   
/*     */   protected final void writeAscii(byte b1, byte b2)
/*     */     throws IOException
/*     */   {
/* 546 */     if (this.mSurrogate != 0) {
/* 547 */       throwUnpairedSurrogate();
/*     */     }
/* 549 */     if (this.mOutputPtr + 1 >= this.mOutputBuffer.length) {
/* 550 */       flushBuffer();
/*     */     }
/* 552 */     this.mOutputBuffer[(this.mOutputPtr++)] = b1;
/* 553 */     this.mOutputBuffer[(this.mOutputPtr++)] = b2;
/*     */   }
/*     */   
/*     */   protected final void writeAscii(String str)
/*     */     throws IOException
/*     */   {
/* 559 */     if (this.mSurrogate != 0) {
/* 560 */       throwUnpairedSurrogate();
/*     */     }
/*     */     
/* 563 */     int len = str.length();
/* 564 */     int ptr = this.mOutputPtr;
/* 565 */     byte[] buf = this.mOutputBuffer;
/* 566 */     if (ptr + len >= buf.length)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 571 */       if (len > buf.length) {
/* 572 */         writeRaw(str, 0, len);
/* 573 */         return;
/*     */       }
/* 575 */       flushBuffer();
/* 576 */       ptr = this.mOutputPtr;
/*     */     }
/* 578 */     this.mOutputPtr += len;
/* 579 */     for (int i = 0; i < len; i++) {
/* 580 */       buf[(ptr++)] = ((byte)str.charAt(i));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final int writeAsEntity(int c)
/*     */     throws IOException
/*     */   {
/* 593 */     byte[] buf = this.mOutputBuffer;
/* 594 */     int ptr = this.mOutputPtr;
/* 595 */     if (ptr + 10 >= buf.length) {
/* 596 */       flushBuffer();
/* 597 */       ptr = this.mOutputPtr;
/*     */     }
/* 599 */     buf[(ptr++)] = 38;
/*     */     
/*     */ 
/* 602 */     if (c < 256)
/*     */     {
/*     */ 
/*     */ 
/* 606 */       if (c == 38) {
/* 607 */         buf[(ptr++)] = 97;
/* 608 */         buf[(ptr++)] = 109;
/* 609 */         buf[(ptr++)] = 112;
/* 610 */       } else if (c == 60) {
/* 611 */         buf[(ptr++)] = 108;
/* 612 */         buf[(ptr++)] = 116;
/* 613 */       } else if (c == 62) {
/* 614 */         buf[(ptr++)] = 103;
/* 615 */         buf[(ptr++)] = 116;
/* 616 */       } else if (c == 39) {
/* 617 */         buf[(ptr++)] = 97;
/* 618 */         buf[(ptr++)] = 112;
/* 619 */         buf[(ptr++)] = 111;
/* 620 */         buf[(ptr++)] = 115;
/* 621 */       } else if (c == 34) {
/* 622 */         buf[(ptr++)] = 113;
/* 623 */         buf[(ptr++)] = 117;
/* 624 */         buf[(ptr++)] = 111;
/* 625 */         buf[(ptr++)] = 116;
/*     */       } else {
/* 627 */         buf[(ptr++)] = 35;
/* 628 */         buf[(ptr++)] = 120;
/*     */         
/* 630 */         if (c >= 16) {
/* 631 */           int digit = c >> 4;
/* 632 */           buf[(ptr++)] = ((byte)(digit < 10 ? 48 + digit : 87 + digit));
/* 633 */           c &= 0xF;
/*     */         }
/* 635 */         buf[(ptr++)] = ((byte)(c < 10 ? 48 + c : 87 + c));
/*     */       }
/*     */     } else {
/* 638 */       buf[(ptr++)] = 35;
/* 639 */       buf[(ptr++)] = 120;
/*     */       
/*     */ 
/* 642 */       int shift = 20;
/* 643 */       int origPtr = ptr;
/*     */       do
/*     */       {
/* 646 */         int digit = c >> shift & 0xF;
/* 647 */         if ((digit > 0) || (ptr != origPtr)) {
/* 648 */           buf[(ptr++)] = ((byte)(digit < 10 ? 48 + digit : 87 + digit));
/*     */         }
/* 650 */         shift -= 4;
/* 651 */       } while (shift > 0);
/* 652 */       c &= 0xF;
/* 653 */       buf[(ptr++)] = ((byte)(c < 10 ? 48 + c : 87 + c));
/*     */     }
/* 655 */     buf[(ptr++)] = 59;
/* 656 */     this.mOutputPtr = ptr;
/* 657 */     return ptr;
/*     */   }
/*     */   
/*     */   protected final void writeName(String name)
/*     */     throws IOException, XMLStreamException
/*     */   {
/* 663 */     if (this.mCheckNames) {
/* 664 */       verifyNameValidity(name, this.mNsAware);
/*     */     }
/*     */     
/* 667 */     writeRaw(name, 0, name.length());
/*     */   }
/*     */   
/*     */   protected final void writeNameUnchecked(String name)
/*     */     throws IOException
/*     */   {
/* 673 */     writeRaw(name, 0, name.length());
/*     */   }
/*     */   
/*     */ 
/*     */   protected final int calcSurrogate(int secondSurr)
/*     */     throws IOException
/*     */   {
/* 680 */     int firstSurr = this.mSurrogate;
/* 681 */     this.mSurrogate = 0;
/* 682 */     if ((firstSurr < 55296) || (firstSurr > 56319)) {
/* 683 */       throwUnpairedSurrogate(firstSurr);
/*     */     }
/*     */     
/*     */ 
/* 687 */     if ((secondSurr < 56320) || (secondSurr > 57343)) {
/* 688 */       throwUnpairedSurrogate(secondSurr);
/*     */     }
/* 690 */     int ch = 65536 + (firstSurr - 55296 << 10) + (secondSurr - 56320);
/* 691 */     if (ch > 1114111) {
/* 692 */       throw new IOException("Illegal surrogate character pair, resulting code 0x" + Integer.toHexString(ch) + " above legal XML character range");
/*     */     }
/* 694 */     return ch;
/*     */   }
/*     */   
/*     */   protected final void throwUnpairedSurrogate()
/*     */     throws IOException
/*     */   {
/* 700 */     int surr = this.mSurrogate;
/* 701 */     this.mSurrogate = 0;
/* 702 */     throwUnpairedSurrogate(surr);
/*     */   }
/*     */   
/*     */ 
/*     */   protected final void throwUnpairedSurrogate(int code)
/*     */     throws IOException
/*     */   {
/* 709 */     flush();
/* 710 */     throw new IOException("Unpaired surrogate character (0x" + Integer.toHexString(code) + ")");
/*     */   }
/*     */   
/*     */   protected abstract void writeAttrValue(String paramString)
/*     */     throws IOException;
/*     */   
/*     */   protected abstract void writeAttrValue(char[] paramArrayOfChar, int paramInt1, int paramInt2)
/*     */     throws IOException;
/*     */   
/*     */   protected abstract int writeCDataContent(String paramString)
/*     */     throws IOException;
/*     */   
/*     */   protected abstract int writeCDataContent(char[] paramArrayOfChar, int paramInt1, int paramInt2)
/*     */     throws IOException;
/*     */   
/*     */   protected abstract int writeCommentContent(String paramString)
/*     */     throws IOException;
/*     */   
/*     */   protected abstract int writePIData(String paramString)
/*     */     throws IOException, XMLStreamException;
/*     */   
/*     */   protected abstract void writeTextContent(String paramString)
/*     */     throws IOException;
/*     */   
/*     */   protected abstract void writeTextContent(char[] paramArrayOfChar, int paramInt1, int paramInt2)
/*     */     throws IOException;
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\sw\EncodingXmlWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */