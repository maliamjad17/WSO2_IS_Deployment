/*     */ package com.ctc.wstx.dtd;
/*     */ 
/*     */ import com.ctc.wstx.api.ReaderConfig;
/*     */ import com.ctc.wstx.api.ValidatorConfig;
/*     */ import com.ctc.wstx.exc.WstxIOException;
/*     */ import com.ctc.wstx.io.InputBootstrapper;
/*     */ import com.ctc.wstx.io.InputSourceFactory;
/*     */ import com.ctc.wstx.io.ReaderBootstrapper;
/*     */ import com.ctc.wstx.io.StreamBootstrapper;
/*     */ import com.ctc.wstx.io.WstxInputSource;
/*     */ import com.ctc.wstx.util.DefaultXmlSymbolTable;
/*     */ import com.ctc.wstx.util.SymbolTable;
/*     */ import com.ctc.wstx.util.URLUtil;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.codehaus.stax2.validation.XMLValidationSchema;
/*     */ import org.codehaus.stax2.validation.XMLValidationSchemaFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DTDSchemaFactory
/*     */   extends XMLValidationSchemaFactory
/*     */ {
/*  58 */   static final SymbolTable mRootSymbols = ;
/*     */   
/*  60 */   static { mRootSymbols.setInternStrings(true); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final ValidatorConfig mSchemaConfig;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DTDSchemaFactory()
/*     */   {
/*  75 */     this.mReaderConfig = ReaderConfig.createFullDefaults();
/*  76 */     this.mSchemaConfig = ValidatorConfig.createDefaults();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPropertySupported(String propName)
/*     */   {
/*  87 */     return this.mSchemaConfig.isPropertySupported(propName);
/*     */   }
/*     */   
/*     */   public boolean setProperty(String propName, Object value)
/*     */   {
/*  92 */     return this.mSchemaConfig.setProperty(propName, value);
/*     */   }
/*     */   
/*     */   public Object getProperty(String propName)
/*     */   {
/*  97 */     return this.mSchemaConfig.getProperty(propName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLValidationSchema createSchema(InputStream in, String encoding, String publicId, String systemId)
/*     */     throws XMLStreamException
/*     */   {
/* 110 */     ReaderConfig rcfg = createPrivateReaderConfig();
/* 111 */     return doCreateSchema(rcfg, StreamBootstrapper.getInstance(in, publicId, systemId), publicId, systemId, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public XMLValidationSchema createSchema(Reader r, String publicId, String systemId)
/*     */     throws XMLStreamException
/*     */   {
/* 119 */     ReaderConfig rcfg = createPrivateReaderConfig();
/* 120 */     return doCreateSchema(rcfg, ReaderBootstrapper.getInstance(r, publicId, systemId, null), publicId, systemId, null);
/*     */   }
/*     */   
/*     */ 
/*     */   public XMLValidationSchema createSchema(URL url)
/*     */     throws XMLStreamException
/*     */   {
/* 127 */     ReaderConfig rcfg = createPrivateReaderConfig();
/*     */     try {
/* 129 */       InputStream in = URLUtil.optimizedStreamFromURL(url);
/* 130 */       return doCreateSchema(rcfg, StreamBootstrapper.getInstance(in, null, null), null, url.toExternalForm(), url);
/*     */     }
/*     */     catch (IOException ioe)
/*     */     {
/* 134 */       throw new WstxIOException(ioe);
/*     */     }
/*     */   }
/*     */   
/*     */   public XMLValidationSchema createSchema(File f)
/*     */     throws XMLStreamException
/*     */   {
/* 141 */     ReaderConfig rcfg = createPrivateReaderConfig();
/*     */     try {
/* 143 */       URL url = f.toURL();
/* 144 */       return doCreateSchema(rcfg, StreamBootstrapper.getInstance(new FileInputStream(f), null, null), null, url.toExternalForm(), url);
/*     */     }
/*     */     catch (IOException ioe)
/*     */     {
/* 148 */       throw new WstxIOException(ioe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final ReaderConfig mReaderConfig;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XMLValidationSchema doCreateSchema(ReaderConfig rcfg, InputBootstrapper bs, String publicId, String systemId, URL ctxt)
/*     */     throws XMLStreamException
/*     */   {
/*     */     try
/*     */     {
/* 173 */       Reader r = bs.bootstrapInput(rcfg, false, 0);
/* 174 */       if (bs.declaredXml11()) {
/* 175 */         rcfg.enableXml11(true);
/*     */       }
/* 177 */       if (ctxt == null) {
/* 178 */         ctxt = URLUtil.urlFromCurrentDir();
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 185 */       WstxInputSource src = InputSourceFactory.constructEntitySource(rcfg, null, null, bs, publicId, systemId, 0, ctxt, r);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 192 */       return FullDTDReader.readExternalSubset(src, rcfg, null, true, bs.getDeclaredVersion());
/*     */     } catch (IOException ioe) {
/* 194 */       throw new WstxIOException(ioe);
/*     */     }
/*     */   }
/*     */   
/*     */   private ReaderConfig createPrivateReaderConfig()
/*     */   {
/* 200 */     return this.mReaderConfig.createNonShared(mRootSymbols.makeChild());
/*     */   }
/*     */ }


/* Location:              C:\Users\MuhammadAli\Desktop\MC\ISCODECOMPARE\wso2is-5.0.0\repository\deployment\server\webapps\oauth2.war!\WEB-INF\lib\wstx-asl-3.2.9.jar!\com\ctc\wstx\dtd\DTDSchemaFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */